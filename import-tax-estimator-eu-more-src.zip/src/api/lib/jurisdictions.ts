/**
 * Central registry of supported jurisdictions.
 *
 * - US/NZ/CH/NO are ingested into Postgres by the cron job.
 * - GB and EU member states (in this MVP) are looked up live.
 */

export const EU_JURISDICTIONS = [
  "AT",
  "BE",
  "BG",
  "CY",
  "CZ",
  "DE",
  "DK",
  "EE",
  "ES",
  "FI",
  "FR",
  "GR",
  "HR",
  "HU",
  "IE",
  "IT",
  "LT",
  "LU",
  "LV",
  "MT",
  "NL",
  "PL",
  "PT",
  "RO",
  "SE",
  "SI",
  "SK",
] as const;

export const SUPPORTED_JURISDICTIONS = [
  "US",
  "NZ",
  "CH",
  "GB",
  "NO",
  ...EU_JURISDICTIONS,
] as const;

export type SupportedJurisdictionId = (typeof SUPPORTED_JURISDICTIONS)[number];

export function isEuJurisdiction(jurisdictionId: string): jurisdictionId is (typeof EU_JURISDICTIONS)[number] {
  return (EU_JURISDICTIONS as readonly string[]).includes(String(jurisdictionId ?? "").toUpperCase());
}
