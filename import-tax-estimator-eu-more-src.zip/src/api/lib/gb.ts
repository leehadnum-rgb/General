import { parseRateToAst } from "../../ingest/lib/parseRateToAst";

export type GbLiveMeasure = {
  measureId: string;
  measureType: "CUSTOMS_DUTY";
  originScope: "MFN" | "PREFERENTIAL" | "ALL";
  originCode: string;
  excludedOriginCodes?: string[] | null;
  expression: { expressionId: string; exprType: "AST" | "CUSTOM"; ast: any; sourceRef?: string | null; raw?: any };
};

export type GbLiveTariff = {
  code: string;
  description: string;
  currency: string;
  vatLabel: string;
  vatRatePct: number;
  vatBaseAst: any;
  measures: GbLiveMeasure[];
  unsupported: any[];
  sourceRef: string;
};

const DEFAULT_BASE_URL = "https://www.trade-tariff.service.gov.uk/uk/api";
const DEFAULT_ACCEPT = "application/vnd.hmrc.2.0+json";

const VAT_BASE_AST = {
  op: "add",
  terms: [
    { op: "field", name: "customs_value" },
    { op: "field", name: "customs_duty_total" },
    { op: "field", name: "fees_total" },
    { op: "field", name: "freight_to_border" },
    { op: "field", name: "insurance_to_border" },
  ],
};

type IncludedObj = { id: any; type: string; attributes?: any; relationships?: any };

function normalizeCode(code: string): string {
  return (code ?? "").replace(/[^0-9]/g, "");
}

function getRelId(rel: any): string | null {
  const d = rel?.data;
  if (!d) return null;
  if (Array.isArray(d) && d.length) return String(d[0]?.id ?? "");
  if (typeof d === "object") return String((d as any).id ?? "");
  return null;
}

function getRelIds(rel: any): string[] {
  const d = rel?.data;
  if (!d) return [];
  if (Array.isArray(d)) return d.map((x) => String(x?.id ?? "")).filter(Boolean);
  if (typeof d === "object") return [String((d as any).id ?? "")].filter(Boolean);
  return [];
}

const UNIT_MAP: Record<string, { unit: string; multiplier: number }> = {
  KGM: { unit: "kg", multiplier: 1 },
  GRM: { unit: "g", multiplier: 1 },
  TNE: { unit: "tonne", multiplier: 1 },
  LTR: { unit: "litre", multiplier: 1 },
  HLT: { unit: "litre", multiplier: 100 }, // hectolitre
  NAR: { unit: "item", multiplier: 1 },
  CEN: { unit: "item", multiplier: 100 }, // hundred items (best-effort)
};

function componentToRateTerm(comp: any): string | null {
  const a = comp?.attributes ?? comp ?? {};

  const dutyAmountRaw = a.duty_amount ?? a.dutyAmount ?? a.duty_amount_formatted ?? a.dutyAmountFormatted;
  const dutyAmount = Number(dutyAmountRaw);
  if (!Number.isFinite(dutyAmount)) return null;

  const monetary = a.monetary_unit_code ?? a.monetaryUnitCode ?? null;
  const measurement = a.measurement_unit_code ?? a.measurementUnitCode ?? null;

  // Ad valorem
  if (!monetary && !measurement) {
    return `${dutyAmount}%`;
  }

  const currency = String(monetary ?? "GBP");
  const unitInfo = measurement ? UNIT_MAP[String(measurement)] : null;
  if (!unitInfo) return null;

  const mult = unitInfo.multiplier;
  const multPart = mult === 1 ? "" : `${mult} `;

  return `${dutyAmount} ${currency} / ${multPart}${unitInfo.unit}`;
}

async function fetchJson(url: string, accept: string, timeoutMs: number): Promise<any> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { headers: { Accept: accept }, signal: ctrl.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status} fetching ${url}`);
    return await res.json();
  } finally {
    clearTimeout(t);
  }
}

type CacheEntry = { expiresAt: number; value: GbLiveTariff };
const cache = new Map<string, CacheEntry>();

export async function fetchGbLiveTariff(codeInput: string): Promise<GbLiveTariff> {
  const baseUrl = process.env.GB_TARIFF_API_BASE_URL ?? DEFAULT_BASE_URL;
  const accept = process.env.GB_TARIFF_ACCEPT ?? DEFAULT_ACCEPT;
  const timeoutMs = Number(process.env.GB_HTTP_TIMEOUT_MS ?? process.env.HTTP_TIMEOUT_MS ?? "30000");
  const ttlMs = Number(process.env.GB_CACHE_TTL_MS ?? "86400000");

  const mfnMeasureTypeId = String(process.env.GB_MFN_MEASURE_TYPE_ID ?? "103").trim();
  const preferentialMeasureTypeIds = String(process.env.GB_PREFERENTIAL_MEASURE_TYPE_IDS ?? "142")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);

  let code = normalizeCode(codeInput);
  // UK goods nomenclature item IDs are 10 digits; pad higher-level codes with trailing zeros.
  if (code.length > 0 && code.length < 10) code = code.padEnd(10, "0");

  const cacheKey = `GB:${code}`;
  const hit = cache.get(cacheKey);
  if (hit && hit.expiresAt > Date.now()) return hit.value;

  const url = `${baseUrl.replace(/\/$/, "")}/commodities/${code}`;
  const json = await fetchJson(url, accept, timeoutMs);

  const data = json?.data;
  const attrs = data?.attributes ?? {};
  const description =
    String(attrs.formatted_description ?? attrs.description_plain ?? attrs.description ?? "").trim() ||
    `Commodity ${code}`;

  const included: IncludedObj[] = Array.isArray(json?.included) ? json.included : [];

  const byKey = new Map<string, IncludedObj>();
  for (const obj of included) {
    if (!obj || typeof obj !== "object") continue;
    byKey.set(`${obj.type}:${obj.id}`, obj);
  }

  const measures: GbLiveMeasure[] = [];
  const unsupported: any[] = [];

  // VAT (best-effort): try to derive rate from measure type 305 or vat=true
  let vatRatePct = Number(process.env.GB_VAT_RATE_PCT ?? "20");

  const measureObjs = included.filter((x) => x?.type === "measure");

  for (const m of measureObjs) {
    const measureTypeId = getRelId(m.relationships?.measure_type) ?? "";

    if (measureTypeId === "305" || m.attributes?.vat === true) {
      const compIds = getRelIds(m.relationships?.measure_components);
      for (const cid of compIds) {
        const comp = byKey.get(`measure_component:${cid}`);
        const a = comp?.attributes ?? {};
        const dutyAmount = Number(a.duty_amount ?? a.dutyAmount);
        const monetary = a.monetary_unit_code ?? a.monetaryUnitCode;
        const measurement = a.measurement_unit_code ?? a.measurementUnitCode;
        if (Number.isFinite(dutyAmount) && !monetary && !measurement) {
          vatRatePct = dutyAmount;
          break;
        }
      }
    }
  }

  // Customs duty measures:
  // - MFN ("third country duty") is usually measure type 103
  // - Preferences are often represented by other measure types (e.g. 142)
  for (const m of measureObjs) {
    const measureTypeId = getRelId(m.relationships?.measure_type) ?? "";

    const isMfn = measureTypeId === mfnMeasureTypeId;
    const isPreferential = preferentialMeasureTypeIds.includes(measureTypeId);
    if (!isMfn && !isPreferential) continue;

    const geoId = getRelId(m.relationships?.geographical_area) ?? "";
    const excluded = Array.from(
      new Set([
        ...getRelIds(m.relationships?.excluded_geographical_areas),
        ...getRelIds(m.relationships?.excluded_geographical_area),
      ])
    ).filter(Boolean);

    const compIds = getRelIds(m.relationships?.measure_components);

    // Strategy A: verbose duty string (if present)
    const verbose = m.attributes?.duty_expression?.verbose_duty ?? m.attributes?.verbose_duty;
    let rawDuty: string | null = typeof verbose === "string" ? verbose : null;

    // Strategy B: build from components
    if (!rawDuty && compIds.length) {
      const parts: string[] = [];
      for (const cid of compIds) {
        const comp = byKey.get(`measure_component:${cid}`);
        const term = componentToRateTerm(comp);
        if (term) parts.push(term);
      }
      if (parts.length) rawDuty = parts.join(" + ");
    }

    // Strategy C: fallback to commodity-level basic_duty_rate (if present)
    if (!rawDuty && typeof attrs.basic_duty_rate === "string") {
      rawDuty = String(attrs.basic_duty_rate);
    }

    const sid = String(m.id ?? "").trim() || `${measureTypeId}:${geoId || "NA"}`;
    const expressionId = `gb:${code}:expr:${measureTypeId}:${sid}`;
    const measureId = `gb:${code}:measure:${measureTypeId}:${sid}`;

    if (!rawDuty) {
      unsupported.push({ measureId, measureTypeId, reason: "no_duty_expression_found" });
      continue;
    }

    const parsed = parseRateToAst(rawDuty, {
      defaultCurrency: "GBP",
      defaultMassField: "net_mass_kg",
      defaultCountField: "quantity",
      defaultVolumeField: "volume_litre",
    });

    if (!parsed.ok) {
      measures.push({
        measureId,
        measureType: "CUSTOMS_DUTY",
        originScope: isMfn ? "MFN" : "PREFERENTIAL",
        originCode: isMfn ? "ALL" : (geoId || "UNKNOWN"),
        excludedOriginCodes: excluded.length ? excluded : null,
        expression: {
          expressionId,
          exprType: "CUSTOM",
          ast: { op: "manual_required", raw: rawDuty, reason: parsed.reason, message: parsed.message },
          sourceRef: url,
          raw: rawDuty,
        },
      });
      unsupported.push({ measureId, reason: "manual_or_unsupported_expression", raw: rawDuty, detail: parsed });
      continue;
    }

    measures.push({
      measureId,
      measureType: "CUSTOMS_DUTY",
      originScope: isMfn ? "MFN" : "PREFERENTIAL",
      originCode: isMfn ? "ALL" : (geoId || "UNKNOWN"),
      excludedOriginCodes: excluded.length ? excluded : null,
      expression: { expressionId, exprType: "AST", ast: parsed.ast, sourceRef: url, raw: rawDuty },
    });
  }

  if (!measures.length) {
    unsupported.push({
      measureTypeId: mfnMeasureTypeId,
      reason: "no_mfn_duty_measure_found",
      message: `No MFN duty measure (measure type ${mfnMeasureTypeId}) could be extracted for this code.`,
    });
  }

  const value: GbLiveTariff = {
    code,
    description,
    currency: "GBP",
    vatLabel: "VAT",
    vatRatePct,
    vatBaseAst: VAT_BASE_AST,
    measures,
    unsupported,
    sourceRef: url,
  };

  cache.set(cacheKey, { expiresAt: Date.now() + ttlMs, value });
  return value;
}
