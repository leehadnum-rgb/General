import { parseRateToAst } from "../../ingest/lib/parseRateToAst";

/**
 * EU (TARIC) live lookup using the public ISZTAR4 REST API published by the
 * Polish Ministry of Finance.
 *
 * We use it as a best-effort proxy for EU common tariff (customs duty + preferences).
 * National levies (VAT/excise) differ by member state, so VAT is configured per
 * jurisdiction via env vars.
 */

export type EuLiveMeasure = {
  measureId: string;
  measureType: "CUSTOMS_DUTY";
  originScope: "MFN" | "PREFERENTIAL" | "ALL";
  originCode: string;
  excludedOriginCodes?: string[] | null;
  originMemberCodes?: string[] | null;
  expression: {
    expressionId: string;
    exprType: "AST" | "CUSTOM";
    ast: any;
    sourceRef?: string | null;
    raw?: any;
  };
};

export type EuLiveTariff = {
  code: string;
  description: string;
  currency: string;
  vatLabel: string;
  vatRatePct: number;
  vatBaseAst: any;
  measures: EuLiveMeasure[];
  unsupported: any[];
  sourceRef: string;
};

const DEFAULT_BASE_URL = "https://ext-isztar4.mf.gov.pl/tariff/rest";

const VAT_BASE_AST = {
  op: "add",
  terms: [
    { op: "field", name: "customs_value" },
    { op: "field", name: "customs_duty_total" },
    { op: "field", name: "fees_total" },
    { op: "field", name: "freight_to_border" },
    { op: "field", name: "insurance_to_border" },
  ],
};

function normalizeCode(code: string): string {
  let c = (code ?? "").replace(/[^0-9]/g, "");
  if (c.length > 0 && c.length < 10) c = c.padEnd(10, "0");
  return c;
}

function slug(s: string): string {
  return (s ?? "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 60) || "m";
}

async function fetchJson(url: string, timeoutMs: number): Promise<any> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { headers: { Accept: "application/json" }, signal: ctrl.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status} fetching ${url}`);
    return await res.json();
  } finally {
    clearTimeout(t);
  }
}

type CacheEntry<T> = { expiresAt: number; value: T };
const tariffCache = new Map<string, CacheEntry<{ description: string; measuresJson: any; sourceRef: string }>>();
const groupCache = new Map<string, CacheEntry<string[]>>();

async function fetchGroupMembers(groupCode: string, baseUrl: string, timeoutMs: number, ttlMs: number): Promise<string[] | null> {
  const key = String(groupCode ?? "").trim();
  if (!key) return null;

  const cacheKey = `GROUP:${key}`;
  const hit = groupCache.get(cacheKey);
  if (hit && hit.expiresAt > Date.now()) return hit.value;

  const url = `${baseUrl.replace(/\/$/, "")}/geographic-area/details?countryGroupCode=${encodeURIComponent(key)}`;
  try {
    const json = await fetchJson(url, timeoutMs);
    const areas = Array.isArray(json?.geographicAreas) ? json.geographicAreas : [];
    const first = areas[0] ?? null;
    const rel = Array.isArray(first?.relatedCodes) ? first.relatedCodes : [];
    const codes = rel.map((x: any) => String(x?.code ?? "").trim().toUpperCase()).filter((c: string) => /^[A-Z]{2}$/.test(c));
    groupCache.set(cacheKey, { expiresAt: Date.now() + ttlMs, value: codes });
    return codes;
  } catch {
    return null;
  }
}

function isThirdCountryDuty(desc: string): boolean {
  const d = (desc ?? "").toLowerCase();
  return d.includes("third country duty") || d.includes("conventional duty") || d.includes("mfn");
}

function isPreferentialDuty(desc: string): boolean {
  const d = (desc ?? "").toLowerCase();
  return d.includes("tariff preference") || d.includes("customs union duty");
}

function shouldIgnoreMeasure(desc: string): boolean {
  const d = (desc ?? "").toLowerCase();
  // We keep this MVP conservative: ignore measures likely to require extra conditions (quotas, suspensions, trade defence, etc.)
  const ignore = [
    "additional dut", // additional duties
    "anti-dumping",
    "countervailing",
    "tariff quota",
    "quota",
    "suspension",
    "autonomous tariff",
    "import control",
    "prohibition",
    "excise",
    "vat",
  ];
  return ignore.some((k) => d.includes(k));
}

export function euVatRatePctForJurisdiction(jurisdictionId: string): number {
  const j = String(jurisdictionId ?? "").trim().toUpperCase();
  const envKey = `${j}_VAT_RATE_PCT`;
  const raw = process.env[envKey];
  if (raw != null && raw !== "") {
    const n = Number(raw);
    if (Number.isFinite(n)) return n;
  }
  // Reasonable defaults (can be overridden per deployment)
  // Source: EU “VAT rates applied in EU member countries” table (standard rate). Last checked 30/10/2025.
  // (We keep these in code so new EU jurisdictions work out-of-the-box.)
  if (j === "AT") return 20;
  if (j === "BE") return 21;
  if (j === "BG") return 20;
  if (j === "CY") return 19;
  if (j === "CZ") return 21;
  if (j === "DE") return 19;
  if (j === "DK") return 25;
  if (j === "EE") return 24;
  if (j === "EL" || j === "GR") return 24;
  if (j === "ES") return 21;
  if (j === "FI") return 25.5;
  if (j === "FR") return 20;
  if (j === "HR") return 25;
  if (j === "HU") return 27;
  if (j === "IE") return 23;
  if (j === "IT") return 22;
  if (j === "LT") return 21;
  if (j === "LU") return 17;
  if (j === "LV") return 21;
  if (j === "MT") return 18;
  if (j === "NL") return 21;
  if (j === "PL") return 23;
  if (j === "PT") return 23;
  if (j === "RO") return 21;
  if (j === "SE") return 25;
  if (j === "SI") return 22;
  if (j === "SK") return 23;
  return Number(process.env.EU_VAT_RATE_PCT ?? "20") || 20;
}

export async function fetchEuLiveTariff(
  codeInput: string,
  asOfDate: string,
  jurisdictionId: string,
  opts?: { expandGroups?: boolean }
): Promise<EuLiveTariff> {
  const baseUrl = process.env.EU_TARIC_API_BASE_URL ?? DEFAULT_BASE_URL;
  const language = (process.env.EU_TARIC_LANGUAGE ?? "EN").trim().toUpperCase();
  const timeoutMs = Number(process.env.EU_HTTP_TIMEOUT_MS ?? process.env.HTTP_TIMEOUT_MS ?? "30000");
  const ttlMs = Number(process.env.EU_CACHE_TTL_MS ?? "86400000");

  let code = normalizeCode(codeInput);
  const date = (asOfDate ?? "").slice(0, 10);

  const cacheKey = `EU:${date}:${language}:${code}`;
  const hit = tariffCache.get(cacheKey);

  let description = `Commodity ${code}`;
  let measuresJson: any = null;
  let sourceRef = "";

  if (hit && hit.expiresAt > Date.now()) {
    description = hit.value.description;
    measuresJson = hit.value.measuresJson;
    sourceRef = hit.value.sourceRef;
  } else {
    sourceRef = `${baseUrl.replace(/\/$/, "")}/goods-nomenclature/measures?nomenclatureCode=${encodeURIComponent(code)}&date=${encodeURIComponent(date)}&language=${encodeURIComponent(language)}`;
    measuresJson = await fetchJson(sourceRef, timeoutMs);
    description = String(measuresJson?.nomenclature?.description ?? "").trim() || description;
    tariffCache.set(cacheKey, { expiresAt: Date.now() + ttlMs, value: { description, measuresJson, sourceRef } });
  }

  const measuresArr = Array.isArray(measuresJson?.tariffMeasures) ? measuresJson.tariffMeasures : [];

  const measures: EuLiveMeasure[] = [];
  const unsupported: any[] = [];

  const expandGroups = Boolean(opts?.expandGroups);
  const groupMembersByCode = new Map<string, string[] | null>();
  if (expandGroups) {
    // Pre-fetch group memberships so we can later match preferential measures by ISO origin.
    // (We still build measures without originMemberCodes if the lookup fails.)
    const groupCodes = Array.from(
      new Set<string>(
        measuresArr
          .map((m: any) => ({ code: String(m?.country?.code ?? "").trim(), group: Boolean(m?.country?.group) }))
          .filter((x: any) => x.group && x.code && x.code.toUpperCase() !== "ERGA OMNES")
          .map((x: any) => x.code)
      )
    );

    for (const gc of groupCodes) {
      const mem = await fetchGroupMembers(gc, baseUrl, timeoutMs, ttlMs);
      groupMembersByCode.set(gc, mem);
    }
  }

  let idx = 0;
  for (const tm of measuresArr) {
    idx += 1;
    const desc = String(tm?.description ?? "").trim();
    const dutyRaw = String(tm?.dutyAmount ?? tm?.dutyAmountWithCodes ?? "").trim();

    if (!dutyRaw) continue;

    if (!isThirdCountryDuty(desc) && !isPreferentialDuty(desc)) {
      if (shouldIgnoreMeasure(desc)) {
        unsupported.push({ kind: "ignored_measure", reason: "ignored_measure_kind", description: desc, duty: dutyRaw });
      }
      continue;
    }

    const countryCode = String(tm?.country?.code ?? "").trim();
    const countryIsGroup = Boolean(tm?.country?.group);
    const excluded = Array.isArray(tm?.excludedCountries)
      ? tm.excludedCountries.map((x: any) => String(x?.code ?? "").trim().toUpperCase()).filter((c: string) => /^[A-Z]{2}$/.test(c))
      : [];

    const originScope: EuLiveMeasure["originScope"] = isThirdCountryDuty(desc) ? "MFN" : "PREFERENTIAL";
    const originCode = originScope === "MFN" ? "ALL" : (countryCode || "UNKNOWN");
    const originMemberCodes =
      originScope === "PREFERENTIAL" && countryIsGroup && expandGroups
        ? (groupMembersByCode.get(countryCode) ?? null)
        : null;

    const sid = `${slug(desc)}:${countryCode || "NA"}:${idx}`;
    const expressionId = `eu:${code}:expr:${sid}`;
    const measureId = `eu:${code}:measure:${sid}`;

    const parsed = parseRateToAst(dutyRaw, {
      defaultCurrency: "EUR",
      defaultMassField: "net_mass_kg",
      defaultCountField: "quantity",
      defaultVolumeField: "volume_litre",
    });

    if (!parsed.ok) {
      measures.push({
        measureId,
        measureType: "CUSTOMS_DUTY",
        originScope,
        originCode,
        excludedOriginCodes: excluded.length ? excluded : null,
        originMemberCodes: originMemberCodes && originMemberCodes.length ? originMemberCodes : null,
        expression: {
          expressionId,
          exprType: "CUSTOM",
          ast: { op: "manual_required", raw: dutyRaw, reason: parsed.reason, message: parsed.message },
          sourceRef,
          raw: dutyRaw,
        },
      });
      unsupported.push({ measureId, reason: "manual_or_unsupported_expression", raw: dutyRaw, detail: parsed });
      continue;
    }

    measures.push({
      measureId,
      measureType: "CUSTOMS_DUTY",
      originScope,
      originCode,
      excludedOriginCodes: excluded.length ? excluded : null,
      originMemberCodes: originMemberCodes && originMemberCodes.length ? originMemberCodes : null,
      expression: {
        expressionId,
        exprType: "AST",
        ast: parsed.ast,
        sourceRef,
        raw: dutyRaw,
      },
    });
  }

  const vatRatePct = euVatRatePctForJurisdiction(jurisdictionId);

  return {
    code,
    description,
    currency: "EUR",
    vatLabel: "VAT",
    vatRatePct,
    vatBaseAst: VAT_BASE_AST,
    measures,
    unsupported,
    sourceRef,
  };
}
