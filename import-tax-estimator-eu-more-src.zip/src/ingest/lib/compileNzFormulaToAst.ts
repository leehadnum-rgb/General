export type NzCompileOk = {
  ok: true;
  exprType: "AD_VALOREM" | "SPECIFIC" | "COMPOUND";
  ast: any;
  requiredFields: string[];
};

export type NzCompileErr = {
  ok: false;
  reason: "MANUAL_REQUIRED" | "MISSING_QTY_FIELD" | "UNSUPPORTED_FORMULA";
  message: string;
  raw: any;
};

function astAdValorem(ratePct: number, base = "customs_value") {
  return { op: "ad_valorem", rate_pct: ratePct, base };
}

function astSpecific(amount: string, currency: string, qtyField: string, unit: string) {
  return { op: "specific", amount, currency, per: { qty_field: qtyField, unit } };
}

function astAdd(terms: any[]) {
  return { op: "add", terms };
}

export function compileNzFormulaToAst(args: {
  formulaCode: string | number;
  factorA?: string | null;
  factorB?: string | null;
  dutyCurrency: string;
  qtyField?: string | null;
  qtyUnit?: "kg" | "L" | "item";
}): NzCompileOk | NzCompileErr {
  const code = String(args.formulaCode ?? "").padStart(2, "0");

  if (code === "01") {
    return { ok: true, exprType: "AD_VALOREM", ast: astAdValorem(0), requiredFields: ["customs_value"] };
  }

  if (code === "02") {
    return { ok: false, reason: "MANUAL_REQUIRED", message: "NZ formula 02: manual calculation required", raw: args };
  }

  if (code === "03") {
    const a = args.factorA ? Number(args.factorA) : NaN;
    if (!Number.isFinite(a)) return { ok: false, reason: "MANUAL_REQUIRED", message: "Missing/invalid Factor A for formula 03", raw: args };
    return { ok: true, exprType: "AD_VALOREM", ast: astAdValorem(a), requiredFields: ["customs_value"] };
  }

  if (code === "04") {
    if (!args.qtyField || !args.qtyUnit) return { ok: false, reason: "MISSING_QTY_FIELD", message: "Formula 04 requires a QTY field/unit", raw: args };
    if (!args.factorA) return { ok: false, reason: "MANUAL_REQUIRED", message: "Missing Factor A for formula 04", raw: args };
    return {
      ok: true,
      exprType: "SPECIFIC",
      ast: astSpecific(args.factorA, args.dutyCurrency, args.qtyField, args.qtyUnit),
      requiredFields: [args.qtyField],
    };
  }

  if (code === "05") {
    const a = args.factorA ? Number(args.factorA) : NaN;
    if (!Number.isFinite(a)) return { ok: false, reason: "MANUAL_REQUIRED", message: "Missing/invalid Factor A for formula 05", raw: args };
    if (!args.factorB) return { ok: false, reason: "MANUAL_REQUIRED", message: "Missing Factor B for formula 05", raw: args };
    if (!args.qtyField || !args.qtyUnit) return { ok: false, reason: "MISSING_QTY_FIELD", message: "Formula 05 requires a QTY field/unit", raw: args };

    return {
      ok: true,
      exprType: "COMPOUND",
      ast: astAdd([astAdValorem(a), astSpecific(args.factorB, args.dutyCurrency, args.qtyField, args.qtyUnit)]),
      requiredFields: [args.qtyField, "customs_value"],
    };
  }

  return { ok: false, reason: "UNSUPPORTED_FORMULA", message: `Unsupported NZ formula ${code} (MVP supports 01–05)`, raw: args };
}
