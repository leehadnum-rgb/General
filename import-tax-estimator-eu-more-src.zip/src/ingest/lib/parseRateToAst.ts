import Decimal from "decimal.js";

export type ParseOk = {
  ok: true;
  exprType: "AD_VALOREM" | "SPECIFIC" | "COMPOUND";
  ast: any;
  requiredFields: string[];
  normalized: string;
  warnings: string[];
};

export type ParseErr = {
  ok: false;
  reason: "MANUAL_REQUIRED" | "UNSUPPORTED_FORMAT" | "EMPTY";
  message: string;
  raw: string;
};

export type ParseRateOptions = {
  defaultCurrency: string;
  defaultMassField?: "net_mass_kg" | "gross_mass_kg";
  defaultCountField?: "quantity";
  defaultVolumeField?: "volume_litre";
};

const MANUAL_TRIGGERS = [
  "see",
  "chapter 99",
  "subchapter",
  "9903",
  "note",
  "additional duty",
  "safeguard",
  "quota",
  "suspended",
];

function norm(s: string): string {
  return s
    .replace(/\u00A0/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function inferCurrency(text: string, fallback: string): string {
  const t = text.toUpperCase();
  if (t.includes("CHF")) return "CHF";
  if (t.includes("NZD")) return "NZD";
  if (t.includes("EUR")) return "EUR";
  if (t.includes("GBP")) return "GBP";
  if (t.includes("USD")) return "USD";
  if (t.includes("$")) return "USD";
  return fallback.toUpperCase();
}

type UnitInfo = {
  qtyField: string;
  baseUnit: "kg" | "L" | "item";
  originalMultiplierInBaseUnits: Decimal;
};

function parseUnit(text: string, opts: ParseRateOptions): UnitInfo | null {
  const t = text.toLowerCase();

  const m = t.match(/(?:per|\/)\s*(\d+(?:\.\d+)?)?\s*(kg|g|t|tonne|tonnes|l|litre|liter|ml|each|ea\.?|no\.?|pcs|piece|item)\b/);
  if (!m) return null;

  const multStr = m[1];
  const unit = m[2];
  const mult = multStr ? new Decimal(multStr) : new Decimal(1);

  const saysGross = t.includes("gross");
  const saysNet = t.includes("net");

  const massField =
    saysGross ? "gross_mass_kg" :
    saysNet ? "net_mass_kg" :
    (opts.defaultMassField ?? "net_mass_kg");

  const countField = opts.defaultCountField ?? "quantity";
  const volumeField = opts.defaultVolumeField ?? "volume_litre";

  if (unit === "kg") {
    return { qtyField: massField, baseUnit: "kg", originalMultiplierInBaseUnits: mult };
  }
  if (unit === "g") {
    return { qtyField: massField, baseUnit: "kg", originalMultiplierInBaseUnits: mult.mul(new Decimal("0.001")) };
  }
  if (unit === "t" || unit === "tonne" || unit === "tonnes") {
    return { qtyField: massField, baseUnit: "kg", originalMultiplierInBaseUnits: mult.mul(new Decimal("1000")) };
  }
  if (unit === "l" || unit === "litre" || unit === "liter") {
    return { qtyField: volumeField, baseUnit: "L", originalMultiplierInBaseUnits: mult };
  }
  if (unit === "ml") {
    return { qtyField: volumeField, baseUnit: "L", originalMultiplierInBaseUnits: mult.mul(new Decimal("0.001")) };
  }
  if (unit === "each" || unit === "ea." || unit === "ea" || unit === "no." || unit === "pcs" || unit === "piece" || unit === "item") {
    return { qtyField: countField, baseUnit: "item", originalMultiplierInBaseUnits: mult };
  }

  return null;
}

function astAdValorem(ratePct: number, base = "customs_value") {
  return { op: "ad_valorem", rate_pct: ratePct, base };
}

function astSpecific(amountPerBaseUnit: Decimal, currency: string, qtyField: string, unit: string) {
  return {
    op: "specific",
    amount: amountPerBaseUnit.toFixed(),
    currency,
    per: { qty_field: qtyField, unit },
  };
}

function astAdd(terms: any[]) {
  return { op: "add", terms };
}

export function parseRateToAst(raw: string, opts: ParseRateOptions): ParseOk | ParseErr {
  const original = raw ?? "";
  let text = norm(original);

  if (!text) return { ok: false, reason: "EMPTY", message: "Empty rate text", raw: original };

  text = text.replace(/\([A-Za-z0-9]+\)/g, "").trim();

  const lower = text.toLowerCase();
  if (MANUAL_TRIGGERS.some((k) => lower.includes(k))) {
    return { ok: false, reason: "MANUAL_REQUIRED", message: "Rate references other provisions (manual)", raw: original };
  }

  if (/\bon\b/.test(lower) && /(content|sugar|lead|nicotine|alcohol|cocoa|milkfat)/.test(lower)) {
    return { ok: false, reason: "MANUAL_REQUIRED", message: "Rate depends on special basis (manual)", raw: original };
  }

  if (/^free$/i.test(text) || /^nil$/i.test(text) || /^0(\.0+)?%?$/.test(text)) {
    return {
      ok: true,
      exprType: "AD_VALOREM",
      ast: astAdValorem(0),
      requiredFields: ["customs_value"],
      normalized: "0%",
      warnings: [],
    };
  }

  if (/\sor\s/i.test(text)) {
    return { ok: false, reason: "MANUAL_REQUIRED", message: "Alternative/conditional duty text (manual)", raw: original };
  }

  const parts = text.split("+").map((p) => norm(p)).filter(Boolean);
  const terms: any[] = [];
  const required = new Set<string>();
  const warnings: string[] = [];

  for (const p of parts) {
    const pct = p.match(/(\d+(?:\.\d+)?)\s*%/);
    if (pct) {
      const rate = Number(pct[1]);
      terms.push(astAdValorem(rate));
      required.add("customs_value");
      continue;
    }

    const currency = inferCurrency(p, opts.defaultCurrency);
    const isCents = p.includes("¢") || /\bcent(s)?\b/i.test(p);

    const numMatch = p.match(/(\d+(?:\.\d+)?)/);
    if (!numMatch) {
      return { ok: false, reason: "UNSUPPORTED_FORMAT", message: `No numeric amount found in "${p}"`, raw: original };
    }
    let amount = new Decimal(numMatch[1]);

    const unit = parseUnit(p, opts);
    if (!unit) {
      return { ok: false, reason: "UNSUPPORTED_FORMAT", message: `Unsupported or missing unit in "${p}"`, raw: original };
    }

    if (isCents) {
      amount = amount.div(100);
      if (currency !== "USD") warnings.push(`Parsed cents as 1/100 of ${currency} (check source)`);
    }

    const amountPerBase = amount.div(unit.originalMultiplierInBaseUnits);
    const unitLabel = unit.baseUnit;

    terms.push(astSpecific(amountPerBase, currency, unit.qtyField, unitLabel));
    required.add(unit.qtyField);
  }

  if (terms.length === 0) {
    return { ok: false, reason: "UNSUPPORTED_FORMAT", message: `Could not parse "${text}"`, raw: original };
  }

  if (terms.length === 1) {
    const only = terms[0];
    const exprType = only.op === "ad_valorem" ? "AD_VALOREM" : "SPECIFIC";
    return { ok: true, exprType, ast: only, requiredFields: [...required], normalized: text, warnings };
  }

  return { ok: true, exprType: "COMPOUND", ast: astAdd(terms), requiredFields: [...required], normalized: text, warnings };
}
