import { v4 as uuidv4 } from "uuid";
import { Connector, ConnectorResult, RunContext } from "./base";
import * as XLSX from "xlsx";
import { parseRateToAst } from "../lib/parseRateToAst";

const OPEN_END = process.env.OPEN_END_DATE ?? "9999-12-31";

function timeoutMs() {
  return Number(process.env.HTTP_TIMEOUT_MS ?? "30000");
}

async function downloadBuffer(url: string): Promise<Buffer> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs());
  try {
    const res = await fetch(url, { signal: ctrl.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
    const ab = await res.arrayBuffer();
    return Buffer.from(ab);
  } finally {
    clearTimeout(t);
  }
}

function normalizeDigits(code: string): string {
  return (code ?? "").replace(/[^0-9]/g, "");
}

type ChColumnMode = "BAZG" | "SIMPLE";

type ChColumns =
  | {
      mode: "SIMPLE";
      codeCol: string;
      descCol: string | null;
      dutyCol: string;
      unitCol: string | null;
    }
  | {
      mode: "BAZG";
      codeCol: string;
      dutyValueCol: string;
      currencyUnitCol: string | null;
      factorTextCol: string | null;
      rateTypeCol: string | null;
      groupIdCol: string | null;
      groupTextECol: string | null;
      groupTextDCol: string | null;
    };

function findCol(keys: string[], patterns: RegExp[]): string | null {
  for (const re of patterns) {
    const hit = keys.find((k) => re.test(k));
    if (hit) return hit;
  }
  return null;
}

function detectColumns(rows: Record<string, any>[]): ChColumns {
  const keys = rows.length ? Object.keys(rows[0]) : [];
  const keysLower = keys.map((k) => k.toLowerCase());

  // Explicit overrides (supports the simple legacy format)
  const envCode = process.env.CH_COL_CODE;
  const envDuty = process.env.CH_COL_DUTY;
  if (envCode && envDuty) {
    return {
      mode: "SIMPLE",
      codeCol: envCode,
      descCol: process.env.CH_COL_DESCRIPTION ?? null,
      dutyCol: envDuty,
      unitCol: process.env.CH_COL_UNIT ?? null,
    };
  }

  const looksLikeBazg = keysLower.some((k) => k.includes("ans berechnet")) && keysLower.some((k) => k.includes("ans ansatzart"));
  if (looksLikeBazg) {
    const codeCol = findCol(keys, [/^tn8\b/i, /tn8\s*nr/i, /tn8/i])
      ?? findCol(keys, [/tariff.*number/i, /commodity/i])
      ?? keys[0]
      ?? null;
    if (!codeCol) throw new Error("CH BAZG mode: could not find code column (TN8 Nr)");

    const dutyValueCol = findCol(keys, [/ans\s*berechnet/i, /ans\s*ans\s*berechnet/i]);
    if (!dutyValueCol) throw new Error("CH BAZG mode: could not find duty value column (ANS berechnet)");

    return {
      mode: "BAZG",
      codeCol,
      dutyValueCol,
      currencyUnitCol: findCol(keys, [/ans\s*einheit/i]),
      factorTextCol: findCol(keys, [/bgl\s*txt\s*e\s*faktor/i, /bgl\s*txt\s*d\s*faktor/i]),
      rateTypeCol: findCol(keys, [/ans\s*ansatzart/i]),
      groupIdCol: findCol(keys, [/ldg\s*nr/i]),
      groupTextECol: findCol(keys, [/ldg\s*ltxt\s*e/i]),
      groupTextDCol: findCol(keys, [/ldg\s*ltxt\s*d/i]),
    };
  }

  // SIMPLE legacy auto-detection
  let codeCol: string | null = null;
  for (const k of keys) {
    let hits = 0;
    for (let i = 0; i < Math.min(rows.length, 50); i++) {
      const v = rows[i]?.[k];
      const d = normalizeDigits(String(v ?? ""));
      if (d.length >= 6 && d.length <= 12) hits++;
    }
    if (hits >= 10) {
      codeCol = k;
      break;
    }
  }

  let dutyCol: string | null = null;
  for (const k of keys) {
    const lk = k.toLowerCase();
    if (lk.includes("ansatz") || lk.includes("duty") || lk.includes("rate") || lk.includes("zoll")) {
      dutyCol = k;
      break;
    }
  }
  if (!dutyCol) {
    for (const k of keys) {
      let hits = 0;
      for (let i = 0; i < Math.min(rows.length, 50); i++) {
        const v = rows[i]?.[k];
        if (v == null) continue;
        const n = Number(String(v).replace(",", "."));
        if (Number.isFinite(n)) hits++;
      }
      if (hits >= 10) {
        dutyCol = k;
        break;
      }
    }
  }

  let unitCol: string | null = null;
  for (const k of keys) {
    const lk = k.toLowerCase();
    if (lk.includes("unit") || lk.includes("einheit") || lk.includes("pro")) {
      unitCol = k;
      break;
    }
  }

  let descCol: string | null = null;
  for (const k of keys) {
    const lk = k.toLowerCase();
    if (lk.includes("description") || lk.includes("bezeichnung") || lk.includes("text")) {
      descCol = k;
      break;
    }
  }

  if (!codeCol || !dutyCol) {
    throw new Error("CH column detection failed. Provide CH_COL_CODE + CH_COL_DUTY (and optionally CH_COL_UNIT/CH_COL_DESCRIPTION). ");
  }

  return { mode: "SIMPLE", codeCol, descCol, dutyCol, unitCol };
}

const EU_ISO2 = [
  "AT","BE","BG","HR","CY","CZ","DK","EE","FI","FR","DE","GR","HU","IE","IT","LV","LT","LU","MT","NL","PL","PT","RO","SK","SI","ES","SE",
];
const EFTA_ISO2 = ["CH","IS","LI","NO"];
const GCC_ISO2 = ["BH","KW","OM","QA","SA","AE"];
const SACU_ISO2 = ["BW","SZ","LS","NA","ZA"]; // SZ = Eswatini
const CENTRAL_AMERICA_ISO2 = ["CR","GT","HN","NI","PA","SV"];

const CH_LDG_TO_ORIGINS: Record<string, string[]> = {
  // 100000 = normal rate (MFN) handled separately
  "100001": EU_ISO2,
  "100002": EFTA_ISO2,
  "100005": SACU_ISO2,
  "100007": ["AD"],
  "100009": GCC_ISO2,
  "100010": CENTRAL_AMERICA_ISO2,
  "100110": ["TR"],
  "100111": ["MA"],
  "100112": ["PS"],
  "100113": ["MK"],
  "100114": ["MX"],
  "100115": ["JO"],
  "100117": ["CL"],
  "100118": ["TN"],
  "100119": ["LB"],
  "100120": ["IL"],
  "100122": ["EG"],
  "100123": ["CA"],
  "100124": ["JP"],
  "100125": ["CO"],
  "100126": ["RS"],
  "100127": ["AL"],
  "100128": ["UA"],
  "100129": ["PE"],
  "100131": ["ME"],
  "100132": ["HK"],
  "100135": ["BA"],
  "100136": ["CN"],
  "100138": ["PH"],
  "100139": ["GE"],
  "100141": ["EC"],
  "100142": ["GB"],
  "100143": ["ID"],
  "100144": ["MD"],
  "100145": ["IN"],
  "100147": ["US"],
  "100180": ["FO"],
  "100322": ["SG"],
  "100323": ["KR"],
};

function expandChOrigins(ldgNr: string | null, ldgTextE: string | null, ldgTextD: string | null): string[] | null {
  const key = String(ldgNr ?? "").trim();
  if (key && CH_LDG_TO_ORIGINS[key]) return CH_LDG_TO_ORIGINS[key];

  // Fallback for single-country groups (best-effort by name)
  const name = (ldgTextE ?? ldgTextD ?? "").trim().toLowerCase();
  const byName: Record<string, string> = {
    "andorra": "AD",
    "united kingdom": "GB",
    "united states": "US",
    "hong kong": "HK",
    "china (excluding hong kong)": "CN",
    "turkiye": "TR",
    "türkiye": "TR",
    "morocco": "MA",
    "israel": "IL",
    "japan": "JP",
    "canada": "CA",
  };
  if (byName[name]) return [byName[name]];
  return null;
}

function normalizeFactorText(raw: string | null | undefined): string | null {
  const s = String(raw ?? "").replace(/\u00A0/g, " ").trim();
  if (!s) return null;
  let t = s.toLowerCase();
  t = t.replace(/^per\s+/i, "").replace(/^par\s+/i, "").replace(/^je\s+/i, "").replace(/^pro\s+/i, "");
  t = t.replace(/\b(gross|brutto)\b/g, "");
  t = t.replace(/\s+/g, " ").trim();
  return t || null;
}

function buildBazgDutyText(valueRaw: any, unitRaw: any, factorRaw: any, currency: string): string {
  const valueStr = String(valueRaw ?? "").trim();
  const unitStr = String(unitRaw ?? "").trim();
  const nValue = valueStr.replace(",", ".");

  if (!nValue) return "";

  if (unitStr.includes("%")) {
    return `${nValue}%`;
  }

  const factor = normalizeFactorText(factorRaw);
  if (factor) {
    return `${currency} ${nValue} / ${factor}`;
  }

  // If we cannot determine the denominator unit, parsing will likely fail.
  return `${currency} ${nValue}`;
}

export class ChConnector implements Connector {
  public readonly sourceName = "CH_TARES_XLSX";

  async run(ctx: RunContext): Promise<ConnectorResult> {
    const urlsRaw = process.env.CH_DUTY_RATES_URLS;
    if (!urlsRaw) throw new Error("CH_DUTY_RATES_URLS is required");

    const urls = urlsRaw.split(",").map((s) => s.trim()).filter(Boolean);
    const currency = (process.env.CH_CURRENCY ?? "CHF").toUpperCase();
    const vatRatePct = String(process.env.CH_VAT_RATE_PCT ?? "8.1");
    const sheetNameOverride = process.env.CH_SHEET_NAME || null;
    const defaultMassField = (process.env.CH_MASS_FIELD_DEFAULT ?? "gross_mass_kg") as any;

    const tariffLines: any[] = [];
    const expressions: any[] = [];
    const measures: any[] = [];

    const tariffLineIdByCode = new Map<string, string>();
    const descByCode = new Map<string, string | null>();
    const hasMfnForCode = new Set<string>();

    for (const url of urls) {
      const buf = await downloadBuffer(url);
      const wb = XLSX.read(buf, { type: "buffer" });

      const sheetName = sheetNameOverride ?? wb.SheetNames[0];
      if (!sheetName) throw new Error(`CH XLSX had no sheets: ${url}`);
      const sheet = wb.Sheets[sheetName]!;
      const rows = XLSX.utils.sheet_to_json<Record<string, any>>(sheet, { defval: null });

      const cols = detectColumns(rows);

      for (const r of rows) {
        const codeDigits = normalizeDigits(String(r[cols.codeCol] ?? ""));
        if (!codeDigits || codeDigits.length < 6) continue;

        let tariffLineId = tariffLineIdByCode.get(codeDigits);
        if (!tariffLineId) {
          tariffLineId = uuidv4();
          tariffLineIdByCode.set(codeDigits, tariffLineId);

          const desc = (cols.mode === "SIMPLE" && cols.descCol) ? (String(r[cols.descCol] ?? "").trim() || null) : null;
          descByCode.set(codeDigits, desc);

          tariffLines.push({
            tariffLineId,
            jurisdictionId: "CH",
            code: codeDigits,
            codeLen: codeDigits.length,
            description: desc,
            validFrom: ctx.asOfDate,
            validTo: OPEN_END,
            sourceRef: url,
          });
        }

        // Build rate text
        let dutyText = "";
        let originScope: "MFN" | "PREFERENTIAL" = "MFN";
        let originCodes: string[] = ["ALL"];

        if (cols.mode === "SIMPLE") {
          const dutyVal = r[cols.dutyCol];
          const unitVal = cols.unitCol ? r[cols.unitCol] : null;
          dutyText =
            unitVal != null && unitVal !== ""
              ? `${currency} ${String(dutyVal).replace(",", ".")} / ${String(unitVal)}`
              : `${currency} ${String(dutyVal).replace(",", ".")}`;
        } else {
          const rateType = cols.rateTypeCol ? String(r[cols.rateTypeCol] ?? "").trim().toUpperCase() : "";
          const ldgNr = cols.groupIdCol ? String(r[cols.groupIdCol] ?? "").trim() : "";
          const ldgTextE = cols.groupTextECol ? String(r[cols.groupTextECol] ?? "").trim() : "";
          const ldgTextD = cols.groupTextDCol ? String(r[cols.groupTextDCol] ?? "").trim() : "";

          dutyText = buildBazgDutyText(r[cols.dutyValueCol], cols.currencyUnitCol ? r[cols.currencyUnitCol] : null, cols.factorTextCol ? r[cols.factorTextCol] : null, currency);

          if (rateType === "PR") {
            const expanded = expandChOrigins(ldgNr || null, ldgTextE || null, ldgTextD || null);
            if (!expanded || expanded.length === 0) continue;
            originScope = "PREFERENTIAL";
            originCodes = expanded;
          } else {
            // NT or unknown -> treat as MFN (but only store one MFN per code)
            originScope = "MFN";
            originCodes = ["ALL"];
            if (hasMfnForCode.has(codeDigits)) continue;
            hasMfnForCode.add(codeDigits);
          }
        }

        const parsed = parseRateToAst(dutyText, {
          defaultCurrency: currency,
          defaultMassField,
        });

        const expressionId = uuidv4();
        if (parsed.ok) {
          expressions.push({
            expressionId,
            exprType: parsed.exprType,
            astJson: parsed.ast,
            currency: parsed.exprType === "SPECIFIC" ? currency : null,
            unitCode: null,
            sourceRef: parsed.normalized,
          });
        } else {
          expressions.push({
            expressionId,
            exprType: "CUSTOM",
            astJson: { op: "manual_required", raw: dutyText, reason: parsed.reason, message: parsed.message },
            currency: null,
            unitCode: null,
            sourceRef: url,
          });
        }

        for (const oc of originCodes) {
          measures.push({
            measureId: uuidv4(),
            tariffLineId,
            expressionId,
            measureType: "CUSTOMS_DUTY",
            originScope,
            originCode: oc,
            validFrom: ctx.asOfDate,
            validTo: OPEN_END,
            sourceRef: url,
          });
        }
      }
    }

    const vatRules = [{
      vatRuleId: uuidv4(),
      jurisdictionId: "CH",
      rateType: "STANDARD" as const,
      ratePct: vatRatePct,
      validFrom: ctx.asOfDate,
      validTo: OPEN_END,
      sourceRef: "CH VAT standard (MVP)",
    }];

    const vatBaseFormulas = [{
      vatBaseFormulaId: uuidv4(),
      jurisdictionId: "CH",
      astJson: {
        op: "add",
        terms: [
          { op: "field", name: "customs_value" },
          { op: "field", name: "customs_duty_total" },
          { op: "field", name: "fees_total" },
          { op: "field", name: "freight_to_border" },
          { op: "field", name: "insurance_to_border" },
        ],
      },
      validFrom: ctx.asOfDate,
      validTo: OPEN_END,
      sourceRef: "CH VAT base (MVP)",
    }];

    return {
      canonical: {
        tariffLines,
        expressions,
        measures,
        vatRules,
        vatBaseFormulas,
        thresholdRules: [],
      },
      manifest: {
        runId: ctx.runId,
        jurisdictionId: ctx.jurisdictionId,
        asOfDate: ctx.asOfDate,
        sourceName: this.sourceName,
        urls,
        insertedLines: tariffLines.length,
      },
    };
  }
}
