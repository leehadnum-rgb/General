export type RunContext = {
  runId: string;
  jurisdictionId: string;
  asOfDate: string;    // YYYY-MM-DD
  startedAt: string;   // ISO timestamp
};

export type CanonicalBundle = {
  tariffLines: Array<{
    tariffLineId: string;
    jurisdictionId: string;
    code: string;
    codeLen: number;
    description?: string | null;
    validFrom: string; // date
    validTo: string;   // date (exclusive end for daterange)
    sourceRef?: string | null;
  }>;

  expressions: Array<{
    expressionId: string;
    exprType: string;
    astJson: any;
    currency?: string | null;
    unitCode?: string | null;
    sourceRef?: string | null;
  }>;

  measures: Array<{
    measureId: string;
    tariffLineId: string;
    expressionId: string;
    measureType: "CUSTOMS_DUTY" | "EXCISE" | "FEE";
    originScope: "MFN" | "PREFERENTIAL" | "ALL";
    originCode: string;
    validFrom: string;
    validTo: string;
    sourceRef?: string | null;
  }>;

  vatRules: Array<{
    vatRuleId: string;
    jurisdictionId: string;
    rateType: "STANDARD";
    ratePct: string;
    validFrom: string;
    validTo: string;
    sourceRef?: string | null;
  }>;

  vatBaseFormulas: Array<{
    vatBaseFormulaId: string;
    jurisdictionId: string;
    astJson: any;
    validFrom: string;
    validTo: string;
    sourceRef?: string | null;
  }>;

  thresholdRules: any[];
};

export type ConnectorResult = {
  canonical: CanonicalBundle;
  manifest: Record<string, any>;
};

export interface Connector {
  readonly sourceName: string;
  run(ctx: RunContext): Promise<ConnectorResult>;
}
