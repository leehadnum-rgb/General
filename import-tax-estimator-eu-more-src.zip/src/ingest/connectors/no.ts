import { v4 as uuidv4 } from "uuid";

import type { Connector, ConnectorResult, RunContext } from "./base";
import { parseRateToAst } from "../lib/parseRateToAst";

const DEFAULT_BOUND_TARIFF_URL =
  "https://data.toll.no/dataset/4db0022e-cf52-4c88-94f0-4d8593d16682/resource/64b0402c-6606-4d19-b04f-76dadb9f2581/download/boundtariffconcessions.json";

const DEFAULT_TARIFF_STRUCTURE_URL =
  "https://data.toll.no/dataset/4e6ec703-ca3c-4aad-b7f2-d9e45da21e0a/resource/b8595e94-71d8-41fc-9c83-9ce5980685ad/download/customstariffstructure.json";

const DEFAULT_RTA_URL =
  "https://data.toll.no/dataset/35879701-da1e-40ed-90a1-30ef2f0c395c/resource/fb5fed00-30b4-47c6-b8eb-46ebbb283541/download/ratetradeagreements.json";

const OPEN_END = process.env.OPEN_END_DATE ?? "9999-12-31";

async function fetchJson(url: string, timeoutMs: number): Promise<any> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { signal: ctrl.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status} fetching ${url}`);
    return await res.json();
  } finally {
    clearTimeout(t);
  }
}

function normalizeCode(code: any): string {
  return String(code ?? "").replace(/[^0-9]/g, "");
}

function buildNoSpecificDutyText(value: any, type: any): string {
  const v = Number(value);
  if (!Number.isFinite(v)) return "";

  const t = String(type ?? "").trim();
  if (!t) return "";
  if (t === "%") return `${v}%`;

  // Examples observed in dataset: "pr.kg", "pr. 100 kg"
  // We convert these into a format parseRateToAst() understands: "X NOK / 100 kg".
  const m = t.match(/pr\.?\s*(\d+(?:\.\d+)?)?\s*([A-Za-z]+)/i);
  if (!m) return "";
  const mult = m[1] ? Number(m[1]) : 1;
  const unitRaw = (m[2] ?? "").toLowerCase();

  const unit =
    unitRaw === "kg" ? "kg" :
    unitRaw === "g" ? "g" :
    unitRaw === "t" || unitRaw === "tonne" || unitRaw === "tonnes" ? "tonne" :
    unitRaw === "l" || unitRaw === "lt" || unitRaw === "liter" || unitRaw === "litre" ? "litre" :
    unitRaw === "stk" || unitRaw === "st" || unitRaw === "pcs" || unitRaw === "piece" || unitRaw === "item" ? "item" :
    null;

  if (!unit) return "";

  const multPart = mult === 1 ? "" : `${mult} `;
  return `${v} NOK / ${multPart}${unit}`;
}

function extractNoDescriptionMap(struct: any): Map<string, string> {
  const map = new Map<string, string>();

  function visitNode(node: any, parents: string[]) {
    if (!node || typeof node !== "object") return;

    const desc = String(node.description ?? node.item ?? "").trim();
    const nextParents = desc ? [...parents, desc] : parents;

    // commodities array
    if (Array.isArray((node as any).commodities)) {
      for (const c of (node as any).commodities) {
        const code = normalizeCode(c?.id ?? c?.goodsNomenclatureItemId ?? c?.goods_nomenclature_item_id);
        if (!code) continue;
        const item = String(c?.item ?? c?.description ?? "").trim();
        const full = item || nextParents[nextParents.length - 1] || "";
        if (full) map.set(code, full);
      }
    }

    // recurse common child collections
    for (const key of ["sections", "chapters", "divisions", "headings", "subheadings", "children"]) {
      const arr = (node as any)[key];
      if (Array.isArray(arr)) {
        for (const child of arr) visitNode(child, nextParents);
      }
    }
  }

  visitNode(struct, []);
  return map;
}

function extractNoBoundRecords(bound: any): any[] {
  if (Array.isArray(bound)) return bound;
  if (Array.isArray(bound?.data)) return bound.data;
  if (Array.isArray(bound?.items)) return bound.items;
  if (Array.isArray(bound?.boundTariffConcessions)) return bound.boundTariffConcessions;
  if (Array.isArray(bound?.boundtariffconcessions)) return bound.boundtariffconcessions;
  return [];
}

function extractNoRtaRecords(rta: any): any[] {
  if (Array.isArray(rta)) return rta;
  if (Array.isArray(rta?.data)) return rta.data;
  if (Array.isArray(rta?.items)) return rta.items;
  if (Array.isArray(rta?.rateTradeAgreements)) return rta.rateTradeAgreements;
  if (Array.isArray(rta?.commodityRtas)) return rta.commodityRtas;
  if (Array.isArray(rta?.commodityRta)) return rta.commodityRta;
  return [];
}

function buildNoDutyText(dutyObj: any): string {
  if (!dutyObj || dutyObj?.classifier === "FREE" || dutyObj?.value == null) {
    return "0%";
  }
  const t = String(dutyObj?.type ?? "");
  if (t === "%") {
    return `${Number(dutyObj.value)}%`;
  }
  return buildNoSpecificDutyText(dutyObj.value, dutyObj.type);
}

const EU_ISO2 = [
  "AT","BE","BG","HR","CY","CZ","DK","EE","FI","FR","DE","GR","HU","IE","IT","LV","LT","LU","MT","NL","PL","PT","RO","SK","SI","ES","SE",
];
const EFTA_ISO2 = ["CH","IS","LI","NO"];
const EEA_ISO2 = [...EU_ISO2, "IS", "LI", "NO"]; // EEA excludes CH

function expandNoLandCode(codeRaw: any): string[] {
  const c = String(codeRaw ?? "").trim().toUpperCase();
  if (!c) return [];
  if (/^[A-Z]{2}$/.test(c)) return [c];

  // Best-effort group expansions (dataset may use group codes)
  if (c === "EU") return EU_ISO2;
  if (c === "EFTA") return EFTA_ISO2;
  if (c === "EEA" || c === "EØS" || c === "EOS") return EEA_ISO2;

  return [];
}

export class NoConnector implements Connector {
  readonly sourceName = "NO Tolletaten open data (bound tariff concessions + tariff structure)";

  async run(ctx: RunContext): Promise<ConnectorResult> {
    const timeoutMs = Number(process.env.HTTP_TIMEOUT_MS ?? "30000");

    const boundUrl = process.env.NO_BOUND_TARIFF_URL ?? DEFAULT_BOUND_TARIFF_URL;
    const structureUrl = process.env.NO_TARIFF_STRUCTURE_URL ?? DEFAULT_TARIFF_STRUCTURE_URL;
    const rtaUrl = process.env.NO_RTA_URL ?? DEFAULT_RTA_URL;
    const vatRatePct = String(process.env.NO_VAT_RATE_PCT ?? "25");

    const [boundJson, structJson, rtaJson] = await Promise.all([
      fetchJson(boundUrl, timeoutMs),
      fetchJson(structureUrl, timeoutMs),
      rtaUrl.toUpperCase() === "NONE" ? Promise.resolve(null) : fetchJson(rtaUrl, timeoutMs).catch((e) => {
        console.warn(`[NO] Could not fetch ratetradeagreements from ${rtaUrl}: ${String((e as any)?.message ?? e)}`);
        return null;
      }),
    ]);

    const descMap = extractNoDescriptionMap(structJson);
    const records = extractNoBoundRecords(boundJson);

    const rtaByCode = new Map<string, any[]>();
    if (rtaJson) {
      for (const rr of extractNoRtaRecords(rtaJson)) {
        const code = normalizeCode(rr?.id ?? rr?.code ?? rr?.commodityCode);
        if (!code) continue;
        const list = Array.isArray(rr?.rateTradeAgreements) ? rr.rateTradeAgreements : Array.isArray(rr?.agreements) ? rr.agreements : [];
        if (list.length) rtaByCode.set(code, list);
      }
    }

    if (!records.length) {
      throw new Error(`NO: No bound tariff records found (unexpected JSON shape) from ${boundUrl}`);
    }

    const tariffLines: any[] = [];
    const expressions: any[] = [];
    const measures: any[] = [];

    for (const r of records) {
      const code = normalizeCode(r?.id ?? r?.code);
      if (!code) continue;

      const tariffLineId = uuidv4();
      const description = descMap.get(code) ?? null;

      tariffLines.push({
        tariffLineId,
        jurisdictionId: "NO",
        code,
        codeLen: code.length,
        description,
        validFrom: ctx.asOfDate,
        validTo: OPEN_END,
        sourceRef: structureUrl,
      });

      const dutyObj = r?.mfn?.customDuty ?? r?.mfn?.custom_duty ?? r?.customDuty ?? null;

      const rawRateText = buildNoDutyText(dutyObj);

      const expressionId = uuidv4();

      if (!rawRateText) {
        expressions.push({
          expressionId,
          exprType: "CUSTOM",
          astJson: { op: "manual_required", raw: dutyObj, reason: "UNSUPPORTED_FORMAT", message: "Could not normalize NO duty type" },
          currency: null,
          unitCode: null,
          sourceRef: boundUrl,
        });

        measures.push({
          measureId: uuidv4(),
          tariffLineId,
          expressionId,
          measureType: "CUSTOMS_DUTY",
          originScope: "MFN",
          originCode: "ALL",
          validFrom: ctx.asOfDate,
          validTo: OPEN_END,
          sourceRef: boundUrl,
        });
        continue;
      }

      const parsed = parseRateToAst(rawRateText, {
        defaultCurrency: "NOK",
        defaultMassField: "net_mass_kg",
        defaultCountField: "quantity",
        defaultVolumeField: "volume_litre",
      });

      if (!parsed.ok) {
        expressions.push({
          expressionId,
          exprType: "CUSTOM",
          astJson: { op: "manual_required", raw: rawRateText, reason: parsed.reason, message: parsed.message },
          currency: null,
          unitCode: null,
          sourceRef: boundUrl,
        });

        measures.push({
          measureId: uuidv4(),
          tariffLineId,
          expressionId,
          measureType: "CUSTOMS_DUTY",
          originScope: "MFN",
          originCode: "ALL",
          validFrom: ctx.asOfDate,
          validTo: OPEN_END,
          sourceRef: boundUrl,
        });
        continue;
      }

      expressions.push({
        expressionId,
        exprType: parsed.exprType,
        astJson: parsed.ast,
        currency: parsed.exprType === "SPECIFIC" ? "NOK" : null,
        unitCode: null,
        sourceRef: boundUrl,
      });

      measures.push({
        measureId: uuidv4(),
        tariffLineId,
        expressionId,
        measureType: "CUSTOMS_DUTY",
        originScope: "MFN",
        originCode: "ALL",
        validFrom: ctx.asOfDate,
        validTo: OPEN_END,
        sourceRef: boundUrl,
      });

      // Preferential (trade agreement) duties, keyed by origin (best-effort assumes eligibility).
      const rtas = rtaByCode.get(code) ?? [];
      for (const a of rtas) {
        const prefDutyObj = a?.customDuty ?? a?.custom_duty ?? a?.rate ?? null;
        const prefRateText = buildNoDutyText(prefDutyObj);
        if (!prefRateText) continue;

        const parsedPref = parseRateToAst(prefRateText, {
          defaultCurrency: "NOK",
          defaultMassField: "net_mass_kg",
          defaultCountField: "quantity",
          defaultVolumeField: "volume_litre",
        });

        const prefExpressionId = uuidv4();
        if (parsedPref.ok) {
          expressions.push({
            expressionId: prefExpressionId,
            exprType: parsedPref.exprType,
            astJson: parsedPref.ast,
            currency: parsedPref.exprType === "SPECIFIC" ? "NOK" : null,
            unitCode: null,
            sourceRef: `NO RTA: ${parsedPref.normalized}`,
          });
        } else {
          expressions.push({
            expressionId: prefExpressionId,
            exprType: "CUSTOM",
            astJson: { op: "manual_required", raw: prefRateText, reason: parsedPref.reason, message: parsedPref.message },
            currency: null,
            unitCode: null,
            sourceRef: `NO RTA: ${prefRateText}`,
          });
        }

        const landCodesRaw = a?.landCodes ?? a?.landCode ?? a?.countries ?? [];
        const landCodes: any[] = Array.isArray(landCodesRaw)
          ? landCodesRaw
          : typeof landCodesRaw === "string"
            ? landCodesRaw.split(/[,\s]+/g).filter(Boolean)
            : [];

        for (const lc of landCodes) {
          for (const oc of expandNoLandCode(lc)) {
            measures.push({
              measureId: uuidv4(),
              tariffLineId,
              expressionId: prefExpressionId,
              measureType: "CUSTOMS_DUTY",
              originScope: "PREFERENTIAL",
              originCode: oc,
              validFrom: ctx.asOfDate,
              validTo: OPEN_END,
              sourceRef: `rta:${String(lc)}`,
            });
          }
        }
      }
    }

    const vatRules = [
      {
        vatRuleId: uuidv4(),
        jurisdictionId: "NO",
        rateType: "STANDARD" as const,
        ratePct: vatRatePct,
        validFrom: ctx.asOfDate,
        validTo: OPEN_END,
        sourceRef: "NO VAT standard (MVP)",
      },
    ];

    const vatBaseFormulas = [
      {
        vatBaseFormulaId: uuidv4(),
        jurisdictionId: "NO",
        astJson: {
          op: "add",
          terms: [
            { op: "field", name: "customs_value" },
            { op: "field", name: "customs_duty_total" },
            { op: "field", name: "fees_total" },
            { op: "field", name: "freight_to_border" },
            { op: "field", name: "insurance_to_border" },
          ],
        },
        validFrom: ctx.asOfDate,
        validTo: OPEN_END,
        sourceRef: "NO VAT base (MVP)",
      },
    ];

    return {
      canonical: {
        tariffLines,
        expressions,
        measures,
        vatRules,
        vatBaseFormulas,
        thresholdRules: [],
      },
      manifest: {
        runId: ctx.runId,
        jurisdictionId: ctx.jurisdictionId,
        asOfDate: ctx.asOfDate,
        sourceName: this.sourceName,
        urls: rtaUrl.toUpperCase() === "NONE" ? [boundUrl, structureUrl] : [boundUrl, structureUrl, rtaUrl],
        insertedLines: tariffLines.length,
      },
    };
  }
}
