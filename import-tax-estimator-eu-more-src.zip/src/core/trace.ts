import { Value } from "./ast";

export type ExprTrace =
  | { op: "field"; name: string; found: boolean }
  | { op: "const_money"; amount: string; currency: string }
  | { op: "const_number"; value: string }
  | { op: "add" | "min" | "max"; children: ExprTrace[] }
  | { op: "mul"; left: ExprTrace; right: ExprTrace }
  | {
      op: "ad_valorem";
      rate_pct: number;
      base: ExprTrace;
      computed?: { base_amount?: { amount: string; currency: string }; result?: { amount: string; currency: string } };
    }
  | {
      op: "specific";
      amount: string;
      currency: string;
      qty_field: string;
      qty_found: boolean;
      computed?: { qty?: string; result?: { amount: string; currency: string } };
    };

export type EvalMeta = {
  usedFields: string[];
  missingFields: string[];
};

export type EvalResult =
  | { ok: true; value: Value; trace: ExprTrace; meta: EvalMeta }
  | { ok: false; error: { code: "MISSING_INPUT" | "TYPE_MISMATCH"; message: string }; trace: ExprTrace; meta: EvalMeta };
