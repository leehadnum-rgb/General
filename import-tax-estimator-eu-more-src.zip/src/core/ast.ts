export type Currency = string;

export type Money = {
  amount: string;   // decimal string
  currency: Currency;
};

export type Value =
  | { kind: "money"; money: Money }
  | { kind: "number"; value: string }
  | { kind: "boolean"; value: boolean };

export type Expr =
  | { op: "field"; name: string }
  | { op: "const_money"; amount: string; currency: Currency }
  | { op: "const_number"; value: string }
  | { op: "add"; terms: Expr[] }
  | { op: "mul"; left: Expr; right: Expr }
  | { op: "min"; terms: Expr[] }
  | { op: "max"; terms: Expr[] }
  | { op: "ad_valorem"; rate_pct: number; base: string }
  | { op: "specific"; amount: string; currency: Currency; per: { qty_field: string; unit: string } };

export type BoolExpr =
  | { op: "and"; terms: BoolExpr[] }
  | { op: "or"; terms: BoolExpr[] }
  | { op: "not"; term: BoolExpr }
  | { op: "lt" | "lte" | "gt" | "gte" | "eq"; left: Expr; right: Expr };
