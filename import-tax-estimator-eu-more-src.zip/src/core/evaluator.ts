import Decimal from "decimal.js";
import { Expr, Money, Value } from "./ast";
import { EvalResult, ExprTrace } from "./trace";

export type EvalContext = {
  fields: Record<string, Value | undefined>;
  convert?: (m: Money, toCurrency: string) => Money;
};

function money(amount: Decimal, currency: string): Value {
  return { kind: "money", money: { amount: amount.toFixed(), currency } };
}

function num(v: Decimal): Value {
  return { kind: "number", value: v.toFixed() };
}

function asDecimalNumber(v: Value): Decimal | null {
  if (v.kind === "number") return new Decimal(v.value);
  return null;
}

function assertMoney(v: Value): { amount: Decimal; currency: string } | null {
  if (v.kind !== "money") return null;
  return { amount: new Decimal(v.money.amount), currency: v.money.currency };
}

export function evalExpr(expr: Expr, ctx: EvalContext): EvalResult {
  const usedFields: string[] = [];
  const missingFields: string[] = [];

  function go(e: Expr): { value?: Value; trace: ExprTrace } {
    switch (e.op) {
      case "field": {
        usedFields.push(e.name);
        const found = ctx.fields[e.name];
        if (!found) {
          missingFields.push(e.name);
          return { trace: { op: "field", name: e.name, found: false } };
        }
        return { value: found, trace: { op: "field", name: e.name, found: true } };
      }

      case "const_money":
        return { value: { kind: "money", money: { amount: e.amount, currency: e.currency } }, trace: e };

      case "const_number":
        return { value: { kind: "number", value: e.value }, trace: e };

      case "add": {
        const children = e.terms.map(go);
        const traces = children.map((c) => c.trace);
        const values = children.map((c) => c.value).filter(Boolean) as Value[];
        if (values.length !== e.terms.length) return { trace: { op: "add", children: traces } };

        const allMoney = values.every((v) => v.kind === "money");
        const allNum = values.every((v) => v.kind === "number");
        if (!allMoney && !allNum) return { trace: { op: "add", children: traces } };

        if (allMoney) {
          const m0 = assertMoney(values[0])!;
          let total = new Decimal(0);
          for (const v of values) {
            const m = assertMoney(v)!;
            if (m.currency !== m0.currency) {
              if (!ctx.convert) throw new Error(`Currency mismatch in add(): ${m.currency} vs ${m0.currency}`);
              const converted = ctx.convert({ amount: m.amount.toFixed(), currency: m.currency }, m0.currency);
              total = total.add(new Decimal(converted.amount));
            } else {
              total = total.add(m.amount);
            }
          }
          return { value: money(total, m0.currency), trace: { op: "add", children: traces } };
        }

        let total = new Decimal(0);
        for (const v of values) total = total.add(new Decimal((v as any).value));
        return { value: num(total), trace: { op: "add", children: traces } };
      }

      case "mul": {
        const left = go(e.left);
        const right = go(e.right);
        if (!left.value || !right.value) return { trace: { op: "mul", left: left.trace, right: right.trace } };

        const lNum = asDecimalNumber(left.value);
        const rNum = asDecimalNumber(right.value);

        if (left.value.kind === "money" && rNum) {
          const m = assertMoney(left.value)!;
          return { value: money(m.amount.mul(rNum), m.currency), trace: { op: "mul", left: left.trace, right: right.trace } };
        }
        if (right.value.kind === "money" && lNum) {
          const m = assertMoney(right.value)!;
          return { value: money(m.amount.mul(lNum), m.currency), trace: { op: "mul", left: left.trace, right: right.trace } };
        }
        if (lNum && rNum) return { value: num(lNum.mul(rNum)), trace: { op: "mul", left: left.trace, right: right.trace } };

        return { trace: { op: "mul", left: left.trace, right: right.trace } };
      }

      case "min":
      case "max": {
        const children = e.terms.map(go);
        const traces = children.map((c) => c.trace);
        const values = children.map((c) => c.value).filter(Boolean) as Value[];
        if (values.length !== e.terms.length) return { trace: { op: e.op, children: traces } };

        const allNum = values.every((v) => v.kind === "number");
        const allMoney = values.every((v) => v.kind === "money");
        if (!allNum && !allMoney) return { trace: { op: e.op, children: traces } };

        if (allNum) {
          const decs = values.map((v) => new Decimal((v as any).value));
          const chosen = e.op === "min" ? Decimal.min(...decs) : Decimal.max(...decs);
          return { value: num(chosen), trace: { op: e.op, children: traces } };
        }

        const m0 = assertMoney(values[0])!;
        const decs = values.map((v) => {
          const m = assertMoney(v)!;
          if (m.currency === m0.currency) return m.amount;
          if (!ctx.convert) throw new Error(`Currency mismatch in ${e.op}()`);
          const converted = ctx.convert({ amount: m.amount.toFixed(), currency: m.currency }, m0.currency);
          return new Decimal(converted.amount);
        });
        const chosen = e.op === "min" ? Decimal.min(...decs) : Decimal.max(...decs);
        return { value: money(chosen, m0.currency), trace: { op: e.op, children: traces } };
      }

      case "ad_valorem": {
        const base = go({ op: "field", name: e.base });
        if (!base.value) return { trace: { op: "ad_valorem", rate_pct: e.rate_pct, base: base.trace } };

        const m = assertMoney(base.value);
        if (!m) {
          return {
            trace: { op: "ad_valorem", rate_pct: e.rate_pct, base: base.trace, computed: {} },
          };
        }
        const result = m.amount.mul(new Decimal(e.rate_pct)).div(100);
        return {
          value: money(result, m.currency),
          trace: {
            op: "ad_valorem",
            rate_pct: e.rate_pct,
            base: base.trace,
            computed: {
              base_amount: { amount: m.amount.toFixed(), currency: m.currency },
              result: { amount: result.toFixed(), currency: m.currency },
            },
          },
        };
      }

      case "specific": {
        usedFields.push(e.per.qty_field);
        const qtyVal = ctx.fields[e.per.qty_field];
        if (!qtyVal || qtyVal.kind !== "number") {
          missingFields.push(e.per.qty_field);
          return { trace: { op: "specific", amount: e.amount, currency: e.currency, qty_field: e.per.qty_field, qty_found: false } };
        }

        const qty = new Decimal(qtyVal.value);
        const res = new Decimal(e.amount).mul(qty);
        return {
          value: { kind: "money", money: { amount: res.toFixed(), currency: e.currency } },
          trace: {
            op: "specific",
            amount: e.amount,
            currency: e.currency,
            qty_field: e.per.qty_field,
            qty_found: true,
            computed: { qty: qty.toFixed(), result: { amount: res.toFixed(), currency: e.currency } },
          },
        };
      }

      default: {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const _never: never = e;
        return { trace: { op: "field", name: "UNREACHABLE", found: false } };
      }
    }
  }

  const out = go(expr);

  const meta = {
    usedFields: [...new Set(usedFields)],
    missingFields: [...new Set(missingFields)],
  };

  if (!out.value) {
    return {
      ok: false,
      error: { code: "MISSING_INPUT", message: meta.missingFields.length ? `Missing inputs: ${meta.missingFields.join(", ")}` : "Missing inputs" },
      trace: out.trace,
      meta,
    };
  }

  return { ok: true, value: out.value, trace: out.trace, meta };
}
