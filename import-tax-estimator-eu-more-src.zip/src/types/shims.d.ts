declare module "tar-stream" {
  export function extract(): any;
}
