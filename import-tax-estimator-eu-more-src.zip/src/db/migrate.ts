import { Pool } from "pg";
import { readdir, readFile } from "node:fs/promises";
import { join } from "node:path";

async function ensureMigrationsTable(pool: Pool) {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      filename TEXT PRIMARY KEY,
      applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
    )
  `);
}

async function main() {
  const DATABASE_URL = process.env.DATABASE_URL;
  if (!DATABASE_URL) throw new Error("DATABASE_URL is required");

  const migrationsDir = join(process.cwd(), "migrations");
  const files = (await readdir(migrationsDir))
    .filter((f) => f.endsWith(".sql"))
    .sort();

  const pool = new Pool({ connectionString: DATABASE_URL });

  try {
    await ensureMigrationsTable(pool);

    for (const f of files) {
      const already = await pool.query(
        `SELECT 1 FROM schema_migrations WHERE filename=$1 LIMIT 1`,
        [f]
      );
      if (already.rowCount) continue;

      const sql = await readFile(join(migrationsDir, f), "utf-8");
      console.log(`[migrate] applying ${f}`);

      await pool.query("BEGIN");
      try {
        await pool.query(sql);
        await pool.query(
          `INSERT INTO schema_migrations (filename) VALUES ($1)`,
          [f]
        );
        await pool.query("COMMIT");
      } catch (e) {
        await pool.query("ROLLBACK");
        throw e;
      }
    }

    console.log("[migrate] done");
  } finally {
    await pool.end();
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
