-- Canonical schema for import-tax-estimator
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS btree_gist;

DO $$
BEGIN
  CREATE TYPE measure_type AS ENUM ('CUSTOMS_DUTY', 'EXCISE', 'FEE');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$
BEGIN
  CREATE TYPE origin_scope AS ENUM ('MFN', 'PREFERENTIAL', 'ALL');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$
BEGIN
  CREATE TYPE expr_type AS ENUM ('AD_VALOREM', 'SPECIFIC', 'COMPOUND', 'ALTERNATIVE', 'MIN_MAX', 'CUSTOM');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

CREATE TABLE IF NOT EXISTS jurisdiction (
  jurisdiction_id  TEXT PRIMARY KEY,
  name             TEXT NOT NULL,
  currency         CHAR(3) NOT NULL,
  vat_label        TEXT NOT NULL DEFAULT 'VAT',
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS data_version (
  data_version_id  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  jurisdiction_id  TEXT NOT NULL REFERENCES jurisdiction(jurisdiction_id),
  source_name      TEXT NOT NULL,
  source_manifest  JSONB NOT NULL,
  loaded_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  is_active        BOOLEAN NOT NULL DEFAULT FALSE,
  notes            TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS one_active_version_per_jurisdiction
ON data_version (jurisdiction_id)
WHERE is_active;

CREATE INDEX IF NOT EXISTS data_version_jurisdiction_loaded_idx
ON data_version (jurisdiction_id, loaded_at DESC);

-- Optional unit table
CREATE TABLE IF NOT EXISTS unit (
  unit_code   TEXT PRIMARY KEY,
  dimension   TEXT NOT NULL,
  description TEXT
);

CREATE TABLE IF NOT EXISTS tariff_line (
  tariff_line_id   UUID PRIMARY KEY,
  data_version_id  UUID NOT NULL REFERENCES data_version(data_version_id) ON DELETE CASCADE,
  jurisdiction_id  TEXT NOT NULL REFERENCES jurisdiction(jurisdiction_id),

  code             TEXT NOT NULL,
  code_len         INT  NOT NULL,
  description      TEXT,

  valid_from       DATE NOT NULL,
  valid_to         DATE NOT NULL,
  valid_range      DATERANGE NOT NULL,

  source_ref       TEXT,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),

  CHECK (code_len = char_length(code)),
  CHECK (valid_from < valid_to),
  CHECK (valid_range = daterange(valid_from, valid_to, '[)'))
);

ALTER TABLE tariff_line
  ADD CONSTRAINT tariff_line_no_overlap
  EXCLUDE USING gist (
    data_version_id WITH =,
    jurisdiction_id WITH =,
    code WITH =,
    valid_range WITH &&
  );

CREATE INDEX IF NOT EXISTS tariff_line_lookup_idx
ON tariff_line (data_version_id, jurisdiction_id, code);

CREATE TABLE IF NOT EXISTS expression (
  expression_id    UUID PRIMARY KEY,
  data_version_id  UUID NOT NULL REFERENCES data_version(data_version_id) ON DELETE CASCADE,
  expr_type        expr_type NOT NULL,
  ast_json         JSONB NOT NULL,
  currency         CHAR(3),
  unit_code        TEXT REFERENCES unit(unit_code),
  source_ref       TEXT,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (jsonb_typeof(ast_json) = 'object')
);

CREATE TABLE IF NOT EXISTS measure (
  measure_id       UUID PRIMARY KEY,
  data_version_id  UUID NOT NULL REFERENCES data_version(data_version_id) ON DELETE CASCADE,
  tariff_line_id   UUID NOT NULL,
  expression_id    UUID NOT NULL,

  measure_type     measure_type NOT NULL,
  origin_scope     origin_scope NOT NULL DEFAULT 'MFN',
  origin_code      TEXT NOT NULL DEFAULT 'ALL',

  conditions_json  JSONB,
  valid_from       DATE NOT NULL,
  valid_to         DATE NOT NULL,
  valid_range      DATERANGE NOT NULL,
  source_ref       TEXT,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),

  FOREIGN KEY (tariff_line_id, data_version_id)
    REFERENCES tariff_line (tariff_line_id, data_version_id) ON DELETE CASCADE,

  FOREIGN KEY (expression_id, data_version_id)
    REFERENCES expression (expression_id, data_version_id) ON DELETE RESTRICT,

  CHECK (valid_from < valid_to),
  CHECK (valid_range = daterange(valid_from, valid_to, '[)'))
);

ALTER TABLE measure
  ADD CONSTRAINT measure_no_overlap
  EXCLUDE USING gist (
    data_version_id WITH =,
    tariff_line_id WITH =,
    measure_type WITH =,
    origin_scope WITH =,
    origin_code WITH =,
    valid_range WITH &&
  );

CREATE INDEX IF NOT EXISTS measure_lookup_idx
ON measure (data_version_id, tariff_line_id, measure_type, origin_scope, origin_code);

CREATE TABLE IF NOT EXISTS vat_rule (
  vat_rule_id      UUID PRIMARY KEY,
  data_version_id  UUID NOT NULL REFERENCES data_version(data_version_id) ON DELETE CASCADE,
  jurisdiction_id  TEXT NOT NULL REFERENCES jurisdiction(jurisdiction_id),

  rate_type        TEXT NOT NULL DEFAULT 'STANDARD',
  rate_pct         NUMERIC(7,4) NOT NULL,

  valid_from       DATE NOT NULL,
  valid_to         DATE NOT NULL,
  valid_range      DATERANGE NOT NULL,

  source_ref       TEXT,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),

  CHECK (rate_pct >= 0),
  CHECK (valid_from < valid_to),
  CHECK (valid_range = daterange(valid_from, valid_to, '[)'))
);

ALTER TABLE vat_rule
  ADD CONSTRAINT vat_rule_no_overlap
  EXCLUDE USING gist (
    data_version_id WITH =,
    jurisdiction_id WITH =,
    rate_type WITH =,
    valid_range WITH &&
  );

CREATE INDEX IF NOT EXISTS vat_rule_lookup_idx
ON vat_rule (data_version_id, jurisdiction_id, rate_type);

CREATE TABLE IF NOT EXISTS vat_base_formula (
  vat_base_formula_id UUID PRIMARY KEY,
  data_version_id     UUID NOT NULL REFERENCES data_version(data_version_id) ON DELETE CASCADE,
  jurisdiction_id     TEXT NOT NULL REFERENCES jurisdiction(jurisdiction_id),

  ast_json            JSONB NOT NULL,

  valid_from          DATE NOT NULL,
  valid_to            DATE NOT NULL,
  valid_range         DATERANGE NOT NULL,

  source_ref          TEXT,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),

  CHECK (jsonb_typeof(ast_json) = 'object'),
  CHECK (valid_from < valid_to),
  CHECK (valid_range = daterange(valid_from, valid_to, '[)'))
);

ALTER TABLE vat_base_formula
  ADD CONSTRAINT vat_base_no_overlap
  EXCLUDE USING gist (
    data_version_id WITH =,
    jurisdiction_id WITH =,
    valid_range WITH &&
  );

CREATE INDEX IF NOT EXISTS vat_base_lookup_idx
ON vat_base_formula (data_version_id, jurisdiction_id);
