# JP + AU full duty ingestion (patch)

This patch adds two ingestion connectors:

- `src/ingest/connectors/jp.ts` (Japan Customs tariff schedule, HTML)
- `src/ingest/connectors/au.ts` (Australia Border Force schedule 3, HTML)

It also adds:

- `src/ingest/lib/html.ts` (tiny HTML fetch/parse helpers; no new deps)
- `src/ingest/lib/parseRateToAst.ts` update (better currency detection for AUD/JPY/etc)

## 1) Env vars to add (Render)

### API service (same as today)
No new required API-service env vars for JP/AU.

### Ingest cron job env vars
Add these env vars to the **ingest cron job** (the one that runs `npm run ingest`).

**Jurisdictions**

- `INGEST_JURISDICTIONS=US,NZ,CH,GB,NO,CA,EU,HK,SG,IS,JP,AU`  
  (keep whatever list you already have — just add `JP,AU`)

**Japan (JP)**

- `JP_TARIFF_EFFECTIVE=2026_01_01`  
- `JP_TARIFF_INDEX_URL=` *(optional; if set, overrides computed index URL)*
  - Example: `https://www.customs.go.jp/english/tariff/2026_01_01/index.htm`
- `JP_DUTY_PREF=WTO` *(or `GENERAL` if you want that column)*
- `JP_MAX_CHAPTERS=0` *(0 = all chapters; set to `3` during first test run)*
- `JP_CHAPTER_CONCURRENCY=3`
- `JP_CONSUMPTION_TAX_RATE_PCT=10`

**Australia (AU)**

- `AU_TARIFF_TOC_URL=https://www.abf.gov.au/importing-exporting-and-manufacturing/tariff-classification/current-tariff/schedule-3`
- `AU_MAX_CHAPTERS=0` *(0 = all chapters; set to `1` during first test run)*
- `AU_CHAPTER_CONCURRENCY=3`
- `AU_GST_RATE_PCT=10`

**Common (already in your app)**

- `HTTP_TIMEOUT_MS=30000`
- `OPEN_END_DATE=9999-12-31`

## 2) Code wiring changes to make in your repo

This patch **adds** the connector classes, but you still need to **wire them into**:

### A) `src/ingest/main.ts`

1. Add imports:

- `import { JpConnector } from "./connectors/jp";`
- `import { AuConnector } from "./connectors/au";`

2. Extend the `JurisdictionId` union to include `JP` and `AU`.

3. Update `upsertJurisdictions()` to include:

- `('JP', 'Japan', 'JPY', 'Consumption Tax')`
- `('AU', 'Australia', 'AUD', 'GST')`

4. Update `makeConnector()`:

- `if (j === "JP") return new JpConnector();`
- `if (j === "AU") return new AuConnector();`

### B) `src/api/routes/requirements.ts` and `src/api/routes/estimate.ts`

Add JP/AU to the jurisdiction enum.

Then, tweak code normalization so common user inputs work:

- AU: if user provides 6-digit HS, pad to 8 (`padEnd(8,'0')`)
- AU: if user provides 10+ digits, truncate to 8 (`slice(0,8)`)
- JP: if user provides 6-digit HS, pad to 9 (`padEnd(9,'0')`)
- JP: if user provides >9, truncate to 9

(Exact code change is small; same approach you already use for NO/CA.)

## 3) Anything.com form updates

In your Anything UI, add `JP` and `AU` as new destinations in the jurisdiction dropdown.

- `JP` label: `Japan`
- `AU` label: `Australia`

Also keep `originCountry` as a required step (even if MFN-only for now) so we can extend preferential logic later.

