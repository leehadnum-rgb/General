/**
 * Tiny HTML utilities for connectors.
 *
 * Intentionally avoids adding new npm deps.
 */

function timeoutMs() {
  return Number(process.env.HTTP_TIMEOUT_MS ?? "30000");
}

export async function fetchBytes(url: string): Promise<Uint8Array> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs());
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      headers: {
        // Some government sites are picky; keep it browser-ish.
        "user-agent": process.env.HTTP_USER_AGENT ?? "Mozilla/5.0 (compatible; ImportTaxEstimator/1.0; +https://render.com)",
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "accept-language": "en-GB,en;q=0.9",
      },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
    const ab = await res.arrayBuffer();
    return new Uint8Array(ab);
  } finally {
    clearTimeout(t);
  }
}

function tryDecode(bytes: Uint8Array, charset: string): string | null {
  try {
    // Node 18+ exposes TextDecoder globally.
    const dec = new TextDecoder(charset as any, { fatal: false });
    return dec.decode(bytes);
  } catch {
    return null;
  }
}

function sniffCharsetFromAscii(htmlAscii: string): string | null {
  const m = htmlAscii.match(/charset\s*=\s*([A-Za-z0-9_\-]+)/i);
  if (!m) return null;
  const cs = String(m[1] ?? "").trim().toLowerCase();
  if (!cs) return null;

  // Normalize a few common labels.
  if (cs === "shift_jis" || cs === "shift-jis" || cs === "sjis" || cs === "ms932" || cs === "windows-31j") return "shift_jis";
  if (cs === "utf8") return "utf-8";
  if (cs === "utf-8") return "utf-8";
  return cs;
}

export async function fetchHtml(url: string, opts?: { defaultCharset?: string }): Promise<string> {
  const bytes = await fetchBytes(url);

  // First attempt: UTF-8
  const utf8 = tryDecode(bytes, opts?.defaultCharset ?? "utf-8");
  if (utf8 && /<html|<body|<table|<div|<!doctype/i.test(utf8)) {
    // If the HTML itself declares Shift_JIS, re-decode.
    const ascii = tryDecode(bytes, "latin1") ?? utf8;
    const sniff = sniffCharsetFromAscii(ascii);
    if (sniff && sniff !== "utf-8") {
      const alt = tryDecode(bytes, sniff);
      if (alt) return alt;
    }
    return utf8;
  }

  // Second attempt: latin1 for "byte-preserving" parsing of ASCII digits.
  const latin1 = tryDecode(bytes, "latin1");
  if (!latin1) return utf8 ?? "";

  const sniff = sniffCharsetFromAscii(latin1);
  if (sniff) {
    const alt = tryDecode(bytes, sniff);
    if (alt) return alt;
  }

  return latin1;
}

const ENTITY_MAP: Record<string, string> = {
  amp: "&",
  lt: "<",
  gt: ">",
  quot: '"',
  apos: "'",
  nbsp: " ",
};

export function decodeHtmlEntities(s: string): string {
  return (s ?? "")
    .replace(/&(#\d+);/g, (_, d) => {
      const n = Number(String(d).replace("#", ""));
      if (!Number.isFinite(n)) return _;
      try { return String.fromCodePoint(n); } catch { return _; }
    })
    .replace(/&(#x[0-9a-fA-F]+);/g, (_, hx) => {
      const n = parseInt(String(hx).replace(/^#x/i, ""), 16);
      if (!Number.isFinite(n)) return _;
      try { return String.fromCodePoint(n); } catch { return _; }
    })
    .replace(/&([A-Za-z]+);/g, (m, name) => ENTITY_MAP[String(name).toLowerCase()] ?? m);
}

export function htmlToText(html: string): string {
  let h = String(html ?? "");

  // Remove scripts/styles.
  h = h.replace(/<script[\s\S]*?<\/script>/gi, " ");
  h = h.replace(/<style[\s\S]*?<\/style>/gi, " ");

  // Normalize common line breaks.
  h = h.replace(/<\s*br\s*\/?\s*>/gi, "\n");
  h = h.replace(/<\s*\/\s*p\s*>/gi, "\n");
  h = h.replace(/<\s*\/\s*div\s*>/gi, "\n");
  h = h.replace(/<\s*\/\s*li\s*>/gi, "\n");
  h = h.replace(/<\s*\/\s*tr\s*>/gi, "\n");
  h = h.replace(/<\s*\/\s*td\s*>/gi, "\t");
  h = h.replace(/<\s*\/\s*th\s*>/gi, "\t");

  // Strip tags.
  h = h.replace(/<[^>]+>/g, " ");

  // Decode entities and normalize whitespace.
  h = decodeHtmlEntities(h);
  h = h.replace(/\u00A0/g, " ");
  h = h.replace(/\r/g, "");
  h = h.replace(/[ \t]+/g, " ");
  h = h.replace(/\n\s+\n/g, "\n");

  return h;
}

export function extractLinks(html: string, baseUrl: string, filter: (href: string) => boolean): string[] {
  const out = new Set<string>();
  const re = /href\s*=\s*"([^"]+)"/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    const href = String(m[1] ?? "").trim();
    if (!href) continue;
    if (href.startsWith("#") || href.startsWith("javascript:")) continue;
    if (!filter(href)) continue;
    try {
      const u = new URL(href, baseUrl);
      out.add(u.toString());
    } catch {
      // ignore
    }
  }
  return [...out];
}

export function extractTableRows(html: string): string[][] {
  const rows: string[][] = [];

  const trRe = /<tr[^>]*>([\s\S]*?)<\/tr>/gi;
  let tr: RegExpExecArray | null;

  while ((tr = trRe.exec(html))) {
    const rowHtml = tr[1] ?? "";

    const cells: string[] = [];
    const tdRe = /<(t[dh])[^>]*>([\s\S]*?)<\/\1>/gi;
    let td: RegExpExecArray | null;
    while ((td = tdRe.exec(rowHtml))) {
      const cellHtml = td[2] ?? "";
      // Keep <br> as line breaks while stripping tags.
      const txt = htmlToText(cellHtml).replace(/\s+/g, " ").trim();
      cells.push(txt);
    }

    if (cells.length) rows.push(cells);
  }

  return rows;
}
