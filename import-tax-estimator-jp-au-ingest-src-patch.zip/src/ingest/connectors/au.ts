import { v4 as uuidv4 } from "uuid";
import { Connector, ConnectorResult, RunContext } from "./base";
import { parseRateToAst } from "../lib/parseRateToAst";
import { extractLinks, fetchHtml, htmlToText } from "../lib/html";

const OPEN_END = process.env.OPEN_END_DATE ?? "9999-12-31";

function normalizeDigits(code: string): string {
  return (code ?? "").replace(/[^0-9]/g, "");
}

function uniq<T>(xs: T[]): T[] {
  return [...new Set(xs)];
}

function pickLastRateToken(text: string): string | null {
  const t = String(text ?? "").replace(/\s+/g, " ").trim();
  if (!t) return null;

  // Prefer explicit "Free" / "Nil".
  const freeMatches = [...t.matchAll(/\b(free|nil)\b/gi)].map((m) => m[0]);
  if (freeMatches.length) return freeMatches[freeMatches.length - 1] ?? null;

  // Percent
  const pctMatches = [...t.matchAll(/(\d+(?:\.\d+)?)\s*%/g)].map((m) => `${m[1]}%`);
  if (pctMatches.length) return pctMatches[pctMatches.length - 1] ?? null;

  // Specific / mixed (best-effort). Capture from the last number before a unit.
  const specRe = /(\d+(?:\.\d+)?)\s*(?:¢|c|cent|cents|\$|A\$|AU\$|AUD)?\s*(?:per|\/)\s*(?:\d+(?:\.\d+)?)?\s*(kg|g|t|tonne|tonnes|l|litre|liter|ml|each|ea\.?|no\.?|pcs|piece|item)\b[\s\S]*$/i;
  const m = t.match(specRe);
  if (m) return m[0].trim();

  return null;
}

function cleanDescription(raw: string, dutyText: string | null): string | null {
  let s = String(raw ?? "");
  s = s.replace(/\s+/g, " ").trim();

  // Drop statistical code + unit if present.
  s = s.replace(/^\d{2}\s+[A-Za-z]{1,5}\s*-?\s*/, "");

  // Remove the duty text tail if found.
  if (dutyText) {
    const idx = s.toLowerCase().lastIndexOf(dutyText.toLowerCase());
    if (idx >= 0) s = s.slice(0, idx).trim();
  }

  // Remove obvious "View TCO" remnants.
  s = s.replace(/\bView\s*TCOs\b[\s\S]*$/i, "").trim();

  // Remove leading bullets/hyphens.
  s = s.replace(/^[\-\.]+\s*/, "");

  return s ? s : null;
}

export class AuConnector implements Connector {
  public readonly sourceName = "AU_ABF_TARIFF";

  async run(ctx: RunContext): Promise<ConnectorResult> {
    const tocUrl = process.env.AU_TARIFF_TOC_URL
      ?? "https://www.abf.gov.au/importing-exporting-and-manufacturing/tariff-classification/current-tariff/schedule-3";

    const manifest: any = {
      runId: ctx.runId,
      jurisdictionId: ctx.jurisdictionId,
      asOfDate: ctx.asOfDate,
      sourceName: this.sourceName,
      tocUrl,
    };

    const tocHtml = await fetchHtml(tocUrl);

    const sectionUrls = uniq(extractLinks(tocHtml, tocUrl, (href) => /\/schedule-3\/section-[a-z0-9\-]+/i.test(href)));

    const chapterUrls: string[] = [];
    for (const su of sectionUrls) {
      const sh = await fetchHtml(su);
      const chs = extractLinks(sh, su, (href) => /\/schedule-3\/section-[a-z0-9\-]+\/chapter-\d+$/i.test(href));
      for (const c of chs) chapterUrls.push(c);
    }

    const chapters = uniq(chapterUrls).sort((a, b) => a.localeCompare(b));

    const maxCh = Number(process.env.AU_MAX_CHAPTERS ?? "0");
    const selected = maxCh > 0 ? chapters.slice(0, maxCh) : chapters;

    const concurrency = Math.max(1, Number(process.env.AU_CHAPTER_CONCURRENCY ?? "3"));

    const tariffLines: any[] = [];
    const expressions: any[] = [];
    const measures: any[] = [];

    const tariffLineIdByCode = new Map<string, string>();

    const queue = [...selected];

    async function worker() {
      while (queue.length) {
        const url = queue.shift()!;
        console.log(`[ingest:AU] fetch ${url}`);

        const html = await fetchHtml(url);
        const text = htmlToText(html);

        // Use a regex anchored on "View TCOs for <code>" which appears for tariff lines.
        const re = /(\d{4}\.\d{2}\.\d{2})([\s\S]{0,260}?)\bView\s*TCOs\s*for\s*\1/gi;
        let m: RegExpExecArray | null;

        while ((m = re.exec(text))) {
          const codeDots = String(m[1] ?? "").trim();
          const chunk = String(m[2] ?? "").replace(/\s+/g, " ").trim();

          const codeDigits = normalizeDigits(codeDots);
          if (!codeDigits || codeDigits.length < 8) continue;

          // Australia classification is typically 8 digits (dots just formatting).
          const code8 = codeDigits.slice(0, 8);

          if (tariffLineIdByCode.has(code8)) continue;

          const dutyText = pickLastRateToken(chunk);
          const desc = cleanDescription(chunk, dutyText);

          const tlid = uuidv4();
          tariffLineIdByCode.set(code8, tlid);

          tariffLines.push({
            tariffLineId: tlid,
            jurisdictionId: "AU",
            code: code8,
            codeLen: code8.length,
            description: desc,
            validFrom: ctx.asOfDate,
            validTo: OPEN_END,
            sourceRef: url,
          });

          const parsed = parseRateToAst(String(dutyText ?? ""), {
            defaultCurrency: "AUD",
            defaultMassField: "net_mass_kg",
          });

          const expressionId = uuidv4();
          if (parsed.ok) {
            expressions.push({
              expressionId,
              exprType: parsed.exprType,
              astJson: parsed.ast,
              currency: parsed.exprType === "SPECIFIC" ? "AUD" : null,
              unitCode: null,
              sourceRef: `AU ${parsed.normalized}`,
            });

            measures.push({
              measureId: uuidv4(),
              tariffLineId: tlid,
              expressionId,
              measureType: "CUSTOMS_DUTY",
              originScope: "MFN",
              originCode: "ALL",
              validFrom: ctx.asOfDate,
              validTo: OPEN_END,
              sourceRef: "AU tariff",
            });
          } else {
            expressions.push({
              expressionId,
              exprType: "CUSTOM",
              astJson: { op: "manual_required", reason: parsed.reason, message: parsed.message, raw: parsed.raw },
              currency: null,
              unitCode: null,
              sourceRef: `AU raw: ${String(dutyText ?? "").slice(0, 200)}`,
            });

            measures.push({
              measureId: uuidv4(),
              tariffLineId: tlid,
              expressionId,
              measureType: "CUSTOMS_DUTY",
              originScope: "MFN",
              originCode: "ALL",
              validFrom: ctx.asOfDate,
              validTo: OPEN_END,
              sourceRef: "manual_required",
            });
          }
        }
      }
    }

    const runners = Array.from({ length: concurrency }, () => worker());
    await Promise.all(runners);

    const gstRate = String(process.env.AU_GST_RATE_PCT ?? "10");

    const vatRules = [{
      vatRuleId: uuidv4(),
      jurisdictionId: "AU",
      rateType: "STANDARD" as const,
      ratePct: gstRate,
      validFrom: ctx.asOfDate,
      validTo: OPEN_END,
      sourceRef: "AU GST standard (MVP)",
    }];

    const vatBaseFormulas = [{
      vatBaseFormulaId: uuidv4(),
      jurisdictionId: "AU",
      astJson: {
        op: "add",
        terms: [
          { op: "field", name: "customs_value" },
          { op: "field", name: "customs_duty_total" },
          { op: "field", name: "freight_to_border" },
          { op: "field", name: "insurance_to_border" },
        ],
      },
      validFrom: ctx.asOfDate,
      validTo: OPEN_END,
      sourceRef: "AU GST base (MVP)",
    }];

    manifest.sectionUrls = sectionUrls;
    manifest.chapterCount = selected.length;
    manifest.chapters = selected;

    return {
      canonical: {
        tariffLines,
        expressions,
        measures,
        vatRules,
        vatBaseFormulas,
        thresholdRules: [],
      },
      manifest: {
        ...manifest,
        insertedLines: tariffLines.length,
        insertedMeasures: measures.length,
      },
    };
  }
}
