import { v4 as uuidv4 } from "uuid";
import { Connector, ConnectorResult, RunContext } from "./base";
import { parseRateToAst } from "../lib/parseRateToAst";
import { extractLinks, extractTableRows, fetchHtml, htmlToText } from "../lib/html";

const OPEN_END = process.env.OPEN_END_DATE ?? "9999-12-31";

function normalizeDigits(code: string): string {
  return (code ?? "").replace(/[^0-9]/g, "");
}

function uniq<T>(xs: T[]): T[] {
  return [...new Set(xs)];
}

function pickDutyColumnIndex(headers: string[]): number | null {
  const pref = String(process.env.JP_DUTY_PREF ?? "WTO").toUpperCase();

  const normalized = headers.map((h) => String(h ?? "").toUpperCase());

  // Try exact-ish matches.
  const candidates =
    pref === "GENERAL" ? ["GENERAL", "GENERAL RATE", "GENERAL RATE OF DUTY", "GENERAL RATE OF DUTY (TEMPORARY)"] :
    pref === "WTO" ? ["WTO", "WTO RATE", "WTO RATE OF DUTY", "WTO (MFN)"] :
    [pref];

  for (const c of candidates) {
    const idx = normalized.findIndex((h) => h.includes(c));
    if (idx >= 0) return idx;
  }

  // Fallback: choose any header containing "RATE".
  const rateIdx = normalized.findIndex((h) => h.includes("RATE"));
  return rateIdx >= 0 ? rateIdx : null;
}

function bestEffortDutyFromCells(cells: string[], dutyIdx: number | null): string {
  if (!cells.length) return "";

  const idx = dutyIdx != null && dutyIdx >= 0 && dutyIdx < cells.length ? dutyIdx : null;
  if (idx != null) {
    const d = String(cells[idx] ?? "").trim();
    if (d) return d;
  }

  // Heuristic: pick the last cell that looks like a rate.
  for (let i = cells.length - 1; i >= 0; i--) {
    const c = String(cells[i] ?? "").trim();
    if (!c) continue;
    if (/\bfree\b|\bnil\b|%|per\s*\d*\s*(kg|g|l|litre|liter|ml|each|pcs|item)\b/i.test(c)) return c;
  }

  return String(cells[cells.length - 1] ?? "").trim();
}

function bestEffortDescriptionFromCells(cells: string[]): string | null {
  if (cells.length < 2) return null;

  // Often column 2 is description; otherwise pick the longest non-rate cell.
  const c1 = String(cells[1] ?? "").trim();
  if (c1 && !/%|\bfree\b|\bnil\b|per\b/i.test(c1)) return c1;

  let best: string | null = null;
  for (const c of cells) {
    const t = String(c ?? "").trim();
    if (!t) continue;
    if (/^\d+$/.test(t)) continue;
    if (/\bfree\b|\bnil\b|%|per\b/i.test(t)) continue;
    if (!best || t.length > best.length) best = t;
  }
  return best;
}

export class JpConnector implements Connector {
  public readonly sourceName = "JP_CUSTOMS_TARIFF";

  async run(ctx: RunContext): Promise<ConnectorResult> {
    const effective = process.env.JP_TARIFF_EFFECTIVE ?? "2026_01_01";
    const indexUrl = process.env.JP_TARIFF_INDEX_URL
      ?? `https://www.customs.go.jp/english/tariff/${effective}/index.htm`;

    const manifest: any = {
      runId: ctx.runId,
      jurisdictionId: ctx.jurisdictionId,
      asOfDate: ctx.asOfDate,
      sourceName: this.sourceName,
      effective,
      indexUrl,
      dutyPref: (process.env.JP_DUTY_PREF ?? "WTO").toUpperCase(),
    };

    const indexHtml = await fetchHtml(indexUrl);

    // Chapter pages are typically under /data/ (e.g., data/e_02.htm).
    const chapterUrls = uniq(extractLinks(indexHtml, indexUrl, (href) => /\/data\/e_\d{2}\.htm/i.test(href)));

    const maxCh = Number(process.env.JP_MAX_CHAPTERS ?? "0");
    const chapters = maxCh > 0 ? chapterUrls.slice(0, maxCh) : chapterUrls;

    const concurrency = Math.max(1, Number(process.env.JP_CHAPTER_CONCURRENCY ?? "3"));

    const tariffLines: any[] = [];
    const expressions: any[] = [];
    const measures: any[] = [];

    const tariffLineIdByCode = new Map<string, string>();
    const dutyByCode = new Map<string, string>();

    // A simple bounded concurrency runner.
    const queue = [...chapters];

    async function worker() {
      while (queue.length) {
        const url = queue.shift()!;
        console.log(`[ingest:JP] fetch ${url}`);

        // Many JP tariff pages are Shift_JIS.
        const html = await fetchHtml(url, { defaultCharset: "utf-8" });

        // Prefer table parsing; fallback to text parsing.
        const rows = extractTableRows(html);

        if (rows.length >= 5) {
          // Find a header row (contains a "Rate" column), then parse subsequent rows.
          let headerIdx = -1;
          for (let i = 0; i < Math.min(rows.length, 20); i++) {
            const r = rows[i] ?? [];
            if (r.some((c) => /rate/i.test(String(c ?? "")))) {
              headerIdx = i;
              break;
            }
          }
          const headers = headerIdx >= 0 ? (rows[headerIdx] ?? []) : [];
          const dutyIdx = headers.length ? pickDutyColumnIndex(headers) : null;

          for (let i = Math.max(0, headerIdx + 1); i < rows.length; i++) {
            const cells = rows[i] ?? [];
            if (!cells.length) continue;

            const codeDigits = normalizeDigits(String(cells[0] ?? ""));
            if (!codeDigits || codeDigits.length < 4) continue;

            const rawDuty = bestEffortDutyFromCells(cells, dutyIdx);

            // Duty inheritance by parent prefix (best-effort).
            let dutyText = String(rawDuty ?? "").trim();
            if (!dutyText) {
              for (let len = codeDigits.length - 1; len >= 4; len--) {
                const p = codeDigits.slice(0, len);
                const inherited = dutyByCode.get(p);
                if (inherited) { dutyText = inherited; break; }
              }
            }
            if (dutyText) dutyByCode.set(codeDigits, dutyText);

            if (!tariffLineIdByCode.has(codeDigits)) {
              const tlid = uuidv4();
              tariffLineIdByCode.set(codeDigits, tlid);

              tariffLines.push({
                tariffLineId: tlid,
                jurisdictionId: "JP",
                code: codeDigits,
                codeLen: codeDigits.length,
                description: bestEffortDescriptionFromCells(cells),
                validFrom: ctx.asOfDate,
                validTo: OPEN_END,
                sourceRef: url,
              });

              const parsed = parseRateToAst(String(dutyText ?? ""), {
                defaultCurrency: "JPY",
                defaultMassField: "net_mass_kg",
              });

              const expressionId = uuidv4();
              if (parsed.ok) {
                expressions.push({
                  expressionId,
                  exprType: parsed.exprType,
                  astJson: parsed.ast,
                  currency: parsed.exprType === "SPECIFIC" ? "JPY" : null,
                  unitCode: null,
                  sourceRef: `JP ${parsed.normalized}`,
                });

                measures.push({
                  measureId: uuidv4(),
                  tariffLineId: tlid,
                  expressionId,
                  measureType: "CUSTOMS_DUTY",
                  originScope: "MFN",
                  originCode: "ALL",
                  validFrom: ctx.asOfDate,
                  validTo: OPEN_END,
                  sourceRef: "JP tariff",
                });
              } else {
                expressions.push({
                  expressionId,
                  exprType: "CUSTOM",
                  astJson: { op: "manual_required", reason: parsed.reason, message: parsed.message, raw: parsed.raw },
                  currency: null,
                  unitCode: null,
                  sourceRef: `JP raw: ${String(dutyText ?? "").slice(0, 200)}`,
                });

                measures.push({
                  measureId: uuidv4(),
                  tariffLineId: tlid,
                  expressionId,
                  measureType: "CUSTOMS_DUTY",
                  originScope: "MFN",
                  originCode: "ALL",
                  validFrom: ctx.asOfDate,
                  validTo: OPEN_END,
                  sourceRef: "manual_required",
                });
              }
            }
          }

          continue;
        }

        // Text fallback (rare)
        const text = htmlToText(html);
        const lines = text.split("\n").map((l) => l.trim()).filter(Boolean);

        for (const line of lines) {
          const m = line.match(/^(\d{4,10})\s+(.*)$/);
          if (!m) continue;

          const codeDigits = normalizeDigits(m[1] ?? "");
          if (!codeDigits || codeDigits.length < 4) continue;

          // Find a rate-ish tail.
          const tail = String(m[2] ?? "");
          const rateMatch = tail.match(/(free|nil|\d+(?:\.\d+)?\s*%|\d+(?:\.\d+)?\s*(?:¥|yen)?\s*(?:per|\/)\s*(?:\d+(?:\.\d+)?)?\s*(kg|g|l|litre|liter|ml|each|pcs|item)\b.*)$/i);
          const dutyText = rateMatch ? String(rateMatch[1]) : "";

          if (!tariffLineIdByCode.has(codeDigits)) {
            const tlid = uuidv4();
            tariffLineIdByCode.set(codeDigits, tlid);

            tariffLines.push({
              tariffLineId: tlid,
              jurisdictionId: "JP",
              code: codeDigits,
              codeLen: codeDigits.length,
              description: tail.replace(rateMatch?.[0] ?? "", "").trim() || null,
              validFrom: ctx.asOfDate,
              validTo: OPEN_END,
              sourceRef: url,
            });

            const parsed = parseRateToAst(String(dutyText ?? ""), { defaultCurrency: "JPY", defaultMassField: "net_mass_kg" });

            const expressionId = uuidv4();
            if (parsed.ok) {
              expressions.push({
                expressionId,
                exprType: parsed.exprType,
                astJson: parsed.ast,
                currency: parsed.exprType === "SPECIFIC" ? "JPY" : null,
                unitCode: null,
                sourceRef: `JP ${parsed.normalized}`,
              });

              measures.push({
                measureId: uuidv4(),
                tariffLineId: tlid,
                expressionId,
                measureType: "CUSTOMS_DUTY",
                originScope: "MFN",
                originCode: "ALL",
                validFrom: ctx.asOfDate,
                validTo: OPEN_END,
                sourceRef: "JP tariff",
              });
            } else {
              expressions.push({
                expressionId,
                exprType: "CUSTOM",
                astJson: { op: "manual_required", reason: parsed.reason, message: parsed.message, raw: parsed.raw },
                currency: null,
                unitCode: null,
                sourceRef: `JP raw: ${String(dutyText ?? "").slice(0, 200)}`,
              });

              measures.push({
                measureId: uuidv4(),
                tariffLineId: tlid,
                expressionId,
                measureType: "CUSTOMS_DUTY",
                originScope: "MFN",
                originCode: "ALL",
                validFrom: ctx.asOfDate,
                validTo: OPEN_END,
                sourceRef: "manual_required",
              });
            }
          }
        }
      }
    }

    const runners = Array.from({ length: concurrency }, () => worker());
    await Promise.all(runners);

    // Consumption tax (10% standard) — keep configurable.
    const ctRate = String(process.env.JP_CONSUMPTION_TAX_RATE_PCT ?? "10");

    const vatRules = [{
      vatRuleId: uuidv4(),
      jurisdictionId: "JP",
      rateType: "STANDARD" as const,
      ratePct: ctRate,
      validFrom: ctx.asOfDate,
      validTo: OPEN_END,
      sourceRef: "JP consumption tax standard (MVP)",
    }];

    const vatBaseFormulas = [{
      vatBaseFormulaId: uuidv4(),
      jurisdictionId: "JP",
      astJson: {
        op: "add",
        terms: [
          { op: "field", name: "customs_value" },
          { op: "field", name: "customs_duty_total" },
          { op: "field", name: "freight_to_border" },
          { op: "field", name: "insurance_to_border" },
        ],
      },
      validFrom: ctx.asOfDate,
      validTo: OPEN_END,
      sourceRef: "JP CT base (MVP)",
    }];

    manifest.chapterUrls = chapters;
    manifest.chapterCount = chapters.length;

    return {
      canonical: {
        tariffLines,
        expressions,
        measures,
        vatRules,
        vatBaseFormulas,
        thresholdRules: [],
      },
      manifest: {
        ...manifest,
        insertedLines: tariffLines.length,
        insertedMeasures: measures.length,
      },
    };
  }
}
