from __future__ import annotations

import csv
import io
import re
from datetime import date
from typing import Dict, List, Optional

from pydantic import BaseModel, Field

from app.services.models_v2 import FxRateV2


class FxCsvIssue(BaseModel):
    severity: str = Field(..., description="'error' or 'warning'")
    row_number: int = Field(..., ge=1, description="1-indexed row number in the CSV (excluding header).")
    field: Optional[str] = Field(default=None)
    message: str


class FxRatesCsvParseResult(BaseModel):
    fx_rates: List[FxRateV2] = Field(default_factory=list)
    issues: List[FxCsvIssue] = Field(default_factory=list)
    detected_columns: List[str] = Field(default_factory=list)
    ignored_columns: List[str] = Field(default_factory=list)


_NUM_RE = re.compile(r"[^0-9eE+\-\.]" )


def _norm_header(h: str) -> str:
    h = (h or "").strip().lower()
    h = re.sub(r"[\s\-]+", "_", h)
    return h


_ALIASES: Dict[str, str] = {
    "avg_rate": "avg_rate_to_reporting",
    "average_rate": "avg_rate_to_reporting",
    "avg_rate_reporting": "avg_rate_to_reporting",
    "spot_rate": "spot_rate_to_reporting",
    "spot": "spot_rate_to_reporting",
    "closing_rate": "spot_rate_to_reporting",
    "closing": "spot_rate_to_reporting",
    "closing_rate_to_reporting": "spot_rate_to_reporting",
    "year_end_rate": "spot_rate_to_reporting",
    "year_end": "spot_rate_to_reporting",
    "fy_start": "fiscal_year_start",
    "fiscal_year": "fiscal_year_start",
    "fy": "fiscal_year_start",
}


def _parse_float(raw: str) -> Optional[float]:
    if raw is None:
        return None
    s = str(raw).strip()
    if s == "":
        return None
    s = _NUM_RE.sub("", s)
    if s in {"", "+", "-", "."}:
        return None
    try:
        return float(s)
    except ValueError:
        return None


def _parse_date(raw: str) -> Optional[date]:
    if raw is None:
        return None
    s = str(raw).strip()
    if s == "":
        return None
    try:
        # Expect YYYY-MM-DD
        parts = s.split("-")
        if len(parts) != 3:
            return None
        y, m, d = (int(parts[0]), int(parts[1]), int(parts[2]))
        return date(y, m, d)
    except Exception:
        return None


def generate_fx_rates_csv_template() -> bytes:
    headers = [
        "currency",
        "avg_rate_to_reporting",
        "spot_rate_to_reporting",
        "fiscal_year_start",
        "note",
    ]

    example = {
        "currency": "USD",
        "avg_rate_to_reporting": "0.92",
        "spot_rate_to_reporting": "0.91",
        "fiscal_year_start": "2027-01-01",
        "note": "Example: USD -> EUR for FY2027",
    }

    buf = io.StringIO(newline="")
    writer = csv.DictWriter(buf, fieldnames=headers)
    writer.writeheader()
    writer.writerow(example)
    return buf.getvalue().encode("utf-8")


def parse_fx_rates_csv(contents: bytes) -> FxRatesCsvParseResult:
    text = contents.decode("utf-8-sig", errors="replace")
    buf = io.StringIO(text)
    reader = csv.DictReader(buf)
    if reader.fieldnames is None:
        return FxRatesCsvParseResult(
            fx_rates=[],
            issues=[FxCsvIssue(severity="error", row_number=1, field=None, message="CSV is missing a header row.")],
        )

    raw_headers = list(reader.fieldnames)
    norm_to_raw: Dict[str, str] = {}
    for h in raw_headers:
        nh = _norm_header(h)
        nh = _ALIASES.get(nh, nh)
        if nh and nh not in norm_to_raw:
            norm_to_raw[nh] = h

    detected = list(norm_to_raw.keys())
    ignored_cols: List[str] = []
    for nh in detected:
        if nh not in {"currency", "avg_rate_to_reporting", "spot_rate_to_reporting", "fiscal_year_start", "note"}:
            ignored_cols.append(norm_to_raw.get(nh, nh))

    out = FxRatesCsvParseResult(detected_columns=raw_headers, ignored_columns=ignored_cols)

    fx_rates: List[FxRateV2] = []
    issues: List[FxCsvIssue] = []

    has_currency = "currency" in detected
    has_avg = "avg_rate_to_reporting" in detected

    for i, row in enumerate(reader, start=1):
        rownum = i
        cur = (row.get(norm_to_raw.get("currency", "")) or "").strip() if has_currency else ""
        avg_raw = row.get(norm_to_raw.get("avg_rate_to_reporting", "")) if has_avg else None
        avg = _parse_float(avg_raw) if avg_raw is not None else None

        if not cur:
            issues.append(FxCsvIssue(severity="error", row_number=rownum, field="currency", message="Missing currency."))
            continue
        if avg is None or avg <= 0:
            issues.append(
                FxCsvIssue(severity="error", row_number=rownum, field="avg_rate_to_reporting", message="Missing or invalid avg FX rate.")
            )
            continue

        spot_raw = row.get(norm_to_raw.get("spot_rate_to_reporting", ""))
        spot = _parse_float(spot_raw) if spot_raw is not None else None
        fy_raw = row.get(norm_to_raw.get("fiscal_year_start", ""))
        fy = _parse_date(fy_raw) if fy_raw is not None else None
        note = (row.get(norm_to_raw.get("note", "")) or "").strip() or None

        try:
            fx_rates.append(
                FxRateV2(
                    currency=cur,
                    avg_rate_to_reporting=float(avg),
                    spot_rate_to_reporting=float(spot) if spot is not None else None,
                    fiscal_year_start=fy,
                    note=note,
                )
            )
        except Exception as e:
            issues.append(FxCsvIssue(severity="error", row_number=rownum, field=None, message=str(e)))

    out.fx_rates = fx_rates
    out.issues = issues
    return out
