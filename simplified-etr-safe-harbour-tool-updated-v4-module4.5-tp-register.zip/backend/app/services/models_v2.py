from __future__ import annotations

from datetime import date
from typing import List, Optional, Literal, Any

from pydantic import BaseModel, Field, model_validator

from app.services.models import (
    AdjustmentLine,
    ElectionRecord,
    TraceLine,
    JurisdictionInput as JurisdictionInputV1,
    EntityInput as EntityInputV1,
)


# ---------------------------------------------------------------------------
# Accounting basis / currency translation scaffolding (v4 module 2)
# ---------------------------------------------------------------------------

AmountScale = Literal["UNITS", "THOUSANDS", "MILLIONS"]
AccountingBasisSource = Literal["CFS", "LOCAL_GAAP", "OTHER"]


class AccountingBasisV2(BaseModel):
    """Accounting basis / currency metadata.

    This tool is a *calculator* and cannot determine accounting standards or currency translation
    independently. The OECD guidance requires that currency translation rules apply, and that
    certain jurisdictions subject to QDMTT LFAS rules may require local accounting standards.

    v4 module 2 introduces lightweight scaffolding to:
      - record the accounting basis assumptions,
      - normalise monetary inputs to a reporting currency when FX rates are provided, and
      - raise errors for obvious LFAS conflicts.
    """

    basis_source: AccountingBasisSource = Field(
        default="CFS",
        description=(
            "Source of accounting basis used for the figures supplied (e.g., CFS or local GAAP). "
            "This is used for validation and audit trail only."
        ),
    )

    standard: Optional[str] = Field(
        default=None,
        description="Optional label for the accounting standard used (e.g., IFRS, US GAAP, UK GAAP, local GAAP).",
    )

    currency: Optional[str] = Field(
        default=None,
        description=(
            "Currency code for monetary inputs provided for this Tested Jurisdiction (e.g., 'EUR', 'USD'). "
            "If omitted, and a request.group_profile.reporting_currency is provided, the tool assumes amounts "
            "are already in that reporting currency."
        ),
    )

    amount_scale: AmountScale = Field(
        default="UNITS",
        description="Scale applied to monetary inputs: UNITS (as entered), THOUSANDS (x1,000), or MILLIONS (x1,000,000).",
    )

    # LFAS / QDMTT scaffolding
    lfas_qdmtt_applies: bool = Field(
        default=False,
        description=(
            "If True, the Tested Jurisdiction is subject to a QDMTT LFAS requirement (jurisdiction requires local financial accounting standards)."
        ),
    )
    lfas_requires_local_gaap: bool = Field(
        default=False,
        description=(
            "If True, the user asserts that the jurisdiction requires using local GAAP for QDMTT LFAS purposes. "
            "If basis_source='CFS' and the jurisdiction does not allow CFS GAAP, the tool will raise an error."
        ),
    )
    jurisdiction_allows_cfs_gaap_for_qdmtt: Optional[bool] = Field(
        default=None,
        description=(
            "If True, the jurisdiction allows using the CFS accounting standard for QDMTT even if LFAS would otherwise apply. "
            "If omitted, treated as False for validation when lfas_requires_local_gaap=True."
        ),
    )

    note: Optional[str] = None

    @model_validator(mode="after")
    def _validate_lfas(self) -> "AccountingBasisV2":
        """Tighter LFAS / QDMTT gating rules (v4 module 3).

        Practical implementation:
        - If the user asserts local GAAP is required (lfas_requires_local_gaap=True), then:
            * basis_source must be either LOCAL_GAAP, or CFS where the jurisdiction explicitly allows it.
            * basis_source='OTHER' is not accepted (too ambiguous for a determinate tool).
        - If basis_source='CFS' under a local GAAP requirement, jurisdiction_allows_cfs_gaap_for_qdmtt must be True.
        """

        if self.lfas_requires_local_gaap:
            if self.basis_source == "OTHER":
                raise ValueError(
                    "LFAS validation: lfas_requires_local_gaap=true but basis_source='OTHER'. Use basis_source='LOCAL_GAAP' (or 'CFS' if explicitly allowed)."
                )

            if self.basis_source == "CFS" and not bool(self.jurisdiction_allows_cfs_gaap_for_qdmtt):
                raise ValueError(
                    "LFAS validation: lfas_requires_local_gaap=true but basis_source='CFS' and jurisdiction_allows_cfs_gaap_for_qdmtt is not true."
                )
        return self


class GroupProfileV2(BaseModel):
    reporting_currency: Optional[str] = Field(
        default=None,
        description="Group reporting currency used for results (e.g., 'EUR'). If provided, FX rates may be used to translate inputs.",
    )
    default_accounting_standard: Optional[str] = Field(
        default=None,
        description="Optional label for group default accounting standard (e.g., IFRS).",
    )
    fx_translation_convention: Optional[str] = Field(
        default="PL_AVG_BS_SPOT",
        description=(
            "Currency translation convention used when FX rates are supplied. "
            "This tool applies average FX rates to P&L-type items (income/taxes) and spot FX rates to balance sheet items "
            "(when/if such items are introduced, e.g., Transition Year opening DTAs/DTLs)."
        ),
    )
    note: Optional[str] = None


class FxRateV2(BaseModel):
    """FX rate to translate from a local currency into the reporting currency."""

    currency: str = Field(..., description="Local currency code (e.g., 'USD').")
    avg_rate_to_reporting: float = Field(..., gt=0.0, description="Average FX rate to reporting currency for P&L items.")
    spot_rate_to_reporting: Optional[float] = Field(
        default=None,
        gt=0.0,
        description=(
            "Optional spot / closing FX rate to reporting currency. "
            "Used for balance sheet translation conventions (v4 module 3 and later modules)."
        ),
    )
    fiscal_year_start: Optional[date] = Field(
        default=None,
        description="Optional fiscal year start date that this FX rate applies to. If omitted, used as a default rate for that currency.",
    )
    note: Optional[str] = None


# ---------------------------------------------------------------------------
# Transition Year rules (v4 module 4)
# ---------------------------------------------------------------------------

DeferredTaxItemType = Literal["DTA", "DTL"]
DeferredTaxCategory = Literal["TEMPORARY_DIFFERENCE", "TAX_LOSS", "TAX_CREDIT", "OTHER"]


class TransitionDeferredTaxItemV2(BaseModel):
    """Opening deferred tax item for Transition Year (Articles 9.1.1 / 9.1.2).

    This is balance-sheet oriented data and is translated using spot/closing FX (when provided).

    The Simplified ETR Safe Harbour requires that Articles 9.1.1 to 9.1.3 and related Commentary
    apply for Transition Year purposes (Box 4.5). In practice, the detailed GloBE deferred tax
    computations can be complex; this model provides a structured way to represent key inputs.

    In v4 Module 4, this data is used primarily to model Article 9.1.2 "disallowed opening DTA"
    effects for the Transition Year.
    """

    item_id: Optional[str] = None
    label: Optional[str] = None

    item_type: DeferredTaxItemType = Field(..., description="Deferred tax item type: DTA or DTL.")
    category: DeferredTaxCategory = Field(
        default="TEMPORARY_DIFFERENCE",
        description="High-level category used for audit and user review.",
    )

    opening_balance: float = Field(
        ...,
        ge=0.0,
        description="Opening deferred tax balance per financial accounts (positive amount).",
    )

    opening_balance_at_minimum_rate: Optional[float] = Field(
        default=None,
        ge=0.0,
        description=(
            "Optional opening balance already expressed on a Minimum Rate basis. "
            "If provided, tax_rate is ignored for recast purposes."
        ),
    )

    tax_rate: Optional[float] = Field(
        default=None,
        ge=0.0,
        le=1.0,
        description=(
            "Tax rate used to measure the opening_balance in the financial accounts (used to recast to Minimum Rate). "
            "If omitted, the tool will attempt to use the jurisdiction accounted_tax_rate (if supplied)."
        ),
    )

    disallowed_under_article_9_1_2: bool = Field(
        default=False,
        description=(
            "If True and item_type='DTA', the opening DTA is not allowed under Article 9.1.2 and is treated as zero "
            "for GloBE purposes."
        ),
    )

    # DTL-specific meta (used in later modules / audit)
    is_recapture_exception_accrual: bool = Field(
        default=False,
        description="For DTL items: whether the DTL is a Recapture Exception Accrual (REA).",
    )
    included_in_prior_globe_or_qdmtt: bool = Field(
        default=False,
        description=(
            "For DTL items: indicates the deferred tax liability was included in Adjusted Covered Taxes under full GloBE "
            "or a QDMTT in a prior year (relevant to whether reversals are excluded)."
        ),
    )

    # Currency/scaling (optional override)
    currency: Optional[str] = Field(
        default=None,
        description=(
            "Optional currency code for this balance. If omitted, uses Tested Jurisdiction accounting_basis.currency "
            "(or the request reporting currency if no currency is provided)."
        ),
    )
    amount_scale: AmountScale = Field(
        default="UNITS",
        description="Scale applied to the opening_balance: UNITS/THOUSANDS/MILLIONS.",
    )

    note: Optional[str] = None

    @model_validator(mode="after")
    def _validate(self) -> "TransitionDeferredTaxItemV2":
        if self.disallowed_under_article_9_1_2 and self.item_type != "DTA":
            raise ValueError(
                "TransitionDeferredTaxItemV2: disallowed_under_article_9_1_2 can only be true for item_type='DTA'."
            )
        return self


class Article913TransferV2(BaseModel):
    """Article 9.1.3 transfer adjustment scaffolding.

    In v4 Module 4, this is implemented as structured net adjustments to Simplified Income and
    Simplified Taxes for the current fiscal year.

    Currency translation follows the tool convention:
      - Income/Tax adjustments are P&L-type items -> average FX.
    """

    transfer_id: Optional[str] = None
    label: str = Field(..., description="Short label for the transfer adjustment.")

    transfer_fiscal_year_start: Optional[date] = Field(
        default=None,
        description="Fiscal year start date when the transfer occurred (optional; audit trail).",
    )

    income_adjustment: float = Field(
        default=0.0,
        description="Signed adjustment to Simplified Income for the current fiscal year.",
    )
    tax_adjustment: float = Field(
        default=0.0,
        description="Signed adjustment to Simplified Taxes for the current fiscal year.",
    )

    # Optional audit-only DTA amount at Minimum Rate (balance sheet)
    deferred_tax_asset_amount: Optional[float] = Field(
        default=None,
        ge=0.0,
        description=(
            "Optional DTA amount at Minimum Rate recognised/used under Article 9.1.3 commentary. "
            "This is audit metadata in Module 4 and is not used to compute Simplified Taxes unless the user "
            "reflects it in tax_adjustment."
        ),
    )

    currency: Optional[str] = Field(
        default=None,
        description=(
            "Optional currency code for income_adjustment / tax_adjustment. If omitted, uses Tested Jurisdiction currency."
        ),
    )
    amount_scale: AmountScale = Field(default="UNITS")

    note: Optional[str] = None


class TransitionYearV2(BaseModel):
    """Transition Year configuration (Box 4.5).

    The Transition Year for a Tested Jurisdiction is the first year the MNE Group elects the Simplified
    ETR Safe Harbour for that Tested Jurisdiction (or an earlier Transition Year otherwise determined
    under the GloBE Model Rules).

    In this stateless tool, the Transition Year date is supplied by the user.
    """

    transition_year_fy_start: Optional[date] = Field(
        default=None,
        description=(
            "Fiscal year start date of the Transition Year for this Tested Jurisdiction. "
            "If omitted but transition_year is provided, the tool assumes the current request fiscal year is the Transition Year."
        ),
    )

    opening_deferred_tax_items: List[TransitionDeferredTaxItemV2] = Field(
        default_factory=list,
        description=(
            "Opening DTAs/DTLs relevant under Articles 9.1.1 / 9.1.2. "
            "These are balance-sheet items and translated using spot FX (if provided)."
        ),
    )

    article_9_1_3_transfers: List[Article913TransferV2] = Field(
        default_factory=list,
        description="Optional structured net adjustments for Article 9.1.3 asset transfers.",
    )

    note: Optional[str] = None



# ---------------------------------------------------------------------------
# Transition Year state (v4 module 4.1)
# ---------------------------------------------------------------------------

class TransitionDeferredTaxRegisterItemV2(BaseModel):
    """Computed register item for Transition Year opening deferred tax balances.

    Purpose:
    - Capture Transition Year opening DTAs/DTLs after scaling and currency translation.
    - Persist the computed Minimum Rate basis amounts for later multi-year use.

    Amount conventions:
    - Amounts are stored in the "state currency" (typically the request reporting currency if FX translation is enabled;
      otherwise the Tested Jurisdiction input currency).
    """

    item_id: Optional[str] = None
    label: Optional[str] = None

    item_type: DeferredTaxItemType
    category: DeferredTaxCategory = 'TEMPORARY_DIFFERENCE'

    disallowed_under_article_9_1_2: bool = False

    # Computed amounts (state currency)
    opening_balance_state_currency: float = 0.0
    opening_balance_minimum_rate_state_currency: float = 0.0
    allowed_opening_balance_minimum_rate_state_currency: float = 0.0

    # If the opening DTA is disallowed, this is the tax increase applied in Transition Year
    disallowed_adjustment_state_currency: float = 0.0

    # Audit metadata
    tax_rate_used: Optional[float] = None
    was_provided_at_minimum_rate: bool = False
    fx_note: Optional[str] = None

    source_currency: Optional[str] = None
    source_amount_scale: AmountScale = 'UNITS'
    note: Optional[str] = None


class TransitionYearStateV2(BaseModel):
    """State object to carry Transition Year deferred tax register forward across fiscal years.

    This enables a stateless API to behave "statefully" across years by returning a state payload
    that the client stores and supplies in later-year requests.

    The state is scoped to one Tested Jurisdiction.
    """

    state_version: Literal['1'] = '1'

    transition_year_fy_start: date

    # Currency that register amounts are expressed in.
    # Typically equals request.group_profile.reporting_currency when FX translation is used.
    state_currency: Optional[str] = None

    # Fiscal year when the state was computed (useful for audit)
    computed_in_fiscal_year_start: Optional[date] = None

    opening_deferred_tax_register: List[TransitionDeferredTaxRegisterItemV2] = Field(default_factory=list)

    note: Optional[str] = None

    @model_validator(mode='after')
    def _normalise(self) -> 'TransitionYearStateV2':
        if self.state_currency:
            self.state_currency = str(self.state_currency).upper().strip() or None
        return self

# ---------------------------------------------------------------------------
# v2 wrappers around v1 input models
# ---------------------------------------------------------------------------

class JurisdictionFactsV2(JurisdictionInputV1):
    """Jurisdiction facts (v2).

    This model inherits the existing v1 JurisdictionInput for maximum re-use, but makes
    jurisdiction_code optional so UI clients do not need to duplicate it. The API will override
    the internal bucket id with tested_jurisdiction_id when running calculations.
    """

    jurisdiction_code: Optional[str] = Field(
        default=None,
        description=(
            "Optional. UI may omit this; the server will fill it internally. "
            "In v2, tested_jurisdiction_id is used as the internal grouping key."
        ),
    )


class EntityFactsV2(EntityInputV1):
    """Entity facts (v2).

    In v2, entities are typically nested under a Tested Jurisdiction. The server will override
    the internal grouping key with tested_jurisdiction_id when running calculations.
    """

    jurisdiction_code: Optional[str] = Field(
        default=None,
        description=(
            "Optional. This tool groups entities by tested_jurisdiction_id (not jurisdiction_code) in v2. "
            "Use tested_jurisdiction.jurisdiction_code for the country/territory code."
        ),
    )


# ---------------------------------------------------------------------------
# Elections (v2)
# ---------------------------------------------------------------------------

Scope = Literal["income", "tax", "eligibility", "metadata"]
ValueType = Literal["bool", "amount", "text"]
TermType = Literal["ANNUAL", "FIVE_YEAR"]
ElectionAction = Literal["ELECT", "REVOKE"]


class ElectionInstanceV2(BaseModel):
    """An election or adjustment selection associated with a Tested Jurisdiction."""

    action: ElectionAction = Field(
        default="ELECT",
        description=(
            "Election register event type. 'ELECT' records that the election is made; 'REVOKE' records that it is revoked "
            "(used for FIVE_YEAR elections which continue until revoked in the OECD guidance)."
        ),
    )

    election_code: str = Field(..., description="Election/adjustment code (see /api/v2/election-catalog).")
    scope: Scope = Field(..., description="Which part of the safe harbour it relates to.")
    value_type: ValueType = Field(..., description="Value type for the election.")
    # Optional term type on instance; if omitted, the server will infer from election catalog when possible.
    term_type: Optional[TermType] = Field(
        default=None,
        description="ANNUAL or FIVE_YEAR. If omitted, server will infer from the election catalog.",
    )
    effective_fiscal_year_start: Optional[date] = Field(
        default=None,
        description="Fiscal year start date when this election starts. Defaults to the request fiscal year start date.",
    )
    # Values
    bool_value: Optional[bool] = None
    amount: Optional[float] = Field(default=None, description="Signed amount (+/-) if value_type='amount'.")
    text_value: Optional[str] = None
    label: Optional[str] = None
    note: Optional[str] = None

    @model_validator(mode="after")
    def _validate_value(self) -> "ElectionInstanceV2":
        # Revocation events act as a timeline marker. They do not carry a value.
        if self.action == "REVOKE":
            return self
        vt = self.value_type
        if vt == "bool" and self.bool_value is None:
            raise ValueError(f"Election {self.election_code}: value_type='bool' requires bool_value.")
        if vt == "amount" and self.amount is None:
            raise ValueError(f"Election {self.election_code}: value_type='amount' requires amount.")
        if vt == "text" and (self.text_value is None or str(self.text_value).strip() == ""):
            raise ValueError(f"Election {self.election_code}: value_type='text' requires text_value.")
        return self


# ---------------------------------------------------------------------------
# Carryforwards (v2)
# ---------------------------------------------------------------------------

CarryforwardKind = Literal[
    "SIMPLIFIED_NEGATIVE_TAX_ADJUSTMENT",  # Box 4.3 (paragraphs 1-3)
    "EXCESS_NEGATIVE_TAX_CARRYFORWARD",    # GloBE Article 4.1.5 carry-forward (input)
    "LOSS_DTA_ADJUSTMENT",                 # Box 4.3 (paragraph 4) alternative methodology
]


class CarryforwardBalanceV2(BaseModel):
    kind: CarryforwardKind
    origin_fiscal_year_start: Optional[date] = Field(
        default=None, description="Fiscal year start date when the balance was generated (if known)."
    )
    amount: float = Field(
        ...,
        description=(
            "Opening amount of the carryforward. Enter as a positive number. "
            "The tool applies it as a reduction to Simplified Taxes, subject to OECD limits."
        ),
    )
    remaining_amount: Optional[float] = Field(
        default=None,
        description="If omitted, defaults to amount. Must be >= 0.",
    )
    note: Optional[str] = None

    @model_validator(mode="after")
    def _normalise(self) -> "CarryforwardBalanceV2":
        # Normalise negative values to positive to avoid sign confusion.
        if self.amount < 0:
            self.amount = abs(self.amount)
        if self.remaining_amount is None:
            self.remaining_amount = float(self.amount)
        if self.remaining_amount < 0:
            self.remaining_amount = abs(self.remaining_amount)
        return self


class CarryforwardMovementV2(BaseModel):
    kind: CarryforwardKind
    used_amount: float = Field(..., ge=0.0, description="Amount utilised in the current fiscal year (>= 0).")
    remaining_amount: float = Field(..., ge=0.0, description="Remaining amount after utilisation (>= 0).")
    note: Optional[str] = None


# ---------------------------------------------------------------------------
# Cross-border adjustments (v2)
# ---------------------------------------------------------------------------

CrossBorderTaxTreatment = Literal[
    "ALLOCATE",          # subtract from source and add to target
    "EXCLUDE_FROM_ALL",  # subtract from source and add to no Tested Jurisdiction
    "KEEP_IN_SOURCE",    # do not adjust (i.e., keep where recorded)
]


class CrossBorderTaxItemV2(BaseModel):
    """Cross-border allocable tax item.

    This is a *structured* way to handle the OECD cross-border tax exclusion/allocation concept.
    The user provides the tax amount and where it is recorded (source) and optionally where it
    should be allocated (target).

    The engine applies the adjustment after the base v1 Simplified Taxes computation, and before
    carryforwards, so it affects Simplified ETR.
    """

    item_id: Optional[str] = None
    label: Optional[str] = None
    category: Optional[str] = Field(
        default=None,
        description="Optional category label (e.g., withholding, CFC, PE, hybrid, other).",
    )

    amount: float = Field(..., ge=0.0, description="Tax amount (positive).")

    currency: Optional[str] = Field(
        default=None,
        description=(
            "Optional currency code for the amount (e.g., 'USD'). If request.group_profile.reporting_currency is provided "
            "and currency differs, the engine will translate this amount using request.fx_rates. "
            "If omitted, the tool assumes the amount is already in the reporting currency (when provided)."
        ),
    )

    amount_scale: AmountScale = Field(
        default="UNITS",
        description="Scale applied to the amount: UNITS/THOUSANDS/MILLIONS. Applied before FX translation.",
    )

    source_tested_jurisdiction_id: Optional[str] = Field(
        default=None,
        description="Tested Jurisdiction where the tax is currently recorded (for safe harbour purposes).",
    )
    target_tested_jurisdiction_id: Optional[str] = Field(
        default=None,
        description="Tested Jurisdiction to which the tax should be allocated (if applicable).",
    )

    treatment: Optional[CrossBorderTaxTreatment] = Field(
        default=None,
        description=(
            "How to treat the tax item. If omitted, the engine infers a default based on whether a target is provided "
            "and whether the cross-border 'keep allocable taxes' election is in effect for the source jurisdiction."
        ),
    )

    requires_pe_simplification_election: bool = Field(
        default=False,
        description=(
            "If True, the engine requires the PE simplification election to be effective for the relevant Tested Jurisdiction(s). "
            "Use this when the allocation relies on the PE simplification election."  
        ),
    )

    note: Optional[str] = None

    @model_validator(mode="after")
    def _validate(self) -> "CrossBorderTaxItemV2":
        if self.treatment == "ALLOCATE" and not self.target_tested_jurisdiction_id:
            raise ValueError("CrossBorderTaxItemV2: treatment='ALLOCATE' requires target_tested_jurisdiction_id.")
        return self



# ---------------------------------------------------------------------------
# After-year-end adjustments (OECD Box 4.6) (v4 phase 4.4)
# ---------------------------------------------------------------------------

AfterYearEndAdjustmentKind = Literal["income", "tax"]
QualifiedRefundCheckBasis = Literal["SIMPLIFIED_ETR", "GLOBE_ETR", "ATTESTATION"]


class AfterYearEndAdjustmentV2(BaseModel):
    """Change to Covered Tax liability or income for a Fiscal Year accrued after year end (Box 4.6).

    Each record links:
      - transaction_year: the Fiscal Year to which the tax/income relates, and
      - accrual_year: the Fiscal Year in which the adjustment is reflected in the financial accounts.

    Default rule (Box 4.6(1)):
      - include in the accrual year.

    Optional Five-Year Election (Box 4.6(2)):
      - for adjustments that accrue within the 12 months following the end of the transaction year,
        include them in the transaction year (group-wide election; excludes TP-related adjustments).

    Downward tax adjustment more than 12 months after year end (Box 4.6(3)):
      - when flagged by the user (apply_large_refund_exclusion=True), the engine can exclude certain
        net decreases from the accrual year to avoid losing the safe harbour, subject to conditions.
    """

    adjustment_id: Optional[str] = None
    label: Optional[str] = None
    tested_jurisdiction_id: str = Field(..., description="Target Tested Jurisdiction receiving the adjustment.")

    kind: AfterYearEndAdjustmentKind = Field(..., description="'income' affects Simplified Income; 'tax' affects Simplified Taxes.")
    amount: float = Field(..., description="Signed amount (+/-). For tax, negative = decrease/refund; positive = increase.")

    transaction_year_fy_start: date = Field(..., description="Fiscal year start date of the transaction year.")
    accrual_year_fy_start: date = Field(..., description="Fiscal year start date of the accrual year (where the adjustment is booked).")

    # Timing metadata for applying the 12-month election and Box 4.6(3) rule
    months_after_transaction_year_end: Optional[int] = Field(
        default=None,
        ge=0,
        description=(
            "Months after the end of the transaction year when the adjustment accrued. "
            "Used to determine whether it is within 12 months (for the Five-Year election) "
            "and whether it is more than 12 months (for Box 4.6(3))."
        ),
    )
    accrued_within_12_months: Optional[bool] = Field(
        default=None,
        description="Optional override for whether the adjustment accrued within 12 months of transaction year end.",
    )

    is_transfer_pricing_related: bool = Field(
        default=False,
        description="If True, the Box 4.6(2) election does not apply. (TP adjustments are handled under section 5.2.)",
    )


    # Transfer pricing (section 5.2) structured counterparty metadata.
    # When is_transfer_pricing_related=True, these fields enable the engine to apply the adjustment
    # to the relevant counterparty Tested Jurisdiction as well (symmetry).
    tp_counterparty_tested_jurisdiction_id: Optional[str] = Field(
        default=None,
        description=(
            "Optional counterparty Tested Jurisdiction for TP-related adjustments. "
            "For kind='income', if provided, the engine will apply a corresponding counterparty income adjustment "
            "(defaulting to the negative of the primary amount unless tp_counterparty_income_amount is provided). "
            "For kind='tax', if tp_counterparty_tax_amount is provided, it will be applied to this counterparty."
        ),
    )
    tp_apply_counterparty_income: bool = Field(
        default=True,
        description=(
            "For TP-related income adjustments: if True (default) and a counterparty Tested Jurisdiction is provided, "
            "apply a corresponding income adjustment to the counterparty (symmetry)."
        ),
    )
    tp_counterparty_income_amount: Optional[float] = Field(
        default=None,
        description=(
            "Optional explicit counterparty income adjustment amount (signed). If omitted and tp_apply_counterparty_income=True, "
            "the engine uses -amount for the counterparty."
        ),
    )
    tp_counterparty_tax_amount: Optional[float] = Field(
        default=None,
        description=(
            "Optional explicit counterparty tax adjustment amount (signed) to apply to tp_counterparty_tested_jurisdiction_id "
            "for TP-related tax adjustments."
        ),
    )

    # Optional TP special-case flags (audit / trace metadata).
    tp_accounted_at_cost: bool = Field(
        default=False,
        description="If True, indicates the relevant intra-group transfer is accounted at cost (OECD section 5.2 special case).",
    )
    tp_intangible_asset_related: bool = Field(
        default=False,
        description="If True, indicates the adjustment relates to an intangible asset transfer (OECD section 5.2 special case).",
    )
    tp_loss_disallowed_deemed_tp_adjustment: bool = Field(
        default=False,
        description="If True, indicates a deemed TP adjustment arises due to a disallowed loss on an intra-group transfer (OECD section 5.2).",
    )

    # Optional currency/scaling if different from the Tested Jurisdiction default
    currency: Optional[str] = Field(
        default=None,
        description=(
            "Optional currency code for this adjustment amount. If omitted, the tool assumes the amount is expressed "
            "in the Tested Jurisdiction's accounting_basis.currency (or reporting currency if none is provided)."
        ),
    )
    amount_scale: Optional[AmountScale] = Field(
        default=None,
        description="Optional scale for this adjustment amount. If omitted, uses the Tested Jurisdiction amount_scale.",
    )

    note: Optional[str] = None

    # Box 4.6(3) large downward tax adjustment handling
    attributable_to_income_change: bool = Field(
        default=False,
        description="For Box 4.6(3): True if the tax decrease is attributable to a decrease in Simplified Income.",
    )
    apply_large_refund_exclusion: bool = Field(
        default=False,
        description="If True and Box 4.6(3) conditions are met, the engine may exclude this net tax decrease from the accrual year.",
    )
    qualification_basis: Optional[QualifiedRefundCheckBasis] = Field(
        default=None,
        description="How the user demonstrates that Box 4.6(3)(a) or (b) conditions are met.",
    )
    prior_year_simplified_income: Optional[float] = Field(
        default=None,
        description="If qualification_basis='SIMPLIFIED_ETR', provide the transaction year's Simplified Income before this adjustment.",
    )
    prior_year_simplified_taxes: Optional[float] = Field(
        default=None,
        description="If qualification_basis='SIMPLIFIED_ETR', provide the transaction year's Simplified Taxes before this adjustment.",
    )
    prior_year_deferred_tax_effect: Optional[float] = Field(
        default=None,
        description="Optional deferred tax effect (signed) for the transaction year associated with this adjustment, for Box 4.6(3) testing.",
    )
    attestation_prior_year_etr_not_below_minimum: Optional[bool] = Field(
        default=None,
        description="If qualification_basis is not SIMPLIFIED_ETR, set True to attest the transaction year's (Simplified or GloBE) ETR after adjustment is not below the Minimum Rate.",
    )

    @model_validator(mode="after")
    def _validate_aye(self) -> "AfterYearEndAdjustmentV2":
        # Normalise currency
        if self.currency:
            self.currency = str(self.currency).upper().strip() or None

        
        # Transfer pricing validations (section 5.2)
        if self.is_transfer_pricing_related:
            # Box 4.6(3) qualified refund exclusion is not intended to apply to TP adjustments (handled under section 5.2).
            if self.apply_large_refund_exclusion:
                raise ValueError("Box 4.6(3) exclusion is not applicable to transfer pricing-related adjustments (section 5.2).")

        # Counterparty field consistency (used when is_transfer_pricing_related=True)
        if self.tp_counterparty_tested_jurisdiction_id is None:
            if self.tp_counterparty_income_amount is not None or self.tp_counterparty_tax_amount is not None:
                raise ValueError(
                    "TP counterparty amounts provided but tp_counterparty_tested_jurisdiction_id is missing."
                )
        if not self.tp_apply_counterparty_income and self.tp_counterparty_income_amount is not None:
            raise ValueError("tp_counterparty_income_amount is set but tp_apply_counterparty_income=false.")
# If user requests Box 4.6(3) exclusion, enforce minimal structured inputs
        if self.apply_large_refund_exclusion:
            if self.kind != "tax":
                raise ValueError("Box 4.6(3) exclusion can only be applied to kind='tax' adjustments.")
            if self.amount >= 0:
                raise ValueError("Box 4.6(3) exclusion requires a net tax decrease (amount < 0).")
            if self.attributable_to_income_change:
                raise ValueError("Box 4.6(3) exclusion is not available where the decrease is attributable to a decrease in Simplified Income.")
            if self.months_after_transaction_year_end is None or self.months_after_transaction_year_end <= 12:
                raise ValueError("Box 4.6(3) exclusion requires months_after_transaction_year_end > 12.")
            if not self.qualification_basis:
                raise ValueError("Box 4.6(3) exclusion requires qualification_basis.")
            if self.qualification_basis == "SIMPLIFIED_ETR":
                if self.prior_year_simplified_income is None or self.prior_year_simplified_taxes is None:
                    raise ValueError("qualification_basis='SIMPLIFIED_ETR' requires prior_year_simplified_income and prior_year_simplified_taxes.")
            else:
                if self.attestation_prior_year_etr_not_below_minimum is not True:
                    raise ValueError("qualification_basis requires attestation_prior_year_etr_not_below_minimum=True when not using SIMPLIFIED_ETR numeric test.")
        return self



# ---------------------------------------------------------------------------
# Transfer pricing adjustments register (OECD section 5.2) (v4 phase 4.5 add-on)
# ---------------------------------------------------------------------------

class TransferPricingAdjustmentV2(BaseModel):
    """Transfer pricing adjustment register entry (OECD section 5.2).

    This is a dedicated register *separate* from Box 4.6 after-year-end adjustments.

    A single register entry represents one linked event across a seller and buyer Tested Jurisdiction,
    and can include both:
      - income adjustments (P&L), and
      - tax adjustments (Covered Tax liability changes),
    as a single coherent record with counterparty symmetry and stronger validation.

    Timing (OECD section 5.2):
      - Default (Box 5.2(1)): include in accrual year.
      - Optional Five-Year election (Box 5.2(2)): where the adjustment accrues within 12 months after the end
        of the transaction year, include in the transaction year (group-wide election).

    Currency translation convention:
      - Income and tax amounts are treated as P&L-type items -> average FX when reporting currency translation applies.
    """

    adjustment_id: Optional[str] = Field(default=None, description="Optional unique id for the TP adjustment.")
    label: Optional[str] = Field(default=None, description="Optional label for display/audit.")

    seller_tested_jurisdiction_id: str = Field(..., description="Seller Tested Jurisdiction (primary side).")
    buyer_tested_jurisdiction_id: str = Field(..., description="Buyer Tested Jurisdiction (counterparty side).")

    transaction_year_fy_start: date = Field(..., description="Fiscal year start date of the transaction year.")
    accrual_year_fy_start: date = Field(..., description="Fiscal year start date of the accrual year (where booked).")

    months_after_transaction_year_end: Optional[int] = Field(
        default=None,
        ge=0,
        description="Months after the end of the transaction year when the adjustment accrued (for the 12-month timing election).",
    )
    accrued_within_12_months: Optional[bool] = Field(
        default=None,
        description="Optional override for whether the adjustment accrued within 12 months of transaction year end.",
    )

    # Seller-side amounts (signed)
    seller_income_adjustment: float = Field(
        default=0.0,
        description="Signed income adjustment for the seller Tested Jurisdiction (P&L).",
    )
    seller_tax_adjustment: float = Field(
        default=0.0,
        description="Signed tax adjustment for the seller Tested Jurisdiction (Covered Tax liability change).",
    )

    # Buyer-side amounts (optional; defaulting rules apply)
    buyer_income_adjustment: Optional[float] = Field(
        default=None,
        description=(
            "Optional signed income adjustment for the buyer Tested Jurisdiction. "
            "If omitted, the tool defaults this to the negative of the seller_income_adjustment (symmetry), "
            "unless a special-case flag requires explicit counterparty treatment."
        ),
    )
    buyer_tax_adjustment: Optional[float] = Field(
        default=None,
        description="Optional signed tax adjustment for the buyer Tested Jurisdiction (if applicable). If omitted, defaults to 0.0.",
    )

    # Special-case flags (audit + validation)
    tp_accounted_at_cost: bool = Field(
        default=False,
        description="If True, indicates the intra-group transfer is accounted at cost (OECD section 5.2 special case).",
    )
    tp_intangible_asset_related: bool = Field(
        default=False,
        description="If True, indicates the adjustment relates to an intangible asset transfer (OECD section 5.2 special case).",
    )
    tp_loss_disallowed_deemed_tp_adjustment: bool = Field(
        default=False,
        description="If True, indicates a deemed TP adjustment arises due to a disallowed loss on an intra-group transfer (OECD section 5.2).",
    )

    # Optional currency/scaling if different from the seller Tested Jurisdiction default
    currency: Optional[str] = Field(
        default=None,
        description=(
            "Optional currency code for this TP adjustment amounts. If omitted, the tool assumes the amounts are expressed "
            "in the seller Tested Jurisdiction accounting_basis.currency (or reporting currency if none is provided)."
        ),
    )
    amount_scale: Optional[AmountScale] = Field(
        default=None,
        description="Optional scale for this adjustment. If omitted, uses the seller Tested Jurisdiction amount_scale.",
    )

    note: Optional[str] = None

    @model_validator(mode="after")
    def _validate_tp(self) -> "TransferPricingAdjustmentV2":
        # Normalise currency
        if self.currency:
            self.currency = str(self.currency).upper().strip() or None

        # Basic sanity: must have a non-zero effect
        total = abs(float(self.seller_income_adjustment or 0.0)) + abs(float(self.seller_tax_adjustment or 0.0))
        total += abs(float(self.buyer_income_adjustment or 0.0)) + abs(float(self.buyer_tax_adjustment or 0.0))
        if total == 0.0:
            raise ValueError("TransferPricingAdjustmentV2: at least one of the income/tax adjustments must be non-zero.")

        # Stronger validations for special cases: require explicit counterparty income treatment
        if (self.tp_accounted_at_cost or self.tp_intangible_asset_related or self.tp_loss_disallowed_deemed_tp_adjustment):
            if self.buyer_income_adjustment is None:
                raise ValueError(
                    "TransferPricingAdjustmentV2: buyer_income_adjustment is required when any TP special-case flag is set "
                    "(tp_accounted_at_cost / tp_intangible_asset_related / tp_loss_disallowed_deemed_tp_adjustment). "
                    "Provide explicit counterparty income treatment rather than relying on default symmetry."
                )

        return self



# ---------------------------------------------------------------------------
# Investment entity owner addbacks (v2)
# ---------------------------------------------------------------------------

OwnerAddbackKind = Literal["tax", "income"]
InvestmentEntityArticle = Literal["7.5", "7.6"]


class InvestmentEntityOwnerAddbackV2(BaseModel):
    """Structured owner addback line for Investment Entity rules (Articles 7.5 and 7.6).

    The OECD investment entity rules can require adding certain owner-level taxes (and in some cases
    related income) back into the Tested Jurisdiction's Simplified Taxes/Simplified Income.

    This tool models the addback as a signed amount applied to Simplified Taxes or Simplified Income.
    """

    addback_id: Optional[str] = None
    label: str = Field(..., description="Short label for the addback.")
    article: InvestmentEntityArticle = Field(..., description="OECD rule reference: '7.5' or '7.6'.")
    kind: OwnerAddbackKind = Field(..., description="Whether this addback adjusts Simplified Taxes or Simplified Income.")
    amount: float = Field(..., description="Signed amount (+/-) to apply.")

    owner_name: Optional[str] = None
    owner_jurisdiction_code: Optional[str] = None
    note: Optional[str] = None


# ---------------------------------------------------------------------------
# Tested Jurisdiction wrapper
# ---------------------------------------------------------------------------

AggregationMethod = Literal["JURISDICTION_FACTS", "ENTITY_ROLLUP", "MIXED"]


class TestedJurisdictionCompositionV2(BaseModel):
    aggregation_method: AggregationMethod = Field(
        default="JURISDICTION_FACTS",
        description="How inputs are provided for the Tested Jurisdiction.",
    )


class EligibilityInputsV2(BaseModel):
    ineligible_stateless: bool = False
    ineligible_investment_entity: bool = False
    ineligible_article7_3_outstanding_recapture: bool = False

    stateless_exception_section_6_2_applies: bool = False
    investment_entity_tax_transparency_election_applies: bool = False

    no_topup_tax_in_prior_24_months: bool = True
    reentry_no_topup_tax_in_prior_24_months: Optional[bool] = None

    integrity_rules_satisfied: bool = True


class DeemedZeroRulesV2(BaseModel):
    apply_deemed_zero: bool = Field(
        default=False,
        description=(
            "If True, treat Simplified Income and Simplified Taxes as zero for the Tested Jurisdiction "
            "(deemed-zero rule). This is intended for certain Tax-Neutral Entity scenarios."
        ),
    )
    rationale: Optional[str] = None


class TestedJurisdictionInputV2(BaseModel):
    tested_jurisdiction_id: str = Field(..., description="Unique identifier for this Tested Jurisdiction.")
    jurisdiction_code: Optional[str] = Field(
        default=None, description="Country/territory code (e.g. 'GB', 'DE'). Multiple Tested Jurisdictions may share a code."
    )
    label: Optional[str] = Field(default=None, description="Optional display label.")
    tested_jurisdiction_type: Optional[str] = Field(
        default=None,
        description="Optional classification (e.g., 'standard', 'stateless', 'investment_entity'). Informational.",
    )

    accounting_basis: AccountingBasisV2 = Field(
        default_factory=AccountingBasisV2,
        description=(
            "Accounting basis and currency metadata. If request.group_profile.reporting_currency is provided "
            "and accounting_basis.currency differs, inputs will be translated using request.fx_rates." 
        ),
    )

    composition: TestedJurisdictionCompositionV2 = Field(default_factory=TestedJurisdictionCompositionV2)

    # Inputs (either provide facts or entities depending on composition method)
    facts: Optional[JurisdictionFactsV2] = None
    entities: List[EntityFactsV2] = Field(default_factory=list)

    # Elections and carryforwards
    elections: List[ElectionInstanceV2] = Field(default_factory=list)
    owner_addbacks: List[InvestmentEntityOwnerAddbackV2] = Field(
        default_factory=list,
        description="Structured owner addbacks (Articles 7.5/7.6) applied to this Tested Jurisdiction.",
    )
    carryforwards_opening: List[CarryforwardBalanceV2] = Field(default_factory=list)

    # Transition Year (Box 4.5)
    transition_year: Optional[TransitionYearV2] = Field(
        default=None,
        description=(
            "Optional Transition Year configuration. If provided, the engine applies Transition Year rules (Box 4.5) "
            "including Articles 9.1.1-9.1.3 scaffolding."
        ),
    )

    transition_year_state_opening: Optional[TransitionYearStateV2] = Field(
        default=None,
        description=(
            "Optional Transition Year deferred-tax state carried forward from a prior computation. "
            "If provided, the engine uses it to determine the Transition Year start date (when transition_year is omitted) "
            "and to re-apply Article 9.1.2 disallowed opening DTA adjustments in the Transition Year without re-entering opening balances."
        ),
    )

    # Eligibility & deemed-zero
    eligibility_inputs: EligibilityInputsV2 = Field(default_factory=EligibilityInputsV2)
    deemed_zero_rules: DeemedZeroRulesV2 = Field(default_factory=DeemedZeroRulesV2)

    @model_validator(mode="after")
    def _validate_composition(self) -> "TestedJurisdictionInputV2":
        m = self.composition.aggregation_method
        if m == "JURISDICTION_FACTS":
            if self.facts is None:
                raise ValueError(f"{self.tested_jurisdiction_id}: aggregation_method='JURISDICTION_FACTS' requires facts.")
        elif m == "ENTITY_ROLLUP":
            if not self.entities:
                raise ValueError(f"{self.tested_jurisdiction_id}: aggregation_method='ENTITY_ROLLUP' requires entities[].")
        elif m == "MIXED":
            if self.facts is None and not self.entities:
                raise ValueError(f"{self.tested_jurisdiction_id}: aggregation_method='MIXED' requires facts and/or entities[].")
        return self


# ---------------------------------------------------------------------------
# Request / Response (v2)
# ---------------------------------------------------------------------------

class ApplicabilityOptionsV2(BaseModel):
    apply_optional_2025_start_rule: bool = False
    early_start_qdmtt_safe_harbour_applies: bool = False
    early_start_only_one_jurisdiction_has_taxing_rights: bool = False
    early_start_all_taxing_rights_jurisdictions_allow: bool = False


class FiscalYearV2(BaseModel):
    start_date: date
    end_date: Optional[date] = None


class CalculationRequestV2(BaseModel):
    schema_version: Literal["2.0", "2.1", "2.2"] = "2.0"
    ruleset_version: str = Field(default="OECD_SBS_2026_01", description="OECD Side-by-Side Package (Jan 2026).")

    fiscal_year: FiscalYearV2
    minimum_rate: float = Field(default=0.15, ge=0.0, le=1.0)

    group_profile: Optional[GroupProfileV2] = Field(
        default=None,
        description="Optional group profile metadata (reporting currency and accounting standard).",
    )
    fx_rates: List[FxRateV2] = Field(
        default_factory=list,
        description=(
            "Optional FX rates used to translate Tested Jurisdiction inputs into the reporting currency. "
            "If group_profile.reporting_currency is provided and a Tested Jurisdiction declares a different currency, "
            "a matching FX rate must be provided."
        ),
    )

    applicability: ApplicabilityOptionsV2 = Field(default_factory=ApplicabilityOptionsV2)


    group_elections: List[ElectionInstanceV2] = Field(
        default_factory=list,
        description=(
            "Optional group-wide election register events. Use this for elections that apply across all Tested Jurisdictions "
            "(e.g., Box 4.6 after-year-end adjustments timing election)."
        ),
    )

    after_year_end_adjustments: List[AfterYearEndAdjustmentV2] = Field(
        default_factory=list,
        description="Optional after-year-end tax/income adjustments under OECD Box 4.6.",
    )

    transfer_pricing_adjustments: List[TransferPricingAdjustmentV2] = Field(
        default_factory=list,
        description="Optional transfer pricing adjustment register entries under OECD section 5.2 (separate from Box 4.6).",
    )

    cross_border_tax_items: List[CrossBorderTaxItemV2] = Field(
        default_factory=list,
        description="Optional cross-border tax items that require exclusion/allocation between Tested Jurisdictions.",
    )

    tested_jurisdictions: List[TestedJurisdictionInputV2] = Field(default_factory=list)

    @model_validator(mode="after")
    def _validate(self) -> "CalculationRequestV2":
        if not self.tested_jurisdictions:
            raise ValueError("tested_jurisdictions[] must contain at least one Tested Jurisdiction.")

        # Normalise reporting currency to uppercase (if provided)
        if self.group_profile and self.group_profile.reporting_currency:
            self.group_profile.reporting_currency = str(self.group_profile.reporting_currency).upper().strip() or None

        # Normalise FX currencies and validate duplicates
        seen_fx: set[tuple[str, Optional[date]]] = set()
        for r in (self.fx_rates or []):
            r.currency = str(r.currency).upper().strip()
            key = (r.currency, r.fiscal_year_start)
            if key in seen_fx:
                raise ValueError(f"Duplicate FX rate entry for currency '{r.currency}' and fiscal_year_start={r.fiscal_year_start}.")
            seen_fx.add(key)

        # LFAS / QDMTT group-wide gating (v4 module 3)
        # OECD requires that if an MNE uses a permitted CFS GAAP election in one QDMTT LFAS jurisdiction,
        # it should apply consistently across all QDMTT LFAS jurisdictions that provide the same election.
        lfas_allow_election: list[TestedJurisdictionInputV2] = []
        for tj in self.tested_jurisdictions:
            b = tj.accounting_basis
            if bool(b.lfas_qdmtt_applies) and bool(b.lfas_requires_local_gaap) and bool(b.jurisdiction_allows_cfs_gaap_for_qdmtt):
                lfas_allow_election.append(tj)

        cfs_used = any(tj.accounting_basis.basis_source == "CFS" for tj in lfas_allow_election)
        if cfs_used:
            # If CFS basis is used in any LFAS jurisdiction where an election is available, require all such jurisdictions to use it.
            offenders = [tj.tested_jurisdiction_id for tj in lfas_allow_election if tj.accounting_basis.basis_source != "CFS"]
            if offenders:
                raise ValueError(
                    "LFAS consistency: basis_source='CFS' is used in at least one QDMTT LFAS jurisdiction where an election is available. "
                    "OECD consistency requires applying the election to all such jurisdictions. "
                    f"Set basis_source='CFS' for: {', '.join(offenders)} (or use LOCAL_GAAP for all)."
                )

        # Prevent accidental double counting: if users supply the explicit TP register,
        # do not allow TP rows inside after_year_end_adjustments at the same time.
        if self.transfer_pricing_adjustments:
            tp_in_aye = any(bool(getattr(a, "is_transfer_pricing_related", False)) for a in (self.after_year_end_adjustments or []))
            if tp_in_aye:
                raise ValueError(
                    "Transfer pricing inputs: transfer_pricing_adjustments[] is provided, but after_year_end_adjustments[] also contains "
                    "transfer pricing-related rows (is_transfer_pricing_related=true). "
                    "Use the explicit transfer_pricing_adjustments register (section 5.2) instead of Box 4.6 TP rows to avoid double counting."
                )

        return self


class TestedJurisdictionResultV2(BaseModel):
    tested_jurisdiction_id: str
    jurisdiction_code: Optional[str] = None
    label: Optional[str] = None

    transition_year_fy_start: Optional[date] = None
    is_transition_year: Optional[bool] = None

    transition_year_state_closing: Optional[TransitionYearStateV2] = Field(
        default=None,
        description="State payload to carry Transition Year deferred-tax register forward to later fiscal years. Store and feed back as transition_year_state_opening.",
    )

    eligible: bool
    ineligibility_reasons: List[str] = Field(default_factory=list)

    simplified_income: float
    simplified_taxes: float
    simplified_etr: Optional[float] = None
    simplified_loss: float = 0.0

    safe_harbour_applies: bool
    safe_harbour_reason: str

    # Negative tax adjustment proxy (for transparency)
    simplified_adjustment_for_negative_taxes: float = 0.0

    # Elections and trace
    effective_elections: List[ElectionInstanceV2] = Field(default_factory=list)
    election_records: List[ElectionRecord] = Field(default_factory=list)
    trace: List[TraceLine] = Field(default_factory=list)

    # Carryforwards
    carryforwards_opening: List[CarryforwardBalanceV2] = Field(default_factory=list)
    carryforward_movements: List[CarryforwardMovementV2] = Field(default_factory=list)
    carryforwards_closing: List[CarryforwardBalanceV2] = Field(default_factory=list)


class CalculationResponseV2(BaseModel):
    schema_version: Literal["2.0", "2.1", "2.2"] = "2.0"
    ruleset_version: str

    fiscal_year: FiscalYearV2
    minimum_rate: float

    reporting_currency: Optional[str] = Field(
        default=None,
        description="Echo of group_profile.reporting_currency if provided; results are expressed in this currency when FX translation is applied.",
    )

    results: List[TestedJurisdictionResultV2]


# ---------------------------------------------------------------------------
# Scenario helpers (v4 add-on): advance-year request builder
# ---------------------------------------------------------------------------


class ScenarioAdvanceYearOptionsV2(BaseModel):
    """Options controlling how the next-year scenario request is generated.

    This API is intentionally stateless. The client supplies the last request and last response.
    The server returns a new request payload for the next fiscal year.
    """

    # Fiscal-year control
    advance_to_fiscal_year_start: Optional[date] = Field(
        default=None,
        description="Optional override for the next fiscal year start date. If omitted, adds 1 year to last_request.fiscal_year.start_date.",
    )

    # Roll-forward controls
    carry_forward_transition_year_state: bool = Field(
        default=True,
        description="If true (default), sets transition_year_state_opening to last_response transition_year_state_closing for each Tested Jurisdiction.",
    )
    carry_forward_carryforwards: bool = Field(
        default=True,
        description="If true (default), sets carryforwards_opening to last_response carryforwards_closing for each Tested Jurisdiction.",
    )

    # Inputs reset controls
    clear_transition_year_inputs: bool = Field(
        default=True,
        description=(
            "If true (default), clears transition_year.opening_deferred_tax_items and transition_year.article_9_1_3_transfers in the next-year request. "
            "Transition Year state is carried separately via transition_year_state_opening."
        ),
    )


    clear_after_year_end_adjustments: bool = Field(
        default=True,
        description="If true (default), clears request.after_year_end_adjustments in the next-year request (year-specific input).",
    )

    clear_transfer_pricing_adjustments: bool = Field(
        default=True,
        description="If true (default), clears request.transfer_pricing_adjustments in the next-year request (year-specific input).",
    )

    # FX placeholders
    include_fx_placeholders: bool = Field(
        default=True,
        description=(
            "If true (default) and reporting currency translation is enabled, ensures the next-year request contains year-specific FX rate rows "
            "for currencies used by Tested Jurisdictions and cross-border items. If a next-year rate is missing, the tool copies the last-year rate "
            "when available or inserts a placeholder rate (1.0) with a warning."
        ),
    )


class ScenarioAdvanceYearRequestV2(BaseModel):
    last_request: CalculationRequestV2
    last_response: CalculationResponseV2
    options: ScenarioAdvanceYearOptionsV2 = Field(default_factory=ScenarioAdvanceYearOptionsV2)


class ScenarioAdvanceYearResponseV2(BaseModel):
    next_request: CalculationRequestV2
    warnings: List[str] = Field(default_factory=list)
