from __future__ import annotations

from datetime import date
from typing import List, Optional, Literal

from pydantic import BaseModel, Field, model_validator


class AdjustmentLine(BaseModel):
    """Generic adjustment line (+ increases, - decreases).

    Use for bespoke adjustments not explicitly modelled in the prototype (e.g. bespoke local rules,
    custom elections, edge cases).
    """

    label: str
    amount: float = Field(..., description="Signed amount (+/-).")
    category: Optional[str] = None
    note: Optional[str] = None


class ElectionRecord(BaseModel):
    """Record of an election/adjustment choice.

    The OECD Side-by-Side package contains elections that may:
      - map to a specific modelling field (e.g. a 5-year election flag), or
      - be documented as an election choice without changing any current-year
        amounts in the Simplified ETR Safe Harbour calculation.

    This model lets the tool preserve an *audit trail* of election choices,
    including elections that are "metadata-only" in this prototype.
    """

    scope: Literal["income", "tax", "eligibility", "metadata"]
    election_code: str
    label: Optional[str] = None
    bool_value: Optional[bool] = None
    amount: Optional[float] = None
    note: Optional[str] = None


class JurisdictionInput(BaseModel):
    jurisdiction_code: str = Field(..., description="ISO-like code, e.g. 'US', 'GB', 'DE'.")
    # Starting point for Simplified Income
    jpbt: float = Field(..., description="Jurisdictional Profit (or Loss) before Income Tax (JPBT).")

    # -----------------------------
    # JPBT scaffolding (OECD Box 3.1 helpers)
    # -----------------------------
    jpbt_includes_other_covered_taxes_elected: bool = Field(
        default=False,
        description=(
            "Set to True if the JPBT you entered already includes the Box 3.1 add-back for any amount entered "
            "under election_include_other_covered_taxes. If False (default), the engine will add "
            "election_include_other_covered_taxes to JPBT for symmetry when that election amount is non-zero."
        ),
    )
    jpbt_consolidation_eliminations_reversal: float = Field(
        default=0.0,
        description=(
            "Optional Box 3.1 helper: net amount to reverse consolidation eliminations for intragroup transactions "
            "so intragroup profits/losses are recognised in JPBT (signed)."
        ),
    )
    jpbt_purchase_price_allocation_reversal: float = Field(
        default=0.0,
        description=(
            "Optional Box 3.1 helper: net amount to reverse Purchase Price Allocation (PPA) accounting income/expense "
            "included in aggregate FANIL, where required (signed)."
        ),
    )


    # -----------------------------
    # Simplified Income
    # -----------------------------
    # Required Basic Adjustments (OECD Box 3.2)
    excluded_dividends: float = 0.0
    excluded_equity_gains_losses: float = 0.0
    illegal_payments: float = 0.0
    fines_penalties_ge_250k: float = 0.0

    # Industry Adjustments (OECD Box 3.3)
    # 3.3.1 Financial Services Industry Adjustments
    insurance_company_income: float = Field(
        default=0.0,
        description=(
            "Insurance company income described in Article 3.2.9 that is included in JPBT. "
            "By default it is excluded from Simplified Income (unless annual election not to apply exclusion)."
        ),
    )
    fs_annual_election_not_to_exclude_insurance_income: bool = False
    at1_rt1_payments_receipts_adjustment: float = Field(
        default=0.0,
        description=(
            "Net adjustment for payments/receipts in respect of Additional Tier One (AT1) and Restricted "
            "Tier One (RT1) Capital pursuant to Article 3.2.10. Can be positive or negative."
        ),
    )
    at1_rt1_corresponding_tax_in_equity: float = Field(
        default=0.0,
        description=(
            "Any corresponding tax accounted in equity/OCI that must be included in Simplified Taxes "
            "when AT1/RT1 items are included in Simplified Income (Article 3.2.10 symmetry rule)."
        ),
    )

    # 3.3.2 Shipping Industry Adjustments
    international_shipping_income: float = 0.0
    qualified_ancillary_international_shipping_income: float = 0.0
    shipping_five_year_election_not_to_exclude: bool = False
    taxes_on_excluded_shipping_income: float = Field(
        default=0.0,
        description=(
            "Covered Taxes attributable to International Shipping Income / Qualified Ancillary International "
            "Shipping Income that are excluded from Simplified Income. Enter as a positive number; the tool "
            "will subtract it from Simplified Taxes when the Shipping Income Exclusion applies."
        ),
    )

    # Conditional Adjustments (OECD Box 3.4)
    # 3.4.1 Equity-reported items (Included Revaluation Method Gains/Losses; Prior Period Errors/Changes in accounting principle)
    equity_reported_items_amount: float = Field(
        default=0.0,
        description=(
            "Net equity-reported items (OCI/equity) that would be included in GloBE income under "
            "Article 3.2.1(d)/(h). If positive (income), tool may add to JPBT unless waiver conditions are met. "
            "If negative (expense/loss), no adjustment is required under the safe harbour."
        ),
    )
    equity_reported_items_subject_to_tax_at_or_above_minimum_rate: bool = Field(
        default=False,
        description="For waiver: income subject to tax at a rate >= Minimum Rate in the jurisdiction.",
    )
    equity_reported_items_related_taxes_accounted_in_equity_or_oci: bool = Field(
        default=False,
        description="For waiver: related income taxes are accounted in equity/OCI (not in P&L).",
    )
    equity_reported_items_related_tax_is_deferred_tax_liability: bool = Field(
        default=False,
        description="If related tax is a deferred tax liability, waiver requires it to be a Recapture Exception Accrual.",
    )
    equity_reported_items_related_dtl_is_recapture_exception_accrual: bool = Field(
        default=False,
        description="If related tax is a DTL, indicate whether it is a Recapture Exception Accrual (REA).",
    )

    # 3.4.2 M&A Simplification and Article 6.3.4 election (simplified inputs)
    mna_simplification_applied: bool = Field(
        default=False,
        description=(
            "If True, apply the M&A Simplification (OECD Box 3.4.2) for this Tested Jurisdiction. "
            "Provide related amounts below where relevant."
        ),
    )
    mna_goodwill_impairment_or_amortisation_addback: float = Field(
        default=0.0,
        description=(
            "Add-back to JPBT for goodwill impairment/amortisation that does NOT have a corresponding DTL "
            "(or has DTL recorded at a rate below Minimum Rate) under the M&A Simplification."
        ),
    )
    mna_article_6_3_4_election_amount: float = Field(
        default=0.0,
        description=(
            "Amount of GloBE-to-book Difference included in Simplified Income for the year under an "
            "Article 6.3.4 election (either full amount or the pro-rata 5-year portion for the year). "
            "Signed amount (+/-)."
        ),
    )

    # Optional Adjustments (OECD Box 3.5.2) – required unless 5-year election not to apply
    asymmetric_fx_gain_loss: float = Field(
        default=0.0,
        description="Asymmetric Foreign Exchange Currency Gain/Loss (AFXGL) adjustment (signed).",
    )
    afxgl_five_year_election_not_to_apply: bool = Field(
        default=False,
        description="Five-year election not to apply the AFXGL adjustment.",
    )
    accrued_pension_expense_adjustment: float = Field(
        default=0.0,
        description="Accrued pension expense adjustment under Article 3.2.1(i) (signed).",
    )
    pension_five_year_election_not_to_apply: bool = Field(
        default=False,
        description="Five-year election not to apply the accrued pension expense adjustment.",
    )

    # Optional / additional income adjustments (placeholder for other Industry/Conditional/Optional adjustments)
    other_income_adjustments: List[AdjustmentLine] = Field(default_factory=list)

    # Election records (audit trail). This does not automatically change calculations unless
    # the election also maps to a dedicated field or has a net income/tax impact.
    election_records: List[ElectionRecord] = Field(default_factory=list)

    # -----------------------------
    # Simplified Taxes
    # -----------------------------
    # Starting point for Simplified Taxes: Jurisdictional Income Tax Expense (JITE)
    current_tax_expense: float = 0.0
    deferred_tax_expense: float = 0.0
    consolidated_level_deferred_tax: float = 0.0

    # Policy-based adjustments and other tax adjustments (OECD Box 4)
    taxes_not_covered: float = 0.0
    tax_refunds_and_credits_adjustment: float = 0.0
    taxes_on_excluded_income: float = 0.0
    uncertain_tax_positions_adjustment: float = 0.0
    current_tax_not_paid_within_3y: float = 0.0

    # Deferred tax adjustments
    accounted_tax_rate: Optional[float] = Field(
        default=None,
        description=(
            "Income tax rate used to recognise deferred taxes in financial accounts (before valuation allowance). "
            "Used to recast deferred tax expense at the Minimum Rate when accounted rate > minimum."
        ),
    )
    valuation_allowance_impact: float = 0.0
    tax_rate_change_impact: float = 0.0
    deferred_tax_from_tax_credits: float = 0.0
    non_rea_dtl_deferred_tax_expense: float = 0.0
    non_rea_dtl_exception_applies: bool = False

    # M&A simplification – tax-side exclusions (simplified inputs)
    mna_deferred_tax_accruals_to_exclude: float = Field(
        default=0.0,
        description=(
            "When M&A Simplification applies: deferred tax expense/benefit attributable to the accrual of "
            "DTAs/DTLs arising from the M&A Transaction that should be excluded from Simplified Taxes. "
            "Enter as the signed amount INCLUDED in deferred tax expense; tool will remove it."
        ),
    )
    mna_goodwill_related_dtl_reversal_to_exclude: float = Field(
        default=0.0,
        description=(
            "When M&A Simplification applies: deferred tax expense/benefit attributable to reversal of a "
            "goodwill-related DTL (if any) that should be excluded from Simplified Taxes. "
            "Enter as the signed amount INCLUDED in deferred tax expense; tool will remove it."
        ),
    )

    other_tax_adjustments: List[AdjustmentLine] = Field(default_factory=list)

    # Optional elections (amounts are entered directly for MVP; aggregated)
    election_include_other_covered_taxes: float = 0.0
    election_include_equity_reported_taxes: float = 0.0
    election_include_qrtc_mttc_credits_in_income: float = 0.0
    election_include_qrtc_mttc_credits_in_taxes: float = 0.0

    # -----------------------------
    # Eligibility / integrity inputs (prototype)
    # -----------------------------
    # Eligibility restriction flags (OECD Box 7.1)
    ineligible_stateless: bool = False
    ineligible_investment_entity: bool = False
    ineligible_article7_3_outstanding_recapture: bool = False

    # Exceptions to ineligibility (OECD Section 6 / Box 7.1)
    stateless_exception_section_6_2_applies: bool = Field(
        default=False,
        description=(
            "If True, the Tested Jurisdiction relates to a Stateless Constituent Entity but is eligible "
            "under the tax transparent entity rule in Section 6.2 (Box 6.2 / Box 7.1(a) exception)."
        ),
    )
    investment_entity_tax_transparency_election_applies: bool = Field(
        default=False,
        description=(
            "If True, the Tested Jurisdiction relates to an Investment Entity but is eligible under "
            "the Investment Entity Tax Transparency Election (Section 6.3 / Article 7.5; Box 6.3 / Box 7.1(b) exception)."
        ),
    )

    # Entry / re-entry criteria (OECD Box 7.2) – simplified input for MVP
    no_topup_tax_in_prior_24_months: bool = True
    reentry_no_topup_tax_in_prior_24_months: Optional[bool] = None

    # Integrity rules (OECD Box 7.3) – user attestation for MVP
    integrity_rules_satisfied: bool = True


class EntityInput(BaseModel):
    """Entity-level inputs that can be rolled up to a Tested Jurisdiction.

    In roll-up mode, numeric fields are aggregated by jurisdiction_code.
    Jurisdiction-level elections/eligibility flags are provided separately via JurisdictionInput rows.
    """

    entity_id: Optional[str] = None
    entity_name: str
    jurisdiction_code: str = Field(..., description="Jurisdiction code for the entity (used for roll-up).")

    # Starting point for Simplified Income
    jpbt: float = Field(..., description="Entity-level profit (or loss) before income tax (PBT analogue).")

    # Basic Adjustments (aggregated to jurisdiction)
    excluded_dividends: float = 0.0
    excluded_equity_gains_losses: float = 0.0
    illegal_payments: float = 0.0
    fines_penalties_ge_250k: float = 0.0

    # Industry amounts (aggregated; elections applied at jurisdiction level)
    insurance_company_income: float = 0.0
    at1_rt1_payments_receipts_adjustment: float = 0.0
    at1_rt1_corresponding_tax_in_equity: float = 0.0
    international_shipping_income: float = 0.0
    qualified_ancillary_international_shipping_income: float = 0.0
    taxes_on_excluded_shipping_income: float = 0.0

    # Conditional / optional income adjustment amounts (aggregated)
    equity_reported_items_amount: float = 0.0
    mna_goodwill_impairment_or_amortisation_addback: float = 0.0
    mna_article_6_3_4_election_amount: float = 0.0
    asymmetric_fx_gain_loss: float = 0.0
    accrued_pension_expense_adjustment: float = 0.0

    # Optional / additional income adjustments (entity-level; not used by Excel template by default)
    other_income_adjustments: List[AdjustmentLine] = Field(default_factory=list)

    # Taxes
    current_tax_expense: float = 0.0
    deferred_tax_expense: float = 0.0
    consolidated_level_deferred_tax: float = 0.0

    taxes_not_covered: float = 0.0
    tax_refunds_and_credits_adjustment: float = 0.0
    taxes_on_excluded_income: float = 0.0
    uncertain_tax_positions_adjustment: float = 0.0
    current_tax_not_paid_within_3y: float = 0.0

    accounted_tax_rate: Optional[float] = None
    valuation_allowance_impact: float = 0.0
    tax_rate_change_impact: float = 0.0
    deferred_tax_from_tax_credits: float = 0.0
    non_rea_dtl_deferred_tax_expense: float = 0.0
    non_rea_dtl_exception_applies: bool = False

    # M&A simplification – tax-side exclusions (entity-level amounts; flags at jurisdiction meta level)
    mna_deferred_tax_accruals_to_exclude: float = 0.0
    mna_goodwill_related_dtl_reversal_to_exclude: float = 0.0

    other_tax_adjustments: List[AdjustmentLine] = Field(default_factory=list)

    # Elections (amounts)
    election_include_other_covered_taxes: float = 0.0
    election_include_equity_reported_taxes: float = 0.0
    election_include_qrtc_mttc_credits_in_income: float = 0.0
    election_include_qrtc_mttc_credits_in_taxes: float = 0.0


class CalculationRequest(BaseModel):
    fiscal_year_start_date: date
    minimum_rate: float = Field(default=0.15, ge=0.0, le=1.0)
    input_mode: Literal["jurisdiction", "entity_rollup"] = Field(
        default="jurisdiction",
        description="Whether inputs are provided at jurisdiction level or rolled up from entities.",
    )
    apply_optional_2025_start_rule: bool = False
    # Optional conditions for early start (if FY begins on/after 31 Dec 2025)
    early_start_qdmtt_safe_harbour_applies: bool = False
    early_start_only_one_jurisdiction_has_taxing_rights: bool = False
    early_start_all_taxing_rights_jurisdictions_allow: bool = False

    jurisdictions: List[JurisdictionInput] = Field(default_factory=list)
    entities: List[EntityInput] = Field(default_factory=list)

    @model_validator(mode="after")
    def _validate_inputs(self) -> "CalculationRequest":
        if self.input_mode == "jurisdiction":
            if not self.jurisdictions:
                raise ValueError("input_mode='jurisdiction' requires at least one jurisdictions[] row.")
        elif self.input_mode == "entity_rollup":
            if not self.entities:
                raise ValueError("input_mode='entity_rollup' requires at least one entities[] row.")
        return self


class TraceLine(BaseModel):
    section: Literal["income", "tax", "eligibility"]
    step: str
    amount: float
    running_total: Optional[float] = None
    note: Optional[str] = None


class JurisdictionResult(BaseModel):
    jurisdiction_code: str
    eligible: bool
    ineligibility_reasons: List[str] = Field(default_factory=list)

    simplified_income: float
    simplified_taxes: float
    simplified_etr: Optional[float] = None

    safe_harbour_applies: bool
    safe_harbour_reason: str

    simplified_loss: float = 0.0
    simplified_adjustment_for_negative_taxes: float = 0.0

    trace: List[TraceLine] = Field(default_factory=list)

    # Echo back election records for transparency/audit (non-breaking additive field).
    election_records: List[ElectionRecord] = Field(default_factory=list)


class CalculationResponse(BaseModel):
    fiscal_year_start_date: date
    minimum_rate: float
    results: List[JurisdictionResult]
