from __future__ import annotations

import re
from datetime import date, datetime
from hashlib import sha1
from io import BytesIO
from typing import Iterable, List, Optional, Set, Tuple

import requests
import xml.etree.ElementTree as ET

from openpyxl import load_workbook

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import Session

from app.api.schemas import (
    ImportGirXmlRequest,
    ImportGirXmlResponse,
    ImportGirXmlStats,
    ImportGirXmlWarning,
    ImportGirXmlValidateRequest,
    ImportGirXmlValidateResponse,
    ImportGirToolkitXlsxRequest,
    ImportGirToolkitXlsxResponse,
    ImportGirToolkitXlsxValidateRequest,
    ImportGirToolkitXlsxValidateResponse,
    ValidationRunCreate,
    ValidationRunRead,
)
from app.db import models
from app.db.session import get_db
from app.services.utils import try_parse_date, try_parse_decimal
from app.core.settings import settings
from app.services.config_loader import load_config
from app.services.submission_history import record_submission_from_import

# Reuse the existing validation run implementation for consistent persistence + outputs.
from app.api.routes_validation import create_validation_run as _create_validation_run


router = APIRouter(prefix="/filings/{filing_id}/imports", tags=["imports"])


def _local(tag: str) -> str:
    """Return localname for XML tags with namespaces."""
    if "}" in tag:
        return tag.split("}", 1)[1]
    return tag


def _child(parent: ET.Element, name: str) -> Optional[ET.Element]:
    for ch in list(parent):
        if isinstance(ch.tag, str) and _local(ch.tag) == name:
            return ch
    return None


def _child_text(parent: ET.Element, name: str) -> Optional[str]:
    ch = _child(parent, name)
    if ch is None:
        return None
    t = (ch.text or "").strip()
    return t or None


def _find_text(root: ET.Element, parts: List[str]) -> Optional[str]:
    cur = root
    for p in parts:
        nxt = _child(cur, p)
        if nxt is None:
            return None
        cur = nxt
    t = (cur.text or "").strip()
    return t or None


def _safe_code(seed: Optional[str], prefix: str, max_len: int = 64) -> str:
    base = (seed or "").strip()
    cleaned = re.sub(r"[^A-Za-z0-9]+", "", base).upper()
    if not cleaned:
        return f"{prefix}01"
    if len(cleaned) <= max_len:
        return cleaned
    h = sha1(base.encode("utf-8")).hexdigest()[:12].upper()
    return (prefix + h)[:max_len]


def _chunked(it: List[dict], n: int) -> Iterable[List[dict]]:
    for i in range(0, len(it), n):
        yield it[i : i + n]


def _ensure_filing(db: Session, filing_id: str) -> models.Filing:
    filing = db.get(models.Filing, filing_id)
    if filing is None:
        raise HTTPException(status_code=404, detail="Filing not found")
    return filing


@router.post("/gir-xml", response_model=ImportGirXmlResponse)
def import_gir_xml(filing_id: str, payload: ImportGirXmlRequest, db: Session = Depends(get_db)):
    """Import a GIR XML file into registers + datapoints.

    This is a pragmatic bridge endpoint intended for customer-facing web tools
    (Anything.com, etc.). The API accepts a file URL, downloads it server-side,
    parses XML, and loads:
      - Filer register (single filer from FilingCE)
      - Jurisdiction register (from JurisdictionSection, plus RecJurCode fallbacks)
      - Constituent Entity register (from GeneralSection/CorporateStructure/CE)
      - Datapoints (flattened leaf nodes)
    """

    filing = _ensure_filing(db, filing_id)

    import_id = f"IMP-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}-{sha1(f'{filing_id}'.encode('utf-8')).hexdigest()[:8].upper()}"
    warnings: List[ImportGirXmlWarning] = []

    url = (payload.file_url or "").strip()
    if not url.lower().startswith(("https://", "http://")):
        raise HTTPException(status_code=400, detail="file_url must start with http:// or https://")

    # Optional replacement (recommended for web UX: re-upload replaces prior state).
    if payload.replace_existing:
        db.query(models.DataPoint).filter(models.DataPoint.filing_id == filing_id).delete(synchronize_session=False)
        db.query(models.Filer).filter(models.Filer.filing_id == filing_id).delete(synchronize_session=False)
        db.query(models.Jurisdiction).filter(models.Jurisdiction.filing_id == filing_id).delete(synchronize_session=False)
        db.query(models.ConstituentEntity).filter(models.ConstituentEntity.filing_id == filing_id).delete(synchronize_session=False)
        db.commit()

    # Download XML
    try:
        resp = requests.get(url, timeout=60)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Could not download file_url: {e}")

    if resp.status_code >= 400:
        raise HTTPException(status_code=400, detail=f"Could not download file_url: HTTP {resp.status_code}")

    content = resp.content or b""
    max_bytes = 50 * 1024 * 1024
    if len(content) > max_bytes:
        raise HTTPException(status_code=413, detail=f"File too large ({len(content)} bytes). Max {max_bytes} bytes")

    # Parse XML
    try:
        root = ET.fromstring(content)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid XML: {e}")

    # Extract FilingCE details for a single 'primary filer'
    filing_ce_name = _find_text(root, ["GLOBEBody", "FilingInfo", "FilingCE", "Name"])
    filing_ce_tin = _find_text(root, ["GLOBEBody", "FilingInfo", "FilingCE", "TIN"])
    filing_ce_role = _find_text(root, ["GLOBEBody", "FilingInfo", "FilingCE", "Role"])
    filing_ce_res = _find_text(root, ["GLOBEBody", "FilingInfo", "FilingCE", "ResCountryCode"])
    filing_ce_res = (filing_ce_res or "").strip().upper() if filing_ce_res else None
    if filing_ce_res and (len(filing_ce_res) != 2 or not filing_ce_res.isalpha()):
        filing_ce_res = None

    # Derive a stable filer_code
    filer_code = _safe_code(filing_ce_tin or filing_ce_name or filing.tenant_id, prefix="FE")

    now = datetime.utcnow()

    # Upsert filer register (single entry)
    filer_row = {
        "filing_id": filing_id,
        "filer_code": filer_code,
        "legal_name": filing_ce_name,
        "role": "FILING_CE",
        "jurisdiction_code": filing_ce_res,
        "tin": filing_ce_tin,
        "filing_ce_role": filing_ce_role,
        "updated_at": now,
        "created_at": now,
    }
    stmt = insert(models.Filer).values([filer_row])
    update_cols = {c.name: getattr(stmt.excluded, c.name) for c in models.Filer.__table__.columns if c.name not in ("id", "created_at")}
    stmt = stmt.on_conflict_do_update(constraint="uq_filer_filing_code", set_=update_cols)
    db.execute(stmt)
    db.commit()

    # Collect jurisdictions from JurisdictionSection and RecJurCode fallbacks.
    jurisdiction_rows: List[dict] = []
    jurisdiction_codes: Set[str] = set()

    gbody = _child(root, "GLOBEBody")
    if gbody is not None:
        for ch in list(gbody):
            if not isinstance(ch.tag, str):
                continue
            if _local(ch.tag) != "JurisdictionSection":
                continue
            jc = (_child_text(ch, "Jurisdiction") or "").strip().upper()
            if len(jc) != 2:
                continue
            jurisdiction_codes.add(jc)
            local_cur = _child_text(ch, "LocalCurrency")
            jurisdiction_rows.append({
                "filing_id": filing_id,
                "jurisdiction_code": jc,
                "local_currency": local_cur,
                "responsible_filer_code": filer_code,
                "computation_mode": None,
                "qdmt_applicable": None,
                "status": None,
                "notes": None,
                "updated_at": now,
                "created_at": now,
            })

    # Parse Constituent Entities from CorporateStructure/CE
    entity_rows: List[dict] = []
    entity_by_key: dict = {}

    def _entity_code_for(name: Optional[str], res: Optional[str], tin: Optional[str]) -> str:
        seed = f"{(res or '').strip().upper()}|{(tin or '').strip()}|{(name or '').strip()}"
        h = sha1(seed.encode("utf-8")).hexdigest()[:12].upper()
        return f"E{h}"

    if gbody is not None:
        general = _child(gbody, "GeneralSection")
        if general is not None:
            corp = _child(general, "CorporateStructure")
            if corp is not None:
                for ce in list(corp):
                    if not isinstance(ce.tag, str) or _local(ce.tag) != "CE":
                        continue
                    id_node = _child(ce, "ID")
                    name = _child_text(id_node, "Name") if id_node is not None else None
                    res = _child_text(id_node, "ResCountryCode") if id_node is not None else None
                    tin = _child_text(id_node, "TIN") if id_node is not None else None
                    id_rules = _child_text(id_node, "Rules") if id_node is not None else None
                    globe_status = _child_text(id_node, "GlobeStatus") if id_node is not None else None

                    entity_code = _entity_code_for(name, res, tin)
                    entity_by_key[id(ce)] = entity_code
                    jcode = (res or "").strip().upper() if res else None
                    if jcode and len(jcode) != 2:
                        jcode = None

                    entity_rows.append({
                        "filing_id": filing_id,
                        "entity_code": entity_code,
                        "legal_name": name,
                        "jurisdiction_code": jcode,
                        "tin": tin,
                        "included_in_gir": True,
                        "filed_by_filer_code": filer_code,
                        "id_rules": id_rules,
                        "globe_status": globe_status,
                        "parent_entity_code": None,
                        "ownership_type": None,
                        "ownership_percentage": None,
                        "owner_tin_override": None,
                        "updated_at": now,
                        "created_at": now,
                    })

                    if jcode:
                        jurisdiction_codes.add(jcode)

    # Import datapoints (flattened leaf nodes)
    recjur_codes: Set[str] = set()
    datapoint_rows: List[dict] = []

    # Track CEComputation occurrences per jurisdiction so we can preserve repeats even when DocRefId is missing.
    cecomp_counter: dict = {}

    def _desc_chain_text(node: ET.Element, chain: List[str]) -> Optional[str]:
        """Find text for the first descendant matching chain[0] then its child chain[1]..."""
        if not chain:
            return None
        first = chain[0]
        for d in node.iter():
            if not isinstance(d.tag, str):
                continue
            if _local(d.tag) != first:
                continue
            cur = d
            ok = True
            for p in chain[1:]:
                cur = _child(cur, p)
                if cur is None:
                    ok = False
                    break
            if not ok:
                continue
            t = (cur.text or "").strip()
            if t:
                return t
        return None

    def _first_desc_text(node: ET.Element, localname: str) -> Optional[str]:
        for d in node.iter():
            if not isinstance(d.tag, str):
                continue
            if _local(d.tag) != localname:
                continue
            t = (d.text or "").strip()
            if t:
                return t
        return None

    def _extract_id_triplet(node: ET.Element) -> Tuple[Optional[str], Optional[str], Optional[str]]:
        """Best-effort: extract (Name, ResCountryCode, TIN) from the first descendant <ID> block."""
        for d in node.iter():
            if not isinstance(d.tag, str):
                continue
            if _local(d.tag) != "ID":
                continue
            name = _child_text(d, "Name")
            res = _child_text(d, "ResCountryCode")
            tin = _child_text(d, "TIN")
            if name or res or tin:
                return name, res, tin
        return None, None, None

    def _cecomp_row_context(node: ET.Element, juris_code: Optional[str]) -> str:
        """Stable-ish context key for repeating CEComputation rows.

        Prefer DocSpec/DocRefId (hashed) when present; otherwise fall back to an index per jurisdiction.
        """
        jc = (juris_code or "XX").strip().upper()
        if len(jc) != 2 or not jc.isalpha():
            jc = "XX"

        doc_ref = _desc_chain_text(node, ["DocSpec", "DocRefId"]) or _first_desc_text(node, "DocRefId")
        if doc_ref:
            h = sha1(doc_ref.strip().encode("utf-8")).hexdigest()[:16].upper()
            return f"CECOMP:{jc}:{h}"

        idx = int(cecomp_counter.get(jc, 0)) + 1
        cecomp_counter[jc] = idx
        return f"CECOMP:{jc}:IDX{idx:04d}"

    def walk(
        node: ET.Element,
        path_parts: List[str],
        juris_code: Optional[str],
        entity_code: Optional[str],
        row_context: Optional[str],
    ):
        tag = _local(node.tag) if isinstance(node.tag, str) else ""
        new_parts = path_parts + ([tag] if tag else [])

        # Children elements only
        children = [c for c in list(node) if isinstance(c.tag, str)]

        # Preserve repeats for CEComputation rows (common source of overwrites if context_key is missing).
        if tag == "CEComputation" and juris_code:
            if row_context is None:
                row_context = _cecomp_row_context(node, juris_code)
            if entity_code is None:
                n, r, t = _extract_id_triplet(node)
                if n or r or t:
                    entity_code = _entity_code_for(n, r, t)

        # Special scoping: entering JurisdictionSection (direct child of GLOBEBody)
        if tag == "GLOBEBody":
            for ch in children:
                ch_tag = _local(ch.tag)
                if ch_tag == "JurisdictionSection":
                    jc = (_child_text(ch, "Jurisdiction") or "").strip().upper()
                    jc = jc if len(jc) == 2 and jc.isalpha() else None
                    walk(ch, new_parts, juris_code=jc, entity_code=None, row_context=None)
                else:
                    walk(ch, new_parts, juris_code=None, entity_code=None, row_context=None)
            return

        # Special scoping: entering CorporateStructure/CE
        if tag == "CorporateStructure":
            for ch in children:
                ch_tag = _local(ch.tag)
                if ch_tag == "CE":
                    ecode = entity_by_key.get(id(ch))
                    if not ecode:
                        # Fallback if CE list parsing missed it
                        id_node = _child(ch, "ID")
                        name = _child_text(id_node, "Name") if id_node is not None else None
                        res = _child_text(id_node, "ResCountryCode") if id_node is not None else None
                        tin = _child_text(id_node, "TIN") if id_node is not None else None
                        ecode = _entity_code_for(name, res, tin)
                        entity_by_key[id(ch)] = ecode
                    walk(ch, new_parts, juris_code=None, entity_code=ecode, row_context=row_context)
                else:
                    walk(ch, new_parts, juris_code=None, entity_code=None, row_context=row_context)
            return

        if not children:
            text = (node.text or "").strip()
            if not text:
                return

            xml_path = "/" + "/".join([p for p in new_parts if p])

            # Default: use the inherited row_context (e.g., for repeated CEComputation rows).
            context_key: Optional[str] = row_context

            if tag == "RecJurCode":
                code = text.strip().upper()
                if len(code) == 2 and code.isalpha():
                    recjur_codes.add(code)
                    base_ctx: Optional[str] = None
                    if "/GeneralSection/RecJurCode" in xml_path:
                        base_ctx = f"GEN_RECJUR:{code}"
                    elif "/Summary/RecJurCode" in xml_path:
                        base_ctx = f"SUM_RECJUR:{code}"
                    elif "/JurisdictionSection/RecJurCode" in xml_path:
                        base_ctx = f"JUR_RECJUR:{(juris_code or code)}"
                    else:
                        base_ctx = f"RECJUR:{code}"

                    if base_ctx:
                        if context_key:
                            context_key = f"{context_key}|{base_ctx}"
                        else:
                            context_key = base_ctx
                        if len(context_key) > 128:
                            context_key = context_key[:128]

            dec = try_parse_decimal(text)
            dt = try_parse_date(text)

            datapoint_rows.append({
                "filing_id": filing_id,
                "filer_code": filer_code,
                "jurisdiction_code": juris_code,
                "entity_code": entity_code,
                "context_key": context_key,
                "xml_path": xml_path,
                "value_raw": text,
                "value_numeric": dec,
                "value_date": dt,
                "currency": None,
                "source": "import",
                "source_system": payload.source_system or "gir_xml_import",
                "notes": None,
                "updated_at": now,
                "created_at": now,
            })
            return

        for ch in children:
            walk(ch, new_parts, juris_code=juris_code, entity_code=entity_code, row_context=row_context)

    # Start traversal from root
    walk(root, [], juris_code=None, entity_code=None, row_context=None)

    # Fallback jurisdictions from RecJurCode values
    for code in sorted(recjur_codes):
        if code and len(code) == 2 and code.isalpha():
            jurisdiction_codes.add(code)

    # Upsert jurisdictions
    if jurisdiction_codes and not jurisdiction_rows:
        # If we have codes but no JurisdictionSection blocks, create minimal register rows.
        for jc in sorted(jurisdiction_codes):
            jurisdiction_rows.append({
                "filing_id": filing_id,
                "jurisdiction_code": jc,
                "local_currency": None,
                "responsible_filer_code": filer_code,
                "computation_mode": None,
                "qdmt_applicable": None,
                "status": None,
                "notes": "Derived from RecJurCode values",
                "updated_at": now,
                "created_at": now,
            })

    if jurisdiction_rows:
        stmt = insert(models.Jurisdiction).values(jurisdiction_rows)
        update_cols = {c.name: getattr(stmt.excluded, c.name) for c in models.Jurisdiction.__table__.columns if c.name not in ("id", "created_at")}
        stmt = stmt.on_conflict_do_update(constraint="uq_juris_filing_code", set_=update_cols)
        db.execute(stmt)
        db.commit()

    # Upsert entities
    if entity_rows:
        stmt = insert(models.ConstituentEntity).values(entity_rows)
        update_cols = {c.name: getattr(stmt.excluded, c.name) for c in models.ConstituentEntity.__table__.columns if c.name not in ("id", "created_at")}
        stmt = stmt.on_conflict_do_update(constraint="uq_entity_filing_code", set_=update_cols)
        db.execute(stmt)
        db.commit()

    # Upsert datapoints (chunked)
    if datapoint_rows:
        for chunk in _chunked(datapoint_rows, 5000):
            stmt = insert(models.DataPoint).values(chunk)
            update_cols = {c.name: getattr(stmt.excluded, c.name) for c in models.DataPoint.__table__.columns if c.name not in ("id", "created_at")}
            stmt = stmt.on_conflict_do_update(constraint="uq_datapoint_key", set_=update_cols)
            db.execute(stmt)
        db.commit()

    # Basic sanity warning: filing currency mismatch vs XML if present
    xml_currency = _find_text(root, ["GLOBEBody", "FilingInfo", "AccountingInfo", "Currency"])
    if xml_currency and filing.reporting_currency and xml_currency.strip().upper() != filing.reporting_currency.strip().upper():
        warnings.append(ImportGirXmlWarning(
            code="CURRENCY_MISMATCH",
            message=f"XML currency={xml_currency.strip().upper()} differs from filing.reporting_currency={filing.reporting_currency.strip().upper()}",
        ))

    # Update filing timestamp
    filing.updated_at = now
    db.add(filing)
    db.commit()

    # Stage 3: persist submission history (for cross-submission OECD validations like 60002/60009/60014)
    try:
        cfg = load_config(settings.config_root, filing.config_version_id)
        msg_ref = _find_text(root, ["GLOBEHeader", "MessageRefId"])
        rp_start_raw = _find_text(root, ["GLOBEHeader", "ReportingPeriod", "StartDate"])
        rp_end_raw = _find_text(root, ["GLOBEHeader", "ReportingPeriod", "EndDate"])
        rp_start = try_parse_date(rp_start_raw) if rp_start_raw else None
        rp_end = try_parse_date(rp_end_raw) if rp_end_raw else None

        record_submission_from_import(
            db=db,
            filing=filing,
            config=cfg,
            source_type="xml",
            file_url=url,
            file_bytes=content,
            datapoint_rows=datapoint_rows,
            message_ref_id=msg_ref,
            reporting_period_start=rp_start,
            reporting_period_end=rp_end,
            notes=f"import_id={import_id}; source_system={payload.source_system or 'gir_xml_import'}",
        )
    except Exception as e:
        warnings.append(ImportGirXmlWarning(
            code="SUBMISSION_HISTORY_FAILED",
            message=f"Could not record submission history: {e}",
        ))

    stats = ImportGirXmlStats(
        filers_total=1,
        jurisdictions_total=len(jurisdiction_codes),
        entities_total=len(entity_rows),
        datapoints_total=len(datapoint_rows),
    )

    return ImportGirXmlResponse(
        import_id=import_id,
        filing_id=filing_id,
        status="completed",
        stats=stats,
        warnings=warnings,
    )


@router.post("/gir-xml:validate", response_model=ImportGirXmlValidateResponse)
def import_gir_xml_and_validate(
    filing_id: str,
    payload: ImportGirXmlValidateRequest,
    db: Session = Depends(get_db),
):
    """One-click import + validate endpoint.

    This is designed specifically for customer-facing self-serve flows (Anything.com, etc.)
    where the UI wants to:
      1) upload XML
      2) import it into the engine
      3) run validations

    ...all in a single API call.
    """

    # First import
    import_payload = ImportGirXmlRequest(
        file_url=payload.file_url,
        source_system=payload.source_system,
        replace_existing=payload.replace_existing,
        strict_xsd=payload.strict_xsd,
    )
    import_result = import_gir_xml(filing_id, import_payload, db)

    # Then validate (reuse existing implementation for consistent persistence)
    try:
        run_dict = _create_validation_run(
            filing_id,
            ValidationRunCreate(notes=payload.notes),
            db,
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Validation failed: {e}")

    return ImportGirXmlValidateResponse(
        import_result=import_result,
        validation_run=ValidationRunRead(**run_dict),
    )


# -----------------------------
# GIR Toolkit XLSX import
# -----------------------------

_HEADER_SCAN_MAX_ROWS = 80
_DATA_MAX_ROWS = 250000
_CONSEC_EMPTY_STOP = 50


def _norm_header(h: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", (h or "").strip().lower())


def _cell_to_text(v) -> Optional[str]:
    """Convert common Excel cell types to a clean string."""
    if v is None:
        return None
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, datetime):
        return v.date().isoformat()
    if isinstance(v, date):
        return v.isoformat()
    s = str(v).strip()
    return s if s != "" else None


def _parse_yes_no(v) -> Optional[bool]:
    s = _cell_to_text(v)
    if s is None:
        return None
    s2 = s.strip().lower()
    if s2 in {"y", "yes", "true", "1"}:
        return True
    if s2 in {"n", "no", "false", "0"}:
        return False
    return None


def _juris_code(v) -> Optional[str]:
    s = _cell_to_text(v)
    if not s:
        return None
    s = s.strip().upper()
    # Keep common 2-char ISO codes; if longer, keep first 2 for robustness.
    return s[:2] if len(s) >= 2 else None


def _find_header_row(ws, required_norm_cols: Set[str]) -> Tuple[int, dict]:
    """Return (header_row_index, norm_col_to_index). header_row_index is 1-based."""
    for r_idx, row in enumerate(ws.iter_rows(min_row=1, max_row=_HEADER_SCAN_MAX_ROWS, values_only=True), start=1):
        norm_to_idx = {}
        for c_idx, v in enumerate(row or [], start=1):
            s = _cell_to_text(v)
            if not s:
                continue
            nh = _norm_header(s)
            if nh:
                # if duplicate header appears, keep first
                norm_to_idx.setdefault(nh, c_idx)
        if required_norm_cols.issubset(set(norm_to_idx.keys())):
            return r_idx, norm_to_idx
    raise ValueError(f"Could not find a header row containing required columns: {sorted(required_norm_cols)}")


def _iter_datapoint_rows_flatfile(ws, header_row: int, colmap: dict) -> Tuple[List[dict], Set[str], Set[str], Set[str]]:
    datapoints: List[dict] = []
    filer_codes: Set[str] = set()
    entity_codes: Set[str] = set()
    juris_codes: Set[str] = set()

    now = datetime.utcnow()

    # Candidate columns (normalized)
    c_filer = colmap.get(_norm_header("FilingEntity_ID"))
    c_entity = colmap.get(_norm_header("Entity_ID"))
    c_juris = colmap.get(_norm_header("Jurisdiction"))
    c_path = colmap.get(_norm_header("XML_Path"))
    c_value = colmap.get(_norm_header("Value"))
    c_ccy = colmap.get(_norm_header("Currency"))
    c_notes = colmap.get(_norm_header("Notes"))
    c_src = colmap.get(_norm_header("Source"))
    c_pby = colmap.get(_norm_header("Prepared_By"))
    c_pdt = colmap.get(_norm_header("Prepared_Date"))

    if not c_path or not c_value:
        raise ValueError("Flatfile sheet is missing required columns XML_Path and Value.")

    empty_run = 0
    for i, row in enumerate(ws.iter_rows(min_row=header_row + 1, max_row=header_row + _DATA_MAX_ROWS, values_only=True), start=1):
        # Stop after enough consecutive blank rows
        if row is None or all(v is None or (isinstance(v, str) and v.strip() == "") for v in row):
            empty_run += 1
            if empty_run >= _CONSEC_EMPTY_STOP:
                break
            continue
        empty_run = 0

        xml_path = _cell_to_text(row[c_path - 1] if c_path <= len(row) else None)
        if not xml_path:
            continue
        xml_path = xml_path.strip()
        if not xml_path.startswith("/"):
            xml_path = "/" + xml_path

        value = _cell_to_text(row[c_value - 1] if c_value <= len(row) else None)
        if value is None or value.strip() == "":
            # Treat blank as not provided
            continue
        value = value.strip()

        filer_code = _cell_to_text(row[c_filer - 1] if c_filer and c_filer <= len(row) else None)
        entity_code = _cell_to_text(row[c_entity - 1] if c_entity and c_entity <= len(row) else None)
        juris = _juris_code(row[c_juris - 1] if c_juris and c_juris <= len(row) else None)
        ccy = _cell_to_text(row[c_ccy - 1] if c_ccy and c_ccy <= len(row) else None)
        src = _cell_to_text(row[c_src - 1] if c_src and c_src <= len(row) else None)
        notes = _cell_to_text(row[c_notes - 1] if c_notes and c_notes <= len(row) else None)

        prepared_by = _cell_to_text(row[c_pby - 1] if c_pby and c_pby <= len(row) else None)
        prepared_date = _cell_to_text(row[c_pdt - 1] if c_pdt and c_pdt <= len(row) else None)

        extra_bits = []
        if prepared_by:
            extra_bits.append(f"prepared_by={prepared_by}")
        if prepared_date:
            extra_bits.append(f"prepared_date={prepared_date}")
        if src:
            extra_bits.append(f"source={src}")
        if extra_bits:
            notes = (notes + " | " if notes else "") + "; ".join(extra_bits)

        if filer_code:
            filer_codes.add(filer_code)
        if entity_code:
            entity_codes.add(entity_code)
        if juris:
            juris_codes.add(juris)

        datapoints.append({
            "filing_id": None,  # fill later
            "filer_code": filer_code,
            "jurisdiction_code": juris,
            "entity_code": entity_code,
            "context_key": None,
            "xml_path": xml_path,
            "value_raw": value,
            "value_numeric": try_parse_decimal(value),
            "value_date": try_parse_date(value),
            "currency": ccy,
            "source": "import",
            "source_system": None,  # fill later
            "notes": notes,
            "created_at": now,
            "updated_at": now,
        })

    return datapoints, filer_codes, juris_codes, entity_codes


def _iter_datapoint_rows_normalised(ws, header_row: int, colmap: dict) -> Tuple[List[dict], Set[str], Set[str], Set[str]]:
    datapoints: List[dict] = []
    filer_codes: Set[str] = set()
    entity_codes: Set[str] = set()
    juris_codes: Set[str] = set()

    now = datetime.utcnow()

    c_filer = colmap.get(_norm_header("FilingEntity_ID"))
    c_entity = colmap.get(_norm_header("Entity_ID"))
    c_juris = colmap.get(_norm_header("Jurisdiction"))
    c_ctx = colmap.get(_norm_header("Context_Key"))
    c_path = colmap.get(_norm_header("XML_Path"))
    c_value = colmap.get(_norm_header("Value"))
    c_ccy = colmap.get(_norm_header("Currency"))
    c_notes = colmap.get(_norm_header("Notes"))
    c_src = colmap.get(_norm_header("Source_Tool"))
    c_tax = colmap.get(_norm_header("Tax_Label"))

    if not c_path or not c_value:
        raise ValueError("Normalised output sheet is missing required columns XML_Path and Value.")

    empty_run = 0
    for row in ws.iter_rows(min_row=header_row + 1, max_row=header_row + _DATA_MAX_ROWS, values_only=True):
        if row is None or all(v is None or (isinstance(v, str) and v.strip() == "") for v in row):
            empty_run += 1
            if empty_run >= _CONSEC_EMPTY_STOP:
                break
            continue
        empty_run = 0

        xml_path = _cell_to_text(row[c_path - 1] if c_path <= len(row) else None)
        if not xml_path:
            continue
        xml_path = xml_path.strip()
        if not xml_path.startswith("/"):
            xml_path = "/" + xml_path

        value = _cell_to_text(row[c_value - 1] if c_value <= len(row) else None)
        if value is None or value.strip() == "":
            continue
        value = value.strip()

        filer_code = _cell_to_text(row[c_filer - 1] if c_filer and c_filer <= len(row) else None)
        entity_code = _cell_to_text(row[c_entity - 1] if c_entity and c_entity <= len(row) else None)
        juris = _juris_code(row[c_juris - 1] if c_juris and c_juris <= len(row) else None)
        ctx = _cell_to_text(row[c_ctx - 1] if c_ctx and c_ctx <= len(row) else None)
        ccy = _cell_to_text(row[c_ccy - 1] if c_ccy and c_ccy <= len(row) else None)
        notes = _cell_to_text(row[c_notes - 1] if c_notes and c_notes <= len(row) else None)
        src = _cell_to_text(row[c_src - 1] if c_src and c_src <= len(row) else None)
        tax_label = _cell_to_text(row[c_tax - 1] if c_tax and c_tax <= len(row) else None)

        extra_bits = []
        if tax_label:
            extra_bits.append(f"tax_label={tax_label}")
        if src:
            extra_bits.append(f"source={src}")
        if extra_bits:
            notes = (notes + " | " if notes else "") + "; ".join(extra_bits)

        if filer_code:
            filer_codes.add(filer_code)
        if entity_code:
            entity_codes.add(entity_code)
        if juris:
            juris_codes.add(juris)

        datapoints.append({
            "filing_id": None,
            "filer_code": filer_code,
            "jurisdiction_code": juris,
            "entity_code": entity_code,
            "context_key": ctx,
            "xml_path": xml_path,
            "value_raw": value,
            "value_numeric": try_parse_decimal(value),
            "value_date": try_parse_date(value),
            "currency": ccy,
            "source": "import",
            "source_system": None,
            "notes": notes,
            "created_at": now,
            "updated_at": now,
        })

    return datapoints, filer_codes, juris_codes, entity_codes


def _read_register_table(ws, required_norm_cols: Set[str]) -> Tuple[int, dict]:
    return _find_header_row(ws, required_norm_cols)


def _parse_filer_register(wb) -> List[dict]:
    if "Filing_Entity_Register" not in wb.sheetnames:
        return []
    ws = wb["Filing_Entity_Register"]
    # Header is usually row 1, but scan anyway.
    required = {_norm_header("FilingEntity_ID")}
    header_row, colmap = _read_register_table(ws, required)
    rows: List[dict] = []
    now = datetime.utcnow()

    def col(name: str) -> Optional[int]:
        return colmap.get(_norm_header(name))

    c_id = col("FilingEntity_ID")
    c_name = col("Legal_Name")
    c_role = col("Role")
    c_juris = col("Jurisdiction")
    c_tin = col("Tax_ID")
    c_ccy = col("Reporting_Currency")
    c_scope = col("Filing_Scope")
    c_owner = col("Contact_Owner")
    c_status = col("Status")
    c_id_rules = col("ID_Rules (default GIR205)")
    c_globe = col("GloBE_Status (default GIR301)")

    empty_run = 0
    for row in ws.iter_rows(min_row=header_row + 1, max_row=header_row + 5000, values_only=True):
        if row is None or all(v is None or (isinstance(v, str) and v.strip() == "") for v in row):
            empty_run += 1
            if empty_run >= _CONSEC_EMPTY_STOP:
                break
            continue
        empty_run = 0

        filer_code = _cell_to_text(row[c_id - 1] if c_id and c_id <= len(row) else None)
        if not filer_code:
            continue

        rows.append({
            "filing_id": None,
            "filer_code": filer_code,
            "legal_name": _cell_to_text(row[c_name - 1]) if c_name and c_name <= len(row) else None,
            "role": _cell_to_text(row[c_role - 1]) if c_role and c_role <= len(row) else None,
            "jurisdiction_code": _juris_code(row[c_juris - 1]) if c_juris and c_juris <= len(row) else None,
            "tin": _cell_to_text(row[c_tin - 1]) if c_tin and c_tin <= len(row) else None,
            "reporting_currency": (_cell_to_text(row[c_ccy - 1]) if c_ccy and c_ccy <= len(row) else None),
            "scope": _cell_to_text(row[c_scope - 1]) if c_scope and c_scope <= len(row) else None,
            "owner": _cell_to_text(row[c_owner - 1]) if c_owner and c_owner <= len(row) else None,
            "status": _cell_to_text(row[c_status - 1]) if c_status and c_status <= len(row) else None,
            "id_rules": _cell_to_text(row[c_id_rules - 1]) if c_id_rules and c_id_rules <= len(row) else None,
            "globe_status": _cell_to_text(row[c_globe - 1]) if c_globe and c_globe <= len(row) else None,
            "created_at": now,
            "updated_at": now,
        })
    return rows


def _parse_entity_register(wb) -> List[dict]:
    if "Constituent_Entity_Register" not in wb.sheetnames:
        return []
    ws = wb["Constituent_Entity_Register"]
    required = {_norm_header("Entity_ID")}
    header_row, colmap = _read_register_table(ws, required)
    rows: List[dict] = []
    now = datetime.utcnow()

    def col(name: str) -> Optional[int]:
        return colmap.get(_norm_header(name))

    c_id = col("Entity_ID")
    c_name = col("Legal_Name")
    c_juris = col("Jurisdiction")
    c_tin = col("Entity_TIN")
    c_incl = col("Included_in_GIR (Y/N)")
    c_filed_by = col("Filed_by (FilingEntity_ID)")
    c_parent = col("Immediate_Parent")
    c_own_pct = col("Ownership_%")
    c_id_rules = col("ID_Rules (default GIR205)")
    c_globe = col("GloBE_Status (default GIR301)")
    c_owner_type = col("Owner_Type_override")
    c_owner_tin = col("Owner_TIN_override")
    c_derived_owner_type = col("Derived_Owner_Type")

    empty_run = 0
    for row in ws.iter_rows(min_row=header_row + 1, max_row=header_row + 20000, values_only=True):
        if row is None or all(v is None or (isinstance(v, str) and v.strip() == "") for v in row):
            empty_run += 1
            if empty_run >= _CONSEC_EMPTY_STOP:
                break
            continue
        empty_run = 0

        entity_code = _cell_to_text(row[c_id - 1] if c_id and c_id <= len(row) else None)
        if not entity_code:
            continue

        own_pct_raw = _cell_to_text(row[c_own_pct - 1]) if c_own_pct and c_own_pct <= len(row) else None
        own_pct = try_parse_decimal(own_pct_raw) if own_pct_raw else None

        ownership_type = _cell_to_text(row[c_owner_type - 1]) if c_owner_type and c_owner_type <= len(row) else None
        if not ownership_type:
            ownership_type = _cell_to_text(row[c_derived_owner_type - 1]) if c_derived_owner_type and c_derived_owner_type <= len(row) else None

        rows.append({
            "filing_id": None,
            "entity_code": entity_code,
            "legal_name": _cell_to_text(row[c_name - 1]) if c_name and c_name <= len(row) else None,
            "jurisdiction_code": _juris_code(row[c_juris - 1]) if c_juris and c_juris <= len(row) else None,
            "tin": _cell_to_text(row[c_tin - 1]) if c_tin and c_tin <= len(row) else None,
            "included_in_gir": (_parse_yes_no(row[c_incl - 1]) if c_incl and c_incl <= len(row) else True),
            "filed_by_filer_code": _cell_to_text(row[c_filed_by - 1]) if c_filed_by and c_filed_by <= len(row) else None,
            "parent_entity_code": _cell_to_text(row[c_parent - 1]) if c_parent and c_parent <= len(row) else None,
            "ownership_percentage": own_pct,
            "ownership_type": ownership_type,
            "owner_tin_override": _cell_to_text(row[c_owner_tin - 1]) if c_owner_tin and c_owner_tin <= len(row) else None,
            "id_rules": _cell_to_text(row[c_id_rules - 1]) if c_id_rules and c_id_rules <= len(row) else None,
            "globe_status": _cell_to_text(row[c_globe - 1]) if c_globe and c_globe <= len(row) else None,
            "created_at": now,
            "updated_at": now,
        })
    return rows


def _parse_jurisdiction_register(wb) -> List[dict]:
    if "Jurisdiction_Register" not in wb.sheetnames:
        return []
    ws = wb["Jurisdiction_Register"]
    required = {_norm_header("Jurisdiction (ISO)")}
    header_row, colmap = _read_register_table(ws, required)
    rows: List[dict] = []
    now = datetime.utcnow()

    def col(name: str) -> Optional[int]:
        return colmap.get(_norm_header(name))

    c_j = col("Jurisdiction (ISO)")
    c_ccy = col("Local Currency (ISO)")
    c_resp = col("Responsible Filer (FilingEntity_ID)")
    c_mode = col("Computation Mode")
    c_qdmt = col("QDMTT applicable? (Y/N)")
    c_status = col("Status")
    c_notes = col("Notes")

    empty_run = 0
    for row in ws.iter_rows(min_row=header_row + 1, max_row=header_row + 5000, values_only=True):
        if row is None or all(v is None or (isinstance(v, str) and v.strip() == "") for v in row):
            empty_run += 1
            if empty_run >= _CONSEC_EMPTY_STOP:
                break
            continue
        empty_run = 0

        j = _juris_code(row[c_j - 1] if c_j and c_j <= len(row) else None)
        if not j:
            continue

        rows.append({
            "filing_id": None,
            "jurisdiction_code": j,
            "local_currency": _cell_to_text(row[c_ccy - 1]) if c_ccy and c_ccy <= len(row) else None,
            "responsible_filer_code": _cell_to_text(row[c_resp - 1]) if c_resp and c_resp <= len(row) else None,
            "computation_mode": _cell_to_text(row[c_mode - 1]) if c_mode and c_mode <= len(row) else None,
            "qdmt_applicable": _parse_yes_no(row[c_qdmt - 1]) if c_qdmt and c_qdmt <= len(row) else None,
            "status": _cell_to_text(row[c_status - 1]) if c_status and c_status <= len(row) else None,
            "notes": _cell_to_text(row[c_notes - 1]) if c_notes and c_notes <= len(row) else None,
            "created_at": now,
            "updated_at": now,
        })
    return rows


@router.post("/gir-toolkit-xlsx", response_model=ImportGirToolkitXlsxResponse)
def import_gir_toolkit_xlsx(filing_id: str, payload: ImportGirToolkitXlsxRequest, db: Session = Depends(get_db)):
    """Import an OECD Pillars GIR Prep Suite workbook (.xlsx) into registers + datapoints.

    Recommended ingestion sources (in priority order):
      1) GIR_Export_FlatFile (flat table: FilingEntity_ID, Jurisdiction, Entity_ID, XML_Path, Value, Currency, ...)
      2) Engine_Normalised_Output (normalized datapoints: includes Context_Key)
    """

    filing = _ensure_filing(db, filing_id)

    import_id = f"IMPX-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}-{sha1(f'{filing_id}'.encode('utf-8')).hexdigest()[:8].upper()}"
    warnings: List[ImportGirXmlWarning] = []

    url = (payload.file_url or "").strip()
    if not url.lower().startswith(("https://", "http://")):
        raise HTTPException(status_code=400, detail="file_url must start with http:// or https://")

    if payload.replace_existing:
        db.query(models.DataPoint).filter(models.DataPoint.filing_id == filing_id).delete(synchronize_session=False)
        db.query(models.Filer).filter(models.Filer.filing_id == filing_id).delete(synchronize_session=False)
        db.query(models.Jurisdiction).filter(models.Jurisdiction.filing_id == filing_id).delete(synchronize_session=False)
        db.query(models.ConstituentEntity).filter(models.ConstituentEntity.filing_id == filing_id).delete(synchronize_session=False)
        db.commit()

    try:
        resp = requests.get(url, timeout=(5, 120))
        resp.raise_for_status()
        content = resp.content
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to download file_url: {e}")

    try:
        wb = load_workbook(BytesIO(content), read_only=True, data_only=True)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to read .xlsx: {e}")

    # Choose sheet
    sheet_used: Optional[str] = None
    candidates = []
    if payload.preferred_sheet:
        candidates = [payload.preferred_sheet]
    else:
        candidates = ["GIR_Export_FlatFile", "Engine_Normalised_Output"]

    datapoint_rows: List[dict] = []
    filer_codes: Set[str] = set()
    juris_codes: Set[str] = set()
    entity_codes: Set[str] = set()

    last_err: Optional[str] = None
    for s in candidates:
        if s not in wb.sheetnames:
            last_err = f"Sheet {s} not present"
            continue
        ws = wb[s]
        try:
            if s == "GIR_Export_FlatFile":
                header_row, colmap = _find_header_row(ws, {_norm_header("XML_Path"), _norm_header("Value")})
                dps, fset, jset, eset = _iter_datapoint_rows_flatfile(ws, header_row, colmap)
            else:
                header_row, colmap = _find_header_row(ws, {_norm_header("XML_Path"), _norm_header("Value")})
                dps, fset, jset, eset = _iter_datapoint_rows_normalised(ws, header_row, colmap)
            if dps:
                datapoint_rows = dps
                filer_codes = fset
                juris_codes = jset
                entity_codes = eset
                sheet_used = s
                break
            else:
                last_err = f"Sheet {s} found but contains no datapoint rows (data_only mode may see blanks if formulas are not cached)."
        except Exception as e:
            last_err = str(e)

    if sheet_used is None:
        detail = (
            "No datapoints found in the workbook export sheets. "
            "Tried: " + ", ".join(candidates) + ". "
            + (f"Last error: {last_err}. " if last_err else "")
            + "Note: the server does not recalculate Excel formulas. "
            "Open the workbook in Excel, allow calculation to complete, save, and upload again; "
            "or export the flatfile to CSV and import that."
        )
        raise HTTPException(status_code=400, detail=detail)

    # Parse registers (best effort)
    filer_rows = _parse_filer_register(wb)
    entity_rows = _parse_entity_register(wb)
    juris_rows = _parse_jurisdiction_register(wb)

    # Fallback placeholders for codes referenced in datapoints but missing from registers
    now = datetime.utcnow()
    existing_filer_codes = {r.get("filer_code") for r in filer_rows if r.get("filer_code")}
    for fc in sorted(filer_codes - existing_filer_codes):
        filer_rows.append({
            "filing_id": None,
            "filer_code": fc,
            "reporting_currency": filing.reporting_currency,
            "created_at": now,
            "updated_at": now,
        })

    existing_entity_codes = {r.get("entity_code") for r in entity_rows if r.get("entity_code")}
    for ec in sorted(entity_codes - existing_entity_codes):
        entity_rows.append({
            "filing_id": None,
            "entity_code": ec,
            "included_in_gir": True,
            "created_at": now,
            "updated_at": now,
        })

    existing_juris_codes = {r.get("jurisdiction_code") for r in juris_rows if r.get("jurisdiction_code")}
    for jc in sorted(juris_codes - existing_juris_codes):
        juris_rows.append({
            "filing_id": None,
            "jurisdiction_code": jc,
            "created_at": now,
            "updated_at": now,
        })

    # Fill filing_id + source_system into row dicts
    for r in filer_rows:
        r["filing_id"] = filing_id
    for r in entity_rows:
        r["filing_id"] = filing_id
    for r in juris_rows:
        r["filing_id"] = filing_id
    for dp in datapoint_rows:
        dp["filing_id"] = filing_id
        dp["source_system"] = payload.source_system or "gir_toolkit_xlsx"

    # Upserts (same strategy as XML import)
    if filer_rows:
        stmt = insert(models.Filer).values(filer_rows)
        update_cols = {c.name: getattr(stmt.excluded, c.name) for c in models.Filer.__table__.columns if c.name not in ("id", "created_at")}
        stmt = stmt.on_conflict_do_update(constraint="uq_filer_filing_code", set_=update_cols)
        db.execute(stmt)
        db.commit()

    if juris_rows:
        stmt = insert(models.Jurisdiction).values(juris_rows)
        update_cols = {c.name: getattr(stmt.excluded, c.name) for c in models.Jurisdiction.__table__.columns if c.name not in ("id", "created_at")}
        stmt = stmt.on_conflict_do_update(constraint="uq_juris_filing_code", set_=update_cols)
        db.execute(stmt)
        db.commit()

    if entity_rows:
        stmt = insert(models.ConstituentEntity).values(entity_rows)
        update_cols = {c.name: getattr(stmt.excluded, c.name) for c in models.ConstituentEntity.__table__.columns if c.name not in ("id", "created_at")}
        stmt = stmt.on_conflict_do_update(constraint="uq_entity_filing_code", set_=update_cols)
        db.execute(stmt)
        db.commit()

    if datapoint_rows:
        for chunk in _chunked(datapoint_rows, 5000):
            stmt = insert(models.DataPoint).values(chunk)
            update_cols = {c.name: getattr(stmt.excluded, c.name) for c in models.DataPoint.__table__.columns if c.name not in ("id", "created_at")}
            stmt = stmt.on_conflict_do_update(constraint="uq_datapoint_key", set_=update_cols)
            db.execute(stmt)
        db.commit()

    filing.updated_at = datetime.utcnow()
    db.add(filing)
    db.commit()

            # Stage 3: persist submission history (for cross-submission OECD validations like 60002/60009/60014)
    try:
        cfg = load_config(settings.config_root, filing.config_version_id)
        record_submission_from_import(
            db=db,
            filing=filing,
            config=cfg,
            source_type="xlsx",
            file_url=url,
            file_bytes=content,
            datapoint_rows=datapoint_rows,
            message_ref_id=None,
            reporting_period_start=filing.period_start,
            reporting_period_end=filing.period_end,
            notes=f"import_id={import_id}; source_system={payload.source_system or 'gir_toolkit_xlsx'}; sheet={sheet_used}",
        )
    except Exception as e:
        warnings.append(ImportGirXmlWarning(
            code="SUBMISSION_HISTORY_FAILED",
            message=f"Could not record submission history: {e}",
        ))

    stats = ImportGirXmlStats(
        filers_total=len({r.get("filer_code") for r in filer_rows if r.get("filer_code")}),
        jurisdictions_total=len({r.get("jurisdiction_code") for r in juris_rows if r.get("jurisdiction_code")}),
        entities_total=len({r.get("entity_code") for r in entity_rows if r.get("entity_code")}),
        datapoints_total=len(datapoint_rows),
    )

    return ImportGirToolkitXlsxResponse(
        import_id=import_id,
        filing_id=filing_id,
        status="completed",
        sheet_used=sheet_used,
        stats=stats,
        warnings=warnings,
    )


@router.post("/gir-toolkit-xlsx:validate", response_model=ImportGirToolkitXlsxValidateResponse)
def import_gir_toolkit_xlsx_and_validate(
    filing_id: str,
    payload: ImportGirToolkitXlsxValidateRequest,
    db: Session = Depends(get_db),
):
    """One-click import + validate for GIR Toolkit workbooks."""

    import_payload = ImportGirToolkitXlsxRequest(
        file_url=payload.file_url,
        source_system=payload.source_system,
        replace_existing=payload.replace_existing,
        preferred_sheet=payload.preferred_sheet,
    )
    import_result = import_gir_toolkit_xlsx(filing_id, import_payload, db)

    try:
        run_dict = _create_validation_run(
            filing_id,
            ValidationRunCreate(notes=payload.notes),
            db,
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Validation failed: {e}")

    return ImportGirToolkitXlsxValidateResponse(
        import_result=import_result,
        validation_run=ValidationRunRead(**run_dict),
    )
