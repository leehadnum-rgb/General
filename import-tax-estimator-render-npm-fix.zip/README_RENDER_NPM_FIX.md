# Render build fix: package-lock registry URLs

Your package-lock.json contained `resolved` URLs pointing at an internal OpenAI Artifactory host.
Render can't access that host, so `npm install` flakes and TypeScript types go missing.

This patch replaces those `resolved` URLs with `https://registry.npmjs.org/` and adds an `.npmrc`
forcing the public npm registry.

After applying:
- Commit these files
- In Render, set Build Command to `npm ci --include=dev --no-audit --no-fund && npm run build`
- Do one "Clear build cache & deploy"
