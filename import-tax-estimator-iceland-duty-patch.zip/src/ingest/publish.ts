import { Pool, PoolClient } from "pg";
import { CanonicalBundle } from "./connectors/base";

function toRange(validFrom: string, validTo: string): string {
  return `[${validFrom},${validTo})`;
}

async function insertMany(
  client: PoolClient,
  table: string,
  columns: string[],
  rows: any[][],
  chunkSize = 500
) {
  if (rows.length === 0) return;

  for (let i = 0; i < rows.length; i += chunkSize) {
    const chunk = rows.slice(i, i + chunkSize);

    const values: any[] = [];
    const placeholders: string[] = [];

    let p = 1;
    for (const r of chunk) {
      const rowPlaceholders: string[] = [];
      for (const _ of r) {
        rowPlaceholders.push(`$${p++}`);
      }
      placeholders.push(`(${rowPlaceholders.join(",")})`);
      values.push(...r);
    }

    const sql = `INSERT INTO ${table} (${columns.join(",")}) VALUES ${placeholders.join(",")}`;
    await client.query(sql, values);
  }
}

export async function publishSnapshot(
  pool: Pool,
  jurisdictionId: string,
  sourceName: string,
  manifest: any,
  canonical: CanonicalBundle
): Promise<string> {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const dv = await client.query<{ data_version_id: string }>(
      `INSERT INTO data_version (jurisdiction_id, source_name, source_manifest, is_active)
       VALUES ($1, $2, $3::jsonb, FALSE)
       RETURNING data_version_id`,
      [jurisdictionId, sourceName, JSON.stringify(manifest)]
    );
    const dataVersionId = dv.rows[0]!.data_version_id;

    // tariff_line
    await insertMany(
      client,
      "tariff_line",
      ["tariff_line_id","data_version_id","jurisdiction_id","code","code_len","description","valid_from","valid_to","valid_range","source_ref"],
      canonical.tariffLines.map((t) => [
        t.tariffLineId,
        dataVersionId,
        jurisdictionId,
        t.code,
        t.codeLen,
        t.description ?? null,
        t.validFrom,
        t.validTo,
        toRange(t.validFrom, t.validTo),
        t.sourceRef ?? null,
      ]),
      1000
    );

    // expression
    await insertMany(
      client,
      "expression",
      ["expression_id","data_version_id","expr_type","ast_json","currency","unit_code","source_ref"],
      canonical.expressions.map((e) => [
        e.expressionId,
        dataVersionId,
        e.exprType,
        JSON.stringify(e.astJson),
        e.currency ?? null,
        e.unitCode ?? null,
        e.sourceRef ?? null,
      ]),
      1000
    );

    // measure
    await insertMany(
      client,
      "measure",
      ["measure_id","data_version_id","tariff_line_id","expression_id","measure_type","origin_scope","origin_code","conditions_json","valid_from","valid_to","valid_range","source_ref"],
      canonical.measures.map((m) => [
        m.measureId,
        dataVersionId,
        m.tariffLineId,
        m.expressionId,
        m.measureType,
        m.originScope,
        m.originCode,
        m.conditionsJson != null ? JSON.stringify(m.conditionsJson) : null,
        m.validFrom,
        m.validTo,
        toRange(m.validFrom, m.validTo),
        m.sourceRef ?? null,
      ]),
      1000
    );

    // vat_rule
    await insertMany(
      client,
      "vat_rule",
      ["vat_rule_id","data_version_id","jurisdiction_id","rate_type","rate_pct","valid_from","valid_to","valid_range","source_ref"],
      canonical.vatRules.map((v) => [
        v.vatRuleId,
        dataVersionId,
        jurisdictionId,
        v.rateType,
        v.ratePct,
        v.validFrom,
        v.validTo,
        toRange(v.validFrom, v.validTo),
        v.sourceRef ?? null,
      ]),
      1000
    );

    // vat_base_formula
    await insertMany(
      client,
      "vat_base_formula",
      ["vat_base_formula_id","data_version_id","jurisdiction_id","ast_json","valid_from","valid_to","valid_range","source_ref"],
      canonical.vatBaseFormulas.map((f) => [
        f.vatBaseFormulaId,
        dataVersionId,
        jurisdictionId,
        JSON.stringify(f.astJson),
        f.validFrom,
        f.validTo,
        toRange(f.validFrom, f.validTo),
        f.sourceRef ?? null,
      ]),
      1000
    );

    // Activate snapshot
    await client.query(`UPDATE data_version SET is_active = FALSE WHERE jurisdiction_id = $1`, [jurisdictionId]);
    await client.query(`UPDATE data_version SET is_active = TRUE WHERE data_version_id = $1`, [dataVersionId]);

    await client.query("COMMIT");
    return dataVersionId;
  } catch (e) {
    await client.query("ROLLBACK");
    throw e;
  } finally {
    client.release();
  }
}
