import { Pool } from "pg";
import { v4 as uuidv4 } from "uuid";

import { publishSnapshot } from "./publish";
import { UsConnector } from "./connectors/us";
import { NzConnector } from "./connectors/nz";
import { ChConnector } from "./connectors/ch";
import { NoConnector } from "./connectors/no";
import { IsConnector } from "./connectors/is";

type JurisdictionId = "US" | "NZ" | "CH" | "NO" | "IS";

function isoDateTodayUTC(): string {
  return new Date().toISOString().slice(0, 10);
}

function parseList(envVal: string | undefined, fallback: string): string[] {
  return (envVal ?? fallback)
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}

async function upsertJurisdictions(pool: Pool) {
  await pool.query(
    `
    INSERT INTO jurisdiction (jurisdiction_id, name, currency, vat_label)
    VALUES
      ('US', 'United States', 'USD', 'Tax'),
      ('NZ', 'New Zealand',  'NZD', 'GST'),
      ('CH', 'Switzerland',  'CHF', 'VAT'),
      ('GB', 'United Kingdom', 'GBP', 'VAT'),
      ('NO', 'Norway', 'NOK', 'VAT'),
      ('LI', 'Liechtenstein', 'CHF', 'VAT'),
      ('IS', 'Iceland', 'ISK', 'VAT'),

      -- EU member states (MVP: amounts in EUR, standard VAT rate configured per country)
      ('AT', 'Austria', 'EUR', 'VAT'),
      ('BE', 'Belgium', 'EUR', 'VAT'),
      ('BG', 'Bulgaria', 'EUR', 'VAT'),
      ('CY', 'Cyprus', 'EUR', 'VAT'),
      ('CZ', 'Czechia', 'EUR', 'VAT'),
      ('DE', 'Germany', 'EUR', 'VAT'),
      ('DK', 'Denmark', 'EUR', 'VAT'),
      ('EE', 'Estonia', 'EUR', 'VAT'),
      ('ES', 'Spain', 'EUR', 'VAT'),
      ('FI', 'Finland', 'EUR', 'VAT'),
      ('FR', 'France', 'EUR', 'VAT'),
      ('GR', 'Greece', 'EUR', 'VAT'),
      ('HR', 'Croatia', 'EUR', 'VAT'),
      ('HU', 'Hungary', 'EUR', 'VAT'),
      ('IE', 'Ireland', 'EUR', 'VAT'),
      ('IT', 'Italy', 'EUR', 'VAT'),
      ('LT', 'Lithuania', 'EUR', 'VAT'),
      ('LU', 'Luxembourg', 'EUR', 'VAT'),
      ('LV', 'Latvia', 'EUR', 'VAT'),
      ('MT', 'Malta', 'EUR', 'VAT'),
      ('NL', 'Netherlands', 'EUR', 'VAT'),
      ('PL', 'Poland', 'EUR', 'VAT'),
      ('PT', 'Portugal', 'EUR', 'VAT'),
      ('RO', 'Romania', 'EUR', 'VAT'),
      ('SE', 'Sweden', 'EUR', 'VAT'),
      ('SI', 'Slovenia', 'EUR', 'VAT'),
      ('SK', 'Slovakia', 'EUR', 'VAT')
    ON CONFLICT (jurisdiction_id)
    DO UPDATE SET
      name = EXCLUDED.name,
      currency = EXCLUDED.currency,
      vat_label = EXCLUDED.vat_label
    `
  );

  // optional units
  try {
    await pool.query(
      `
      INSERT INTO unit (unit_code, dimension, description) VALUES
        ('kg','mass','kilogram'),
        ('L','volume','litre'),
        ('item','count','item')
      ON CONFLICT (unit_code) DO NOTHING
      `
    );
  } catch {
    // ignore if unit table missing
  }
}

function makeConnector(j: JurisdictionId) {
  if (j === "US") return new UsConnector();
  if (j === "NZ") return new NzConnector();
  if (j === "CH") return new ChConnector();
  if (j === "NO") return new NoConnector();
  if (j === "IS") return new IsConnector();
  const _never: never = j;
  return _never;
}

async function runWithLimit<T>(items: T[], limit: number, worker: (item: T) => Promise<void>) {
  const queue = [...items];
  const runners: Promise<void>[] = [];

  async function runOne() {
    while (queue.length) {
      const item = queue.shift()!;
      await worker(item);
    }
  }

  for (let i = 0; i < Math.max(1, limit); i++) runners.push(runOne());
  await Promise.all(runners);
}

async function main() {
  const DATABASE_URL = process.env.DATABASE_URL;
  if (!DATABASE_URL) throw new Error("DATABASE_URL is required");

  const runId = uuidv4();
  const asOfDate = process.env.INGEST_AS_OF_DATE ?? isoDateTodayUTC();
  const startedAt = new Date().toISOString();

  const jurisdictions = parseList(process.env.INGEST_JURISDICTIONS, "US,NZ,CH,NO,IS") as JurisdictionId[];
  const concurrency = Number(process.env.INGEST_CONCURRENCY ?? "1");

  const pool = new Pool({ connectionString: DATABASE_URL });

  console.log(`[ingest] runId=${runId} asOfDate=${asOfDate} jurisdictions=${jurisdictions.join(",")} concurrency=${concurrency}`);

  try {
    await upsertJurisdictions(pool);

    const failures: { j: string; error: string }[] = [];

    await runWithLimit(jurisdictions, concurrency, async (j) => {
      const ctx = { runId, jurisdictionId: j, asOfDate, startedAt };
      console.log(`[ingest:${j}] starting`);

      try {
        const connector = makeConnector(j);
        const { canonical, manifest } = await connector.run(ctx as any);
        console.log(`[ingest:${j}] parsed lines=${canonical.tariffLines.length} measures=${canonical.measures.length}`);

        const dv = await publishSnapshot(pool, j, connector.sourceName, manifest, canonical);
        console.log(`[ingest:${j}] published data_version_id=${dv}`);
      } catch (e: any) {
        const msg = e?.stack || e?.message || String(e);
        failures.push({ j, error: msg });
        console.error(`[ingest:${j}] FAILED: ${msg}`);
      }
    });

    if (failures.length) {
      console.error(`[ingest] failures=${failures.length}`);
      for (const f of failures) console.error(`- ${f.j}: ${f.error}`);
      process.exitCode = 1;
    } else {
      console.log("[ingest] OK");
    }
  } finally {
    await pool.end();
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
