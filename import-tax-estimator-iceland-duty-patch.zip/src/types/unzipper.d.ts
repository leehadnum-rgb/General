declare module "unzipper" {
  export type UnzipperFile = {
    path: string;
    type: "File" | "Directory" | string;
    buffer(): Promise<Buffer>;
  };

  export type UnzipperDirectory = {
    files: UnzipperFile[];
  };

  const unzipper: {
    Open: {
      buffer(buf: Buffer): Promise<UnzipperDirectory>;
    };
  };

  export default unzipper;
}
