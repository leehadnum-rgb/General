# Anything.com prompts (copy/paste)

## Prompt 1 — App & flow
Build a web app called "Import Tax Estimator" with a clean step-by-step flow:

Step 1:
- Inputs: Jurisdiction (dropdown: US, NZ, CH, LI, GB, NO, IS, plus EU member states AT, BE, BG, CY, CZ, DE, DK, EE, GR, ES, FI, FR, HR, HU, IE, IT, LT, LU, LV, MT, NL, PL, PT, RO, SE, SI, SK), HS/Commodity Code (text).
- Optional: As-of date (date picker). Default to today.

Step 2:
- When Step 1 is submitted, call /api/tax/requirements (backend function) with {jurisdictionId, code}.
- Display the returned tariff line description.
- Dynamically show the returned required inputs list (including **originCountry** and **customsValue**) plus any extra fields such as netMassKg, grossMassKg, volumeLitre, quantity.amount.

Notes:
- originCountry is **ISO alpha-2** (examples: CN, US, DE, AU).
- Default currency by jurisdiction:
  - US → USD
  - NZ → NZD
  - CH → CHF
  - IS → ISK
  - GB → GBP
  - NO → NOK
  - EU member states → EUR

Step 3:
- Submit everything to /api/tax/estimate (backend function) and display:
  - Customs duty total
  - VAT/GST amount (if applicable)
  - Total tax
  - Any warnings or missing inputs
- If unsupported/manual measures exist, show a clear warning banner:
  "Some duties require manual review and are not included in this estimate."

Add a small disclaimer: “Estimates only. Not legal advice.”

## Prompt 2 — Backend proxy /api/tax/requirements
Create a backend API route at /api/tax/requirements.

It should:
- Accept POST JSON { jurisdictionId, code, asOfDate? }.
- Call the external API at `${IMPORT_TAX_API_BASE_URL}/v1/requirements` using POST.
- Add header `X-API-Key: ${IMPORT_TAX_API_KEY}`.
- Return the external API JSON response directly.

Use Anything Saved Secrets named exactly:
- IMPORT_TAX_API_BASE_URL
- IMPORT_TAX_API_KEY

## Prompt 3 — Backend proxy /api/tax/estimate
Create a backend API route at /api/tax/estimate.

It should:
- Accept POST JSON matching the estimator form, including optional fields:
  - originCountry (ISO alpha-2)
  - freightToBorder, insuranceToBorder
  - netMassKg, grossMassKg, volumeLitre
  - quantity {amount, unit}
- Call `${IMPORT_TAX_API_BASE_URL}/v1/estimate` using POST.
- Add header `X-API-Key: ${IMPORT_TAX_API_KEY}`.
- Return the JSON response directly.

## Prompt 4 — UI polish
Improve the UI:
- Step 2 should only show extra fields that /api/tax/requirements returns as required.
- Show required fields with a red asterisk and inline helper text (reason from requirements response).
- Format money nicely (2 decimals).
- Show a collapsible “Calculation details” section that displays duty components and VAT base/rate if present.
- Add a “Start over” button to reset the flow.
