import unittest
from datetime import date

from app.services.models_v2 import (
    CalculationRequestV2,
    CalculationResponseV2,
    FiscalYearV2,
    TestedJurisdictionInputV2,
    TestedJurisdictionCompositionV2,
    JurisdictionFactsV2,
    CarryforwardBalanceV2,
    ScenarioAdvanceYearRequestV2,
    ScenarioAdvanceYearOptionsV2,
    GroupProfileV2,
    FxRateV2,
    TransitionYearV2,
    TransitionDeferredTaxItemV2,
)

from app.services.calculator_v2 import calculate_v2
from app.services.scenario_v2 import advance_year_scenario


class ScenarioAdvanceYearTests(unittest.TestCase):
    def test_advance_year_rolls_forward_carryforwards_and_transition_state_and_fx(self):
        last_req = CalculationRequestV2(
            schema_version="2.2",
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            group_profile=GroupProfileV2(reporting_currency="EUR"),
            fx_rates=[FxRateV2(currency="USD", avg_rate_to_reporting=0.5, spot_rate_to_reporting=0.4, fiscal_year_start=date(2027, 1, 1))],
            tested_jurisdictions=[
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="US_MAIN",
                    jurisdiction_code="US",
                    accounting_basis={"currency": "USD", "amount_scale": "UNITS"},
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    facts=JurisdictionFactsV2(jpbt=-100.0, current_tax_expense=-5.0),
                    transition_year=TransitionYearV2(
                        transition_year_fy_start=date(2027, 1, 1),
                        opening_deferred_tax_items=[
                            TransitionDeferredTaxItemV2(
                                label="Opening DTA",
                                item_type="DTA",
                                opening_balance=10.0,
                                tax_rate=0.25,
                                disallowed_under_article_9_1_2=True,
                            )
                        ],
                    ),
                )
            ],
        )

        last_resp: CalculationResponseV2 = calculate_v2(last_req)
        us_res = last_resp.results[0]
        self.assertIsNotNone(us_res.transition_year_state_closing)
        self.assertTrue(len(us_res.carryforwards_closing) > 0)

        payload = ScenarioAdvanceYearRequestV2(
            last_request=last_req,
            last_response=last_resp,
            options=ScenarioAdvanceYearOptionsV2(include_fx_placeholders=True),
        )
        adv = advance_year_scenario(payload)
        next_req = adv.next_request

        # FY advanced
        self.assertEqual(next_req.fiscal_year.start_date, date(2028, 1, 1))

        # Transition state carried forward
        tj_next = next_req.tested_jurisdictions[0]
        self.assertIsNotNone(tj_next.transition_year_state_opening)
        self.assertEqual(
            tj_next.transition_year_state_opening.transition_year_fy_start,
            us_res.transition_year_state_closing.transition_year_fy_start,
        )

        # Carryforwards carried forward
        self.assertGreaterEqual(len(tj_next.carryforwards_opening), 1)
        self.assertEqual(tj_next.carryforwards_opening[0].kind, us_res.carryforwards_closing[0].kind)

        # FX placeholder/copy exists for next FY
        fx_next = [r for r in next_req.fx_rates if r.currency == "USD" and r.fiscal_year_start == date(2028, 1, 1)]
        self.assertEqual(len(fx_next), 1)
        self.assertAlmostEqual(fx_next[0].avg_rate_to_reporting, 0.5)

        # Module 9: prior-year status auto-appended (Box 7.2 history builder)
        py = [r for r in (next_req.prior_years_status or []) if r.tested_jurisdiction_id == "US_MAIN" and r.fiscal_year_start == date(2027, 1, 1)]
        self.assertEqual(len(py), 1)
        self.assertEqual(py[0].regime, "SIMPLIFIED_ETR_SAFE_HARBOUR")
        self.assertEqual(py[0].topup_tax_status, "NONE")


    def test_advance_year_does_not_duplicate_prior_year_status(self):
        last_req = CalculationRequestV2(
            schema_version="2.2",
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            prior_years_status=[
                {
                    "tested_jurisdiction_id": "US_MAIN",
                    "fiscal_year_start": date(2027, 1, 1),
                    "regime": "SIMPLIFIED_ETR_SAFE_HARBOUR",
                    "topup_tax_status": "NONE",
                    "note": "pre-existing",
                }
            ],
            tested_jurisdictions=[
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="US_MAIN",
                    jurisdiction_code="US",
                    accounting_basis={"currency": "USD", "amount_scale": "UNITS"},
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    facts=JurisdictionFactsV2(jpbt=100.0, current_tax_expense=20.0),
                )
            ],
        )

        last_resp: CalculationResponseV2 = calculate_v2(last_req)

        payload = ScenarioAdvanceYearRequestV2(
            last_request=last_req,
            last_response=last_resp,
            options=ScenarioAdvanceYearOptionsV2(include_fx_placeholders=False, append_prior_year_status=True),
        )
        adv = advance_year_scenario(payload)
        next_req = adv.next_request

        py = [r for r in (next_req.prior_years_status or []) if r.tested_jurisdiction_id == "US_MAIN" and r.fiscal_year_start == date(2027, 1, 1)]
        self.assertEqual(len(py), 1)
        self.assertEqual(py[0].note, "pre-existing")


if __name__ == "__main__":
    unittest.main()
