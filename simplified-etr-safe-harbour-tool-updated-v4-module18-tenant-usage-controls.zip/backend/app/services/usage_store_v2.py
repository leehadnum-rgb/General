from __future__ import annotations

import os
import sqlite3
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional, Tuple


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _today_utc() -> str:
    return datetime.now(timezone.utc).date().isoformat()


def _data_dir() -> str:
    # Render containers always have a writable /tmp.
    return (os.getenv("DATA_DIR") or "/tmp/etr_safe_harbour").strip() or "/tmp/etr_safe_harbour"


def _db_path() -> str:
    # Share DB with storage-lite unless explicitly overridden.
    p = (os.getenv("USAGE_DB_PATH") or "").strip()
    if p:
        return p

    # If STORAGE_DB_PATH is set, follow it so usage tables share the same sqlite file.
    sp = (os.getenv("STORAGE_DB_PATH") or "").strip()
    if sp:
        return sp

    return os.path.join(_data_dir(), "storage.sqlite3")


def _ensure_dir(path: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)


def _connect() -> sqlite3.Connection:
    db = _db_path()
    _ensure_dir(db)
    conn = sqlite3.connect(db, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def _init(conn: sqlite3.Connection) -> None:
    # Per-tenant audit event log (basic).
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS audit_events (
          event_id TEXT PRIMARY KEY,
          tenant_id TEXT NOT NULL,
          ts TEXT NOT NULL,
          method TEXT,
          path TEXT,
          status_code INTEGER,
          duration_ms INTEGER,
          request_bytes INTEGER,
          response_bytes INTEGER,
          client_ip TEXT,
          user_agent TEXT,
          error_code TEXT
        );
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_audit_events_tenant_ts
        ON audit_events(tenant_id, ts);
        """
    )

    # Lightweight daily usage counters for quotas.
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS tenant_daily_usage (
          tenant_id TEXT NOT NULL,
          day TEXT NOT NULL,
          request_count INTEGER NOT NULL DEFAULT 0,
          calc_count INTEGER NOT NULL DEFAULT 0,
          export_count INTEGER NOT NULL DEFAULT 0,
          upload_bytes INTEGER NOT NULL DEFAULT 0,
          last_updated TEXT NOT NULL,
          PRIMARY KEY (tenant_id, day)
        );
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_tenant_daily_usage_day
        ON tenant_daily_usage(day);
        """
    )

    conn.commit()


@dataclass(frozen=True)
class DailyUsageRow:
    tenant_id: str
    day: str
    request_count: int
    calc_count: int
    export_count: int
    upload_bytes: int
    last_updated: str


class QuotaExceededError(RuntimeError):
    def __init__(self, message: str, error_code: str = "QUOTA_EXCEEDED"):
        super().__init__(message)
        self.error_code = error_code


def is_usage_controls_enabled() -> bool:
    # Enabled by default when auth is enabled (API_KEY/API_KEYS present),
    # unless explicitly disabled.
    v = (os.getenv("USAGE_CONTROLS_ENABLED") or "").strip().lower()
    if v in {"0", "false", "no"}:
        return False
    if v in {"1", "true", "yes"}:
        return True
    # auto mode: enable if auth configured
    return bool((os.getenv("API_KEY") or "").strip() or (os.getenv("API_KEYS") or "").strip())


def get_audit_retention_days() -> int:
    v = (os.getenv("AUDIT_LOG_RETENTION_DAYS") or "30").strip()
    try:
        n = int(v)
        return max(1, min(365, n))
    except ValueError:
        return 30


def _prune(conn: sqlite3.Connection) -> None:
    # Best-effort prune; keep simple to avoid overhead.
    days = get_audit_retention_days()
    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).replace(microsecond=0).isoformat()
    conn.execute("DELETE FROM audit_events WHERE ts < ?", (cutoff,))
    # Keep daily usage rows slightly longer (days + 7).
    cutoff_day = (datetime.now(timezone.utc).date() - timedelta(days=days + 7)).isoformat()
    conn.execute("DELETE FROM tenant_daily_usage WHERE day < ?", (cutoff_day,))
    conn.commit()


def record_audit_event(
    *,
    tenant_id: str,
    method: str,
    path: str,
    status_code: int,
    duration_ms: int,
    request_bytes: int,
    response_bytes: int,
    client_ip: Optional[str],
    user_agent: Optional[str],
    error_code: Optional[str],
) -> None:
    if not is_usage_controls_enabled():
        return

    event_id = str(uuid.uuid4())
    now = _now_iso()

    with _connect() as conn:
        _init(conn)
        conn.execute(
            """
            INSERT INTO audit_events (event_id, tenant_id, ts, method, path, status_code, duration_ms, request_bytes, response_bytes, client_ip, user_agent, error_code)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                event_id,
                tenant_id,
                now,
                method,
                path,
                int(status_code),
                int(duration_ms),
                int(request_bytes),
                int(response_bytes),
                client_ip,
                user_agent,
                error_code,
            ),
        )
        # prune occasionally (1% chance) to keep overhead negligible
        # Deterministic alternative would require tracking last prune time in DB.
        try:
            if uuid.uuid4().int % 100 == 0:
                _prune(conn)
        except Exception:
            pass
        conn.commit()


def _get_or_create_daily_row(conn: sqlite3.Connection, tenant_id: str, day: str) -> None:
    now = _now_iso()
    conn.execute(
        """
        INSERT INTO tenant_daily_usage (tenant_id, day, request_count, calc_count, export_count, upload_bytes, last_updated)
        VALUES (?, ?, 0, 0, 0, 0, ?)
        ON CONFLICT(tenant_id, day) DO NOTHING
        """,
        (tenant_id, day, now),
    )


def increment_daily_usage(
    tenant_id: str,
    *,
    day: Optional[str] = None,
    request_count: int = 0,
    calc_count: int = 0,
    export_count: int = 0,
    upload_bytes: int = 0,
) -> DailyUsageRow:
    if not is_usage_controls_enabled():
        # Return a synthetic row (not persisted)
        d = day or _today_utc()
        return DailyUsageRow(
            tenant_id=tenant_id,
            day=d,
            request_count=request_count,
            calc_count=calc_count,
            export_count=export_count,
            upload_bytes=upload_bytes,
            last_updated=_now_iso(),
        )

    d = day or _today_utc()
    now = _now_iso()

    with _connect() as conn:
        _init(conn)
        _get_or_create_daily_row(conn, tenant_id, d)
        conn.execute(
            """
            UPDATE tenant_daily_usage
            SET request_count = request_count + ?,
                calc_count = calc_count + ?,
                export_count = export_count + ?,
                upload_bytes = upload_bytes + ?,
                last_updated = ?
            WHERE tenant_id = ? AND day = ?
            """,
            (int(request_count), int(calc_count), int(export_count), int(upload_bytes), now, tenant_id, d),
        )
        conn.commit()
        return get_daily_usage(tenant_id, day=d)


def get_daily_usage(tenant_id: str, *, day: Optional[str] = None) -> DailyUsageRow:
    d = day or _today_utc()
    with _connect() as conn:
        _init(conn)
        row = conn.execute(
            """
            SELECT tenant_id, day, request_count, calc_count, export_count, upload_bytes, last_updated
            FROM tenant_daily_usage
            WHERE tenant_id = ? AND day = ?
            """,
            (tenant_id, d),
        ).fetchone()
        if row is None:
            return DailyUsageRow(
                tenant_id=tenant_id,
                day=d,
                request_count=0,
                calc_count=0,
                export_count=0,
                upload_bytes=0,
                last_updated=_now_iso(),
            )
        return DailyUsageRow(
            tenant_id=row["tenant_id"],
            day=row["day"],
            request_count=int(row["request_count"] or 0),
            calc_count=int(row["calc_count"] or 0),
            export_count=int(row["export_count"] or 0),
            upload_bytes=int(row["upload_bytes"] or 0),
            last_updated=row["last_updated"],
        )


def list_audit_events(
    tenant_id: str,
    *,
    limit: int = 100,
    offset: int = 0,
    since_ts: Optional[str] = None,
) -> Tuple[List[Dict[str, Any]], int, int]:
    limit = max(1, min(500, int(limit)))
    offset = max(0, int(offset))

    with _connect() as conn:
        _init(conn)
        args: List[Any] = [tenant_id]
        where = "WHERE tenant_id = ?"
        if since_ts and since_ts.strip():
            where += " AND ts >= ?"
            args.append(since_ts.strip())

        rows = conn.execute(
            f"""
            SELECT event_id, ts, method, path, status_code, duration_ms, request_bytes, response_bytes, client_ip, user_agent, error_code
            FROM audit_events
            {where}
            ORDER BY ts DESC
            LIMIT ? OFFSET ?
            """,
            (*args, limit, offset),
        ).fetchall()

        events: List[Dict[str, Any]] = []
        for r in rows:
            events.append(
                {
                    "event_id": r["event_id"],
                    "ts": r["ts"],
                    "method": r["method"],
                    "path": r["path"],
                    "status_code": int(r["status_code"] or 0),
                    "duration_ms": int(r["duration_ms"] or 0),
                    "request_bytes": int(r["request_bytes"] or 0),
                    "response_bytes": int(r["response_bytes"] or 0),
                    "client_ip": r["client_ip"],
                    "user_agent": r["user_agent"],
                    "error_code": r["error_code"],
                }
            )
        return events, limit, offset


def get_daily_calc_quota() -> int:
    v = (os.getenv("MAX_DAILY_CALCS_PER_TENANT") or "500").strip()
    try:
        n = int(v)
        return max(0, min(100000, n))
    except ValueError:
        return 500


def get_daily_export_quota() -> int:
    v = (os.getenv("MAX_DAILY_EXPORTS_PER_TENANT") or "500").strip()
    try:
        n = int(v)
        return max(0, min(100000, n))
    except ValueError:
        return 500


def get_daily_upload_bytes_quota() -> int:
    v = (os.getenv("MAX_DAILY_UPLOAD_BYTES_PER_TENANT") or "50000000").strip()
    try:
        n = int(v)
        return max(0, min(5_000_000_000, n))
    except ValueError:
        return 50_000_000


def enforce_daily_quota_or_raise(tenant_id: str, *, event: str, increment: int = 1, bytes_in: int = 0) -> None:
    if not is_usage_controls_enabled():
        return
    d = _today_utc()
    row = get_daily_usage(tenant_id, day=d)

    if event == "calc":
        limit = get_daily_calc_quota()
        if limit and (row.calc_count + increment) > limit:
            raise QuotaExceededError(
                f"Daily calc quota exceeded for tenant '{tenant_id}'. Limit={limit} per day.",
                error_code="QUOTA_DAILY_CALC_EXCEEDED",
            )
    elif event == "export":
        limit = get_daily_export_quota()
        if limit and (row.export_count + increment) > limit:
            raise QuotaExceededError(
                f"Daily export quota exceeded for tenant '{tenant_id}'. Limit={limit} per day.",
                error_code="QUOTA_DAILY_EXPORT_EXCEEDED",
            )
    elif event == "upload_bytes":
        limit = get_daily_upload_bytes_quota()
        if limit and (row.upload_bytes + bytes_in) > limit:
            raise QuotaExceededError(
                f"Daily upload quota exceeded for tenant '{tenant_id}'. Limit={limit} bytes per day.",
                error_code="QUOTA_DAILY_UPLOAD_BYTES_EXCEEDED",
            )
    else:
        # unknown event type: no-op
        return
