from __future__ import annotations

import csv
import io
import re
from datetime import date
from typing import Dict, List, Optional

from pydantic import BaseModel, Field

from app.services.models_v2 import PermanentEstablishmentV2

_NUM_RE = re.compile(r"[^0-9eE+\-\.]")

def _norm_header(h: str) -> str:
    h = (h or "").strip().lower()
    h = re.sub(r"[\s\-]+", "_", h)
    return h

_ALIASES: Dict[str, str] = {
    "pe": "pe_id",
    "peid": "pe_id",
    "pe_entity": "pe_entity_id",
    "pe_entityid": "pe_entity_id",
    "main_entity": "main_entity_id",
    "main_entityid": "main_entity_id",
    "host_tj": "pe_tested_jurisdiction_id",
    "pe_tj": "pe_tested_jurisdiction_id",
    "home_tj": "main_entity_tested_jurisdiction_id",
    "main_tj": "main_entity_tested_jurisdiction_id",
    "host_country": "pe_jurisdiction_code",
    "pe_country": "pe_jurisdiction_code",
    "home_country": "main_entity_jurisdiction_code",
    "main_country": "main_entity_jurisdiction_code",
    "taxable_branch": "taxable_branch_regime_applies",
}

def _parse_date(raw: str) -> Optional[date]:
    if raw is None:
        return None
    s = str(raw).strip()
    if s == "":
        return None
    try:
        return date.fromisoformat(s)
    except ValueError:
        return None

def _parse_bool(raw: str) -> Optional[bool]:
    if raw is None:
        return None
    s = str(raw).strip().lower()
    if s == "":
        return None
    if s in {"1", "true", "t", "yes", "y"}:
        return True
    if s in {"0", "false", "f", "no", "n"}:
        return False
    return None

class PermanentEstablishmentsCsvIssue(BaseModel):
    severity: str = Field(..., description="'error' or 'warning'")
    row_number: int = Field(..., ge=1, description="1-indexed row number in the CSV (excluding header).")
    field: Optional[str] = None
    message: str

class PermanentEstablishmentsCsvParseResult(BaseModel):
    permanent_establishments: List[PermanentEstablishmentV2] = Field(default_factory=list)
    issues: List[PermanentEstablishmentsCsvIssue] = Field(default_factory=list)
    detected_columns: List[str] = Field(default_factory=list)
    ignored_columns: List[str] = Field(default_factory=list)

def generate_permanent_establishments_csv_template() -> bytes:
    headers = [
        "pe_id",
        "pe_entity_id",
        "main_entity_id",
        "pe_tested_jurisdiction_id",
        "main_entity_tested_jurisdiction_id",
        "pe_jurisdiction_code",
        "main_entity_jurisdiction_code",
        "taxable_branch_regime_applies",
        "note",
    ]
    example = {
        "pe_id": "PE-001",
        "pe_entity_id": "DE-PE-1",
        "main_entity_id": "US-HO-1",
        "pe_tested_jurisdiction_id": "DE_MAIN",
        "main_entity_tested_jurisdiction_id": "US_MAIN",
        "pe_jurisdiction_code": "DE",
        "main_entity_jurisdiction_code": "US",
        "taxable_branch_regime_applies": "true",
        "note": "Example only",
    }
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=headers)
    w.writeheader()
    w.writerow(example)
    return buf.getvalue().encode("utf-8")

def parse_permanent_establishments_csv(contents: bytes) -> PermanentEstablishmentsCsvParseResult:
    text = contents.decode("utf-8-sig", errors="replace")
    buf = io.StringIO(text)
    reader = csv.DictReader(buf)
    if reader.fieldnames is None:
        return PermanentEstablishmentsCsvParseResult(
            permanent_establishments=[],
            issues=[PermanentEstablishmentsCsvIssue(severity="error", row_number=1, message="CSV is missing a header row.")],
        )

    raw_headers = list(reader.fieldnames)
    norm_to_raw: Dict[str, str] = {}
    for h in raw_headers:
        nh = _ALIASES.get(_norm_header(h), _norm_header(h))
        if nh and nh not in norm_to_raw:
            norm_to_raw[nh] = h

    allowed = set(PermanentEstablishmentV2.model_fields.keys())
    ignored = [raw for nh, raw in norm_to_raw.items() if nh not in allowed]
    out = PermanentEstablishmentsCsvParseResult(detected_columns=raw_headers, ignored_columns=ignored)

    rows: List[PermanentEstablishmentV2] = []
    for idx, row in enumerate(reader, start=1):
        data: Dict[str, object] = {}
        issues: List[PermanentEstablishmentsCsvIssue] = []

        for nh, raw in norm_to_raw.items():
            if nh not in allowed:
                continue
            val = row.get(raw)
            if nh in {"taxable_branch_regime_applies"}:
                b = _parse_bool(val)
                if b is not None:
                    data[nh] = b
            else:
                if val is None:
                    continue
                s = str(val).strip()
                if s == "":
                    continue
                data[nh] = s

        if not data.get("pe_id"):
            issues.append(PermanentEstablishmentsCsvIssue(severity="error", row_number=idx, field="pe_id", message="Missing pe_id."))
        if issues:
            out.issues.extend(issues)

        try:
            if issues and any(i.severity == "error" for i in issues):
                continue
            rows.append(PermanentEstablishmentV2.model_validate(data))
        except Exception as e:
            out.issues.append(PermanentEstablishmentsCsvIssue(severity="error", row_number=idx, message=f"Row validation failed: {e}"))

    out.permanent_establishments = rows
    return out
