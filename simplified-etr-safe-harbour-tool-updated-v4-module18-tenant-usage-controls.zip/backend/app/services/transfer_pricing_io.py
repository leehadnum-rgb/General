from __future__ import annotations

import csv
import io
import re
from datetime import date
from typing import Dict, List, Optional

from pydantic import BaseModel, Field

from app.services.models_v2 import TransferPricingAdjustmentV2


_NUM_RE = re.compile(r"[^0-9eE+\-\.]")


def _norm_header(h: str) -> str:
    h = (h or "").strip().lower()
    h = re.sub(r"[\s\-]+", "_", h)
    return h


_ALIASES: Dict[str, str] = {
    "tp_id": "adjustment_id",
    "tp_adjustment_id": "adjustment_id",
    "id": "adjustment_id",
    "seller_tj_id": "seller_tested_jurisdiction_id",
    "seller_id": "seller_tested_jurisdiction_id",
    "seller_tested_jurisdiction": "seller_tested_jurisdiction_id",
    "buyer_tj_id": "buyer_tested_jurisdiction_id",
    "buyer_id": "buyer_tested_jurisdiction_id",
    "buyer_tested_jurisdiction": "buyer_tested_jurisdiction_id",
    "transaction_year": "transaction_year_fy_start",
    "transaction_fy_start": "transaction_year_fy_start",
    "accrual_year": "accrual_year_fy_start",
    "accrual_fy_start": "accrual_year_fy_start",
    "months_after_year_end": "months_after_transaction_year_end",
    "within_12_months": "accrued_within_12_months",
    "seller_income": "seller_income_adjustment",
    "buyer_income": "buyer_income_adjustment",
    "seller_tax": "seller_tax_adjustment",
    "buyer_tax": "buyer_tax_adjustment",
    "tp_accounted_at_cost": "tp_accounted_at_cost",
    "tp_intangible_asset_related": "tp_intangible_asset_related",
    "tp_loss_disallowed": "tp_loss_disallowed_deemed_tp_adjustment",
    "tp_loss_disallowed_deemed_tp_adjustment": "tp_loss_disallowed_deemed_tp_adjustment",
}


def _parse_float(raw: str) -> Optional[float]:
    if raw is None:
        return None
    s = str(raw).strip()
    if s == "":
        return None
    s = _NUM_RE.sub("", s)
    if s in {"", "+", "-", "."}:
        return None
    try:
        return float(s)
    except ValueError:
        return None


def _parse_int(raw: str) -> Optional[int]:
    if raw is None:
        return None
    s = str(raw).strip()
    if s == "":
        return None
    try:
        return int(float(s))
    except ValueError:
        return None


def _parse_date(raw: str) -> Optional[date]:
    if raw is None:
        return None
    s = str(raw).strip()
    if s == "":
        return None
    try:
        return date.fromisoformat(s)
    except ValueError:
        return None


def _parse_bool(raw: str) -> Optional[bool]:
    if raw is None:
        return None
    s = str(raw).strip().lower()
    if s == "":
        return None
    if s in {"1", "true", "t", "yes", "y"}:
        return True
    if s in {"0", "false", "f", "no", "n"}:
        return False
    return None


class TransferPricingCsvIssue(BaseModel):
    severity: str = Field(..., description="'error' or 'warning'")
    row_number: int = Field(..., ge=1, description="1-indexed row number in the CSV (excluding header).")
    field: Optional[str] = Field(default=None, description="Column/field associated with the issue (if known).")
    message: str


class TransferPricingCsvParseResult(BaseModel):
    adjustments: List[TransferPricingAdjustmentV2] = Field(default_factory=list)
    issues: List[TransferPricingCsvIssue] = Field(default_factory=list)
    detected_columns: List[str] = Field(default_factory=list)
    ignored_columns: List[str] = Field(default_factory=list)


def generate_transfer_pricing_adjustments_csv_template() -> bytes:
    """Generate a CSV template for OECD section 5.2 transfer pricing adjustment register entries."""

    headers = [
        "adjustment_id",
        "label",
        "seller_tested_jurisdiction_id",
        "buyer_tested_jurisdiction_id",
        "transaction_year_fy_start",
        "accrual_year_fy_start",
        "months_after_transaction_year_end",
        "accrued_within_12_months",
        "seller_income_adjustment",
        "buyer_income_adjustment",
        "seller_tax_adjustment",
        "buyer_tax_adjustment",
        "tp_accounted_at_cost",
        "tp_intangible_asset_related",
        "tp_loss_disallowed_deemed_tp_adjustment",
        "currency",
        "amount_scale",
        "note",
    ]

    sample = {
        "adjustment_id": "TP-001",
        "label": "TP true-up within 12 months",
        "seller_tested_jurisdiction_id": "TJ_SELLER",
        "buyer_tested_jurisdiction_id": "TJ_BUYER",
        "transaction_year_fy_start": "2027-01-01",
        "accrual_year_fy_start": "2028-01-01",
        "months_after_transaction_year_end": "6",
        "accrued_within_12_months": "",
        "seller_income_adjustment": "100000",
        "buyer_income_adjustment": "",  # blank -> defaults to -seller income (unless special-case flags)
        "seller_tax_adjustment": "0",
        "buyer_tax_adjustment": "",
        "tp_accounted_at_cost": "false",
        "tp_intangible_asset_related": "false",
        "tp_loss_disallowed_deemed_tp_adjustment": "false",
        "currency": "EUR",
        "amount_scale": "UNITS",
        "note": "Example only",
    }

    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=headers)
    writer.writeheader()
    writer.writerow(sample)
    return buf.getvalue().encode("utf-8")


def parse_transfer_pricing_adjustments_csv(contents: bytes) -> TransferPricingCsvParseResult:
    text = contents.decode("utf-8-sig", errors="replace")
    buf = io.StringIO(text)
    reader = csv.DictReader(buf)
    if reader.fieldnames is None:
        return TransferPricingCsvParseResult(
            adjustments=[],
            issues=[TransferPricingCsvIssue(severity="error", row_number=1, field=None, message="CSV is missing a header row.")],
        )

    raw_headers = list(reader.fieldnames)
    norm_to_raw: Dict[str, str] = {}
    for h in raw_headers:
        nh = _norm_header(h)
        nh = _ALIASES.get(nh, nh)
        if nh and nh not in norm_to_raw:
            norm_to_raw[nh] = h

    detected = list(norm_to_raw.keys())
    allowed = set(TransferPricingAdjustmentV2.model_fields.keys())
    ignored_cols: List[str] = []
    for nh in detected:
        if nh not in allowed:
            ignored_cols.append(norm_to_raw.get(nh, nh))

    out = TransferPricingCsvParseResult(detected_columns=raw_headers, ignored_columns=ignored_cols)

    adjustments: List[TransferPricingAdjustmentV2] = []
    issues: List[TransferPricingCsvIssue] = []

    # Required fields
    req_fields = {
        "seller_tested_jurisdiction_id",
        "buyer_tested_jurisdiction_id",
        "transaction_year_fy_start",
        "accrual_year_fy_start",
    }

    for i, row in enumerate(reader, start=1):
        rownum = i
        parsed: Dict[str, object] = {}

        for nh, raw in norm_to_raw.items():
            if nh in ignored_cols:
                continue
            val = row.get(raw)

            if nh in {"seller_income_adjustment", "buyer_income_adjustment", "seller_tax_adjustment", "buyer_tax_adjustment"}:
                parsed[nh] = _parse_float(val)
            elif nh in {"months_after_transaction_year_end"}:
                parsed[nh] = _parse_int(val)
            elif nh in {"transaction_year_fy_start", "accrual_year_fy_start"}:
                parsed[nh] = _parse_date(val)
            elif nh in {"accrued_within_12_months", "tp_accounted_at_cost", "tp_intangible_asset_related", "tp_loss_disallowed_deemed_tp_adjustment"}:
                parsed[nh] = _parse_bool(val)
            else:
                if val is not None:
                    s = str(val).strip()
                    parsed[nh] = s if s != "" else None

        # Trim None values for optional fields so pydantic defaults can apply
        parsed = {k: v for k, v in parsed.items() if v is not None}

        missing = [f for f in req_fields if not parsed.get(f)]
        if missing:
            issues.append(
                TransferPricingCsvIssue(
                    severity="error",
                    row_number=rownum,
                    field=",".join(missing),
                    message="Missing required field(s): " + ", ".join(missing),
                )
            )
            continue

        # Apply defaults for numeric fields if omitted in CSV
        if "seller_income_adjustment" not in parsed:
            parsed["seller_income_adjustment"] = 0.0
        if "seller_tax_adjustment" not in parsed:
            parsed["seller_tax_adjustment"] = 0.0

        try:
            obj = TransferPricingAdjustmentV2.model_validate(parsed)
            adjustments.append(obj)
        except Exception as e:
            issues.append(
                TransferPricingCsvIssue(
                    severity="error",
                    row_number=rownum,
                    field=None,
                    message=str(e),
                )
            )

    out.adjustments = adjustments
    out.issues = issues
    return out
