from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import List, Optional

from app.services.models_v2 import EngineMetaV2

from app.services.auth_v2 import get_auth_config
from app.services.storage_v2 import _db_path
from app.services.usage_store_v2 import is_usage_controls_enabled, get_daily_calc_quota, get_daily_export_quota, get_daily_upload_bytes_quota



ENGINE_VERSION = os.getenv("ENGINE_VERSION", "0.1.0")


def get_engine_meta() -> EngineMetaV2:
    git_commit = (
        os.getenv("RENDER_GIT_COMMIT")
        or os.getenv("GIT_COMMIT")
        or os.getenv("COMMIT_SHA")
        or None
    )
    build_time = os.getenv("BUILD_TIMESTAMP") or None
    if build_time is None:
        # Best-effort; this is runtime time, not build time.
        build_time = datetime.now(timezone.utc).replace(microsecond=0).isoformat()

    auth_cfg = get_auth_config()

    return EngineMetaV2(
        api_version="v2",
        engine_version=ENGINE_VERSION,
        supported_schema_versions=EngineMetaV2.supported_schema_versions_default(),
        default_ruleset_version="OECD_SBS_2026_01",
        git_commit=git_commit,
        build_timestamp=build_time,

        auth_enabled=auth_cfg.enabled,
        api_key_header_name=auth_cfg.header_name if auth_cfg.enabled else None,
        storage_enabled=True,
        storage_backend="sqlite",
        storage_location=_db_path(),

        # Module 18
        usage_controls_enabled=is_usage_controls_enabled(),
        max_request_bytes=int((os.getenv("MAX_REQUEST_BYTES") or "2000000").strip() or "2000000"),
        max_upload_bytes=int((os.getenv("MAX_UPLOAD_BYTES") or "15000000").strip() or "15000000"),
        rate_limit_window_seconds=int((os.getenv("RATE_LIMIT_WINDOW_SECONDS") or "60").strip() or "60"),
        rate_limit_rpm_default=int((os.getenv("RATE_LIMIT_RPM_DEFAULT") or "600").strip() or "600"),
        rate_limit_rpm_calc=int((os.getenv("RATE_LIMIT_RPM_CALC") or "120").strip() or "120"),
        rate_limit_rpm_export=int((os.getenv("RATE_LIMIT_RPM_EXPORT") or "120").strip() or "120"),
        rate_limit_rpm_upload=int((os.getenv("RATE_LIMIT_RPM_UPLOAD") or "120").strip() or "120"),
        max_daily_calcs_per_tenant=get_daily_calc_quota(),
        max_daily_exports_per_tenant=get_daily_export_quota(),
        max_daily_upload_bytes_per_tenant=get_daily_upload_bytes_quota(),
        max_scenarios_per_tenant=int((os.getenv("MAX_SCENARIOS_PER_TENANT") or "200").strip() or "200"),
        max_total_runs_per_tenant=int((os.getenv("MAX_TOTAL_RUNS_PER_TENANT") or "2000").strip() or "2000"),
        max_storage_bytes_per_tenant=int((os.getenv("MAX_STORAGE_BYTES_PER_TENANT") or "200000000").strip() or "200000000"),
        max_runs_per_scenario=int((os.getenv("MAX_RUNS_PER_SCENARIO") or "50").strip() or "50"),
    )
