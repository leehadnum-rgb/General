from __future__ import annotations

from dataclasses import dataclass
from datetime import date

from app.services.models import CalculationRequest, JurisdictionInput, TraceLine


@dataclass
class EligibilityOutcome:
    eligible: bool
    reasons: list[str]
    trace: list[TraceLine]


def check_applicability_date(req: CalculationRequest) -> tuple[bool, str]:
    """Return (allowed, explanation) based on applicability date rules.

    OECD framework: FY commencing on/after 31 Dec 2026; optional earlier start (on/after 31 Dec 2025)
    only if certain conditions are met.
    """
    fy_start = req.fiscal_year_start_date

    if fy_start >= date(2026, 12, 31):
        return True, "FY start is on/after 31 Dec 2026."
    if fy_start >= date(2025, 12, 31):
        if not req.apply_optional_2025_start_rule:
            return False, "FY start is in 2025/2026 window; optional early-start rule not enabled in request."
        ok = (
            req.early_start_qdmtt_safe_harbour_applies
            or req.early_start_only_one_jurisdiction_has_taxing_rights
            or req.early_start_all_taxing_rights_jurisdictions_allow
        )
        if ok:
            return True, "FY start is on/after 31 Dec 2025 and early-start conditions are satisfied."
        return False, "FY start is on/after 31 Dec 2025 but none of the early-start conditions are satisfied."
    return False, "FY start is before 31 Dec 2025, outside applicability date."


def check_jurisdiction_eligibility(req: CalculationRequest, j: JurisdictionInput) -> EligibilityOutcome:
    reasons: list[str] = []
    trace: list[TraceLine] = []

    applies, note = check_applicability_date(req)
    trace.append(TraceLine(section="eligibility", step="Applicability date check", amount=0.0, note=note))
    if not applies:
        reasons.append(note)

    # Ineligible Tested Jurisdictions (Box 7.1)
    # - Stateless entities are ineligible except as provided in Section 6.2 (tax transparent entities).
    # - Investment entities are ineligible except as provided in Section 6.3 (Art 7.5 transparency election).
    if j.ineligible_stateless:
        if getattr(j, "stateless_exception_section_6_2_applies", False):
            trace.append(
                TraceLine(
                    section="eligibility",
                    step="Stateless entity: exception applies (Section 6.2)",
                    amount=0.0,
                )
            )
        else:
            reasons.append("Ineligible: stateless constituent entity tested jurisdiction.")
            trace.append(TraceLine(section="eligibility", step="Ineligible jurisdiction: stateless", amount=0.0))

    if j.ineligible_investment_entity:
        if getattr(j, "investment_entity_tax_transparency_election_applies", False):
            trace.append(
                TraceLine(
                    section="eligibility",
                    step="Investment entity: transparency election applies (Section 6.3 / Art 7.5)",
                    amount=0.0,
                )
            )
        else:
            reasons.append("Ineligible: investment entity tested jurisdiction (unless Section 6.3 applies).")
            trace.append(TraceLine(section="eligibility", step="Ineligible jurisdiction: investment entity", amount=0.0))
    if j.ineligible_article7_3_outstanding_recapture:
        reasons.append("Ineligible: Article 7.3 election with outstanding recapture account at FY start.")
        trace.append(TraceLine(section="eligibility", step="Ineligible jurisdiction: Article 7.3 outstanding", amount=0.0))

    # Entry / re-entry criteria (Box 7.2) – simplified boolean inputs for prototype
    if not j.no_topup_tax_in_prior_24_months:
        reasons.append("Entry criteria not met: Top-up tax existed within prior 24 months (as provided).")
        trace.append(TraceLine(section="eligibility", step="Entry criteria failed (24 months)", amount=0.0))

    if j.reentry_no_topup_tax_in_prior_24_months is False:
        reasons.append("Re-entry criteria not met: Top-up tax existed within prior 24 months after lapse (as provided).")
        trace.append(TraceLine(section="eligibility", step="Re-entry criteria failed (24 months)", amount=0.0))

    if not j.integrity_rules_satisfied:
        reasons.append("Integrity rules not satisfied (matching/allocation/single expense/single tax).")
        trace.append(TraceLine(section="eligibility", step="Integrity rules failed", amount=0.0))

    eligible = len(reasons) == 0
    return EligibilityOutcome(eligible=eligible, reasons=reasons, trace=trace)
