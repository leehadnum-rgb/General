from __future__ import annotations

import csv
import io
import re
from datetime import date
from typing import Dict, List, Optional

from pydantic import BaseModel, Field

from app.services.models_v2 import AllocableTaxItemV2

_NUM_RE = re.compile(r"[^0-9eE+\-\.]")

def _norm_header(h: str) -> str:
    h = (h or "").strip().lower()
    h = re.sub(r"[\s\-]+", "_", h)
    return h

_ALIASES: Dict[str, str] = {
    "article": "globe_article",
    "article_ref": "globe_article",
    "globe_article_ref": "globe_article",
    "source_tj": "source_tested_jurisdiction_id",
    "target_tj": "target_tested_jurisdiction_id",
    "withholding": "is_withholding_on_distribution",
    "pe_id": "related_pe_id",
    "flow_through_entity_id": "related_flow_through_entity_id",
    "fy_start": "fiscal_year_start",
}

def _parse_float(raw: str) -> Optional[float]:
    if raw is None:
        return None
    s = str(raw).strip()
    if s == "":
        return None
    s = _NUM_RE.sub("", s)
    if s in {"", "+", "-", "."}:
        return None
    try:
        return float(s)
    except ValueError:
        return None

def _parse_date(raw: str) -> Optional[date]:
    if raw is None:
        return None
    s = str(raw).strip()
    if s == "":
        return None
    try:
        return date.fromisoformat(s)
    except ValueError:
        return None

def _parse_bool(raw: str) -> Optional[bool]:
    if raw is None:
        return None
    s = str(raw).strip().lower()
    if s == "":
        return None
    if s in {"1", "true", "t", "yes", "y"}:
        return True
    if s in {"0", "false", "f", "no", "n"}:
        return False
    return None

class AllocableTaxItemsCsvIssue(BaseModel):
    severity: str = Field(..., description="'error' or 'warning'")
    row_number: int = Field(..., ge=1, description="1-indexed row number in the CSV (excluding header).")
    field: Optional[str] = None
    message: str

class AllocableTaxItemsCsvParseResult(BaseModel):
    allocable_tax_items: List[AllocableTaxItemV2] = Field(default_factory=list)
    issues: List[AllocableTaxItemsCsvIssue] = Field(default_factory=list)
    detected_columns: List[str] = Field(default_factory=list)
    ignored_columns: List[str] = Field(default_factory=list)

def generate_allocable_tax_items_csv_template() -> bytes:
    headers = [
        "item_id",
        "label",
        "globe_article",
        "amount",
        "source_tested_jurisdiction_id",
        "target_tested_jurisdiction_id",
        "is_withholding_on_distribution",
        "related_pe_id",
        "related_flow_through_entity_id",
        "fiscal_year_start",
        "currency",
        "amount_scale",
        "note",
    ]
    example = {
        "item_id": "ATI-001",
        "label": "Withholding tax on distribution",
        "globe_article": "4.3.2(b)",
        "amount": "10000",
        "source_tested_jurisdiction_id": "GB_MAIN",
        "target_tested_jurisdiction_id": "US_MAIN",
        "is_withholding_on_distribution": "true",
        "related_pe_id": "",
        "related_flow_through_entity_id": "",
        "fiscal_year_start": "2027-01-01",
        "currency": "GBP",
        "amount_scale": "UNITS",
        "note": "Example only",
    }
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=headers)
    w.writeheader()
    w.writerow(example)
    return buf.getvalue().encode("utf-8")

def parse_allocable_tax_items_csv(contents: bytes) -> AllocableTaxItemsCsvParseResult:
    text = contents.decode("utf-8-sig", errors="replace")
    buf = io.StringIO(text)
    reader = csv.DictReader(buf)
    if reader.fieldnames is None:
        return AllocableTaxItemsCsvParseResult(
            allocable_tax_items=[],
            issues=[AllocableTaxItemsCsvIssue(severity="error", row_number=1, message="CSV is missing a header row.")],
        )

    raw_headers = list(reader.fieldnames)
    norm_to_raw: Dict[str, str] = {}
    for h in raw_headers:
        nh = _ALIASES.get(_norm_header(h), _norm_header(h))
        if nh and nh not in norm_to_raw:
            norm_to_raw[nh] = h

    allowed = set(AllocableTaxItemV2.model_fields.keys())
    ignored = [raw for nh, raw in norm_to_raw.items() if nh not in allowed]
    out = AllocableTaxItemsCsvParseResult(detected_columns=raw_headers, ignored_columns=ignored)

    rows: List[AllocableTaxItemV2] = []
    for idx, row in enumerate(reader, start=1):
        data: Dict[str, object] = {}
        issues: List[AllocableTaxItemsCsvIssue] = []

        for nh, raw in norm_to_raw.items():
            if nh not in allowed:
                continue
            val = row.get(raw)
            if nh == "amount":
                f = _parse_float(val)
                if f is not None:
                    data[nh] = f
            elif nh == "fiscal_year_start":
                d = _parse_date(val)
                if d is not None:
                    data[nh] = d
            elif nh == "is_withholding_on_distribution":
                b = _parse_bool(val)
                if b is not None:
                    data[nh] = b
            else:
                if val is None:
                    continue
                s = str(val).strip()
                if s == "":
                    continue
                data[nh] = s

        if not data.get("globe_article"):
            issues.append(AllocableTaxItemsCsvIssue(severity="error", row_number=idx, field="globe_article", message="Missing globe_article (e.g., 4.3.2(b))."))
        if not data.get("amount"):
            issues.append(AllocableTaxItemsCsvIssue(severity="error", row_number=idx, field="amount", message="Missing amount (positive)."))
        if issues:
            out.issues.extend(issues)

        try:
            if issues and any(i.severity == "error" for i in issues):
                continue
            rows.append(AllocableTaxItemV2.model_validate(data))
        except Exception as e:
            out.issues.append(AllocableTaxItemsCsvIssue(severity="error", row_number=idx, message=f"Row validation failed: {e}"))

    out.allocable_tax_items = rows
    return out
