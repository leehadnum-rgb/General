import unittest
from datetime import date

from app.services.models_v2 import (
    CalculationRequestV2,
    FiscalYearV2,
    TestedJurisdictionInputV2,
    TestedJurisdictionCompositionV2,
    JurisdictionFactsV2,
    FlowThroughEntityAllocationV2,
    AllocableTaxItemV2,
    ElectionInstanceV2,
    PermanentEstablishmentV2,
)
from app.services.calculator_v2 import calculate_v2


class Module6AllocationsTests(unittest.TestCase):
    def _tj_facts(self, tj_id: str, country: str, jpbt: float, tax: float, elections=None):
        return TestedJurisdictionInputV2(
            tested_jurisdiction_id=tj_id,
            jurisdiction_code=country,
            composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
            facts=JurisdictionFactsV2(jpbt=jpbt, current_tax_expense=tax),
            elections=elections or [],
        )

    def test_flow_through_allocation_moves_income(self):
        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            tested_jurisdictions=[
                self._tj_facts("LU_FTE_TJ", "LU", jpbt=200.0, tax=0.0),
                self._tj_facts("GB_MAIN", "GB", jpbt=1000.0, tax=150.0),
            ],
            flow_through_entities=[
                FlowThroughEntityAllocationV2(
                    line_id="FTE-L1",
                    flow_through_entity_id="FTE_001",
                    flow_through_entity_name="Lux Transparent Partnership",
                    flow_through_tested_jurisdiction_id="LU_FTE_TJ",
                    owner_tested_jurisdiction_id="GB_MAIN",
                    fiscal_year_start=date(2027, 1, 1),
                    income_allocated_amount=200.0,
                    tax_allocated_amount=0.0,
                    currency=None,
                    amount_scale="UNITS",
                )
            ],
        )

        resp = calculate_v2(req)
        by_id = {r.tested_jurisdiction_id: r for r in resp.results}

        self.assertAlmostEqual(by_id["LU_FTE_TJ"].simplified_income_pre_allocations, 200.0, places=6)
        self.assertAlmostEqual(by_id["LU_FTE_TJ"].simplified_income_post_allocations, 0.0, places=6)
        self.assertAlmostEqual(by_id["GB_MAIN"].simplified_income_pre_allocations, 1000.0, places=6)
        self.assertAlmostEqual(by_id["GB_MAIN"].simplified_income_post_allocations, 1200.0, places=6)

        # Ledger exists on both sides
        self.assertTrue(any(e.source_type == "FLOW_THROUGH" and e.kind == "income" for e in by_id["LU_FTE_TJ"].allocation_ledger))
        self.assertTrue(any(e.source_type == "FLOW_THROUGH" and e.kind == "income" for e in by_id["GB_MAIN"].allocation_ledger))

    def test_allocable_tax_item_excluded_by_default(self):
        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            tested_jurisdictions=[self._tj_facts("GB_MAIN", "GB", jpbt=1000.0, tax=150.0)],
            allocable_tax_items=[
                AllocableTaxItemV2(
                    item_id="ATI-1",
                    label="WHT example",
                    globe_article="4.3.2(c)",
                    amount=10.0,
                    source_tested_jurisdiction_id="GB_MAIN",
                    target_tested_jurisdiction_id=None,
                    is_withholding_on_distribution=False,
                    fiscal_year_start=date(2027, 1, 1),
                    currency=None,
                    amount_scale="UNITS",
                )
            ],
        )

        resp = calculate_v2(req)
        r = resp.results[0]
        self.assertAlmostEqual(r.simplified_taxes_pre_allocations, 150.0, places=6)
        self.assertAlmostEqual(r.simplified_taxes_post_allocations, 140.0, places=6)
        self.assertTrue(any(e.source_type == "ALLOCABLE_TAX_ITEM" and e.operation == "EXCLUDE" for e in r.allocation_ledger))

    def test_allocable_tax_item_allocated_when_election_and_target(self):
        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            group_elections=[
                ElectionInstanceV2(
                    election_code="CROSS_BORDER_FIVE_YEAR_ELECTION_KEEP_ALLOCABLE_TAXES",
                    scope="metadata",
                    value_type="bool",
                    bool_value=True,
                    effective_fiscal_year_start=date(2027, 1, 1),
                )
            ],
            tested_jurisdictions=[
                self._tj_facts("GB_MAIN", "GB", jpbt=1000.0, tax=150.0),
                self._tj_facts("LU_TGT", "LU", jpbt=100.0, tax=0.0),
            ],
            allocable_tax_items=[
                AllocableTaxItemV2(
                    item_id="ATI-2",
                    label="Allocable tax",
                    globe_article="4.3.2(d)",
                    amount=10.0,
                    source_tested_jurisdiction_id="GB_MAIN",
                    target_tested_jurisdiction_id="LU_TGT",
                    is_withholding_on_distribution=False,
                    fiscal_year_start=date(2027, 1, 1),
                    currency=None,
                    amount_scale="UNITS",
                )
            ],
        )

        resp = calculate_v2(req)
        by_id = {r.tested_jurisdiction_id: r for r in resp.results}

        self.assertAlmostEqual(by_id["GB_MAIN"].simplified_taxes_post_allocations, 140.0, places=6)
        self.assertAlmostEqual(by_id["LU_TGT"].simplified_taxes_post_allocations, 10.0, places=6)
        self.assertTrue(any(e.operation == "ALLOCATE" for e in by_id["GB_MAIN"].allocation_ledger))
        self.assertTrue(any(e.operation == "ALLOCATE" for e in by_id["LU_TGT"].allocation_ledger))

    def test_pe_simplification_blocks_432a_allocation(self):
        # When PE simplification election is effective, the 5-year allocation election does not apply to 4.3.2(a) PE-linked items.
        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            group_elections=[
                ElectionInstanceV2(
                    election_code="CROSS_BORDER_FIVE_YEAR_ELECTION_KEEP_ALLOCABLE_TAXES",
                    scope="metadata",
                    value_type="bool",
                    bool_value=True,
                    effective_fiscal_year_start=date(2027, 1, 1),
                )
            ],
            tested_jurisdictions=[
                self._tj_facts("GB_MAIN", "GB", jpbt=1000.0, tax=150.0),
                self._tj_facts(
                    "DE_PE_TJ",
                    "DE",
                    jpbt=100.0,
                    tax=0.0,
                    elections=[
                        ElectionInstanceV2(
                            election_code="PE_SIMPLIFICATION_ELECTION_NOTE",
                            scope="metadata",
                            value_type="bool",
                            bool_value=True,
                            effective_fiscal_year_start=date(2027, 1, 1),
                        )
                    ],
                ),
            ],
            permanent_establishments=[
                PermanentEstablishmentV2(
                    pe_id="PE-001",
                    pe_tested_jurisdiction_id="DE_PE_TJ",
                    main_entity_tested_jurisdiction_id="GB_MAIN",
                    pe_jurisdiction_code="DE",
                    main_entity_jurisdiction_code="GB",
                    taxable_branch_regime_applies=True,
                )
            ],
            allocable_tax_items=[
                AllocableTaxItemV2(
                    item_id="ATI-3",
                    label="CFC/branch tax linked to PE",
                    globe_article="4.3.2(a)",
                    amount=10.0,
                    source_tested_jurisdiction_id="GB_MAIN",
                    target_tested_jurisdiction_id="DE_PE_TJ",
                    related_pe_id="PE-001",
                    fiscal_year_start=date(2027, 1, 1),
                    currency=None,
                    amount_scale="UNITS",
                )
            ],
        )

        resp = calculate_v2(req)
        by_id = {r.tested_jurisdiction_id: r for r in resp.results}

        # Default exclusion applies (subtract from source; do not allocate to target)
        self.assertAlmostEqual(by_id["GB_MAIN"].simplified_taxes_post_allocations, 140.0, places=6)
        self.assertAlmostEqual(by_id["DE_PE_TJ"].simplified_taxes_post_allocations, 0.0, places=6)
        self.assertTrue(any(e.operation == "EXCLUDE" for e in by_id["GB_MAIN"].allocation_ledger))


if __name__ == "__main__":
    unittest.main()
