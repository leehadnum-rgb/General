# Supply chain MVP API

This patch adds **three** new endpoints to support a graph-based supply chain UI:

- `GET /v1/jurisdictions`
- `POST /v1/supplychain/requirements`
- `POST /v1/supplychain/estimate`

The supply-chain endpoints **reuse** your existing single-leg endpoints by calling:
- `POST /v1/requirements`
- `POST /v1/estimate`

So your existing connectors, rule engine, and data ingestion remain the source of truth.

## Customs territory logic (MVP)

The supply chain layer introduces a simple concept of **customs territories** so you don't mistakenly treat internal movements as imports.

MVP territories:
- `EU`: EU member states (duty is collected at first entry; intra-EU legs are not imports)
- `CHLI`: Switzerland + Liechtenstein treated as a single customs territory
- Otherwise: each jurisdiction/country is its own territory

A shipment edge is treated as an **import event** only if it crosses a customs territory boundary, unless `forceImport: true` is set on the edge.

## `GET /v1/jurisdictions`

Returns supported destination jurisdictions (for UI dropdowns) plus the modeled customs territories.

Response:

```json
{
  "jurisdictions": [
    {
      "jurisdictionId": "GB",
      "name": "United Kingdom",
      "currency": "GBP",
      "vatLabel": "VAT",
      "mode": "LIVE",
      "customsTerritoryId": "GB"
    }
  ],
  "customsTerritories": [
    {
      "territoryId": "EU",
      "name": "European Union (customs territory)",
      "members": ["DE", "FR", "GR", "BE"]
    }
  ]
}
```

## `POST /v1/supplychain/requirements`

Purpose: given a graph scenario, returns which edges/lines are import events and the **required inputs** per line.

Request:

```json
{
  "asOfDate": "2026-02-27",
  "scenario": {
    "nodes": [
      {"nodeId":"n1","label":"Company A","countryIso2":"CN"},
      {"nodeId":"n2","label":"Supplier","countryIso2":"AU"},
      {"nodeId":"n3","label":"Warehouse","countryIso2":"GR"}
    ],
    "commodities": [
      {"commodityId":"c1","name":"Goods X","hsCode":"02031219","defaultOriginCountry":"AU"}
    ],
    "edges": [
      {
        "edgeId":"e1",
        "fromNodeId":"n2",
        "toNodeId":"n1",
        "lines":[{"lineId":"l1","commodityId":"c1"}]
      },
      {
        "edgeId":"e2",
        "fromNodeId":"n1",
        "toNodeId":"n3",
        "lines":[{"lineId":"l2","commodityId":"c1","originCountry":"AU"}]
      }
    ]
  }
}
```

Response:
- Each edge includes `type`:
  - `IMPORT_EVENT`
  - `NO_IMPORT_EVENT`
  - `INVALID_EDGE`
- For `IMPORT_EVENT` lines, `requirements` embeds the full `/v1/requirements` response.

## `POST /v1/supplychain/estimate`

Purpose: compute import taxes at each import-event edge/line.

Request is the same shape as `/v1/supplychain/requirements`, but each line should include the fields needed to compute `/v1/estimate`:

```json
{
  "asOfDate": "2026-02-27",
  "scenario": {
    "nodes": [
      {"nodeId":"n2","label":"Supplier","countryIso2":"AU"},
      {"nodeId":"n1","label":"Company A","countryIso2":"CN"}
    ],
    "edges": [
      {
        "edgeId":"e1",
        "fromNodeId":"n2",
        "toNodeId":"n1",
        "lines":[
          {
            "lineId":"l1",
            "hsCode":"02031219",
            "originCountry":"AU",
            "customsValue":{"amount":"1000.00","currency":"CNY"}
          }
        ]
      }
    ]
  }
}
```

Response:
- `edges[].lines[].estimate` embeds the full `/v1/estimate` response.
- Best-effort edge totals (`totals.totalTax`) are included if all line totals are in one currency.

## Anything.com graph builder notes

- Use `GET /v1/jurisdictions` for the destination dropdown.
- Use a standard ISO country list for origins and node locations (nodes can be ANY country).
- Compute requirements first (`/v1/supplychain/requirements`), then render a per-edge sidebar form using `requirements.inputs.required` / `recommended`.
- Then call `/v1/supplychain/estimate` and paint results onto edges.

## Wiring

After unzipping this patch into your repo, you must **register the new route plugins** in your API server:

- Import and `app.register(...)`:
  - `src/api/routes/jurisdictions.ts`
  - `src/api/routes/supplychain.ts`

