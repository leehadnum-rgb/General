# Anything.com prompts (Graph Builder MVP)

Use these prompts in Anything.com to add a graph builder UI that calls the new supply chain endpoints.

## Prompt 1 — Add API proxy endpoints

Create three backend proxy functions that call the Render API:

- `GET /api/tax/jurisdictions` -> forwards to `GET {API_BASE_URL}/v1/jurisdictions`
- `POST /api/tax/supplychain/requirements` -> forwards to `POST {API_BASE_URL}/v1/supplychain/requirements`
- `POST /api/tax/supplychain/estimate` -> forwards to `POST {API_BASE_URL}/v1/supplychain/estimate`

Ensure the proxy includes header `x-api-key: <API_KEY>`.

## Prompt 2 — Build the graph UI

Build a graph canvas UI (React Flow or similar) with:

- Nodes: location + label
  - fields: nodeId (auto), label, countryIso2, optional companyName
- Edges: shipments
  - selecting an edge opens a right sidebar editor

Sidebar editor for an edge:
- fromNode and toNode (read-only)
- add shipment lines
  - hsCode (digits only)
  - originCountry (ISO2)
  - customsValue amount + currency
  - optional freightToBorder + insuranceToBorder
  - optional netMassKg / quantity / volumeLitre

## Prompt 3 — Requirements and estimate actions

Add two top-level actions:

1) "Compute requirements"
- call `POST /api/tax/supplychain/requirements` with the full scenario JSON
- for each edge:
  - if type == NO_IMPORT_EVENT, show a grey label: "No import (same customs territory)"
  - if type == IMPORT_EVENT, highlight edge if any line has requirements errors

2) "Estimate taxes"
- call `POST /api/tax/supplychain/estimate` with the scenario JSON
- render per-edge totals (totalTax) on the edge label
- clicking an edge shows a breakdown per line from the embedded estimate response

## Prompt 4 — UX guardrails (MVP)

- Always require originCountry and customsValue for lines on import-event edges
- Show a warning banner if any estimate or requirements call failed for a line
- Do NOT attempt to compute FX or infer customs value across legs in MVP

