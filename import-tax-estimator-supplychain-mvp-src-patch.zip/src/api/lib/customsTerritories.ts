import { isEuJurisdiction } from "./jurisdictions";

export type CustomsTerritoryId = string;

export type CustomsTerritory = {
  territoryId: CustomsTerritoryId;
  name: string;
  members: string[];
};

// NOTE: This is intentionally small and opinionated for MVP.
// We model customs *territories* (customs unions / shared territories) so we can
// avoid charging "import" taxes on internal movements.
//
// Current territories:
// - EU: EU member states (duty collected at first entry; intra-EU legs are not imports)
// - CHLI: Switzerland + Liechtenstein (MVP: treated as one territory)
// - DEFAULT: each jurisdiction/country is its own territory

export function jurisdictionToCustomsTerritoryId(jurisdictionId: string): CustomsTerritoryId {
  const j = String(jurisdictionId ?? "").trim().toUpperCase();
  if (!j) return "UNKNOWN";
  if (isEuJurisdiction(j)) return "EU";
  if (j === "CH" || j === "LI") return "CHLI";
  return j;
}

export function listCustomsTerritories(supportedJurisdictions: string[]): CustomsTerritory[] {
  const euMembers = supportedJurisdictions
    .map((x) => String(x).toUpperCase())
    .filter((x) => isEuJurisdiction(x));

  const chliMembers = supportedJurisdictions
    .map((x) => String(x).toUpperCase())
    .filter((x) => x === "CH" || x === "LI");

  const territories: CustomsTerritory[] = [];

  if (euMembers.length) {
    territories.push({
      territoryId: "EU",
      name: "European Union (customs territory)",
      members: Array.from(new Set(euMembers)).sort(),
    });
  }

  if (chliMembers.length) {
    territories.push({
      territoryId: "CHLI",
      name: "Switzerland + Liechtenstein (customs territory)",
      members: Array.from(new Set(chliMembers)).sort(),
    });
  }

  return territories;
}
