import { jurisdictionToCustomsTerritoryId } from "./customsTerritories";

export type SupplyChainNode = {
  nodeId: string;
  label?: string;
  countryIso2: string; // e.g. CN, AU, GR
  jurisdictionId?: string; // optional override; default = countryIso2
  companyName?: string;
};

export type SupplyChainCommodity = {
  commodityId: string;
  name: string;
  hsCode: string;
  defaultOriginCountry: string;
  notes?: string;
};

export type Money = { amount: string; currency: string };
export type Quantity = { amount: string; unit: string };

export type SupplyChainLine = {
  lineId: string;
  commodityId?: string;
  hsCode?: string;
  originCountry?: string;

  customsValue?: Money;
  freightToBorder?: Money;
  insuranceToBorder?: Money;

  netMassKg?: string;
  grossMassKg?: string;
  volumeLitre?: string;
  quantity?: Quantity;

  originBasis?: "MANUAL" | "WHOLLY_OBTAINED" | "SUBSTANTIAL_TRANSFORMATION" | "RVC" | "CTH" | "UNKNOWN";
  qualifiesForPreference?: "YES" | "NO" | "UNKNOWN";
  transformationRef?: string;
};

export type SupplyChainEdge = {
  edgeId: string;
  fromNodeId: string;
  toNodeId: string;
  incoterm?: string;
  importProcedure?: string;
  forceImport?: boolean;
  lines: SupplyChainLine[];
};

export type SupplyChainScenario = {
  nodes: SupplyChainNode[];
  edges: SupplyChainEdge[];
  commodities?: SupplyChainCommodity[];
  transformations?: any[];
};

export type EdgeClassification = {
  edgeId: string;
  fromNodeId: string;
  toNodeId: string;
  fromJurisdictionId: string;
  toJurisdictionId: string;
  fromTerritoryId: string;
  toTerritoryId: string;
  isImportEvent: boolean;
  reason: string;
};

export function normalizeIso2(x: string | undefined | null): string {
  return String(x ?? "").trim().toUpperCase();
}

export function normalizeHsCodeDigits(x: string | undefined | null): string {
  return String(x ?? "").replace(/[^0-9]/g, "");
}

export function indexScenario(s: SupplyChainScenario): {
  nodesById: Map<string, SupplyChainNode>;
  commoditiesById: Map<string, SupplyChainCommodity>;
} {
  const nodesById = new Map<string, SupplyChainNode>();
  for (const n of s.nodes ?? []) {
    nodesById.set(String(n.nodeId), n);
  }

  const commoditiesById = new Map<string, SupplyChainCommodity>();
  for (const c of s.commodities ?? []) {
    commoditiesById.set(String(c.commodityId), c);
  }

  return { nodesById, commoditiesById };
}

export function nodeJurisdictionId(n: SupplyChainNode | undefined | null): string {
  const j = normalizeIso2(n?.jurisdictionId || n?.countryIso2);
  return j || "UNKNOWN";
}

export function classifyEdge(edge: SupplyChainEdge, nodesById: Map<string, SupplyChainNode>): EdgeClassification {
  const fromNode = nodesById.get(String(edge.fromNodeId));
  const toNode = nodesById.get(String(edge.toNodeId));

  const fromJurisdictionId = nodeJurisdictionId(fromNode);
  const toJurisdictionId = nodeJurisdictionId(toNode);

  const fromTerritoryId = jurisdictionToCustomsTerritoryId(fromJurisdictionId);
  const toTerritoryId = jurisdictionToCustomsTerritoryId(toJurisdictionId);

  const forced = Boolean(edge.forceImport);
  const crosses = fromTerritoryId !== toTerritoryId;
  const isImportEvent = forced || crosses;

  const reason = forced
    ? "forced_import"
    : crosses
      ? "crosses_customs_territory"
      : "same_customs_territory";

  return {
    edgeId: String(edge.edgeId),
    fromNodeId: String(edge.fromNodeId),
    toNodeId: String(edge.toNodeId),
    fromJurisdictionId,
    toJurisdictionId,
    fromTerritoryId,
    toTerritoryId,
    isImportEvent,
    reason,
  };
}

export function resolveLine(
  line: SupplyChainLine,
  commoditiesById: Map<string, SupplyChainCommodity>
): {
  lineId: string;
  hsCode: string;
  originCountry: string;
  money: { customsValue?: Money; freightToBorder?: Money; insuranceToBorder?: Money };
  quantities: {
    netMassKg?: string;
    grossMassKg?: string;
    volumeLitre?: string;
    quantity?: Quantity;
  };
  metadata: {
    commodityId?: string;
    originBasis?: SupplyChainLine["originBasis"];
    qualifiesForPreference?: SupplyChainLine["qualifiesForPreference"];
    transformationRef?: string;
  };
} {
  const commodity = line.commodityId ? commoditiesById.get(String(line.commodityId)) : undefined;

  const hsCode = normalizeHsCodeDigits(line.hsCode ?? commodity?.hsCode);
  const originCountry = normalizeIso2(line.originCountry ?? commodity?.defaultOriginCountry);

  return {
    lineId: String(line.lineId),
    hsCode,
    originCountry,
    money: {
      customsValue: line.customsValue,
      freightToBorder: line.freightToBorder,
      insuranceToBorder: line.insuranceToBorder,
    },
    quantities: {
      netMassKg: line.netMassKg,
      grossMassKg: line.grossMassKg,
      volumeLitre: line.volumeLitre,
      quantity: line.quantity,
    },
    metadata: {
      commodityId: line.commodityId,
      originBasis: line.originBasis,
      qualifiesForPreference: line.qualifiesForPreference,
      transformationRef: line.transformationRef,
    },
  };
}
