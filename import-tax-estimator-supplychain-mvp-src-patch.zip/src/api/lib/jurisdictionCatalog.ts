import { SUPPORTED_JURISDICTIONS, isEuJurisdiction } from "./jurisdictions";
import { jurisdictionToCustomsTerritoryId } from "./customsTerritories";

export type JurisdictionMode = "LIVE" | "INGESTED" | "ALIAS";

export type JurisdictionInfo = {
  jurisdictionId: string;
  name: string;
  currency: string;
  vatLabel: string;
  mode: JurisdictionMode;
  customsTerritoryId: string;
};

// NOTE: This is display metadata for UI (Anything graph builder).
// The calculation engine remains the source of truth; the UI should still call
// /v1/requirements and /v1/estimate for actual currency/rules.
//
// If we don't recognize a jurisdiction, we still include it with minimal info.

const NAME_MAP: Record<string, string> = {
  US: "United States",
  CA: "Canada",
  GB: "United Kingdom",
  NZ: "New Zealand",
  CH: "Switzerland",
  LI: "Liechtenstein",
  NO: "Norway",
  IS: "Iceland",
  AU: "Australia",
  JP: "Japan",
  SG: "Singapore",
  HK: "Hong Kong",
  // EU (member state names)
  AT: "Austria",
  BE: "Belgium",
  BG: "Bulgaria",
  CY: "Cyprus",
  CZ: "Czechia",
  DE: "Germany",
  DK: "Denmark",
  EE: "Estonia",
  ES: "Spain",
  FI: "Finland",
  FR: "France",
  GR: "Greece",
  HR: "Croatia",
  HU: "Hungary",
  IE: "Ireland",
  IT: "Italy",
  LT: "Lithuania",
  LU: "Luxembourg",
  LV: "Latvia",
  MT: "Malta",
  NL: "Netherlands",
  PL: "Poland",
  PT: "Portugal",
  RO: "Romania",
  SE: "Sweden",
  SI: "Slovenia",
  SK: "Slovakia",
};

const CURRENCY_MAP: Record<string, string> = {
  US: "USD",
  CA: "CAD",
  GB: "GBP",
  NZ: "NZD",
  CH: "CHF",
  LI: "CHF",
  NO: "NOK",
  IS: "ISK",
  AU: "AUD",
  JP: "JPY",
  SG: "SGD",
  HK: "HKD",
};

function vatLabelFor(j: string): string {
  if (isEuJurisdiction(j)) return "VAT";
  if (j === "GB") return "VAT";
  if (j === "NZ" || j === "SG" || j === "AU" || j === "CA") return "GST";
  if (j === "JP") return "Consumption Tax";
  if (j === "HK" || j === "US") return "Tax";
  if (j === "CH" || j === "LI" || j === "NO" || j === "IS") return "VAT";
  return "Tax";
}

function modeFor(j: string): JurisdictionMode {
  if (j === "GB" || j === "HK" || j === "SG" || isEuJurisdiction(j)) return "LIVE";
  if (j === "LI") return "ALIAS";
  // Everything else currently in this tool is ingested.
  return "INGESTED";
}

export function listJurisdictions(): JurisdictionInfo[] {
  const ids = (SUPPORTED_JURISDICTIONS ?? []).map((x) => String(x).toUpperCase());
  const uniq = Array.from(new Set(ids)).sort();

  return uniq.map((id) => {
    const name = NAME_MAP[id] ?? id;
    const currency = isEuJurisdiction(id) ? "EUR" : (CURRENCY_MAP[id] ?? id);
    const vatLabel = vatLabelFor(id);
    const mode = modeFor(id);
    const customsTerritoryId = jurisdictionToCustomsTerritoryId(id);

    return { jurisdictionId: id, name, currency, vatLabel, mode, customsTerritoryId };
  });
}
