import type { FastifyInstance } from "fastify";
import { listJurisdictions } from "../lib/jurisdictionCatalog";
import { listCustomsTerritories } from "../lib/customsTerritories";
import { SUPPORTED_JURISDICTIONS } from "../lib/jurisdictions";

export default async function jurisdictionsRoutes(app: FastifyInstance) {
  app.get("/v1/jurisdictions", async (_req, reply) => {
    const jurisdictions = listJurisdictions();
    const customsTerritories = listCustomsTerritories(SUPPORTED_JURISDICTIONS);

    return reply.send({
      jurisdictions,
      customsTerritories,
    });
  });
}
