import type { FastifyInstance } from "fastify";
import { z } from "zod";
import {
  classifyEdge,
  indexScenario,
  resolveLine,
  type SupplyChainScenario,
} from "../lib/supplychain";

// --- Zod schemas (MVP) -------------------------------------------------------

const Iso2 = z
  .string()
  .transform((s) => String(s ?? "").trim().toUpperCase())
  .refine((s) => /^[A-Z]{2}$/.test(s), "Expected ISO alpha-2 country code");

const HsCode = z
  .string()
  .transform((s) => String(s ?? "").replace(/[^0-9]/g, ""))
  .refine((s) => s.length >= 2, "HS code must have at least 2 digits");

const Money = z.object({
  amount: z.string(),
  currency: z.string().transform((s) => String(s ?? "").trim().toUpperCase()),
});

const Quantity = z.object({
  amount: z.string(),
  unit: z.string(),
});

const Node = z.object({
  nodeId: z.string(),
  label: z.string().optional(),
  countryIso2: Iso2,
  jurisdictionId: z.string().optional(),
  companyName: z.string().optional(),
});

const Commodity = z.object({
  commodityId: z.string(),
  name: z.string(),
  hsCode: HsCode,
  defaultOriginCountry: Iso2,
  notes: z.string().optional(),
});

const Line = z.object({
  lineId: z.string(),
  commodityId: z.string().optional(),
  hsCode: HsCode.optional(),
  originCountry: Iso2.optional(),

  customsValue: Money.optional(),
  freightToBorder: Money.optional(),
  insuranceToBorder: Money.optional(),

  netMassKg: z.string().optional(),
  grossMassKg: z.string().optional(),
  volumeLitre: z.string().optional(),
  quantity: Quantity.optional(),

  originBasis: z
    .enum([
      "MANUAL",
      "WHOLLY_OBTAINED",
      "SUBSTANTIAL_TRANSFORMATION",
      "RVC",
      "CTH",
      "UNKNOWN",
    ])
    .optional(),
  qualifiesForPreference: z.enum(["YES", "NO", "UNKNOWN"]).optional(),
  transformationRef: z.string().optional(),
});

const Edge = z.object({
  edgeId: z.string(),
  fromNodeId: z.string(),
  toNodeId: z.string(),
  incoterm: z.string().optional(),
  importProcedure: z.string().optional(),
  forceImport: z.boolean().optional(),
  lines: z.array(Line).min(1),
});

const Scenario = z.object({
  nodes: z.array(Node).min(1),
  edges: z.array(Edge).min(1),
  commodities: z.array(Commodity).optional(),
  transformations: z.array(z.any()).optional(),
});

const SupplyChainRequest = z.object({
  asOfDate: z.string().optional(),
  scenario: Scenario,
});

// --- Internal inject helpers -------------------------------------------------

function internalHeaders(): Record<string, string> {
  const headers: Record<string, string> = {
    "content-type": "application/json",
  };
  // If API_KEY is configured, internal calls must pass it because inject() runs hooks.
  if (process.env.API_KEY) headers["x-api-key"] = String(process.env.API_KEY);
  return headers;
}

async function injectJson(app: FastifyInstance, url: string, payload: any): Promise<{ status: number; body: any; raw: string }>
{
  const res = await app.inject({
    method: "POST",
    url,
    headers: internalHeaders(),
    payload: JSON.stringify(payload),
  });

  const raw = res.body ?? "";
  let body: any = null;
  try {
    body = raw ? JSON.parse(raw) : null;
  } catch {
    body = raw;
  }

  return { status: res.statusCode, body, raw };
}

function todayIso(): string {
  return new Date().toISOString().slice(0, 10);
}

function get(obj: any, path: string[]): any {
  let cur: any = obj;
  for (const p of path) {
    if (cur == null) return undefined;
    cur = cur[p];
  }
  return cur;
}

function extractCurrencyFromRequirements(reqBody: any): string | undefined {
  return (
    get(reqBody, ["jurisdiction", "currency"]) ||
    get(reqBody, ["jurisdiction", "currencyCode"]) ||
    get(reqBody, ["currency"]) ||
    get(reqBody, ["result", "currency"]) ||
    undefined
  );
}

function extractTotalTaxAmount(estimateBody: any): { amount: number; currency?: string } | null {
  const total =
    get(estimateBody, ["totalTax"]) ||
    get(estimateBody, ["result", "totalTax"]) ||
    get(estimateBody, ["totals", "totalTax"]);

  if (!total) return null;
  const amtRaw = total.amount ?? total.value ?? total;
  const currency = total.currency ?? total.ccy;
  const n = Number(amtRaw);
  if (!Number.isFinite(n)) return null;
  return { amount: n, currency };
}

// --- Routes -----------------------------------------------------------------

export default async function supplyChainRoutes(app: FastifyInstance) {
  // Requirements: tells the UI what inputs are needed per import-event leg/line.
  app.post("/v1/supplychain/requirements", async (req, reply) => {
    const parsed = SupplyChainRequest.parse((req as any).body);
    const asOfDate = (parsed.asOfDate ?? todayIso()).slice(0, 10);

    const scenario = parsed.scenario as unknown as SupplyChainScenario;
    const { nodesById, commoditiesById } = indexScenario(scenario);

    const reqCache = new Map<string, any>();

    const edgesOut: any[] = [];

    for (const edge of scenario.edges) {
      const cls = classifyEdge(edge, nodesById);

      // Validate nodes exist
      if (!nodesById.get(String(edge.fromNodeId)) || !nodesById.get(String(edge.toNodeId))) {
        edgesOut.push({
          ...cls,
          type: "INVALID_EDGE",
          message: "Edge references unknown nodeId",
          lines: edge.lines.map((l) => ({ lineId: l.lineId, error: "invalid_edge" })),
        });
        continue;
      }

      if (!cls.isImportEvent) {
        edgesOut.push({
          ...cls,
          type: "NO_IMPORT_EVENT",
          message: "No import event: movement stays within the same customs territory.",
          lines: edge.lines.map((l) => {
            const r = resolveLine(l, commoditiesById);
            return {
              lineId: r.lineId,
              hsCode: r.hsCode,
              originCountry: r.originCountry,
              requirements: null,
              note: "no_import_event",
            };
          }),
        });
        continue;
      }

      // Import event: compute requirements for each line using existing /v1/requirements.
      const linesOut: any[] = [];

      for (const line of edge.lines) {
        const r = resolveLine(line, commoditiesById);

        if (!r.hsCode) {
          linesOut.push({ lineId: r.lineId, hsCode: "", error: "missing_hs_code" });
          continue;
        }

        const cacheKey = `${cls.toJurisdictionId}:${asOfDate}:${r.hsCode}`;
        let reqRes = reqCache.get(cacheKey);
        if (!reqRes) {
          reqRes = await injectJson(app, "/v1/requirements", {
            jurisdictionId: cls.toJurisdictionId,
            code: r.hsCode,
            asOfDate,
          });
          reqCache.set(cacheKey, reqRes);
        }

        if (reqRes.status < 200 || reqRes.status >= 300) {
          linesOut.push({
            lineId: r.lineId,
            hsCode: r.hsCode,
            originCountry: r.originCountry,
            error: "requirements_failed",
            status: reqRes.status,
            body: reqRes.body,
          });
          continue;
        }

        linesOut.push({
          lineId: r.lineId,
          hsCode: r.hsCode,
          originCountry: r.originCountry,
          requirements: reqRes.body,
        });
      }

      edgesOut.push({
        ...cls,
        type: "IMPORT_EVENT",
        message: "Import event: crosses customs territory boundary.",
        destinationJurisdictionId: cls.toJurisdictionId,
        asOfDate,
        lines: linesOut,
      });
    }

    return reply.send({ asOfDate, edges: edgesOut });
  });

  // Estimate: runs the chain by calling existing /v1/estimate per import-event leg/line.
  app.post("/v1/supplychain/estimate", async (req, reply) => {
    const parsed = SupplyChainRequest.parse((req as any).body);
    const asOfDate = (parsed.asOfDate ?? todayIso()).slice(0, 10);

    const scenario = parsed.scenario as unknown as SupplyChainScenario;
    const { nodesById, commoditiesById } = indexScenario(scenario);

    const reqCache = new Map<string, any>();

    const edgesOut: any[] = [];

    // Running totals (best-effort)
    let totalTaxSum: number | null = 0;
    let totalTaxCurrency: string | null = null;

    for (const edge of scenario.edges) {
      const cls = classifyEdge(edge, nodesById);

      if (!nodesById.get(String(edge.fromNodeId)) || !nodesById.get(String(edge.toNodeId))) {
        edgesOut.push({
          ...cls,
          type: "INVALID_EDGE",
          message: "Edge references unknown nodeId",
          lines: edge.lines.map((l) => ({ lineId: l.lineId, error: "invalid_edge" })),
        });
        continue;
      }

      if (!cls.isImportEvent) {
        edgesOut.push({
          ...cls,
          type: "NO_IMPORT_EVENT",
          message: "No import event: movement stays within the same customs territory.",
          totals: null,
          lines: edge.lines.map((l) => {
            const r = resolveLine(l, commoditiesById);
            return {
              lineId: r.lineId,
              hsCode: r.hsCode,
              originCountry: r.originCountry,
              estimate: null,
              note: "no_import_event",
            };
          }),
        });
        continue;
      }

      const linesOut: any[] = [];
      let edgeTotalTax: number | null = 0;
      let edgeCurrency: string | null = null;

      for (const line of edge.lines) {
        const r = resolveLine(line, commoditiesById);

        if (!r.hsCode) {
          linesOut.push({ lineId: r.lineId, hsCode: "", error: "missing_hs_code" });
          edgeTotalTax = null;
          continue;
        }

        // Fetch requirements (cached) to discover destination currency.
        const cacheKey = `${cls.toJurisdictionId}:${asOfDate}:${r.hsCode}`;
        let reqRes = reqCache.get(cacheKey);
        if (!reqRes) {
          reqRes = await injectJson(app, "/v1/requirements", {
            jurisdictionId: cls.toJurisdictionId,
            code: r.hsCode,
            asOfDate,
          });
          reqCache.set(cacheKey, reqRes);
        }

        const destCurrency = reqRes.status >= 200 && reqRes.status < 300 ? extractCurrencyFromRequirements(reqRes.body) : undefined;

        // Build estimate payload (MVP: assume user provided correct per-line values).
        const payload: any = {
          jurisdictionId: cls.toJurisdictionId,
          code: r.hsCode,
          asOfDate,
          originCountry: r.originCountry,
          currency: r.money.customsValue?.currency || destCurrency,
          customsValue: r.money.customsValue,
          freightToBorder: r.money.freightToBorder,
          insuranceToBorder: r.money.insuranceToBorder,
          netMassKg: r.quantities.netMassKg,
          grossMassKg: r.quantities.grossMassKg,
          volumeLitre: r.quantities.volumeLitre,
          quantity: r.quantities.quantity,
        };

        const estRes = await injectJson(app, "/v1/estimate", payload);

        if (estRes.status < 200 || estRes.status >= 300) {
          linesOut.push({
            lineId: r.lineId,
            hsCode: r.hsCode,
            originCountry: r.originCountry,
            error: "estimate_failed",
            status: estRes.status,
            body: estRes.body,
          });
          edgeTotalTax = null;
          continue;
        }

        linesOut.push({
          lineId: r.lineId,
          hsCode: r.hsCode,
          originCountry: r.originCountry,
          estimate: estRes.body,
        });

        const tt = extractTotalTaxAmount(estRes.body);
        if (!tt) {
          edgeTotalTax = null;
          continue;
        }

        const ccy = tt.currency || payload.currency || destCurrency || null;
        if (!ccy) {
          edgeTotalTax = null;
          continue;
        }

        if (edgeCurrency == null) edgeCurrency = ccy;
        if (edgeCurrency !== ccy) {
          // Mixed currency edge – we don't sum.
          edgeTotalTax = null;
        } else if (edgeTotalTax != null) {
          edgeTotalTax += tt.amount;
        }
      }

      // Accumulate overall totals if we can
      if (edgeTotalTax != null && edgeCurrency != null) {
        if (totalTaxCurrency == null) totalTaxCurrency = edgeCurrency;
        if (totalTaxCurrency !== edgeCurrency) {
          totalTaxSum = null;
        } else if (totalTaxSum != null) {
          totalTaxSum += edgeTotalTax;
        }
      } else {
        totalTaxSum = null;
      }

      edgesOut.push({
        ...cls,
        type: "IMPORT_EVENT",
        message: "Import event: crosses customs territory boundary.",
        destinationJurisdictionId: cls.toJurisdictionId,
        asOfDate,
        totals: edgeTotalTax != null && edgeCurrency ? { totalTax: { amount: String(edgeTotalTax.toFixed(2)), currency: edgeCurrency } } : null,
        lines: linesOut,
      });
    }

    const totals =
      totalTaxSum != null && totalTaxCurrency
        ? { totalTax: { amount: String(totalTaxSum.toFixed(2)), currency: totalTaxCurrency } }
        : null;

    return reply.send({ asOfDate, edges: edgesOut, totals });
  });
}
