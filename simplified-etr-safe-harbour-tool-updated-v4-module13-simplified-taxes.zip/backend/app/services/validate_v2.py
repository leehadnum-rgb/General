from __future__ import annotations

from typing import Dict, List, Optional, Set, Tuple

from app.services.models_v2 import (
    CalculationRequestV2,
    ValidationIssueV2,
    ValidationResponseV2,
)


def _issue(
    issues: List[ValidationIssueV2],
    *,
    severity: str,
    code: str,
    message: str,
    path: Optional[str] = None,
    tested_jurisdiction_id: Optional[str] = None,
    entity_id: Optional[str] = None,
) -> None:
    issues.append(
        ValidationIssueV2(
            severity=severity,
            code=code,
            message=message,
            path=path,
            tested_jurisdiction_id=tested_jurisdiction_id,
            entity_id=entity_id,
        )
    )


def validate_request_v2(req: CalculationRequestV2) -> ValidationResponseV2:
    """Validate a CalculationRequestV2 for completeness and allocation readiness.

    This endpoint does not mutate the request. It returns a list of issues with severities.

    Modules 5-6 focus:
      - Entity classification presence / consistency (Section 6 scaffolding).
      - Presence of PE / flow-through registers when such entity types exist.
      - ID reference checks for allocation-ready registers.

    Note: As of Module 6, the allocation engine (OECD section 5.1) is active and can change computed Simplified Income and Simplified Taxes.
    Validation here aims to prevent users from believing an allocation outcome is being computed
    when key register data is missing.
    """

    issues: List[ValidationIssueV2] = []

    tj_ids: Set[str] = {tj.tested_jurisdiction_id for tj in req.tested_jurisdictions}
    if len(tj_ids) != len(req.tested_jurisdictions):
        _issue(
            issues,
            severity="error",
            code="DUPLICATE_TESTED_JURISDICTION_ID",
            message="tested_jurisdictions contains duplicate tested_jurisdiction_id values; IDs must be unique.",
            path="$.tested_jurisdictions",
        )



    # Prior-year status register checks (Box 7.2) (v4 module 8)
    py_seen: Set[Tuple[str, object]] = set()
    for row in getattr(req, 'prior_years_status', None) or []:
        tj_id = getattr(row, 'tested_jurisdiction_id', None)
        fy = getattr(row, 'fiscal_year_start', None)
        if tj_id and tj_id not in tj_ids:
            _issue(
                issues,
                severity='error',
                code='UNKNOWN_TESTED_JURISDICTION_IN_PRIOR_YEAR_STATUS',
                message=f"prior_years_status references tested_jurisdiction_id '{tj_id}' that is not present in tested_jurisdictions.",
                path='$.prior_years_status[]',
            )
        key = (str(tj_id), fy)
        if key in py_seen:
            _issue(
                issues,
                severity='error',
                code='DUPLICATE_PRIOR_YEAR_STATUS',
                message=f"Duplicate prior_years_status row for tested_jurisdiction_id '{tj_id}' and fiscal_year_start {fy}.",
                path='$.prior_years_status[]',
                tested_jurisdiction_id=tj_id,
            )
        py_seen.add(key)

    if bool(getattr(getattr(req, 'entry_reentry_automation', None), 'enable_auto_entry_reentry', True)) and not (getattr(req, 'prior_years_status', None) or []):
        _issue(
            issues,
            severity='warning',
            code='NO_PRIOR_YEAR_STATUS_ROWS',
            message=(
                "No prior_years_status rows were provided. Box 7.2 entry/re-entry criteria will rely on tested_jurisdiction.eligibility_inputs booleans (attestation)."
            ),
            path='$.prior_years_status',
        )
    # Build entity index
    entity_index: Dict[str, Tuple[str, object]] = {}  # entity_id -> (tj_id, entity_obj)
    missing_entity_id_count = 0
    for tj in req.tested_jurisdictions:
        for e in tj.entities or []:
            eid = getattr(e, "entity_id", None)
            if not eid:
                missing_entity_id_count += 1
                continue
            if eid in entity_index:
                _issue(
                    issues,
                    severity="warning",
                    code="DUPLICATE_ENTITY_ID",
                    message=f"Entity_id '{eid}' appears in multiple Tested Jurisdictions; allocation registers may not resolve uniquely.",
                    tested_jurisdiction_id=tj.tested_jurisdiction_id,
                    entity_id=eid,
                    path="$.tested_jurisdictions[].entities[].entity_id",
                )
            entity_index[eid] = (tj.tested_jurisdiction_id, e)

    if missing_entity_id_count:
        _issue(
            issues,
            severity="warning",
            code="MISSING_ENTITY_ID",
            message=(
                f"{missing_entity_id_count} entity rows are missing entity_id. "
                "If you want to use PE / flow-through allocation registers, provide entity_id values for referenced entities."
            ),
            path="$.tested_jurisdictions[].entities[]",
        )

    # Build PE register index
    pe_by_id: Dict[str, object] = {pe.pe_id: pe for pe in (req.permanent_establishments or []) if getattr(pe, "pe_id", None)}
    pe_by_entity: Dict[str, object] = {
        pe.pe_entity_id: pe for pe in (req.permanent_establishments or []) if getattr(pe, "pe_entity_id", None)
    }

    # Flow-through allocation lines index
    fte_lines_by_entity: Dict[str, List[object]] = {}
    for line in req.flow_through_entities or []:
        fte_lines_by_entity.setdefault(line.flow_through_entity_id, []).append(line)

        if line.flow_through_tested_jurisdiction_id and line.flow_through_tested_jurisdiction_id not in tj_ids:
            _issue(
                issues,
                severity="error",
                code="UNKNOWN_FLOW_THROUGH_TJ",
                message=f"Flow-through allocation line references unknown flow_through_tested_jurisdiction_id '{line.flow_through_tested_jurisdiction_id}'.",
                path="$.flow_through_entities[]",
            )

        if line.owner_tested_jurisdiction_id and line.owner_tested_jurisdiction_id not in tj_ids:
            _issue(
                issues,
                severity="error",
                code="UNKNOWN_OWNER_TJ",
                message=f"Flow-through allocation line references unknown owner_tested_jurisdiction_id '{line.owner_tested_jurisdiction_id}'.",
                path="$.flow_through_entities[]",
            )

    # Allocable tax items reference checks (schema already enforces article values)
    for item in req.allocable_tax_items or []:
        if item.source_tested_jurisdiction_id and item.source_tested_jurisdiction_id not in tj_ids:
            _issue(
                issues,
                severity="error",
                code="UNKNOWN_ALLOCABLE_TAX_SOURCE_TJ",
                message=f"Allocable tax item references unknown source_tested_jurisdiction_id '{item.source_tested_jurisdiction_id}'.",
                path="$.allocable_tax_items[]",
            )
        if item.target_tested_jurisdiction_id and item.target_tested_jurisdiction_id not in tj_ids:
            _issue(
                issues,
                severity="error",
                code="UNKNOWN_ALLOCABLE_TAX_TARGET_TJ",
                message=f"Allocable tax item references unknown target_tested_jurisdiction_id '{item.target_tested_jurisdiction_id}'.",
                path="$.allocable_tax_items[]",
            )

        # Guidance for non-(b) items with no target (allocation vs exclusion decision)
        if item.globe_article != "4.3.2(b)" and not item.target_tested_jurisdiction_id:
            _issue(
                issues,
                severity="warning",
                code="ALLOCABLE_TAX_NO_TARGET",
                message=(
                    f"Allocable tax item '{item.item_id or item.label or '<unnamed>'}' tagged {item.globe_article} has no target_tested_jurisdiction_id. "
                    "Later OECD section 5.1 allocation modules may require an explicit allocation/exclusion decision."
                ),
                path="$.allocable_tax_items[]",
            )

    # Entity-type specific completeness checks
    for tj in req.tested_jurisdictions:
        for e in tj.entities or []:
            et = getattr(e, "entity_type", None) or "STANDARD_CE"
            eid = getattr(e, "entity_id", None)
            # PE requires register linkage
            if et == "PERMANENT_ESTABLISHMENT":
                linked = False
                pe_id = getattr(e, "pe_id", None)
                if pe_id and pe_id in pe_by_id:
                    linked = True
                if eid and eid in pe_by_entity:
                    linked = True
                if not linked:
                    _issue(
                        issues,
                        severity="error",
                        code="PE_MISSING_REGISTER",
                        message=(
                            f"Entity '{e.entity_name}' (entity_id={eid or 'n/a'}) is classified as PERMANENT_ESTABLISHMENT but no matching permanent_establishments register entry was found. "
                            "Provide a register row keyed by pe_id and/or pe_entity_id."
                        ),
                        tested_jurisdiction_id=tj.tested_jurisdiction_id,
                        entity_id=eid,
                        path="$.tested_jurisdictions[].entities[]",
                    )

            # Flow-through / tax-transparent requires allocation lines
            if et in {"FLOW_THROUGH_ENTITY", "TAX_TRANSPARENT_ENTITY"}:
                if not eid:
                    _issue(
                        issues,
                        severity="warning",
                        code="FLOW_THROUGH_MISSING_ENTITY_ID",
                        message=(
                            f"Entity '{e.entity_name}' is classified as {et} but has no entity_id. "
                            "Provide entity_id to link to flow_through_entities allocation lines."
                        ),
                        tested_jurisdiction_id=tj.tested_jurisdiction_id,
                        path="$.tested_jurisdictions[].entities[]",
                    )
                else:
                    if eid not in fte_lines_by_entity:
                        _issue(
                            issues,
                            severity="error",
                        code="FLOW_THROUGH_MISSING_ALLOCATION_LINES",
                            message=(
                                f"Entity '{e.entity_name}' (entity_id={eid}) is classified as {et} but has no flow_through_entities allocation lines. "
                                "Provide at least one allocation line to support OECD section 5.1 / section 6 deemed-zero logic."
                            ),
                            tested_jurisdiction_id=tj.tested_jurisdiction_id,
                            entity_id=eid,
                            path="$.flow_through_entities",
                        )

            # Tax-neutral UPE ownership
            if et == "TAX_NEUTRAL_UPE":
                qp = getattr(e, "qualified_persons_ownership_percentage", None)
                if qp is None:
                    _issue(
                        issues,
                        severity="warning",
                        code="TAX_NEUTRAL_MISSING_OWNERSHIP",
                        message=(
                            f"Entity '{e.entity_name}' is classified as TAX_NEUTRAL_UPE but qualified_persons_ownership_percentage is missing. "
                            "Provide a 0–1 proportion to support section 6 deemed-zero determination."
                        ),
                        tested_jurisdiction_id=tj.tested_jurisdiction_id,
                        entity_id=eid,
                        path="$.tested_jurisdictions[].entities[].qualified_persons_ownership_percentage",
                    )

    # Note about current module scope
    if (req.permanent_establishments or req.flow_through_entities or req.allocable_tax_items):
        _issue(
            issues,
            severity="warning",
            code="ALLOCATION_ENGINE_APPLIED",
            message=(
                "Allocation-ready registers are provided. The section 5.1 allocation engine is active and will adjust Simplified Income and Simplified Taxes based on these registers. Review the allocation ledger in results."
                "current calculations may not yet reflect PE/flow-through allocations unless separately modelled via other adjustments."
            ),
            path="$.permanent_establishments/$.flow_through_entities/$.allocable_tax_items",
        )

    
    # Potential double-counting warning: both legacy cross_border_tax_items and allocable_tax_items provided
    if (req.cross_border_tax_items or []) and (req.allocable_tax_items or []):
        _issue(
            issues,
            severity="warning",
            code="POTENTIAL_DOUBLE_COUNTING_CROSS_BORDER",
            message=(
                "Both cross_border_tax_items and allocable_tax_items are provided. This can lead to double-counting or offsetting adjustments. "
                "Prefer allocable_tax_items (Article 4.3.2 tagged) for section 5.1 mechanics and use cross_border_tax_items only for residual/manual corrections."
            ),
            path="$.cross_border_tax_items/$.allocable_tax_items",
        )



    # ------------------------------------------------------------------
    # Module 10 (Box 7.3) Integrity rules – structural validations
    # ------------------------------------------------------------------

    # SINGLE_TAX: duplicate allocable tax item ids (high-risk for double counting)
    seen_allocable: Set[str] = set()
    for it in (req.allocable_tax_items or []):
        if it.item_id:
            if it.item_id in seen_allocable:
                _issue(
                    issues,
                    severity="error",
                    code="SINGLE_TAX_DUPLICATE_ALLOCABLE_TAX_ITEM_ID",
                    message=(
                        f"allocable_tax_items contains duplicate item_id '{it.item_id}'. "
                        "Each allocable tax item should be recorded once to satisfy the single-tax integrity principle."
                    ),
                    path="$.allocable_tax_items[]",
                )
            seen_allocable.add(it.item_id)

    # TP register sanity: duplicate adjustment_id (not always fatal, but confusing audit)
    seen_tp: Set[str] = set()
    for tp in (req.transfer_pricing_adjustments or []):
        if tp.adjustment_id:
            if tp.adjustment_id in seen_tp:
                _issue(
                    issues,
                    severity="warning",
                    code="DUPLICATE_TP_ADJUSTMENT_ID",
                    message=(
                        f"transfer_pricing_adjustments contains duplicate adjustment_id '{tp.adjustment_id}'. "
                        "Use unique ids to keep audit trails unambiguous."
                    ),
                    path="$.transfer_pricing_adjustments[]",
                )
            seen_tp.add(tp.adjustment_id)

    # Integrity adjustments: FX pre-check (so calc doesn't 400 later)
    rep = (req.group_profile.reporting_currency or "").upper().strip() or None
    fy = req.fiscal_year.start_date
    if rep and (req.integrity_adjustments or []):
        # Build a lookup of avg FX rates provided for this FY (by currency)
        fx_map: Dict[str, float] = {}
        for r in (req.fx_rates or []):
            if r.fiscal_year_start is not None and r.fiscal_year_start != fy:
                continue
            cur = (r.currency or "").upper().strip()
            if not cur:
                continue
            if r.avg_rate_to_reporting is None:
                continue
            fx_map[cur] = float(r.avg_rate_to_reporting)

        for adj in (req.integrity_adjustments or []):
            cur = (adj.currency or "").upper().strip() or None
            if cur and cur != rep and cur not in fx_map:
                _issue(
                    issues,
                    severity="error",
                    code="MISSING_FX_RATE_INTEGRITY_ADJUSTMENT",
                    message=(
                        f"Integrity adjustment '{adj.adjustment_id or ''}' uses currency '{cur}' but request.reporting_currency is '{rep}' "
                        f"and no FX avg_rate_to_reporting is provided for FY start {fy}. "
                        "Add fx_rates[] rows or omit currency to assume TJ/reporting currency."
                    ),
                    path="$.integrity_adjustments[]/$.fx_rates[]",
                )

    # ------------------------------------------------------------------
    # Module 11: PE allocation / PE Simplification Election (section 5.1)
    # ------------------------------------------------------------------
    # - Validate PE allocation line identifiers
    # - Validate continuation state presence/derivation
    # - Warn when election is required by continuation state

    # Index permanent establishments by pe_id (if provided)
    pe_index: Dict[str, dict] = {}
    for pe in (getattr(req, "permanent_establishments", None) or []):
        if getattr(pe, "pe_id", None):
            pe_index[str(pe.pe_id)] = {
                "main": getattr(pe, "main_entity_tested_jurisdiction_id", None),
                "pe": getattr(pe, "pe_tested_jurisdiction_id", None),
                "branch": bool(getattr(pe, "taxable_branch_regime_applies", False)),
            }

    # Which Tested Jurisdictions explicitly elect PE simplification?
    explicit_pe_simpl_tjs: Set[str] = set()
    for tj in (req.tested_jurisdictions or []):
        for e in (getattr(tj, "elections", None) or []):
            if getattr(e, "election_code", None) == "PE_SIMPLIFICATION_ELECTION_NOTE" and bool(getattr(e, "bool_value", False)):
                explicit_pe_simpl_tjs.add(str(tj.tested_jurisdiction_id))

    # Continuation state can force the election for a Main Entity TJ.
    forced_pe_simpl_tjs: Set[str] = set()
    seen_state_pe: Set[str] = set()
    for st in (getattr(req, "pe_simplification_state_opening", None) or []):
        pe_id = str(getattr(st, "pe_id", "") or "").strip()
        if not pe_id:
            _issue(
                issues,
                severity="error",
                code="PE_SIMPLIFICATION_STATE_MISSING_PE_ID",
                message="pe_simplification_state_opening contains a row with missing pe_id.",
                path="$.pe_simplification_state_opening[]",
            )
            continue
        if pe_id in seen_state_pe:
            _issue(
                issues,
                severity="warning",
                code="DUPLICATE_PE_SIMPLIFICATION_STATE_PE_ID",
                message=(
                    f"pe_simplification_state_opening contains duplicate pe_id '{pe_id}'. "
                    "Use one row per PE to avoid ambiguous continuation tracking."
                ),
                path="$.pe_simplification_state_opening[]",
            )
        seen_state_pe.add(pe_id)

        loss_bal = float(getattr(st, "unrecouped_loss_balance", 0.0) or 0.0)
        tail = int(getattr(st, "tail_years_remaining", 0) or 0)

        main_tj = getattr(st, "main_entity_tested_jurisdiction_id", None)
        if not main_tj and pe_id in pe_index:
            main_tj = pe_index[pe_id].get("main")
        if (loss_bal > 1e-9 or tail > 0):
            if not main_tj:
                _issue(
                    issues,
                    severity="error",
                    code="PE_SIMPLIFICATION_STATE_CANNOT_DERIVE_MAIN_TJ",
                    message=(
                        f"pe_simplification_state_opening for pe_id '{pe_id}' requires a main_entity_tested_jurisdiction_id "
                        "(or a matching permanent_establishments row) to enforce the continuation requirement."
                    ),
                    path="$.pe_simplification_state_opening[]",
                )
            else:
                forced_pe_simpl_tjs.add(str(main_tj))

    # Warn if continuation state implies election is required but user did not elect.
    for tj_id in sorted(forced_pe_simpl_tjs):
        if tj_id not in explicit_pe_simpl_tjs:
            _issue(
                issues,
                severity="warning",
                code="PE_SIMPLIFICATION_ELECTION_REQUIRED_BY_STATE",
                message=(
                    f"PE simplification election appears required for Tested Jurisdiction '{tj_id}' due to prior-year included PE losses (continuation state). "
                    "The calculator will auto-apply the election for this year, but for audit clarity you should also record the election in tj.elections[]."
                ),
                path="$.pe_simplification_state_opening[]/$.tested_jurisdictions[].elections[]",
                tested_jurisdiction_id=tj_id,
            )

    # Validate PE allocation lines
    seen_line_ids: Set[str] = set()
    seen_line_key: Set[Tuple[str, Optional[date]]] = set()
    for idx, line in enumerate(getattr(req, "pe_allocation_lines", None) or []):
        line_id = str(getattr(line, "line_id", "") or "").strip()
        if line_id:
            if line_id in seen_line_ids:
                _issue(
                    issues,
                    severity="warning",
                    code="DUPLICATE_PE_ALLOCATION_LINE_ID",
                    message=(
                        f"pe_allocation_lines contains duplicate line_id '{line_id}'. "
                        "Use unique ids to keep audit trails unambiguous."
                    ),
                    path=f"$.pe_allocation_lines[{idx}]",
                )
            seen_line_ids.add(line_id)

        pe_id = str(getattr(line, "pe_id", "") or "").strip()
        fy_line = getattr(line, "fiscal_year_start", None)
        if pe_id:
            key = (pe_id, fy_line)
            if key in seen_line_key:
                _issue(
                    issues,
                    severity="warning",
                    code="DUPLICATE_PE_ALLOCATION_LINE_PER_PE_YEAR",
                    message=(
                        f"Multiple pe_allocation_lines provided for pe_id '{pe_id}' and fiscal_year_start '{fy_line}'. "
                        "Rows will be summed, but consider consolidating to one line per PE per year for clarity."
                    ),
                    path=f"$.pe_allocation_lines[{idx}]",
                )
            seen_line_key.add(key)

        # FY mismatch
        if fy_line is not None and fy_line != req.fiscal_year.start_date:
            _issue(
                issues,
                severity="warning",
                code="PE_ALLOCATION_LINE_FY_MISMATCH",
                message=(
                    f"pe_allocation_lines row for pe_id '{pe_id}' has fiscal_year_start={fy_line}, but request fiscal_year.start_date={req.fiscal_year.start_date}. "
                    "The calculator will ignore this row for the current year."
                ),
                path=f"$.pe_allocation_lines[{idx}].fiscal_year_start",
            )

        # Basic numeric sanity
        ftc = float(getattr(line, "foreign_tax_credit_used", 0.0) or 0.0)
        if ftc < -1e-9:
            _issue(
                issues,
                severity="warning",
                code="NEGATIVE_FOREIGN_TAX_CREDIT_USED",
                message=(
                    f"pe_allocation_lines row for pe_id '{pe_id}' has foreign_tax_credit_used={ftc} (negative). "
                    "Foreign tax credit used is typically non-negative; confirm sign conventions."
                ),
                path=f"$.pe_allocation_lines[{idx}].foreign_tax_credit_used",
            )

        # If election is not explicitly recorded, warn if line carries non-zero amounts.
        # (The calculator may still apply due to forced state.)
        main_tj = getattr(line, "main_entity_tested_jurisdiction_id", None)
        if not main_tj and pe_id and pe_id in pe_index:
            main_tj = pe_index[pe_id].get("main")
        non_zero = any(
            abs(float(getattr(line, f, 0.0) or 0.0)) > 1e-9
            for f in ["pe_income_included_in_main", "main_entity_taxes_related_to_pe", "foreign_tax_credit_used"]
        )
        if non_zero and main_tj and str(main_tj) not in explicit_pe_simpl_tjs and str(main_tj) not in forced_pe_simpl_tjs:
            _issue(
                issues,
                severity="warning",
                code="PE_ALLOCATION_LINE_PRESENT_BUT_ELECTION_NOT_RECORDED",
                message=(
                    f"pe_allocation_lines row provided for pe_id '{pe_id}' / main TJ '{main_tj}', but the PE simplification election "
                    "is not recorded for that Tested Jurisdiction and no continuation state forces it. "
                    "Row will be ignored unless the election is made."
                ),
                path=f"$.pe_allocation_lines[{idx}]/$.tested_jurisdictions[].elections[]",
                tested_jurisdiction_id=str(main_tj),
            )

        # Branch-regime gating (input flag)
        if main_tj and pe_id and pe_id in pe_index:
            if not pe_index[pe_id].get("branch") and (str(main_tj) in explicit_pe_simpl_tjs or str(main_tj) in forced_pe_simpl_tjs):
                _issue(
                    issues,
                    severity="warning",
                    code="PE_SIMPLIFICATION_NO_BRANCH_REGIME_FLAG",
                    message=(
                        f"PE simplification election recorded for main TJ '{main_tj}', but permanent_establishments for pe_id '{pe_id}' "
                        "does not indicate taxable_branch_regime_applies=true. Confirm PE simplification election conditions."
                    ),
                    path="$.permanent_establishments[]",
                    tested_jurisdiction_id=str(main_tj),
                )

    # --------------------------------------------------------------------
    # Module 12: Box 3.1 JPBT scaffolding awareness (other covered taxes)
    # --------------------------------------------------------------------
    for tj in req.tested_jurisdictions:
        tj_id = tj.tested_jurisdiction_id

        # Determine the election amount (facts-level preferred; otherwise sum entities).
        other_cov_amt = 0.0
        if getattr(tj, "facts", None) is not None:
            other_cov_amt = float(getattr(tj.facts, "election_include_other_covered_taxes", 0.0) or 0.0)
        else:
            other_cov_amt = float(
                sum(float(getattr(e, "election_include_other_covered_taxes", 0.0) or 0.0) for e in (tj.entities or []))
            )

        if abs(other_cov_amt) > 1e-9:
            jpbt_flag = bool(
                getattr(getattr(tj, "facts", None), "jpbt_includes_other_covered_taxes_elected", False)
            )
            if jpbt_flag:
                _issue(
                    issues,
                    severity="warning",
                    code="BOX3_1_OTHER_COVERED_TAXES_FLAG_TRUE",
                    message=(
                        f"Tested Jurisdiction '{tj_id}' has election_include_other_covered_taxes={other_cov_amt}. "
                        "jpbt_includes_other_covered_taxes_elected=True indicates your JPBT input already includes the Box 3.1 add-back. "
                        "The calculator will NOT add it again. Confirm this to avoid understating Simplified Income."
                    ),
                    path="$.tested_jurisdictions[].facts.jpbt_includes_other_covered_taxes_elected",
                    tested_jurisdiction_id=tj_id,
                )
            else:
                _issue(
                    issues,
                    severity="warning",
                    code="BOX3_1_OTHER_COVERED_TAXES_ADD_BACK_APPLIES",
                    message=(
                        f"Tested Jurisdiction '{tj_id}' has election_include_other_covered_taxes={other_cov_amt}. "
                        "Box 3.1 treats these taxes as part of the JPBT construction (reclassifying them below-the-line). "
                        "The calculator will add this amount to JPBT unless you set facts.jpbt_includes_other_covered_taxes_elected=True. "
                        "If your JPBT already includes this add-back, set the flag to prevent double counting."
                    ),
                    path="$.tested_jurisdictions[].facts.election_include_other_covered_taxes",
                    tested_jurisdiction_id=tj_id,
                )

    # --------------------------------------------------------------------
    # Module 13: Simplified Taxes enhancements (GloBE Loss Election + non-REA DTL carve-ins)
    # --------------------------------------------------------------------
    for tj in req.tested_jurisdictions:
        tj_id = tj.tested_jurisdiction_id
        facts = getattr(tj, "facts", None)
        if facts is None:
            continue

        globe_loss = bool(getattr(facts, "globe_loss_election_applies", False))
        globe_loss_amt = float(getattr(facts, "globe_loss_dta_deferred_tax_expense", 0.0) or 0.0)
        globe_loss_at_min = bool(getattr(facts, "globe_loss_dta_amount_is_at_minimum_rate", True))

        if globe_loss:
            if abs(globe_loss_amt) <= 1e-9:
                _issue(
                    issues,
                    severity="warning",
                    code="GLOBE_LOSS_ELECTION_NO_DTA_AMOUNT",
                    message=(
                        f"Tested Jurisdiction '{tj_id}' has globe_loss_election_applies=true but globe_loss_dta_deferred_tax_expense is 0. "
                        "If the GloBE Loss Election is made and a GloBE Loss DTA exists, enter the deferred tax expense/benefit attributable to that DTA."
                    ),
                    path="$.tested_jurisdictions[].facts.globe_loss_dta_deferred_tax_expense",
                    tested_jurisdiction_id=tj_id,
                )

            # Under the election, deferred-tax adjustments relating to financial-account DTAs/DTLs are ignored.
            ignored_fields = {
                "valuation_allowance_impact": float(getattr(facts, "valuation_allowance_impact", 0.0) or 0.0),
                "tax_rate_change_impact": float(getattr(facts, "tax_rate_change_impact", 0.0) or 0.0),
                "deferred_tax_from_tax_credits": float(getattr(facts, "deferred_tax_from_tax_credits", 0.0) or 0.0),
                "non_rea_dtl_deferred_tax_expense": float(getattr(facts, "non_rea_dtl_deferred_tax_expense", 0.0) or 0.0),
                "non_rea_dtl_carve_in_mna_reversal": float(getattr(facts, "non_rea_dtl_carve_in_mna_reversal", 0.0) or 0.0),
                "non_rea_dtl_carve_in_prior_etr_reversal": float(getattr(facts, "non_rea_dtl_carve_in_prior_etr_reversal", 0.0) or 0.0),
                "mna_deferred_tax_accruals_to_exclude": float(getattr(facts, "mna_deferred_tax_accruals_to_exclude", 0.0) or 0.0),
                "mna_goodwill_related_dtl_reversal_to_exclude": float(getattr(facts, "mna_goodwill_related_dtl_reversal_to_exclude", 0.0) or 0.0),
            }
            if any(abs(v) > 1e-9 for v in ignored_fields.values()):
                _issue(
                    issues,
                    severity="warning",
                    code="GLOBE_LOSS_ELECTION_IGNORES_DEFERRED_ADJUSTMENTS",
                    message=(
                        f"Tested Jurisdiction '{tj_id}' has globe_loss_election_applies=true. Under the GloBE Loss Election, deferred-tax adjustments "
                        "relating to financial-account DTAs/DTLs (valuation allowances, rate changes, tax credits, non-REA DTL exclusions, M&A deferred exclusions) are ignored. "
                        "Clear these fields or ensure you have not double-counted."
                    ),
                    path="$.tested_jurisdictions[].facts",
                    tested_jurisdiction_id=tj_id,
                )

            if globe_loss_at_min is False and not getattr(facts, "accounted_tax_rate", None):
                _issue(
                    issues,
                    severity="warning",
                    code="GLOBE_LOSS_ELECTION_RECAST_FLAG_NO_RATE",
                    message=(
                        f"Tested Jurisdiction '{tj_id}' has globe_loss_dta_amount_is_at_minimum_rate=false but no accounted_tax_rate provided. "
                        "If you need recasting, provide accounted_tax_rate."
                    ),
                    path="$.tested_jurisdictions[].facts.accounted_tax_rate",
                    tested_jurisdiction_id=tj_id,
                )

        # Non-REA carve-in validations
        gross_non_rea = float(getattr(facts, "non_rea_dtl_deferred_tax_expense", 0.0) or 0.0)
        carve_mna = float(getattr(facts, "non_rea_dtl_carve_in_mna_reversal", 0.0) or 0.0)
        carve_prior = float(getattr(facts, "non_rea_dtl_carve_in_prior_etr_reversal", 0.0) or 0.0)
        carve_total = carve_mna + carve_prior

        if abs(carve_total) > 1e-9 and abs(gross_non_rea) <= 1e-9 and not globe_loss:
            _issue(
                issues,
                severity="warning",
                code="NON_REA_CARVE_IN_WITHOUT_GROSS",
                message=(
                    f"Tested Jurisdiction '{tj_id}' has non-REA DTL carve-in amounts but non_rea_dtl_deferred_tax_expense is 0. "
                    "Carve-ins are intended to offset the exclusion of non-REA DTL deferred tax expense; confirm inputs."
                ),
                path="$.tested_jurisdictions[].facts.non_rea_dtl_carve_in_mna_reversal",
                tested_jurisdiction_id=tj_id,
            )

        if bool(getattr(facts, "non_rea_dtl_exception_applies", False)) and abs(carve_total) > 1e-9 and not globe_loss:
            _issue(
                issues,
                severity="warning",
                code="NON_REA_LEGACY_EXCEPTION_WITH_CARVE_IN",
                message=(
                    f"Tested Jurisdiction '{tj_id}' has non_rea_dtl_exception_applies=true and also provides carve-in amounts. "
                    "The legacy boolean keeps the entire non-REA DTL amount; prefer using carve-ins for the specific OECD exceptions."
                ),
                path="$.tested_jurisdictions[].facts.non_rea_dtl_exception_applies",
                tested_jurisdiction_id=tj_id,
            )

        # Heuristic magnitude check (signed amounts): flag if carve-ins are very large relative to the gross.
        if abs(gross_non_rea) > 1e-9 and abs(carve_total) > abs(gross_non_rea) * 1.05 and not globe_loss:
            _issue(
                issues,
                severity="warning",
                code="NON_REA_CARVE_IN_EXCEEDS_GROSS",
                message=(
                    f"Tested Jurisdiction '{tj_id}' has non-REA DTL carve-ins (total={carve_total}) whose magnitude exceeds non_rea_dtl_deferred_tax_expense ({gross_non_rea}). "
                    "Confirm signs/amounts and whether gross is net-of-exceptions."
                ),
                path="$.tested_jurisdictions[].facts.non_rea_dtl_carve_in_prior_etr_reversal",
                tested_jurisdiction_id=tj_id,
            )


    return ValidationResponseV2(issues=issues)
