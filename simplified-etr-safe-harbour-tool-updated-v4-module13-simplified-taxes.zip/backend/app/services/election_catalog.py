from __future__ import annotations

"""Election & adjustment catalogue.

This module serves two purposes:
1) Populate the Excel template "ElectionCatalog" and "ElectionAdjustments" sheets.
2) Drive the (prototype) web UI selection lists.

Design note
-----------
The OECD Simplified ETR Safe Harbour allows a number of elections and also requires
several adjustments that, in a production tool, would typically be computed from source
financial/tax data. In this prototype, elections are represented either:

* as dedicated fields in :class:`~app.services.models.JurisdictionInput` ("mapped" elections), or
* as user-provided net income/tax adjustments ("unmapped" elections) recorded as
  :class:`~app.services.models.AdjustmentLine` items.

The catalogue below includes both kinds so that users have a single place to discover what
can be input in a structured way.

Update (v2)
-----------
To support a multi-year (professional) workflow and Anything-driven UI, each election includes
a default term type:
  * ANNUAL
  * FIVE_YEAR

In v1 Excel upload mode, the term type is informational only. In v2 JSON mode, the server
uses term type to determine which elections are effective in a Fiscal Year.
"""

from dataclasses import dataclass
from typing import Literal, Optional


Scope = Literal["income", "tax", "eligibility", "metadata"]
ValueType = Literal["bool", "amount", "text"]
TermType = Literal["ANNUAL", "FIVE_YEAR"]
Level = Literal["TESTED_JURISDICTION", "GROUP"]


@dataclass(frozen=True)
class ElectionDef:
    code: str
    label: str
    group: str
    scope: Scope
    value_type: ValueType
    # Default term of the election in the OECD guidance.
    term_type: TermType = "ANNUAL"
    # For FIVE_YEAR elections, the OECD guidance generally treats the election as continuing until revoked,
    # with a minimum lock-in period of 5 Fiscal Years.
    continues_until_revoked: bool = False
    # Minimum number of years after the effective start before the election may be revoked.
    # For a typical FIVE_YEAR election, revocation is permitted in Year 6 or following -> 5 years after start.
    revocable_after_years: int = 0
    # Optional cooldown (in years) after a revocation year before the same election may be made again.
    # For example, the Shipping election prevents a new election in the 4 Fiscal Years succeeding revocation.
    cooldown_years: int = 0
    # Whether the election continues in years where the MNE Group applies the full GloBE Rules (not the SH).
    continues_when_sh_not_applied: bool = False
    # Scope of the election: Tested Jurisdiction-level (default) or Group-level.
    level: Level = "TESTED_JURISDICTION"
    description: str = ""
    # If provided, the election maps directly to a JurisdictionInput attribute.
    target_field: Optional[str] = None


# ---------------------------------------------------------------------------
# Catalogue
# ---------------------------------------------------------------------------

ELECTION_DEFS: list[ElectionDef] = [
    # ----------------------------
    # 3.3 Industry adjustments
    # ----------------------------
    ElectionDef(
        code="FS_ANNUAL_ELECTION_NOT_TO_EXCLUDE_INSURANCE_INCOME",
        label="Financial services: Annual election not to exclude insurance company income (Box 3.3.1 / Art 3.2.9)",
        group="3.3 Financial services",
        scope="income",
        value_type="bool",
        term_type="ANNUAL",
        target_field="fs_annual_election_not_to_exclude_insurance_income",
        description="If True, insurance company income remains included in Simplified Income.",
    ),
    ElectionDef(
        code="SHIPPING_FIVE_YEAR_ELECTION_NOT_TO_EXCLUDE",
        label="Shipping: Five-Year Election not to apply Shipping Income Exclusion (Box 3.3.2)",
        group="3.3 Shipping",
        scope="income",
        value_type="bool",
        term_type="FIVE_YEAR",
        continues_until_revoked=True,
        revocable_after_years=5,
        cooldown_years=4,
        continues_when_sh_not_applied=True,
        target_field="shipping_five_year_election_not_to_exclude",
        description=(
            "If True (and aggregate shipping income is positive), shipping income exclusion is not applied. "
            "This is a FIVE_YEAR election that continues until revoked. The OECD text indicates the MNE Group may revoke in "
            "Year 6 or following; after revocation, a new election cannot be made for the four Fiscal Years succeeding the "
            "revocation year."
        ),
    ),

    # ----------------------------
    # 3.4 Conditional adjustments
    # ----------------------------
    ElectionDef(
        code="MNA_SIMPLIFICATION_APPLIED",
        label="M&A Simplification applies for the Tested Jurisdiction (Box 3.4.2)",
        group="3.4 Conditional adjustments",
        scope="income",
        value_type="bool",
        term_type="ANNUAL",
        target_field="mna_simplification_applied",
        description="If True, apply the M&A simplification add-back and related deferred-tax exclusions where amounts are provided.",
    ),

    # ----------------------------
    # 3.5 Optional adjustments
    # ----------------------------
    ElectionDef(
        code="AFXGL_FIVE_YEAR_ELECTION_NOT_TO_APPLY",
        label="Optional exclusions: Five-Year Election not to apply AFXGL adjustment (Box 3.5.2 / Art 3.2.1(f))",
        group="3.5 Optional exclusions",
        scope="income",
        value_type="bool",
        term_type="FIVE_YEAR",
        continues_until_revoked=True,
        revocable_after_years=5,
        continues_when_sh_not_applied=True,
        target_field="afxgl_five_year_election_not_to_apply",
    ),
    ElectionDef(
        code="PENSION_FIVE_YEAR_ELECTION_NOT_TO_APPLY",
        label="Optional exclusions: Five-Year Election not to apply accrued pension expense adjustment (Box 3.5.2 / Art 3.2.1(i))",
        group="3.5 Optional exclusions",
        scope="income",
        value_type="bool",
        term_type="FIVE_YEAR",
        continues_until_revoked=True,
        revocable_after_years=5,
        continues_when_sh_not_applied=True,
        target_field="pension_five_year_election_not_to_apply",
    ),

    # 3.5.1: Chapter 3 elections (unmapped - user provides net impact)
    ElectionDef(
        code="CH3_GLOBE_ELECTION_NET_INCOME_ADJUSTMENT",
        label="Chapter 3 GloBE elections: net impact on Simplified Income (Box 3.5.1)",
        group="3.5.1 Chapter 3 elections",
        scope="income",
        value_type="amount",
        term_type="ANNUAL",
        description="Enter the net signed impact of any Chapter 3 elections you apply that affect GloBE Income/Simplified Income.",
    ),
    ElectionDef(
        code="CH3_GLOBE_ELECTION_NET_TAX_ADJUSTMENT",
        label="Chapter 3 GloBE elections: net impact on Simplified Taxes (Box 3.5.1)",
        group="3.5.1 Chapter 3 elections",
        scope="tax",
        value_type="amount",
        term_type="ANNUAL",
        description="Enter the net signed impact of any Chapter 3 elections you apply that affect Covered Taxes/Simplified Taxes.",
    ),
    ElectionDef(
        code="NMCE_SIMPLIFIED_CALCULATION_NOTE",
        label="Non‑Material Constituent Entities Simplified Calculation used (Box 3.5.1)",
        group="3.5.1 Chapter 3 elections",
        scope="metadata",
        value_type="bool",
        term_type="ANNUAL",
        description="Record whether the NMCE simplified calculation is used. Enter resulting net impacts via adjustments if needed.",
    ),

    # ----------------------------
    # 4.3 Negative taxes in Simplified Loss years
    # ----------------------------
    ElectionDef(
        code="LOSS_DTA_ADJUSTMENT_METHOD_ELECTED",
        label="Loss DTA Adjustment methodology elected (in lieu of Simplified Adjustment for Negative Taxes) (Box 4.3(4))",
        group="4.3 Negative taxes in loss years",
        scope="metadata",
        value_type="bool",
        term_type="FIVE_YEAR",
        continues_until_revoked=True,
        revocable_after_years=5,
        continues_when_sh_not_applied=True,
        description=(
            "If True, the group intends to use the Loss DTA Adjustment methodology (transitional) instead of "
            "computing the Simplified Adjustment for Negative Taxes. Provide the yearly Loss DTA Adjustment generated "
            "amount via LOSS_DTA_ADJUSTMENT_GENERATED_AMOUNT."
        ),
    ),
    ElectionDef(
        code="LOSS_DTA_ADJUSTMENT_GENERATED_AMOUNT",
        label="Loss DTA Adjustment generated for the year (Box 4.3(4) / para 116)",
        group="4.3 Negative taxes in loss years",
        scope="tax",
        value_type="amount",
        term_type="ANNUAL",
        description=(
            "Enter the Loss DTA Adjustment amount computed for the year (sum of the two components described in the OECD guidance). "
            "This tool treats it as a carryforward that can reduce future loss DTA reversals / Simplified Taxes, subject to limits."
        ),
    ),
    ElectionDef(
        code="LOSS_DTA_REVERSAL_TENTATIVE_AMOUNT",
        label="Tentative loss DTA reversal included in Simplified Taxes for the year (Box 4.3(4) / para 117)",
        group="4.3 Negative taxes in loss years",
        scope="tax",
        value_type="amount",
        term_type="ANNUAL",
        description=(
            "Optional. Enter the portion of deferred tax expense in the year that represents a loss DTA reversal. "
            "If provided, the Loss DTA Adjustment carryforward is capped so it cannot reduce this reversal below zero."
        ),
    ),

    # ----------------------------
    # 4.4 Annual elections
    # ----------------------------
    ElectionDef(
        code="ELECTION_INCLUDE_OTHER_COVERED_TAXES",
        label="Annual election: include Covered Taxes accrued as expense but not in income tax expense (Box 4.4(1) / Art 4.1.2(a))",
        group="4.4 Annual elections",
        scope="tax",
        value_type="amount",
        term_type="ANNUAL",
        target_field="election_include_other_covered_taxes",
    ),
    ElectionDef(
        code="ELECTION_INCLUDE_EQUITY_REPORTED_TAXES",
        label="Annual election: include Covered Taxes related to equity-reported income included in Simplified Income (Box 4.4(2))",
        group="4.4 Annual elections",
        scope="tax",
        value_type="amount",
        term_type="ANNUAL",
        target_field="election_include_equity_reported_taxes",
    ),
    ElectionDef(
        code="ELECTION_INCLUDE_QRTC_MTTC_CREDITS_IN_INCOME",
        label="Annual election: include QRTC/MTTC credits in Simplified Income (Box 4.4(3))",
        group="4.4 Annual elections",
        scope="income",
        value_type="amount",
        term_type="ANNUAL",
        target_field="election_include_qrtc_mttc_credits_in_income",
    ),
    ElectionDef(
        code="ELECTION_INCLUDE_QRTC_MTTC_CREDITS_IN_TAXES",
        label="Annual election: include QRTC/MTTC credits in Simplified Taxes (Box 4.4(3))",
        group="4.4 Annual elections",
        scope="tax",
        value_type="amount",
        term_type="ANNUAL",
        target_field="election_include_qrtc_mttc_credits_in_taxes",
    ),
    ElectionDef(
        code="GLOBE_LOSS_ELECTION_NOTE",
        label="GloBE Loss Election made (Box 4.4.5 / Art 4.5)",
        group="4.4 Annual elections",
        scope="metadata",
        value_type="bool",
        term_type="ANNUAL",
        target_field="globe_loss_election_applies",
        description=(
            "Record whether the GloBE Loss Election is made. When True, the engine will apply the OECD 4.2.4 mechanics: "
            "remove deferred tax expense/benefit attributable to DTAs/DTLs in the financial accounts and include only the "
            "deferred tax expense/benefit attributable to the GloBE Loss DTA."
        ),
    ),

    # ----------------------------
    # 4.6 Tax adjustments after year end
    # ----------------------------
    ElectionDef(
        code="AFTER_YEAR_END_ADJUSTMENTS_FIVE_YEAR_ELECTION_TRANSACTION_YEAR_METHOD",
        label="Five-Year Election to include tax/income adjustments accruing within 12 months in the transaction year (Box 4.6(2))",
        group="4.6 After year end adjustments",
        scope="metadata",
        value_type="bool",
        term_type="FIVE_YEAR",
        continues_until_revoked=True,
        revocable_after_years=5,
        continues_when_sh_not_applied=True,
        description=(
            "Record whether this election is used. If made, the election continues until revoked and applies "
            "regardless of whether the MNE Group applies the Simplified ETR Safe Harbour or the full GloBE Rules. "
            "Reflect the timing choice by inputting the amounts in the appropriate year."
        ),
    ),

    # ----------------------------
    # 5 Cross-border
    # ----------------------------
    ElectionDef(
        code="CROSS_BORDER_FIVE_YEAR_ELECTION_KEEP_ALLOCABLE_TAXES",
        label="Five-Year Election to not exclude allocable cross-border taxes from all Tested Jurisdictions (Box 5.1(2)/para 8)",
        group="5.1 Cross-border allocation",
        scope="metadata",
        value_type="bool",
        term_type="FIVE_YEAR",
        continues_until_revoked=True,
        revocable_after_years=5,
        continues_when_sh_not_applied=True,
        description=(
            "Record the election. If made, the election continues until revoked and applies regardless of whether the MNE Group "
            "applies the Simplified ETR Safe Harbour or the full GloBE Rules. Any net impacts on current-year allocations should "
            "be reflected via income/tax adjustments."
        ),
    ),
    ElectionDef(
        code="PE_SIMPLIFICATION_ELECTION_NOTE",
        label="PE Simplification Election (Box 5.1(3)-(4))",
        group="5.1 Cross-border allocation",
        scope="metadata",
        value_type="bool",
        term_type="ANNUAL",
        description=(
            "Record the PE simplification election. In the OECD guidance this is an Annual Election with a continuation requirement "
            "in certain cases (where a PE loss has been included). This tool currently records the election as metadata; reflect net "
            "effects on allocations through adjustments if needed."
        ),
    ),

    # ----------------------------
    # 5.2 Transfer pricing
    # ----------------------------
    ElectionDef(
        code="TP_FIVE_YEAR_ELECTION_TRANSACTION_YEAR_METHOD",
        label="Five-Year Election to include TP taxable income adjustments accruing within 12 months in the transaction year (Box 5.2(2))",
        group="5.2 Transfer pricing",
        scope="metadata",
        value_type="bool",
        term_type="FIVE_YEAR",
        continues_until_revoked=True,
        revocable_after_years=5,
        continues_when_sh_not_applied=True,
        description=(
            "Record the election. If made, the election continues until revoked and applies regardless of whether the MNE Group "
            "applies the Simplified ETR Safe Harbour or the full GloBE Rules. Reflect the timing choice by inputting the amounts in "
            "the appropriate year."
        ),
    ),
    ElectionDef(
        code="TP_NET_ADJUSTMENT_INCOME",
        label="Transfer pricing adjustments: net impact on JPBT for the year (Box 5.2)",
        group="5.2 Transfer pricing",
        scope="income",
        value_type="amount",
        term_type="ANNUAL",
        description="Enter net signed TP adjustment to JPBT for this year (whether accrual-year or transaction-year method is used).",
    ),
    ElectionDef(
        code="TP_NET_ADJUSTMENT_TAX",
        label="Transfer pricing adjustments: net impact on JITE for the year (Box 5.2)",
        group="5.2 Transfer pricing",
        scope="tax",
        value_type="amount",
        term_type="ANNUAL",
        description="Enter net signed TP-related Covered Tax change for this year.",
    ),

    # ----------------------------
    # 6 Tax-neutral entities
    # ----------------------------
    ElectionDef(
        code="STATELESS_EXCEPTION_SECTION_6_2_APPLIES",
        label="Stateless entity exception applies (Box 6.2 / Box 7.1(a) exception)",
        group="6 Tax-neutral entities",
        scope="eligibility",
        value_type="bool",
        term_type="ANNUAL",
        target_field="stateless_exception_section_6_2_applies",
        description=(
            "If True, treat a Stateless Constituent Entity Tested Jurisdiction as eligible for the safe harbour "
            "under the tax transparent entity rule in Section 6.2."
        ),
    ),
    ElectionDef(
        code="INVESTMENT_ENTITY_TAX_TRANSPARENCY_ELECTION_ART_7_5",
        label="Investment Entity Tax Transparency Election (Box 6.3 / Art 7.5)",
        group="6 Tax-neutral entities",
        scope="eligibility",
        value_type="bool",
        term_type="ANNUAL",
        target_field="investment_entity_tax_transparency_election_applies",
        description=(
            "If True, an Investment Entity may be treated as tax transparent for safe harbour purposes "
            "(Section 6.3 / Article 7.5; affects eligibility assessment)."
        ),
    ),
]


ELECTIONS_BY_CODE: dict[str, ElectionDef] = {e.code: e for e in ELECTION_DEFS}


def as_public_dict() -> list[dict[str, str]]:
    """Return a JSON-serialisable representation for the API/UI."""

    out: list[dict[str, str]] = []
    for e in ELECTION_DEFS:
        out.append(
            {
                "code": e.code,
                "label": e.label,
                "group": e.group,
                "scope": e.scope,
                "value_type": e.value_type,
                "term_type": e.term_type,
                "continues_until_revoked": str(bool(getattr(e, "continues_until_revoked", False))),
                "revocable_after_years": str(int(getattr(e, "revocable_after_years", 0) or 0)),
                # Back-compat: keep the original key name and also expose a clearer name.
                "cooldown_years": str(int(getattr(e, "cooldown_years", 0) or 0)),
                "cooldown_years_after_revocation": str(int(getattr(e, "cooldown_years", 0) or 0)),
                "continues_when_sh_not_applied": str(bool(getattr(e, "continues_when_sh_not_applied", False))),
                "level": str(getattr(e, "level", "TESTED_JURISDICTION")),
                "target_field": e.target_field or "",
                "description": e.description or "",
            }
        )
    return out
