from __future__ import annotations

import csv
import io
import re
from typing import Any, Dict, List, Optional, Tuple

from pydantic import BaseModel, Field

from app.services.models_v2 import EntityFactsV2


class CsvRowIssue(BaseModel):
    """Issue encountered while parsing a CSV row."""

    severity: str = Field(..., description="'error' or 'warning'")
    row_number: int = Field(..., ge=1, description="1-indexed row number in the CSV (excluding header).")
    field: Optional[str] = Field(default=None, description="Field name (if applicable).")
    message: str


class EntitiesCsvParseResult(BaseModel):
    """Structured parse result returned by /api/v2/entities/parse-csv."""

    entities: List[EntityFactsV2] = Field(default_factory=list)
    grouped_entities: Dict[str, List[EntityFactsV2]] = Field(
        default_factory=dict,
        description=(
            "If the CSV provides tested_jurisdiction_id, parsed entities are also grouped here by that id. "
            "Rows without a tested_jurisdiction_id are grouped under '__UNASSIGNED__'."
        ),
    )
    issues: List[CsvRowIssue] = Field(default_factory=list)
    detected_columns: List[str] = Field(default_factory=list)
    ignored_columns: List[str] = Field(default_factory=list)
    rows_with_tested_jurisdiction_id: bool = False


_NUM_RE = re.compile(r"[^0-9eE+\-\.]")


def _norm_header(h: str) -> str:
    # Lowercase, trim, replace spaces/dashes with underscores
    h = (h or "").strip().lower()
    h = re.sub(r"[\s\-]+", "_", h)
    return h


# Common aliases to make uploads more forgiving
_ALIASES: Dict[str, str] = {
    "pbt": "jpbt",
    "profit_before_tax": "jpbt",
    "profit_or_loss_before_tax": "jpbt",
    "current_tax": "current_tax_expense",
    "current_tax_charge": "current_tax_expense",
    "deferred_tax": "deferred_tax_expense",
    "deferred_tax_charge": "deferred_tax_expense",
    "entity": "entity_name",
    "name": "entity_name",
    "jurisdiction": "jurisdiction_code",
    "country": "jurisdiction_code",

"type": "entity_type",
"entity_type": "entity_type",
"upe": "is_upe",
"is_upe": "is_upe",
"qualified_persons_ownership": "qualified_persons_ownership_percentage",
"qualified_persons_ownership_percentage": "qualified_persons_ownership_percentage",
"pe": "pe_id",
"pe_id": "pe_id",
"main_entity": "main_entity_id",
"main_entity_id": "main_entity_id",

    # Module 15 scoping / groups
    "jv_group_id": "jv_group_id",
    "jv_id": "jv_group_id",
    "joint_venture_group_id": "jv_group_id",
    "moce_group_id": "moce_group_id",
    "moce_id": "moce_group_id",
    "minority_owned_group_id": "moce_group_id",

}


def _parse_bool(raw: str) -> Optional[bool]:
    s = (raw or "").strip().lower()
    if s == "":
        return None
    if s in {"true", "t", "yes", "y", "1"}:
        return True
    if s in {"false", "f", "no", "n", "0"}:
        return False
    return None


def _parse_float(raw: str) -> Optional[float]:
    """Parse float from a CSV cell.

    Supports:
    - thousand separators
    - currency symbols
    - parentheses for negatives
    """

    if raw is None:
        return None
    s = str(raw).strip()
    if s == "":
        return None

    neg = False
    if s.startswith("(") and s.endswith(")"):
        neg = True
        s = s[1:-1]

    # remove non-numeric characters except + - . e E
    s = _NUM_RE.sub("", s)
    if s in {"", "+", "-", "."}:
        return None
    try:
        v = float(s)
        return -v if neg else v
    except ValueError:
        return None


def generate_entities_csv_template() -> bytes:
    """Generate a CSV template for Entity roll-up uploads.

    v4 Module 12 note:
    - The v2 engine supports the full Box 3 (Simplified Income or Loss) adjustment set via the v1 calculator.
    - This template is intentionally broad so users can populate the major Section 3 adjustment inputs at
      entity level (where available in reporting packages).
    - Jurisdiction-only Box 3.1 helper inputs (e.g., PPA reversal) remain on the Tested Jurisdiction facts
      (jurisdiction-level) rather than in this entity CSV.
    """

    headers = [
        # Grouping / IDs
        "tested_jurisdiction_id",
        "jurisdiction_code",
        "entity_id",
        "entity_name",

        # Classification scaffolding (Module 5)
        "entity_type",
        "is_upe",
        "qualified_persons_ownership_percentage",
        "pe_id",
        "main_entity_id",
        "jv_group_id",
        "moce_group_id",

        # Starting points
        "jpbt",

        # ----------------------------
        # Section 3: Simplified Income or Loss (Box 3)
        # ----------------------------
        # Basic adjustments (Box 3.2)
        "excluded_dividends",
        "excluded_equity_gains_losses",
        "illegal_payments",
        "fines_penalties_ge_250k",

        # Industry adjustments (Box 3.3)
        # Financial services (Art 3.2.9 / 3.2.10)
        "insurance_company_income",
        "at1_rt1_payments_receipts_adjustment",
        "at1_rt1_corresponding_tax_in_equity",

        # Shipping (Art 3.3)
        "international_shipping_income",
        "qualified_ancillary_international_shipping_income",
        "taxes_on_excluded_shipping_income",

        # Conditional adjustments (Box 3.4)
        "equity_reported_items_amount",
        "mna_goodwill_impairment_or_amortisation_addback",
        "mna_article_6_3_4_election_amount",

        # Optional adjustments (Box 3.5.2)
        "asymmetric_fx_gain_loss",
        "accrued_pension_expense_adjustment",

        # ----------------------------
        # Section 4: Simplified Taxes (selected key fields)
        # ----------------------------
        "current_tax_expense",
        "deferred_tax_expense",
        "consolidated_level_deferred_tax",
        "accounted_tax_rate",

        "taxes_not_covered",
        "tax_refunds_and_credits_adjustment",
        "taxes_on_excluded_income",
        "uncertain_tax_positions_adjustment",
        "current_tax_not_paid_within_3y",

        "valuation_allowance_impact",
        "tax_rate_change_impact",
        "deferred_tax_from_tax_credits",
        "non_rea_dtl_deferred_tax_expense",
        # Module 13: non-REA DTL carve-ins (exceptions)
        "non_rea_dtl_carve_in_mna_reversal",
        "non_rea_dtl_carve_in_prior_etr_reversal",
        "non_rea_dtl_exception_applies",

        # Module 13: GloBE Loss Election (amount-only; election flag is jurisdiction-level)
        "globe_loss_dta_deferred_tax_expense",

        # M&A deferred-tax exclusions (optional; entity-level)
        "mna_deferred_tax_accruals_to_exclude",
        "mna_goodwill_related_dtl_reversal_to_exclude",

        # Elections (annual amounts)
        "election_include_other_covered_taxes",
        "election_include_equity_reported_taxes",
        "election_include_qrtc_mttc_credits_in_income",
        "election_include_qrtc_mttc_credits_in_taxes",
    ]

    example = {h: "" for h in headers}
    example.update(
        {
            "tested_jurisdiction_id": "GB_MAIN",
            "jurisdiction_code": "GB",
            "entity_id": "GB-1",
            "entity_name": "Example Entity 1",
            "entity_type": "STANDARD_CE",
            "is_upe": "false",
            "jpbt": "1000",
            "current_tax_expense": "160",
            "deferred_tax_expense": "0",
            "accounted_tax_rate": "0.25",
        }
    )

    buf = io.StringIO(newline="")
    writer = csv.DictWriter(buf, fieldnames=headers)
    writer.writeheader()
    writer.writerow(example)
    return buf.getvalue().encode("utf-8")


def parse_entities_csv(
    contents: bytes,
    *,
    default_tested_jurisdiction_id: Optional[str] = None,
    default_jurisdiction_code: Optional[str] = None,
) -> EntitiesCsvParseResult:
    """Parse entity roll-up CSV into EntityFactsV2 rows.

    Notes:
    - The v2 engine groups entities by tested_jurisdiction_id (bucket) rather than jurisdiction_code.
    - If a CSV includes tested_jurisdiction_id, it is carried through only as metadata for the UI.
      (EntityFactsV2 does not include tested_jurisdiction_id itself.)
    """

    text = contents.decode("utf-8-sig", errors="replace")
    buf = io.StringIO(text)

    reader = csv.DictReader(buf)
    if reader.fieldnames is None:
        return EntitiesCsvParseResult(
            entities=[],
            issues=[CsvRowIssue(severity="error", row_number=1, field=None, message="CSV is missing a header row.")],
        )

    # Build header mapping
    raw_headers = list(reader.fieldnames)
    norm_to_raw: Dict[str, str] = {}
    for h in raw_headers:
        nh = _norm_header(h)
        nh = _ALIASES.get(nh, nh)
        # first wins
        if nh and nh not in norm_to_raw:
            norm_to_raw[nh] = h

    detected = list(norm_to_raw.keys())
    out = EntitiesCsvParseResult(detected_columns=raw_headers)

    # Figure out which columns we can map to EntityFactsV2 scalar fields
    model_fields = EntityFactsV2.model_fields
    scalar_fields: set[str] = set()
    for fname, finfo in model_fields.items():
        ann = finfo.annotation
        # allow the common scalar fields
        if ann in {str, float, bool, Optional[str], Optional[float], Optional[bool], Optional[int], int}:
            scalar_fields.add(fname)

    # tested_jurisdiction_id is handled separately
    has_tj_col = "tested_jurisdiction_id" in detected
    out.rows_with_tested_jurisdiction_id = bool(has_tj_col or default_tested_jurisdiction_id)

    ignored_cols: List[str] = []
    for nh in detected:
        if nh in {"tested_jurisdiction_id"}:
            continue
        if nh not in scalar_fields and nh not in {"entity", "name", "pbt", "profit_before_tax"}:
            ignored_cols.append(norm_to_raw.get(nh, nh))
    out.ignored_columns = ignored_cols

    # Parse rows
    entities: List[EntityFactsV2] = []
    grouped: Dict[str, List[EntityFactsV2]] = {}
    issues: List[CsvRowIssue] = []

    for i, row in enumerate(reader, start=1):
        # 1-indexed data row number
        rownum = i
        data: Dict[str, Any] = {}

        # tested_jurisdiction_id meta
        tj_from_row = None
        if has_tj_col:
            tj_from_row = (row.get(norm_to_raw["tested_jurisdiction_id"]) or "").strip() or None
        tj_effective = default_tested_jurisdiction_id or tj_from_row

        # Map scalar fields
        for nh, raw_h in norm_to_raw.items():
            if nh == "tested_jurisdiction_id":
                continue
            if nh in _ALIASES:
                nh = _ALIASES[nh]

            if nh not in scalar_fields:
                continue

            raw_val = row.get(raw_h)
            ann = model_fields[nh].annotation
            if ann in {float, Optional[float], int, Optional[int]}:
                v = _parse_float(raw_val)
                if v is None:
                    continue
                data[nh] = float(v)
            elif ann in {bool, Optional[bool]}:
                bv = _parse_bool(str(raw_val) if raw_val is not None else "")
                if bv is None:
                    continue
                data[nh] = bool(bv)
            else:
                sv = ("" if raw_val is None else str(raw_val)).strip()
                if sv == "":
                    continue
                data[nh] = sv

        # Apply defaults for jurisdiction_code if provided
        if default_jurisdiction_code and not data.get("jurisdiction_code"):
            data["jurisdiction_code"] = default_jurisdiction_code

        # Required fields
        if not data.get("entity_name"):
            # Try entity_id, else fallback
            fallback = data.get("entity_id") or f"Entity {rownum}"
            data["entity_name"] = str(fallback)
            issues.append(
                CsvRowIssue(
                    severity="warning",
                    row_number=rownum,
                    field="entity_name",
                    message="entity_name missing; populated from entity_id/row number.",
                )
            )

        if data.get("jpbt") is None:
            issues.append(
                CsvRowIssue(
                    severity="error",
                    row_number=rownum,
                    field="jpbt",
                    message="jpbt is required and was not provided or could not be parsed as a number.",
                )
            )
            continue

        # Even though v2 allows jurisdiction_code=None, it can help the UI to carry it through.
        # If neither row nor default provides it, warn (but do not fail).
        if not data.get("jurisdiction_code"):
            issues.append(
                CsvRowIssue(
                    severity="warning",
                    row_number=rownum,
                    field="jurisdiction_code",
                    message=(
                        "jurisdiction_code missing. This is OK for v2 roll-up inside a Tested Jurisdiction, "
                        "but providing it helps validation and reporting."
                    ),
                )
            )

        # Build entity
        try:
            ent = EntityFactsV2(**data)
            entities.append(ent)
            key = tj_effective or "__UNASSIGNED__"
            grouped.setdefault(key, []).append(ent)

            if has_tj_col and not tj_effective:
                issues.append(
                    CsvRowIssue(
                        severity="warning",
                        row_number=rownum,
                        field="tested_jurisdiction_id",
                        message="tested_jurisdiction_id column exists but this row is blank; grouped under '__UNASSIGNED__'.",
                    )
                )
        except Exception as e:
            issues.append(
                CsvRowIssue(
                    severity="error",
                    row_number=rownum,
                    field=None,
                    message=f"Row could not be parsed into an entity: {e}",
                )
            )

    out.entities = entities
    out.grouped_entities = grouped
    out.issues = issues
    return out
