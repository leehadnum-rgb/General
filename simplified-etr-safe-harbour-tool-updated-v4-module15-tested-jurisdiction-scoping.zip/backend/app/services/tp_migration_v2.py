from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from datetime import date
from typing import Dict, List, Optional, Tuple

from app.services.models_v2 import (
    AfterYearEndAdjustmentV2,
    TPMigrateFromAYERequestV2,
    TPMigrateFromAYEResponseV2,
    TPMigrationIssueV2,
    TransferPricingAdjustmentV2,
)


@dataclass
class _GroupAgg:
    seller_id: str
    buyer_id: str
    transaction_year: date
    accrual_year: date
    months_after: Optional[int]
    within_12_override: Optional[bool]
    currency: Optional[str]
    amount_scale: Optional[str]
    label: Optional[str]
    base_id: Optional[str]

    seller_income: float = 0.0
    seller_tax: float = 0.0
    buyer_income: float = 0.0
    buyer_tax: float = 0.0

    # Track whether buyer income can safely default to -seller income
    buyer_income_is_pure_default_symmetry: bool = True

    # Special-case flags (OR)
    tp_accounted_at_cost: bool = False
    tp_intangible_asset_related: bool = False
    tp_loss_disallowed_deemed_tp_adjustment: bool = False

    notes: List[str] = None

    def __post_init__(self) -> None:
        if self.notes is None:
            self.notes = []


def _within_12_months(row: AfterYearEndAdjustmentV2) -> Optional[bool]:
    if row.accrued_within_12_months is not None:
        return bool(row.accrued_within_12_months)
    if row.months_after_transaction_year_end is None:
        return None
    return bool(row.months_after_transaction_year_end <= 12)


def migrate_tp_from_aye(payload: TPMigrateFromAYERequestV2) -> TPMigrateFromAYEResponseV2:
    """Convert TP-tagged AfterYearEndAdjustmentV2 rows into TransferPricingAdjustmentV2 register entries.

    - TP rows are identified where is_transfer_pricing_related=True.
    - Non-TP AYE rows are passed through unchanged.
    - TP rows are grouped (by default) so income + tax can be represented as a single linked TP event.
    """

    valid_ids = set(payload.tested_jurisdiction_ids or [])
    enforce_ids = payload.tested_jurisdiction_ids is not None

    remaining_aye: List[AfterYearEndAdjustmentV2] = []
    tp_rows: List[Tuple[int, AfterYearEndAdjustmentV2]] = []

    for idx, row in enumerate(payload.after_year_end_adjustments, start=1):
        if row.is_transfer_pricing_related:
            tp_rows.append((idx, row))
        else:
            remaining_aye.append(row)

    issues: List[TPMigrationIssueV2] = []

    def _err(row_number: int, row: AfterYearEndAdjustmentV2, msg: str) -> None:
        issues.append(
            TPMigrationIssueV2(
                severity="error",
                row_number=row_number,
                source_adjustment_id=row.adjustment_id,
                message=msg,
            )
        )

    def _warn(row_number: int, row: AfterYearEndAdjustmentV2, msg: str) -> None:
        issues.append(
            TPMigrationIssueV2(
                severity="warning",
                row_number=row_number,
                source_adjustment_id=row.adjustment_id,
                message=msg,
            )
        )

    # If user already has TP register entries AND TP-tagged AYE rows, the calc endpoint rejects
    # (no double counting). For migration, we allow it and produce an appended list.
    existing = list(payload.existing_transfer_pricing_adjustments or [])

    # Combine by adjustment_id/label + parties + timing, so income+tax merge.
    combine = bool(payload.options.combine_income_and_tax)
    groups: Dict[Tuple[object, ...], _GroupAgg] = {}
    per_row_groups: List[Tuple[int, AfterYearEndAdjustmentV2, _GroupAgg]] = []

    for row_number, row in tp_rows:
        seller_id = row.tested_jurisdiction_id
        buyer_id = row.tp_counterparty_tested_jurisdiction_id

        if not buyer_id:
            _err(row_number, row, "TP migration: tp_counterparty_tested_jurisdiction_id is required for TP-tagged AYE rows.")
            if not payload.options.drop_unmigrated_tp_rows:
                remaining_aye.append(row)
            continue

        if enforce_ids:
            if seller_id not in valid_ids:
                _err(row_number, row, f"TP migration: seller tested_jurisdiction_id '{seller_id}' not found in tested_jurisdiction_ids.")
                if not payload.options.drop_unmigrated_tp_rows:
                    remaining_aye.append(row)
                continue
            if buyer_id not in valid_ids:
                _err(row_number, row, f"TP migration: buyer tested_jurisdiction_id '{buyer_id}' not found in tested_jurisdiction_ids.")
                if not payload.options.drop_unmigrated_tp_rows:
                    remaining_aye.append(row)
                continue

        # Build grouping key
        base_id = row.adjustment_id
        label = row.label
        within12 = _within_12_months(row)

        if combine:
            key = (
                base_id or "",
                label or "",
                seller_id,
                buyer_id,
                row.transaction_year_fy_start,
                row.accrual_year_fy_start,
                row.months_after_transaction_year_end,
                within12,
                row.currency,
                row.amount_scale,
            )
        else:
            key = (
                row_number,
                seller_id,
                buyer_id,
                row.transaction_year_fy_start,
                row.accrual_year_fy_start,
            )

        agg = groups.get(key)
        if agg is None:
            agg = _GroupAgg(
                seller_id=seller_id,
                buyer_id=buyer_id,
                transaction_year=row.transaction_year_fy_start,
                accrual_year=row.accrual_year_fy_start,
                months_after=row.months_after_transaction_year_end,
                within_12_override=row.accrued_within_12_months,
                currency=row.currency,
                amount_scale=row.amount_scale,
                label=label,
                base_id=base_id,
            )
            groups[key] = agg

        # Special-case flags
        agg.tp_accounted_at_cost = agg.tp_accounted_at_cost or bool(row.tp_accounted_at_cost)
        agg.tp_intangible_asset_related = agg.tp_intangible_asset_related or bool(row.tp_intangible_asset_related)
        agg.tp_loss_disallowed_deemed_tp_adjustment = agg.tp_loss_disallowed_deemed_tp_adjustment or bool(
            row.tp_loss_disallowed_deemed_tp_adjustment
        )

        # Record note context
        if row.note:
            agg.notes.append(str(row.note))
        if row.adjustment_id or row.label:
            agg.notes.append(f"Migrated from AYE row {row_number}: {row.adjustment_id or row.label}")
        else:
            agg.notes.append(f"Migrated from AYE row {row_number}")

        # Apply amounts
        if row.kind == "income":
            agg.seller_income += float(row.amount or 0.0)

            # Determine buyer-side income contribution
            if not row.tp_apply_counterparty_income:
                agg.buyer_income_is_pure_default_symmetry = False
                buyer_contrib = 0.0
            elif row.tp_counterparty_income_amount is not None:
                agg.buyer_income_is_pure_default_symmetry = False
                buyer_contrib = float(row.tp_counterparty_income_amount)
            else:
                buyer_contrib = -float(row.amount or 0.0)
            agg.buyer_income += buyer_contrib

        elif row.kind == "tax":
            agg.seller_tax += float(row.amount or 0.0)
            if row.tp_counterparty_tax_amount is not None:
                agg.buyer_tax += float(row.tp_counterparty_tax_amount)
        else:
            _warn(row_number, row, f"TP migration: unsupported kind '{row.kind}' – row skipped.")
            if not payload.options.drop_unmigrated_tp_rows:
                remaining_aye.append(row)
            continue

        per_row_groups.append((row_number, row, agg))

    # Build register entries
    used_ids: Dict[str, int] = defaultdict(int)
    out_new: List[TransferPricingAdjustmentV2] = []
    combined_entries = 0

    for agg in groups.values():
        base_id = (agg.base_id or "").strip() or None
        if base_id is None:
            base_id = f"TP_MIG_{len(out_new) + 1:03d}"
        used_ids[base_id] += 1
        adj_id = base_id if used_ids[base_id] == 1 else f"{base_id}-{used_ids[base_id]}"

        # Determine whether to omit buyer income (default symmetry) or provide explicit
        special_case = agg.tp_accounted_at_cost or agg.tp_intangible_asset_related or agg.tp_loss_disallowed_deemed_tp_adjustment
        buyer_income_field: Optional[float]
        if special_case:
            buyer_income_field = float(agg.buyer_income)
        else:
            # If symmetry is pure default, omit (let engine default) to keep it simple
            if agg.buyer_income_is_pure_default_symmetry and float(agg.buyer_income) == -float(agg.seller_income):
                buyer_income_field = None
            else:
                buyer_income_field = float(agg.buyer_income)

        buyer_tax_field: Optional[float] = None if abs(float(agg.buyer_tax)) == 0.0 else float(agg.buyer_tax)

        note = "\n".join([n for n in agg.notes if n]) if agg.notes else None

        try:
            obj = TransferPricingAdjustmentV2(
                adjustment_id=adj_id,
                label=agg.label or adj_id,
                seller_tested_jurisdiction_id=agg.seller_id,
                buyer_tested_jurisdiction_id=agg.buyer_id,
                transaction_year_fy_start=agg.transaction_year,
                accrual_year_fy_start=agg.accrual_year,
                months_after_transaction_year_end=agg.months_after,
                accrued_within_12_months=_within_12_months(
                    AfterYearEndAdjustmentV2(
                        tested_jurisdiction_id=agg.seller_id,
                        kind="income",
                        amount=0.0,
                        transaction_year_fy_start=agg.transaction_year,
                        accrual_year_fy_start=agg.accrual_year,
                        months_after_transaction_year_end=agg.months_after,
                        accrued_within_12_months=agg.within_12_override,
                        is_transfer_pricing_related=True,
                        tp_counterparty_tested_jurisdiction_id=agg.buyer_id,
                    )
                ),
                seller_income_adjustment=float(agg.seller_income),
                seller_tax_adjustment=float(agg.seller_tax),
                buyer_income_adjustment=buyer_income_field,
                buyer_tax_adjustment=buyer_tax_field,
                tp_accounted_at_cost=bool(agg.tp_accounted_at_cost),
                tp_intangible_asset_related=bool(agg.tp_intangible_asset_related),
                tp_loss_disallowed_deemed_tp_adjustment=bool(agg.tp_loss_disallowed_deemed_tp_adjustment),
                currency=agg.currency,
                amount_scale=agg.amount_scale,
                note=note,
            )
            out_new.append(obj)
            combined_entries += 1
        except Exception as e:
            # If the combined entry cannot be validated, report an error
            issues.append(
                TPMigrationIssueV2(
                    severity="error",
                    row_number=1,
                    source_adjustment_id=adj_id,
                    message=f"TP migration: failed to build register entry '{adj_id}': {e}",
                )
            )

    # Combine with existing register entries
    out_all = existing + out_new

    migrated_tp_rows = len(tp_rows) - sum(1 for i in issues if i.severity == "error")
    skipped_tp_rows = sum(1 for i in issues if i.severity == "error")

    resp = TPMigrateFromAYEResponseV2(
        transfer_pricing_adjustments=out_all,
        remaining_after_year_end_adjustments=remaining_aye,
        issues=issues,
        migrated_tp_rows=migrated_tp_rows,
        combined_register_entries=combined_entries,
        skipped_tp_rows=skipped_tp_rows,
    )

    return resp
