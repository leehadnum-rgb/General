from __future__ import annotations

from datetime import date

import pytest

from app.services.builder_v2 import build_tested_jurisdictions_from_entities
from app.services.models_v2 import (
    AccountingBasisV2,
    CalculationRequestV2,
    EntityFactsV2,
    FiscalYearV2,
    TestedJurisdictionCompositionV2,
    TestedJurisdictionInputV2,
    TestedJurisdictionsBuildOptionsV2,
    TestedJurisdictionsBuildRequestV2,
)
from app.services.validate_v2 import validate_request_v2


def test_module15_builder_separates_jv_and_moce_groups() -> None:
    req = TestedJurisdictionsBuildRequestV2(
        entities=[
            EntityFactsV2(
                entity_id="E1",
                entity_name="GB JV Entity",
                jurisdiction_code="GB",
                jpbt=100.0,
                jv_group_id="JV1",
            ),
            EntityFactsV2(
                entity_id="E2",
                entity_name="GB Main Entity",
                jurisdiction_code="GB",
                jpbt=200.0,
            ),
            EntityFactsV2(
                entity_id="E3",
                entity_name="US MOCE Entity",
                jurisdiction_code="US",
                jpbt=50.0,
                moce_group_id="M1",
            ),
        ],
        options=TestedJurisdictionsBuildOptionsV2(
            separate_joint_venture_groups=True,
            separate_moce_groups=True,
            separate_investment_entities=True,
            separate_tax_neutral_upe=True,
            separate_tax_transparent_entities=True,
            separate_flow_through_entities=True,
            separate_stateless=True,
        ),
    )

    resp = build_tested_jurisdictions_from_entities(req)

    tj_ids = {tj.tested_jurisdiction_id for tj in resp.tested_jurisdictions}
    assert "GB_MAIN" in tj_ids
    assert "GB_JV_JV1_MAIN" in tj_ids
    assert "US_MOCE_M1_MAIN" in tj_ids

    by_entity = {a.entity_id: a for a in resp.assignments}
    assert by_entity["E1"].jv_group_id == "JV1"
    assert by_entity["E1"].tested_jurisdiction_id == "GB_JV_JV1_MAIN"
    assert by_entity["E3"].moce_group_id == "M1"
    assert by_entity["E3"].tested_jurisdiction_id == "US_MOCE_M1_MAIN"


def test_module15_validate_flags_mixed_jv_groups_in_one_tj() -> None:
    tj = TestedJurisdictionInputV2(
        tested_jurisdiction_id="GB_MAIN",
        jurisdiction_code="GB",
        label="GB Main",
        tested_jurisdiction_type="standard",
        accounting_basis=AccountingBasisV2(currency="GBP", amount_scale="UNITS"),
        composition=TestedJurisdictionCompositionV2(aggregation_method="ENTITY_ROLLUP"),
        entities=[
            EntityFactsV2(entity_id="A", entity_name="A", jurisdiction_code="GB", jpbt=10.0, jv_group_id="JV1"),
            EntityFactsV2(entity_id="B", entity_name="B", jurisdiction_code="GB", jpbt=20.0, jv_group_id="JV2"),
        ],
    )

    req = CalculationRequestV2(
        schema_version="2.7",
        ruleset_version="OECD_SBS_2026_01",
        fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
        tested_jurisdictions=[tj],
    )

    vr = validate_request_v2(req)
    codes = {i.code for i in vr.issues}
    assert "SCOPE_MIXED_JV_GROUP_IDS" in codes


def test_module15_entity_cannot_have_both_jv_and_moce() -> None:
    with pytest.raises(ValueError):
        EntityFactsV2(
            entity_id="X",
            entity_name="X",
            jurisdiction_code="GB",
            jpbt=1.0,
            jv_group_id="JV1",
            moce_group_id="M1",
        )
