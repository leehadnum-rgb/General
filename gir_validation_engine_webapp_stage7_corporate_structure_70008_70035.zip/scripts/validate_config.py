#!/usr/bin/env python3
"""Validate a config folder by loading it with the backend Pydantic models."""
import argparse
import sys
from pathlib import Path

# Ensure backend is importable when running from repo root
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.services.config_loader import load_config
from app.core.settings import Settings

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config-root", required=True)
    ap.add_argument("--config-version", required=True)
    args = ap.parse_args()

    cfg = load_config(args.config_root, args.config_version)
    print("OK")
    print(f"version={cfg.meta.config_version_id}")
    print(f"elements={len(cfg.elements)} section_cardinality={len(cfg.section_cardinality)} codelists={len(cfg.codelists)} error_codes={len(cfg.error_codes)}")

if __name__ == "__main__":
    main()
