#!/usr/bin/env python3
"""Seed a demo filing into a running API.

This is optional helper tooling for Sprint 0 demos.
"""
import argparse
import requests
from datetime import date

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--api", default="http://localhost:8000")
    ap.add_argument("--tenant", default="demo")
    ap.add_argument("--config", default="GIR_CONFIG_v1")
    args = ap.parse_args()

    resp = requests.post(f"{args.api}/filings", json={
        "tenant_id": args.tenant,
        "config_version_id": args.config,
        "period_start": "2025-01-01",
        "period_end": "2025-12-31",
        "reporting_currency": "USD"
    })
    resp.raise_for_status()
    filing = resp.json()
    print("Created filing:", filing["id"])

if __name__ == "__main__":
    main()
