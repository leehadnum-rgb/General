#!/usr/bin/env python3
"""Seed a demo dataset and exercise Sprint 2.0 export endpoints.

Usage:
  python scripts/seed_demo_sprint2_0.py --api http://localhost:8000 --out ./out

This script:
- creates a filing
- upserts registers (filers, jurisdictions, entities)
- upserts a couple of datapoints
- runs validations
- downloads:
  - effective datapoints CSV
  - validation report zip
"""

import argparse
import os
import requests


def post(url: str, payload):
    r = requests.post(url, json=payload)
    r.raise_for_status()
    return r.json()


def get_bytes(url: str):
    r = requests.get(url)
    r.raise_for_status()
    return r.content, r.headers.get("content-type")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--api", default="http://localhost:8000")
    ap.add_argument("--tenant", default="demo")
    ap.add_argument("--config", default="GIR_CONFIG_v1")
    ap.add_argument("--out", default="./out")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)

    filing = post(f"{args.api}/filings", {
        "tenant_id": args.tenant,
        "config_version_id": args.config,
        "period_start": "2025-01-01",
        "period_end": "2025-12-31",
        "reporting_currency": "USD",
    })
    filing_id = filing["id"]
    print("Created filing:", filing_id)

    # Filers
    post(f"{args.api}/filings/{filing_id}/filers:bulkUpsert", [
        {
            "filer_code": "FILER_UPE",
            "legal_name": "Demo UPE",
            "role": "UPE",
            "filing_ce_role": "GIR401",
            "jurisdiction_code": "US",
            "tin": "US-TIN-UPE",
            "id_rules": "GIR201",
            "globe_status": "GIR301",
        },
        {
            "filer_code": "FILER_POPE",
            "legal_name": "Demo POPE",
            "role": "POPE",
            "filing_ce_role": "GIR404",
            "jurisdiction_code": "GB",
            "tin": "GB-TIN-POPE",
            "id_rules": "GIR201",
            "globe_status": "GIR301",
        },
    ])

    # Jurisdictions
    post(f"{args.api}/filings/{filing_id}/jurisdictions:bulkUpsert", [
        {"jurisdiction_code": "US", "local_currency": "USD", "responsible_filer_code": "FILER_UPE"},
        {"jurisdiction_code": "GB", "local_currency": "GBP", "responsible_filer_code": "FILER_POPE"},
    ])

    # Entities
    post(f"{args.api}/filings/{filing_id}/entities:bulkUpsert", [
        {
            "entity_code": "CE_US_1",
            "legal_name": "US Sub 1",
            "jurisdiction_code": "US",
            "tin": "US-TIN-CE1",
            "included_in_gir": True,
            "filed_by_filer_code": "FILER_UPE",
            "id_rules": "GIR201",
            "globe_status": "GIR301",
            "parent_entity_code": "CE_GB_1",
            "ownership_type": "GIR801",
            "ownership_percentage": "100.0",
        },
        {
            "entity_code": "CE_GB_1",
            "legal_name": "GB Sub 1",
            "jurisdiction_code": "GB",
            "tin": "GB-TIN-CE1",
            "included_in_gir": True,
            "filed_by_filer_code": "FILER_POPE",
            "id_rules": "GIR201",
            "globe_status": "GIR301",
            "parent_entity_code": None,
            "ownership_type": "GIR801",
            "ownership_percentage": "100.0",
            "owner_tin_override": "US-TIN-UPE",
        },
    ])

    # Add one datapoint explicitly (to demonstrate persisted override vs derived)
    post(f"{args.api}/filings/{filing_id}/datapoints:bulkUpsert", [
        {
            "filer_code": "FILER_UPE",
            "xml_path": "/GLOBE_OECD/GLOBEBody/FilingInfo/AccountingInfo/Currency",
            "value_raw": "USD",
            "source": "import",
            "source_system": "demo",
        }
    ])

    # Run validation
    run = post(f"{args.api}/filings/{filing_id}/validation-runs", {"notes": "Sprint 2.0 demo run"})
    run_id = run["id"]
    print("Validation run:", run_id, "Blocking:", run["blocking_issues"], "Total:", run["total_issues"])

    # Exports
    eff_csv, _ = get_bytes(f"{args.api}/filings/{filing_id}/exports/effective-datapoints.csv")
    eff_path = os.path.join(args.out, f"effective_datapoints_{filing_id}.csv")
    with open(eff_path, "wb") as f:
        f.write(eff_csv)
    print("Wrote:", eff_path)

    rep_zip, _ = get_bytes(f"{args.api}/filings/{filing_id}/exports/validation-report.zip?run_id={run_id}")
    rep_path = os.path.join(args.out, f"validation_report_{filing_id}_{run_id}.zip")
    with open(rep_path, "wb") as f:
        f.write(rep_zip)
    print("Wrote:", rep_path)


if __name__ == "__main__":
    main()
