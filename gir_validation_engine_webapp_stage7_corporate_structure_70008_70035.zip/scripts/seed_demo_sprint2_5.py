#!/usr/bin/env python3
"""Seed a demo dataset and exercise Sprint 2.5 dashboard + export endpoints.

Usage:
  python scripts/seed_demo_sprint2_5.py --api http://localhost:8000 --out ./out

This script:
- creates a filing
- upserts registers (filers, jurisdictions, entities)
- upserts a couple of datapoints
- runs validations
- downloads:
  - pack completeness dashboard JSON
  - pack completeness dashboard CSV
  - pack completeness dashboard JSON for one jurisdiction (include_filers=false)
"""

import argparse
import os
import json
import requests


def post(url: str, payload):
    r = requests.post(url, json=payload, timeout=60)
    r.raise_for_status()
    return r.json()


def get(url: str):
    r = requests.get(url, timeout=60)
    r.raise_for_status()
    return r


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--api", required=True, help="API base URL, e.g. http://localhost:8000")
    ap.add_argument("--out", default="./out", help="Output folder")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)

    # 1) Create filing
    filing = post(f"{args.api}/filings", {
        "tenant_id": "demo",
        "config_version_id": "GIR_CONFIG_v1",
        "period_start": "2025-01-01",
        "period_end": "2025-12-31",
        "reporting_currency": "USD"
    })
    filing_id = filing["id"]
    print("Created filing", filing_id)

    # 2) Registers
    post(f"{args.api}/filings/{filing_id}/filers:bulkUpsert", [
        {"filer_code":"FE01","legal_name":"ParentCo","role":"UPE","jurisdiction_code":"US","tin":"12-3456789"},
        {"filer_code":"FE02","legal_name":"HoldCo","role":"POPE","jurisdiction_code":"DE","tin":"DE123"},
    ])

    post(f"{args.api}/filings/{filing_id}/jurisdictions:bulkUpsert", [
        {"jurisdiction_code":"US","local_currency":"USD","responsible_filer_code":"FE01","computation_mode":"Full ETR computation","qdmt_applicable": False},
        {"jurisdiction_code":"DE","local_currency":"EUR","responsible_filer_code":"FE02","computation_mode":"QDMTT","qdmt_applicable": True},
    ])

    post(f"{args.api}/filings/{filing_id}/entities:bulkUpsert", [
        {"entity_code":"E001","legal_name":"US Co","jurisdiction_code":"US","tin":"US-TIN-1","included_in_gir":True,"filed_by_filer_code":"FE01"},
        {"entity_code":"E002","legal_name":"DE Co","jurisdiction_code":"DE","tin":"DE-TIN-2","included_in_gir":True,"filed_by_filer_code":"FE02"},
    ])

    # 3) Minimal datapoints (to show some 'present')
    post(f"{args.api}/filings/{filing_id}/datapoints:bulkUpsert", [
        {
            "filer_code":"FE01",
            "xml_path":"/GLOBE_OECD/GLOBEBody/FilingInfo/DocSpec/DocTypeIndic",
            "value_raw":"OECD0",
            "source":"manual"
        },
        {
            "filer_code":"FE01",
            "xml_path":"/GLOBE_OECD/GLOBEBody/FilingInfo/DocSpec/DocRefId",
            "value_raw":"DOCREF-001",
            "source":"manual"
        }
    ])

    # 4) Run validation (optional but common)
    run = post(f"{args.api}/filings/{filing_id}/validation-runs", {"notes":"Sprint 2.5 demo"})
    run_id = run["id"]
    print("Validation run", run_id)

    # 5) Dashboard JSON
    r = get(f"{args.api}/filings/{filing_id}/reconciliation/pack-completeness-dashboard")
    with open(os.path.join(args.out, f"pack_dashboard_{filing_id}.json"), "w", encoding="utf-8") as f:
        f.write(r.text)

    # 6) Dashboard export JSON
    r = get(f"{args.api}/filings/{filing_id}/exports/pack-completeness-dashboard.json?pretty=true")
    with open(os.path.join(args.out, f"pack_dashboard_export_{filing_id}.json"), "w", encoding="utf-8") as f:
        f.write(r.text)

    # 7) Dashboard export CSV
    r = get(f"{args.api}/filings/{filing_id}/exports/pack-completeness-dashboard.csv")
    with open(os.path.join(args.out, f"pack_dashboard_export_{filing_id}.csv"), "wb") as f:
        f.write(r.content)

    # 8) Single jurisdiction card (no filers)
    r = get(f"{args.api}/filings/{filing_id}/reconciliation/pack-completeness-dashboard?jurisdiction_code=US&include_filers=false")
    with open(os.path.join(args.out, f"pack_dashboard_US_{filing_id}.json"), "w", encoding="utf-8") as f:
        f.write(r.text)

    print("Done. Outputs written to", args.out)


if __name__ == "__main__":
    main()
