#!/usr/bin/env python3
"""Seed a register-driven demo dataset (Sprint 1.3) and run validations.

Sprint 1.3 introduces a register->datapoint bridge, so many common GIR fields are
derived automatically during validation (without being explicitly stored as datapoints).

Usage:
  python scripts/seed_demo_sprint1_3.py --api http://localhost:8000
"""

import argparse
import requests


def post(url: str, payload):
    r = requests.post(url, json=payload)
    r.raise_for_status()
    return r.json()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--api", default="http://localhost:8000")
    ap.add_argument("--tenant", default="demo")
    ap.add_argument("--config", default="GIR_CONFIG_v1")
    args = ap.parse_args()

    # 1) Create filing
    filing = post(f"{args.api}/filings", {
        "tenant_id": args.tenant,
        "config_version_id": args.config,
        "period_start": "2025-01-01",
        "period_end": "2025-12-31",
        "reporting_currency": "USD",
    })
    filing_id = filing["id"]
    print("Created filing:", filing_id)

    # 2) Register filers (note: filing_ce_role + id_rules + globe_status are new in Sprint 1.3)
    post(f"{args.api}/filings/{filing_id}/filers:bulkUpsert", [
        {
            "filer_code": "FILER_UPE",
            "legal_name": "Demo UPE",
            "role": "UPE",
            "filing_ce_role": "GIR401",
            "jurisdiction_code": "US",
            "tin": "US-TIN-UPE",
            "id_rules": "GIR201",
            "globe_status": "GIR301",
        },
        {
            "filer_code": "FILER_POPE",
            "legal_name": "Demo POPE",
            "role": "POPE",
            "filing_ce_role": "GIR404",
            "jurisdiction_code": "GB",
            "tin": "GB-TIN-POPE",
            "id_rules": "GIR201",
            "globe_status": "GIR301",
        },
    ])

    # 3) Register jurisdictions + responsible filers
    post(f"{args.api}/filings/{filing_id}/jurisdictions:bulkUpsert", [
        {"jurisdiction_code": "US", "local_currency": "USD", "responsible_filer_code": "FILER_UPE"},
        {"jurisdiction_code": "GB", "local_currency": "GBP", "responsible_filer_code": "FILER_POPE"},
    ])

    # 4) Register constituent entities with minimal ownership fields
    post(f"{args.api}/filings/{filing_id}/entities:bulkUpsert", [
        {
            "entity_code": "CE_US_1",
            "legal_name": "US Sub 1",
            "jurisdiction_code": "US",
            "tin": "US-TIN-CE1",
            "included_in_gir": True,
            "filed_by_filer_code": "FILER_UPE",
            "id_rules": "GIR201",
            "globe_status": "GIR301",
            "parent_entity_code": None,
            "ownership_type": "GIR801",
            "ownership_percentage": 100,
        },
        {
            "entity_code": "CE_GB_1",
            "legal_name": "GB Sub 1",
            "jurisdiction_code": "GB",
            "tin": "GB-TIN-CE1",
            "included_in_gir": True,
            "filed_by_filer_code": "FILER_POPE",
            "id_rules": "GIR201",
            "globe_status": "GIR301",
            "parent_entity_code": "CE_US_1",
            "ownership_type": "GIR801",
            "ownership_percentage": 100,
        },
    ])

    # 5) Run validations (you will still see missing fields that are not mapped/derived yet)
    run = post(f"{args.api}/filings/{filing_id}/validation-runs", {"notes": "Sprint 1.3 demo run"})
    print("Validation run:", run["id"], "blocking:", run["blocking_issues"], "warnings:", run["warning_issues"])
    print("See issues at:", f"{args.api}/filings/{filing_id}/validation-runs/{run['id']}/issues")


if __name__ == "__main__":
    main()
