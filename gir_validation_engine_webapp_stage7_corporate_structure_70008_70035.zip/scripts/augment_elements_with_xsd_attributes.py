#!/usr/bin/env python3
"""Augment an existing config/<version>/elements.json with attribute xpaths from the OECD GIR XSD.

This is useful when you:
- already have an Excel-derived config pack (elements.json, error_codes.json, etc.)
- want to add XSD-driven attribute nodes (e.g. /.../TIN/@issuedBy) without re-running the full
  workbook extraction.

Example:
  python scripts/augment_elements_with_xsd_attributes.py \
    --config-dir config/GIR_CONFIG_v1 \
    --xsd-zip globe-xsd.zip

It will update:
- elements.json (adds attribute entries)
- config.json (adds source_xsd_sha256 + attributes_added metadata)

By default, only required attributes are added. Use --include-optional-attributes to include optional ones too.
"""

import argparse
import hashlib
import json
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import xml.etree.ElementTree as ET

XSD_NS = "http://www.w3.org/2001/XMLSchema"

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def sha256_dir_xsd(dir_path: Path) -> str:
    parts: List[str] = []
    for p in sorted(dir_path.rglob("*.xsd")):
        try:
            parts.append(f"{p.name}:{sha256_file(p)}")
        except Exception:
            continue
    h = hashlib.sha256()
    h.update("\n".join(parts).encode("utf-8"))
    return h.hexdigest()

def export_json(obj: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)

def _lname(tag: str) -> str:
    if tag.startswith("{"):
        return tag.split("}", 1)[1]
    return tag

def _strip_prefix(qname: Optional[str]) -> Optional[str]:
    if not qname:
        return qname
    return qname.split(":", 1)[-1]

@dataclass(frozen=True)
class XsdAttr:
    name: str
    required: bool
    xsd_type: Optional[str] = None
    allowed_values: Tuple[str, ...] = ()

def _parse_simpletype_enums(st: ET.Element) -> List[str]:
    enums: List[str] = []
    for e in st.findall(f".//{{{XSD_NS}}}enumeration"):
        v = e.attrib.get("value")
        if v is not None and str(v).strip() != "":
            enums.append(str(v).strip())
    return list(dict.fromkeys(enums))

def _load_xsd_documents(xsd_dir: Optional[Path], xsd_zip: Optional[Path]) -> List[ET.ElementTree]:
    trees: List[ET.ElementTree] = []
    if xsd_dir:
        for p in sorted(xsd_dir.rglob("*.xsd")):
            try:
                trees.append(ET.parse(p))
            except Exception:
                continue
    if xsd_zip:
        with zipfile.ZipFile(xsd_zip, "r") as z:
            for name in sorted([n for n in z.namelist() if n.lower().endswith(".xsd")]):
                try:
                    data = z.read(name)
                    trees.append(ET.ElementTree(ET.fromstring(data)))
                except Exception:
                    continue
    return trees

def _build_xsd_index(trees: List[ET.ElementTree]) -> Dict[str, Any]:
    complex_types: Dict[str, ET.Element] = {}
    attribute_groups: Dict[str, ET.Element] = {}
    global_attributes: Dict[str, ET.Element] = {}
    simple_types: Dict[str, List[str]] = {}

    for t in trees:
        root = t.getroot()
        for st in root.findall(f".//{{{XSD_NS}}}simpleType[@name]"):
            name = st.attrib.get("name")
            if name:
                enums = _parse_simpletype_enums(st)
                if enums:
                    simple_types[_strip_prefix(name) or name] = enums

        for ag in root.findall(f".//{{{XSD_NS}}}attributeGroup[@name]"):
            name = ag.attrib.get("name")
            if name:
                attribute_groups[_strip_prefix(name) or name] = ag

        for a in root.findall(f".//{{{XSD_NS}}}attribute[@name]"):
            name = a.attrib.get("name")
            if name:
                global_attributes[_strip_prefix(name) or name] = a

        for ct in root.findall(f".//{{{XSD_NS}}}complexType[@name]"):
            name = ct.attrib.get("name")
            if name:
                complex_types[_strip_prefix(name) or name] = ct

    return {
        "complex_types": complex_types,
        "attribute_groups": attribute_groups,
        "global_attributes": global_attributes,
        "simple_types": simple_types,
    }

def _iter_attr_related_nodes(node: ET.Element) -> List[ET.Element]:
    out: List[ET.Element] = []
    def rec(n: ET.Element):
        for ch in list(n):
            ln = _lname(ch.tag)
            if ln == "element":
                continue
            if ln in {"attribute", "attributeGroup"}:
                out.append(ch)
                continue
            rec(ch)
    rec(node)
    return out

def _resolve_attr_type_and_enums(a: ET.Element, idx: Dict[str, Any]) -> Tuple[Optional[str], List[str]]:
    simple_types: Dict[str, List[str]] = idx["simple_types"]
    global_attrs: Dict[str, ET.Element] = idx["global_attributes"]

    t = _strip_prefix(a.attrib.get("type"))
    enums: List[str] = []
    if t and t in simple_types:
        return t, simple_types[t]

    st = a.find(f"./{{{XSD_NS}}}simpleType")
    if st is not None:
        enums = _parse_simpletype_enums(st)
        return t, enums

    ref = _strip_prefix(a.attrib.get("ref"))
    if ref and ref in global_attrs:
        ga = global_attrs[ref]
        t2 = _strip_prefix(ga.attrib.get("type"))
        if t2 and t2 in simple_types:
            return t2, simple_types[t2]
        st2 = ga.find(f"./{{{XSD_NS}}}simpleType")
        if st2 is not None:
            enums = _parse_simpletype_enums(st2)
        return t2, enums

    return t, enums

def _collect_attrs_for_complex_type(type_name: str, idx: Dict[str, Any], _seen: Optional[set]=None) -> List[XsdAttr]:
    complex_types: Dict[str, ET.Element] = idx["complex_types"]
    attribute_groups: Dict[str, ET.Element] = idx["attribute_groups"]

    if _seen is None:
        _seen = set()
    if type_name in _seen:
        return []
    _seen.add(type_name)

    ct = complex_types.get(type_name)
    if ct is None:
        return []

    attrs: List[XsdAttr] = []

    base = None
    ext = ct.find(f".//{{{XSD_NS}}}extension")
    if ext is None:
        ext = ct.find(f".//{{{XSD_NS}}}restriction")
    if ext is not None and ext.attrib.get("base"):
        base = _strip_prefix(ext.attrib.get("base"))
    if base:
        attrs.extend(_collect_attrs_for_complex_type(base, idx, _seen))

    for n in _iter_attr_related_nodes(ct):
        ln = _lname(n.tag)
        if ln == "attributeGroup":
            ref = _strip_prefix(n.attrib.get("ref"))
            if not ref:
                ref = _strip_prefix(n.attrib.get("name"))
            if ref and ref in attribute_groups:
                grp = attribute_groups[ref]
                for gn in _iter_attr_related_nodes(grp):
                    if _lname(gn.tag) != "attribute":
                        continue
                    aname = _strip_prefix(gn.attrib.get("name")) or _strip_prefix(gn.attrib.get("ref")) or ""
                    if not aname:
                        continue
                    required = (gn.attrib.get("use") == "required")
                    atype, enums = _resolve_attr_type_and_enums(gn, idx)
                    attrs.append(XsdAttr(name=aname, required=required, xsd_type=atype, allowed_values=tuple(enums)))
            continue

        if ln == "attribute":
            aname = _strip_prefix(n.attrib.get("name")) or _strip_prefix(n.attrib.get("ref")) or ""
            if not aname:
                continue
            required = (n.attrib.get("use") == "required")
            atype, enums = _resolve_attr_type_and_enums(n, idx)
            attrs.append(XsdAttr(name=aname, required=required, xsd_type=atype, allowed_values=tuple(enums)))

    by_name: Dict[str, XsdAttr] = {}
    for a in attrs:
        ex = by_name.get(a.name)
        if ex is None:
            by_name[a.name] = a
        else:
            req = ex.required or a.required
            enums = tuple(dict.fromkeys(list(ex.allowed_values) + list(a.allowed_values)))
            t = ex.xsd_type or a.xsd_type
            by_name[a.name] = XsdAttr(name=a.name, required=req, xsd_type=t, allowed_values=enums)

    return list(by_name.values())

def augment_elements(elements: List[Dict[str, Any]], type_to_attrs: Dict[str, List[XsdAttr]], include_optional: bool) -> Dict[str, int]:
    existing = {e.get("xpath") for e in elements if isinstance(e.get("xpath"), str)}
    added = 0
    required_added = 0
    for e in list(elements):
        xtype = _strip_prefix(e.get("xsd_type"))
        if not xtype:
            continue
        attrs = type_to_attrs.get(xtype, [])
        if not attrs:
            continue
        for a in attrs:
            if (not a.required) and (not include_optional):
                continue
            axp = f"{e['xpath']}/@{a.name}"
            if axp in existing:
                continue
            existing.add(axp)
            added += 1
            if a.required:
                required_added += 1
            hl = e.get("hierarchy_level")
            try:
                hl2 = int(hl) + 1 if hl is not None else None
            except Exception:
                hl2 = None
            elements.append({
                "section": e.get("section", ""),
                "element_name": f"@{a.name}",
                "tax_label": f"{e.get('tax_label','').strip()} — @{a.name}".strip(" —"),
                "guidance": None,
                "input_field": False,
                "example_value": None,
                "required": bool(a.required),
                "repeatable": False,
                "repeatability_scope": "Attribute (non-repeatable)",
                "allowed_values": list(a.allowed_values) if a.allowed_values else [],
                "is_container": False,
                "xsd_type": a.xsd_type,
                "min_occurs": 1 if a.required else 0,
                "max_occurs": 1,
                "xpath": axp,
                "hierarchy_level": hl2,
                "xml_hierarchy_path": None,
            })
    return {"attributes_added": added, "required_attributes_added": required_added}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config-dir", required=True, help="Path to config folder (e.g. config/GIR_CONFIG_v1)")
    ap.add_argument("--xsd-dir", default=None, help="Directory containing .xsd files")
    ap.add_argument("--xsd-zip", default=None, help="Path to OECD GIR XSD ZIP")
    ap.add_argument("--include-optional-attributes", action="store_true", help="Include optional attributes too")
    args = ap.parse_args()

    cfg_dir = Path(args.config_dir).expanduser().resolve()
    if not cfg_dir.exists():
        raise SystemExit(f"Config dir not found: {cfg_dir}")
    xsd_dir = Path(args.xsd_dir).expanduser().resolve() if args.xsd_dir else None
    xsd_zip = Path(args.xsd_zip).expanduser().resolve() if args.xsd_zip else None
    if xsd_dir and not xsd_dir.exists():
        raise SystemExit(f"XSD dir not found: {xsd_dir}")
    if xsd_zip and not xsd_zip.exists():
        raise SystemExit(f"XSD zip not found: {xsd_zip}")
    if xsd_dir and xsd_zip:
        raise SystemExit("Provide only one of --xsd-dir or --xsd-zip")

    elements_path = cfg_dir / "elements.json"
    config_path = cfg_dir / "config.json"
    if not elements_path.exists():
        raise SystemExit(f"elements.json not found: {elements_path}")
    if not config_path.exists():
        raise SystemExit(f"config.json not found: {config_path}")

    elements = json.loads(elements_path.read_text(encoding="utf-8"))
    meta = json.loads(config_path.read_text(encoding="utf-8"))

    trees = _load_xsd_documents(xsd_dir, xsd_zip)
    idx = _build_xsd_index(trees)

    used_types = sorted({(_strip_prefix(e.get("xsd_type")) or "").strip() for e in elements if e.get("xsd_type")})
    used_types = [t for t in used_types if t]
    type_to_attrs: Dict[str, List[XsdAttr]] = {}
    for tname in used_types:
        attrs = _collect_attrs_for_complex_type(tname, idx)
        if attrs:
            type_to_attrs[tname] = attrs

    stats = augment_elements(elements, type_to_attrs, include_optional=bool(args.include_optional_attributes))

    # update meta for traceability
    if xsd_zip:
        meta["source_xsd_sha256"] = sha256_file(xsd_zip)
        meta["source_xsd_source"] = str(xsd_zip)
    if xsd_dir:
        meta["source_xsd_sha256"] = sha256_dir_xsd(xsd_dir)
        meta["source_xsd_source"] = str(xsd_dir)
    meta.update(stats)

    export_json(elements, elements_path)
    export_json(meta, config_path)

    print("OK")
    print(f"Updated {elements_path} (+{stats['attributes_added']} attrs, required={stats['required_attributes_added']})")
    print(f"Updated {config_path} with source_xsd_sha256 + stats")

if __name__ == "__main__":
    main()
