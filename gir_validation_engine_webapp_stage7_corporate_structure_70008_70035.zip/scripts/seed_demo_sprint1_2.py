#!/usr/bin/env python3
"""Seed a small multi-filer demo dataset and run validations.

This helper script is optional. It demonstrates Sprint 1.2 features:
- filer-scoped requiredness
- jurisdiction-scoped requiredness using responsible_filer_code
- OECD error code mapping for DocRefId/CorrDocRefId rules

Usage:
  python scripts/seed_demo_sprint1_2.py --api http://localhost:8000
"""

import argparse
import requests


def post(url: str, payload: dict):
    r = requests.post(url, json=payload)
    r.raise_for_status()
    return r.json()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--api", default="http://localhost:8000")
    ap.add_argument("--tenant", default="demo")
    ap.add_argument("--config", default="GIR_CONFIG_v1")
    args = ap.parse_args()

    # 1) Create filing
    filing = post(f"{args.api}/filings", {
        "tenant_id": args.tenant,
        "config_version_id": args.config,
        "period_start": "2025-01-01",
        "period_end": "2025-12-31",
        "reporting_currency": "USD",
    })
    filing_id = filing["id"]
    print("Created filing:", filing_id)

    # 2) Upsert two filers
    post(f"{args.api}/filings/{filing_id}/filers:bulk_upsert", {
        "items": [
            {"filer_code": "FILER_UPE", "legal_name": "Demo UPE", "role": "UPE", "jurisdiction_code": "US"},
            {"filer_code": "FILER_POPE", "legal_name": "Demo POPE", "role": "POPE", "jurisdiction_code": "GB"},
        ]
    })

    # 3) Register jurisdictions with responsible filers
    post(f"{args.api}/filings/{filing_id}/jurisdictions:bulk_upsert", {
        "items": [
            {"jurisdiction_code": "US", "local_currency": "USD", "responsible_filer_code": "FILER_UPE"},
            {"jurisdiction_code": "GB", "local_currency": "GBP", "responsible_filer_code": "FILER_POPE"},
        ]
    })

    # 4) Seed datapoints to trigger a few validations
    # NOTE: These are intentionally incomplete / inconsistent to show issues.
    # DocRefId duplicate within FILER_UPE (General vs Summary)
    # CorrDocRefId unknown record
    post(f"{args.api}/filings/{filing_id}/datapoints:bulk_upsert", {
        "items": [
            # FilingInfo (per filer) - only provide for one filer to show filer-scoped missing
            {"filer_code": "FILER_UPE", "xml_path": "/GLOBE_OECD/GLOBEBody/FilingInfo/FilingJurisdiction", "value_raw": "US"},

            # General docspec (UPE)
            {"filer_code": "FILER_UPE", "xml_path": "/GLOBE_OECD/GLOBEBody/GeneralSection/DocSpec/DocTypeIndic", "value_raw": "OECD1"},
            {"filer_code": "FILER_UPE", "xml_path": "/GLOBE_OECD/GLOBEBody/GeneralSection/DocSpec/DocRefId", "value_raw": "US2025-DEMO-0001"},

            # Summary docspec (UPE) - same DocRefId to trigger 60007
            {"filer_code": "FILER_UPE", "xml_path": "/GLOBE_OECD/GLOBEBody/Summary/DocSpec/DocTypeIndic", "value_raw": "OECD1"},
            {"filer_code": "FILER_UPE", "xml_path": "/GLOBE_OECD/GLOBEBody/Summary/DocSpec/DocRefId", "value_raw": "US2025-DEMO-0001"},

            # CorrDocRefId provided even though DocTypeIndic is OECD1 -> triggers 60012
            {"filer_code": "FILER_UPE", "xml_path": "/GLOBE_OECD/GLOBEBody/GeneralSection/DocSpec/CorrDocRefId", "value_raw": "US2024-UNKNOWN-9999"},

            # JurisdictionSection minimal rows (scoped by responsible filer)
            {"filer_code": "FILER_UPE", "jurisdiction_code": "US", "xml_path": "/GLOBE_OECD/GLOBEBody/JurisdictionSection/RecJurCode", "value_raw": "US"},
            {"filer_code": "FILER_POPE", "jurisdiction_code": "GB", "xml_path": "/GLOBE_OECD/GLOBEBody/JurisdictionSection/RecJurCode", "value_raw": "GB"},
        ]
    })

    # 5) Run validations
    run = post(f"{args.api}/filings/{filing_id}/validation-runs", {"notes": "Seed demo Sprint 1.2"})
    run_id = run["id"]
    print("Validation run:", run_id)

    # 6) Fetch and print blocking issues
    issues = requests.get(
        f"{args.api}/filings/{filing_id}/validation-runs/{run_id}/issues",
        params={"severity": "BLOCKING", "limit": 2000, "offset": 0},
    )
    issues.raise_for_status()
    data = issues.json()
    print(f"Blocking issues: {data['count']}")
    for it in data["items"][:25]:
        print(f"- {it.get('severity')} | error={it.get('error_number')} | filer={it.get('filer_code')} | juris={it.get('jurisdiction_code')} | path={it.get('xml_path')}")
        print(f"  {it.get('message')}")


if __name__ == "__main__":
    main()
