#!/usr/bin/env python3
"""Extract GIR configuration JSON from the Excel GIR toolkit.

This script is intentionally **data-driven**:
- It reads the master element library (paths, requiredness, allowed values, etc.)
- It reads section cardinality
- It reads lists/codelists
- It reads OECD error codes

Stage 4.6 (attributes):
-----------------------
The Excel toolkit often omits **XML attributes** that exist in the OECD XSD (e.g. TIN metadata),
which means attribute-aware validations cannot be driven from `elements.json`.

This script can optionally ingest the OECD GIR XSD package (directory of .xsd files or a ZIP)
and will add attribute entries into `elements.json` using XPath syntax:

  /.../TIN/@issuedBy

and will mark required attributes (XSD `use="required"`) with:
  required=true, min_occurs=1

By default we only add *required* attributes to avoid noisy configs. Use
`--include-optional-attributes` if you also want optional attributes included.

Usage:
  python scripts/extract_config_from_excel.py \
    --workbook <file.xlsx> \
    --config-version GIR_CONFIG_v1 \
    --outdir config/GIR_CONFIG_v1 \
    --xsd-zip globe-xsd.zip

or

  python scripts/extract_config_from_excel.py --workbook <file.xlsx> --config-version GIR_CONFIG_v1 --outdir config/GIR_CONFIG_v1 --xsd-dir ./globe-xsd/

"""

import argparse
import hashlib
import io
import json
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import pandas as pd
import numpy as np
import xml.etree.ElementTree as ET

XSD_NS = "http://www.w3.org/2001/XMLSchema"

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def sha256_dir_xsd(dir_path: Path) -> str:
    """Compute a stable hash for an XSD directory (file names + file sha256)."""
    parts: List[str] = []
    for p in sorted(dir_path.rglob("*.xsd")):
        try:
            parts.append(f"{p.name}:{sha256_file(p)}")
        except Exception:
            continue
    h = hashlib.sha256()
    h.update("\n".join(parts).encode("utf-8"))
    return h.hexdigest()

def yn_to_bool(v: Any) -> bool:
    if isinstance(v, str):
        return v.strip().lower() in ("y", "yes", "true", "1")
    if isinstance(v, (int, float)) and not np.isnan(v):
        return bool(v)
    return False

def parse_max_occurs(v: Any) -> Optional[Union[int, str]]:
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return None
    if isinstance(v, str):
        s = v.strip()
        if s == "":
            return None
        if s.lower() == "unbounded":
            return "unbounded"
        # numeric string
        try:
            return int(float(s))
        except Exception:
            return s
    if isinstance(v, (int, np.integer)):
        return int(v)
    if isinstance(v, float):
        if np.isnan(v):
            return None
        return int(v)
    return str(v)

def parse_min_occurs(v: Any) -> Optional[int]:
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return None
    try:
        return int(float(v))
    except Exception:
        return None

def parse_allowed_values(dropdown_codes: Any, codes: Any) -> List[str]:
    # Prefer the dropdown-code field if present (it is already pipe-delimited)
    raw = None
    if isinstance(dropdown_codes, str) and dropdown_codes.strip():
        raw = dropdown_codes.strip()
        parts = [p.strip() for p in raw.split("|") if p.strip()]
        return sorted(list(dict.fromkeys(parts)))
    # Fallback: parse the long 'Allowed Values (Codes)' which is usually line-delimited
    if isinstance(codes, str) and codes.strip():
        lines = [ln.strip() for ln in codes.splitlines() if ln.strip()]
        # Many lines are like "GIR401 – Ultimate Parent Entity" -> take the code before the dash.
        out = []
        for ln in lines:
            code = ln.split("–")[0].strip()
            code = code.split("-")[0].strip()
            if code:
                out.append(code)
        return sorted(list(dict.fromkeys(out)))
    return []

def export_json(obj: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)

def _lname(tag: str) -> str:
    """Localname for namespaced tags."""
    if tag.startswith("{"):
        return tag.split("}", 1)[1]
    return tag

def _strip_prefix(qname: Optional[str]) -> Optional[str]:
    if not qname:
        return qname
    return qname.split(":", 1)[-1]

@dataclass(frozen=True)
class XsdAttr:
    name: str
    required: bool
    xsd_type: Optional[str] = None
    allowed_values: Tuple[str, ...] = ()

def _parse_simpletype_enums(st: ET.Element) -> List[str]:
    enums: List[str] = []
    for e in st.findall(f".//{{{XSD_NS}}}enumeration"):
        v = e.attrib.get("value")
        if v is not None and str(v).strip() != "":
            enums.append(str(v).strip())
    # stable unique
    return list(dict.fromkeys(enums))

def _load_xsd_documents(xsd_dir: Optional[Path], xsd_zip: Optional[Path]) -> List[ET.ElementTree]:
    trees: List[ET.ElementTree] = []
    if xsd_dir:
        for p in sorted(xsd_dir.rglob("*.xsd")):
            try:
                trees.append(ET.parse(p))
            except Exception:
                continue
    if xsd_zip:
        with zipfile.ZipFile(xsd_zip, "r") as z:
            for name in sorted([n for n in z.namelist() if n.lower().endswith(".xsd")]):
                try:
                    data = z.read(name)
                    trees.append(ET.ElementTree(ET.fromstring(data)))
                except Exception:
                    continue
    return trees

def _build_xsd_index(trees: List[ET.ElementTree]) -> Dict[str, Any]:
    """Build component indexes we need for attribute extraction."""
    complex_types: Dict[str, ET.Element] = {}
    attribute_groups: Dict[str, ET.Element] = {}
    global_attributes: Dict[str, ET.Element] = {}
    simple_types: Dict[str, List[str]] = {}

    for t in trees:
        root = t.getroot()
        # Simple types
        for st in root.findall(f".//{{{XSD_NS}}}simpleType[@name]"):
            name = st.attrib.get("name")
            if name:
                enums = _parse_simpletype_enums(st)
                if enums:
                    simple_types[_strip_prefix(name) or name] = enums

        # Attribute groups
        for ag in root.findall(f".//{{{XSD_NS}}}attributeGroup[@name]"):
            name = ag.attrib.get("name")
            if name:
                attribute_groups[_strip_prefix(name) or name] = ag

        # Global attributes (best-effort)
        for a in root.findall(f".//{{{XSD_NS}}}attribute[@name]"):
            name = a.attrib.get("name")
            if name:
                global_attributes[_strip_prefix(name) or name] = a

        # Complex types
        for ct in root.findall(f".//{{{XSD_NS}}}complexType[@name]"):
            name = ct.attrib.get("name")
            if name:
                complex_types[_strip_prefix(name) or name] = ct

    return {
        "complex_types": complex_types,
        "attribute_groups": attribute_groups,
        "global_attributes": global_attributes,
        "simple_types": simple_types,
    }

def _iter_attr_related_nodes(node: ET.Element) -> List[ET.Element]:
    """Traverse a complexType node but skip nested <element> declarations.

    We want only attribute/attributeGroup usage for the *current* complexType,
    not for anonymous complexTypes nested under child elements.
    """
    out: List[ET.Element] = []
    def rec(n: ET.Element):
        for ch in list(n):
            ln = _lname(ch.tag)
            if ln == "element":
                # Don't descend into nested element declarations
                continue
            if ln in {"attribute", "attributeGroup"}:
                out.append(ch)
                continue
            # descend further
            rec(ch)
    rec(node)
    return out

def _resolve_attr_type_and_enums(a: ET.Element, idx: Dict[str, Any]) -> Tuple[Optional[str], List[str]]:
    """Resolve XSD type + enumerations for an attribute node (best-effort)."""
    simple_types: Dict[str, List[str]] = idx["simple_types"]
    global_attrs: Dict[str, ET.Element] = idx["global_attributes"]

    # type from this node
    t = _strip_prefix(a.attrib.get("type"))
    enums: List[str] = []
    if t and t in simple_types:
        enums = simple_types.get(t, [])
        return t, enums

    # inline simpleType
    st = a.find(f"./{{{XSD_NS}}}simpleType")
    if st is not None:
        enums = _parse_simpletype_enums(st)
        return t, enums

    # ref to global attribute
    ref = _strip_prefix(a.attrib.get("ref"))
    if ref and ref in global_attrs:
        ga = global_attrs[ref]
        t2 = _strip_prefix(ga.attrib.get("type"))
        if t2 and t2 in simple_types:
            return t2, simple_types[t2]
        st2 = ga.find(f"./{{{XSD_NS}}}simpleType")
        if st2 is not None:
            enums = _parse_simpletype_enums(st2)
        return t2, enums

    return t, enums

def _collect_attrs_for_complex_type(type_name: str, idx: Dict[str, Any], _seen: Optional[set]=None) -> List[XsdAttr]:
    complex_types: Dict[str, ET.Element] = idx["complex_types"]
    attribute_groups: Dict[str, ET.Element] = idx["attribute_groups"]

    if _seen is None:
        _seen = set()
    if type_name in _seen:
        return []
    _seen.add(type_name)

    ct = complex_types.get(type_name)
    if ct is None:
        return []

    attrs: List[XsdAttr] = []

    # base type inheritance (complexContent/simpleContent extension or restriction)
    base = None
    ext = ct.find(f".//{{{XSD_NS}}}extension")
    if ext is None:
        ext = ct.find(f".//{{{XSD_NS}}}restriction")
    if ext is not None and ext.attrib.get("base"):
        base = _strip_prefix(ext.attrib.get("base"))
    if base:
        attrs.extend(_collect_attrs_for_complex_type(base, idx, _seen))

    # direct attributes + attributeGroups on ct (excluding nested element decls)
    for n in _iter_attr_related_nodes(ct):
        ln = _lname(n.tag)
        if ln == "attributeGroup":
            # expand group
            ref = _strip_prefix(n.attrib.get("ref"))
            if not ref:
                # named inline group
                name = _strip_prefix(n.attrib.get("name"))
                ref = name
            if ref and ref in attribute_groups:
                grp = attribute_groups[ref]
                # group can contain attributes and nested attributeGroup refs
                for gn in _iter_attr_related_nodes(grp):
                    if _lname(gn.tag) == "attribute":
                        aname = _strip_prefix(gn.attrib.get("name")) or _strip_prefix(gn.attrib.get("ref")) or ""
                        if not aname:
                            continue
                        required = (gn.attrib.get("use") == "required")
                        atype, enums = _resolve_attr_type_and_enums(gn, idx)
                        attrs.append(XsdAttr(name=aname, required=required, xsd_type=atype, allowed_values=tuple(enums)))
                    elif _lname(gn.tag) == "attributeGroup":
                        # nested group
                        ref2 = _strip_prefix(gn.attrib.get("ref"))
                        if ref2 and ref2 in attribute_groups:
                            # recurse by inlining
                            nested = attribute_groups[ref2]
                            for nn in _iter_attr_related_nodes(nested):
                                if _lname(nn.tag) != "attribute":
                                    continue
                                aname = _strip_prefix(nn.attrib.get("name")) or _strip_prefix(nn.attrib.get("ref")) or ""
                                if not aname:
                                    continue
                                required = (nn.attrib.get("use") == "required")
                                atype, enums = _resolve_attr_type_and_enums(nn, idx)
                                attrs.append(XsdAttr(name=aname, required=required, xsd_type=atype, allowed_values=tuple(enums)))
            continue

        if ln == "attribute":
            aname = _strip_prefix(n.attrib.get("name")) or _strip_prefix(n.attrib.get("ref")) or ""
            if not aname:
                continue
            required = (n.attrib.get("use") == "required")
            atype, enums = _resolve_attr_type_and_enums(n, idx)
            attrs.append(XsdAttr(name=aname, required=required, xsd_type=atype, allowed_values=tuple(enums)))

    # Deduplicate by name (prefer required=True)
    by_name: Dict[str, XsdAttr] = {}
    for a in attrs:
        existing = by_name.get(a.name)
        if existing is None:
            by_name[a.name] = a
        else:
            # if either is required, keep required
            req = existing.required or a.required
            # merge enums
            enums = tuple(dict.fromkeys(list(existing.allowed_values) + list(a.allowed_values)))
            # keep a type if missing
            t = existing.xsd_type or a.xsd_type
            by_name[a.name] = XsdAttr(name=a.name, required=req, xsd_type=t, allowed_values=enums)

    return list(by_name.values())

def _augment_elements_with_xsd_attributes(
    elements: List[Dict[str, Any]],
    type_to_attrs: Dict[str, List[XsdAttr]],
    include_optional: bool = False,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    existing = {e.get("xpath") for e in elements if isinstance(e.get("xpath"), str)}
    added = 0
    required_added = 0

    for e in list(elements):
        xtype = _strip_prefix(e.get("xsd_type"))
        if not xtype:
            continue
        attrs = type_to_attrs.get(xtype, [])
        if not attrs:
            continue
        for a in attrs:
            if (not a.required) and (not include_optional):
                continue
            axp = f"{e['xpath']}/@{a.name}"
            if axp in existing:
                continue
            existing.add(axp)
            added += 1
            if a.required:
                required_added += 1
            # Build attribute element entry
            hl = e.get("hierarchy_level")
            try:
                hl2 = int(hl) + 1 if hl is not None else None
            except Exception:
                hl2 = None
            elements.append({
                "section": e.get("section", ""),
                "element_name": f"@{a.name}",
                "tax_label": f"{e.get('tax_label','').strip()} — @{a.name}".strip(" —"),
                "guidance": None,
                "input_field": False,
                "example_value": None,
                "required": bool(a.required),
                "repeatable": False,
                "repeatability_scope": "Attribute (non-repeatable)",
                "allowed_values": list(a.allowed_values) if a.allowed_values else [],
                "is_container": False,
                "xsd_type": a.xsd_type,
                "min_occurs": 1 if a.required else 0,
                "max_occurs": 1,
                "xpath": axp,
                "hierarchy_level": hl2,
                "xml_hierarchy_path": None,
            })

    stats = {
        "attributes_added": added,
        "required_attributes_added": required_added,
    }
    return elements, stats

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--workbook", required=True, help="Path to the Excel workbook")
    ap.add_argument("--config-version", required=True, help="Config version id (folder name)")
    ap.add_argument("--outdir", required=True, help="Output directory (e.g., config/GIR_CONFIG_v1)")
    ap.add_argument("--xsd-dir", default=None, help="Optional directory containing the OECD GIR XSD package (.xsd files)")
    ap.add_argument("--xsd-zip", default=None, help="Optional path to the OECD GIR XSD ZIP package")
    ap.add_argument("--include-optional-attributes", action="store_true", help="Also include optional attributes in elements.json (required=false)")
    args = ap.parse_args()

    wb_path = Path(args.workbook).expanduser().resolve()
    outdir = Path(args.outdir).expanduser().resolve()

    xsd_dir = Path(args.xsd_dir).expanduser().resolve() if args.xsd_dir else None
    xsd_zip = Path(args.xsd_zip).expanduser().resolve() if args.xsd_zip else None
    if xsd_dir and not xsd_dir.exists():
        raise SystemExit(f"XSD directory not found: {xsd_dir}")
    if xsd_zip and not xsd_zip.exists():
        raise SystemExit(f"XSD ZIP not found: {xsd_zip}")
    if xsd_dir and xsd_zip:
        raise SystemExit("Provide only one of --xsd-dir or --xsd-zip")

    if not wb_path.exists():
        raise SystemExit(f"Workbook not found: {wb_path}")

    wb_hash = sha256_file(wb_path)
    generated_at = datetime.now(timezone.utc).isoformat()

    # Load sheets
    elements_df = pd.read_excel(wb_path, sheet_name="Master_All_Elements")
    cardinality_df = pd.read_excel(wb_path, sheet_name="Section_Cardinality")
    lists_df = pd.read_excel(wb_path, sheet_name="Lists")
    errors_df = pd.read_excel(wb_path, sheet_name="Error_Code_Library")

    # Elements
    elements: List[Dict[str, Any]] = []
    for _, r in elements_df.iterrows():
        xpath = r.get("XSD XPath (absolute)") or r.get("XML Hierarchy (Path)") or r.get("XSD XPath (relative)")
        if not isinstance(xpath, str) or not xpath.strip():
            continue
        el = {
            "section": str(r.get("Section", "")).strip(),
            "element_name": str(r.get("Element Name", "")).strip(),
            "tax_label": str(r.get("Tax-Friendly Label (v1)", "")).strip(),
            "guidance": None if pd.isna(r.get("OECD Guidance Explanation")) else str(r.get("OECD Guidance Explanation")),
            "input_field": yn_to_bool(r.get("Input Field?")),
            "example_value": None if pd.isna(r.get("Example Value")) else str(r.get("Example Value")),
            "required": yn_to_bool(r.get("Required?")),
            "repeatable": yn_to_bool(r.get("Repeatable?")),
            "repeatability_scope": None if pd.isna(r.get("Repeatability Scope")) else str(r.get("Repeatability Scope")),
            "allowed_values": parse_allowed_values(r.get("Allowed Values (Dropdown Codes)"), r.get("Allowed Values (Codes)")),
            "is_container": yn_to_bool(r.get("Is Container?")),
            "xsd_type": None if pd.isna(r.get("XSD Type")) else str(r.get("XSD Type")),
            "min_occurs": parse_min_occurs(r.get("minOccurs")),
            "max_occurs": parse_max_occurs(r.get("maxOccurs")),
            "xpath": xpath.strip(),
            "hierarchy_level": None if pd.isna(r.get("Hierarchy Level")) else int(r.get("Hierarchy Level")),
            "xml_hierarchy_path": None if pd.isna(r.get("XML Hierarchy (Path)")) else str(r.get("XML Hierarchy (Path)")),
        }
        elements.append(el)

    # Section cardinality
    section_cardinality: List[Dict[str, Any]] = []
    for _, r in cardinality_df.iterrows():
        section_cardinality.append({
            "section": str(r.get("Section", "")).strip(),
            "container_xpath": str(r.get("Container XPath", "")).strip(),
            "xsd_type": None if pd.isna(r.get("XSD Type")) else str(r.get("XSD Type")),
            "min_occurs": parse_min_occurs(r.get("minOccurs")),
            "max_occurs": parse_max_occurs(r.get("maxOccurs")),
            "repeatable": yn_to_bool(r.get("Repeatable?")),
        })

    # Codelists (each column is a list)
    codelists: Dict[str, List[str]] = {}
    for col in lists_df.columns:
        values = [str(x).strip() for x in lists_df[col].dropna().tolist() if str(x).strip() != ""]
        # Deduplicate but preserve order
        dedup = list(dict.fromkeys(values))
        if dedup:
            codelists[col] = dedup

    # Error codes
    error_codes: List[Dict[str, Any]] = []
    for _, r in errors_df.iterrows():
        if pd.isna(r.get("Number")):
            continue
        try:
            num = int(r.get("Number"))
        except Exception:
            continue
        error_codes.append({
            "section": str(r.get("Section", "")).strip(),
            "number": num,
            "path_target": None if pd.isna(r.get("Path (Target)")) else str(r.get("Path (Target)")),
            "path_reference": None if pd.isna(r.get("Path (Reference)")) else str(r.get("Path (Reference)")),
            "element_name": None if pd.isna(r.get("Element Name")) else str(r.get("Element Name")),
            "validation_rule": None if pd.isna(r.get("Validation Rule")) else str(r.get("Validation Rule")),
            "validation_description": None if pd.isna(r.get("Validation Description")) else str(r.get("Validation Description")),
        })

    # Optional: augment elements with required attributes from OECD XSD
    xsd_meta: Dict[str, Any] = {}
    if xsd_dir or xsd_zip:
        trees = _load_xsd_documents(xsd_dir, xsd_zip)
        idx = _build_xsd_index(trees)

        # Only resolve attrs for types we actually use in the excel config.
        used_types = sorted({(_strip_prefix(e.get("xsd_type")) or "").strip() for e in elements if e.get("xsd_type")})
        used_types = [t for t in used_types if t]

        type_to_attrs: Dict[str, List[XsdAttr]] = {}
        for tname in used_types:
            attrs = _collect_attrs_for_complex_type(tname, idx)
            if attrs:
                type_to_attrs[tname] = attrs

        elements, stats = _augment_elements_with_xsd_attributes(
            elements,
            type_to_attrs,
            include_optional=bool(args.include_optional_attributes),
        )

        # meta for traceability
        if xsd_zip:
            xsd_meta["source_xsd_sha256"] = sha256_file(xsd_zip)
            xsd_meta["source_xsd_source"] = str(xsd_zip)
        if xsd_dir:
            xsd_meta["source_xsd_sha256"] = sha256_dir_xsd(xsd_dir)
            xsd_meta["source_xsd_source"] = str(xsd_dir)
        xsd_meta.update(stats)

    # Config meta
    meta = {
        "config_version_id": args.config_version,
        "generated_at_utc": generated_at,
        "source_workbook_sha256": wb_hash,
        "notes": "Generated from Excel toolkit" + (" + XSD attribute augmentation" if xsd_meta else ""),
        **xsd_meta,
    }

    # Write files
    export_json(meta, outdir / "config.json")
    export_json(elements, outdir / "elements.json")
    export_json(section_cardinality, outdir / "section_cardinality.json")
    export_json(codelists, outdir / "codelists.json")
    export_json(error_codes, outdir / "error_codes.json")

    # Sprint 2.2: starter reconciliation set definitions.
    reconciliation_sets = {
        "version": "1",
        "sets": [
            {
                "set_id": "JURIS_OVERALL_REQUIRED",
                "description": "Jurisdiction-level required outputs under OverallComputation (minOccurs>=1, non-repeatable leaves).",
                "section": "Jurisdiction",
                "scope": "jurisdiction",
                "xpath_includes": ["/OverallComputation/"],
                "required_only": True,
                "exclude_repeatable": True,
            },
            {
                "set_id": "JURIS_CE_REQUIRED",
                "description": "Entity-level required outputs under CEComputation (minOccurs>=1, non-repeatable leaves).",
                "section": "Jurisdiction",
                "scope": "entity",
                "xpath_includes": ["/CEComputation/"],
                "required_only": True,
                "exclude_repeatable": True,
            },
        ],
    }
    export_json(reconciliation_sets, outdir / "reconciliation_sets.json")

    print(f"Wrote config to: {outdir}")
    print(f"Elements: {len(elements)} | Error codes: {len(error_codes)} | Codelists: {len(codelists)}")
    if xsd_meta:
        print(f"XSD attribute augmentation: +{xsd_meta.get('attributes_added',0)} attributes (required={xsd_meta.get('required_attributes_added',0)})")

if __name__ == "__main__":
    main()
