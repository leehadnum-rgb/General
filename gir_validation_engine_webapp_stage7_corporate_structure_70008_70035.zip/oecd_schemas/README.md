# Place the OECD GIR XSD ZIP here (e.g., oecd_gir_xml_schema.zip)\n\nThis folder is intentionally kept in the repo so Stage 5 XSD validation can run on Render.\n
