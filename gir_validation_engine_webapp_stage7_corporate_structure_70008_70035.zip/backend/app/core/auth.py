"""Very small API-key authentication helper.

For MVP/dev, auth can be disabled by leaving GIR_API_KEY unset.
For production, set GIR_API_KEY and all non-health endpoints will require:

  X-API-Key: <your key>
"""

from __future__ import annotations

from typing import Optional

from fastapi import HTTPException, Header

from app.core.settings import settings


def require_api_key(x_api_key: Optional[str] = Header(default=None)) -> None:
    """Enforce X-API-Key when configured.

    If GIR_API_KEY is not set, the API runs in "open" mode.
    """

    # Dev / local mode.
    if not settings.api_key:
        return

    if x_api_key != settings.api_key:
        raise HTTPException(status_code=401, detail="Invalid API key")
