from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from app.services.config_models import GIRConfig, Element


@dataclass(frozen=True)
class ReconciliationSet:
    """Defines a *set* of expected datapoints for reconciliation.

    The philosophy is:
    - The GIR schema contains hundreds of elements and many are conditional.
    - A reconciliation view is most useful when it can answer:
        *What do I expect to have for each (jurisdiction/entity/filer), and what is missing?*

    Sets provide a config-driven way to define expected datapoints without hardcoding
    business logic in code. In Sprint 2.2 we ship a minimal default file that can be
    refined over time.
    """

    set_id: str
    description: str
    section: str
    scope: str  # filing|filer|jurisdiction|entity

    # Element filters
    # If provided, these are treated as an *explicit allow-list* of xpaths.
    # This is the most precise way to replicate Excel "expected datapoints" packs.
    xpaths: Optional[List[str]]

    # Otherwise we do substring matching using includes/excludes.
    xpath_includes: List[str]
    xpath_excludes: Optional[List[str]] = None
    required_only: bool = True
    exclude_repeatable: bool = True

    # Optional conditions (not yet fully used, but forward-compatible)
    computation_mode_in: Optional[List[str]] = None
    qdmt_applicable: Optional[bool] = None

    # Pack metadata (Sprint 2.3)
    # These fields make reconciliation-sets usable as explicit Excel-style
    # "packs" (Core/Full/QDMTT-only/UTPR-only, etc.).
    pack_family: Optional[str] = None
    pack_variant: Optional[str] = None
    pack_tags: List[str] = field(default_factory=list)

    # If true, the engine will treat *all* elements in this set as required
    # for reconciliation (even if the underlying schema marks them optional).
    treat_included_as_required: bool = False


def load_reconciliation_sets(config_root: str, config_version_id: str) -> List[ReconciliationSet]:
    """Load reconciliation set definitions from config.

    File name: reconciliation_sets.json (optional)
    If missing, returns an empty list (callers can fall back to defaults).
    """

    folder = Path(config_root) / config_version_id
    path = folder / "reconciliation_sets.json"
    if not path.exists():
        return []

    with open(path, "r", encoding="utf-8") as f:
        payload = json.load(f)

    sets: List[ReconciliationSet] = []
    for row in payload.get("sets", []) or []:
        sets.append(
            ReconciliationSet(
                set_id=str(row.get("set_id")),
                description=str(row.get("description") or ""),
                section=str(row.get("section") or ""),
                scope=str(row.get("scope") or ""),
                xpaths=row.get("xpaths"),
                xpath_includes=list(row.get("xpath_includes") or []),
                xpath_excludes=row.get("xpath_excludes"),
                required_only=bool(row.get("required_only", True)),
                exclude_repeatable=bool(row.get("exclude_repeatable", True)),
                computation_mode_in=row.get("computation_mode_in"),
                qdmt_applicable=row.get("qdmt_applicable"),

                pack_family=row.get("pack_family"),
                pack_variant=row.get("pack_variant"),
                pack_tags=list(row.get("pack_tags") or []),
                treat_included_as_required=bool(row.get("treat_included_as_required", False)),
            )
        )
    return sets


def default_reconciliation_sets() -> List[ReconciliationSet]:
    """Default sets when reconciliation_sets.json is not present.

    These defaults are intentionally conservative and designed for "engine output" coverage:
    - Jurisdiction-level required leaves under OverallComputation
    - Entity-level required leaves under CEComputation
    """
    return [
        ReconciliationSet(
            set_id="JURIS_OVERALL_REQUIRED",
            description="Jurisdiction-level required outputs under OverallComputation (minOccurs>=1, non-repeatable leaves).",
            section="Jurisdiction",
            scope="jurisdiction",
            xpaths=None,
            xpath_includes=["/OverallComputation/"],
            required_only=True,
            exclude_repeatable=True,
            pack_family="Jurisdiction",
            pack_variant="full",
            pack_tags=["full"],
        ),
        ReconciliationSet(
            set_id="JURIS_CE_REQUIRED",
            description="Entity-level required outputs under CEComputation (minOccurs>=1, non-repeatable leaves).",
            section="Jurisdiction",
            scope="entity",
            xpaths=None,
            xpath_includes=["/CEComputation/"],
            required_only=True,
            exclude_repeatable=True,
            pack_family="Jurisdiction",
            pack_variant="full",
            pack_tags=["full", "entity"],
        ),
    ]


def select_elements_for_set(config: GIRConfig, s: ReconciliationSet) -> List[Element]:
    """Return config Elements that belong to a reconciliation set."""

    want_section = (s.section or "").strip().lower()
    explicit = [x for x in (s.xpaths or []) if isinstance(x, str) and x.strip()]
    explicit_set = {x.strip() for x in explicit}

    includes = [x.lower() for x in (s.xpath_includes or []) if x]
    excludes = [x.lower() for x in (s.xpath_excludes or []) if x]

    out: List[Element] = []
    for e in config.elements:
        if not e.xpath or e.is_container:
            continue
        if (e.section or "").strip().lower() != want_section:
            continue

        if explicit_set:
            if e.xpath not in explicit_set:
                continue
        else:
            xp = e.xpath.lower()
            if includes and not any(tok in xp for tok in includes):
                continue
            if excludes and any(tok in xp for tok in excludes):
                continue

        if s.required_only:
            # Prefer explicit min_occurs; fall back to the derived 'required' flag.
            mo = e.min_occurs if e.min_occurs is not None else (1 if e.required else 0)
            if int(mo or 0) < 1:
                continue

        if s.exclude_repeatable and bool(e.repeatable):
            continue

        out.append(e)

    # Deterministic ordering.
    out.sort(key=lambda el: el.xpath)
    return out
