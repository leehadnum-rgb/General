from datetime import date
from decimal import Decimal, InvalidOperation
import re

ISO_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")

def try_parse_decimal(value: str):
    try:
        # remove commas used as thousands separators
        cleaned = value.replace(",", "").strip()
        if cleaned == "":
            return None
        return Decimal(cleaned)
    except (InvalidOperation, AttributeError):
        return None

def try_parse_date(value: str):
    if not isinstance(value, str):
        return None
    v = value.strip()
    if not ISO_DATE.match(v):
        return None
    try:
        y, m, d = v.split("-")
        return date(int(y), int(m), int(d))
    except Exception:
        return None
