from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha1
from typing import Any, Dict, Iterable, List, Optional, Tuple

import re
from datetime import datetime
import time
import threading

from sqlalchemy import func

from sqlalchemy.orm import Session

from app.db import models
from app.services.config_models import GIRConfig, Element
from app.services.validation_engine import derive_virtual_datapoints_from_registers
from app.services.reconciliation_sets import ReconciliationSet, select_elements_for_set


@dataclass(frozen=True)
class EffectiveDP:
    dp: models.DataPoint
    is_virtual: bool


def normalize_computation_mode(value: Optional[str]) -> str:
    """Normalize free-text jurisdiction.computation_mode into a stable key.

    We intentionally accept messy user-entered values and map them into a few
    canonical buckets so reconciliation set activation rules can be written as:
      - full_etr
      - safe_harbour
      - de_minimis
      - utpr
      - qdmt

    If no mapping is recognized, we return a slugified form.
    """

    if not value:
        return ""
    raw = str(value).strip().lower()
    if not raw:
        return ""

    # Prefer specific patterns first.
    if ("safe" in raw and ("harbour" in raw or "harbor" in raw)) or "cbcr" in raw:
        return "safe_harbour"
    if "de" in raw and "min" in raw:
        return "de_minimis"
    if "nmce" in raw:
        return "de_minimis"
    if "utpr" in raw:
        return "utpr"
    if "qdmt" in raw:
        return "qdmt"
    if "full" in raw or raw == "etr" or "etr" in raw:
        return "full_etr"
    if "out" in raw and "scope" in raw:
        return "out_of_scope"

    # Fallback slug.
    return re.sub(r"[^a-z0-9]+", "_", raw).strip("_")


def jurisdiction_applies_to_set(s: ReconciliationSet, j: models.Jurisdiction) -> bool:
    """Return True if a reconciliation set applies to a jurisdiction row.

    Notes:
    - If the jurisdiction has *no* mode/qdmt values, we treat conditions as
      "unknown" and keep the jurisdiction (do not filter out) to avoid hiding
      missing datapoints when registers are incomplete.
    """

    # Mode gating
    if s.computation_mode_in:
        allowed = {normalize_computation_mode(x) for x in (s.computation_mode_in or []) if x}
        actual_raw = (j.computation_mode or "").strip()
        actual = normalize_computation_mode(actual_raw)
        if actual:
            if allowed and actual not in allowed:
                return False

    # QDMT gating
    if s.qdmt_applicable is not None:
        if j.qdmt_applicable is not None and bool(j.qdmt_applicable) != bool(s.qdmt_applicable):
            return False

    return True


def _virtual_id(dp: models.DataPoint) -> str:
    key = f"{dp.filer_code or ''}|{dp.jurisdiction_code or ''}|{dp.entity_code or ''}|{dp.context_key or ''}|{dp.xml_path or ''}"
    h = sha1(key.encode("utf-8")).hexdigest()[:16].upper()
    return f"V-{h}"


def load_effective_datapoints(
    *,
    db: Session,
    filing: models.Filing,
    config: GIRConfig,
    jurisdiction_codes: Optional[Iterable[str]] = None,
    filer_codes: Optional[Iterable[str]] = None,
) -> List[EffectiveDP]:
    """Return the effective datapoint set (persisted ∪ derived).

    Persisted datapoints override derived datapoints.
    """

    persisted: List[models.DataPoint] = (
        db.query(models.DataPoint)
        .filter(models.DataPoint.filing_id == filing.id)
        .all()
    )

    filers = db.query(models.Filer).filter(models.Filer.filing_id == filing.id).all()
    juris_rows = db.query(models.Jurisdiction).filter(models.Jurisdiction.filing_id == filing.id).all()
    entities = db.query(models.ConstituentEntity).filter(models.ConstituentEntity.filing_id == filing.id).all()

    # Optional filtering for dashboard slice requests (e.g., single jurisdiction card).
    juris_filter = {str(c).strip().upper() for c in (jurisdiction_codes or []) if str(c).strip()}
    filer_filter = {str(c).strip() for c in (filer_codes or []) if str(c).strip()}

    if juris_filter:
        juris_rows = [j for j in (juris_rows or []) if (j.jurisdiction_code or "").strip().upper() in juris_filter]
        entities = [e for e in (entities or []) if (e.jurisdiction_code or "").strip().upper() in juris_filter]

    if filer_filter:
        filers = [f for f in (filers or []) if (f.filer_code or "").strip() in filer_filter]


    derived: List[models.DataPoint] = derive_virtual_datapoints_from_registers(
        db=db,
        filing=filing,
        config=config,
        filers=filers,
        jurisdictions=juris_rows,
        entities=entities,
        existing_datapoints=persisted,
        suppress_if_exists=True,
    )

    out: List[EffectiveDP] = [EffectiveDP(dp=p, is_virtual=False) for p in persisted]
    out.extend([EffectiveDP(dp=v, is_virtual=True) for v in derived])
    return out


def _build_indexes(effective: List[EffectiveDP]) -> Dict[str, Any]:
    """Build lookup indexes for presence checks."""

    from collections import defaultdict

    idx = {
        "entity_path": defaultdict(list),
        "entity_juris_path": defaultdict(list),
        "entity_filer_path": defaultdict(list),
        "entity_filer_juris_path": defaultdict(list),
        "juris_path": defaultdict(list),
        "filer_juris_path": defaultdict(list),
        "filer_path": defaultdict(list),
    }

    for edp in effective:
        dp = edp.dp
        xp = dp.xml_path or ""
        if not xp:
            continue

        if dp.entity_code:
            idx["entity_path"][(dp.entity_code, xp)].append(edp)
            if dp.jurisdiction_code:
                idx["entity_juris_path"][(dp.entity_code, dp.jurisdiction_code, xp)].append(edp)
            if dp.filer_code:
                idx["entity_filer_path"][(dp.entity_code, dp.filer_code, xp)].append(edp)
            if dp.filer_code and dp.jurisdiction_code:
                idx["entity_filer_juris_path"][(dp.entity_code, dp.filer_code, dp.jurisdiction_code, xp)].append(edp)

        if dp.jurisdiction_code:
            idx["juris_path"][(dp.jurisdiction_code, xp)].append(edp)
            if dp.filer_code:
                idx["filer_juris_path"][(dp.filer_code, dp.jurisdiction_code, xp)].append(edp)

        if dp.filer_code:
            idx["filer_path"][(dp.filer_code, xp)].append(edp)

    return idx


def _pick_best(matches: List[EffectiveDP]) -> Optional[EffectiveDP]:
    if not matches:
        return None
    # Prefer persisted datapoints over virtual.
    matches_sorted = sorted(matches, key=lambda m: (m.is_virtual, (m.dp.updated_at or m.dp.created_at)), reverse=False)
    return matches_sorted[0]


def find_present_datapoint(
    *,
    idx: Dict[str, Any],
    xml_path: str,
    filer_code: Optional[str],
    jurisdiction_code: Optional[str],
    entity_code: Optional[str],
) -> Optional[EffectiveDP]:
    """Find a datapoint that satisfies an expected key.

    Matching is intentionally tolerant of missing filer_code / jurisdiction_code
    on the actual datapoint (common for imported engine outputs).

    We never allow a datapoint from a *different* jurisdiction to satisfy a
    jurisdiction-scoped expectation.
    """

    xml_path = xml_path or ""
    if not xml_path:
        return None

    # Entity-scoped
    if entity_code:
        # Most-specific first.
        if filer_code and jurisdiction_code:
            m = idx["entity_filer_juris_path"].get((entity_code, filer_code, jurisdiction_code, xml_path))
            if m:
                return _pick_best(m)

        if filer_code:
            m = idx["entity_filer_path"].get((entity_code, filer_code, xml_path))
            if m:
                return _pick_best(m)

        if jurisdiction_code:
            m = idx["entity_juris_path"].get((entity_code, jurisdiction_code, xml_path))
            if m:
                return _pick_best(m)

        m = idx["entity_path"].get((entity_code, xml_path))
        return _pick_best(m) if m else None

    # Jurisdiction-scoped
    if jurisdiction_code:
        if filer_code:
            m = idx["filer_juris_path"].get((filer_code, jurisdiction_code, xml_path))
            if m:
                return _pick_best(m)
        m = idx["juris_path"].get((jurisdiction_code, xml_path))
        return _pick_best(m) if m else None

    # Filer-scoped
    if filer_code:
        m = idx["filer_path"].get((filer_code, xml_path))
        return _pick_best(m) if m else None

    return None


def build_expected_datapoints_for_set(
    *,
    db: Session,
    filing: models.Filing,
    config: GIRConfig,
    s: ReconciliationSet,
    include_present_values: bool = False,
    only_missing: bool = False,
) -> Dict[str, Any]:
    """Compute expected datapoints (expanded by registers) for a reconciliation set."""

    elements = select_elements_for_set(config, s)
    elements_by_xpath: Dict[str, Element] = {e.xpath: e for e in config.elements if e.xpath}

    filers = db.query(models.Filer).filter(models.Filer.filing_id == filing.id).all()
    juris_rows = db.query(models.Jurisdiction).filter(models.Jurisdiction.filing_id == filing.id).all()
    entities = db.query(models.ConstituentEntity).filter(models.ConstituentEntity.filing_id == filing.id).all()

    # Optional filtering for dashboard slice requests (e.g., single jurisdiction card).
    juris_filter = {str(c).strip().upper() for c in (jurisdiction_codes or []) if str(c).strip()}
    filer_filter = {str(c).strip() for c in (filer_codes or []) if str(c).strip()}

    if juris_filter:
        juris_rows = [j for j in (juris_rows or []) if (j.jurisdiction_code or "").strip().upper() in juris_filter]
        entities = [e for e in (entities or []) if (e.jurisdiction_code or "").strip().upper() in juris_filter]

    if filer_filter:
        filers = [f for f in (filers or []) if (f.filer_code or "").strip() in filer_filter]


    effective = load_effective_datapoints(db=db, filing=filing, config=config)
    idx = _build_indexes(effective)

    rows: List[Dict[str, Any]] = []

    def _add_row(*, filer_code: Optional[str], jurisdiction_code: Optional[str], entity_code: Optional[str], el: Element):
        present = find_present_datapoint(
            idx=idx,
            xml_path=el.xpath,
            filer_code=filer_code,
            jurisdiction_code=jurisdiction_code,
            entity_code=entity_code,
        )

        is_present = present is not None
        if only_missing and is_present:
            return

        item = {
            "set_id": s.set_id,
            "section": el.section,
            "scope": s.scope,
            "filer_code": filer_code,
            "jurisdiction_code": jurisdiction_code,
            "entity_code": entity_code,
            "context_key": None,
            "xml_path": el.xpath,
            "tax_label": el.tax_label,
            "required": bool(s.treat_included_as_required)
            or bool(el.required)
            or (el.min_occurs is not None and int(el.min_occurs) >= 1),
            "repeatable": bool(el.repeatable),
            "is_present": is_present,
        }
        if present is not None:
            dp = present.dp
            item["present_id"] = dp.id if not present.is_virtual else _virtual_id(dp)
            item["present_is_virtual"] = present.is_virtual
            item["present_source"] = dp.source
            item["present_source_system"] = dp.source_system
            if include_present_values:
                item["present_value_raw"] = dp.value_raw
                item["present_currency"] = dp.currency
        else:
            item["present_id"] = None
            item["present_is_virtual"] = None
            item["present_source"] = None
            item["present_source_system"] = None
            if include_present_values:
                item["present_value_raw"] = None
                item["present_currency"] = None

        rows.append(item)

    scope = (s.scope or "").strip().lower()
    if scope == "jurisdiction":
        # Expand across jurisdiction register; fall back to datapoints if register is empty.
        if juris_rows:
            for j in juris_rows:
                if not jurisdiction_applies_to_set(s, j):
                    continue
                jc = j.jurisdiction_code
                fc = j.responsible_filer_code
                for el in elements:
                    _add_row(filer_code=fc, jurisdiction_code=jc, entity_code=None, el=el)
        else:
            juris_codes = sorted({edp.dp.jurisdiction_code for edp in effective if edp.dp.jurisdiction_code})
            for jc in juris_codes:
                for el in elements:
                    _add_row(filer_code=None, jurisdiction_code=jc, entity_code=None, el=el)

    elif scope == "entity":
        juris_by_code: Dict[str, models.Jurisdiction] = {
            (j.jurisdiction_code or "").strip(): j for j in (juris_rows or []) if (j.jurisdiction_code or "").strip()
        }
        for e in entities:
            if not e.included_in_gir:
                continue
            fc = (e.filed_by_filer_code or None)
            jc = (e.jurisdiction_code or None)
            if jc and (jc.strip() in juris_by_code):
                if not jurisdiction_applies_to_set(s, juris_by_code[jc.strip()]):
                    continue
            ec = e.entity_code
            for el in elements:
                _add_row(filer_code=fc, jurisdiction_code=jc, entity_code=ec, el=el)

    elif scope == "filer":
        for f in filers:
            fc = f.filer_code
            for el in elements:
                _add_row(filer_code=fc, jurisdiction_code=None, entity_code=None, el=el)

    else:  # filing
        for el in elements:
            _add_row(filer_code=None, jurisdiction_code=None, entity_code=None, el=el)

    # Deterministic ordering.
    rows.sort(key=lambda r: (
        r["xml_path"],
        r.get("filer_code") or "",
        r.get("jurisdiction_code") or "",
        r.get("entity_code") or "",
    ))

    return {
        "set_id": s.set_id,
        "set_description": s.description,
        "count": len(rows),
        "items": rows,
    }


def compute_jurisdiction_entity_completeness(
    *,
    db: Session,
    filing: models.Filing,
    config: GIRConfig,
    s: ReconciliationSet,
    include_entities: bool = False,
) -> Dict[str, Any]:
    """Per-jurisdiction entity-output completeness against a required datapoint set."""

    if (s.scope or "").lower() != "entity":
        raise ValueError("Completeness requires an entity-scoped reconciliation set")

    required_elements = select_elements_for_set(config, s)
    required_paths = [e.xpath for e in required_elements]

    entities = db.query(models.ConstituentEntity).filter(models.ConstituentEntity.filing_id == filing.id).all()

    # Optional filtering for dashboard slice requests (e.g., single jurisdiction card).
    juris_filter = {str(c).strip().upper() for c in (jurisdiction_codes or []) if str(c).strip()}
    filer_filter = {str(c).strip() for c in (filer_codes or []) if str(c).strip()}

    if juris_filter:
        juris_rows = [j for j in (juris_rows or []) if (j.jurisdiction_code or "").strip().upper() in juris_filter]
        entities = [e for e in (entities or []) if (e.jurisdiction_code or "").strip().upper() in juris_filter]

    if filer_filter:
        filers = [f for f in (filers or []) if (f.filer_code or "").strip() in filer_filter]

    juris_rows = db.query(models.Jurisdiction).filter(models.Jurisdiction.filing_id == filing.id).all()

    effective = load_effective_datapoints(db=db, filing=filing, config=config)
    idx = _build_indexes(effective)

    # Jurisdiction universe: prefer jurisdiction register; fall back to entities.
    # Sprint 2.3: filter the jurisdiction universe by set activation rules
    # (computation_mode / qdmt_applicable) when register data is available.
    filtered_juris_rows = [j for j in (juris_rows or []) if (j.jurisdiction_code or "").strip() and jurisdiction_applies_to_set(s, j)]
    juris_codes = sorted({j.jurisdiction_code for j in filtered_juris_rows if j.jurisdiction_code})
    if not juris_codes:
        juris_codes = sorted({(e.jurisdiction_code or "").strip() for e in entities if (e.jurisdiction_code or "").strip()})

    juris_by_code: Dict[str, models.Jurisdiction] = {
        (j.jurisdiction_code or "").strip(): j for j in (juris_rows or []) if (j.jurisdiction_code or "").strip()
    }

    entities_by_juris: Dict[str, List[models.ConstituentEntity]] = {jc: [] for jc in juris_codes}
    for e in entities:
        if not e.included_in_gir:
            continue
        jc = (e.jurisdiction_code or "").strip()
        if jc and jc in juris_by_code:
            if not jurisdiction_applies_to_set(s, juris_by_code[jc]):
                continue
        if jc and jc in entities_by_juris:
            entities_by_juris[jc].append(e)

    results: List[Dict[str, Any]] = []
    for jc in juris_codes:
        exp_entities = entities_by_juris.get(jc, [])

        entities_complete = 0
        entities_partial = 0
        entities_missing = 0
        missing_datapoints_total = 0
        entity_details: List[Dict[str, Any]] = []

        for e in exp_entities:
            fc = (e.filed_by_filer_code or None)
            ec = e.entity_code

            present_count = 0
            missing_paths: List[str] = []
            for xp in required_paths:
                present = find_present_datapoint(
                    idx=idx,
                    xml_path=xp,
                    filer_code=fc,
                    jurisdiction_code=jc,
                    entity_code=ec,
                )
                if present is not None:
                    present_count += 1
                else:
                    missing_paths.append(xp)

            missing_count = len(required_paths) - present_count
            missing_datapoints_total += missing_count
            if present_count == 0:
                entities_missing += 1
            elif missing_count == 0:
                entities_complete += 1
            else:
                entities_partial += 1

            if include_entities:
                entity_details.append(
                    {
                        "entity_code": ec,
                        "legal_name": e.legal_name,
                        "filer_code": fc,
                        "required_count": len(required_paths),
                        "present_count": present_count,
                        "missing_count": missing_count,
                        "missing_xml_paths": missing_paths[:50],
                    }
                )

        expected = len(exp_entities)
        results.append(
            {
                "jurisdiction_code": jc,
                "expected_entities": expected,
                "entities_complete": entities_complete,
                "entities_partial": entities_partial,
                "entities_missing": entities_missing,
                "missing_datapoints_total": missing_datapoints_total,
                "required_datapoints_per_entity": len(required_paths),
                "completion_ratio_entities": (entities_complete / expected) if expected else None,
                "entities": entity_details if include_entities else None,
            }
        )

    results.sort(key=lambda r: (r["expected_entities"], r["entities_missing"], r["jurisdiction_code"]), reverse=True)

    return {
        "set_id": s.set_id,
        "set_description": s.description,
        "required_datapoints_per_entity": len(required_paths),
        "jurisdictions": results,
    }


def pivot_expected_datapoints(
    *,
    items: List[Dict[str, Any]],
    pivot: str = "auto",
    cell: str = "status",
    max_columns: int = 200,
) -> Dict[str, Any]:
    """Pivot a long-form expected datapoints matrix into a wide table.

    Parameters
    ----------
    items:
        Rows from build_expected_datapoints_for_set()["items"].

    pivot:
        One of:
          - auto (default)
          - jurisdiction
          - filer
          - entity
          - jurisdiction_entity

    cell:
        One of:
          - status  -> "P" (present) / "M" (missing)
          - present -> 1/0
          - missing -> 1/0 (inverse)
          - value   -> present_value_raw (blank if missing)

    max_columns:
        Guard rail to avoid huge responses.
    """

    if not items:
        return {
            "pivot": pivot,
            "cell": cell,
            "columns": [],
            "row_count": 0,
            "items": [],
        }

    scope = (items[0].get("scope") or "").strip().lower()
    if (pivot or "").lower() == "auto":
        if scope == "jurisdiction":
            pivot = "jurisdiction"
        elif scope == "entity":
            pivot = "jurisdiction_entity"
        elif scope == "filer":
            pivot = "filer"
        else:
            pivot = "filing"

    pivot = (pivot or "").strip().lower()
    cell = (cell or "status").strip().lower()

    def _col_key(r: Dict[str, Any]) -> str:
        if pivot == "jurisdiction":
            return (r.get("jurisdiction_code") or "<none>")
        if pivot == "filer":
            return (r.get("filer_code") or "<none>")
        if pivot == "entity":
            return (r.get("entity_code") or "<none>")
        if pivot == "jurisdiction_entity":
            jc = (r.get("jurisdiction_code") or "").strip()
            ec = (r.get("entity_code") or "").strip()
            if jc or ec:
                return f"{jc}|{ec}"
            return "<none>"
        # filing (no real pivot)
        return "<filing>"

    # Column universe
    col_keys = sorted({str(_col_key(r)) for r in items})
    if max_columns is not None and len(col_keys) > int(max_columns):
        raise ValueError(f"Too many pivot columns ({len(col_keys)}). Increase max_columns or choose a different pivot.")

    # Group rows by xml_path
    by_path: Dict[str, List[Dict[str, Any]]] = {}
    for r in items:
        xp = str(r.get("xml_path") or "").strip()
        if not xp:
            continue
        by_path.setdefault(xp, []).append(r)

    def _cell_value(r: Dict[str, Any]):
        present = bool(r.get("is_present"))
        if cell == "present":
            return 1 if present else 0
        if cell == "missing":
            return 0 if present else 1
        if cell == "value":
            return r.get("present_value_raw") if present else ""
        # status
        return "P" if present else "M"

    pivot_rows: List[Dict[str, Any]] = []
    for xp in sorted(by_path.keys()):
        group = by_path[xp]
        base = group[0]
        row: Dict[str, Any] = {
            "xml_path": xp,
            "tax_label": base.get("tax_label"),
            "section": base.get("section"),
            "scope": base.get("scope"),
            "required": bool(base.get("required")),
            "repeatable": bool(base.get("repeatable")),
        }

        # Aggregate across duplicates: if any present, cell reflects present.
        agg: Dict[str, Dict[str, Any]] = {}
        for r in group:
            ck = _col_key(r)
            if ck not in agg:
                agg[ck] = {"present": bool(r.get("is_present")), "row": r}
            else:
                if bool(r.get("is_present")):
                    agg[ck] = {"present": True, "row": r}

        for ck in col_keys:
            if ck in agg:
                row[ck] = _cell_value(agg[ck]["row"])
            else:
                # No expected row for this path/col combo => blank
                row[ck] = "" if cell == "value" else (0 if cell in ("present", "missing") else "")

        pivot_rows.append(row)

    return {
        "pivot": pivot,
        "cell": cell,
        "columns": col_keys,
        "row_count": len(pivot_rows),
        "items": pivot_rows,
    }


# -----------------------------
# Sprint 2.4 — Multi-pack completeness dashboards
# -----------------------------


def _is_required_for_pack(s: ReconciliationSet, el: Element) -> bool:
    """Return True if an element should count as "required" for a pack checklist."""

    if bool(getattr(s, "treat_included_as_required", False)):
        return True
    mo = el.min_occurs if el.min_occurs is not None else (1 if el.required else 0)
    try:
        return int(mo or 0) >= 1
    except Exception:
        return bool(el.required)


def compute_pack_completeness_dashboard(
    *,
    db: Session,
    filing: models.Filing,
    config: GIRConfig,
    sets: List[ReconciliationSet],
    include_inactive: bool = False,
    missing_sample_n: int = 10,
    jurisdiction_codes: Optional[Iterable[str]] = None,
    filer_codes: Optional[Iterable[str]] = None,
) -> Dict[str, Any]:
    """Compute multi-pack completeness across jurisdictions and filers.

    This is designed for UI dashboards:
    - For jurisdiction-scoped packs: per jurisdiction required/present/missing counts.
    - For entity-scoped packs: per jurisdiction summary (entities_complete/partial/missing).
    - For filer-scoped packs: per filer required/present/missing counts.

    Notes
    -----
    - We intentionally compute counts over *required* datapoints only.
    - Set activation rules (computation_mode / qdmt_applicable) are honored.
    - Missing samples include XML path + tax label (where available).
    """

    missing_sample_n = max(0, min(int(missing_sample_n or 0), 50))

    # Load registers once.
    filers = db.query(models.Filer).filter(models.Filer.filing_id == filing.id).all()
    juris_rows = db.query(models.Jurisdiction).filter(models.Jurisdiction.filing_id == filing.id).all()
    entities = db.query(models.ConstituentEntity).filter(models.ConstituentEntity.filing_id == filing.id).all()

    # Optional filtering for dashboard slice requests (e.g., single jurisdiction card).
    juris_filter = {str(c).strip().upper() for c in (jurisdiction_codes or []) if str(c).strip()}
    filer_filter = {str(c).strip() for c in (filer_codes or []) if str(c).strip()}

    if juris_filter:
        juris_rows = [j for j in (juris_rows or []) if (j.jurisdiction_code or "").strip().upper() in juris_filter]
        entities = [e for e in (entities or []) if (e.jurisdiction_code or "").strip().upper() in juris_filter]

    if filer_filter:
        filers = [f for f in (filers or []) if (f.filer_code or "").strip() in filer_filter]


    # Effective datapoints once.
    effective = load_effective_datapoints(db=db, filing=filing, config=config)
    idx = _build_indexes(effective)

    # Preselect elements per set (deterministic ordering).
    set_required_elements: Dict[str, List[Element]] = {}
    for s in sets:
        els = select_elements_for_set(config, s)
        req = [el for el in els if _is_required_for_pack(s, el)]
        set_required_elements[s.set_id] = req

    # Universe dictionaries.
    juris_by_code: Dict[str, models.Jurisdiction] = {
        (j.jurisdiction_code or "").strip(): j
        for j in (juris_rows or [])
        if (j.jurisdiction_code or "").strip()
    }
    entities_by_juris: Dict[str, List[models.ConstituentEntity]] = {}
    for e in entities:
        if not e.included_in_gir:
            continue
        jc = (e.jurisdiction_code or "").strip()
        if not jc:
            continue
        entities_by_juris.setdefault(jc, []).append(e)

    # Helper for jurisdiction-scoped pack stats.
    def _juris_pack_stats(*, s: ReconciliationSet, j: models.Jurisdiction) -> Dict[str, Any]:
        active = jurisdiction_applies_to_set(s, j)
        if not active and not include_inactive:
            return {}

        req_elements = set_required_elements.get(s.set_id, [])
        required_count = len(req_elements) if active else 0
        present_count = 0
        missing_samples: List[Dict[str, Any]] = []
        if active and required_count:
            for el in req_elements:
                present = find_present_datapoint(
                    idx=idx,
                    xml_path=el.xpath,
                    filer_code=(j.responsible_filer_code or None),
                    jurisdiction_code=(j.jurisdiction_code or None),
                    entity_code=None,
                )
                if present is not None:
                    present_count += 1
                else:
                    if missing_sample_n and len(missing_samples) < missing_sample_n:
                        missing_samples.append({"xml_path": el.xpath, "tax_label": el.tax_label})

        missing_count = max(0, required_count - present_count)
        ratio = (present_count / required_count) if required_count else None
        return {
            "set_id": s.set_id,
            "active": bool(active),
            "required_count": required_count,
            "present_count": present_count,
            "missing_count": missing_count,
            "completion_ratio": ratio,
            "missing_samples": missing_samples,
        }

    # Helper for filer-scoped pack stats.
    def _filer_pack_stats(*, s: ReconciliationSet, f: models.Filer) -> Dict[str, Any]:
        req_elements = set_required_elements.get(s.set_id, [])
        required_count = len(req_elements)
        present_count = 0
        missing_samples: List[Dict[str, Any]] = []

        if required_count:
            for el in req_elements:
                present = find_present_datapoint(
                    idx=idx,
                    xml_path=el.xpath,
                    filer_code=(f.filer_code or None),
                    jurisdiction_code=None,
                    entity_code=None,
                )
                if present is not None:
                    present_count += 1
                else:
                    if missing_sample_n and len(missing_samples) < missing_sample_n:
                        missing_samples.append({"xml_path": el.xpath, "tax_label": el.tax_label})

        missing_count = max(0, required_count - present_count)
        ratio = (present_count / required_count) if required_count else None
        return {
            "set_id": s.set_id,
            "active": True,
            "required_count": required_count,
            "present_count": present_count,
            "missing_count": missing_count,
            "completion_ratio": ratio,
            "missing_samples": missing_samples,
        }

    # Helper for entity-scoped pack stats (summarized per jurisdiction).
    def _entity_pack_stats_for_juris(*, s: ReconciliationSet, j: models.Jurisdiction) -> Dict[str, Any]:
        active = jurisdiction_applies_to_set(s, j)
        if not active and not include_inactive:
            return {}

        req_elements = set_required_elements.get(s.set_id, [])
        required_paths = [el.xpath for el in req_elements]
        if not active:
            return {
                "set_id": s.set_id,
                "active": False,
                "expected_entities": 0,
                "entities_complete": 0,
                "entities_partial": 0,
                "entities_missing": 0,
                "missing_datapoints_total": 0,
                "required_datapoints_per_entity": len(required_paths),
                "completion_ratio_entities": None,
            }

        exp_entities = entities_by_juris.get((j.jurisdiction_code or "").strip(), [])
        expected = len(exp_entities)
        complete = 0
        partial = 0
        missing = 0
        missing_total = 0

        for e in exp_entities:
            fc = (e.filed_by_filer_code or None)
            jc = (j.jurisdiction_code or None)
            ec = (e.entity_code or None)

            present_count = 0
            for xp in required_paths:
                present = find_present_datapoint(
                    idx=idx,
                    xml_path=xp,
                    filer_code=fc,
                    jurisdiction_code=jc,
                    entity_code=ec,
                )
                if present is not None:
                    present_count += 1

            missing_count = len(required_paths) - present_count
            missing_total += max(0, missing_count)
            if present_count == 0:
                missing += 1
            elif missing_count == 0:
                complete += 1
            else:
                partial += 1

        ratio = (complete / expected) if expected else None
        return {
            "set_id": s.set_id,
            "active": True,
            "expected_entities": expected,
            "entities_complete": complete,
            "entities_partial": partial,
            "entities_missing": missing,
            "missing_datapoints_total": int(missing_total),
            "required_datapoints_per_entity": len(required_paths),
            "completion_ratio_entities": ratio,
        }

    # Jurisdiction dashboard rows.
    juris_out: List[Dict[str, Any]] = []
    for jc, j in sorted(juris_by_code.items(), key=lambda kv: kv[0]):
        row = {
            "jurisdiction_code": jc,
            "responsible_filer_code": j.responsible_filer_code,
            "computation_mode": j.computation_mode,
            "computation_mode_norm": normalize_computation_mode(j.computation_mode),
            "qdmt_applicable": j.qdmt_applicable,
            "packs": [],
            "entity_packs": [],

            "packs_active_count": 0,
            "packs_required_total": 0,
            "packs_present_total": 0,
            "packs_missing_total": 0,
            "packs_completion_ratio": None,

            "entity_packs_active_count": 0,
            "entity_packs_expected_entities_total": 0,
            "entity_packs_entities_complete_total": 0,
            "entity_packs_entities_missing_total": 0,
        }

        for s in sets:
            scope = (s.scope or "").strip().lower()
            if scope == "jurisdiction":
                st = _juris_pack_stats(s=s, j=j)
                if st:
                    row["packs"].append(st)
            elif scope == "entity":
                st = _entity_pack_stats_for_juris(s=s, j=j)
                if st:
                    row["entity_packs"].append(st)

        # Totals (active packs only)
        active_packs = [p for p in (row.get("packs") or []) if bool(p.get("active"))]
        req_total = int(sum(int(p.get("required_count") or 0) for p in active_packs))
        pres_total = int(sum(int(p.get("present_count") or 0) for p in active_packs))
        miss_total = int(sum(int(p.get("missing_count") or 0) for p in active_packs))
        row["packs_active_count"] = int(len(active_packs))
        row["packs_required_total"] = req_total
        row["packs_present_total"] = pres_total
        row["packs_missing_total"] = miss_total
        row["packs_completion_ratio"] = (pres_total / req_total) if req_total else None

        active_entity_packs = [p for p in (row.get("entity_packs") or []) if bool(p.get("active"))]
        row["entity_packs_active_count"] = int(len(active_entity_packs))
        row["entity_packs_expected_entities_total"] = int(sum(int(p.get("expected_entities") or 0) for p in active_entity_packs))
        row["entity_packs_entities_complete_total"] = int(sum(int(p.get("entities_complete") or 0) for p in active_entity_packs))
        row["entity_packs_entities_missing_total"] = int(sum(int(p.get("entities_missing") or 0) for p in active_entity_packs))

        juris_out.append(row)

    # Filer dashboard rows.
    filer_out: List[Dict[str, Any]] = []
    for f in sorted(filers, key=lambda x: (x.filer_code or "")):
        row = {
            "filer_code": f.filer_code,
            "role": f.role,
            "jurisdiction_code": f.jurisdiction_code,
            "packs": [],

            "packs_active_count": 0,
            "packs_required_total": 0,
            "packs_present_total": 0,
            "packs_missing_total": 0,
            "packs_completion_ratio": None,
        }
        for s in sets:
            scope = (s.scope or "").strip().lower()
            if scope == "filer":
                row["packs"].append(_filer_pack_stats(s=s, f=f))

        active_packs = [p for p in (row.get("packs") or []) if bool(p.get("active"))]
        req_total = int(sum(int(p.get("required_count") or 0) for p in active_packs))
        pres_total = int(sum(int(p.get("present_count") or 0) for p in active_packs))
        miss_total = int(sum(int(p.get("missing_count") or 0) for p in active_packs))
        row["packs_active_count"] = int(len(active_packs))
        row["packs_required_total"] = req_total
        row["packs_present_total"] = pres_total
        row["packs_missing_total"] = miss_total
        row["packs_completion_ratio"] = (pres_total / req_total) if req_total else None
        filer_out.append(row)

    return {
        "sets": [
            {
                "set_id": s.set_id,
                "description": s.description,
                "section": s.section,
                "scope": s.scope,
                "pack_family": s.pack_family,
                "pack_variant": s.pack_variant,
                "pack_tags": list(s.pack_tags or []),
                "treat_included_as_required": bool(getattr(s, "treat_included_as_required", False)),
                "computation_mode_in": s.computation_mode_in,
                "qdmt_applicable": s.qdmt_applicable,
            }
            for s in sets
        ],
        "jurisdictions": juris_out,
        "filers": filer_out,
    }


# -----------------------------
# Dashboard caching (Sprint 2.5)
# -----------------------------

_DASHBOARD_CACHE_LOCK = threading.Lock()
_DASHBOARD_CACHE: Dict[str, Tuple[float, float, Dict[str, Any]]] = {}
_DASHBOARD_CACHE_MAX_ENTRIES = 64
_DASHBOARD_CACHE_TTL_SECONDS_DEFAULT = 300  # 5 minutes


def _dashboard_cache_cleanup(now_ts: float) -> None:
    """Remove expired entries and evict oldest if over capacity."""
    # Remove expired
    expired_keys = [k for k, (exp, _created, _val) in _DASHBOARD_CACHE.items() if exp <= now_ts]
    for k in expired_keys:
        _DASHBOARD_CACHE.pop(k, None)

    # Evict oldest if over capacity
    if len(_DASHBOARD_CACHE) > _DASHBOARD_CACHE_MAX_ENTRIES:
        items = sorted(_DASHBOARD_CACHE.items(), key=lambda kv: kv[1][1])  # created_at asc
        for k, _v in items[: max(0, len(_DASHBOARD_CACHE) - _DASHBOARD_CACHE_MAX_ENTRIES)]:
            _DASHBOARD_CACHE.pop(k, None)


def _compute_filing_watermark(db: Session, filing: models.Filing) -> str:
    """Compute a watermark that changes whenever filing inputs change.

    Used to make cached dashboard results safe:
    - datapoints updated_at
    - filers/entities/jurisdictions updated_at
    - filing.updated_at
    """
    ts_vals: List[datetime] = []

    def _max_updated(model_cls):
        try:
            return (
                db.query(func.max(model_cls.updated_at))
                .filter(model_cls.filing_id == filing.id)
                .scalar()
            )
        except Exception:
            return None

    for cls in (models.DataPoint, models.Filer, models.ConstituentEntity, models.Jurisdiction):
        m = _max_updated(cls)
        if m:
            ts_vals.append(m)

    if getattr(filing, "updated_at", None):
        ts_vals.append(filing.updated_at)

    if not ts_vals:
        # Fall back to filing id (still stable) — but this should rarely happen.
        return f"{filing.id}"

    return max(ts_vals).isoformat()


def compute_pack_completeness_dashboard_cached(
    *,
    db: Session,
    filing: models.Filing,
    config: GIRConfig,
    sets: List[ReconciliationSet],
    include_inactive: bool = False,
    missing_sample_n: int = 10,
    jurisdiction_codes: Optional[Iterable[str]] = None,
    filer_codes: Optional[Iterable[str]] = None,
    use_cache: bool = True,
    cache_ttl_seconds: Optional[int] = None,
) -> Dict[str, Any]:
    """Compute the pack completeness dashboard, with a safe cache.

    Cache key includes:
    - filing id + config version
    - computed watermark (max updated_at across inputs)
    - included sets
    - flags and filters

    Persisted changes automatically invalidate the cache via watermark.
    """
    ttl = int(cache_ttl_seconds or _DASHBOARD_CACHE_TTL_SECONDS_DEFAULT)
    ttl = max(0, min(ttl, 3600))

    # Always compute watermark; it is cheap and ensures safety.
    watermark = _compute_filing_watermark(db, filing)

    set_key = ",".join(sorted([str(s.set_id or "") for s in (sets or [])]))
    juris_key = ",".join(sorted({str(c).strip().upper() for c in (jurisdiction_codes or []) if str(c).strip()}))
    filer_key = ",".join(sorted({str(c).strip() for c in (filer_codes or []) if str(c).strip()}))

    key_payload = f"{filing.id}|{filing.config_version_id}|{watermark}|{set_key}|{include_inactive}|{missing_sample_n}|{juris_key}|{filer_key}"
    key = sha1(key_payload.encode("utf-8")).hexdigest()

    if not use_cache or ttl == 0:
        return compute_pack_completeness_dashboard(
            db=db,
            filing=filing,
            config=config,
            sets=sets,
            include_inactive=include_inactive,
            missing_sample_n=missing_sample_n,
            jurisdiction_codes=jurisdiction_codes,
            filer_codes=filer_codes,
        )

    now_ts = time.time()
    with _DASHBOARD_CACHE_LOCK:
        _dashboard_cache_cleanup(now_ts)
        hit = _DASHBOARD_CACHE.get(key)
        if hit:
            exp_ts, _created_ts, val = hit
            if exp_ts > now_ts:
                return val

    # Miss; compute outside lock.
    val = compute_pack_completeness_dashboard(
        db=db,
        filing=filing,
        config=config,
        sets=sets,
        include_inactive=include_inactive,
        missing_sample_n=missing_sample_n,
        jurisdiction_codes=jurisdiction_codes,
        filer_codes=filer_codes,
    )

    with _DASHBOARD_CACHE_LOCK:
        _dashboard_cache_cleanup(now_ts)
        _DASHBOARD_CACHE[key] = (now_ts + ttl, now_ts, val)

    return val
