from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from hashlib import sha256
import re
from typing import Dict, List, Optional, Sequence, Set, Tuple

from sqlalchemy.orm import Session

from app.db import models
from app.services.config_models import GIRConfig
from app.services.utils import try_parse_date


def _norm_xpath(xp: Optional[str]) -> str:
    """Normalize xpaths for robust matching across wrapper variants.

    Mirrors the logic used in validation_engine so imports and validations agree.
    """
    if not xp:
        return ""
    x = xp.strip()
    x = x.replace(
        "/GLOBE_OECD/GLOBEBody/eForm/Payload/GLOBE_OECD/GLOBEBody",
        "/GLOBE_OECD/GLOBEBody",
    )
    x = x.replace(
        "/eForm/Payload/GLOBE_OECD/GLOBEBody",
        "/GLOBE_OECD/GLOBEBody",
    )
    x = re.sub(r"/{2,}", "/", x)
    return x


def _section_to_record_type(section: Optional[str]) -> Optional[str]:
    if not section:
        return None
    s = section.strip()
    if s == "General":
        return "GeneralSection"
    if s == "Jurisdiction":
        return "JurisdictionSection"
    return s


def _derive_message_ref_id(datapoint_rows: Sequence[dict]) -> Optional[str]:
    for dp in datapoint_rows:
        xp = _norm_xpath(dp.get("xml_path") or "")
        if xp.lower().endswith("/messagerefid"):
            v = (dp.get("value_raw") or "").strip()
            if v:
                return v
    return None


def _derive_reporting_period(datapoint_rows: Sequence[dict]) -> Tuple[Optional[date], Optional[date]]:
    start: Optional[date] = None
    end: Optional[date] = None
    for dp in datapoint_rows:
        xp = (_norm_xpath(dp.get("xml_path") or "")).lower()
        if "globeheader" not in xp or "reportingperiod" not in xp:
            continue
        v = (dp.get("value_raw") or "").strip()
        if not v:
            continue
        d = try_parse_date(v)
        if d is None:
            continue
        if xp.endswith("/startdate") and start is None:
            start = d
        if xp.endswith("/enddate") and end is None:
            end = d
    return start, end


def _build_docref_section_map(config: GIRConfig) -> Dict[str, str]:
    """Map normalized DocRefId xpath (lowercased) -> config.section."""
    out: Dict[str, str] = {}
    for e in (config.elements or []):
        if (e.element_name or "").strip() != "DocRefId":
            continue
        if not e.xpath:
            continue
        out[_norm_xpath(e.xpath).lower()] = (e.section or "").strip()
    return out


def _build_container_prefixes(config: GIRConfig) -> List[Tuple[str, str]]:
    """Return list of (record_type, container_xpath_lc) sorted by longest prefix."""
    items: List[Tuple[str, str]] = []
    for s in (config.section_cardinality or []):
        rt = _section_to_record_type(s.section)
        if not rt or not s.container_xpath:
            continue
        items.append((rt, _norm_xpath(s.container_xpath).lower()))
    items.sort(key=lambda x: len(x[1]), reverse=True)
    return items


def _infer_record_type_from_xpath(xp_lc: str, container_prefixes: List[Tuple[str, str]]) -> Optional[str]:
    for rt, pref in container_prefixes:
        if pref and xp_lc.startswith(pref):
            return rt
    return None


def extract_docspec_records(
    datapoint_rows: Sequence[dict],
    config: GIRConfig,
) -> List[dict]:
    """Extract DocSpec summary rows from imported datapoint rows.

    We create one SubmissionRecord per DocRefId datapoint found.
    """
    # Fast lookup of values by (scope key + xpath)
    key_to_val: Dict[Tuple[Optional[str], Optional[str], Optional[str], Optional[str], str], str] = {}
    for dp in datapoint_rows:
        xp = _norm_xpath(dp.get("xml_path") or "")
        if not xp:
            continue
        key = (
            dp.get("filer_code"),
            dp.get("jurisdiction_code"),
            dp.get("entity_code"),
            dp.get("context_key"),
            xp,
        )
        key_to_val[key] = (dp.get("value_raw") or "").strip()

    docref_section = _build_docref_section_map(config)
    container_prefixes = _build_container_prefixes(config)

    records: List[dict] = []
    for dp in datapoint_rows:
        xp = _norm_xpath(dp.get("xml_path") or "")
        if not xp:
            continue
        xp_lc = xp.lower()
        # DocRefId but not CorrDocRefId
        if not xp_lc.endswith("/docrefid") or xp_lc.endswith("/corrdocrefid"):
            continue
        doc_ref_id = (dp.get("value_raw") or "").strip()
        if not doc_ref_id:
            continue

        base = xp.rsplit("/", 1)[0]
        doc_type = key_to_val.get((
            dp.get("filer_code"), dp.get("jurisdiction_code"), dp.get("entity_code"), dp.get("context_key"), base + "/DocTypeIndic"
        ), "").strip()
        corr = key_to_val.get((
            dp.get("filer_code"), dp.get("jurisdiction_code"), dp.get("entity_code"), dp.get("context_key"), base + "/CorrDocRefId"
        ), "").strip()

        sec = docref_section.get(xp_lc)
        record_type = _section_to_record_type(sec) if sec else None
        if not record_type:
            record_type = _infer_record_type_from_xpath(xp_lc, container_prefixes) or "Unknown"

        records.append({
            "record_type": record_type,
            "filer_code": (dp.get("filer_code") or None),
            "doc_type_indic": doc_type or None,
            "doc_ref_id": doc_ref_id,
            "corr_doc_ref_id": corr or None,
        })

    return records


def record_submission_from_import(
    *,
    db: Session,
    filing: models.Filing,
    config: GIRConfig,
    source_type: str,
    file_url: Optional[str],
    file_bytes: Optional[bytes],
    datapoint_rows: Sequence[dict],
    message_ref_id: Optional[str] = None,
    reporting_period_start: Optional[date] = None,
    reporting_period_end: Optional[date] = None,
    notes: Optional[str] = None,
) -> models.Submission:
    """Persist a Submission + SubmissionRecord rows for an import."""
    file_hash = None
    if file_bytes:
        file_hash = sha256(file_bytes).hexdigest()

    if message_ref_id is None:
        message_ref_id = _derive_message_ref_id(datapoint_rows)

    if reporting_period_start is None or reporting_period_end is None:
        s, e = _derive_reporting_period(datapoint_rows)
        reporting_period_start = reporting_period_start or s
        reporting_period_end = reporting_period_end or e

    sub = models.Submission(
        filing_id=filing.id,
        source_type=source_type,
        file_url=file_url,
        file_hash=file_hash,
        message_ref_id=message_ref_id,
        reporting_period_start=reporting_period_start,
        reporting_period_end=reporting_period_end,
        imported_at=datetime.utcnow(),
        notes=notes,
    )
    db.add(sub)
    db.commit()
    db.refresh(sub)

    recs = extract_docspec_records(datapoint_rows, config)
    if recs:
        for r in recs:
            db.add(models.SubmissionRecord(
                submission_id=sub.id,
                filing_id=filing.id,
                record_type=r.get("record_type") or "Unknown",
                filer_code=r.get("filer_code"),
                doc_type_indic=r.get("doc_type_indic"),
                doc_ref_id=r.get("doc_ref_id"),
                corr_doc_ref_id=r.get("corr_doc_ref_id"),
                created_at=datetime.utcnow(),
            ))
        db.commit()

    return sub
