from typing import List, Dict, Optional, Union
from pydantic import BaseModel, Field

MaxOccurs = Union[int, str]

class Element(BaseModel):
    section: str
    element_name: str
    tax_label: str
    guidance: Optional[str] = None
    input_field: bool = False
    example_value: Optional[str] = None
    required: bool = False
    repeatable: bool = False
    repeatability_scope: Optional[str] = None
    allowed_values: List[str] = Field(default_factory=list)
    is_container: bool = False
    xsd_type: Optional[str] = None
    min_occurs: Optional[int] = None
    max_occurs: Optional[MaxOccurs] = None
    xpath: str
    hierarchy_level: Optional[int] = None
    xml_hierarchy_path: Optional[str] = None

class SectionCardinality(BaseModel):
    section: str
    container_xpath: str
    xsd_type: Optional[str] = None
    min_occurs: Optional[int] = None
    max_occurs: Optional[MaxOccurs] = None
    repeatable: bool = False

class ErrorCode(BaseModel):
    section: str
    number: int
    path_target: Optional[str] = None
    path_reference: Optional[str] = None
    element_name: Optional[str] = None
    validation_rule: Optional[str] = None
    validation_description: Optional[str] = None

class ConfigMeta(BaseModel):
    config_version_id: str
    generated_at_utc: str
    source_workbook_sha256: str
    source_xsd_sha256: Optional[str] = None
    source_xsd_source: Optional[str] = None
    attributes_added: Optional[int] = None
    required_attributes_added: Optional[int] = None
    notes: Optional[str] = None

class GIRConfig(BaseModel):
    meta: ConfigMeta
    elements: List[Element]
    section_cardinality: List[SectionCardinality]
    codelists: Dict[str, List[str]]
    error_codes: List[ErrorCode]
