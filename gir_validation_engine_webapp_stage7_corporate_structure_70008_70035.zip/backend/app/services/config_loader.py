import json
import os
from pathlib import Path
from typing import List, Dict, Any, Optional
from app.services.config_models import GIRConfig

def list_config_versions(config_root: str) -> List[str]:
    root = Path(config_root)
    if not root.exists():
        return []
    return sorted([p.name for p in root.iterdir() if p.is_dir()])

def load_config(config_root: str, config_version_id: str) -> GIRConfig:
    folder = Path(config_root) / config_version_id
    if not folder.exists():
        raise FileNotFoundError(f"Config version '{config_version_id}' not found under {config_root}")

    def _read(name: str) -> Any:
        with open(folder / name, "r", encoding="utf-8") as f:
            return json.load(f)

    meta = _read("config.json")
    elements = _read("elements.json")
    section_cardinality = _read("section_cardinality.json")
    codelists = _read("codelists.json")
    error_codes = _read("error_codes.json")

    return GIRConfig(
        meta=meta,
        elements=elements,
        section_cardinality=section_cardinality,
        codelists=codelists,
        error_codes=error_codes,
    )

def load_config_meta(config_root: str, config_version_id: str) -> Dict[str, Any]:
    folder = Path(config_root) / config_version_id
    with open(folder / "config.json", "r", encoding="utf-8") as f:
        return json.load(f)



def load_error_codes(config_root: str, config_version_id: str) -> List[Dict[str, Any]]:
    """Load the OECD GIR error code catalogue for a config version.

    This reads `error_codes.json` only (unlike `load_config`, which loads the full config pack).
    """
    folder = Path(config_root) / config_version_id
    with open(folder / "error_codes.json", "r", encoding="utf-8") as f:
        return json.load(f)
