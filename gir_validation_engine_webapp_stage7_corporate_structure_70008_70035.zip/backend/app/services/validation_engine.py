from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha1
import re
from typing import Dict, List, Optional, Set, Tuple, Iterable
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP

from sqlalchemy.orm import Session

from app.db import models
from app.services.config_models import GIRConfig, Element, ErrorCode
from app.services.utils import try_parse_decimal, try_parse_date


@dataclass(frozen=True)
class Issue:
    severity: str  # BLOCKING/WARNING/INFO
    rule_id: str
    message: str
    how_to_fix: Optional[str] = None
    error_number: Optional[int] = None
    section: Optional[str] = None
    xml_path: Optional[str] = None
    filer_code: Optional[str] = None
    jurisdiction_code: Optional[str] = None
    entity_code: Optional[str] = None
    context_key: Optional[str] = None


def _rid(prefix: str, key: str) -> str:
    h = sha1(key.encode("utf-8")).hexdigest()[:10].upper()
    return f"{prefix}-{h}"


def _ancestors(xpath: str) -> List[str]:
    """Return all ancestor xpaths (excluding the xpath itself).

    Example: /a/b/c -> [/a/b, /a]
    """
    out: List[str] = []
    cur = xpath
    while "/" in cur:
        cur = cur.rsplit("/", 1)[0]
        if cur:
            out.append(cur)
        else:
            break
    return out



# -----------------------------
# Choice container overrides
# -----------------------------
#
# The extracted Excel config does not model XSD <choice> groups. In the OECD GIR
# schema, certain sibling containers (e.g., UPE/ExcludedUPE vs UPE/OtherUPE) are
# mutually exclusive. Without special handling, both branches appear 'required'
# and the engine produces false missing-required errors.
#
# Sprint 1.3: treat known choice-branches as optional 'gates'. Required leaf
# elements under these containers are only enforced when the branch is active
# (i.e., any datapoint exists beneath it).
CHOICE_CONTAINER_MIN_OCCURS_OVERRIDES: Dict[str, int] = {
    "/GLOBE_OECD/GLOBEBody/GeneralSection/CorporateStructure/UPE/ExcludedUPE": 0,
    "/GLOBE_OECD/GLOBEBody/GeneralSection/CorporateStructure/UPE/OtherUPE": 0,
}

def _build_container_index(config: GIRConfig) -> Dict[str, int]:
    """Map container xpath -> min_occurs.

    Includes:
    - container elements (complex types) from elements.json
    - section root containers from section_cardinality.json
    """
    containers: Dict[str, int] = {}
    for e in config.elements:
        if e.is_container and e.xpath:
            containers[e.xpath] = int(e.min_occurs or 0)
    for s in config.section_cardinality:
        if s.container_xpath:
            containers[s.container_xpath] = int(s.min_occurs or 0)
    # Apply choice overrides (see CHOICE_CONTAINER_MIN_OCCURS_OVERRIDES).
    for xp, mo in CHOICE_CONTAINER_MIN_OCCURS_OVERRIDES.items():
        containers[xp] = int(mo)

    return containers


def _deepest_optional_gate(leaf_xpath: str, containers_min_occurs: Dict[str, int]) -> Optional[str]:
    """Find the deepest optional container (minOccurs=0) in the leaf's ancestor chain.

    This is the container we use to gate requiredness to reduce false positives for
    optional blocks.
    """
    for anc in _ancestors(leaf_xpath):
        mo = containers_min_occurs.get(anc)
        if mo is None:
            continue
        if mo == 0:
            return anc
    return None


# -----------------------------
# Error code mapping helpers
# -----------------------------

def _error_by_number(config: GIRConfig) -> Dict[int, ErrorCode]:
    out: Dict[int, ErrorCode] = {}
    for ec in config.error_codes:
        if ec.number is None:
            continue
        out[int(ec.number)] = ec
    return out


def _oecd_fix_text(error_map: Dict[int, ErrorCode], number: int) -> Optional[str]:
    ec = error_map.get(number)
    if ec and ec.validation_description:
        return ec.validation_description
    return None



# -----------------------------
# Calculation helpers (Stage 4: 60025–60028)
# -----------------------------

_CALC_Q4 = Decimal("0.0001")
_CALC_MARGIN = Decimal("0.01")  # 1% relative margin


def _round4(x: Decimal) -> Decimal:
    """Round to 4 decimal places (OECD guidance for calc validations)."""
    return x.quantize(_CALC_Q4, rounding=ROUND_HALF_UP)


def _as_decimal(val: Optional[object]) -> Optional[Decimal]:
    if val is None:
        return None
    if isinstance(val, Decimal):
        return val
    try:
        return Decimal(str(val))
    except Exception:
        return None


def _dp_decimal(dp: models.DataPoint) -> Optional[Decimal]:
    """Best-effort decimal value from a datapoint."""
    if dp.value_numeric is not None:
        return _as_decimal(dp.value_numeric)
    v = (dp.value_raw or "").strip()
    if not v:
        return None
    return try_parse_decimal(v)


def _calc_equal(expected: Decimal, actual: Decimal) -> bool:
    """Return True if actual is within OECD tolerance rules.

    We apply:
      1) rounding to 4dp
      2) allow 1% relative margin (when expected != 0)
      3) when expected == 0, allow tiny absolute tolerance (4dp)
    """
    exp4 = _round4(expected)
    act4 = _round4(actual)
    if exp4 == act4:
        return True
    diff = abs(act4 - exp4)
    if exp4 == 0:
        return diff <= _CALC_Q4
    return diff <= abs(exp4) * _CALC_MARGIN


# -----------------------------
# Record type mapping helpers (DocSpec)
# -----------------------------
#
# Several OECD severe record errors refer to the DocTypeIndic of specific "record types"
# (FilingInfo, GeneralSection, Summary, JurisdictionSection, UTPRAttribution). Early
# versions of this engine used substring matching on xml_path, which can be brittle
# (eForm wrappers, variant roots, etc.). These helpers map record types explicitly
# using config-derived container xpaths and DocSpec/DocTypeIndic xpaths.

@dataclass(frozen=True)
class RecordTypeSpec:
    record_type: str
    section: str
    container_xpaths_lc: Set[str]
    doctypeindic_xpaths_lc: Set[str]


def _norm_xpath(xp: Optional[str]) -> str:
    """Normalize xpaths for robust matching across wrapper variants.

    The config extracted from the Excel/XSD toolkit sometimes includes an eForm wrapper
    segment like:
      /GLOBE_OECD/GLOBEBody/eForm/Payload/GLOBE_OECD/GLOBEBody/...

    while XML imports may produce:
      /GLOBE_OECD/GLOBEBody/...

    We collapse the wrapper segment when present.
    """
    if not xp:
        return ""
    x = xp.strip()
    x = x.replace(
        "/GLOBE_OECD/GLOBEBody/eForm/Payload/GLOBE_OECD/GLOBEBody",
        "/GLOBE_OECD/GLOBEBody",
    )
    x = x.replace(
        "/eForm/Payload/GLOBE_OECD/GLOBEBody",
        "/GLOBE_OECD/GLOBEBody",
    )
    x = re.sub(r"/{2,}", "/", x)
    return x


def _parse_bool(v: Optional[str]) -> Optional[bool]:
    """Parse common boolean lexical forms used in XML attributes.

    Returns:
      - True / False when parsing succeeds
      - None when value is missing or unrecognized
    """
    if v is None:
        return None
    s = str(v).strip().lower()
    if s == "":
        return None
    if s in {"1", "true", "t", "yes", "y"}:
        return True
    if s in {"0", "false", "f", "no", "n"}:
        return False
    return None



def _build_record_type_specs(config: GIRConfig) -> Dict[str, RecordTypeSpec]:
    """Build explicit record-type specifications from config.

    Returns a dict with keys:
      - FilingInfo
      - GeneralSection
      - Summary
      - JurisdictionSection
      - UTPRAttribution
    """
    containers_by_section: Dict[str, str] = {}
    for s in config.section_cardinality:
        if s.section and s.container_xpath:
            containers_by_section[s.section] = _norm_xpath(s.container_xpath).lower()

    doctype_by_section: Dict[str, Set[str]] = {}
    for e in config.elements:
        if not e.xpath:
            continue
        if (e.element_name or "").strip().lower() != "doctypeindic":
            continue
        sec = (e.section or "").strip()
        doctype_by_section.setdefault(sec, set()).add(_norm_xpath(e.xpath).lower())

    def _mk(record_type: str, section: str) -> RecordTypeSpec:
        cx = containers_by_section.get(section, "")
        dx = doctype_by_section.get(section, set())
        return RecordTypeSpec(
            record_type=record_type,
            section=section,
            container_xpaths_lc={cx} if cx else set(),
            doctypeindic_xpaths_lc=set(dx),
        )

    return {
        "FilingInfo": _mk("FilingInfo", "FilingInfo"),
        "GeneralSection": _mk("GeneralSection", "General"),
        "Summary": _mk("Summary", "Summary"),
        "JurisdictionSection": _mk("JurisdictionSection", "Jurisdiction"),
        "UTPRAttribution": _mk("UTPRAttribution", "UTPRAttribution"),
    }


def _filer_matches(dp_filer: Optional[str], filer: Optional[str]) -> bool:
    """Treat missing dp.filer_code as 'global' (matches any filer)."""
    if not filer:
        return True
    if not (dp_filer or "").strip():
        return True
    return dp_filer == filer


def _dp_xpath_lc(dp: models.DataPoint) -> str:
    return _norm_xpath(dp.xml_path).lower() if dp.xml_path else ""


def _record_present(dps: List[models.DataPoint], spec: RecordTypeSpec, filer: Optional[str]) -> bool:
    """Return True if any datapoint exists under the record container for the filer."""
    if not spec.container_xpaths_lc:
        return False
    for dp in dps:
        if not _filer_matches(dp.filer_code, filer):
            continue
        xp = _dp_xpath_lc(dp)
        for cx in spec.container_xpaths_lc:
            if cx and xp.startswith(cx):
                return True
    return False


def _record_doctype_dps(dps: List[models.DataPoint], spec: RecordTypeSpec, filer: Optional[str]) -> List[models.DataPoint]:
    """Return datapoints that correspond to DocSpec/DocTypeIndic for the record type."""
    if not spec.doctypeindic_xpaths_lc:
        return []
    out: List[models.DataPoint] = []
    for dp in dps:
        if not _filer_matches(dp.filer_code, filer):
            continue
        xp = _dp_xpath_lc(dp)
        if xp in spec.doctypeindic_xpaths_lc:
            out.append(dp)
    return out


# -----------------------------
# Scoping helpers
# -----------------------------

ScopeKind = str  # "filing" | "filer" | "jurisdiction" | "entity"


def _infer_scope(e: Element) -> ScopeKind:
    """Best-effort scope inference based on section and xpath.

    Sprint 1.2 goal: improve scoping so requiredness is not just "present somewhere".

    Principles:
    - Jurisdiction section is jurisdiction-scoped.
    - CE/ConstituentEntity/CEComputation blocks are entity-scoped.
    - FilingInfo is filer-scoped.
    - General/Summary/UTPRAttribution default to filer-scoped (but filing-level values
      satisfy all filers).
    """
    sec = (e.section or "").strip().lower()
    xp = (e.xpath or "").lower()

    if sec == "jurisdiction" or "jurisdictionsection" in xp:
        return "jurisdiction"

    # Entity-level constructs
    if any(tok in xp for tok in ["/cecomputation/", "/constituententity", "/corporatestructure/ce/", "nonmaterial"]):
        return "entity"

    if sec == "filinginfo" or "filingce" in xp:
        return "filer"

    if sec in {"general", "summary", "utprattribution"}:
        return "filer"

    return "filing"


def _build_presence_indexes(non_empty_dps: List[models.DataPoint]) -> dict:
    """Build sets for fast presence checks across scopes."""
    present_paths_global: Set[str] = set()
    present_by_filer: Set[Tuple[str, str]] = set()
    present_by_juris: Set[Tuple[str, str]] = set()
    present_by_entity: Set[Tuple[str, str]] = set()

    present_by_filer_juris: Set[Tuple[str, str, str]] = set()
    present_by_filer_entity: Set[Tuple[str, str, str]] = set()

    # Track "no-filer" subsets for jurisdiction/entity so filer-scoped checks can accept shared values.
    present_juris_no_filer: Set[Tuple[str, str]] = set()
    present_entity_no_filer: Set[Tuple[str, str]] = set()

    for dp in non_empty_dps:
        present_paths_global.add(dp.xml_path)

        if dp.filer_code:
            present_by_filer.add((dp.filer_code, dp.xml_path))

        if dp.jurisdiction_code:
            present_by_juris.add((dp.jurisdiction_code, dp.xml_path))
            if not dp.filer_code:
                present_juris_no_filer.add((dp.jurisdiction_code, dp.xml_path))

        if dp.entity_code:
            present_by_entity.add((dp.entity_code, dp.xml_path))
            if not dp.filer_code:
                present_entity_no_filer.add((dp.entity_code, dp.xml_path))

        if dp.filer_code and dp.jurisdiction_code:
            present_by_filer_juris.add((dp.filer_code, dp.jurisdiction_code, dp.xml_path))

        if dp.filer_code and dp.entity_code:
            present_by_filer_entity.add((dp.filer_code, dp.entity_code, dp.xml_path))

    return {
        "present_paths_global": present_paths_global,
        "present_by_filer": present_by_filer,
        "present_by_juris": present_by_juris,
        "present_by_entity": present_by_entity,
        "present_by_filer_juris": present_by_filer_juris,
        "present_by_filer_entity": present_by_filer_entity,
        "present_juris_no_filer": present_juris_no_filer,
        "present_entity_no_filer": present_entity_no_filer,
    }


def _build_activation_indexes(non_empty_dps: List[models.DataPoint], optional_containers: Set[str]) -> dict:
    """Build activation sets for optional blocks across scopes.

    A block is "active" for a scope if any non-empty datapoint exists under that container.
    """
    active_optional_global: Set[str] = set()
    active_optional_by_filer: Dict[str, Set[str]] = {}
    active_optional_by_juris: Dict[str, Set[str]] = {}
    active_optional_by_entity: Dict[str, Set[str]] = {}
    active_optional_by_filer_juris: Dict[Tuple[str, str], Set[str]] = {}
    active_optional_by_filer_entity: Dict[Tuple[str, str], Set[str]] = {}

    for dp in non_empty_dps:
        for anc in _ancestors(dp.xml_path):
            if anc not in optional_containers:
                continue
            active_optional_global.add(anc)
            if dp.filer_code:
                active_optional_by_filer.setdefault(dp.filer_code, set()).add(anc)
            if dp.jurisdiction_code:
                active_optional_by_juris.setdefault(dp.jurisdiction_code, set()).add(anc)
            if dp.entity_code:
                active_optional_by_entity.setdefault(dp.entity_code, set()).add(anc)
            if dp.filer_code and dp.jurisdiction_code:
                active_optional_by_filer_juris.setdefault((dp.filer_code, dp.jurisdiction_code), set()).add(anc)
            if dp.filer_code and dp.entity_code:
                active_optional_by_filer_entity.setdefault((dp.filer_code, dp.entity_code), set()).add(anc)

    return {
        "active_optional_global": active_optional_global,
        "active_optional_by_filer": active_optional_by_filer,
        "active_optional_by_juris": active_optional_by_juris,
        "active_optional_by_entity": active_optional_by_entity,
        "active_optional_by_filer_juris": active_optional_by_filer_juris,
        "active_optional_by_filer_entity": active_optional_by_filer_entity,
    }


def _is_gate_active(
    gate: Optional[str],
    *,
    filer: Optional[str],
    juris: Optional[str],
    entity: Optional[str],
    activation: dict,
    force_active: bool = False,
) -> bool:
    if gate is None:
        return True
    if force_active:
        return True

    if gate in activation["active_optional_global"]:
        return True

    if filer and gate in activation["active_optional_by_filer"].get(filer, set()):
        return True

    if juris and gate in activation["active_optional_by_juris"].get(juris, set()):
        return True

    if entity and gate in activation["active_optional_by_entity"].get(entity, set()):
        return True

    if filer and juris and gate in activation["active_optional_by_filer_juris"].get((filer, juris), set()):
        return True

    if filer and entity and gate in activation["active_optional_by_filer_entity"].get((filer, entity), set()):
        return True

    return False



# -----------------------------
# Register-driven datapoint bridge (Sprint 1.3)
# -----------------------------

DEFAULT_ID_RULES = "GIR201"
DEFAULT_GLOBE_STATUS = "GIR301"
DEFAULT_OWNERSHIP_TYPE = "GIR801"

def _dp_key(dp: models.DataPoint) -> Tuple[Optional[str], Optional[str], Optional[str], Optional[str], str]:
    return (dp.filer_code, dp.jurisdiction_code, dp.entity_code, dp.context_key, dp.xml_path)

def _make_virtual_dp(
    *,
    filing_id: str,
    xml_path: str,
    value_raw: str,
    filer_code: Optional[str] = None,
    jurisdiction_code: Optional[str] = None,
    entity_code: Optional[str] = None,
    context_key: Optional[str] = None,
    source_system: str = "register_bridge",
    notes: Optional[str] = None,
) -> models.DataPoint:
    now = datetime.utcnow()
    dp = models.DataPoint(
        filing_id=filing_id,
        filer_code=filer_code,
        jurisdiction_code=jurisdiction_code,
        entity_code=entity_code,
        context_key=context_key,
        xml_path=xml_path,
        value_raw=value_raw,
        source="derived",
        source_system=source_system,
        notes=notes,
        updated_at=now,
        created_at=now,
    )
    dp.value_numeric = try_parse_decimal(value_raw)
    dp.value_date = try_parse_date(value_raw)
    return dp

def _find_xpath(
    config: GIRConfig,
    *,
    section: Optional[str] = None,
    endswith: Optional[str] = None,
    contains: Optional[str] = None,
) -> Optional[str]:
    for e in config.elements:
        if section and (e.section or "") != section:
            continue
        xp = (e.xpath or "").strip()
        if not xp:
            continue
        if endswith and not xp.endswith(endswith):
            continue
        if contains and contains not in xp:
            continue
        return xp
    return None

def _gen_docrefid(prefix: str, filing_id: str, scope_key: str) -> str:
    """Generate a schema-friendly DocRefId.

    OECD severe record error **60011** expects a high-level format:
      [CountryCode][ReportingYear][UniqueID]

    For this web tool we generate a deterministic value that:
      - stays within the XSD 200 char max
      - matches the expected high-level pattern
      - is stable for a given (prefix, filing_id, scope_key)

    The `prefix` parameter is overloaded:
      - If prefix matches /^[A-Z]{2}\\d{4}$/ then we treat it as CCYYYY
      - Otherwise we fall back to CC=XX and YYYY=1900

    Callers that *know* the CCYYYY should pass it via prefix.
    """
    key = f"{prefix}|{filing_id}|{scope_key}"
    h = sha1(key.encode("utf-8")).hexdigest()[:20].upper()

    cc = "XX"
    yyyy = "1900"
    if re.match(r"^[A-Z]{2}\d{4}$", (prefix or "")):
        cc = prefix[:2]
        yyyy = prefix[2:6]

    docref = f"{cc}{yyyy}{h}"
    return docref[:200]

def _map_filing_ce_role(filer: models.Filer) -> Optional[str]:
    # Prefer explicit GIR code if provided.
    if (filer.filing_ce_role or "").strip():
        return filer.filing_ce_role.strip()
    r = (filer.role or "").strip().upper()
    if r == "UPE":
        return "GIR401"
    if "DESIGNATED" in r:
        return "GIR402"
    if "LOCAL" in r:
        return "GIR403"
    if r in {"POPE", "CE", "CONSTITUENT"}:
        return "GIR404"
    if r:
        return "GIR405"
    return None

def _register_hint_for_xpath(xpath: str) -> Optional[str]:
    xp = xpath or ""
    # Filing register
    if xp.endswith("/FilingCE/Name"):
        return "Populate legal_name in the Filing Entity Register."
    if xp.endswith("/FilingCE/TIN"):
        return "Populate tin in the Filing Entity Register (or use NOTIN if applicable)."
    if xp.endswith("/FilingCE/Role"):
        return "Populate filing_ce_role (preferred) or role in the Filing Entity Register."
    if xp.endswith("/FilingInfo/Period/Start"):
        return "Populate period_start on the Filing record (or submit a datapoint for Period/Start)."
    if xp.endswith("/FilingInfo/Period/End"):
        return "Populate period_end on the Filing record (or submit a datapoint for Period/End)."
    if xp.endswith("/FilingInfo/AccountingInfo/Currency"):
        return "Populate reporting_currency on the Filing record (or submit a datapoint for AccountingInfo/Currency)."
    if xp.endswith("/DocSpec/DocTypeIndic") or xp.endswith("/DocSpec/DocRefId"):
        return "DocSpec values are auto-generated by the engine unless you override them via datapoints."

    # Constituent entity register
    if "/CorporateStructure/CE/ID/Name" in xp:
        return "Populate legal_name in the Constituent Entity Register for this entity."
    if "/CorporateStructure/CE/ID/ResCountryCode" in xp:
        return "Populate jurisdiction_code in the Constituent Entity Register for this entity."
    if "/CorporateStructure/CE/ID/TIN" in xp:
        return "Populate tin in the Constituent Entity Register for this entity (or use NOTIN if applicable)."
    if "/CorporateStructure/CE/ID/Rules" in xp:
        return "Populate id_rules in the Constituent Entity Register for this entity."
    if "/CorporateStructure/CE/ID/GlobeStatus" in xp:
        return "Populate globe_status in the Constituent Entity Register for this entity."
    if "/CorporateStructure/CE/Ownership/OwnershipType" in xp:
        return "Populate ownership_type (GIR801..GIR806) in the Constituent Entity Register for this entity."
    if "/CorporateStructure/CE/Ownership/OwnershipPercentage" in xp:
        return "Populate ownership_percentage in the Constituent Entity Register for this entity."
    if "/CorporateStructure/CE/Ownership/TIN" in xp:
        return "Provide owner_tin_override, or set parent_entity_code (with a TIN present on the parent), so the engine can derive the ownership holder TIN."

    # Jurisdiction register
    if xp.endswith("/JurisdictionSection/Jurisdiction"):
        return "Ensure this jurisdiction is present in the Jurisdiction Register."
    if xp.endswith("/JurisdictionSection/LocalCurrency"):
        return "Populate local_currency in the Jurisdiction Register (if required for your facts)."
    if xp.endswith("/JurisdictionSection/RecJurCode"):
        return "Populate the receiving jurisdiction(s). By default the engine uses the responsible filer's jurisdiction_code."

    return None

def derive_virtual_datapoints_from_registers(
    *,
    db: Session,
    filing: models.Filing,
    config: GIRConfig,
    filers: List[models.Filer],
    jurisdictions: List[models.Jurisdiction],
    entities: List[models.ConstituentEntity],
    existing_datapoints: List[models.DataPoint],
    suppress_if_exists: bool = True,
) -> List[models.DataPoint]:
    """Create non-persisted datapoints from registers (and filing header fields).

    These derived datapoints are used for validation scope/presence checks, so the
    engine can be 'register driven' rather than requiring users to manually
    populate datapoints for obvious header / identity fields.

    The rule is: *never override an explicit datapoint* (same key).
    """
    # Keys already explicitly provided by the user (persisted datapoints).
    # By default we suppress derived datapoints that would collide with these keys.
    occupied_keys: Set[Tuple[Optional[str], Optional[str], Optional[str], Optional[str], str]] = (
        {_dp_key(dp) for dp in existing_datapoints} if suppress_if_exists else set()
    )

    # Avoid duplicates in the derived output itself.
    seen_keys: Set[Tuple[Optional[str], Optional[str], Optional[str], Optional[str], str]] = set()

    out: List[models.DataPoint] = []

    def add(
        *,
        xml_path: Optional[str],
        value: Optional[str],
        filer_code: Optional[str] = None,
        jurisdiction_code: Optional[str] = None,
        entity_code: Optional[str] = None,
        context_key: Optional[str] = None,
        origin: Optional[str] = None,
    ):
        if not xml_path:
            return
        v = (value or "").strip()
        if v == "":
            return
        dp = _make_virtual_dp(
            filing_id=filing.id,
            xml_path=xml_path,
            value_raw=v,
            filer_code=filer_code,
            jurisdiction_code=jurisdiction_code,
            entity_code=entity_code,
            context_key=context_key,
            notes=origin,
        )
        k = _dp_key(dp)
        if k in occupied_keys:
            return
        if k in seen_keys:
            return
        seen_keys.add(k)
        out.append(dp)

    # --- XPaths (config driven) ---
    xp_filingce_name = _find_xpath(config, section="FilingInfo", endswith="/FilingCE/Name")
    xp_filingce_tin = _find_xpath(config, section="FilingInfo", endswith="/FilingCE/TIN")
    xp_filingce_role = _find_xpath(config, section="FilingInfo", endswith="/FilingCE/Role")

    xp_filing_period_start = _find_xpath(config, section="FilingInfo", endswith="/FilingInfo/Period/Start")
    xp_filing_period_end = _find_xpath(config, section="FilingInfo", endswith="/FilingInfo/Period/End")
    xp_filing_currency = _find_xpath(config, section="FilingInfo", endswith="/FilingInfo/AccountingInfo/Currency")

    xp_filing_doc_type = _find_xpath(config, section="FilingInfo", endswith="/DocSpec/DocTypeIndic")
    xp_filing_doc_ref = _find_xpath(config, section="FilingInfo", endswith="/DocSpec/DocRefId")

    xp_summary_recjur = _find_xpath(config, section="Summary", endswith="/Summary/RecJurCode")
    xp_summary_doc_type = _find_xpath(config, section="Summary", endswith="/Summary/DocSpec/DocTypeIndic")
    xp_summary_doc_ref = _find_xpath(config, section="Summary", endswith="/Summary/DocSpec/DocRefId")

    xp_general_recjur = _find_xpath(config, section="General", endswith="/GeneralSection/RecJurCode")

    xp_juris = _find_xpath(config, section="Jurisdiction", endswith="/JurisdictionSection/Jurisdiction")
    xp_juris_recjur = _find_xpath(config, section="Jurisdiction", endswith="/JurisdictionSection/RecJurCode")
    xp_juris_local_cur = _find_xpath(config, section="Jurisdiction", endswith="/JurisdictionSection/LocalCurrency")
    xp_juris_doc_type = _find_xpath(config, section="Jurisdiction", endswith="/JurisdictionSection/DocSpec/DocTypeIndic")
    xp_juris_doc_ref = _find_xpath(config, section="Jurisdiction", endswith="/JurisdictionSection/DocSpec/DocRefId")

    # CorporateStructure (UPE branch - OtherUPE)
    xp_upe_name = _find_xpath(config, section="General", contains="/CorporateStructure/UPE/OtherUPE/ID/Name")
    xp_upe_res = _find_xpath(config, section="General", contains="/CorporateStructure/UPE/OtherUPE/ID/ResCountryCode")
    xp_upe_tin = _find_xpath(config, section="General", contains="/CorporateStructure/UPE/OtherUPE/ID/TIN")
    xp_upe_rules = _find_xpath(config, section="General", contains="/CorporateStructure/UPE/OtherUPE/ID/Rules")
    xp_upe_status = _find_xpath(config, section="General", contains="/CorporateStructure/UPE/OtherUPE/ID/GlobeStatus")

    # CorporateStructure (CE)
    xp_ce_name = _find_xpath(config, section="General", contains="/CorporateStructure/CE/ID/Name")
    xp_ce_res = _find_xpath(config, section="General", contains="/CorporateStructure/CE/ID/ResCountryCode")
    xp_ce_tin = _find_xpath(config, section="General", contains="/CorporateStructure/CE/ID/TIN")
    xp_ce_rules = _find_xpath(config, section="General", contains="/CorporateStructure/CE/ID/Rules")
    xp_ce_status = _find_xpath(config, section="General", contains="/CorporateStructure/CE/ID/GlobeStatus")

    xp_own_type = _find_xpath(config, section="General", contains="/CorporateStructure/CE/Ownership/OwnershipType")
    xp_own_tin = _find_xpath(config, section="General", contains="/CorporateStructure/CE/Ownership/TIN")
    xp_own_pct = _find_xpath(config, section="General", contains="/CorporateStructure/CE/Ownership/OwnershipPercentage")

    # --- Filing header datapoints (global; satisfy all filers) ---
    add(xml_path=xp_filing_period_start, value=filing.period_start.isoformat() if filing.period_start else None, origin="filing.period_start")
    add(xml_path=xp_filing_period_end, value=filing.period_end.isoformat() if filing.period_end else None, origin="filing.period_end")
    add(xml_path=xp_filing_currency, value=filing.reporting_currency, origin="filing.reporting_currency")

    # --- Best-effort CCYYYY prefix for DocRefId generation ---
    # Prefer the UPE jurisdiction, then any filer jurisdiction, then infer from TIN.
    def _best_effort_ccyyyy() -> str:
        # 1) UPE filer jurisdiction
        upe = next((f for f in filers if (f.role or "").strip().upper() == "UPE" and (f.jurisdiction_code or "").strip()), None)
        if upe and (upe.jurisdiction_code or "").strip():
            cc = upe.jurisdiction_code.strip().upper()[:2]
        else:
            # 2) any filer jurisdiction
            any_f = next((f for f in filers if (f.jurisdiction_code or "").strip()), None)
            if any_f and (any_f.jurisdiction_code or "").strip():
                cc = any_f.jurisdiction_code.strip().upper()[:2]
            else:
                # 3) infer from TIN prefix (e.g. "US-...")
                tin = (filers[0].tin or "").strip() if filers else ""
                cc = (tin[:2].upper() if len(tin) >= 2 and tin[:2].isalpha() else "XX")

        year = (filing.period_end.year if filing.period_end else datetime.utcnow().year)
        return f"{cc}{year:04d}"

    ccyyyy = _best_effort_ccyyyy()

    # --- FilingInfo per filer ---
    for f in filers:
        fc = (f.filer_code or "").strip()
        if not fc:
            continue
        add(xml_path=xp_filingce_name, value=f.legal_name, filer_code=fc, origin="filer.legal_name")
        add(xml_path=xp_filingce_tin, value=f.tin, filer_code=fc, origin="filer.tin")
        add(xml_path=xp_filingce_role, value=_map_filing_ce_role(f), filer_code=fc, origin="filer.filing_ce_role_or_role_map")

        # DocSpec (auto-generated) for FilingInfo
        # Default to OECD1 (new record) for self-serve validation.
        add(xml_path=xp_filing_doc_type, value="OECD1", filer_code=fc, origin="auto_generated:filinginfo.docspec.doctype")
        add(xml_path=xp_filing_doc_ref, value=_gen_docrefid(ccyyyy, filing.id, f"FILINFO:{fc}"), filer_code=fc, origin="auto_generated:filinginfo.docspec.docrefid")

    # --- Summary (global) ---
    add(xml_path=xp_summary_doc_type, value="OECD1", origin="auto_generated:summary.docspec.doctype")
    add(xml_path=xp_summary_doc_ref, value=_gen_docrefid(ccyyyy, filing.id, "SUMMARY:GLOBAL"), origin="auto_generated:summary.docspec.docrefid")

    # --- Receiving jurisdiction codes (global, repeatable) ---
    juris_codes = sorted({(j.jurisdiction_code or "").strip().upper() for j in jurisdictions if (j.jurisdiction_code or "").strip()})
    for code in juris_codes:
        add(xml_path=xp_general_recjur, value=code, context_key=f"GEN_RECJUR:{code}", origin="jurisdiction_register.jurisdiction_code")
        add(xml_path=xp_summary_recjur, value=code, context_key=f"SUM_RECJUR:{code}", origin="jurisdiction_register.jurisdiction_code")

    # --- JurisdictionSection (per jurisdiction) ---
    filers_by_code: Dict[str, models.Filer] = {f.filer_code: f for f in filers if f.filer_code}
    for j in jurisdictions:
        jc = (j.jurisdiction_code or "").strip().upper()
        if not jc:
            continue
        responsible = (j.responsible_filer_code or "").strip() or None
        responsible_filer = filers_by_code.get(responsible) if responsible else None
        rec = (responsible_filer.jurisdiction_code or "").strip().upper() if responsible_filer else None
        add(xml_path=xp_juris, value=jc, jurisdiction_code=jc, filer_code=responsible, origin="jurisdiction_register.jurisdiction_code")
        add(xml_path=xp_juris_recjur, value=rec or jc, jurisdiction_code=jc, filer_code=responsible, origin="jurisdiction_register.responsible_filer_or_jurisdiction")
        add(xml_path=xp_juris_local_cur, value=j.local_currency, jurisdiction_code=jc, filer_code=responsible, origin="jurisdiction_register.local_currency")
        add(xml_path=xp_juris_doc_type, value="OECD1", jurisdiction_code=jc, filer_code=responsible, origin="auto_generated:jurisdiction.docspec.doctype")
        add(xml_path=xp_juris_doc_ref, value=_gen_docrefid(ccyyyy, filing.id, f"JUR:{jc}:{responsible or 'GLOBAL'}"), jurisdiction_code=jc, filer_code=responsible, origin="auto_generated:jurisdiction.docspec.docrefid")

    # --- CorporateStructure: UPE ---
    upe_filers = [f for f in filers if (f.role or "").strip().upper() == "UPE"]
    for upe in upe_filers:
        u_code = (upe.filer_code or "").strip() or "UPE"
        ctx = f"UPE:{u_code}"
        add(xml_path=xp_upe_name, value=upe.legal_name, context_key=ctx, origin="filer_register(role=UPE).legal_name")
        add(xml_path=xp_upe_res, value=upe.jurisdiction_code, context_key=ctx, origin="filer_register(role=UPE).jurisdiction_code")
        add(xml_path=xp_upe_tin, value=upe.tin, context_key=ctx, origin="filer_register(role=UPE).tin")
        add(xml_path=xp_upe_rules, value=(upe.id_rules or DEFAULT_ID_RULES), context_key=ctx, origin="filer_register(role=UPE).id_rules_or_default")
        add(xml_path=xp_upe_status, value=(upe.globe_status or DEFAULT_GLOBE_STATUS), context_key=ctx, origin="filer_register(role=UPE).globe_status_or_default")

    # --- CorporateStructure: Constituent entities (included) ---
    entities_by_code: Dict[str, models.ConstituentEntity] = {e.entity_code: e for e in entities if e.entity_code}
    upe_tin = (upe_filers[0].tin or "").strip() if upe_filers else None

    def owner_tin(ent: models.ConstituentEntity) -> Tuple[Optional[str], str]:
        """Return (owner_tin_value, origin_string)."""
        if (ent.owner_tin_override or "").strip():
            return ent.owner_tin_override.strip(), "entity_register.owner_tin_override"
        p = (ent.parent_entity_code or "").strip()
        if p and p in entities_by_code and (entities_by_code[p].tin or "").strip():
            return entities_by_code[p].tin.strip(), f"entity_register.parent_entity_code({p}).tin"
        fb = (ent.filed_by_filer_code or "").strip()
        if fb and fb in filers_by_code and (filers_by_code[fb].tin or "").strip():
            return filers_by_code[fb].tin.strip(), f"filer_register({fb}).tin"
        if upe_tin and upe_tin.strip():
            return upe_tin.strip(), "filer_register(role=UPE).tin"
        return None, "unresolved"

    for ent in entities:
        if not ent.included_in_gir:
            continue
        ec = (ent.entity_code or "").strip()
        if not ec:
            continue
        ctx = f"CE:{ec}"
        fc = (ent.filed_by_filer_code or "").strip() or None
        add(xml_path=xp_ce_name, value=ent.legal_name, entity_code=ec, filer_code=fc, context_key=ctx, origin="entity_register.legal_name")
        add(xml_path=xp_ce_res, value=ent.jurisdiction_code, entity_code=ec, filer_code=fc, context_key=ctx, origin="entity_register.jurisdiction_code")
        add(xml_path=xp_ce_tin, value=ent.tin, entity_code=ec, filer_code=fc, context_key=ctx, origin="entity_register.tin")
        add(xml_path=xp_ce_rules, value=(ent.id_rules or DEFAULT_ID_RULES), entity_code=ec, filer_code=fc, context_key=ctx, origin="entity_register.id_rules_or_default")
        add(xml_path=xp_ce_status, value=(ent.globe_status or DEFAULT_GLOBE_STATUS), entity_code=ec, filer_code=fc, context_key=ctx, origin="entity_register.globe_status_or_default")

        add(xml_path=xp_own_type, value=(ent.ownership_type or DEFAULT_OWNERSHIP_TYPE), entity_code=ec, filer_code=fc, context_key=ctx, origin="entity_register.ownership_type_or_default")
        own_tin_val, own_tin_origin = owner_tin(ent)
        add(xml_path=xp_own_tin, value=own_tin_val, entity_code=ec, filer_code=fc, context_key=ctx, origin=own_tin_origin)
        add(
            xml_path=xp_own_pct,
            value=str(ent.ownership_percentage) if ent.ownership_percentage is not None else None,
            entity_code=ec,
            filer_code=fc,
            context_key=ctx,
            origin="entity_register.ownership_percentage",
        )

    return out

def run_validations(
    db: Session,
    filing_id: str,
    config: GIRConfig,
    *,
    attribute_requiredness_mode: str = "auto",
) -> List[Issue]:
    # Load filing + registers + datapoints.
    filing = db.get(models.Filing, filing_id)
    if filing is None:
        # Should be prevented by the API layer, but keep validation_engine robust.
        return [Issue(
            severity="BLOCKING",
            rule_id=_rid("SYS", f"missing_filing|{filing_id}"),
            section="General",
            message="Filing not found.",
            how_to_fix="Create the filing first, then retry validation.",
        )]

    dps: List[models.DataPoint] = (
        db.query(models.DataPoint)
        .filter(models.DataPoint.filing_id == filing_id)
        .all()
    )

    filers: List[models.Filer] = (
        db.query(models.Filer).filter(models.Filer.filing_id == filing_id).all()
    )
    juris_rows: List[models.Jurisdiction] = (
        db.query(models.Jurisdiction).filter(models.Jurisdiction.filing_id == filing_id).all()
    )
    entity_rows: List[models.ConstituentEntity] = (
        db.query(models.ConstituentEntity).filter(models.ConstituentEntity.filing_id == filing_id).all()
    )

    # Sprint 1.3: derive datapoints from registers so validations can be register-driven.
    virtual_dps = derive_virtual_datapoints_from_registers(
        db=db,
        filing=filing,
        config=config,
        filers=filers,
        jurisdictions=juris_rows,
        entities=entity_rows,
        existing_datapoints=dps,
    )
    all_dps: List[models.DataPoint] = list(dps) + list(virtual_dps)
    # "Submission view" datapoints: excludes engine-derived helper datapoints.
    # Many OECD severe record errors are defined against the submitted XML.
    submission_dps: List[models.DataPoint] = [dp for dp in all_dps if (dp.source or "").lower() != "derived"]

    # Build element lookup for type / allowed values checks.
    elements_by_path: Dict[str, Element] = {e.xpath: e for e in config.elements if e.xpath}

    non_empty_dps: List[models.DataPoint] = [dp for dp in all_dps if (dp.value_raw or "").strip() != ""]
    presence = _build_presence_indexes(non_empty_dps)

    issues: List[Issue] = []

    # -----------------------------
    # 0) Precompute config-driven helper indexes
    # -----------------------------
    containers_min_occurs = _build_container_index(config)
    optional_containers: Set[str] = {xp for xp, mo in containers_min_occurs.items() if mo == 0}
    activation = _build_activation_indexes(non_empty_dps, optional_containers)

    error_map = _error_by_number(config)

    # -----------------------------
    # Stage 3: Submission history context ("previously received")
    # -----------------------------
    #
    # Certain OECD severe record errors (e.g., 60002 / 60008 / 60009 / 60014) depend on
    # what has been previously received. The web tool stores an immutable Submission
    # summary per import (see models.Submission / models.SubmissionRecord).
    submissions: List[models.Submission] = []
    current_submission: Optional[models.Submission] = None
    prev_submissions: List[models.Submission] = []
    prev_records: List[models.SubmissionRecord] = []

    # Indexes used by cross-submission validations
    prev_docrefs_by_filer: Dict[Optional[str], Set[str]] = {}
    corr_successor: Dict[str, str] = {}  # CorrDocRefId -> DocRefId (latest successor in history)
    sub_time: Dict[str, datetime] = {}

    try:
        submissions = (
            db.query(models.Submission)
            .filter(models.Submission.filing_id == filing_id)
            .order_by(models.Submission.imported_at.asc())
            .all()
        )
        if submissions:
            current_submission = submissions[-1]
            prev_submissions = submissions[:-1]
            sub_time = {s.id: (s.imported_at or datetime.min) for s in submissions}

        if prev_submissions:
            prev_ids = [s.id for s in prev_submissions]
            prev_records = (
                db.query(models.SubmissionRecord)
                .filter(models.SubmissionRecord.filing_id == filing_id)
                .filter(models.SubmissionRecord.submission_id.in_(prev_ids))
                .all()
            )

        for r in prev_records:
            if not r.doc_ref_id:
                continue
            fk = r.filer_code  # None means GLOBAL
            prev_docrefs_by_filer.setdefault(fk, set()).add((r.doc_ref_id or "").strip())

        # Build successor links for correction chains in *history* (order matters).
        recs_sorted = sorted(
            [r for r in prev_records if (r.corr_doc_ref_id or '').strip() and (r.doc_ref_id or '').strip()],
            key=lambda rr: sub_time.get(rr.submission_id, datetime.min),
        )
        for r in recs_sorted:
            corr = (r.corr_doc_ref_id or '').strip()
            new = (r.doc_ref_id or '').strip()
            if corr and new:
                corr_successor[corr] = new

    except Exception:
        # Non-fatal: if history tables are not available, cross-submission checks are skipped.
        submissions = []
        current_submission = None
        prev_submissions = []
        prev_records = []
        prev_docrefs_by_filer = {}
        corr_successor = {}
        sub_time = {}

    def _latest_instance(docref: str) -> str:
        """Follow CorrDocRefId -> DocRefId links to find the latest instance in history."""
        cur = (docref or '').strip()
        seen: Set[str] = set()
        while cur and cur in corr_successor and cur not in seen:
            seen.add(cur)
            cur = (corr_successor.get(cur) or '').strip()
        return cur


    # Expected filers (prefer register; fallback to datapoints)
    expected_filers: List[str] = sorted({f.filer_code for f in filers if (f.filer_code or "").strip()})
    if not expected_filers:
        expected_filers = sorted({dp.filer_code for dp in all_dps if dp.filer_code})

    # Expected jurisdictions (prefer register; fallback to datapoints)
    responsible_by_juris: Dict[str, Optional[str]] = {
        j.jurisdiction_code: (j.responsible_filer_code or None)
        for j in juris_rows
    }
    expected_jurisdictions: List[str] = sorted({j.jurisdiction_code for j in juris_rows})
    if not expected_jurisdictions:
        expected_jurisdictions = sorted({dp.jurisdiction_code for dp in all_dps if dp.jurisdiction_code})

    # Expected entities (prefer register; fallback to datapoints)
    filed_by_entity: Dict[str, Optional[str]] = {
        e.entity_code: (e.filed_by_filer_code or None)
        for e in entity_rows
        if e.entity_code
    }
    expected_entities: List[str] = sorted({e.entity_code for e in entity_rows if e.included_in_gir and e.entity_code})
    if not expected_entities:
        expected_entities = sorted({dp.entity_code for dp in all_dps if dp.entity_code})

    # Jurisdiction section root container (optional overall, but can be expected per jurisdiction)
    juris_section_container = next(
        (s.container_xpath for s in config.section_cardinality if s.section == "Jurisdiction"),
        None,
    )

    # Helpful inference: if jurisdiction_code is not set on the datapoint but the
    # value of RecJurCode/Jurisdiction looks like an ISO-2 code, treat it as
    # belonging to that jurisdiction for scoping checks.
    # (We add these to presence indexes in a minimal way.)
    for dp in non_empty_dps:
        if dp.jurisdiction_code:
            continue
        if not dp.xml_path:
            continue
        if not (dp.xml_path.endswith("/RecJurCode") or dp.xml_path.endswith("/Jurisdiction")):
            continue
        code = (dp.value_raw or "").strip().upper()
        if len(code) == 2 and code.isalpha():
            presence["present_by_juris"].add((code, dp.xml_path))
            if dp.filer_code:
                presence["present_by_filer_juris"].add((dp.filer_code, code, dp.xml_path))
            else:
                presence["present_juris_no_filer"].add((code, dp.xml_path))

    # -----------------------------
    # 1) Generated validations (Sprint 1.2)
    # -----------------------------

    # 1a) Required leaf element presence (scope-aware)
    #
    # Stage 4.5: Attribute-path requiredness
    #
    # The importer can emit attribute datapoints with xml_path like:
    #   /.../TIN/@issuedBy
    # Some configs (when generated from the OECD XSD rather than the Excel toolkit)
    # may include attributes as required nodes.
    #
    # To avoid breaking XLSX/CSV submissions (which typically cannot supply XML
    # attributes), we allow this behaviour to be controlled via a mode:
    #   - off  : never enforce attribute requiredness
    #   - auto : enforce only when the latest submission source_type is "xml"
    #   - on   : always enforce
    arm = (attribute_requiredness_mode or "auto").strip().lower()
    if arm not in {"off", "auto", "on"}:
        arm = "auto"
    config_has_attributes = any("/@" in (el.xpath or "") for el in (config.elements or []))
    enforce_attribute_requiredness = False
    if config_has_attributes:
        if arm == "on":
            enforce_attribute_requiredness = True
        elif arm == "auto":
            enforce_attribute_requiredness = bool(
                current_submission
                and (current_submission.source_type or "").strip().lower() == "xml"
            )

    def _is_required_leaf(el: Element) -> bool:
        if el.is_container:
            return False
        if not el.required:
            return False
        xp = (el.xpath or "").strip()
        is_attr = "/@" in xp
        if is_attr:
            return enforce_attribute_requiredness
        return (el.min_occurs or 0) >= 1

    required_elements = [e for e in (config.elements or []) if _is_required_leaf(e)]

    def _present_for_filer(filer: str, xpath: str) -> bool:
        return (
            xpath in presence["present_paths_global"]
            or (filer, xpath) in presence["present_by_filer"]
        )

    def _present_for_juris(juris: str, xpath: str, filer: Optional[str]) -> bool:
        if filer:
            # Prefer scoped datapoints for the responsible filer; allow "no-filer" shared datapoints.
            return (
                (filer, juris, xpath) in presence["present_by_filer_juris"]
                or (juris, xpath) in presence["present_juris_no_filer"]
            )
        # If no responsible filer is defined, accept any filer scoped to that jurisdiction.
        return (juris, xpath) in presence["present_by_juris"]

    def _present_for_entity(entity: str, xpath: str, filer: Optional[str]) -> bool:
        if filer:
            return (
                (filer, entity, xpath) in presence["present_by_filer_entity"]
                or (entity, xpath) in presence["present_entity_no_filer"]
            )
        return (entity, xpath) in presence["present_by_entity"]

    for e in required_elements:
        scope = _infer_scope(e)
        gate = _deepest_optional_gate(e.xpath, containers_min_occurs)

        if scope == "jurisdiction" and expected_jurisdictions:
            for juris in expected_jurisdictions:
                responsible = responsible_by_juris.get(juris)
                filer_for_scope = responsible

                # Special case: treat JurisdictionSection root as active if the jurisdiction is expected.
                force_active = bool(juris_section_container and gate == juris_section_container)

                if not _is_gate_active(
                    gate,
                    filer=filer_for_scope,
                    juris=juris,
                    entity=None,
                    activation=activation,
                    force_active=force_active,
                ):
                    continue

                if not _present_for_juris(juris, e.xpath, filer_for_scope):
                    kind = "attribute" if "/@" in (e.xpath or "") else "element"
                    issues.append(Issue(
                        severity="BLOCKING",
                        rule_id=_rid("REQJ", f"{e.xpath}|{juris}|{filer_for_scope or ''}"),
                        section=e.section,
                        xml_path=e.xpath,
                        filer_code=filer_for_scope,
                        jurisdiction_code=juris,
                        message=(
                            f"Missing required {kind} for jurisdiction {juris}"
                            + (f" (responsible filer {filer_for_scope})" if filer_for_scope else "")
                            + f": {e.tax_label} ({e.xpath})"
                        ),
                        how_to_fix=_register_hint_for_xpath(e.xpath) or "Provide a value for this required field for the jurisdiction.",
                    ))
            continue

        if scope == "entity" and expected_entities:
            for entity in expected_entities:
                filer_for_scope = filed_by_entity.get(entity)

                if not _is_gate_active(
                    gate,
                    filer=filer_for_scope,
                    juris=None,
                    entity=entity,
                    activation=activation,
                ):
                    continue

                if not _present_for_entity(entity, e.xpath, filer_for_scope):
                    kind = "attribute" if "/@" in (e.xpath or "") else "element"
                    issues.append(Issue(
                        severity="BLOCKING",
                        rule_id=_rid("REQE", f"{e.xpath}|{entity}|{filer_for_scope or ''}"),
                        section=e.section,
                        xml_path=e.xpath,
                        filer_code=filer_for_scope,
                        entity_code=entity,
                        message=(
                            f"Missing required {kind} for entity {entity}"
                            + (f" (filed by {filer_for_scope})" if filer_for_scope else "")
                            + f": {e.tax_label} ({e.xpath})"
                        ),
                        how_to_fix=_register_hint_for_xpath(e.xpath) or "Provide a value for this required field for the entity.",
                    ))
            continue

        if scope == "filer" and expected_filers:
            for filer in expected_filers:
                if not _is_gate_active(
                    gate,
                    filer=filer,
                    juris=None,
                    entity=None,
                    activation=activation,
                ):
                    continue

                if not _present_for_filer(filer, e.xpath):
                    kind = "attribute" if "/@" in (e.xpath or "") else "element"
                    issues.append(Issue(
                        severity="BLOCKING",
                        rule_id=_rid("REQF", f"{e.xpath}|{filer}"),
                        section=e.section,
                        xml_path=e.xpath,
                        filer_code=filer,
                        message=f"Missing required {kind} for filer {filer}: {e.tax_label} ({e.xpath})",
                        how_to_fix=_register_hint_for_xpath(e.xpath) or "Provide a value for this required field for the filing entity.",
                    ))
            continue

        # Filing-level presence (gated by optional containers)
        if not _is_gate_active(
            gate,
            filer=None,
            juris=None,
            entity=None,
            activation=activation,
        ):
            continue

        if e.xpath not in presence["present_paths_global"]:
            kind = "attribute" if "/@" in (e.xpath or "") else "element"
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("REQ", e.xpath),
                section=e.section,
                xml_path=e.xpath,
                message=f"Missing required {kind}: {e.tax_label} ({e.xpath})",
                how_to_fix=_register_hint_for_xpath(e.xpath) or "Provide a value for this required field.",
            ))

    # 1b) Allowed values (enums / code lists)
    for dp in all_dps:
        e = elements_by_path.get(dp.xml_path)
        if e is None:
            continue  # unknown path
        allowed = list(e.allowed_values or [])
        if not allowed:
            continue
        v = (dp.value_raw or "").strip()
        if v == "":
            continue
        if v not in allowed:
            preview = ", ".join(allowed[:20])
            more = "" if len(allowed) <= 20 else f" (+{len(allowed)-20} more)"
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("ENUM", f"{dp.xml_path}|{v}|{dp.filer_code}|{dp.jurisdiction_code}|{dp.entity_code}|{dp.context_key}"),
                section=e.section,
                xml_path=dp.xml_path,
                filer_code=dp.filer_code,
                jurisdiction_code=dp.jurisdiction_code,
                entity_code=dp.entity_code,
                context_key=dp.context_key,
                message=f"Invalid value '{v}' for {e.tax_label}. Allowed: {preview}{more}",
                how_to_fix="Select/submit a value from the allowed code list.",
            ))

    # 1c) Basic datatype sanity (best-effort)
    for dp in all_dps:
        e = elements_by_path.get(dp.xml_path)
        if e is None or not e.xsd_type:
            continue
        v = (dp.value_raw or "").strip()
        if v == "":
            continue
        t = e.xsd_type.lower()
        if "date" in t and dp.value_date is None:
            issues.append(Issue(
                severity="WARNING",
                rule_id=_rid("TYPE", f"date|{dp.xml_path}|{v}|{dp.filer_code}|{dp.jurisdiction_code}|{dp.entity_code}|{dp.context_key}"),
                section=e.section,
                xml_path=dp.xml_path,
                filer_code=dp.filer_code,
                jurisdiction_code=dp.jurisdiction_code,
                entity_code=dp.entity_code,
                context_key=dp.context_key,
                message=f"Value '{v}' does not look like a valid date for {e.tax_label}.",
                how_to_fix="Provide the date in ISO format (YYYY-MM-DD) or as required by your data source.",
            ))
        if any(x in t for x in ["decimal", "integer", "nonnegativeinteger", "positiveinteger"]) and dp.value_numeric is None:
            issues.append(Issue(
                severity="WARNING",
                rule_id=_rid("TYPE", f"num|{dp.xml_path}|{v}|{dp.filer_code}|{dp.jurisdiction_code}|{dp.entity_code}|{dp.context_key}"),
                section=e.section,
                xml_path=dp.xml_path,
                filer_code=dp.filer_code,
                jurisdiction_code=dp.jurisdiction_code,
                entity_code=dp.entity_code,
                context_key=dp.context_key,
                message=f"Value '{v}' does not look like a valid number for {e.tax_label}.",
                how_to_fix="Provide a numeric value (e.g., 123.45).",
            ))

    # -----------------------------
    # 2) Bespoke validations (expanded / scoped)
    # -----------------------------

    filer_codes = {f.filer_code for f in filers}

    # 2a) Exactly one UPE filer (best-effort; assumes role='UPE')
    upe_filers = [f for f in filers if (f.role or "").strip().upper() == "UPE"]
    if len(upe_filers) != 1:
        issues.append(Issue(
            severity="BLOCKING",
            rule_id=_rid("BIZ", "upe_count"),
            section="General",
            message=f"Expected exactly 1 UPE filer in Filing Entity Register, found {len(upe_filers)}.",
            how_to_fix="Ensure one (and only one) filer has role 'UPE'.",
        ))

    # 2b) Included entities must map to an existing filer when multiple filers exist
    multi_filer = len(filers) > 1
    for ent in entity_rows:
        if not ent.included_in_gir:
            continue
        fb = (ent.filed_by_filer_code or "").strip()
        if fb == "":
            if multi_filer:
                issues.append(Issue(
                    severity="BLOCKING",
                    rule_id=_rid("BIZ", f"missing_filed_by|{ent.entity_code}"),
                    section="General",
                    entity_code=ent.entity_code,
                    message=f"Included entity '{ent.entity_code}' is missing filed_by_filer_code in a multi-filer filing.",
                    how_to_fix="Populate filed_by_filer_code for this entity to assign it to a filing entity (UPE/POPE/designated).",
                ))
            continue
        if fb not in filer_codes:
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("BIZ", f"invalid_filed_by|{ent.entity_code}|{fb}"),
                section="General",
                entity_code=ent.entity_code,
                message=f"Included entity '{ent.entity_code}' references unknown filer '{fb}'.",
                how_to_fix="Fix filed_by_filer_code to match a filer_code in the Filing Entity Register.",
            ))

    # 2c) DocRefId uniqueness and CorrDocRefId referential integrity (scoped per filer)
    #      This avoids false positives when one Filing contains multiple filer submissions.
    docref_paths = [p for p in {dp.xml_path for dp in submission_dps} if p and p.lower().endswith("docrefid") and not p.lower().endswith("corrdocrefid")]
    corr_paths = [p for p in {dp.xml_path for dp in submission_dps} if p and p.lower().endswith("corrdocrefid")]

    # Group datapoints by filer_code (None is its own group)
    def _filer_group(dp: models.DataPoint) -> Optional[str]:
        return dp.filer_code

    dps_by_filer: Dict[Optional[str], List[models.DataPoint]] = {}
    for dp in submission_dps:
        dps_by_filer.setdefault(_filer_group(dp), []).append(dp)

    from collections import Counter

    for filer, rows in dps_by_filer.items():
        # Collect DocRefId
        docref_values: List[str] = []
        for dp in rows:
            if dp.xml_path not in docref_paths:
                continue
            v = (dp.value_raw or "").strip()
            if v:
                docref_values.append(v)

        docref_counter = Counter(docref_values)
        duplicates = [v for v, c in docref_counter.items() if c > 1]
        if duplicates:
            preview = ", ".join(duplicates[:10])
            more = "" if len(duplicates) <= 10 else f" (+{len(duplicates)-10} more)"
            num = 60007 if 60007 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("DOC", f"dup_docrefid|{filer or 'GLOBAL'}"),
                section="FilingInfo",
                filer_code=filer,
                error_number=num,
                message=(
                    f"Duplicate DocRefId values detected for filer {filer or 'GLOBAL'}: {preview}{more}."
                ),
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure every DocRefId is unique within the submission.",
            ))

        docref_set = set(docref_counter.keys())

        # Collect CorrDocRefId
        corr_values: List[str] = []
        for dp in rows:
            if dp.xml_path not in corr_paths:
                continue
            v = (dp.value_raw or "").strip()
            if v:
                corr_values.append(v)

        # 60006: same docref corrected/deleted twice in same message
        corr_counter = Counter(corr_values)
        corr_dups = [v for v, c in corr_counter.items() if c > 1]
        if corr_dups:
            preview = ", ".join(corr_dups[:10])
            more = "" if len(corr_dups) <= 10 else f" (+{len(corr_dups)-10} more)"
            num = 60006 if 60006 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("DOC", f"dup_corrdocrefid|{filer or 'GLOBAL'}"),
                section="FilingInfo",
                filer_code=filer,
                error_number=num,
                message=f"The same CorrDocRefId is used more than once for filer {filer or 'GLOBAL'}: {preview}{more}.",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure each DocRefId is corrected/deleted at most once per submission.",
            ))

        # 60008: CorrDocRefId refers to an unknown record (cross-submission aware)
        history_known: Set[str] = set()
        if prev_docrefs_by_filer:
            if filer is None:
                for s in prev_docrefs_by_filer.values():
                    history_known |= set(s)
            else:
                history_known |= set(prev_docrefs_by_filer.get(filer, set()))
                history_known |= set(prev_docrefs_by_filer.get(None, set()))

        known_docrefs = set(docref_set) | history_known

        missing_corr_refs = sorted({v for v in corr_values if v not in known_docrefs})
        if missing_corr_refs:
            preview = ", ".join(missing_corr_refs[:10])
            more = "" if len(missing_corr_refs) <= 10 else f" (+{len(missing_corr_refs)-10} more)"
            num = 60008 if 60008 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("DOC", f"missing_corr_ref|{filer or 'GLOBAL'}"),
                section="FilingInfo",
                filer_code=filer,
                error_number=num,
                message=(
                    f"CorrDocRefId values not found among previously received DocRefId values for filer {filer or 'GLOBAL'}: "
                    f"{preview}{more}."
                ),
                how_to_fix=_oecd_fix_text(error_map, num) if num else "CorrDocRefId must reference an existing DocRefId from a previously received submission.",
            ))

        # 60009: CorrDocRefId does not relate to the latest instance (cross-submission)
        not_latest: List[Tuple[str, str]] = []
        for v in sorted({v for v in corr_values if v in history_known}):
            latest = _latest_instance(v)
            if latest and latest != v:
                not_latest.append((v, latest))

        if not_latest:
            preview = ", ".join([f"{a}->{b}" for (a, b) in not_latest[:8]])
            suffix = "..." if len(not_latest) > 8 else ""
            num = 60009 if 60009 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("DOC", f"corr_not_latest|{filer or 'GLOBAL'}"),
                section="FilingInfo",
                filer_code=filer,
                error_number=num,
                message=(
                    f"CorrDocRefId does not refer to the latest instance for filer {filer or 'GLOBAL'}: "
                    f"{preview}{suffix}."
                ),
                how_to_fix=_oecd_fix_text(error_map, num) if num else "When correcting/deleting a record, CorrDocRefId must refer to the latest previously received DocRefId in that correction chain.",
            ))

    # 2d) DocTypeIndic <-> CorrDocRefId consistency (scoped to the same DocSpec container)
    correction_types = {"OECD2", "OECD3", "OECD12", "OECD13"}

    # Build fast lookup by full key (filer/juris/entity/context + xml_path)
    key_to_dp: Dict[Tuple[Optional[str], Optional[str], Optional[str], Optional[str], str], models.DataPoint] = {}
    for dp in all_dps:
        key_to_dp[(dp.filer_code, dp.jurisdiction_code, dp.entity_code, dp.context_key, dp.xml_path)] = dp

    # CorrDocRefId present but DocTypeIndic is OECD0/OECD1 (OECD 60012)
    for dp in all_dps:
        if not dp.xml_path.lower().endswith("corrdocrefid"):
            continue
        corr_val = (dp.value_raw or "").strip()
        if not corr_val:
            continue
        base = dp.xml_path.rsplit("/", 1)[0]
        doc_type_path = base + "/DocTypeIndic"
        doc_type_dp = key_to_dp.get((dp.filer_code, dp.jurisdiction_code, dp.entity_code, dp.context_key, doc_type_path))
        if doc_type_dp is None:
            continue
        dt = (doc_type_dp.value_raw or "").strip()
        if dt in {"OECD0", "OECD1"}:
            num = 60012 if 60012 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("DOC", f"corr_present_non_correction|{dp.filer_code}|{dp.jurisdiction_code}|{dp.entity_code}|{dp.context_key}|{dp.xml_path}"),
                section="FilingInfo",
                filer_code=dp.filer_code,
                jurisdiction_code=dp.jurisdiction_code,
                entity_code=dp.entity_code,
                context_key=dp.context_key,
                xml_path=dp.xml_path,
                error_number=num,
                message=f"CorrDocRefId must be omitted when DocTypeIndic is '{dt}'.",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Remove CorrDocRefId or set DocTypeIndic to a correction/deletion code.",
            ))

    # DocTypeIndic indicates correction but CorrDocRefId missing
    for dp in all_dps:
        if not dp.xml_path.lower().endswith("doctypeindic"):
            continue
        dt = (dp.value_raw or "").strip()
        if dt not in correction_types:
            continue

        base = dp.xml_path.rsplit("/", 1)[0]
        corr_path = base + "/CorrDocRefId"
        corr_dp = key_to_dp.get((dp.filer_code, dp.jurisdiction_code, dp.entity_code, dp.context_key, corr_path))
        corr_val = (corr_dp.value_raw or "").strip() if corr_dp else ""
        if not corr_val:
            num = 60015 if 60015 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("DOC", f"missing_corrdocrefid|{dp.filer_code}|{dp.jurisdiction_code}|{dp.entity_code}|{dp.context_key}|{corr_path}|{dt}"),
                section="FilingInfo",
                filer_code=dp.filer_code,
                jurisdiction_code=dp.jurisdiction_code,
                entity_code=dp.entity_code,
                context_key=dp.context_key,
                xml_path=corr_path,
                error_number=num,
                message=f"DocTypeIndic='{dt}' indicates a correction/deletion but CorrDocRefId is missing.",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Provide CorrDocRefId referencing the prior DocRefId.",
            ))

    # -----------------------------
    # 2e) OECD 600xx severe record errors (single-file, best-effort)
    # -----------------------------

    # Helper: string value
    def _v(dp: models.DataPoint) -> str:
        return (dp.value_raw or "").strip()

    # 60001: MessageRefId format
    msgref_dps = [dp for dp in submission_dps if (dp.xml_path or "").endswith("/MessageRefId")]
    # Accept a high-level pattern: CCYYYYCCUnique (<= 200 chars)
    msgref_re = re.compile(r"^[A-Z]{2}\d{4}[A-Z]{2}[A-Za-z0-9][A-Za-z0-9\-_.:]{0,193}$")
    for dp in msgref_dps:
        val = _v(dp)
        if not val:
            continue
        if len(val) > 200 or not msgref_re.match(val):
            num = 60001 if 60001 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("OECD", f"60001|{dp.xml_path}|{val}"),
                section="GLOBEHeader",
                xml_path=dp.xml_path,
                filer_code=dp.filer_code,
                error_number=num,
                message=f"MessageRefId '{val}' does not match the expected format (CCYYYYCCUniqueID).",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure MessageRefId follows the OECD structure and is <= 200 characters.",
            ))

    # 60002: MessageRefId has already been used in a previously received submission
    current_msgref: Optional[str] = None
    msgref_xpath: Optional[str] = None
    if current_submission and (current_submission.message_ref_id or '').strip():
        current_msgref = (current_submission.message_ref_id or '').strip()
    else:
        for dp in msgref_dps:
            val = _v(dp)
            if val:
                current_msgref = val
                msgref_xpath = dp.xml_path
                break

    if current_msgref and prev_submissions:
        prev_hits = [s for s in prev_submissions if (s.message_ref_id or '').strip() == current_msgref]
        if prev_hits:
            num = 60002 if 60002 in error_map else None
            # Show up to 3 dates for context
            dates = []
            for s in sorted(prev_hits, key=lambda x: x.imported_at or datetime.min, reverse=True):
                if s.imported_at:
                    dates.append(s.imported_at.date().isoformat())
                if len(dates) >= 3:
                    break
            preview = ", ".join(dates)
            more = "" if len(prev_hits) <= 3 else f" (+{len(prev_hits)-3} more)"
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("OECD", f"60002|{current_msgref}"),
                section="GLOBEHeader",
                xml_path=msgref_xpath or "/GLOBE_OECD/GLOBEHeader/MessageRefId",
                error_number=num,
                message=f"MessageRefId '{current_msgref}' has already been used in a previously received submission: {preview}{more}.",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Use a new, unique MessageRefId for each GIR submission.",
            ))

    # Extract header reporting period end date / year (best-effort)
    header_period_end = None
    # Prefer explicit EndDate within GLOBEHeader/ReportingPeriod
    for dp in submission_dps:
        p = (dp.xml_path or "").lower()
        if "globeheader" not in p or "reportingperiod" not in p:
            continue
        if not (p.endswith("enddate") or p.endswith("/enddate") or p.endswith("/end")):
            continue
        if dp.value_date:
            header_period_end = dp.value_date
            break
    # Fallback: any date under GLOBEHeader/ReportingPeriod
    if header_period_end is None:
        for dp in submission_dps:
            p = (dp.xml_path or "").lower()
            if "globeheader" not in p or "reportingperiod" not in p:
                continue
            if dp.value_date:
                header_period_end = dp.value_date
                break

    # 60003: ReportingPeriod year <= current year
    if header_period_end is not None:
        current_year = datetime.utcnow().year
        if header_period_end.year > current_year:
            num = 60003 if 60003 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("OECD", f"60003|{header_period_end.isoformat()}"),
                section="GLOBEHeader",
                error_number=num,
                message=f"ReportingPeriod year {header_period_end.year} is later than the current year {current_year}.",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Set ReportingPeriod to the correct year (<= current year).",
            ))

    # 60004: mixture of new (OECD1) and corrections (OECD2/OECD3) in a message
    doc_types = {(_v(dp)) for dp in all_dps if (dp.xml_path or "").lower().endswith("doctypeindic") and _v(dp)}
    has_new = "OECD1" in doc_types
    has_corr = any(dt in {"OECD2", "OECD3", "OECD12", "OECD13"} for dt in doc_types)
    if has_new and has_corr:
        num = 60004 if 60004 in error_map else None
        issues.append(Issue(
            severity="BLOCKING",
            rule_id=_rid("OECD", f"60004|{sorted(doc_types)}"),
            section="FilingInfo",
            error_number=num,
            message="This message contains a mix of new records (OECD1) and correction/deletion records (OECD2/OECD3).",
            how_to_fix=_oecd_fix_text(error_map, num) if num else "Do not mix new records and corrections in the same message; submit separate messages.",
        ))

    # 60011: DocRefId format (CCYYYYUniqueID)
    docref_re = re.compile(r"^[A-Z]{2}\d{4}[A-Za-z0-9][A-Za-z0-9\-_.:]{0,193}$")
    for dp in all_dps:
        p = (dp.xml_path or "").lower()
        if not p.endswith("docrefid") or p.endswith("corrdocrefid"):
            continue
        val = _v(dp)
        if not val:
            continue
        if len(val) > 200 or not docref_re.match(val):
            num = 60011 if 60011 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("OECD", f"60011|{dp.xml_path}|{val}|{dp.filer_code}|{dp.jurisdiction_code}|{dp.entity_code}|{dp.context_key}"),
                section=dp.xml_path.split("/")[3] if dp.xml_path.startswith("/") and len(dp.xml_path.split("/")) > 3 else "FilingInfo",
                xml_path=dp.xml_path,
                filer_code=dp.filer_code,
                jurisdiction_code=dp.jurisdiction_code,
                entity_code=dp.entity_code,
                context_key=dp.context_key,
                error_number=num,
                message=f"DocRefId '{val}' does not match the expected format (CCYYYYUniqueID).",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure DocRefId begins with a 2-letter country code and 4-digit year.",
            ))

    # 60013: OECD0 (Resend) is only allowed for FilingInfo
    for dp in all_dps:
        p = (dp.xml_path or "").lower()
        if not p.endswith("doctypeindic"):
            continue
        if _v(dp) != "OECD0":
            continue
        if "/filinginfo/" in p:
            continue
        num = 60013 if 60013 in error_map else None
        issues.append(Issue(
            severity="BLOCKING",
            rule_id=_rid("OECD", f"60013|{dp.xml_path}|{dp.filer_code}|{dp.jurisdiction_code}|{dp.entity_code}|{dp.context_key}"),
            section="General",
            xml_path=dp.xml_path,
            filer_code=dp.filer_code,
            jurisdiction_code=dp.jurisdiction_code,
            entity_code=dp.entity_code,
            context_key=dp.context_key,
            error_number=num,
            message="DocTypeIndic 'OECD0' (Resend) may only be used for FilingInfo.",
            how_to_fix=_oecd_fix_text(error_map, num) if num else "Use OECD0 only for FilingInfo; use OECD1/2/3 as appropriate for other records.",
        ))

    # 60016 / 60017: FilingInfo <-> GeneralSection relationship (record-type mapped)
    # These rules reference the DocSpec/DocTypeIndic of the FilingInfo and GeneralSection records.
    record_specs = _build_record_type_specs(config)
    filing_spec = record_specs.get("FilingInfo")
    general_spec = record_specs.get("GeneralSection")

    filing_docref_xp = _find_xpath(config, section="FilingInfo", endswith="/DocSpec/DocRefId")
    filing_docref_xp_lc = _norm_xpath(filing_docref_xp).lower() if filing_docref_xp else ""

    filing_doctype_dps: List[models.DataPoint] = []
    if filing_spec and filing_spec.doctypeindic_xpaths_lc:
        # filer=None here means "include all filers"; we will group by filer_code below.
        filing_doctype_dps = _record_doctype_dps(submission_dps, filing_spec, filer=None)

    filing_dt_by_filer: Dict[str, Set[str]] = {}
    for dp in filing_doctype_dps:
        fk = (dp.filer_code or "").strip() or "GLOBAL"
        filing_dt_by_filer.setdefault(fk, set()).add(_v(dp))

    def _general_present_for(filer_code: Optional[str]) -> bool:
        if not general_spec:
            return False
        return _record_present(submission_dps, general_spec, filer=filer_code)

    def _general_doctypes_for(filer_code: Optional[str]) -> Set[str]:
        if not general_spec:
            return set()
        return {(_v(dp)) for dp in _record_doctype_dps(submission_dps, general_spec, filer=filer_code) if _v(dp)}

    for fk, dts in filing_dt_by_filer.items():
        filer_code = None if fk == "GLOBAL" else fk

        # 60014: If FilingInfo is resent with OECD0, its DocRefId must match the latest previously received FilingInfo DocRefId.
        if "OECD0" in dts:
            current_docref = None
            current_docref_xpath = None
            if filing_docref_xp_lc:
                for dp in submission_dps:
                    if not _filer_matches(dp.filer_code, filer_code):
                        continue
                    if _dp_xpath_lc(dp) != filing_docref_xp_lc:
                        continue
                    v = _v(dp)
                    if v:
                        current_docref = v
                        current_docref_xpath = dp.xml_path
                        break

            latest_prev_docref = None
            if prev_records:
                candidates = []
                for r in prev_records:
                    if (r.record_type or "") != "FilingInfo":
                        continue
                    if filer_code and (r.filer_code not in (None, filer_code)):
                        continue
                    if (r.doc_ref_id or "").strip():
                        candidates.append(r)
                if candidates:
                    latest_rec = max(candidates, key=lambda rr: sub_time.get(rr.submission_id, datetime.min))
                    latest_prev_docref = (latest_rec.doc_ref_id or "").strip()

            if current_docref:
                if (not latest_prev_docref) or (current_docref != latest_prev_docref):
                    num = 60014 if 60014 in error_map else None
                    expected_txt = latest_prev_docref or "<none found>"
                    issues.append(Issue(
                        severity="BLOCKING",
                        rule_id=_rid("OECD", f"60014|{fk}|{current_docref}|{expected_txt}"),
                        section="FilingInfo",
                        xml_path=current_docref_xpath or filing_docref_xp or "/GLOBE_OECD/GLOBEBody/FilingInfo/DocSpec/DocRefId",
                        filer_code=filer_code,
                        error_number=num,
                        message=(
                            "FilingInfo DocTypeIndic is 'OECD0' (Resend) but the FilingInfo DocRefId "
                            f"'{current_docref}' does not match the latest previously received FilingInfo DocRefId '{expected_txt}'."
                        ),
                        how_to_fix=_oecd_fix_text(error_map, num) if num else "Use the same FilingInfo DocRefId as the latest previously received FilingInfo record when submitting a resend (OECD0).",
                    ))


        # 60017: if FilingInfo DocTypeIndic is OECD1 (new filing), GeneralSection must be provided.
        if "OECD1" in dts and not _general_present_for(filer_code):
            num = 60017 if 60017 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("OECD", f"60017|{fk}"),
                section="General",
                filer_code=filer_code,
                error_number=num,
                message="FilingInfo DocTypeIndic is OECD1 (new filing) but GeneralSection is missing.",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Provide GeneralSection when submitting a new GIR (OECD1).",
            ))

        # 60016: if FilingInfo DocTypeIndic is OECD0 (resend), GeneralSection DocTypeIndic must not be OECD1 (new).
        if "OECD0" in dts:
            gen_dts = _general_doctypes_for(filer_code)
            if "OECD1" in gen_dts:
                num = 60016 if 60016 in error_map else None
                issues.append(Issue(
                    severity="BLOCKING",
                    rule_id=_rid("OECD", f"60016|{fk}"),
                    section="General",
                    filer_code=filer_code,
                    error_number=num,
                    message="FilingInfo DocTypeIndic is OECD0 (resend) but GeneralSection DocTypeIndic is OECD1 (new).",
                    how_to_fix=_oecd_fix_text(error_map, num) if num else "Do not include a new GeneralSection (OECD1) when resending FilingInfo (OECD0).",
                ))

    # 60018: at least one RecJurCode must match ReceivingCountry (best-effort)
    receiving_country = None
    for dp in submission_dps:
        p = (dp.xml_path or "").lower()
        if p.endswith("/receivingcountry") or p.endswith("receivingcountry"):
            rc = _v(dp).upper()
            if len(rc) >= 2 and rc[:2].isalpha():
                receiving_country = rc[:2]
                break
    if receiving_country:
        recjur = {(_v(dp).upper()[:2]) for dp in submission_dps if (dp.xml_path or "").endswith("/RecJurCode") and len(_v(dp)) >= 2}
        if receiving_country not in recjur:
            num = 60018 if 60018 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("OECD", f"60018|{receiving_country}|{sorted(recjur)}"),
                section="GLOBEHeader",
                error_number=num,
                message=f"No RecJurCode matches ReceivingCountry '{receiving_country}'.",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure at least one RecJurCode equals ReceivingCountry.",
            ))

    # 60019: Local lodgement roles must not be exchanged (informational in this web tool)
    filing_ce_role = None
    filing_ce_tin = None
    for dp in all_dps:
        p = (dp.xml_path or "").lower()
        if "/filinginfo/" in p and p.endswith("/filingce/role"):
            filing_ce_role = _v(dp)
        if "/filinginfo/" in p and p.endswith("/filingce/tin"):
            filing_ce_tin = _v(dp)
    if filing_ce_role in {"GIR403", "GIR404", "GIR405"}:
        num = 60019 if 60019 in error_map else None
        issues.append(Issue(
            severity="WARNING",
            rule_id=_rid("OECD", f"60019|{filing_ce_role}"),
            section="FilingInfo",
            error_number=num,
            message=f"Filing CE role '{filing_ce_role}' indicates a local lodgement GIR that should not be exchanged.",
            how_to_fix=_oecd_fix_text(error_map, num) if num else "If this is a local lodgement, do not exchange the GIR; file locally as required.",
        ))

    # 60020: FilingInfo period start must not be later than period end
    if filing.period_start and filing.period_end and filing.period_start > filing.period_end:
        num = 60020 if 60020 in error_map else None
        xp_start = _find_xpath(config, section="FilingInfo", endswith="/FilingInfo/Period/Start") or "/GLOBE_OECD/GLOBEBody/FilingInfo/Period/Start"
        xp_end = _find_xpath(config, section="FilingInfo", endswith="/FilingInfo/Period/End") or "/GLOBE_OECD/GLOBEBody/FilingInfo/Period/End"
        issues.append(Issue(
            severity="BLOCKING",
            rule_id=_rid("OECD", f"60020|{filing.period_start.isoformat()}|{filing.period_end.isoformat()}"),
            section="FilingInfo",
            xml_path=xp_start,
            error_number=num,
            message=f"Period start date {filing.period_start.isoformat()} is later than period end date {filing.period_end.isoformat()}.",
            how_to_fix=_oecd_fix_text(error_map, num) if num else f"Ensure Period/Start <= Period/End (currently {xp_start} > {xp_end}).",
        ))

    # 60021: FilingInfo Period/End must not be later than header ReportingPeriod
    if filing.period_end and header_period_end and filing.period_end > header_period_end:
        num = 60021 if 60021 in error_map else None
        xp_end = _find_xpath(config, section="FilingInfo", endswith="/FilingInfo/Period/End") or "/GLOBE_OECD/GLOBEBody/FilingInfo/Period/End"
        issues.append(Issue(
            severity="BLOCKING",
            rule_id=_rid("OECD", f"60021|{filing.period_end.isoformat()}|{header_period_end.isoformat()}"),
            section="FilingInfo",
            xml_path=xp_end,
            error_number=num,
            message=f"FilingInfo Period/End {filing.period_end.isoformat()} is later than header ReportingPeriod {header_period_end.isoformat()}.",
            how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure FilingInfo Period/End is within the header ReportingPeriod.",
        ))

    # 60022: If Filing CE role is GIR401, FilingCE TIN should match a UPE TIN
    if filing_ce_role == "GIR401" and filing_ce_tin:
        upe_tins = {(_v(dp)) for dp in all_dps if "/corporatestructure/upe/" in (dp.xml_path or "").lower() and (dp.xml_path or "").lower().endswith("/tin") and _v(dp)}
        if upe_tins and filing_ce_tin not in upe_tins:
            num = 60022 if 60022 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("OECD", f"60022|{filing_ce_tin}|{sorted(upe_tins)}"),
                section="FilingInfo",
                error_number=num,
                message="When Filing CE role is GIR401, FilingCE TIN should match a TIN provided in the UPE ID.",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure the FilingCE/TIN equals one of the UPE/ID/TIN values.",
            ))

    # 60023: FilingCE ResCountryCode must match TransmittingCountry (best-effort)
    transmitting_country = None
    for dp in submission_dps:
        p = (dp.xml_path or "").lower()
        if p.endswith("/transmittingcountry") or p.endswith("transmittingcountry"):
            tc = _v(dp).upper()
            if len(tc) >= 2 and tc[:2].isalpha():
                transmitting_country = tc[:2]
                break
    filing_ce_res = None
    # Prefer explicit element if present in the submission
    for dp in submission_dps:
        p = (dp.xml_path or "").lower()
        if "/filinginfo/" in p and p.endswith("/filingce/rescountrycode"):
            fc = _v(dp).upper()
            if len(fc) >= 2 and fc[:2].isalpha():
                filing_ce_res = fc[:2]
                break
    # Fallback to filer register jurisdiction_code
    if filing_ce_res is None and filers:
        f0 = next((f for f in filers if (f.jurisdiction_code or "").strip()), None)
        if f0 and (f0.jurisdiction_code or "").strip():
            filing_ce_res = f0.jurisdiction_code.strip().upper()[:2]
    if transmitting_country and filing_ce_res and transmitting_country != filing_ce_res:
        num = 60023 if 60023 in error_map else None
        issues.append(Issue(
            severity="BLOCKING",
            rule_id=_rid("OECD", f"60023|{filing_ce_res}|{transmitting_country}"),
            section="FilingInfo",
            error_number=num,
            message=f"FilingCE ResCountryCode '{filing_ce_res}' does not match TransmittingCountry '{transmitting_country}'.",
            how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure FilingCE ResCountryCode matches the TransmittingCountry in the header.",
        ))

    # 60010: FilingInfo deletion requires deletion of related records (single-file only, record-type mapped)
    deletion_types = {"OECD3", "OECD13"}

    record_specs = _build_record_type_specs(config)
    filing_spec = record_specs.get("FilingInfo")
    related_specs: List[RecordTypeSpec] = [
        record_specs.get("GeneralSection"),
        record_specs.get("Summary"),
        record_specs.get("JurisdictionSection"),
        record_specs.get("UTPRAttribution"),
    ]
    related_specs = [s for s in related_specs if s is not None]

    filing_doctype_dps: List[models.DataPoint] = []
    if filing_spec and filing_spec.doctypeindic_xpaths_lc:
        filing_doctype_dps = _record_doctype_dps(submission_dps, filing_spec, filer=None)

    filing_dt_by_filer: Dict[str, Set[str]] = {}
    for dp in filing_doctype_dps:
        fk = (dp.filer_code or "").strip() or "GLOBAL"
        filing_dt_by_filer.setdefault(fk, set()).add(_v(dp))

    for fk, dts in filing_dt_by_filer.items():
        if not any(dt in deletion_types for dt in dts):
            continue
        filer_code = None if fk == "GLOBAL" else fk

        violations: List[Tuple[str, str]] = []
        for spec in related_specs:
            for dp in _record_doctype_dps(submission_dps, spec, filer=filer_code):
                dt = _v(dp)
                if dt and dt not in deletion_types:
                    violations.append((spec.record_type, dt))

        if violations:
            # Collapse to a compact summary for the message.
            uniq = sorted({f"{rt}:{dt}" for (rt, dt) in violations})
            preview = ", ".join(uniq[:8])
            suffix = "..." if len(uniq) > 8 else ""
            num = 60010 if 60010 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("OECD", f"60010|{fk}|{preview}"),
                section="FilingInfo",
                filer_code=filer_code,
                error_number=num,
                message=(
                    "FilingInfo is marked for deletion, but one or more related records are not deleted "
                    + f"in this message: {preview}{suffix}"
                ),
                how_to_fix=_oecd_fix_text(error_map, num) if num else "If deleting FilingInfo, also delete all related GeneralSection/Summary/JurisdictionSection/UTPRAttribution records.",
            ))



    # -----------------------------
    # Stage 4: additional OECD severe record errors
    #   - 60005 (record type mismatch for correction/deletion)
    #   - 60024 (Summary conditional requiredness)
    #   - 60025–60028 (calculation checks with 4dp rounding + 1% margin)
    # -----------------------------

    # 60005: When DocTypeIndic is OECD2 or OECD3, the record must concern the same sub section
    #        as the CorrDocRefId (cross-submission aware via SubmissionRecord history).
    try:
        current_records: List[models.SubmissionRecord] = []
        if current_submission is not None:
            current_records = (
                db.query(models.SubmissionRecord)
                .filter(models.SubmissionRecord.filing_id == filing_id)
                .filter(models.SubmissionRecord.submission_id == current_submission.id)
                .all()
            )

        # Build a "latest record" lookup by DocRefId across history + current.
        # (We already enforce CorrDocRefId -> latest via 60009; but 60005 uses section identity.)
        docref_to_latest: Dict[str, models.SubmissionRecord] = {}
        for r in (prev_records + current_records):
            docref = (r.doc_ref_id or "").strip()
            if not docref:
                continue
            rt = sub_time.get(r.submission_id, datetime.min)
            if docref not in docref_to_latest:
                docref_to_latest[docref] = r
                continue
            existing = docref_to_latest[docref]
            et = sub_time.get(existing.submission_id, datetime.min)
            if rt > et:
                docref_to_latest[docref] = r

        def _rt_to_section(rt: str) -> str:
            if rt == "GeneralSection":
                return "General"
            if rt == "JurisdictionSection":
                return "Jurisdiction"
            return rt

        corr_xpath_by_rt: Dict[str, str] = {}
        for rt in ["FilingInfo", "GeneralSection", "Summary", "JurisdictionSection", "UTPRAttribution"]:
            sec = _rt_to_section(rt)
            xp = _find_xpath(config, section=sec, endswith="/DocSpec/CorrDocRefId")
            if xp:
                corr_xpath_by_rt[rt] = xp

        correction_types_60005 = {"OECD2", "OECD3"}
        for r in current_records:
            dt = (r.doc_type_indic or "").strip()
            if dt not in correction_types_60005:
                continue
            corr = (r.corr_doc_ref_id or "").strip()
            if not corr:
                continue

            target = docref_to_latest.get(corr)
            if not target:
                continue

            if (target.record_type or "") != (r.record_type or ""):
                num = 60005 if 60005 in error_map else None
                rt_cur = r.record_type or "Unknown"
                rt_prev = target.record_type or "Unknown"
                issues.append(Issue(
                    severity="BLOCKING",
                    rule_id=_rid("OECD", f"60005|{rt_cur}|{rt_prev}|{r.doc_ref_id}|{corr}|{r.filer_code}"),
                    section=rt_cur,
                    xml_path=corr_xpath_by_rt.get(rt_cur),
                    filer_code=r.filer_code,
                    error_number=num,
                    message=(
                        f"DocTypeIndic '{dt}' indicates a correction/deletion for record type '{rt_cur}', "
                        f"but CorrDocRefId '{corr}' refers to a previously received record of type '{rt_prev}'."
                    ),
                    how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure CorrDocRefId references a record in the same subsection (FilingInfo/GeneralSection/Summary/JurisdictionSection/UTPRAttribution).",
                ))
    except Exception:
        # Non-fatal: if submission history isn't available, this check is skipped.
        pass


    # 60024: If Summary contains any of SafeHarbour, ETRRange, SBIE, QDMTTut, GLoBETut,
    #        then JurWithTaxingRights/JurisdictionName must be provided.
    try:
        record_specs2 = record_specs if 'record_specs' in locals() else _build_record_type_specs(config)
        summary_spec = record_specs2.get("Summary") if record_specs2 else None

        trigger_names = ["SafeHarbour", "ETRRange", "SBIE", "QDMTTut", "GLoBETut"]
        trigger_roots_lc: Dict[str, str] = {}
        for nm in trigger_names:
            for e in config.elements:
                if (e.section or "").strip() != "Summary":
                    continue
                if (e.element_name or "").strip() != nm:
                    continue
                if not e.xpath:
                    continue
                trigger_roots_lc[nm] = _norm_xpath(e.xpath).lower()
                break

        req_xpath = None
        for e in config.elements:
            if (e.section or "").strip() != "Summary":
                continue
            if (e.element_name or "").strip() != "JurisdictionName":
                continue
            xp = (e.xpath or "")
            if "JurWithTaxingRights" not in xp:
                continue
            req_xpath = e.xpath
            break
        req_xpath_lc = _norm_xpath(req_xpath).lower() if req_xpath else ""

        if summary_spec and summary_spec.container_xpaths_lc and trigger_roots_lc and req_xpath_lc:
            # Determine which filers have a Summary record (or treat as GLOBAL)
            summary_filers: Set[Optional[str]] = set()
            for dp in submission_dps:
                xp = _dp_xpath_lc(dp)
                if any(cx and xp.startswith(cx) for cx in summary_spec.container_xpaths_lc):
                    summary_filers.add(dp.filer_code or None)

            if not summary_filers:
                summary_filers = {None}

            for filer_code in summary_filers:
                found_triggers: Set[str] = set()
                for dp in submission_dps:
                    if not _filer_matches(dp.filer_code, filer_code):
                        continue
                    if (dp.value_raw or "").strip() == "":
                        continue
                    xp = _dp_xpath_lc(dp)
                    # Trigger if any datapoint exists under the trigger root.
                    for nm, root in trigger_roots_lc.items():
                        if root and xp.startswith(root):
                            found_triggers.add(nm)

                if not found_triggers:
                    continue

                has_req = any(
                    _filer_matches(dp.filer_code, filer_code)
                    and _dp_xpath_lc(dp) == req_xpath_lc
                    and (dp.value_raw or "").strip() != ""
                    for dp in submission_dps
                )

                if not has_req:
                    num = 60024 if 60024 in error_map else None
                    trig_preview = ", ".join(sorted(found_triggers))
                    issues.append(Issue(
                        severity="BLOCKING",
                        rule_id=_rid("OECD", f"60024|{filer_code or 'GLOBAL'}|{trig_preview}"),
                        section="Summary",
                        xml_path=req_xpath,
                        filer_code=filer_code,
                        error_number=num,
                        message=(
                            f"Summary contains {trig_preview}, so JurWithTaxingRights/JurisdictionName must be provided, "
                            "but none was found."
                        ),
                        how_to_fix=_oecd_fix_text(error_map, num) if num else "Provide Summary/JurWithTaxingRights/JurisdictionName when any SafeHarbour/ETRRange/SBIE/QDMTTut/GLoBETut elements are present.",
                    ))
    except Exception:
        pass


    # 60025–60028: calculation validations
    # Note: These validations only run when the target element exists in the submission.
    try:
        def _pick_xpath(*, section: str, element_name: str, must_contain: Optional[str] = None, must_end: Optional[str] = None, must_not_contain: Optional[str] = None) -> Optional[str]:
            sec = (section or "").strip()
            en = (element_name or "").strip().lower()
            for e in config.elements:
                if sec and (e.section or "").strip() != sec:
                    continue
                if (e.element_name or "").strip().lower() != en:
                    continue
                xp = (e.xpath or "").strip()
                if not xp:
                    continue
                xp_n = _norm_xpath(xp)
                xp_lc = xp_n.lower()
                if must_contain and must_contain.lower() not in xp_lc:
                    continue
                if must_end and not xp_lc.endswith(must_end.lower()):
                    continue
                if must_not_contain and must_not_contain.lower() in xp_lc:
                    continue
                return xp_n
            return None

        def _first_dec(dps: List[models.DataPoint]) -> Decimal:
            """Return first parseable decimal from a list, else 0."""
            for ddp in dps:
                v = _dp_decimal(ddp)
                if v is not None:
                    return v
            return Decimal("0")

        # --- 60025 ---
        xp_etr = _pick_xpath(section="Jurisdiction", element_name="ETRRate", must_contain="/overallcomputation/", must_end="/etrrate", must_not_contain="/additionaltopuptax/")
        xp_adj = _pick_xpath(section="Jurisdiction", element_name="AdjustedCoveredTax", must_contain="/overallcomputation/", must_end="/adjustedcoveredtax", must_not_contain="/additionaltopuptax/")
        xp_net = _pick_xpath(section="Jurisdiction", element_name="NetGlobeIncome", must_contain="/overallcomputation/", must_end="/netglobeincome", must_not_contain="/additionaltopuptax/")

        if xp_etr and xp_net:
            xp_etr_lc = _norm_xpath(xp_etr).lower()
            xp_adj_lc = _norm_xpath(xp_adj).lower() if xp_adj else ""
            xp_net_lc = _norm_xpath(xp_net).lower()

            # Group by filer + jurisdiction (+ context_key) because the values are jurisdiction-scoped.
            groups: Dict[Tuple[Optional[str], Optional[str], Optional[str]], Dict[str, models.DataPoint]] = {}
            for dp in submission_dps:
                if not dp.jurisdiction_code:
                    continue
                xp = _dp_xpath_lc(dp)
                if xp not in {xp_etr_lc, xp_adj_lc, xp_net_lc}:
                    continue
                gk = (dp.filer_code or None, dp.jurisdiction_code, dp.context_key or None)
                d = groups.setdefault(gk, {})
                if xp == xp_etr_lc and "etr" not in d:
                    d["etr"] = dp
                elif xp == xp_adj_lc and "adj" not in d:
                    d["adj"] = dp
                elif xp == xp_net_lc and "net" not in d:
                    d["net"] = dp

            for (filer_code, juris, ctx), d in groups.items():
                dp_etr = d.get("etr")
                dp_net = d.get("net")
                if dp_etr is None or dp_net is None:
                    continue

                etr_val = _dp_decimal(dp_etr)
                net_val = _dp_decimal(dp_net)
                if etr_val is None or net_val is None:
                    continue
                if net_val <= 0:
                    continue  # rule does not apply

                adj_val = Decimal("0")
                if d.get("adj") is not None:
                    v = _dp_decimal(d["adj"])
                    if v is not None:
                        adj_val = v

                expected = (adj_val / net_val) if net_val != 0 else Decimal("0")
                if not _calc_equal(expected, etr_val):
                    num = 60025 if 60025 in error_map else None
                    issues.append(Issue(
                        severity="BLOCKING",
                        rule_id=_rid("OECD", f"60025|{filer_code}|{juris}|{ctx}|{etr_val}|{adj_val}|{net_val}"),
                        section="Jurisdiction",
                        xml_path=xp_etr,
                        filer_code=filer_code,
                        jurisdiction_code=juris,
                        context_key=ctx,
                        error_number=num,
                        message=(
                            f"ETRRate={etr_val} but expected approximately {_round4(expected)} (AdjustedCoveredTax={adj_val} / NetGlobeIncome={net_val})."
                        ),
                        how_to_fix=_oecd_fix_text(error_map, num) if num else "Recalculate ETRRate as AdjustedCoveredTax/Total divided by NetGlobeIncome/Total (4dp, allow 1% margin).",
                    ))

        # --- 60026 ---
        xp_topup = _pick_xpath(section="Jurisdiction", element_name="TopUpTax", must_contain="/overallcomputation/", must_end="/topuptax", must_not_contain="/additionaltopuptax/")
        xp_tup_pct = _pick_xpath(section="Jurisdiction", element_name="TopUpTaxPercentage", must_contain="/overallcomputation/", must_end="/topuptaxpercentage", must_not_contain="/additionaltopuptax/")
        xp_excess = _pick_xpath(section="Jurisdiction", element_name="ExcessProfits", must_contain="/overallcomputation/", must_end="/excessprofits", must_not_contain="/additionaltopuptax/")
        xp_add_non = _pick_xpath(section="Jurisdiction", element_name="AdditionalTopUpTax", must_contain="/overallcomputation/additionaltopuptax/nonart4.1.5/", must_end="/additionaltopuptax")
        xp_add_art = _pick_xpath(section="Jurisdiction", element_name="AdditionalTopUpTax", must_contain="/overallcomputation/additionaltopuptax/art4.1.5/", must_end="/additionaltopuptax")
        xp_qdmt_amt = _pick_xpath(section="Jurisdiction", element_name="Amount", must_contain="/overallcomputation/qdmt", must_end="/amount")

        if xp_topup:
            x_topup_lc = _norm_xpath(xp_topup).lower()
            x_pct_lc = _norm_xpath(xp_tup_pct).lower() if xp_tup_pct else ""
            x_exc_lc = _norm_xpath(xp_excess).lower() if xp_excess else ""
            x_non_lc = _norm_xpath(xp_add_non).lower() if xp_add_non else ""
            x_art_lc = _norm_xpath(xp_add_art).lower() if xp_add_art else ""
            x_qdmt_lc = _norm_xpath(xp_qdmt_amt).lower() if xp_qdmt_amt else ""

            groups2: Dict[Tuple[Optional[str], Optional[str], Optional[str]], Dict[str, List[models.DataPoint]]] = {}
            for dp in submission_dps:
                if not dp.jurisdiction_code:
                    continue
                xp = _dp_xpath_lc(dp)
                if xp not in {x_topup_lc, x_pct_lc, x_exc_lc, x_non_lc, x_art_lc, x_qdmt_lc}:
                    continue
                gk = (dp.filer_code or None, dp.jurisdiction_code, dp.context_key or None)
                d = groups2.setdefault(gk, {})
                if xp == x_topup_lc:
                    d.setdefault("topup", []).append(dp)
                elif xp == x_pct_lc:
                    d.setdefault("pct", []).append(dp)
                elif xp == x_exc_lc:
                    d.setdefault("excess", []).append(dp)
                elif xp == x_non_lc:
                    d.setdefault("non", []).append(dp)
                elif xp == x_art_lc:
                    d.setdefault("art", []).append(dp)
                elif xp == x_qdmt_lc:
                    d.setdefault("qdmt", []).append(dp)


            for (filer_code, juris, ctx), d in groups2.items():
                if "topup" not in d:
                    continue
                topup_val = _first_dec(d.get("topup", []))
                pct_val = _first_dec(d.get("pct", []))
                excess_val = _first_dec(d.get("excess", []))
                non_val = _first_dec(d.get("non", []))
                art_val = _first_dec(d.get("art", []))
                qdmt_val = _first_dec(d.get("qdmt", []))

                expected = (pct_val * excess_val) + (non_val + art_val) - qdmt_val
                if not _calc_equal(expected, topup_val):
                    num = 60026 if 60026 in error_map else None
                    issues.append(Issue(
                        severity="BLOCKING",
                        rule_id=_rid("OECD", f"60026|{filer_code}|{juris}|{ctx}|{topup_val}|{pct_val}|{excess_val}|{non_val}|{art_val}|{qdmt_val}"),
                        section="Jurisdiction",
                        xml_path=xp_topup,
                        filer_code=filer_code,
                        jurisdiction_code=juris,
                        context_key=ctx,
                        error_number=num,
                        message=(
                            f"TopUpTax={topup_val} but expected approximately {_round4(expected)} "
                            f"(TopUpTaxPercentage={pct_val} * ExcessProfits={excess_val} + AdditionalTopUpTax={non_val + art_val} - QDMTT/Amount={qdmt_val})."
                        ),
                        how_to_fix=_oecd_fix_text(error_map, num) if num else "Recalculate TopUpTax per OECD formula (4dp, allow 1% margin).",
                    ))

        # --- 60027 ---
        xp_iir_topup = _pick_xpath(section="Jurisdiction", element_name="TopUpTax", must_contain="/iir/parententity/", must_end="/topuptax")
        xp_iir_share = _pick_xpath(section="Jurisdiction", element_name="TopUpTaxShare", must_contain="/iir/parententity/", must_end="/topuptaxshare")
        xp_iir_off = _pick_xpath(section="Jurisdiction", element_name="IIROffSet", must_contain="/iir/parententity/", must_end="/iiroffset")

        if xp_iir_topup:
            x_it_lc = _norm_xpath(xp_iir_topup).lower()
            x_is_lc = _norm_xpath(xp_iir_share).lower() if xp_iir_share else ""
            x_io_lc = _norm_xpath(xp_iir_off).lower() if xp_iir_off else ""

            groups3: Dict[Tuple[Optional[str], Optional[str], Optional[str]], Dict[str, List[models.DataPoint]]] = {}
            for dp in submission_dps:
                if not dp.jurisdiction_code:
                    continue
                xp = _dp_xpath_lc(dp)
                if xp not in {x_it_lc, x_is_lc, x_io_lc}:
                    continue
                gk = (dp.filer_code or None, dp.jurisdiction_code, dp.context_key or None)
                d = groups3.setdefault(gk, {})
                if xp == x_it_lc:
                    d.setdefault("topup", []).append(dp)
                elif xp == x_is_lc:
                    d.setdefault("share", []).append(dp)
                elif xp == x_io_lc:
                    d.setdefault("off", []).append(dp)

            for (filer_code, juris, ctx), d in groups3.items():
                if "topup" not in d:
                    continue
                topup_val = _first_dec(d.get("topup", []))
                share_val = _first_dec(d.get("share", []))
                off_val = _first_dec(d.get("off", []))

                expected = share_val - off_val
                if not _calc_equal(expected, topup_val):
                    num = 60027 if 60027 in error_map else None
                    issues.append(Issue(
                        severity="BLOCKING",
                        rule_id=_rid("OECD", f"60027|{filer_code}|{juris}|{ctx}|{topup_val}|{share_val}|{off_val}"),
                        section="Jurisdiction",
                        xml_path=xp_iir_topup,
                        filer_code=filer_code,
                        jurisdiction_code=juris,
                        context_key=ctx,
                        error_number=num,
                        message=(
                            f"IIR/ParentEntity/TopUpTax={topup_val} but expected approximately {_round4(expected)} "
                            f"(TopUpTaxShare={share_val} - IIROffSet={off_val})."
                        ),
                        how_to_fix=_oecd_fix_text(error_map, num) if num else "Recalculate IIR/ParentEntity/TopUpTax as TopUpTaxShare minus IIROffSet (4dp, allow 1% margin).",
                    ))

        # --- 60028 ---
        xp_af_total = _pick_xpath(section="Jurisdiction", element_name="Total", must_contain="/cecomputation/adjustedfanil/", must_end="/total")
        xp_af_fanil = _pick_xpath(section="Jurisdiction", element_name="FANIL", must_contain="/cecomputation/adjustedfanil/", must_end="/fanil")
        xp_af_add = _pick_xpath(section="Jurisdiction", element_name="Additions", must_contain="/cecomputation/adjustedfanil/adjustment/mainentitypeandfte/", must_end="/additions")
        xp_af_red = _pick_xpath(section="Jurisdiction", element_name="Reductions", must_contain="/cecomputation/adjustedfanil/adjustment/mainentitypeandfte/", must_end="/reductions")

        if xp_af_total and xp_af_fanil:
            x_tot_lc = _norm_xpath(xp_af_total).lower()
            x_fan_lc = _norm_xpath(xp_af_fanil).lower()
            x_add_lc = _norm_xpath(xp_af_add).lower() if xp_af_add else ""
            x_red_lc = _norm_xpath(xp_af_red).lower() if xp_af_red else ""

            # CEComputation is repeatable and also contains nested repeatable containers
            # (e.g., multiple MainEntityPEandFTE entries). The XML importer preserves these by
            # appending repeat-instance markers to context_key (base|MainEntityPEandFTE:2).
            # For 60028 we need to sum Additions/Reductions at the CEComputation row level, so
            # we group by the *base* context_key segment (before the first '|').
            def _ctx_base(v: Optional[str]) -> Optional[str]:
                if not v:
                    return None
                return str(v).split("|", 1)[0]

            groups4: Dict[Tuple[Optional[str], Optional[str], Optional[str], Optional[str]], Dict[str, List[models.DataPoint]]] = {}
            for dp in submission_dps:
                xp = _dp_xpath_lc(dp)
                if xp not in {x_tot_lc, x_fan_lc, x_add_lc, x_red_lc}:
                    continue
                gk = (dp.filer_code or None, dp.jurisdiction_code or None, dp.entity_code or None, _ctx_base(dp.context_key))
                d = groups4.setdefault(gk, {})
                if xp == x_tot_lc:
                    d.setdefault("total", []).append(dp)
                elif xp == x_fan_lc:
                    d.setdefault("fanil", []).append(dp)
                elif xp == x_add_lc:
                    d.setdefault("add", []).append(dp)
                elif xp == x_red_lc:
                    d.setdefault("red", []).append(dp)

            for (filer_code, juris, ent, ctx), d in groups4.items():
                if "total" not in d or "fanil" not in d:
                    continue
                total_val = _first_dec(d.get("total", []))
                fanil_val = _first_dec(d.get("fanil", []))
                add_sum = sum([_first_dec([dp]) for dp in d.get("add", [])], Decimal("0"))
                red_sum = sum([_first_dec([dp]) for dp in d.get("red", [])], Decimal("0"))

                expected = fanil_val + add_sum - red_sum
                if not _calc_equal(expected, total_val):
                    num = 60028 if 60028 in error_map else None
                    issues.append(Issue(
                        severity="BLOCKING",
                        rule_id=_rid("OECD", f"60028|{filer_code}|{juris}|{ent}|{ctx}|{total_val}|{fanil_val}|{add_sum}|{red_sum}"),
                        section="Jurisdiction",
                        xml_path=xp_af_total,
                        filer_code=filer_code,
                        jurisdiction_code=juris,
                        entity_code=ent,
                        context_key=ctx,
                        error_number=num,
                        message=(
                            f"AdjustedFANIL/Total={total_val} but expected approximately {_round4(expected)} "
                            f"(FANIL={fanil_val} + Additions={add_sum} - Reductions={red_sum})."
                        ),
                        how_to_fix=_oecd_fix_text(error_map, num) if num else "Recalculate AdjustedFANIL/Total per OECD formula (4dp, allow 1% margin).",
                    ))

    except Exception:
        # Calculations are best-effort; do not fail the overall run if inputs are missing/invalid.
        pass

    # -----------------------------
    # Stage 4.7: Attribute-driven OECD record errors (TIN) — 70001–70007
    # -----------------------------
    #
    # The OECD Status Message guidance defines several record errors that are specifically
    # driven by XML attributes on the TIN type (issuedBy / unknown / TypeOfTIN).
    # See Status Message User Guide Part 4 (70001–70007).
    #
    # We only run these checks when the latest submission is XML (or when attribute mode is forced on),
    # to avoid false positives for XLSX/CSV uploads which generally cannot represent XML attributes.
    try:
        tin_rules_enabled = False
        if arm != "off":
            if arm == "on":
                tin_rules_enabled = True
            elif arm == "auto":
                tin_rules_enabled = bool(
                    current_submission
                    and (current_submission.source_type or "").strip().lower() == "xml"
                )

        if tin_rules_enabled:
            filer_juris: Dict[str, str] = {
                (f.filer_code or "").strip(): (f.jurisdiction_code or "").strip()
                for f in filers
                if (f.filer_code or "").strip()
            }
            entity_juris: Dict[str, str] = {
                (e.entity_code or "").strip(): (e.jurisdiction_code or "").strip()
                for e in entity_rows
                if (e.entity_code or "").strip()
            }

            # 70006 exception needs CE/ID/GloBEStatus for the same entity (GIR316 / GIR318).
            ce_globe_status_xpath = _find_xpath(
                config,
                section="General",
                endswith="/CorporateStructure/CE/ID/GloBEStatus",
            ) or _find_xpath(config, endswith="/CorporateStructure/CE/ID/GloBEStatus")
            ce_globe_status_xpath_lc = _norm_xpath(ce_globe_status_xpath).lower() if ce_globe_status_xpath else ""

            globe_status_by_entity: Dict[str, str] = {}
            if ce_globe_status_xpath_lc:
                for dp in submission_dps:
                    ec = (dp.entity_code or "").strip()
                    if not ec:
                        continue
                    if _dp_xpath_lc(dp) != ce_globe_status_xpath_lc:
                        continue
                    v = (dp.value_raw or "").strip()
                    if v:
                        globe_status_by_entity[ec] = v

            # Group all TIN datapoints by their base element path + scope keys.
            # Base path example: /.../ID/TIN
            # Attribute path examples: /.../ID/TIN/@TypeOfTIN, /.../ID/TIN/@issuedBy, /.../ID/TIN/@unknown
            def _base_tin_path(xp: Optional[str]) -> Optional[str]:
                if not xp:
                    return None
                nx = _norm_xpath(xp)
                if "/@" in nx:
                    base = nx.split("/@", 1)[0]
                else:
                    base = nx
                return base if base.lower().endswith("/tin") else None

            groups: Dict[
                Tuple[Optional[str], Optional[str], Optional[str], Optional[str], str],
                Dict[str, Optional[str]],
            ] = {}

            for dp in submission_dps:
                base = _base_tin_path(dp.xml_path)
                if not base:
                    continue

                key = (dp.filer_code or None, dp.jurisdiction_code or None, dp.entity_code or None, dp.context_key or None, base)
                g = groups.get(key)
                if g is None:
                    g = {
                        "base": base,
                        "tin": None,
                        "typeoftin": None,
                        "issuedby": None,
                        "unknown": None,
                        "filer_code": dp.filer_code,
                        "jurisdiction_code": dp.jurisdiction_code,
                        "entity_code": dp.entity_code,
                        "context_key": dp.context_key,
                    }
                    groups[key] = g

                nx = _norm_xpath(dp.xml_path or "")
                val = (dp.value_raw or "").strip()

                if nx == base:
                    if val:
                        g["tin"] = val
                    continue

                # Attribute
                if "/@" not in nx:
                    continue
                attr = nx.split("/@", 1)[1].strip()
                if not attr:
                    continue
                attr_lc = attr.lower()

                if val == "":
                    # treat empty attribute as absent for these rules
                    continue

                if attr_lc == "typeoftin":
                    g["typeoftin"] = val
                elif attr_lc == "issuedby":
                    g["issuedby"] = val
                elif attr_lc == "unknown":
                    g["unknown"] = val

            # Common helpers
            def _issue(
                *,
                number: int,
                base: str,
                xml_path: str,
                message: str,
                filer_code: Optional[str],
                jurisdiction_code: Optional[str],
                entity_code: Optional[str],
                context_key: Optional[str],
            ) -> None:
                num = number if number in error_map else None
                issues.append(Issue(
                    severity="BLOCKING",
                    rule_id=_rid("OECD", f"{number}|{xml_path}|{filer_code}|{jurisdiction_code}|{entity_code}|{context_key}|{message}"),
                    section="General",
                    xml_path=xml_path,
                    filer_code=filer_code,
                    jurisdiction_code=jurisdiction_code,
                    entity_code=entity_code,
                    context_key=context_key,
                    error_number=num,
                    message=message,
                    how_to_fix=_oecd_fix_text(error_map, num) if num else None,
                ))

            # -----------------------------
            # Stage 4.8: OECD 70025 (OwnershipType GIR805/GIR806 => NOTIN + TypeOfTIN GIR3004)
            # -----------------------------
            # The OECD catalogue includes an attribute-driven rule outside the core TIN block.
            # When OwnershipType indicates an ownership type that requires NOTIN (GIR805/GIR806),
            # the associated ownership TIN must use the NOTIN convention (TypeOfTIN=GIR3004 and value NOTIN).
            #
            # We scope within the same (filer, jurisdiction, entity, context_key) so repeated OwnershipChange
            # list entries (IDX scopes) are validated independently.
            try:
                own_type_xps = [
                    _find_xpath(config, endswith="/CorporateStructure/CE/Ownership/OwnershipType"),
                    _find_xpath(config, endswith="/CorporateStructure/CE/OwnershipChange/PreOwnership/OwnershipType"),
                ]
                own_type_xps_lc = {
                    _norm_xpath(xp).lower() for xp in own_type_xps if (xp or "").strip()
                }

                # Build a lookup of datapoints by scope key + normalized xpath.
                scope_idx: Dict[
                    Tuple[Optional[str], Optional[str], Optional[str], Optional[str]],
                    Dict[str, List[models.DataPoint]],
                ] = {}
                for dp in submission_dps:
                    sk = (dp.filer_code or None, dp.jurisdiction_code or None, dp.entity_code or None, dp.context_key or None)
                    scope_idx.setdefault(sk, {}).setdefault(_dp_xpath_lc(dp), []).append(dp)

                def _first_val(dps: List[models.DataPoint]) -> str:
                    if not dps:
                        return ""
                    return (dps[0].value_raw or "").strip()

                for dp in submission_dps:
                    xp_lc = _dp_xpath_lc(dp)
                    if own_type_xps_lc and xp_lc not in own_type_xps_lc:
                        continue
                    own_val = (dp.value_raw or "").strip()
                    if own_val not in {"GIR805", "GIR806"}:
                        continue

                    parent = _norm_xpath(dp.xml_path or "")
                    if not parent:
                        continue
                    parent = parent.rsplit("/", 1)[0]
                    tin_base = f"{parent}/TIN"
                    tin_base_lc = tin_base.lower()
                    tin_type_lc = f"{tin_base}/@typeoftin".lower()

                    sk = (dp.filer_code or None, dp.jurisdiction_code or None, dp.entity_code or None, dp.context_key or None)
                    m = scope_idx.get(sk, {})
                    tin_val = _first_val(m.get(tin_base_lc, []))
                    typ_val = _first_val(m.get(tin_type_lc, []))

                    ok = (tin_val.upper() == "NOTIN") and (typ_val == "GIR3004")
                    if not ok:
                        _issue(
                            number=70025,
                            base=tin_base,
                            xml_path=_norm_xpath(dp.xml_path or "") or dp.xml_path or tin_base,
                            message=(
                                f"OwnershipType is '{own_val}', so the associated ownership TIN must be 'NOTIN' "
                                "with TypeOfTIN='GIR3004'. "
                                f"Observed TIN='{tin_val or '∅'}', TypeOfTIN='{typ_val or '∅'}'."
                            ),
                            filer_code=dp.filer_code,
                            jurisdiction_code=dp.jurisdiction_code,
                            entity_code=dp.entity_code,
                            context_key=dp.context_key,
                        )
            except Exception:
                pass

            # 70006 target path list (normalized, no namespaces)
            t70006_suffixes = [
                "/GLOBE_OECD/GLOBEBody/GeneralSection/CorporateStructure/UPE/ExcludedUPE/ID/TIN",
                "/GLOBE_OECD/GLOBEBody/GeneralSection/CorporateStructure/UPE/OtherUPE/ID/TIN",
                "/GLOBE_OECD/GLOBEBody/GeneralSection/CorporateStructure/CE/ID/TIN",
                "/GLOBE_OECD/GLOBEBody/GeneralSection/CorporateStructure/CE/QIIR/Exception/TIN",
                "/GLOBE_OECD/GLOBEBody/JurisdictionSection/GLoBETax/ETR/ETRStatus/ETRComputation/CEComputation/Elections/AggregatedReporting/TaxConsolGroupTIN",
            ]
            t70006_suffixes_lc = [s.lower() for s in t70006_suffixes]

            # 70007 regex (designated reference for TypeOfTIN GIR3003)
            # Format: P2JJYYYYMMDDCCCXXX
            # - P2 constant
            # - JJ ISO country code (2 letters)
            # - YYYYMMDD date
            # - CCC 3-letter group ref
            # - XXX 3-digit unique number
            t70007_re = re.compile(r"^P2[A-Z]{2}\d{8}[A-Z]{3}\d{3}$")

            for g in groups.values():
                base = (g.get("base") or "").strip()
                tin_val = (g.get("tin") or "").strip()
                typ = (g.get("typeoftin") or "").strip()
                issued = (g.get("issuedby") or "").strip()
                unk = _parse_bool(g.get("unknown"))
                unk_true = (unk is True)

                fc = g.get("filer_code")
                jc = g.get("jurisdiction_code")
                ec = g.get("entity_code")
                ck = g.get("context_key")

                # 70005: Attributes issuedBy and TypeOfTIN must always be present,
                # except issuedBy is not required when TypeOfTIN is GIR3003 or GIR3004.
                if not typ:
                    _issue(
                        number=70005,
                        base=base,
                        xml_path=f"{base}/@TypeOfTIN",
                        message="TIN is missing required attribute TypeOfTIN.",
                        filer_code=fc,
                        jurisdiction_code=jc,
                        entity_code=ec,
                        context_key=ck,
                    )
                    # Without TypeOfTIN we cannot apply dependent rules reliably.
                    continue

                if (typ not in {"GIR3003", "GIR3004"}) and (not issued):
                    _issue(
                        number=70005,
                        base=base,
                        xml_path=f"{base}/@issuedBy",
                        message=f"TIN is missing required attribute issuedBy for TypeOfTIN='{typ}'.",
                        filer_code=fc,
                        jurisdiction_code=jc,
                        entity_code=ec,
                        context_key=ck,
                    )

                # 70001/70002/70003: NOTIN / GIR3004 / Unknown / issuedBy consistency
                if typ == "GIR3004":
                    ok = (tin_val.upper() == "NOTIN") and unk_true and (not issued)
                    if not ok:
                        _issue(
                            number=70001,
                            base=base,
                            xml_path=f"{base}/@TypeOfTIN",
                            message=(
                                "TypeOfTIN is GIR3004, so TIN must be 'NOTIN', unknown must be TRUE, "
                                "and issuedBy must NOT be provided."
                            ),
                            filer_code=fc,
                            jurisdiction_code=jc,
                            entity_code=ec,
                            context_key=ck,
                        )
                elif tin_val.upper() == "NOTIN":
                    ok = (typ == "GIR3004") and unk_true and (not issued)
                    if not ok:
                        _issue(
                            number=70002,
                            base=base,
                            xml_path=base,
                            message=(
                                "TIN value is 'NOTIN', so TypeOfTIN must be GIR3004, unknown must be TRUE, "
                                "and issuedBy must NOT be provided."
                            ),
                            filer_code=fc,
                            jurisdiction_code=jc,
                            entity_code=ec,
                            context_key=ck,
                        )
                elif unk_true:
                    ok = (tin_val.upper() == "NOTIN") and (typ == "GIR3004") and (not issued)
                    if not ok:
                        _issue(
                            number=70003,
                            base=base,
                            xml_path=f"{base}/@unknown",
                            message=(
                                "TIN is flagged unknown=TRUE, so TIN must be 'NOTIN', TypeOfTIN must be GIR3004, "
                                "and issuedBy must NOT be provided."
                            ),
                            filer_code=fc,
                            jurisdiction_code=jc,
                            entity_code=ec,
                            context_key=ck,
                        )


                # 70004: Where issuedBy is the local jurisdiction, validate TIN format for that jurisdiction.
                #
                # OECD notes this should only be applied by the issuing jurisdiction unless a TIN validation tool is available.
                # To avoid false positives, this validator ONLY applies 70004 when you configure BOTH:
                #   - LOCAL_JURISDICTION_CODE=<JJ>   (2-letter ISO code)
                #   - TIN_VALIDATION_REGEX_MAP_JSON='{"JJ":"<regex>", "AA":"<regex>", ...}'
                #
                # Example:
                #   LOCAL_JURISDICTION_CODE=GB
                #   TIN_VALIDATION_REGEX_MAP_JSON={"GB":"^[A-Z0-9]{1,20}$"}
                #
                # If not configured, 70004 is skipped.
                try:
                    import os as _os
                    import json as _json
                    _local = (_os.getenv("LOCAL_JURISDICTION_CODE") or "").strip().upper()
                    _rx_map_raw = (_os.getenv("TIN_VALIDATION_REGEX_MAP_JSON") or "").strip()
                    _rx_map = {}
                    if _local and _rx_map_raw:
                        try:
                            _rx_map = _json.loads(_rx_map_raw)
                        except Exception:
                            _rx_map = {}
                    if _local and _rx_map and issued and issued.strip().upper() == _local:
                        # Skip cases already handled by NOTIN/unknown logic
                        if typ not in {"GIR3004"} and (not unk_true) and tin_val:
                            pat = (_rx_map.get(_local) or "").strip()
                            if pat:
                                try:
                                    _re = re.compile(pat)
                                    if not _re.match(tin_val.strip()):
                                        _issue(
                                            number=70004,
                                            base=base,
                                            xml_path=f"{base}/@issuedBy",
                                            message=(
                                                f"TIN issuedBy='{_local}' does not match the configured local-jurisdiction "
                                                "TIN validation pattern."
                                            ),
                                            filer_code=fc,
                                            jurisdiction_code=jc,
                                            entity_code=ec,
                                            context_key=ck,
                                        )
                                except Exception:
                                    # Bad regex => skip validation
                                    pass
                except Exception:
                    pass

                # 70006: Certain key TINs must not use TypeOfTIN GIR3004 and must not be Unknown
                base_lc = _norm_xpath(base).lower()
                if any(base_lc.endswith(suf) for suf in t70006_suffixes_lc):
                    # Exception for CE/ID/TIN when GloBEStatus is GIR316 or GIR318
                    skip = False
                    if base_lc.endswith("/generalsection/corporatestructure/ce/id/tin"):
                        st = globe_status_by_entity.get((ec or "").strip(), "")
                        if st in {"GIR316", "GIR318"}:
                            skip = True
                    if not skip and (typ == "GIR3004" or unk_true):
                        _issue(
                            number=70006,
                            base=base,
                            xml_path=f"{base}/@TypeOfTIN",
                            message="This TIN must not use TypeOfTIN GIR3004 and must not be flagged unknown.",
                            filer_code=fc,
                            jurisdiction_code=jc,
                            entity_code=ec,
                            context_key=ck,
                        )

                # 70007: If TypeOfTIN is GIR3003, validate designated reference format
                if typ == "GIR3003" and tin_val:
                    tin_up = tin_val.strip().upper()
                    if not t70007_re.match(tin_up):
                        _issue(
                            number=70007,
                            base=base,
                            xml_path=base,
                            message=(
                                "TypeOfTIN is GIR3003, so TIN must follow the designated reference format "
                                "P2JJYYYYMMDDCCCXXX (e.g., P2GB20250101ABC001)."
                            ),
                            filer_code=fc,
                            jurisdiction_code=jc,
                            entity_code=ec,
                            context_key=ck,
                        )
                    else:
                        # Extra check: JJ should match entity/filer jurisdiction when we can infer it.
                        jj = tin_up[2:4]
                        expected = ""
                        if ec and (ec or "").strip() in entity_juris:
                            expected = (entity_juris.get((ec or "").strip()) or "").strip().upper()
                        elif fc and (fc or "").strip() in filer_juris:
                            expected = (filer_juris.get((fc or "").strip()) or "").strip().upper()
                        elif jc:
                            expected = (jc or "").strip().upper()
                        if expected and jj and expected != jj:
                            _issue(
                                number=70007,
                                base=base,
                                xml_path=base,
                                message=(
                                    f"TypeOfTIN is GIR3003 and TIN reference begins with JJ='{jj}', but the "
                                    f"inferred jurisdiction is '{expected}'. JJ should match the jurisdiction of location."
                                ),
                                filer_code=fc,
                                jurisdiction_code=jc,
                                entity_code=ec,
                                context_key=ck,
                            )
                        # Validate date chunk is a real date (YYYYMMDD)
                        try:
                            _ = datetime.strptime(tin_up[4:12], "%Y%m%d")
                        except Exception:
                            _issue(
                                number=70007,
                                base=base,
                                xml_path=base,
                                message=(
                                    f"TypeOfTIN is GIR3003, but the YYYYMMDD segment '{tin_up[4:12]}' is not a valid date."
                                ),
                                filer_code=fc,
                                jurisdiction_code=jc,
                                entity_code=ec,
                                context_key=ck,
                            )
    except Exception:
        # Non-fatal: attribute-driven rules are best-effort.
        pass


    # -----------------------------
    # Stage 7: OECD CorporateStructure / Ownership / UTPR record errors — 70008–70035
    # -----------------------------
    #
    # These are additional OECD “Other record errors” that are not pure XSD constraints.
    # They primarily relate to:
    #   - CorporateStructure (UPE/CE status consistency, ownership rules)
    #   - OwnershipChange date window checks
    #   - QIIR / POPE-IPE exception flags
    #   - UTPRAttribution RecJurCode validation
    try:
        # Helper for consistent OECD issue emission.
        def _oecd_issue(
            *,
            number: int,
            severity: str,
            xml_path: Optional[str],
            message: str,
            filer_code: Optional[str] = None,
            jurisdiction_code: Optional[str] = None,
            entity_code: Optional[str] = None,
            context_key: Optional[str] = None,
        ) -> None:
            num = number if number in error_map else None
            issues.append(Issue(
                severity=severity,
                rule_id=_rid(
                    "OECD",
                    f"{number}|{xml_path}|{filer_code}|{jurisdiction_code}|{entity_code}|{context_key}|{message}",
                ),
                section="General",
                xml_path=xml_path,
                filer_code=filer_code,
                jurisdiction_code=jurisdiction_code,
                entity_code=entity_code,
                context_key=context_key,
                error_number=num,
                message=message,
                how_to_fix=_oecd_fix_text(error_map, num) if num else None,
            ))

        def _truthy(v: str) -> bool:
            vv = (v or "").strip().lower()
            return vv in {"1", "true", "t", "yes", "y"}

        # --- Locate xpaths used by these rules ---
        xp_utpr_rec = _find_xpath(config, endswith="/UTPRAttribution/RecJurCode")
        xp_jwtr_name = _find_xpath(config, endswith="/JurisdictionSection/JurWithTaxingRights/JurisdictionName")

        xp_upe_other_res = _find_xpath(config, endswith="/CorporateStructure/UPE/OtherUPE/ID/ResCountryCode")
        xp_upe_excl_res = _find_xpath(config, endswith="/CorporateStructure/UPE/ExcludedUPE/ID/ResCountryCode")
        xp_upe_other_rules = _find_xpath(config, endswith="/CorporateStructure/UPE/OtherUPE/ID/Rules")
        xp_upe_excl_rules = _find_xpath(config, endswith="/CorporateStructure/UPE/ExcludedUPE/ID/Rules")
        xp_upe_other_globe = _find_xpath(config, endswith="/CorporateStructure/UPE/OtherUPE/ID/GloBEStatus")
        xp_upe_excl_globe = _find_xpath(config, endswith="/CorporateStructure/UPE/ExcludedUPE/ID/GloBEStatus")
        xp_upe_other_tin = _find_xpath(config, endswith="/CorporateStructure/UPE/OtherUPE/ID/TIN")
        xp_upe_excl_tin = _find_xpath(config, endswith="/CorporateStructure/UPE/ExcludedUPE/ID/TIN")

        xp_ce_globe = _find_xpath(config, endswith="/CorporateStructure/CE/ID/GloBEStatus")
        xp_ce_res = _find_xpath(config, endswith="/CorporateStructure/CE/ID/ResCountryCode")
        xp_ce_rules = _find_xpath(config, endswith="/CorporateStructure/CE/ID/Rules")
        xp_ce_id_tin = _find_xpath(config, endswith="/CorporateStructure/CE/ID/TIN")

        xp_own_pct = _find_xpath(config, endswith="/CorporateStructure/CE/Ownership/OwnershipPercentage")
        xp_own_tin = _find_xpath(config, endswith="/CorporateStructure/CE/Ownership/TIN")
        xp_own_type = _find_xpath(config, endswith="/CorporateStructure/CE/Ownership/OwnershipType")

        xp_ownchg_date = _find_xpath(config, endswith="/CorporateStructure/CE/OwnershipChange/ChangeDate")
        xp_pre_globe = _find_xpath(config, endswith="/CorporateStructure/CE/OwnershipChange/PreGlobeStatus")
        xp_pre_own_tin = _find_xpath(config, endswith="/CorporateStructure/CE/OwnershipChange/PreOwnership/TIN")

        xp_qiir_pope_ipe = _find_xpath(config, endswith="/CorporateStructure/CE/QIIR/POPE-IPE")
        xp_qiir_exc_tin = _find_xpath(config, endswith="/CorporateStructure/CE/QIIR/Exception/TIN")
        xp_qiir_art213 = _find_xpath(config, endswith="/CorporateStructure/CE/QIIR/Exception/ExceptionRule/Art2.1.3")
        xp_qiir_art215 = _find_xpath(config, endswith="/CorporateStructure/CE/QIIR/Exception/ExceptionRule/Art2.1.5")

        # Normalize to lowercase for fast comparisons.
        xp_utpr_rec_lc = _norm_xpath(xp_utpr_rec).lower() if xp_utpr_rec else ""
        xp_jwtr_name_lc = _norm_xpath(xp_jwtr_name).lower() if xp_jwtr_name else ""

        xp_upe_other_res_lc = _norm_xpath(xp_upe_other_res).lower() if xp_upe_other_res else ""
        xp_upe_excl_res_lc = _norm_xpath(xp_upe_excl_res).lower() if xp_upe_excl_res else ""
        xp_upe_other_rules_lc = _norm_xpath(xp_upe_other_rules).lower() if xp_upe_other_rules else ""
        xp_upe_excl_rules_lc = _norm_xpath(xp_upe_excl_rules).lower() if xp_upe_excl_rules else ""
        xp_upe_other_globe_lc = _norm_xpath(xp_upe_other_globe).lower() if xp_upe_other_globe else ""
        xp_upe_excl_globe_lc = _norm_xpath(xp_upe_excl_globe).lower() if xp_upe_excl_globe else ""
        xp_upe_other_tin_lc = _norm_xpath(xp_upe_other_tin).lower() if xp_upe_other_tin else ""
        xp_upe_excl_tin_lc = _norm_xpath(xp_upe_excl_tin).lower() if xp_upe_excl_tin else ""

        xp_ce_globe_lc = _norm_xpath(xp_ce_globe).lower() if xp_ce_globe else ""
        xp_ce_res_lc = _norm_xpath(xp_ce_res).lower() if xp_ce_res else ""
        xp_ce_rules_lc = _norm_xpath(xp_ce_rules).lower() if xp_ce_rules else ""
        xp_ce_id_tin_lc = _norm_xpath(xp_ce_id_tin).lower() if xp_ce_id_tin else ""

        xp_own_pct_lc = _norm_xpath(xp_own_pct).lower() if xp_own_pct else ""
        xp_own_tin_lc = _norm_xpath(xp_own_tin).lower() if xp_own_tin else ""
        xp_own_type_lc = _norm_xpath(xp_own_type).lower() if xp_own_type else ""

        xp_ownchg_date_lc = _norm_xpath(xp_ownchg_date).lower() if xp_ownchg_date else ""
        xp_pre_globe_lc = _norm_xpath(xp_pre_globe).lower() if xp_pre_globe else ""
        xp_pre_own_tin_lc = _norm_xpath(xp_pre_own_tin).lower() if xp_pre_own_tin else ""

        xp_qiir_pope_ipe_lc = _norm_xpath(xp_qiir_pope_ipe).lower() if xp_qiir_pope_ipe else ""
        xp_qiir_exc_tin_lc = _norm_xpath(xp_qiir_exc_tin).lower() if xp_qiir_exc_tin else ""
        xp_qiir_art213_lc = _norm_xpath(xp_qiir_art213).lower() if xp_qiir_art213 else ""
        xp_qiir_art215_lc = _norm_xpath(xp_qiir_art215).lower() if xp_qiir_art215 else ""

        # -----------------------------
        # 70008: UTPRAttribution/RecJurCode allowed values (UPE jurisdiction or JurWithTaxingRights)
        # -----------------------------
        # Build UPE jurisdiction set and JWTR index by jurisdiction section.
        upe_juris: Set[str] = set()
        if xp_upe_other_res_lc or xp_upe_excl_res_lc:
            for dp in submission_dps:
                xp = _dp_xpath_lc(dp)
                if xp in {xp_upe_other_res_lc, xp_upe_excl_res_lc}:
                    v = (dp.value_raw or "").strip().upper()
                    if v:
                        upe_juris.add(v)

        jwtr_by_juris: Dict[Optional[str], Set[str]] = {}
        if xp_jwtr_name_lc:
            for dp in submission_dps:
                if _dp_xpath_lc(dp) != xp_jwtr_name_lc:
                    continue
                v = (dp.value_raw or "").strip().upper()
                if not v:
                    continue
                jwtr_by_juris.setdefault(dp.jurisdiction_code or None, set()).add(v)

        if xp_utpr_rec_lc:
            all_jwtr = set().union(*jwtr_by_juris.values()) if jwtr_by_juris else set()
            for dp in submission_dps:
                if _dp_xpath_lc(dp) != xp_utpr_rec_lc:
                    continue
                rec = (dp.value_raw or "").strip().upper()
                if not rec:
                    continue
                allowed = set(upe_juris)
                if dp.jurisdiction_code is not None and dp.jurisdiction_code in jwtr_by_juris:
                    allowed |= jwtr_by_juris.get(dp.jurisdiction_code, set())
                else:
                    allowed |= all_jwtr
                if allowed and rec not in allowed:
                    _oecd_issue(
                        number=70008,
                        severity="BLOCKING",
                        xml_path=dp.xml_path,
                        filer_code=dp.filer_code,
                        jurisdiction_code=dp.jurisdiction_code,
                        entity_code=dp.entity_code,
                        context_key=dp.context_key,
                        message=(
                            f"RecJurCode '{rec}' is not permitted. It must be the UPE jurisdiction "
                            f"({', '.join(sorted(upe_juris)) or '∅'}) or one of the JurWithTaxingRights jurisdictions "
                            "for the relevant JurisdictionSection."
                        ),
                    )

        # -----------------------------
        # Build CorporateStructure indexes for CE + UPE
        # -----------------------------
        ce_statuses: Dict[str, Set[str]] = {}
        if xp_ce_globe_lc:
            for dp in submission_dps:
                if _dp_xpath_lc(dp) != xp_ce_globe_lc:
                    continue
                ec = (dp.entity_code or "").strip()
                if not ec:
                    continue
                v = (dp.value_raw or "").strip()
                if v:
                    ce_statuses.setdefault(ec, set()).add(v)

        # UPE status + identifiers
        upe_statuses: Set[str] = set()
        if xp_upe_other_globe_lc or xp_upe_excl_globe_lc:
            for dp in submission_dps:
                if _dp_xpath_lc(dp) in {xp_upe_other_globe_lc, xp_upe_excl_globe_lc}:
                    v = (dp.value_raw or "").strip()
                    if v:
                        upe_statuses.add(v)

        # Entity TIN lookup (CE/ID/TIN)
        ce_tin_by_entity: Dict[str, str] = {}
        tin_to_entities: Dict[str, Set[str]] = {}
        if xp_ce_id_tin_lc:
            for dp in submission_dps:
                if _dp_xpath_lc(dp) != xp_ce_id_tin_lc:
                    continue
                ec = (dp.entity_code or "").strip()
                if not ec:
                    continue
                v = (dp.value_raw or "").strip()
                if not v:
                    continue
                # prefer first seen
                if ec not in ce_tin_by_entity:
                    ce_tin_by_entity[ec] = v
                tin_to_entities.setdefault(v, set()).add(ec)

        ce_tins: Set[str] = set(tin_to_entities.keys())

        # UPE TIN set (OtherUPE/ID/TIN or ExcludedUPE/ID/TIN)
        upe_tins: Set[str] = set()
        if xp_upe_other_tin_lc or xp_upe_excl_tin_lc:
            for dp in submission_dps:
                if _dp_xpath_lc(dp) in {xp_upe_other_tin_lc, xp_upe_excl_tin_lc}:
                    v = (dp.value_raw or "").strip()
                    if v:
                        upe_tins.add(v)

        # -----------------------------
        # 70009: Invalid UPE GloBEStatus values
        # -----------------------------
        invalid_upe = {"GIR305", "GIR307", "GIR308", "GIR309", "GIR312", "GIR313", "GIR314", "GIR315", "GIR317", "GIR318"}
        if (xp_upe_other_globe_lc or xp_upe_excl_globe_lc) and invalid_upe:
            for dp in submission_dps:
                if _dp_xpath_lc(dp) not in {xp_upe_other_globe_lc, xp_upe_excl_globe_lc}:
                    continue
                v = (dp.value_raw or "").strip()
                if v in invalid_upe:
                    _oecd_issue(
                        number=70009,
                        severity="BLOCKING",
                        xml_path=dp.xml_path,
                        filer_code=dp.filer_code,
                        jurisdiction_code=dp.jurisdiction_code,
                        message=f"UPE GloBEStatus '{v}' is not permitted for the UPE.",
                    )

        # -----------------------------
        # 70010: Only one ResCountryCode allowed for UPE/OtherUPE
        # -----------------------------
        if xp_upe_other_res_lc:
            # Count occurrences across the submission (choice group means there should be at most one).
            seen: List[models.DataPoint] = [dp for dp in submission_dps if _dp_xpath_lc(dp) == xp_upe_other_res_lc]
            if len(seen) > 1:
                vals = sorted({(dp.value_raw or "").strip().upper() for dp in seen if (dp.value_raw or "").strip()})
                _oecd_issue(
                    number=70010,
                    severity="BLOCKING",
                    xml_path=xp_upe_other_res,
                    message=f"More than one ResCountryCode was provided for UPE/OtherUPE: {', '.join(vals) or '∅'}.",
                )

        # -----------------------------
        # 70011: Only one ResCountryCode allowed per CE
        # -----------------------------
        if xp_ce_res_lc:
            by_ent: Dict[str, List[models.DataPoint]] = {}
            for dp in submission_dps:
                if _dp_xpath_lc(dp) != xp_ce_res_lc:
                    continue
                ec = (dp.entity_code or "").strip()
                if not ec:
                    continue
                by_ent.setdefault(ec, []).append(dp)
            for ec, arr in by_ent.items():
                if len(arr) > 1:
                    vals = sorted({(dp.value_raw or "").strip().upper() for dp in arr if (dp.value_raw or "").strip()})
                    _oecd_issue(
                        number=70011,
                        severity="BLOCKING",
                        xml_path=xp_ce_res,
                        entity_code=ec,
                        message=f"More than one ResCountryCode was provided for CE '{ec}': {', '.join(vals) or '∅'}.",
                    )

        # -----------------------------
        # 70012: Entities in same ResCountryCode must share the same Rules (ignoring GIR204)
        # -----------------------------
        # Collect rules per entity-like record.
        rules_by_key: Dict[str, Set[str]] = {}
        res_by_key: Dict[str, str] = {}

        # UPE (OtherUPE / ExcludedUPE)
        def _collect_single(prefix: str, xp_res_lc: str, xp_rules_lc: str) -> None:
            if not xp_res_lc:
                return
            # ResCountryCode
            for dp in submission_dps:
                if _dp_xpath_lc(dp) == xp_res_lc:
                    v = (dp.value_raw or "").strip().upper()
                    if v:
                        res_by_key[prefix] = v
                        break
            if not xp_rules_lc:
                return
            for dp in submission_dps:
                if _dp_xpath_lc(dp) != xp_rules_lc:
                    continue
                v = (dp.value_raw or "").strip()
                if v:
                    rules_by_key.setdefault(prefix, set()).add(v)

        _collect_single("UPE_OTHER", xp_upe_other_res_lc, xp_upe_other_rules_lc)
        _collect_single("UPE_EXCL", xp_upe_excl_res_lc, xp_upe_excl_rules_lc)

        # CEs
        if xp_ce_res_lc:
            for dp in submission_dps:
                if _dp_xpath_lc(dp) != xp_ce_res_lc:
                    continue
                ec = (dp.entity_code or "").strip()
                if not ec:
                    continue
                v = (dp.value_raw or "").strip().upper()
                if v:
                    res_by_key.setdefault(ec, v)
        if xp_ce_rules_lc:
            for dp in submission_dps:
                if _dp_xpath_lc(dp) != xp_ce_rules_lc:
                    continue
                ec = (dp.entity_code or "").strip()
                if not ec:
                    continue
                v = (dp.value_raw or "").strip()
                if v:
                    rules_by_key.setdefault(ec, set()).add(v)

        # Compare within each ResCountryCode.
        by_res: Dict[str, List[str]] = {}
        for key, res in res_by_key.items():
            if not res:
                continue
            by_res.setdefault(res, []).append(key)

        for res, keys in by_res.items():
            # Determine the canonical rule-set, ignoring GIR204.
            norm_sets: Dict[str, Set[str]] = {}
            for k in keys:
                s = set(rules_by_key.get(k, set()))
                s.discard("GIR204")
                norm_sets[k] = s
            unique = {frozenset(v) for v in norm_sets.values()}
            if len(unique) <= 1:
                continue
            # Emit issues for all keys in the jurisdiction (so users can reconcile).
            pretty = {k: ",".join(sorted(v)) or "∅" for k, v in norm_sets.items()}
            msg = " ; ".join([f"{k}=[{pretty[k]}]" for k in sorted(pretty.keys())])
            _oecd_issue(
                number=70012,
                severity="BLOCKING",
                xml_path=xp_ce_rules or xp_upe_other_rules or xp_upe_excl_rules,
                jurisdiction_code=res,
                message=(
                    f"Entities with ResCountryCode '{res}' have inconsistent Rules (ignoring GIR204): {msg}."
                ),
            )

        # -----------------------------
        # 70013–70021: CE GloBEStatus consistency rules
        # -----------------------------
        any_gir307 = any("GIR307" in s for s in ce_statuses.values())
        any_gir306 = any("GIR306" in s for s in ce_statuses.values())

        for ec, st in ce_statuses.items():
            # 70013: GIR313 and GIR314 cannot both be present
            if "GIR313" in st and "GIR314" in st:
                _oecd_issue(
                    number=70013,
                    severity="BLOCKING",
                    xml_path=xp_ce_globe,
                    entity_code=ec,
                    message="CE has both GloBEStatus GIR313 and GIR314; they must not be reported together.",
                )
            # 70014: GIR307 and GIR308 cannot both be present
            if "GIR307" in st and "GIR308" in st:
                _oecd_issue(
                    number=70014,
                    severity="BLOCKING",
                    xml_path=xp_ce_globe,
                    entity_code=ec,
                    message="CE has both GloBEStatus GIR307 and GIR308; they must not be reported together.",
                )

            # 70016/70017: GIR307/308 should also include GIR309
            if "GIR307" in st and "GIR309" not in st:
                _oecd_issue(
                    number=70016,
                    severity="WARNING",
                    xml_path=xp_ce_globe,
                    entity_code=ec,
                    message="CE has GloBEStatus GIR307 but is missing GIR309, which should also be reported.",
                )
            if "GIR308" in st and "GIR309" not in st:
                _oecd_issue(
                    number=70017,
                    severity="WARNING",
                    xml_path=xp_ce_globe,
                    entity_code=ec,
                    message="CE has GloBEStatus GIR308 but is missing GIR309, which should also be reported.",
                )

            # 70018: GIR305 and GIR306 cannot both be present
            if "GIR305" in st and "GIR306" in st:
                _oecd_issue(
                    number=70018,
                    severity="BLOCKING",
                    xml_path=xp_ce_globe,
                    entity_code=ec,
                    message="CE has both GloBEStatus GIR305 and GIR306; they must not be reported together.",
                )

            # 70020: GIR316/GIR318 should be the only GloBEStatus value
            if ("GIR316" in st or "GIR318" in st) and len(st) > 1:
                _oecd_issue(
                    number=70020,
                    severity="WARNING",
                    xml_path=xp_ce_globe,
                    entity_code=ec,
                    message=(
                        "CE has GloBEStatus GIR316/GIR318 but also other GloBEStatus values; GIR316 or GIR318 should be the only value."
                    ),
                )

        # 70015: GIR308 requires another CE with GIR307
        if not any_gir307:
            for ec, st in ce_statuses.items():
                if "GIR308" in st:
                    _oecd_issue(
                        number=70015,
                        severity="BLOCKING",
                        xml_path=xp_ce_globe,
                        entity_code=ec,
                        message=(
                            "A CE is reported with GloBEStatus GIR308, but no other CE in CorporateStructure has GloBEStatus GIR307."
                        ),
                    )

        # 70019: GIR305 requires another CE with GIR306
        if not any_gir306:
            for ec, st in ce_statuses.items():
                if "GIR305" in st:
                    _oecd_issue(
                        number=70019,
                        severity="BLOCKING",
                        xml_path=xp_ce_globe,
                        entity_code=ec,
                        message=(
                            "A CE is reported with GloBEStatus GIR305 (PE), but no other CE in CorporateStructure has GloBEStatus GIR306 (main entity)."
                        ),
                    )

        # 70021: GIR316/GIR318 requires a completed OwnershipChange (ID/TIN must match PreOwnership/TIN)
        if xp_pre_own_tin_lc and xp_ce_id_tin_lc:
            pre_tins_by_ent: Dict[str, Set[str]] = {}
            for dp in submission_dps:
                if _dp_xpath_lc(dp) != xp_pre_own_tin_lc:
                    continue
                ec = (dp.entity_code or "").strip()
                if not ec:
                    continue
                v = (dp.value_raw or "").strip()
                if v:
                    pre_tins_by_ent.setdefault(ec, set()).add(v)

            for ec, st in ce_statuses.items():
                if "GIR316" not in st and "GIR318" not in st:
                    continue
                id_tin = ce_tin_by_entity.get(ec)
                if not id_tin:
                    continue
                if id_tin not in pre_tins_by_ent.get(ec, set()):
                    _oecd_issue(
                        number=70021,
                        severity="BLOCKING",
                        xml_path=xp_ce_globe,
                        entity_code=ec,
                        message=(
                            f"CE has GloBEStatus GIR316/GIR318, but no OwnershipChange is completed where PreOwnership/TIN matches CE/ID/TIN ('{id_tin}')."
                        ),
                    )

        # -----------------------------
        # 70022–70024: OwnershipChange date window + PreOwnership gating
        # -----------------------------
        if xp_ownchg_date_lc:
            for dp in submission_dps:
                if _dp_xpath_lc(dp) != xp_ownchg_date_lc:
                    continue
                dt = dp.value_date or try_parse_date((dp.value_raw or "").strip())
                if not dt:
                    continue
                if filing.period_start and dt < filing.period_start:
                    _oecd_issue(
                        number=70022,
                        severity="BLOCKING",
                        xml_path=dp.xml_path,
                        filer_code=dp.filer_code,
                        jurisdiction_code=dp.jurisdiction_code,
                        entity_code=dp.entity_code,
                        context_key=dp.context_key,
                        message=(
                            f"OwnershipChange/ChangeDate {dt.isoformat()} is before FilingInfo Period Start {filing.period_start.isoformat()}."
                        ),
                    )
                if filing.period_end and dt > filing.period_end:
                    _oecd_issue(
                        number=70023,
                        severity="BLOCKING",
                        xml_path=dp.xml_path,
                        filer_code=dp.filer_code,
                        jurisdiction_code=dp.jurisdiction_code,
                        entity_code=dp.entity_code,
                        context_key=dp.context_key,
                        message=(
                            f"OwnershipChange/ChangeDate {dt.isoformat()} is after FilingInfo Period End {filing.period_end.isoformat()}."
                        ),
                    )

        # 70024: When PreGlobeStatus=GIR719, PreOwnership must not be completed.
        if xp_pre_globe_lc:
            # Build quick lookup of any PreOwnership leaf presence by (entity, context_key)
            preown_present: Set[Tuple[str, Optional[str]]] = set()
            for dp in submission_dps:
                xp = _norm_xpath(dp.xml_path or "").lower()
                if "/ownershipchange/preownership/" in xp:
                    ec = (dp.entity_code or "").strip()
                    if ec:
                        preown_present.add((ec, dp.context_key or None))

            for dp in submission_dps:
                if _dp_xpath_lc(dp) != xp_pre_globe_lc:
                    continue
                ec = (dp.entity_code or "").strip()
                if not ec:
                    continue
                v = (dp.value_raw or "").strip()
                if v != "GIR719":
                    continue
                if (ec, dp.context_key or None) in preown_present:
                    _oecd_issue(
                        number=70024,
                        severity="BLOCKING",
                        xml_path=dp.xml_path,
                        filer_code=dp.filer_code,
                        jurisdiction_code=dp.jurisdiction_code,
                        entity_code=ec,
                        context_key=dp.context_key,
                        message="PreGlobeStatus is GIR719, so PreOwnership must not be completed for this OwnershipChange.",
                    )

        # -----------------------------
        # 70026–70031: Ownership element rules
        # -----------------------------
        # Build ownership datapoint index by (entity_code, context_key)
        own_idx: Dict[Tuple[str, Optional[str]], Dict[str, List[models.DataPoint]]] = {}
        if xp_own_type_lc or xp_own_pct_lc or xp_own_tin_lc:
            for dp in submission_dps:
                ec = (dp.entity_code or "").strip()
                if not ec:
                    continue
                xp = _dp_xpath_lc(dp)
                if xp not in {xp_own_type_lc, xp_own_pct_lc, xp_own_tin_lc}:
                    continue
                k = (ec, dp.context_key or None)
                own_idx.setdefault(k, {}).setdefault(xp, []).append(dp)

        def _first_str(arr: List[models.DataPoint]) -> str:
            if not arr:
                return ""
            return (arr[0].value_raw or "").strip()

        def _first_dec(arr: List[models.DataPoint]) -> Optional[Decimal]:
            if not arr:
                return None
            return _dp_decimal(arr[0])

        # 70026: PE (GIR305) OwnershipPercentage must equal 100%
        for ec, st in ce_statuses.items():
            if "GIR305" not in st:
                continue
            for (e2, ck), m in own_idx.items():
                if e2 != ec:
                    continue
                pct = _first_dec(m.get(xp_own_pct_lc, []))
                if pct is None:
                    continue
                if pct != Decimal("100"):
                    _oecd_issue(
                        number=70026,
                        severity="BLOCKING",
                        xml_path=xp_own_pct,
                        entity_code=ec,
                        context_key=ck,
                        message=f"CE has GloBEStatus GIR305 (PE) but OwnershipPercentage is {pct} (must be 100).",
                    )

        # 70027: Non-Group Member (GIR318) should have 0% + NOTIN + OwnershipType GIR806
        for ec, st in ce_statuses.items():
            if "GIR318" not in st:
                continue
            for (e2, ck), m in own_idx.items():
                if e2 != ec:
                    continue
                pct = _first_dec(m.get(xp_own_pct_lc, []))
                ot = _first_str(m.get(xp_own_type_lc, []))
                tin = _first_str(m.get(xp_own_tin_lc, []))
                problems: List[str] = []
                if pct is not None and pct != Decimal("0"):
                    problems.append(f"OwnershipPercentage={pct} (expected 0)")
                if tin and tin.upper() != "NOTIN":
                    problems.append(f"Ownership/TIN='{tin}' (expected NOTIN)")
                if ot and ot != "GIR806":
                    problems.append(f"OwnershipType='{ot}' (expected GIR806)")
                if problems:
                    _oecd_issue(
                        number=70027,
                        severity="WARNING",
                        xml_path=xp_own_type or xp_own_pct or xp_own_tin,
                        entity_code=ec,
                        context_key=ck,
                        message=(
                            "CE has GloBEStatus GIR318; ownership should reflect Non-Group Member conventions. "
                            + "; ".join(problems)
                        ),
                    )

        # 70028: Unless GIR318, OwnershipPercentage must not be 0%
        for (ec, ck), m in own_idx.items():
            st = ce_statuses.get(ec, set())
            if "GIR318" in st:
                continue
            pct = _first_dec(m.get(xp_own_pct_lc, []))
            if pct is None:
                continue
            if pct == Decimal("0"):
                _oecd_issue(
                    number=70028,
                    severity="BLOCKING",
                    xml_path=xp_own_pct,
                    entity_code=ec,
                    context_key=ck,
                    message="OwnershipPercentage is 0% but CE is not reported as GloBEStatus GIR318 (Non-Group Member).",
                )

        # 70029/70030: OwnershipType-based owner TIN references
        for (ec, ck), m in own_idx.items():
            ot = _first_str(m.get(xp_own_type_lc, []))
            tin = _first_str(m.get(xp_own_tin_lc, []))
            if not ot or not tin:
                continue
            if ot == "GIR801" and upe_tins:
                if tin not in upe_tins:
                    _oecd_issue(
                        number=70029,
                        severity="BLOCKING",
                        xml_path=xp_own_tin,
                        entity_code=ec,
                        context_key=ck,
                        message=(
                            f"OwnershipType is GIR801 (UPE), but Ownership/TIN '{tin}' does not match any UPE TIN ({', '.join(sorted(upe_tins))})."
                        ),
                    )
            if ot in {"GIR802", "GIR803", "GIR804"} and ce_tins:
                if tin not in ce_tins:
                    _oecd_issue(
                        number=70030,
                        severity="BLOCKING",
                        xml_path=xp_own_tin,
                        entity_code=ec,
                        context_key=ck,
                        message=(
                            f"OwnershipType is {ot}, but Ownership/TIN '{tin}' does not match any CE/ID/TIN in CorporateStructure."
                        ),
                    )

        # 70031: PE owner TIN must be held by a main entity (GIR306) (CE or UPE/OtherUPE)
        main_tins: Set[str] = set()
        for ec, st in ce_statuses.items():
            if "GIR306" in st:
                t = ce_tin_by_entity.get(ec)
                if t:
                    main_tins.add(t)
        if "GIR306" in upe_statuses:
            # Use UPE TIN(s) if UPE is a main entity.
            main_tins |= set(upe_tins)

        if main_tins:
            for pe, st in ce_statuses.items():
                if "GIR305" not in st:
                    continue
                # Any ownership record must reference a main entity TIN.
                ok = False
                for (ec, ck), m in own_idx.items():
                    if ec != pe:
                        continue
                    tin = _first_str(m.get(xp_own_tin_lc, []))
                    if tin and tin in main_tins:
                        ok = True
                        break
                if not ok:
                    _oecd_issue(
                        number=70031,
                        severity="BLOCKING",
                        xml_path=xp_own_tin,
                        entity_code=pe,
                        message=(
                            f"CE has GloBEStatus GIR305 (PE) but Ownership/TIN does not match any main entity (GIR306) TIN ({', '.join(sorted(main_tins))})."
                        ),
                    )

        # -----------------------------
        # 70032–70035: QIIR / exception rules
        # -----------------------------
        # 70032: If QIIR is provided, CE/ID/Rules must include GIR201 or GIR202.
        if xp_qiir_pope_ipe_lc and xp_ce_rules_lc:
            qiir_entities: Set[str] = set()
            for dp in submission_dps:
                if "/corporatestructure/ce/qiir" not in (_norm_xpath(dp.xml_path or "").lower()):
                    continue
                ec = (dp.entity_code or "").strip()
                if ec:
                    qiir_entities.add(ec)

            for ec in qiir_entities:
                rules = set(rules_by_key.get(ec, set()))
                if not ({"GIR201", "GIR202"} & rules):
                    _oecd_issue(
                        number=70032,
                        severity="BLOCKING",
                        xml_path=xp_ce_rules,
                        entity_code=ec,
                        message=(
                            "QIIR is provided for this CE, but CE/ID/Rules does not include GIR201 or GIR202."
                        ),
                    )

        # 70033: QIIR/Exception/TIN must match another CE/ID/TIN.
        if xp_qiir_exc_tin_lc and tin_to_entities:
            for dp in submission_dps:
                if _dp_xpath_lc(dp) != xp_qiir_exc_tin_lc:
                    continue
                ec = (dp.entity_code or "").strip()
                v = (dp.value_raw or "").strip()
                if not v:
                    continue
                owners = tin_to_entities.get(v, set())
                if not owners or (ec and owners == {ec}):
                    _oecd_issue(
                        number=70033,
                        severity="BLOCKING",
                        xml_path=dp.xml_path,
                        entity_code=ec or None,
                        context_key=dp.context_key,
                        message=(
                            f"QIIR/Exception/TIN '{v}' does not match the TIN of any other CE in CorporateStructure."
                        ),
                    )

        # 70034/70035: POPE-IPE + exception implies Art2.1.3 / Art2.1.5 must be TRUE.
        if xp_qiir_pope_ipe_lc and (xp_qiir_art213_lc or xp_qiir_art215_lc):
            # Index QIIR values per entity
            pope_ipe_by_ent: Dict[str, str] = {}
            exc_present: Set[Tuple[str, Optional[str]]] = set()
            art213_by_key: Dict[Tuple[str, Optional[str]], str] = {}
            art215_by_key: Dict[Tuple[str, Optional[str]], str] = {}

            for dp in submission_dps:
                ec = (dp.entity_code or "").strip()
                if not ec:
                    continue
                xp = _dp_xpath_lc(dp)
                ck = dp.context_key or None
                if xp == xp_qiir_pope_ipe_lc:
                    v = (dp.value_raw or "").strip()
                    if v:
                        pope_ipe_by_ent[ec] = v
                # Exception container presence: any dp under /QIIR/Exception
                if "/corporatestructure/ce/qiir/exception" in (_norm_xpath(dp.xml_path or "").lower()):
                    exc_present.add((ec, ck))
                if xp_qiir_art213_lc and xp == xp_qiir_art213_lc:
                    art213_by_key[(ec, ck)] = (dp.value_raw or "").strip()
                if xp_qiir_art215_lc and xp == xp_qiir_art215_lc:
                    art215_by_key[(ec, ck)] = (dp.value_raw or "").strip()

            for (ec, ck) in exc_present:
                pi = pope_ipe_by_ent.get(ec)
                if not pi:
                    continue
                if pi == "GIR902":
                    v = art213_by_key.get((ec, ck), "")
                    if not _truthy(v):
                        _oecd_issue(
                            number=70034,
                            severity="BLOCKING",
                            xml_path=xp_qiir_art213,
                            entity_code=ec,
                            context_key=ck,
                            message=(
                                "QIIR exception applies and POPE-IPE is GIR902 (IPE), but Art2.1.3 is not TRUE."
                            ),
                        )
                if pi == "GIR901":
                    v = art215_by_key.get((ec, ck), "")
                    if not _truthy(v):
                        _oecd_issue(
                            number=70035,
                            severity="BLOCKING",
                            xml_path=xp_qiir_art215,
                            entity_code=ec,
                            context_key=ck,
                            message=(
                                "QIIR exception applies and POPE-IPE is GIR901 (POPE), but Art2.1.5 is not TRUE."
                            ),
                        )
    except Exception:
        # Non-fatal: OECD record error checks are best-effort.
        pass


    return issues
