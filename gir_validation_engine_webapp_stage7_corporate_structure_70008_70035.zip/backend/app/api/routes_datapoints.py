from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy.dialects.postgresql import insert
from datetime import datetime
from typing import List, Optional
from hashlib import sha1

from app.db.session import get_db
from app.db import models
from app.api.schemas import (
    DataPointUpsert,
    BulkUpsertResult,
    DataPointRead,
    EffectiveDataPointQueryResult,
    EffectiveDataPointDiffResult,
    EffectiveDataPointDiffItem,
    EffectiveDataPointDiffSummaryResult,
    EffectiveDataPointDiffSummaryBucket,
    EffectiveDataPointDiffPathBucket,
    DataPointKey,
)
from app.services.utils import try_parse_decimal, try_parse_date

from app.core.settings import settings
from app.services.config_loader import load_config
from app.services.validation_engine import derive_virtual_datapoints_from_registers

router = APIRouter(prefix="/filings/{filing_id}", tags=["datapoints"])

def _ensure_filing(db: Session, filing_id: str) -> models.Filing:
    filing = db.get(models.Filing, filing_id)
    if filing is None:
        raise HTTPException(status_code=404, detail="Filing not found")
    return filing

@router.post("/datapoints:bulkUpsert", response_model=BulkUpsertResult)
def bulk_upsert_datapoints(filing_id: str, payload: List[DataPointUpsert], db: Session = Depends(get_db)):
    _ensure_filing(db, filing_id)

    rows = []
    now = datetime.utcnow()
    for x in payload:
        dec = try_parse_decimal(x.value_raw)
        dt = try_parse_date(x.value_raw)
        rows.append({
            "filing_id": filing_id,
            "filer_code": x.filer_code,
            "jurisdiction_code": x.jurisdiction_code,
            "entity_code": x.entity_code,
            "context_key": x.context_key,
            "xml_path": x.xml_path,
            "value_raw": x.value_raw,
            "value_numeric": dec,
            "value_date": dt,
            "currency": x.currency,
            "source": x.source,
            "source_system": x.source_system,
            "notes": x.notes,
            "updated_at": now,
            "created_at": now,
        })

    stmt = insert(models.DataPoint).values(rows)
    update_cols = {c.name: getattr(stmt.excluded, c.name) for c in models.DataPoint.__table__.columns
                   if c.name not in ("id", "created_at")}
    stmt = stmt.on_conflict_do_update(
        constraint="uq_datapoint_key",
        set_=update_cols
    )
    db.execute(stmt)
    db.commit()
    return BulkUpsertResult(inserted=0, updated=0, total=len(rows))

@router.get("/datapoints")
def query_datapoints(
    filing_id: str,
    xml_path_prefix: Optional[str] = Query(default=None),
    filer_code: Optional[str] = Query(default=None),
    jurisdiction_code: Optional[str] = Query(default=None),
    entity_code: Optional[str] = Query(default=None),
    limit: int = Query(default=2000, ge=1, le=20000),
    db: Session = Depends(get_db),
):
    _ensure_filing(db, filing_id)
    q = db.query(models.DataPoint).filter(models.DataPoint.filing_id == filing_id)
    if xml_path_prefix:
        q = q.filter(models.DataPoint.xml_path.startswith(xml_path_prefix))
    if filer_code:
        q = q.filter(models.DataPoint.filer_code == filer_code)
    if jurisdiction_code:
        q = q.filter(models.DataPoint.jurisdiction_code == jurisdiction_code)
    if entity_code:
        q = q.filter(models.DataPoint.entity_code == entity_code)

    rows = q.order_by(models.DataPoint.xml_path.asc()).limit(limit).all()
    return {
        "count": len(rows),
        "items": [
            {
                "filer_code": r.filer_code,
                "jurisdiction_code": r.jurisdiction_code,
                "entity_code": r.entity_code,
                "context_key": r.context_key,
                "xml_path": r.xml_path,
                "value_raw": r.value_raw,
                "currency": r.currency,
                "source": r.source,
                "source_system": r.source_system,
                "notes": r.notes,
                "updated_at": r.updated_at.isoformat(),
            }
            for r in rows
        ],
    }


@router.get("/datapoints:effective", response_model=EffectiveDataPointQueryResult)
def query_effective_datapoints(
    filing_id: str,
    xml_path_prefix: Optional[str] = Query(default=None, description="Filter by xpath prefix"),
    filer_code: Optional[str] = Query(default=None),
    jurisdiction_code: Optional[str] = Query(default=None),
    entity_code: Optional[str] = Query(default=None),
    include_persisted: bool = Query(default=True, description="Include datapoints stored in the database"),
    include_virtual: bool = Query(default=True, description="Include datapoints derived from registers on the fly"),
    limit: int = Query(default=5000, ge=1, le=50000),
    db: Session = Depends(get_db),
):
    """Return the *effective* datapoint set used by the validation engine.

    Effective datapoints = (persisted datapoints) ∪ (virtual datapoints derived
    from registers + filing header fields).

    This endpoint exists primarily for:
    - front-end rendering (show users what values the engine sees)
    - debugging / support (explain why a required field is considered present)
    """

    filing = _ensure_filing(db, filing_id)

    persisted: List[models.DataPoint] = []
    if include_persisted or include_virtual:
        # We load the full set so that virtual datapoints never override explicit
        # datapoints, even if the caller is filtering.
        persisted = (
            db.query(models.DataPoint)
            .filter(models.DataPoint.filing_id == filing_id)
            .all()
        )

    virtual: List[models.DataPoint] = []
    if include_virtual:
        try:
            config = load_config(settings.config_root, filing.config_version_id)
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Cannot load config: {e}")

        filers = db.query(models.Filer).filter(models.Filer.filing_id == filing_id).all()
        juris_rows = db.query(models.Jurisdiction).filter(models.Jurisdiction.filing_id == filing_id).all()
        entity_rows = db.query(models.ConstituentEntity).filter(models.ConstituentEntity.filing_id == filing_id).all()

        virtual = derive_virtual_datapoints_from_registers(
            db=db,
            filing=filing,
            config=config,
            filers=filers,
            jurisdictions=juris_rows,
            entities=entity_rows,
            existing_datapoints=persisted,
        )

    def _match(dp: models.DataPoint) -> bool:
        if xml_path_prefix and not (dp.xml_path or "").startswith(xml_path_prefix):
            return False
        if filer_code and (dp.filer_code or None) != filer_code:
            return False
        if jurisdiction_code and (dp.jurisdiction_code or None) != jurisdiction_code:
            return False
        if entity_code and (dp.entity_code or None) != entity_code:
            return False
        return True

    def _virtual_id(dp: models.DataPoint) -> str:
        key = f"{dp.filer_code or ''}|{dp.jurisdiction_code or ''}|{dp.entity_code or ''}|{dp.context_key or ''}|{dp.xml_path or ''}"
        h = sha1(key.encode("utf-8")).hexdigest()[:16].upper()
        return f"V-{h}"

    items: List[DataPointRead] = []

    if include_persisted:
        for dp in persisted:
            if not _match(dp):
                continue
            items.append(DataPointRead(
                id=dp.id,
                filer_code=dp.filer_code,
                jurisdiction_code=dp.jurisdiction_code,
                entity_code=dp.entity_code,
                context_key=dp.context_key,
                xml_path=dp.xml_path,
                value_raw=dp.value_raw,
                value_numeric=dp.value_numeric,
                value_date=dp.value_date,
                currency=dp.currency,
                source=dp.source,
                source_system=dp.source_system,
                notes=dp.notes,
                updated_at=dp.updated_at,
                is_virtual=False,
            ))

    if include_virtual:
        for dp in virtual:
            if not _match(dp):
                continue
            items.append(DataPointRead(
                id=_virtual_id(dp),
                filer_code=dp.filer_code,
                jurisdiction_code=dp.jurisdiction_code,
                entity_code=dp.entity_code,
                context_key=dp.context_key,
                xml_path=dp.xml_path,
                value_raw=dp.value_raw,
                value_numeric=dp.value_numeric,
                value_date=dp.value_date,
                currency=dp.currency,
                source=dp.source,
                source_system=dp.source_system,
                notes=dp.notes,
                updated_at=dp.updated_at,
                is_virtual=True,
            ))

    # Stable ordering for UI/debugging.
    items.sort(key=lambda x: (
        x.xml_path,
        x.filer_code or "",
        x.jurisdiction_code or "",
        x.entity_code or "",
        x.context_key or "",
        "1" if x.is_virtual else "0",
    ))

    # Totals are computed *before* limiting so UIs can show "X of Y".
    total_count = len(items)
    persisted_count = sum(1 for x in items if not x.is_virtual)
    virtual_count = sum(1 for x in items if x.is_virtual)

    items = items[:limit]

    return EffectiveDataPointQueryResult(
        generated_at=datetime.utcnow(),
        count=total_count,
        persisted_count=persisted_count,
        virtual_count=virtual_count,
        items=items,
    )


@router.get("/effective-datapoints:diff", response_model=EffectiveDataPointDiffResult)
def query_effective_datapoints_diff(
    filing_id: str,
    xml_path_prefix: Optional[str] = Query(default=None, description="Filter by xpath prefix"),
    filer_code: Optional[str] = Query(default=None),
    jurisdiction_code: Optional[str] = Query(default=None),
    entity_code: Optional[str] = Query(default=None),
    only_overrides: bool = Query(default=False, description="If true, only return keys where both persisted and virtual exist"),
    only_differences: bool = Query(default=False, description="If true, only return keys where both exist and differ"),
    limit: int = Query(default=5000, ge=1, le=50000),
    db: Session = Depends(get_db),
):
    """Return a side-by-side diff view of persisted vs derived datapoints.

    This endpoint is designed for UI/debugging use cases, especially:
    - explaining why a field has a value (persisted vs derived)
    - highlighting mismatches between registers and uploaded datapoints
    """

    filing = _ensure_filing(db, filing_id)

    # Load persisted datapoints (full set; filters applied later).
    persisted: List[models.DataPoint] = (
        db.query(models.DataPoint)
        .filter(models.DataPoint.filing_id == filing_id)
        .all()
    )

    # Derive virtual datapoints WITHOUT suppressing keys that already exist,
    # so callers can see what the register bridge *would* produce.
    try:
        config = load_config(settings.config_root, filing.config_version_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Cannot load config: {e}")

    filers = db.query(models.Filer).filter(models.Filer.filing_id == filing_id).all()
    juris_rows = db.query(models.Jurisdiction).filter(models.Jurisdiction.filing_id == filing_id).all()
    entity_rows = db.query(models.ConstituentEntity).filter(models.ConstituentEntity.filing_id == filing_id).all()

    virtual: List[models.DataPoint] = derive_virtual_datapoints_from_registers(
        db=db,
        filing=filing,
        config=config,
        filers=filers,
        jurisdictions=juris_rows,
        entities=entity_rows,
        existing_datapoints=persisted,
        suppress_if_exists=False,
    )

    def _match_key(
        *,
        xml_path: str,
        filer: Optional[str],
        juris: Optional[str],
        entity: Optional[str],
    ) -> bool:
        if xml_path_prefix and not (xml_path or "").startswith(xml_path_prefix):
            return False
        if filer_code and (filer or None) != filer_code:
            return False
        if jurisdiction_code and (juris or None) != jurisdiction_code:
            return False
        if entity_code and (entity or None) != entity_code:
            return False
        return True

    def _virtual_id(dp: models.DataPoint) -> str:
        key = f"{dp.filer_code or ''}|{dp.jurisdiction_code or ''}|{dp.entity_code or ''}|{dp.context_key or ''}|{dp.xml_path or ''}"
        h = sha1(key.encode("utf-8")).hexdigest()[:16].upper()
        return f"V-{h}"

    # Build maps.
    def _key(dp: models.DataPoint):
        return (dp.filer_code or None, dp.jurisdiction_code or None, dp.entity_code or None, dp.context_key or None, dp.xml_path)

    persisted_map = { _key(dp): dp for dp in persisted }
    virtual_map = { _key(dp): dp for dp in virtual }

    keys = set(persisted_map.keys()) | set(virtual_map.keys())

    items: List[EffectiveDataPointDiffItem] = []
    keys_with_both = 0
    overrides_count = 0
    differences_count = 0

    for k in keys:
        f, j, e, ctx, xp = k
        if not _match_key(xml_path=xp, filer=f, juris=j, entity=e):
            continue

        p = persisted_map.get(k)
        v = virtual_map.get(k)

        if p is not None and v is not None:
            keys_with_both += 1

        # Determine effective value (engine behavior): persisted wins.
        effective_dp = p if p is not None else v
        if effective_dp is None:
            continue

        # Determine differences.
        diff_fields: List[str] = []
        differs = False
        if p is not None and v is not None:
            if (p.value_raw or "") != (v.value_raw or ""):
                diff_fields.append("value_raw")
            if (p.currency or "") != (v.currency or ""):
                diff_fields.append("currency")
            differs = len(diff_fields) > 0
            if differs:
                differences_count += 1
            overrides_count += 1

        # Filtering modes.
        if only_overrides and not (p is not None and v is not None):
            continue
        if only_differences and not differs:
            continue

        # Convert to API models.
        def _to_read(dp: models.DataPoint, is_virtual: bool) -> DataPointRead:
            return DataPointRead(
                id=_virtual_id(dp) if is_virtual else str(dp.id),
                filer_code=dp.filer_code,
                jurisdiction_code=dp.jurisdiction_code,
                entity_code=dp.entity_code,
                context_key=dp.context_key,
                xml_path=dp.xml_path,
                value_raw=dp.value_raw,
                value_numeric=dp.value_numeric,
                value_date=dp.value_date,
                currency=dp.currency,
                source=dp.source,
                source_system=dp.source_system,
                notes=dp.notes,
                updated_at=dp.updated_at,
                is_virtual=is_virtual,
            )

        persisted_read = _to_read(p, is_virtual=False) if p is not None else None
        virtual_read = _to_read(v, is_virtual=True) if v is not None else None
        effective_read = _to_read(effective_dp, is_virtual=(p is None))

        # Resolution label.
        if p is not None and v is not None:
            if differs:
                resolution = "persisted_overrides_virtual"
            else:
                resolution = "persisted_equals_virtual"
        elif p is not None:
            resolution = "persisted_only"
        else:
            resolution = "virtual_only"

        # Explain string (for UI tooltips).
        if p is None and v is not None:
            origin = (v.notes or "").strip() or "register_bridge"
            explain = f"Using derived value (no persisted datapoint). Origin: {origin}."
        elif p is not None and v is None:
            explain = f"Using persisted value (source={p.source}{', source_system='+p.source_system if p.source_system else ''})."
        else:
            v_origin = (v.notes or "").strip() if v is not None else ""
            if differs:
                explain = (
                    f"Using persisted value (source={p.source}{', source_system='+p.source_system if p.source_system else ''}) "
                    f"which overrides a different derived value (origin: {v_origin or 'register_bridge'})."
                )
            else:
                explain = (
                    f"Persisted value matches derived value (origin: {v_origin or 'register_bridge'}). "
                    f"Persisted value will be used for export/validation."
                )

        items.append(EffectiveDataPointDiffItem(
            key=DataPointKey(
                filer_code=f,
                jurisdiction_code=j,
                entity_code=e,
                context_key=ctx,
                xml_path=xp,
            ),
            resolution=resolution,
            differs=differs,
            explain=explain,
            effective=effective_read,
            persisted=persisted_read,
            virtual=virtual_read,
            diff_fields=diff_fields,
        ))

    # Stable ordering.
    items.sort(key=lambda it: (
        it.key.xml_path,
        it.key.filer_code or "",
        it.key.jurisdiction_code or "",
        it.key.entity_code or "",
        it.key.context_key or "",
    ))

    total_count = len(items)
    items = items[:limit]

    return EffectiveDataPointDiffResult(
        generated_at=datetime.utcnow(),
        count=total_count,
        keys_with_both=keys_with_both,
        overrides_count=overrides_count,
        differences_count=differences_count,
        items=items,
    )


@router.get("/effective-datapoints:diff/summary", response_model=EffectiveDataPointDiffSummaryResult)
def query_effective_datapoints_diff_summary(
    filing_id: str,
    xml_path_prefix: Optional[str] = Query(default=None, description="Filter by xpath prefix"),
    filer_code: Optional[str] = Query(default=None),
    jurisdiction_code: Optional[str] = Query(default=None),
    entity_code: Optional[str] = Query(default=None),
    only_overrides: bool = Query(default=False, description="If true, only include keys where both persisted and virtual exist"),
    only_differences: bool = Query(default=False, description="If true, only include keys where both exist and differ"),
    top_n: int = Query(default=25, ge=1, le=200, description="How many items to return in each 'top' list"),
    db: Session = Depends(get_db),
):
    """Return a compact dashboard-style breakdown of effective-datapoint diffs.

    This is the summary companion to `GET /effective-datapoints:diff` and is
    intended to power UI widgets such as:
    - top mismatches by section
    - top mismatches by filer / jurisdiction / entity
    - top XML paths with the most mismatches
    """

    filing = _ensure_filing(db, filing_id)

    # Load persisted datapoints.
    persisted: List[models.DataPoint] = (
        db.query(models.DataPoint)
        .filter(models.DataPoint.filing_id == filing_id)
        .all()
    )

    # Load config (used for mapping xpath -> section).
    try:
        config = load_config(settings.config_root, filing.config_version_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Cannot load config: {e}")

    xpath_to_section = {e.xpath: e.section for e in config.elements}

    def _infer_section(xml_path: str) -> str:
        sec = xpath_to_section.get(xml_path)
        if sec:
            return sec
        # Fallback heuristics.
        xp = xml_path or ""
        if "/FilingInfo" in xp:
            return "FilingInfo"
        if "/GeneralSection" in xp or "/General" in xp:
            return "General"
        if "/Summary" in xp:
            return "Summary"
        if "/JurisdictionSection" in xp or "/Jurisdiction" in xp:
            return "Jurisdiction"
        if "/UTPRAttribution" in xp:
            return "UTPRAttribution"
        return "Unknown"

    # Derive virtual datapoints WITHOUT suppressing keys that already exist.
    filers = db.query(models.Filer).filter(models.Filer.filing_id == filing_id).all()
    juris_rows = db.query(models.Jurisdiction).filter(models.Jurisdiction.filing_id == filing_id).all()
    entity_rows = db.query(models.ConstituentEntity).filter(models.ConstituentEntity.filing_id == filing_id).all()

    virtual: List[models.DataPoint] = derive_virtual_datapoints_from_registers(
        db=db,
        filing=filing,
        config=config,
        filers=filers,
        jurisdictions=juris_rows,
        entities=entity_rows,
        existing_datapoints=persisted,
        suppress_if_exists=False,
    )

    def _key(dp: models.DataPoint):
        return (dp.filer_code or None, dp.jurisdiction_code or None, dp.entity_code or None, dp.context_key or None, dp.xml_path)

    persisted_map = {_key(dp): dp for dp in persisted}
    virtual_map = {_key(dp): dp for dp in virtual}
    keys = set(persisted_map.keys()) | set(virtual_map.keys())

    def _match(xml_path: str, f: Optional[str], j: Optional[str], e: Optional[str]) -> bool:
        if xml_path_prefix and not (xml_path or "").startswith(xml_path_prefix):
            return False
        if filer_code and (f or None) != filer_code:
            return False
        if jurisdiction_code and (j or None) != jurisdiction_code:
            return False
        if entity_code and (e or None) != entity_code:
            return False
        return True

    def _differs(p: models.DataPoint, v: models.DataPoint) -> bool:
        if (p.value_raw or "") != (v.value_raw or ""):
            return True
        if (p.currency or "") != (v.currency or ""):
            return True
        return False

    # Aggregate helpers.
    def _bucket_key(x: Optional[str]) -> str:
        return x if x is not None and x != "" else "(none)"

    def _bump(agg: dict, dim_key: str, *, has_both: bool, differs: bool, persisted_only: bool, virtual_only: bool):
        d = agg.get(dim_key)
        if d is None:
            d = {"total": 0, "both": 0, "diff": 0, "p_only": 0, "v_only": 0}
            agg[dim_key] = d
        d["total"] += 1
        if has_both:
            d["both"] += 1
        if differs:
            d["diff"] += 1
        if persisted_only:
            d["p_only"] += 1
        if virtual_only:
            d["v_only"] += 1

    overall = {"total": 0, "both": 0, "diff": 0, "p_only": 0, "v_only": 0}
    by_section: dict = {}
    by_filer: dict = {}
    by_juris: dict = {}
    by_entity: dict = {}
    by_path: dict = {}

    for k in keys:
        f, j, e, ctx, xp = k
        if not _match(xp, f, j, e):
            continue

        p = persisted_map.get(k)
        v = virtual_map.get(k)
        has_p = p is not None
        has_v = v is not None
        has_both = has_p and has_v
        differs = _differs(p, v) if has_both else False
        p_only = has_p and not has_v
        v_only = has_v and not has_p

        # Filtering modes.
        if only_overrides and not has_both:
            continue
        if only_differences and not differs:
            continue

        overall["total"] += 1
        if has_both:
            overall["both"] += 1
        if differs:
            overall["diff"] += 1
        if p_only:
            overall["p_only"] += 1
        if v_only:
            overall["v_only"] += 1

        sec = _infer_section(xp)
        _bump(by_section, _bucket_key(sec), has_both=has_both, differs=differs, persisted_only=p_only, virtual_only=v_only)
        _bump(by_filer, _bucket_key(f), has_both=has_both, differs=differs, persisted_only=p_only, virtual_only=v_only)
        _bump(by_juris, _bucket_key(j), has_both=has_both, differs=differs, persisted_only=p_only, virtual_only=v_only)
        _bump(by_entity, _bucket_key(e), has_both=has_both, differs=differs, persisted_only=p_only, virtual_only=v_only)
        _bump(by_path, xp, has_both=has_both, differs=differs, persisted_only=p_only, virtual_only=v_only)

    def _to_buckets(agg: dict) -> List[EffectiveDataPointDiffSummaryBucket]:
        items = [
            EffectiveDataPointDiffSummaryBucket(
                key=k,
                total_keys=v["total"],
                keys_with_both=v["both"],
                differences=v["diff"],
                persisted_only=v["p_only"],
                virtual_only=v["v_only"],
            )
            for k, v in agg.items()
        ]
        items.sort(key=lambda x: (x.differences, x.keys_with_both, x.total_keys, x.key), reverse=True)
        return items[:top_n]

    def _to_path_buckets(agg: dict) -> List[EffectiveDataPointDiffPathBucket]:
        items = [
            EffectiveDataPointDiffPathBucket(
                xml_path=k,
                total_keys=v["total"],
                keys_with_both=v["both"],
                differences=v["diff"],
            )
            for k, v in agg.items() if v.get("diff", 0) > 0
        ]
        items.sort(key=lambda x: (x.differences, x.keys_with_both, x.total_keys, x.xml_path), reverse=True)
        return items[:top_n]

    return EffectiveDataPointDiffSummaryResult(
        generated_at=datetime.utcnow(),
        count_keys=overall["total"],
        keys_with_both=overall["both"],
        differences_count=overall["diff"],
        persisted_only_count=overall["p_only"],
        virtual_only_count=overall["v_only"],
        by_section=_to_buckets(by_section),
        by_filer=_to_buckets(by_filer),
        by_jurisdiction=_to_buckets(by_juris),
        by_entity=_to_buckets(by_entity),
        top_diff_paths=_to_path_buckets(by_path),
    )
