from __future__ import annotations

from datetime import datetime
from typing import Optional, Dict, Any, List, Tuple

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.core.settings import settings
from app.db.session import get_db
from app.db import models
from app.api.schemas import (
    ReconciliationSummaryResult,
    ReconciliationGroupCounts,
    JurisdictionCoverageBucket,
    MissingDatapointResult,
    MissingDatapointItem,
    RegisterCoverageResult,
    RegisterCoverageIssue,
    ExpectedDatapointResult,
    ExpectedDatapointItem,
    JurisdictionEntityCompletenessResult,
    JurisdictionEntityCompletenessRow,
    JurisdictionEntityCompletenessEntity,

    PackCompletenessDashboardResult,
)
from app.services.config_loader import load_config
from app.services.reconciliation_sets import load_reconciliation_sets, default_reconciliation_sets
from app.services.expected_datapoints import (
    build_expected_datapoints_for_set,
    compute_jurisdiction_entity_completeness,
    pivot_expected_datapoints,
    jurisdiction_applies_to_set,
    normalize_computation_mode,
    compute_pack_completeness_dashboard_cached,
)


router = APIRouter(prefix="/filings/{filing_id}/reconciliation", tags=["reconciliation"])


def _ensure_filing(db: Session, filing_id: str) -> models.Filing:
    filing = db.get(models.Filing, filing_id)
    if filing is None:
        raise HTTPException(status_code=404, detail="Filing not found")
    return filing


def _get_validation_run(db: Session, filing_id: str, run_id: Optional[str]) -> models.ValidationRun:
    if run_id:
        run = db.get(models.ValidationRun, run_id)
        if run is None or run.filing_id != filing_id:
            raise HTTPException(status_code=404, detail="Validation run not found")
        return run

    run = (
        db.query(models.ValidationRun)
        .filter(models.ValidationRun.filing_id == filing_id)
        .filter(models.ValidationRun.status == "completed")
        .order_by(models.ValidationRun.completed_at.desc().nullslast(), models.ValidationRun.started_at.desc())
        .first()
    )
    if run is None:
        raise HTTPException(
            status_code=400,
            detail="No completed validation run found for this filing. Create one via POST /filings/{filing_id}/validation-runs.",
        )
    return run


def _load_config_for_filing(filing: models.Filing):
    try:
        return load_config(settings.config_root, filing.config_version_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Cannot load config: {e}")


def _load_reconciliation_sets_for_filing(filing: models.Filing):
    sets = load_reconciliation_sets(settings.config_root, filing.config_version_id)
    if not sets:
        sets = default_reconciliation_sets()
    return sets


def _get_set_or_404(filing: models.Filing, set_id: str):
    sets = _load_reconciliation_sets_for_filing(filing)
    for s in sets:
        if (s.set_id or "") == set_id:
            return s
    raise HTTPException(status_code=404, detail=f"Reconciliation set not found: {set_id}")


def _elements_by_xpath(config) -> Dict[str, Any]:
    m: Dict[str, Any] = {}
    for e in getattr(config, "elements", []) or []:
        xp = getattr(e, "xpath", None)
        if xp:
            m[xp] = e
    return m


def _group_issue_counts(issues: List[models.ValidationIssue], key_fn) -> List[ReconciliationGroupCounts]:
    agg: Dict[str, Dict[str, int]] = {}
    for iss in issues:
        key = key_fn(iss) or "<none>"
        if key not in agg:
            agg[key] = {"BLOCKING": 0, "WARNING": 0, "INFO": 0, "TOTAL": 0}
        sev = (iss.severity or "").upper() or "INFO"
        if sev not in ("BLOCKING", "WARNING", "INFO"):
            sev = "INFO"
        agg[key][sev] += 1
        agg[key]["TOTAL"] += 1

    buckets = [
        ReconciliationGroupCounts(
            key=k,
            blocking=v["BLOCKING"],
            warning=v["WARNING"],
            info=v["INFO"],
            total=v["TOTAL"],
        )
        for k, v in agg.items()
    ]
    buckets.sort(key=lambda b: (b.blocking, b.warning, b.total), reverse=True)
    return buckets


def _is_missing_required_issue(iss: models.ValidationIssue) -> bool:
    rid = (iss.rule_id or "").upper()
    return rid.startswith("REQ")


def _infer_scope_from_issue(iss: models.ValidationIssue) -> str:
    # Note: jurisdiction-scoped requiredness can include filer_code when a
    # responsible filer exists; scope is still "jurisdiction".
    if iss.entity_code:
        return "entity"
    if iss.jurisdiction_code:
        return "jurisdiction"
    if iss.filer_code:
        return "filer"
    return "filing"


def _compute_jurisdiction_coverage(
    *,
    db: Session,
    filing: models.Filing,
    config: Any,
) -> List[JurisdictionCoverageBucket]:
    """Compute entity-output coverage per jurisdiction.

    This is deliberately conservative and *engine-agnostic*: it checks whether
    the filing has **any entity-scoped datapoints** under the Jurisdiction
    section (often CEComputation outputs) for the entities expected in each
    jurisdiction.
    """

    elements = _elements_by_xpath(config)
    xpath_to_section = {xp: (getattr(e, "section", None) or "") for xp, e in elements.items()}

    entities = db.query(models.ConstituentEntity).filter(models.ConstituentEntity.filing_id == filing.id).all()
    ent_juris: Dict[str, str] = {
        (e.entity_code or "").strip(): (e.jurisdiction_code or "").strip()
        for e in entities
        if (e.entity_code or "").strip()
    }

    jurisdictions = db.query(models.Jurisdiction).filter(models.Jurisdiction.filing_id == filing.id).all()
    expected_juris = sorted({j.jurisdiction_code for j in jurisdictions if j.jurisdiction_code})
    if not expected_juris:
        # Fall back: infer from datapoints.
        expected_juris = sorted({dp.jurisdiction_code for dp in db.query(models.DataPoint).filter(models.DataPoint.filing_id == filing.id).all() if dp.jurisdiction_code})

    expected_entities_by_juris: Dict[str, List[str]] = {j: [] for j in expected_juris}
    for e in entities:
        if not e.included_in_gir:
            continue
        j = (e.jurisdiction_code or "").strip()
        if j and j in expected_entities_by_juris:
            expected_entities_by_juris[j].append(e.entity_code)

    # Load datapoints once.
    dps = db.query(models.DataPoint).filter(models.DataPoint.filing_id == filing.id).all()

    juris_output_rows: Dict[str, int] = {j: 0 for j in expected_juris}
    entity_output_rows: Dict[str, int] = {j: 0 for j in expected_juris}
    entities_with_outputs: Dict[str, set] = {j: set() for j in expected_juris}

    for dp in dps:
        sec = xpath_to_section.get(dp.xml_path or "", "")
        if sec != "Jurisdiction":
            continue

        # Determine jurisdiction for the datapoint.
        j = (dp.jurisdiction_code or "").strip()
        if not j and dp.entity_code:
            j = ent_juris.get((dp.entity_code or "").strip(), "")
        if not j or j not in juris_output_rows:
            continue

        juris_output_rows[j] += 1
        if dp.entity_code:
            entity_output_rows[j] += 1
            entities_with_outputs[j].add((dp.entity_code or "").strip())

    responsible_by_juris = {
        j.jurisdiction_code: (j.responsible_filer_code or None)
        for j in jurisdictions
        if j.jurisdiction_code
    }

    buckets: List[JurisdictionCoverageBucket] = []
    for j in expected_juris:
        expected_entities = sorted({ec for ec in expected_entities_by_juris.get(j, []) if ec})
        got_entities = sorted({ec for ec in entities_with_outputs.get(j, set()) if ec})

        buckets.append(
            JurisdictionCoverageBucket(
                jurisdiction_code=j,
                responsible_filer_code=responsible_by_juris.get(j),
                expected_included_entities=len(expected_entities),
                entities_with_outputs=len(got_entities),
                missing_entity_outputs=max(0, len(expected_entities) - len(got_entities)),
                jurisdiction_output_rows=juris_output_rows.get(j, 0),
                entity_output_rows=entity_output_rows.get(j, 0),
            )
        )

    buckets.sort(key=lambda b: (b.missing_entity_outputs, b.expected_included_entities, b.jurisdiction_code), reverse=True)
    return buckets


@router.get("/summary", response_model=ReconciliationSummaryResult)
def reconciliation_summary(
    filing_id: str,
    run_id: Optional[str] = Query(default=None, description="Validation run id (defaults to latest completed run)"),
    top_n: int = Query(default=25, ge=1, le=200),
    db: Session = Depends(get_db),
):
    filing = _ensure_filing(db, filing_id)
    run = _get_validation_run(db, filing_id, run_id)
    config = _load_config_for_filing(filing)

    issues: List[models.ValidationIssue] = (
        db.query(models.ValidationIssue)
        .filter(models.ValidationIssue.validation_run_id == run.id)
        .all()
    )

    sev_counts = {"BLOCKING": 0, "WARNING": 0, "INFO": 0, "TOTAL": 0}
    for iss in issues:
        sev = (iss.severity or "").upper() or "INFO"
        if sev not in ("BLOCKING", "WARNING", "INFO"):
            sev = "INFO"
        sev_counts[sev] += 1
        sev_counts["TOTAL"] += 1

    by_section = _group_issue_counts(issues, lambda i: i.section)
    by_filer = _group_issue_counts(issues, lambda i: i.filer_code)
    by_jurisdiction = _group_issue_counts(issues, lambda i: i.jurisdiction_code)
    by_entity = _group_issue_counts(issues, lambda i: i.entity_code)

    missing_required = [i for i in issues if _is_missing_required_issue(i)]
    by_missing_path = _group_issue_counts(missing_required, lambda i: i.xml_path)

    # Coverage diagnostics (engine-agnostic): expected entities per jurisdiction vs entities with any CE outputs.
    juris_coverage = _compute_jurisdiction_coverage(db=db, filing=filing, config=config)

    return ReconciliationSummaryResult(
        generated_at=datetime.utcnow(),
        filing_id=filing.id,
        validation_run_id=run.id,
        severity_counts=sev_counts,
        by_section=by_section[:top_n],
        by_filer=by_filer[:top_n],
        by_jurisdiction=by_jurisdiction[:top_n],
        by_entity=by_entity[:top_n],
        missing_required_total=len(missing_required),
        top_missing_required_paths=by_missing_path[:top_n],
        jurisdiction_coverage=juris_coverage[:top_n],
    )


@router.get("/missing-datapoints", response_model=MissingDatapointResult)
def missing_datapoints(
    filing_id: str,
    run_id: Optional[str] = Query(default=None, description="Validation run id (defaults to latest completed run)"),
    severity: Optional[str] = Query(default="BLOCKING", description="Severity filter (default BLOCKING)"),
    limit: int = Query(default=2000, ge=1, le=20000),
    offset: int = Query(default=0, ge=0),
    db: Session = Depends(get_db),
):
    filing = _ensure_filing(db, filing_id)
    run = _get_validation_run(db, filing_id, run_id)
    config = _load_config_for_filing(filing)
    elements = _elements_by_xpath(config)

    q = (
        db.query(models.ValidationIssue)
        .filter(models.ValidationIssue.validation_run_id == run.id)
        .filter(models.ValidationIssue.rule_id.ilike("REQ%"))
    )
    if severity:
        q = q.filter(models.ValidationIssue.severity == severity)

    rows = (
        q.order_by(models.ValidationIssue.section.asc(), models.ValidationIssue.xml_path.asc())
        .offset(offset)
        .limit(limit)
        .all()
    )

    items: List[MissingDatapointItem] = []
    for iss in rows:
        e = elements.get(iss.xml_path or "")
        tax_label = getattr(e, "tax_label", None) if e is not None else None
        allowed = list(getattr(e, "allowed_values", []) or []) if e is not None else []
        items.append(
            MissingDatapointItem(
                severity=iss.severity,
                error_number=int(iss.error_number) if iss.error_number is not None else None,
                rule_id=iss.rule_id,
                section=iss.section,
                xml_path=iss.xml_path or "",
                scope=_infer_scope_from_issue(iss),
                tax_label=tax_label,
                allowed_values=allowed,
                filer_code=iss.filer_code,
                jurisdiction_code=iss.jurisdiction_code,
                entity_code=iss.entity_code,
                context_key=iss.context_key,
                message=iss.message,
                how_to_fix=iss.how_to_fix,
            )
        )

    return MissingDatapointResult(
        generated_at=datetime.utcnow(),
        filing_id=filing.id,
        validation_run_id=run.id,
        count=len(items),
        items=items,
    )


@router.get("/register-coverage", response_model=RegisterCoverageResult)
def register_coverage(
    filing_id: str,
    db: Session = Depends(get_db),
):
    filing = _ensure_filing(db, filing_id)
    filers = db.query(models.Filer).filter(models.Filer.filing_id == filing.id).all()
    entities = db.query(models.ConstituentEntity).filter(models.ConstituentEntity.filing_id == filing.id).all()
    jurisdictions = db.query(models.Jurisdiction).filter(models.Jurisdiction.filing_id == filing.id).all()

    filer_codes = {f.filer_code for f in filers if f.filer_code}
    roles = [(f.filer_code, (f.role or "").upper()) for f in filers]

    upe_count = sum(1 for _, r in roles if r == "UPE")
    pope_count = sum(1 for _, r in roles if r == "POPE")
    designated_count = sum(1 for _, r in roles if r in ("DESIGNATED", "DESIGNATED_FILER", "DESIGNATEDFILER"))

    included_entities = [e for e in entities if e.included_in_gir]
    unassigned_included = [e for e in included_entities if not (e.filed_by_filer_code or "").strip()]
    invalid_assigned = [e for e in included_entities if (e.filed_by_filer_code or "").strip() and (e.filed_by_filer_code or "").strip() not in filer_codes]

    missing_entity_tin = [e for e in included_entities if not (e.tin or "").strip()]

    invalid_responsible = [j for j in jurisdictions if (j.responsible_filer_code or "").strip() and (j.responsible_filer_code or "").strip() not in filer_codes]
    missing_responsible = [j for j in jurisdictions if not (j.responsible_filer_code or "").strip()]

    issues: List[RegisterCoverageIssue] = []
    if upe_count != 1:
        issues.append(RegisterCoverageIssue(
            severity="BLOCKING",
            area="filers",
            code="upe_count",
            message=f"Expected exactly 1 UPE filer, found {upe_count}.",
        ))
    if pope_count == 0:
        # Not strictly required, but helpful for multi-filer governance.
        issues.append(RegisterCoverageIssue(
            severity="INFO",
            area="filers",
            code="no_pope",
            message="No POPE filer rows found (this is OK if the group has no POPE filings).",
        ))
    if unassigned_included:
        issues.append(RegisterCoverageIssue(
            severity="BLOCKING",
            area="entities",
            code="missing_filed_by",
            message=f"{len(unassigned_included)} included entities are missing filed_by_filer_code.",
        ))
    if invalid_assigned:
        issues.append(RegisterCoverageIssue(
            severity="BLOCKING",
            area="entities",
            code="invalid_filed_by",
            message=f"{len(invalid_assigned)} included entities reference an unknown filer_code in filed_by_filer_code.",
        ))
    if invalid_responsible:
        issues.append(RegisterCoverageIssue(
            severity="WARNING",
            area="jurisdictions",
            code="invalid_responsible_filer",
            message=f"{len(invalid_responsible)} jurisdictions reference an unknown responsible_filer_code.",
        ))
    if missing_responsible:
        issues.append(RegisterCoverageIssue(
            severity="INFO",
            area="jurisdictions",
            code="missing_responsible_filer",
            message=f"{len(missing_responsible)} jurisdictions have no responsible_filer_code (the validator will accept any filer-scoped datapoint for that jurisdiction).",
        ))
    if missing_entity_tin:
        issues.append(RegisterCoverageIssue(
            severity="INFO",
            area="entities",
            code="missing_entity_tin",
            message=f"{len(missing_entity_tin)} included entities have no TIN in the register (may be required for CorporateStructure depending on your config).",
        ))

    return RegisterCoverageResult(
        generated_at=datetime.utcnow(),
        filing_id=filing.id,
        filers={
            "count": len(filers),
            "upe_count": upe_count,
            "pope_count": pope_count,
            "designated_count": designated_count,
        },
        entities={
            "count": len(entities),
            "included_count": len(included_entities),
            "unassigned_included_count": len(unassigned_included),
            "invalid_assigned_count": len(invalid_assigned),
            "missing_tin_count": len(missing_entity_tin),
        },
        jurisdictions={
            "count": len(jurisdictions),
            "missing_responsible_filer_count": len(missing_responsible),
            "invalid_responsible_filer_count": len(invalid_responsible),
        },
        issues=issues,
    )


@router.get("/active-sets")
def active_reconciliation_sets(
    filing_id: str,
    set_id: Optional[str] = Query(default=None, description="Optional set id to evaluate (defaults to all sets)"),
    db: Session = Depends(get_db),
):
    """Evaluate reconciliation set *activation* per jurisdiction.

    Sprint 2.3 adds mode-aware set activation. A set can specify:
      - computation_mode_in (e.g., ["full_etr", "safe_harbour", ...])
      - qdmt_applicable (true/false)

    This endpoint helps the UI / debugging answer: "Which packs are active for each jurisdiction?".
    """

    filing = _ensure_filing(db, filing_id)
    sets = _load_reconciliation_sets_for_filing(filing)
    if set_id:
        sets = [_get_set_or_404(filing, set_id)]

    juris_rows = db.query(models.Jurisdiction).filter(models.Jurisdiction.filing_id == filing.id).all()
    if not juris_rows:
        return {
            "generated_at": datetime.utcnow().isoformat() + "Z",
            "filing_id": filing.id,
            "set_count": len(sets),
            "jurisdiction_count": 0,
            "jurisdictions": [],
            "note": "No jurisdiction register rows found; set activation cannot be evaluated without /jurisdictions register data.",
        }

    set_stats: Dict[str, Dict[str, int]] = {s.set_id: {"active": 0, "inactive": 0} for s in sets}
    juris_out: List[Dict[str, Any]] = []
    for j in juris_rows:
        active: List[str] = []
        inactive: List[str] = []
        for s in sets:
            # Only jurisdiction/entity-scoped sets use jurisdiction activation.
            scope = (s.scope or "").strip().lower()
            if scope in ("jurisdiction", "entity"):
                if jurisdiction_applies_to_set(s, j):
                    active.append(s.set_id)
                    set_stats[s.set_id]["active"] += 1
                else:
                    inactive.append(s.set_id)
                    set_stats[s.set_id]["inactive"] += 1
            else:
                # Filing/filer scoped sets are considered globally active.
                active.append(s.set_id)
                set_stats[s.set_id]["active"] += 1

        juris_out.append(
            {
                "jurisdiction_code": j.jurisdiction_code,
                "responsible_filer_code": j.responsible_filer_code,
                "computation_mode": j.computation_mode,
                "computation_mode_norm": normalize_computation_mode(j.computation_mode),
                "qdmt_applicable": j.qdmt_applicable,
                "active_set_ids": sorted(active),
                "inactive_set_ids": sorted(inactive),
            }
        )

    juris_out.sort(key=lambda r: (r.get("jurisdiction_code") or ""))

    return {
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "filing_id": filing.id,
        "set_count": len(sets),
        "jurisdiction_count": len(juris_out),
        "set_stats": {k: v for k, v in set_stats.items()},
        "jurisdictions": juris_out,
    }


@router.get("/expected-datapoints", response_model=ExpectedDatapointResult)
def expected_datapoints(
    filing_id: str,
    set_id: str = Query(default="JURIS_CE_REQUIRED", description="Reconciliation set id"),
    include_present_values: bool = Query(default=False, description="Include present value/currency in response"),
    only_missing: bool = Query(default=False, description="Return only missing expected datapoints"),
    db: Session = Depends(get_db),
):
    """Compute expected datapoints (from config) expanded by registers.

    This endpoint is intended to power a UI 'missing vs present matrix' view.
    """

    filing = _ensure_filing(db, filing_id)
    config = _load_config_for_filing(filing)
    s = _get_set_or_404(filing, set_id)

    res = build_expected_datapoints_for_set(
        db=db,
        filing=filing,
        config=config,
        s=s,
        include_present_values=include_present_values,
        only_missing=only_missing,
    )

    # Pydantic will validate the items; add metadata fields.
    return ExpectedDatapointResult(
        generated_at=datetime.utcnow(),
        filing_id=filing.id,
        set_id=res["set_id"],
        set_description=res.get("set_description"),
        count=int(res.get("count") or 0),
        items=[ExpectedDatapointItem(**it) for it in (res.get("items") or [])],
    )


@router.get("/expected-datapoints:pivot")
def expected_datapoints_pivot(
    filing_id: str,
    set_id: str = Query(default="JURIS_CE_REQUIRED", description="Reconciliation set id"),
    pivot: str = Query(default="auto", description="auto|jurisdiction|filer|entity|jurisdiction_entity"),
    cell: str = Query(default="status", description="status|present|missing|value"),
    max_columns: int = Query(default=200, ge=1, le=5000),
    include_present_values: bool = Query(default=False, description="Required if cell=value"),
    db: Session = Depends(get_db),
):
    """Wide/pivot view of the expected datapoints matrix.

    Sprint 2.3 adds this endpoint to make front-end grids and Excel-style
    downloads easier.
    """

    filing = _ensure_filing(db, filing_id)
    config = _load_config_for_filing(filing)
    s = _get_set_or_404(filing, set_id)

    res = build_expected_datapoints_for_set(
        db=db,
        filing=filing,
        config=config,
        s=s,
        include_present_values=include_present_values or (cell == "value"),
        only_missing=False,
    )

    try:
        piv = pivot_expected_datapoints(items=res.get("items") or [], pivot=pivot, cell=cell, max_columns=max_columns)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    return {
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "filing_id": filing.id,
        "config_version_id": filing.config_version_id,
        "set_id": res.get("set_id"),
        "set_description": res.get("set_description"),
        **piv,
    }


@router.get("/jurisdiction-entity-output-completeness", response_model=JurisdictionEntityCompletenessResult)
def jurisdiction_entity_output_completeness(
    filing_id: str,
    set_id: str = Query(default="JURIS_CE_REQUIRED", description="Entity-scoped reconciliation set id"),
    include_entities: bool = Query(default=False, description="Include per-entity detail (can be large)"),
    db: Session = Depends(get_db),
):
    """Per-jurisdiction entity-output completeness against a required datapoint set."""

    filing = _ensure_filing(db, filing_id)
    config = _load_config_for_filing(filing)
    s = _get_set_or_404(filing, set_id)

    try:
        res = compute_jurisdiction_entity_completeness(
            db=db,
            filing=filing,
            config=config,
            s=s,
            include_entities=include_entities,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    juris_rows = []
    for jr in res.get("jurisdictions") or []:
        entities = None
        if include_entities and jr.get("entities") is not None:
            entities = [JurisdictionEntityCompletenessEntity(**e) for e in (jr.get("entities") or [])]

        juris_rows.append(
            JurisdictionEntityCompletenessRow(
                jurisdiction_code=jr["jurisdiction_code"],
                expected_entities=int(jr.get("expected_entities") or 0),
                entities_complete=int(jr.get("entities_complete") or 0),
                entities_partial=int(jr.get("entities_partial") or 0),
                entities_missing=int(jr.get("entities_missing") or 0),
                missing_datapoints_total=int(jr.get("missing_datapoints_total") or 0),
                required_datapoints_per_entity=int(jr.get("required_datapoints_per_entity") or 0),
                completion_ratio_entities=jr.get("completion_ratio_entities"),
                entities=entities,
            )
        )

    return JurisdictionEntityCompletenessResult(
        generated_at=datetime.utcnow(),
        filing_id=filing.id,
        set_id=res["set_id"],
        set_description=res.get("set_description"),
        required_datapoints_per_entity=int(res.get("required_datapoints_per_entity") or 0),
        jurisdictions=juris_rows,
    )


@router.get("/pack-completeness-dashboard", response_model=PackCompletenessDashboardResult)
def pack_completeness_dashboard(
    filing_id: str,
    set_ids: Optional[str] = Query(default=None, description="Optional comma-separated set_ids to include (defaults to all)"),
    pack_family: Optional[str] = Query(default=None, description="Optional pack_family filter (case-insensitive)"),
    pack_tags: Optional[List[str]] = Query(default=None, description="Optional pack_tags filter (all tags must match)"),
    include_inactive: bool = Query(default=False, description="Include inactive packs (activation false) in the dashboard"),
    missing_sample_n: int = Query(default=10, ge=0, le=50, description="How many missing datapoints to sample per pack"),

    jurisdiction_code: Optional[str] = Query(default=None, description="Optional ISO-2 jurisdiction_code to fetch one jurisdiction card"),
    filer_code: Optional[str] = Query(default=None, description="Optional filer_code to fetch one filer card"),
    include_filers: bool = Query(default=True, description="Include filer rows in the response (set false for faster jurisdiction-only cards)"),

    use_cache: bool = Query(default=True, description="Use watermark-based cache for dashboard computation"),
    cache_ttl_seconds: Optional[int] = Query(default=None, ge=0, le=3600, description="Override dashboard cache TTL seconds (0 disables cache)"),

    db: Session = Depends(get_db),
):
    """Multi-pack completeness dashboard.

    Returns:
    - Per-jurisdiction pack completeness (jurisdiction-scoped packs)
    - Per-jurisdiction entity-pack completeness (entity-scoped packs)
    - Per-filer pack completeness (filer-scoped packs)

    This endpoint is intended for front-end dashboards and "traffic light" views.
    """

    filing = _ensure_filing(db, filing_id)
    config = _load_config_for_filing(filing)
    sets_all = _load_reconciliation_sets_for_filing(filing)

    # Filters
    sets = list(sets_all)
    if set_ids:
        wanted = {s.strip() for s in str(set_ids).split(",") if s and s.strip()}
        sets = [s for s in sets if (s.set_id or "") in wanted]
        if not sets:
            raise HTTPException(status_code=404, detail="No reconciliation sets matched set_ids")

    if pack_family:
        fam = str(pack_family).strip().lower()
        sets = [s for s in sets if (s.pack_family or "").strip().lower() == fam]
        if not sets:
            raise HTTPException(status_code=404, detail="No reconciliation sets matched pack_family")

    if pack_tags:
        wanted_tags = {str(t).strip().lower() for t in (pack_tags or []) if str(t).strip()}
        if wanted_tags:
            def _has_all_tags(s):
                tags = {str(t).strip().lower() for t in (s.pack_tags or []) if str(t).strip()}
                return wanted_tags.issubset(tags)
            sets = [s for s in sets if _has_all_tags(s)]
            if not sets:
                raise HTTPException(status_code=404, detail="No reconciliation sets matched pack_tags")

    res = compute_pack_completeness_dashboard_cached(
        db=db,
        filing=filing,
        config=config,
        sets=sets,
        include_inactive=include_inactive,
        missing_sample_n=missing_sample_n,
        jurisdiction_codes=([jurisdiction_code] if jurisdiction_code else None),
        filer_codes=(["__none__"] if (not include_filers and not filer_code) else ([filer_code] if filer_code else None)),
        use_cache=use_cache,
        cache_ttl_seconds=cache_ttl_seconds,
    )

    return {
        "generated_at": datetime.utcnow(),
        "filing_id": filing.id,
        "config_version_id": filing.config_version_id,
        "set_count": len(sets),
        "sets": res.get("sets") or [],
        "jurisdictions": res.get("jurisdictions") or [],
        "filers": res.get("filers") or [],
    }
