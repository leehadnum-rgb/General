from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy.dialects.postgresql import insert
from datetime import datetime
from typing import List

from app.db.session import get_db
from app.db import models
from app.api.schemas import (
    FilerUpsert, ConstituentEntityUpsert, JurisdictionUpsert, BulkUpsertResult
)

router = APIRouter(prefix="/filings/{filing_id}", tags=["registers"])

def _ensure_filing(db: Session, filing_id: str) -> models.Filing:
    filing = db.get(models.Filing, filing_id)
    if filing is None:
        raise HTTPException(status_code=404, detail="Filing not found")
    return filing

@router.post("/filers:bulkUpsert", response_model=BulkUpsertResult)
def bulk_upsert_filers(filing_id: str, payload: List[FilerUpsert], db: Session = Depends(get_db)):
    _ensure_filing(db, filing_id)

    rows = []
    now = datetime.utcnow()
    for x in payload:
        rows.append({
            "filing_id": filing_id,
            "filer_code": x.filer_code,
            "legal_name": x.legal_name,
            "role": x.role,
            "jurisdiction_code": x.jurisdiction_code,
            "tin": x.tin,
            "filing_ce_role": x.filing_ce_role,
            "id_rules": x.id_rules,
            "globe_status": x.globe_status,
            "reporting_currency": x.reporting_currency,
            "scope": x.scope,
            "owner": x.owner,
            "status": x.status,
            "updated_at": now,
            "created_at": now,
        })

    stmt = insert(models.Filer).values(rows)
    update_cols = {c.name: getattr(stmt.excluded, c.name) for c in models.Filer.__table__.columns
                   if c.name not in ("id", "created_at")}
    stmt = stmt.on_conflict_do_update(
        constraint="uq_filer_filing_code",
        set_=update_cols
    )
    result = db.execute(stmt)
    db.commit()

    # Postgres doesn't distinguish inserted/updated rowcounts easily for upsert in one go.
    # We return total affected rows.
    return BulkUpsertResult(inserted=0, updated=0, total=len(rows))

@router.post("/entities:bulkUpsert", response_model=BulkUpsertResult)
def bulk_upsert_entities(filing_id: str, payload: List[ConstituentEntityUpsert], db: Session = Depends(get_db)):
    _ensure_filing(db, filing_id)

    rows = []
    now = datetime.utcnow()
    for x in payload:
        rows.append({
            "filing_id": filing_id,
            "entity_code": x.entity_code,
            "legal_name": x.legal_name,
            "jurisdiction_code": x.jurisdiction_code,
            "tin": x.tin,
            "included_in_gir": x.included_in_gir,
            "filed_by_filer_code": x.filed_by_filer_code,
            "id_rules": x.id_rules,
            "globe_status": x.globe_status,
            "parent_entity_code": x.parent_entity_code,
            "ownership_type": x.ownership_type,
            "ownership_percentage": x.ownership_percentage,
            "owner_tin_override": x.owner_tin_override,
            "updated_at": now,
            "created_at": now,
        })

    stmt = insert(models.ConstituentEntity).values(rows)
    update_cols = {c.name: getattr(stmt.excluded, c.name) for c in models.ConstituentEntity.__table__.columns
                   if c.name not in ("id", "created_at")}
    stmt = stmt.on_conflict_do_update(
        constraint="uq_entity_filing_code",
        set_=update_cols
    )
    db.execute(stmt)
    db.commit()
    return BulkUpsertResult(inserted=0, updated=0, total=len(rows))

@router.post("/jurisdictions:bulkUpsert", response_model=BulkUpsertResult)
def bulk_upsert_jurisdictions(filing_id: str, payload: List[JurisdictionUpsert], db: Session = Depends(get_db)):
    _ensure_filing(db, filing_id)

    rows = []
    now = datetime.utcnow()
    for x in payload:
        rows.append({
            "filing_id": filing_id,
            "jurisdiction_code": x.jurisdiction_code,
            "local_currency": x.local_currency,
            "responsible_filer_code": x.responsible_filer_code,
            "computation_mode": x.computation_mode,
            "qdmt_applicable": x.qdmt_applicable,
            "status": x.status,
            "notes": x.notes,
            "updated_at": now,
            "created_at": now,
        })

    stmt = insert(models.Jurisdiction).values(rows)
    update_cols = {c.name: getattr(stmt.excluded, c.name) for c in models.Jurisdiction.__table__.columns
                   if c.name not in ("id", "created_at")}
    stmt = stmt.on_conflict_do_update(
        constraint="uq_juris_filing_code",
        set_=update_cols
    )
    db.execute(stmt)
    db.commit()
    return BulkUpsertResult(inserted=0, updated=0, total=len(rows))
