from fastapi import APIRouter, Depends, HTTPException, Query
from app.core.settings import settings
from app.services.config_loader import list_config_versions, load_config_meta, load_error_codes
from app.services.reconciliation_sets import load_reconciliation_sets, default_reconciliation_sets
from app.api.schemas import OecdErrorCodesResponse, OecdErrorCodeRead

router = APIRouter(prefix="/config", tags=["config"])

@router.get("/versions")
def get_versions():
    return {"versions": list_config_versions(settings.config_root)}

@router.get("/versions/{config_version_id}")
def get_version_meta(config_version_id: str):
    try:
        meta = load_config_meta(settings.config_root, config_version_id)
        return meta
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Config version not found")



@router.get("/versions/{config_version_id}/error-codes", response_model=OecdErrorCodesResponse)
def get_error_codes(
    config_version_id: str,
    section: str | None = Query(default=None, description="Optional filter by OECD catalogue section (e.g., 'File errors')"),
):
    """Return the OECD GIR error-code catalogue for a config version.

    This is loaded from `config/<version>/error_codes.json` and is intended for UIs to render
    friendly guidance next to `error_number` values produced by the validation engine.
    """
    try:
        codes = load_error_codes(settings.config_root, config_version_id)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Config version not found")

    if section:
        want = section.strip().lower()
        codes = [c for c in codes if (c.get("section") or "").strip().lower() == want]

    sections: dict[str, int] = {}
    for c in codes:
        s = (c.get("section") or "Unknown").strip() or "Unknown"
        sections[s] = sections.get(s, 0) + 1

    return {
        "config_version_id": config_version_id,
        "count": len(codes),
        "sections": sections,
        "codes": codes,
    }


@router.get("/versions/{config_version_id}/error-codes/{number}", response_model=OecdErrorCodeRead)
def get_error_code_detail(config_version_id: str, number: int):
    """Return a single OECD error code entry by number."""
    try:
        codes = load_error_codes(settings.config_root, config_version_id)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Config version not found")

    for c in codes:
        if int(c.get("number")) == int(number):
            return c
    raise HTTPException(status_code=404, detail="Error code not found")


@router.get("/versions/{config_version_id}/reconciliation-sets")
def get_reconciliation_sets(config_version_id: str):
    """List reconciliation set definitions for a config version.

    These sets drive the Sprint 2.2 expected-datapoints matrix.
    """
    try:
        sets = load_reconciliation_sets(settings.config_root, config_version_id)
        if not sets:
            sets = default_reconciliation_sets()
        return {
            "config_version_id": config_version_id,
            "count": len(sets),
            "sets": [
                {
                    "set_id": s.set_id,
                    "description": s.description,
                    "section": s.section,
                    "scope": s.scope,
                    "xpaths": s.xpaths,
                    "xpath_includes": s.xpath_includes,
                    "xpath_excludes": s.xpath_excludes,
                    "required_only": s.required_only,
                    "exclude_repeatable": s.exclude_repeatable,
                    "computation_mode_in": s.computation_mode_in,
                    "qdmt_applicable": s.qdmt_applicable,
                    "pack_family": s.pack_family,
                    "pack_variant": s.pack_variant,
                    "pack_tags": s.pack_tags,
                    "treat_included_as_required": s.treat_included_as_required,
                }
                for s in sets
            ],
        }
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Config version not found")
