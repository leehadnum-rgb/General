from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from datetime import datetime
from typing import Optional, List, Dict, Any, Tuple
from hashlib import sha1
import io
import csv
import json
import zipfile

from starlette.responses import StreamingResponse, Response

from app.db.session import get_db
from app.db import models
from app.core.settings import settings
from app.services.config_loader import load_config
from app.services.validation_engine import derive_virtual_datapoints_from_registers
from app.services.reconciliation_sets import load_reconciliation_sets, default_reconciliation_sets
from app.services.expected_datapoints import (
    build_expected_datapoints_for_set,
    compute_jurisdiction_entity_completeness,
    pivot_expected_datapoints,
    compute_pack_completeness_dashboard_cached,
)



router = APIRouter(prefix="/filings/{filing_id}/exports", tags=["exports"])


def _ensure_filing(db: Session, filing_id: str) -> models.Filing:
    filing = db.get(models.Filing, filing_id)
    if filing is None:
        raise HTTPException(status_code=404, detail="Filing not found")
    return filing


def _get_validation_run(db: Session, filing_id: str, run_id: Optional[str]) -> models.ValidationRun:
    """Return the specified run or the latest completed run for a filing."""
    if run_id:
        run = db.get(models.ValidationRun, run_id)
        if run is None or run.filing_id != filing_id:
            raise HTTPException(status_code=404, detail="Validation run not found")
        return run

    run = (
        db.query(models.ValidationRun)
        .filter(models.ValidationRun.filing_id == filing_id, models.ValidationRun.status == "completed")
        .order_by(models.ValidationRun.completed_at.desc().nullslast(), models.ValidationRun.started_at.desc())
        .first()
    )
    if run is None:
        raise HTTPException(status_code=404, detail="No completed validation run found for this filing")
    return run


def _virtual_id(dp: models.DataPoint) -> str:
    key = f"{dp.filer_code or ''}|{dp.jurisdiction_code or ''}|{dp.entity_code or ''}|{dp.context_key or ''}|{dp.xml_path or ''}"
    h = sha1(key.encode("utf-8")).hexdigest()[:16].upper()
    return f"V-{h}"


def _load_effective_datapoints(
    db: Session,
    filing: models.Filing,
) -> Tuple[Any, List[models.DataPoint], List[models.DataPoint]]:
    """Return (config, persisted, virtual_effective).

    `virtual_effective` is derived from registers and *suppresses* keys that
    already exist as persisted datapoints (persisted wins). This matches what
    the validation engine uses as its effective dataset.
    """

    try:
        config = load_config(settings.config_root, filing.config_version_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Cannot load config: {e}")

    persisted: List[models.DataPoint] = (
        db.query(models.DataPoint)
        .filter(models.DataPoint.filing_id == filing.id)
        .all()
    )

    filers = db.query(models.Filer).filter(models.Filer.filing_id == filing.id).all()
    juris_rows = db.query(models.Jurisdiction).filter(models.Jurisdiction.filing_id == filing.id).all()
    entity_rows = db.query(models.ConstituentEntity).filter(models.ConstituentEntity.filing_id == filing.id).all()

    virtual: List[models.DataPoint] = derive_virtual_datapoints_from_registers(
        db=db,
        filing=filing,
        config=config,
        filers=filers,
        jurisdictions=juris_rows,
        entities=entity_rows,
        existing_datapoints=persisted,
        suppress_if_exists=True,
    )

    return config, persisted, virtual


def _load_reconciliation_sets_for_filing(filing: models.Filing):
    sets = load_reconciliation_sets(settings.config_root, filing.config_version_id)
    if not sets:
        sets = default_reconciliation_sets()
    return sets


def _get_set_or_404(filing: models.Filing, set_id: str):
    for s in _load_reconciliation_sets_for_filing(filing):
        if (s.set_id or "") == set_id:
            return s
    raise HTTPException(status_code=404, detail=f"Reconciliation set not found: {set_id}")


def _filter_datapoints(
    persisted: List[models.DataPoint],
    virtual: List[models.DataPoint],
    *,
    xml_path_prefix: Optional[str],
    filer_code: Optional[str],
    jurisdiction_code: Optional[str],
    entity_code: Optional[str],
) -> List[Dict[str, Any]]:
    items: List[Dict[str, Any]] = []

    def _match(dp: models.DataPoint) -> bool:
        if xml_path_prefix and not (dp.xml_path or "").startswith(xml_path_prefix):
            return False
        if filer_code and (dp.filer_code or None) != filer_code:
            return False
        if jurisdiction_code and (dp.jurisdiction_code or None) != jurisdiction_code:
            return False
        if entity_code and (dp.entity_code or None) != entity_code:
            return False
        return True

    for dp in persisted:
        if not _match(dp):
            continue
        items.append({
            "id": dp.id,
            "filer_code": dp.filer_code,
            "jurisdiction_code": dp.jurisdiction_code,
            "entity_code": dp.entity_code,
            "context_key": dp.context_key,
            "xml_path": dp.xml_path,
            "value_raw": dp.value_raw,
            "value_numeric": str(dp.value_numeric) if dp.value_numeric is not None else None,
            "value_date": dp.value_date.isoformat() if dp.value_date is not None else None,
            "currency": dp.currency,
            "source": dp.source,
            "source_system": dp.source_system,
            "notes": dp.notes,
            "updated_at": dp.updated_at.isoformat() if dp.updated_at is not None else None,
            "is_virtual": False,
        })

    for dp in virtual:
        if not _match(dp):
            continue
        items.append({
            "id": _virtual_id(dp),
            "filer_code": dp.filer_code,
            "jurisdiction_code": dp.jurisdiction_code,
            "entity_code": dp.entity_code,
            "context_key": dp.context_key,
            "xml_path": dp.xml_path,
            "value_raw": dp.value_raw,
            "value_numeric": str(dp.value_numeric) if dp.value_numeric is not None else None,
            "value_date": dp.value_date.isoformat() if dp.value_date is not None else None,
            "currency": dp.currency,
            "source": dp.source,
            "source_system": dp.source_system,
            "notes": dp.notes,
            "updated_at": dp.updated_at.isoformat() if dp.updated_at is not None else None,
            "is_virtual": True,
        })

    # Stable ordering for exports.
    items.sort(key=lambda x: (
        x["xml_path"] or "",
        x["filer_code"] or "",
        x["jurisdiction_code"] or "",
        x["entity_code"] or "",
        x["context_key"] or "",
        "1" if x["is_virtual"] else "0",
    ))
    return items


def _csv_generator(rows: List[Dict[str, Any]], *, filing_id: str, config_version_id: str):
    """Yield CSV text in chunks."""
    output = io.StringIO()
    writer = csv.writer(output)

    header = [
        "filing_id",
        "config_version_id",
        "filer_code",
        "jurisdiction_code",
        "entity_code",
        "context_key",
        "xml_path",
        "value_raw",
        "currency",
        "source",
        "source_system",
        "notes",
        "is_virtual",
        "updated_at",
    ]
    writer.writerow(header)
    yield output.getvalue()
    output.seek(0)
    output.truncate(0)

    for r in rows:
        writer.writerow([
            filing_id,
            config_version_id,
            r.get("filer_code") or "",
            r.get("jurisdiction_code") or "",
            r.get("entity_code") or "",
            r.get("context_key") or "",
            r.get("xml_path") or "",
            r.get("value_raw") or "",
            r.get("currency") or "",
            r.get("source") or "",
            r.get("source_system") or "",
            (r.get("notes") or "").replace("\n", " ").strip(),
            "1" if r.get("is_virtual") else "0",
            r.get("updated_at") or "",
        ])
        yield output.getvalue()
        output.seek(0)
        output.truncate(0)


def _issues_to_csv(issues: List[models.ValidationIssue]) -> str:
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "severity",
        "error_number",
        "rule_id",
        "section",
        "xml_path",
        "message",
        "how_to_fix",
        "filer_code",
        "jurisdiction_code",
        "entity_code",
        "context_key",
        "created_at",
    ])
    for iss in issues:
        writer.writerow([
            iss.severity,
            iss.error_number or "",
            iss.rule_id or "",
            iss.section or "",
            iss.xml_path or "",
            (iss.message or "").replace("\n", " ").strip(),
            (iss.how_to_fix or "").replace("\n", " ").strip(),
            iss.filer_code or "",
            iss.jurisdiction_code or "",
            iss.entity_code or "",
            iss.context_key or "",
            iss.created_at.isoformat() if iss.created_at else "",
        ])
    return output.getvalue()


def _compute_effective_diff_summary(
    *,
    filing: models.Filing,
    config: Any,
    persisted: List[models.DataPoint],
    db: Session,
    top_n: int = 25,
) -> Dict[str, Any]:
    """Compute a compact diff summary between persisted and derived datapoints.

    NOTE: This is a report-oriented summary. It is not intended to be a perfect
    replacement for the full /effective-datapoints:diff endpoint.
    """

    # Map xpath -> section from config elements.
    xpath_to_section: Dict[str, str] = {}
    try:
        for e in config.elements:
            xpath_to_section[getattr(e, "xpath", None) or e.get("xpath")] = getattr(e, "section", None) or e.get("section")
    except Exception:
        # tolerate unexpected config shapes
        pass

    def _infer_section(xml_path: str) -> str:
        sec = xpath_to_section.get(xml_path)
        if sec:
            return sec
        xp = xml_path or ""
        if "/FilingInfo" in xp:
            return "FilingInfo"
        if "/GeneralSection" in xp or "/General" in xp:
            return "General"
        if "/Summary" in xp:
            return "Summary"
        if "/JurisdictionSection" in xp or "/Jurisdiction" in xp:
            return "Jurisdiction"
        if "/UTPRAttribution" in xp:
            return "UTPRAttribution"
        return "Unknown"

    # Derive virtual datapoints WITHOUT suppressing keys that already exist
    filers = db.query(models.Filer).filter(models.Filer.filing_id == filing.id).all()
    juris_rows = db.query(models.Jurisdiction).filter(models.Jurisdiction.filing_id == filing.id).all()
    entity_rows = db.query(models.ConstituentEntity).filter(models.ConstituentEntity.filing_id == filing.id).all()

    virtual_all: List[models.DataPoint] = derive_virtual_datapoints_from_registers(
        db=db,
        filing=filing,
        config=config,
        filers=filers,
        jurisdictions=juris_rows,
        entities=entity_rows,
        existing_datapoints=persisted,
        suppress_if_exists=False,
    )

    def _key(dp: models.DataPoint):
        return (dp.filer_code or None, dp.jurisdiction_code or None, dp.entity_code or None, dp.context_key or None, dp.xml_path)

    persisted_map = {_key(dp): dp for dp in persisted}
    virtual_map = {_key(dp): dp for dp in virtual_all}
    keys = set(persisted_map.keys()) | set(virtual_map.keys())

    persisted_only = 0
    virtual_only = 0
    both = 0
    differences = 0

    # Buckets
    by_section: Dict[str, int] = {}
    by_filer: Dict[str, int] = {}
    by_juris: Dict[str, int] = {}
    by_entity: Dict[str, int] = {}
    by_path: Dict[str, int] = {}

    def _norm(v: Any) -> str:
        if v is None:
            return ""
        return str(v)

    for k in keys:
        p = persisted_map.get(k)
        v = virtual_map.get(k)
        if p and not v:
            persisted_only += 1
            continue
        if v and not p:
            virtual_only += 1
            continue
        both += 1

        # Compare "meaningful" fields
        differs = (_norm(p.value_raw) != _norm(v.value_raw)) or (_norm(p.currency) != _norm(v.currency))
        if not differs:
            continue

        differences += 1

        filer, juris, entity, _ctx, xpath = k
        sec = _infer_section(xpath)
        by_section[sec] = by_section.get(sec, 0) + 1
        by_filer[filer or ""] = by_filer.get(filer or "", 0) + 1
        by_juris[juris or ""] = by_juris.get(juris or "", 0) + 1
        by_entity[entity or ""] = by_entity.get(entity or "", 0) + 1
        by_path[xpath] = by_path.get(xpath, 0) + 1

    def _top(d: Dict[str, int]) -> List[Dict[str, Any]]:
        items = [{"key": k, "count": c} for k, c in d.items()]
        items.sort(key=lambda x: (-x["count"], x["key"]))
        return items[:top_n]

    def _top_paths(d: Dict[str, int]) -> List[Dict[str, Any]]:
        items = [{"xml_path": k, "count": c} for k, c in d.items()]
        items.sort(key=lambda x: (-x["count"], x["xml_path"]))
        return items[:top_n]

    return {
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "count_keys": len(keys),
        "keys_with_both": both,
        "differences_count": differences,
        "persisted_only_count": persisted_only,
        "virtual_only_count": virtual_only,
        "by_section": _top(by_section),
        "by_filer": _top(by_filer),
        "by_jurisdiction": _top(by_juris),
        "by_entity": _top(by_entity),
        "top_diff_paths": _top_paths(by_path),
    }


@router.get("/effective-datapoints.csv")
def export_effective_datapoints_csv(
    filing_id: str,
    xml_path_prefix: Optional[str] = Query(default=None),
    filer_code: Optional[str] = Query(default=None),
    jurisdiction_code: Optional[str] = Query(default=None),
    entity_code: Optional[str] = Query(default=None),
    db: Session = Depends(get_db),
):
    filing = _ensure_filing(db, filing_id)
    _config, persisted, virtual = _load_effective_datapoints(db, filing)

    items = _filter_datapoints(
        persisted,
        virtual,
        xml_path_prefix=xml_path_prefix,
        filer_code=filer_code,
        jurisdiction_code=jurisdiction_code,
        entity_code=entity_code,
    )

    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    filename = f"effective_datapoints_{filing_id}_{ts}.csv"
    headers = {"Content-Disposition": f'attachment; filename="{filename}"'}

    return StreamingResponse(
        _csv_generator(items, filing_id=filing_id, config_version_id=filing.config_version_id),
        media_type="text/csv",
        headers=headers,
    )


@router.get("/effective-datapoints.json")
def export_effective_datapoints_json(
    filing_id: str,
    xml_path_prefix: Optional[str] = Query(default=None),
    filer_code: Optional[str] = Query(default=None),
    jurisdiction_code: Optional[str] = Query(default=None),
    entity_code: Optional[str] = Query(default=None),
    pretty: bool = Query(default=False, description="Pretty-print JSON"),
    db: Session = Depends(get_db),
):
    filing = _ensure_filing(db, filing_id)
    config, persisted, virtual = _load_effective_datapoints(db, filing)

    items = _filter_datapoints(
        persisted,
        virtual,
        xml_path_prefix=xml_path_prefix,
        filer_code=filer_code,
        jurisdiction_code=jurisdiction_code,
        entity_code=entity_code,
    )

    payload = {
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "filing": {
            "id": filing.id,
            "tenant_id": filing.tenant_id,
            "config_version_id": filing.config_version_id,
            "period_start": filing.period_start.isoformat(),
            "period_end": filing.period_end.isoformat(),
            "reporting_currency": filing.reporting_currency,
            "status": filing.status,
        },
        "config_meta": getattr(config, "meta", None).model_dump() if hasattr(getattr(config, "meta", None), "model_dump") else getattr(config, "meta", None),
        "effective_count": len(items),
        "persisted_count": len(persisted),
        "virtual_count": len(virtual),
        "items": items,
    }

    content = json.dumps(payload, indent=2 if pretty else None, ensure_ascii=False)
    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    filename = f"effective_datapoints_{filing_id}_{ts}.json"
    headers = {"Content-Disposition": f'attachment; filename="{filename}"'}

    return Response(content=content, media_type="application/json", headers=headers)


@router.get("/validation-issues.csv")
def export_validation_issues_csv(
    filing_id: str,
    run_id: Optional[str] = Query(default=None, description="Validation run id; if omitted, uses the most recent completed run"),
    severity: Optional[str] = Query(default=None, description="Optional severity filter: BLOCKING/WARNING/INFO"),
    db: Session = Depends(get_db),
):
    """Download the validation issues as a flat CSV.

    This is intentionally separate from the zipped validation report so the UI can
    fetch issues quickly (and in a predictable format) without downloading a zip.
    """

    _ensure_filing(db, filing_id)
    run = _get_validation_run(db, filing_id, run_id)

    q = db.query(models.ValidationIssue).filter(models.ValidationIssue.validation_run_id == run.id)
    if severity:
        q = q.filter(models.ValidationIssue.severity == severity)

    issues: List[models.ValidationIssue] = (
        q.order_by(models.ValidationIssue.severity.asc(), models.ValidationIssue.section.asc(), models.ValidationIssue.xml_path.asc())
        .all()
    )

    content = _issues_to_csv(issues)
    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    filename = f"validation_issues_{filing_id}_{run.id}_{ts}.csv"
    headers = {"Content-Disposition": f'attachment; filename="{filename}"'}
    return Response(content=content, media_type="text/csv", headers=headers)


@router.get("/validation-issues.json")
def export_validation_issues_json(
    filing_id: str,
    run_id: Optional[str] = Query(default=None, description="Validation run id; if omitted, uses the most recent completed run"),
    severity: Optional[str] = Query(default=None, description="Optional severity filter: BLOCKING/WARNING/INFO"),
    pretty: bool = Query(default=False, description="Pretty-print JSON"),
    include_oecd_catalogue: bool = Query(default=True, description="Include OECD error-code metadata (for codes present in the output) as a top-level lookup table"),
    db: Session = Depends(get_db),
):
    """Download the validation issues as JSON."""

    filing = _ensure_filing(db, filing_id)
    run = _get_validation_run(db, filing_id, run_id)

    q = db.query(models.ValidationIssue).filter(models.ValidationIssue.validation_run_id == run.id)
    if severity:
        q = q.filter(models.ValidationIssue.severity == severity)

    issues: List[models.ValidationIssue] = (
        q.order_by(models.ValidationIssue.severity.asc(), models.ValidationIssue.section.asc(), models.ValidationIssue.xml_path.asc())
        .all()
    )


    # Optional OECD error-code metadata lookup (Stage 0).
    oecd_catalogue = {}
    if include_oecd_catalogue:
        try:
            cfg = load_config(settings.config_root, filing.config_version_id)
            code_map = {int(ec.number): ec.model_dump() for ec in (cfg.error_codes or [])}
            codes_used = sorted({int(i.error_number) for i in issues if i.error_number is not None})
            oecd_catalogue = {str(c): code_map[c] for c in codes_used if c in code_map}
        except Exception:
            oecd_catalogue = {}

    payload = {
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "filing_id": filing_id,
        "config_version_id": filing.config_version_id,
        "oecd_catalogue_count": len(oecd_catalogue),
        "oecd_catalogue": oecd_catalogue,
        "validation_run_id": run.id,
        "count": len(issues),
        "items": [
            {
                "id": i.id,
                "severity": i.severity,
                "error_number": int(i.error_number) if i.error_number is not None else None,
                "rule_id": i.rule_id,
                "section": i.section,
                "xml_path": i.xml_path,
                "message": i.message,
                "how_to_fix": i.how_to_fix,
                "filer_code": i.filer_code,
                "jurisdiction_code": i.jurisdiction_code,
                "entity_code": i.entity_code,
                "context_key": i.context_key,
                "created_at": i.created_at.isoformat() if i.created_at else None,
            }
            for i in issues
        ],
    }

    content = json.dumps(payload, indent=2 if pretty else None, ensure_ascii=False)
    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    filename = f"validation_issues_{filing_id}_{run.id}_{ts}.json"
    headers = {"Content-Disposition": f'attachment; filename="{filename}"'}
    return Response(content=content, media_type="application/json", headers=headers)


@router.get("/validation-report.zip")
def export_validation_report_zip(
    filing_id: str,
    run_id: Optional[str] = Query(default=None, description="Validation run id; if omitted, uses the most recent completed run"),
    include_effective_csv: bool = Query(default=True),
    include_effective_json: bool = Query(default=False),
    include_diff_summary: bool = Query(default=True),
    db: Session = Depends(get_db),
):
    """Export a validation report pack as a zip file.

    The zip includes:
    - report_metadata.json
    - validation_run.json
    - validation_issues.csv
    - (optional) effective_datapoints.csv / .json
    - (optional) effective_datapoints_diff_summary.json
    """

    filing = _ensure_filing(db, filing_id)

    # Determine run
    run = _get_validation_run(db, filing_id, run_id)

    issues: List[models.ValidationIssue] = (
        db.query(models.ValidationIssue)
        .filter(models.ValidationIssue.validation_run_id == run.id)
        .order_by(models.ValidationIssue.severity.asc(), models.ValidationIssue.section.asc(), models.ValidationIssue.xml_path.asc())
        .all()
    )

    # Load config + effective datapoints for metadata / optional attachments
    config, persisted, virtual = _load_effective_datapoints(db, filing)

    effective_items = _filter_datapoints(
        persisted,
        virtual,
        xml_path_prefix=None,
        filer_code=None,
        jurisdiction_code=None,
        entity_code=None,
    )

    diff_summary = None
    if include_diff_summary:
        diff_summary = _compute_effective_diff_summary(
            filing=filing,
            config=config,
            persisted=persisted,
            db=db,
            top_n=25,
        )

    counts = {
        "total_issues": len(issues),
        "blocking_issues": sum(1 for x in issues if x.severity == "BLOCKING"),
        "warning_issues": sum(1 for x in issues if x.severity == "WARNING"),
        "info_issues": sum(1 for x in issues if x.severity == "INFO"),
    }

    report_metadata = {
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "filing": {
            "id": filing.id,
            "tenant_id": filing.tenant_id,
            "config_version_id": filing.config_version_id,
            "period_start": filing.period_start.isoformat(),
            "period_end": filing.period_end.isoformat(),
            "reporting_currency": filing.reporting_currency,
            "status": filing.status,
        },
        "config_meta": getattr(config, "meta", None).model_dump() if hasattr(getattr(config, "meta", None), "model_dump") else getattr(config, "meta", None),
        "validation_run": {
            "id": run.id,
            "status": run.status,
            "started_at": run.started_at.isoformat() if run.started_at else None,
            "completed_at": run.completed_at.isoformat() if run.completed_at else None,
            "message": run.message,
            **counts,
        },
        "effective_datapoints": {
            "persisted_count": len(persisted),
            "virtual_count": len(virtual),
            "effective_count": len(effective_items),
        },
        "diff_summary_included": include_diff_summary,
    }

    # Build files
    issues_csv = _issues_to_csv(issues)

    eff_csv = None
    eff_json = None
    if include_effective_csv:
        eff_csv = "".join(_csv_generator(effective_items, filing_id=filing.id, config_version_id=filing.config_version_id))

    if include_effective_json:
        eff_json_payload = {
            "generated_at": datetime.utcnow().isoformat() + "Z",
            "filing_id": filing.id,
            "config_version_id": filing.config_version_id,
            "effective_count": len(effective_items),
            "items": effective_items,
        }
        eff_json = json.dumps(eff_json_payload, indent=2, ensure_ascii=False)

    # Zip assembly
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr("report_metadata.json", json.dumps(report_metadata, indent=2, ensure_ascii=False))
        z.writestr("validation_run.json", json.dumps(report_metadata["validation_run"], indent=2, ensure_ascii=False))
        z.writestr("validation_issues.csv", issues_csv)

        if include_effective_csv and eff_csv is not None:
            z.writestr("effective_datapoints.csv", eff_csv)
        if include_effective_json and eff_json is not None:
            z.writestr("effective_datapoints.json", eff_json)
        if include_diff_summary and diff_summary is not None:
            z.writestr("effective_datapoints_diff_summary.json", json.dumps(diff_summary, indent=2, ensure_ascii=False))

    buf.seek(0)
    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    filename = f"validation_report_{filing_id}_{run.id}_{ts}.zip"
    headers = {"Content-Disposition": f'attachment; filename="{filename}"'}

    return Response(content=buf.getvalue(), media_type="application/zip", headers=headers)


# -----------------------------
# Sprint 2.2 exports — expected datapoints matrix & completeness
# -----------------------------


@router.get("/expected-datapoints-matrix.csv")
def export_expected_datapoints_matrix_csv(
    filing_id: str,
    set_id: str = Query(default="JURIS_CE_REQUIRED", description="Reconciliation set id"),
    include_present_values: bool = Query(default=False, description="Include present value/currency columns"),
    only_missing: bool = Query(default=False, description="Export only missing expected datapoints"),
    db: Session = Depends(get_db),
):
    """Export the expected datapoints matrix as a long-form CSV.

    Each row represents an expected datapoint key and whether it is present in
    the effective dataset (persisted ∪ derived).
    """

    filing = _ensure_filing(db, filing_id)
    try:
        config = load_config(settings.config_root, filing.config_version_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Cannot load config: {e}")

    s = _get_set_or_404(filing, set_id)

    res = build_expected_datapoints_for_set(
        db=db,
        filing=filing,
        config=config,
        s=s,
        include_present_values=include_present_values,
        only_missing=only_missing,
    )

    rows = res.get("items") or []

    output = io.StringIO()
    writer = csv.writer(output)

    header = [
        "filing_id",
        "config_version_id",
        "set_id",
        "section",
        "scope",
        "filer_code",
        "jurisdiction_code",
        "entity_code",
        "context_key",
        "xml_path",
        "tax_label",
        "required",
        "repeatable",
        "is_present",
        "present_id",
        "present_is_virtual",
        "present_source",
        "present_source_system",
    ]
    if include_present_values:
        header.extend(["present_value_raw", "present_currency"])

    writer.writerow(header)
    for r in rows:
        base = [
            filing.id,
            filing.config_version_id,
            r.get("set_id"),
            r.get("section"),
            r.get("scope"),
            r.get("filer_code"),
            r.get("jurisdiction_code"),
            r.get("entity_code"),
            r.get("context_key"),
            r.get("xml_path"),
            r.get("tax_label"),
            str(bool(r.get("required"))),
            str(bool(r.get("repeatable"))),
            str(bool(r.get("is_present"))),
            r.get("present_id"),
            r.get("present_is_virtual"),
            r.get("present_source"),
            r.get("present_source_system"),
        ]
        if include_present_values:
            base.extend([r.get("present_value_raw"), r.get("present_currency")])
        writer.writerow(base)

    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    filename = f"expected_datapoints_matrix_{filing_id}_{set_id}_{ts}.csv"
    headers = {"Content-Disposition": f'attachment; filename="{filename}"'}
    return Response(content=output.getvalue(), media_type="text/csv", headers=headers)


@router.get("/expected-datapoints-matrix.json")
def export_expected_datapoints_matrix_json(
    filing_id: str,
    set_id: str = Query(default="JURIS_CE_REQUIRED", description="Reconciliation set id"),
    include_present_values: bool = Query(default=False, description="Include present value/currency in rows"),
    only_missing: bool = Query(default=False, description="Export only missing expected datapoints"),
    pretty: bool = Query(default=True),
    db: Session = Depends(get_db),
):
    filing = _ensure_filing(db, filing_id)
    try:
        config = load_config(settings.config_root, filing.config_version_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Cannot load config: {e}")

    s = _get_set_or_404(filing, set_id)

    res = build_expected_datapoints_for_set(
        db=db,
        filing=filing,
        config=config,
        s=s,
        include_present_values=include_present_values,
        only_missing=only_missing,
    )

    payload = {
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "filing_id": filing.id,
        "config_version_id": filing.config_version_id,
        "set_id": res.get("set_id"),
        "set_description": res.get("set_description"),
        "count": len(res.get("items") or []),
        "items": res.get("items") or [],
    }

    content = json.dumps(payload, indent=2 if pretty else None, ensure_ascii=False)
    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    filename = f"expected_datapoints_matrix_{filing_id}_{set_id}_{ts}.json"
    headers = {"Content-Disposition": f'attachment; filename="{filename}"'}
    return Response(content=content, media_type="application/json", headers=headers)


@router.get("/expected-datapoints-matrix-pivot.csv")
def export_expected_datapoints_matrix_pivot_csv(
    filing_id: str,
    set_id: str = Query(default="JURIS_CE_REQUIRED", description="Reconciliation set id"),
    pivot: str = Query(default="auto", description="auto|jurisdiction|filer|entity|jurisdiction_entity"),
    cell: str = Query(default="status", description="status|present|missing|value"),
    max_columns: int = Query(default=200, ge=1, le=5000),
    include_present_values: bool = Query(default=False, description="Required if cell=value"),
    db: Session = Depends(get_db),
):
    """Export the expected datapoints matrix as a *wide/pivot* CSV."""

    filing = _ensure_filing(db, filing_id)
    try:
        config = load_config(settings.config_root, filing.config_version_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Cannot load config: {e}")

    s = _get_set_or_404(filing, set_id)

    res = build_expected_datapoints_for_set(
        db=db,
        filing=filing,
        config=config,
        s=s,
        include_present_values=include_present_values or (cell == "value"),
        only_missing=False,
    )

    try:
        piv = pivot_expected_datapoints(items=res.get("items") or [], pivot=pivot, cell=cell, max_columns=max_columns)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    rows = piv.get("items") or []
    columns = piv.get("columns") or []

    output = io.StringIO()
    writer = csv.writer(output)

    header = [
        "filing_id",
        "config_version_id",
        "set_id",
        "pivot",
        "cell",
        "section",
        "scope",
        "xml_path",
        "tax_label",
        "required",
        "repeatable",
    ] + [str(c) for c in columns]
    writer.writerow(header)

    for r in rows:
        base = [
            filing.id,
            filing.config_version_id,
            res.get("set_id"),
            piv.get("pivot"),
            piv.get("cell"),
            r.get("section"),
            r.get("scope"),
            r.get("xml_path"),
            r.get("tax_label"),
            str(bool(r.get("required"))),
            str(bool(r.get("repeatable"))),
        ]
        for c in columns:
            base.append(r.get(c))
        writer.writerow(base)

    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    filename = f"expected_datapoints_matrix_pivot_{filing_id}_{set_id}_{ts}.csv"
    headers = {"Content-Disposition": f'attachment; filename="{filename}"'}
    return Response(content=output.getvalue(), media_type="text/csv", headers=headers)


@router.get("/expected-datapoints-matrix-pivot.json")
def export_expected_datapoints_matrix_pivot_json(
    filing_id: str,
    set_id: str = Query(default="JURIS_CE_REQUIRED", description="Reconciliation set id"),
    pivot: str = Query(default="auto", description="auto|jurisdiction|filer|entity|jurisdiction_entity"),
    cell: str = Query(default="status", description="status|present|missing|value"),
    max_columns: int = Query(default=200, ge=1, le=5000),
    include_present_values: bool = Query(default=False, description="Required if cell=value"),
    pretty: bool = Query(default=True),
    db: Session = Depends(get_db),
):
    """Export the expected datapoints matrix as a *wide/pivot* JSON payload."""

    filing = _ensure_filing(db, filing_id)
    try:
        config = load_config(settings.config_root, filing.config_version_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Cannot load config: {e}")

    s = _get_set_or_404(filing, set_id)

    res = build_expected_datapoints_for_set(
        db=db,
        filing=filing,
        config=config,
        s=s,
        include_present_values=include_present_values or (cell == "value"),
        only_missing=False,
    )

    try:
        piv = pivot_expected_datapoints(items=res.get("items") or [], pivot=pivot, cell=cell, max_columns=max_columns)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    payload = {
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "filing_id": filing.id,
        "config_version_id": filing.config_version_id,
        "set_id": res.get("set_id"),
        "set_description": res.get("set_description"),
        **piv,
    }

    content = json.dumps(payload, indent=2 if pretty else None, ensure_ascii=False)
    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    filename = f"expected_datapoints_matrix_pivot_{filing_id}_{set_id}_{ts}.json"
    headers = {"Content-Disposition": f'attachment; filename="{filename}"'}
    return Response(content=content, media_type="application/json", headers=headers)


@router.get("/jurisdiction-entity-output-completeness.csv")
def export_jurisdiction_entity_output_completeness_csv(
    filing_id: str,
    set_id: str = Query(default="JURIS_CE_REQUIRED", description="Entity-scoped reconciliation set id"),
    db: Session = Depends(get_db),
):
    filing = _ensure_filing(db, filing_id)
    try:
        config = load_config(settings.config_root, filing.config_version_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Cannot load config: {e}")

    s = _get_set_or_404(filing, set_id)

    try:
        res = compute_jurisdiction_entity_completeness(db=db, filing=filing, config=config, s=s, include_entities=False)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    output = io.StringIO()
    writer = csv.writer(output)

    writer.writerow([
        "filing_id",
        "config_version_id",
        "set_id",
        "jurisdiction_code",
        "expected_entities",
        "entities_complete",
        "entities_partial",
        "entities_missing",
        "missing_datapoints_total",
        "required_datapoints_per_entity",
        "completion_ratio_entities",
    ])

    for r in res.get("jurisdictions") or []:
        writer.writerow([
            filing.id,
            filing.config_version_id,
            res.get("set_id"),
            r.get("jurisdiction_code"),
            r.get("expected_entities"),
            r.get("entities_complete"),
            r.get("entities_partial"),
            r.get("entities_missing"),
            r.get("missing_datapoints_total"),
            r.get("required_datapoints_per_entity"),
            r.get("completion_ratio_entities"),
        ])

    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    filename = f"jurisdiction_entity_output_completeness_{filing_id}_{set_id}_{ts}.csv"
    headers = {"Content-Disposition": f'attachment; filename="{filename}"'}
    return Response(content=output.getvalue(), media_type="text/csv", headers=headers)


@router.get("/jurisdiction-entity-output-completeness.json")
def export_jurisdiction_entity_output_completeness_json(
    filing_id: str,
    set_id: str = Query(default="JURIS_CE_REQUIRED", description="Entity-scoped reconciliation set id"),
    pretty: bool = Query(default=True),
    db: Session = Depends(get_db),
):
    filing = _ensure_filing(db, filing_id)
    try:
        config = load_config(settings.config_root, filing.config_version_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Cannot load config: {e}")

    s = _get_set_or_404(filing, set_id)

    try:
        res = compute_jurisdiction_entity_completeness(db=db, filing=filing, config=config, s=s, include_entities=False)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    payload = {
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "filing_id": filing.id,
        "config_version_id": filing.config_version_id,
        **res,
    }

    content = json.dumps(payload, indent=2 if pretty else None, ensure_ascii=False)
    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    filename = f"jurisdiction_entity_output_completeness_{filing_id}_{set_id}_{ts}.json"
    headers = {"Content-Disposition": f'attachment; filename="{filename}"'}
    return Response(content=content, media_type="application/json", headers=headers)



# -----------------------------
# Sprint 2.5 exports — multi-pack dashboard
# -----------------------------

@router.get("/pack-completeness-dashboard.json")
def export_pack_completeness_dashboard_json(
    filing_id: str,
    set_ids: Optional[str] = Query(default=None, description="Optional comma-separated set_ids to include (defaults to all)"),
    pack_family: Optional[str] = Query(default=None, description="Optional pack_family filter (case-insensitive)"),
    pack_tags: Optional[List[str]] = Query(default=None, description="Optional pack_tags filter (all tags must match)"),
    include_inactive: bool = Query(default=False, description="Include inactive packs (activation false)"),
    missing_sample_n: int = Query(default=10, ge=0, le=50, description="Missing sample size per pack"),
    jurisdiction_code: Optional[str] = Query(default=None, description="Optional ISO-2 jurisdiction_code to fetch one jurisdiction card"),
    filer_code: Optional[str] = Query(default=None, description="Optional filer_code to fetch one filer card"),
    include_filers: bool = Query(default=True, description="Include filer rows in the response (set false for faster jurisdiction-only cards)"),
    use_cache: bool = Query(default=True, description="Use watermark-based cache"),
    cache_ttl_seconds: Optional[int] = Query(default=None, ge=0, le=3600, description="Override cache TTL seconds (0 disables cache)"),
    pretty: bool = Query(default=False, description="Pretty-print JSON"),
    db: Session = Depends(get_db),
):
    """Export the pack completeness dashboard as JSON."""

    filing = _ensure_filing(db, filing_id)
    try:
        config = load_config(settings.config_root, filing.config_version_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Cannot load config: {e}")

    sets_all = load_reconciliation_sets(settings.config_root, filing.config_version_id) or default_reconciliation_sets()
    sets = list(sets_all)

    if set_ids:
        wanted = {s.strip() for s in str(set_ids).split(",") if s and s.strip()}
        sets = [s for s in sets if (s.set_id or "") in wanted]
        if not sets:
            raise HTTPException(status_code=404, detail="No reconciliation sets matched set_ids")

    if pack_family:
        fam = str(pack_family).strip().lower()
        sets = [s for s in sets if (s.pack_family or "").strip().lower() == fam]
        if not sets:
            raise HTTPException(status_code=404, detail="No reconciliation sets matched pack_family")

    if pack_tags:
        wanted_tags = {str(t).strip().lower() for t in (pack_tags or []) if str(t).strip()}
        if wanted_tags:
            def _has_all_tags(s):
                tags = {str(t).strip().lower() for t in (s.pack_tags or []) if str(t).strip()}
                return wanted_tags.issubset(tags)
            sets = [s for s in sets if _has_all_tags(s)]
            if not sets:
                raise HTTPException(status_code=404, detail="No reconciliation sets matched pack_tags")

    res = compute_pack_completeness_dashboard_cached(
        db=db,
        filing=filing,
        config=config,
        sets=sets,
        include_inactive=include_inactive,
        missing_sample_n=missing_sample_n,
        jurisdiction_codes=([jurisdiction_code] if jurisdiction_code else None),
        filer_codes=(["__none__"] if (not include_filers and not filer_code) else ([filer_code] if filer_code else None)),
        use_cache=use_cache,
        cache_ttl_seconds=cache_ttl_seconds,
    )

    payload = {
        "generated_at": datetime.utcnow().isoformat(),
        "filing_id": filing.id,
        "config_version_id": filing.config_version_id,
        "set_count": len(sets),
        "sets": res.get("sets") or [],
        "jurisdictions": res.get("jurisdictions") or [],
        "filers": res.get("filers") or [],
    }

    content = json.dumps(payload, indent=2 if pretty else None)
    return Response(content=content, media_type="application/json")


@router.get("/pack-completeness-dashboard.csv")
def export_pack_completeness_dashboard_csv(
    filing_id: str,
    set_ids: Optional[str] = Query(default=None, description="Optional comma-separated set_ids to include (defaults to all)"),
    pack_family: Optional[str] = Query(default=None, description="Optional pack_family filter (case-insensitive)"),
    pack_tags: Optional[List[str]] = Query(default=None, description="Optional pack_tags filter (all tags must match)"),
    include_inactive: bool = Query(default=False, description="Include inactive packs (activation false)"),
    missing_sample_n: int = Query(default=10, ge=0, le=50, description="Missing sample size per pack"),
    jurisdiction_code: Optional[str] = Query(default=None, description="Optional ISO-2 jurisdiction_code to fetch one jurisdiction card"),
    filer_code: Optional[str] = Query(default=None, description="Optional filer_code to fetch one filer card"),
    include_filers: bool = Query(default=True, description="Include filer rows in the response (set false for faster jurisdiction-only cards)"),
    use_cache: bool = Query(default=True, description="Use watermark-based cache"),
    cache_ttl_seconds: Optional[int] = Query(default=None, ge=0, le=3600, description="Override cache TTL seconds (0 disables cache)"),
    db: Session = Depends(get_db),
):
    """Export the pack completeness dashboard as a flat CSV.

    The CSV is long-form with a row_type column:
    - jurisdiction_pack
    - jurisdiction_entity_pack
    - filer_pack
    - jurisdiction_totals
    - filer_totals
    """

    filing = _ensure_filing(db, filing_id)
    try:
        config = load_config(settings.config_root, filing.config_version_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Cannot load config: {e}")

    sets_all = load_reconciliation_sets(settings.config_root, filing.config_version_id) or default_reconciliation_sets()
    sets = list(sets_all)

    if set_ids:
        wanted = {s.strip() for s in str(set_ids).split(",") if s and s.strip()}
        sets = [s for s in sets if (s.set_id or "") in wanted]
        if not sets:
            raise HTTPException(status_code=404, detail="No reconciliation sets matched set_ids")

    if pack_family:
        fam = str(pack_family).strip().lower()
        sets = [s for s in sets if (s.pack_family or "").strip().lower() == fam]
        if not sets:
            raise HTTPException(status_code=404, detail="No reconciliation sets matched pack_family")

    if pack_tags:
        wanted_tags = {str(t).strip().lower() for t in (pack_tags or []) if str(t).strip()}
        if wanted_tags:
            def _has_all_tags(s):
                tags = {str(t).strip().lower() for t in (s.pack_tags or []) if str(t).strip()}
                return wanted_tags.issubset(tags)
            sets = [s for s in sets if _has_all_tags(s)]
            if not sets:
                raise HTTPException(status_code=404, detail="No reconciliation sets matched pack_tags")

    res = compute_pack_completeness_dashboard_cached(
        db=db,
        filing=filing,
        config=config,
        sets=sets,
        include_inactive=include_inactive,
        missing_sample_n=missing_sample_n,
        jurisdiction_codes=([jurisdiction_code] if jurisdiction_code else None),
        filer_codes=(["__none__"] if (not include_filers and not filer_code) else ([filer_code] if filer_code else None)),
        use_cache=use_cache,
        cache_ttl_seconds=cache_ttl_seconds,
    )

    output = io.StringIO()
    writer = csv.writer(output)

    header = [
        "row_type",
        "filing_id",
        "config_version_id",
        "jurisdiction_code",
        "filer_code",
        "set_id",
        "pack_family",
        "pack_variant",
        "scope",
        "active",
        "required_count",
        "present_count",
        "missing_count",
        "completion_ratio",
        "expected_entities",
        "entities_complete",
        "entities_partial",
        "entities_missing",
        "required_datapoints_per_entity",
        "missing_datapoints_total",
        "completion_ratio_entities",
        "missing_samples",
    ]
    writer.writerow(header)

    set_meta_by_id = {s.get("set_id"): s for s in (res.get("sets") or [])}

    # Jurisdictions
    for jr in (res.get("jurisdictions") or []):
        jc = jr.get("jurisdiction_code")
        # Totals row
        writer.writerow([
            "jurisdiction_totals",
            filing.id,
            filing.config_version_id,
            jc,
            "",
            "",
            "",
            "",
            "",
            "",
            jr.get("packs_required_total"),
            jr.get("packs_present_total"),
            jr.get("packs_missing_total"),
            jr.get("packs_completion_ratio"),
            jr.get("entity_packs_expected_entities_total"),
            jr.get("entity_packs_entities_complete_total"),
            "",
            jr.get("entity_packs_entities_missing_total"),
            "",
            "",
            "",
            "",
        ])

        for p in (jr.get("packs") or []):
            meta = set_meta_by_id.get(p.get("set_id"), {})
            samples = p.get("missing_samples") or []
            sample_str = "; ".join([f"{x.get('tax_label') or ''}:{x.get('xml_path') or ''}" for x in samples])
            writer.writerow([
                "jurisdiction_pack",
                filing.id,
                filing.config_version_id,
                jc,
                "",
                p.get("set_id"),
                meta.get("pack_family"),
                meta.get("pack_variant"),
                "jurisdiction",
                p.get("active"),
                p.get("required_count"),
                p.get("present_count"),
                p.get("missing_count"),
                p.get("completion_ratio"),
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                sample_str,
            ])

        for ep in (jr.get("entity_packs") or []):
            meta = set_meta_by_id.get(ep.get("set_id"), {})
            samples = ep.get("missing_samples") or []
            sample_str = "; ".join([f"{x.get('tax_label') or ''}:{x.get('xml_path') or ''}" for x in samples])
            writer.writerow([
                "jurisdiction_entity_pack",
                filing.id,
                filing.config_version_id,
                jc,
                "",
                ep.get("set_id"),
                meta.get("pack_family"),
                meta.get("pack_variant"),
                "entity",
                ep.get("active"),
                "",
                "",
                "",
                "",
                ep.get("expected_entities"),
                ep.get("entities_complete"),
                ep.get("entities_partial"),
                ep.get("entities_missing"),
                ep.get("required_datapoints_per_entity"),
                ep.get("missing_datapoints_total"),
                ep.get("completion_ratio_entities"),
                sample_str,
            ])

    # Filers
    for fr in (res.get("filers") or []):
        fc = fr.get("filer_code")
        writer.writerow([
            "filer_totals",
            filing.id,
            filing.config_version_id,
            "",
            fc,
            "",
            "",
            "",
            "",
            "",
            fr.get("packs_required_total"),
            fr.get("packs_present_total"),
            fr.get("packs_missing_total"),
            fr.get("packs_completion_ratio"),
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
        ])

        for p in (fr.get("packs") or []):
            meta = set_meta_by_id.get(p.get("set_id"), {})
            samples = p.get("missing_samples") or []
            sample_str = "; ".join([f"{x.get('tax_label') or ''}:{x.get('xml_path') or ''}" for x in samples])
            writer.writerow([
                "filer_pack",
                filing.id,
                filing.config_version_id,
                "",
                fc,
                p.get("set_id"),
                meta.get("pack_family"),
                meta.get("pack_variant"),
                "filer",
                p.get("active"),
                p.get("required_count"),
                p.get("present_count"),
                p.get("missing_count"),
                p.get("completion_ratio"),
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                sample_str,
            ])

    content = output.getvalue().encode("utf-8")
    headers = {"Content-Disposition": f"attachment; filename=pack_completeness_dashboard_{filing.id}.csv"}
    return StreamingResponse(io.BytesIO(content), media_type="text/csv", headers=headers)
