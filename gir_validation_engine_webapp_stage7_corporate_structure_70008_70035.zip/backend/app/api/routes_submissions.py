from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.db import models
from app.api.schemas import (
    SubmissionListResponse,
    SubmissionDetailResponse,
    SubmissionHistoryResetRequest,
    SubmissionHistoryResetResponse,
)


# NOTE: Keep routes stable:
#   GET  /filings/{filing_id}/submissions
#   GET  /filings/{filing_id}/submissions/{submission_id}
# Stage 3.1 adds:
#   POST /filings/{filing_id}/submissions:reset
router = APIRouter(prefix="/filings/{filing_id}", tags=["submissions"])


@router.get("/submissions", response_model=SubmissionListResponse)
def list_submissions(
    filing_id: str,
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    db: Session = Depends(get_db),
):
    filing = db.get(models.Filing, filing_id)
    if filing is None:
        raise HTTPException(status_code=404, detail="Filing not found")

    q = (
        db.query(models.Submission)
        .filter(models.Submission.filing_id == filing_id)
        .order_by(models.Submission.imported_at.desc())
    )
    total = q.count()
    items = q.offset(offset).limit(limit).all()
    return SubmissionListResponse(count=total, items=items)


@router.get("/submissions/{submission_id}", response_model=SubmissionDetailResponse)
def get_submission(
    filing_id: str,
    submission_id: str,
    include_records: bool = Query(default=True),
    db: Session = Depends(get_db),
):
    sub = db.get(models.Submission, submission_id)
    if sub is None or sub.filing_id != filing_id:
        raise HTTPException(status_code=404, detail="Submission not found")

    records = []
    if include_records:
        records = (
            db.query(models.SubmissionRecord)
            .filter(models.SubmissionRecord.filing_id == filing_id)
            .filter(models.SubmissionRecord.submission_id == submission_id)
            .order_by(models.SubmissionRecord.record_type.asc(), models.SubmissionRecord.filer_code.asc())
            .all()
        )

    return SubmissionDetailResponse(
        submission=sub,
        records_count=len(records),
        records=records,
    )


@router.post("/submissions:reset", response_model=SubmissionHistoryResetResponse)
def reset_submission_history(
    filing_id: str,
    payload: SubmissionHistoryResetRequest = SubmissionHistoryResetRequest(),
    db: Session = Depends(get_db),
):
    """Reset (delete) submission history for a filing.

    This is intended for demo / testing environments where repeated uploads
    would otherwise trigger cross-submission OECD validations (e.g., 60002).

    It does NOT delete the current filing registers/datapoints/validation runs.
    """

    filing = db.get(models.Filing, filing_id)
    if filing is None:
        raise HTTPException(status_code=404, detail="Filing not found")

    # Count first (supports dry-run + provides deterministic response)
    sub_q = db.query(models.Submission).filter(models.Submission.filing_id == filing_id)
    rec_q = db.query(models.SubmissionRecord).filter(models.SubmissionRecord.filing_id == filing_id)

    submissions_matched = sub_q.count()
    records_matched = rec_q.count()

    submissions_deleted = 0
    records_deleted = 0

    if not payload.dry_run:
        if not payload.confirm:
            raise HTTPException(status_code=400, detail="Set confirm=true to reset submission history")

        # Delete records first (FK safety), then submissions.
        records_deleted = rec_q.delete(synchronize_session=False)
        submissions_deleted = sub_q.delete(synchronize_session=False)
        db.commit()

    return SubmissionHistoryResetResponse(
        filing_id=filing_id,
        dry_run=payload.dry_run,
        submissions_matched=submissions_matched,
        records_matched=records_matched,
        submissions_deleted=submissions_deleted,
        records_deleted=records_deleted,
    )
