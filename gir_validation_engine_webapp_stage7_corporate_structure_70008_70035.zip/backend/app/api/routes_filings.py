from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime

from app.db.session import get_db
from app.db import models
from app.api.schemas import FilingCreate, FilingRead
from app.core.settings import settings
from app.services.config_loader import list_config_versions

router = APIRouter(prefix="/filings", tags=["filings"])

@router.post("", response_model=FilingRead)
def create_filing(payload: FilingCreate, db: Session = Depends(get_db)):
    # validate config version exists
    if payload.config_version_id not in set(list_config_versions(settings.config_root)):
        raise HTTPException(status_code=400, detail=f"Unknown config_version_id: {payload.config_version_id}")

    # ensure tenant exists (simple upsert for Sprint 0)
    tenant = db.get(models.Tenant, payload.tenant_id)
    if tenant is None:
        tenant = models.Tenant(id=payload.tenant_id, name=payload.tenant_id)
        db.add(tenant)
        db.commit()

    filing = models.Filing(
        tenant_id=payload.tenant_id,
        config_version_id=payload.config_version_id,
        period_start=payload.period_start,
        period_end=payload.period_end,
        reporting_currency=payload.reporting_currency,
        status="draft",
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    db.add(filing)
    db.commit()
    db.refresh(filing)
    return filing

@router.get("/{filing_id}", response_model=FilingRead)
def get_filing(filing_id: str, db: Session = Depends(get_db)):
    filing = db.get(models.Filing, filing_id)
    if filing is None:
        raise HTTPException(status_code=404, detail="Filing not found")
    return filing
