# GIR Validation Engine — Sprint 2.5 Dashboard Caching + Exports Backend


## Sprint 2.5 additions
- Watermark-based caching for multi-pack completeness dashboard (safe invalidation via max(updated_at) watermark).
- Optional jurisdiction_code/filer_code filters for fetching a single dashboard card.
- New export endpoints:
  - `GET /filings/{filing_id}/exports/pack-completeness-dashboard.json`
  - `GET /filings/{filing_id}/exports/pack-completeness-dashboard.csv`
- Demo script: `python scripts/seed_demo_sprint2_5.py --api http://localhost:8000 --out ./out`

## OECD error codes — stages implemented

This backend includes a growing set of **OECD GIR error-code** validations (especially the 600xx “Severe record errors”).

Implemented stages so far:
- **Stage 0**: OECD error-code catalogue mapping into validation outputs and export payloads.
- **Stage 2 / 2.5**: many 600xx single-file severe record errors, including explicit **record-type mapping** for 60010/60016/60017.
- **Stage 3 / 3.1**: submission history support ("previously received") plus a per-filing reset endpoint.
- **Stage 4**: 60005 and 60024–60028 (calculation checks use 4dp rounding and allow a 1% margin).
- **Stage 4.1–4.3**: XML importer preserves repeating records/containers (CEComputation + DocSpec-bearing records + other repeatables).
- **Stage 4.4**: XML importer also captures attribute datapoints (`/@attr`) + mixed-content text nodes (`/text()`) and derives stable `entity_code` for entity-like blocks beyond CorporateStructure/CE when possible.
- **Stage 4.7**: attribute-driven OECD record errors for **TIN** (70001–70007: NOTIN/Unknown/issuedBy/TypeOfTIN consistency + GIR3003 designated reference format; 70004 supported when local-jurisdiction regex is configured via env vars).
- **Stage 4.8**: additional attribute-driven OECD record error **70025** (OwnershipType GIR805/GIR806 ⇒ associated ownership TIN must be `NOTIN` with `TypeOfTIN=GIR3004`).
- **Stage 5**: optional true **XSD validation** against the OECD GIR XML Schema bundle; failures are returned as an OECD **50007** file error issue (best for comprehensive attribute correctness such as `currCode`).
- **Stage 6**: OECD *file* errors 50001/50003/50008/50009/50010 (download/decompress, DocTypeIndic test-vs-prod context, ReceivingCountry mismatch).
- **Stage 7**: additional OECD “Other record errors” **70008–70035** (UTPRAttribution RecJurCode checks; CorporateStructure/UPE + CE GloBEStatus consistency; OwnershipChange date-window + PreOwnership gating; Ownership / OwnershipType TIN references; QIIR POPE/IPE exception flags).

This repo is the **Sprint 2.2** backend for a web-based GIR Validation Engine.

Sprint 1.3 adds a **register-driven datapoint bridge**, so common header/identity fields
(e.g., FilingInfo dates/currency, Filing CE identity, Jurisdiction header fields, and
baseline CorporateStructure identity/ownership fields) can be stored in registers and
still satisfy config-driven validations — without manually keying everything as datapoints.

Sprint 1.3.1 adds **Get Effective Datapoints**: an endpoint that returns the union of:
- persisted datapoints (what you've uploaded)
- virtual datapoints derived on-the-fly from registers and filing header fields (what the validation engine *sees*)

Sprint 1.3.3 adds a **Diff Summary** endpoint for dashboards (top mismatches by section / filer / jurisdiction / entity).




## Sprint 2.0 — Exports

Sprint 2.0 adds **export endpoints** to support front-end downloads, audit trails, and downstream XML builders / vendor tools:

- `GET /filings/{filing_id}/exports/effective-datapoints.csv`
- `GET /filings/{filing_id}/exports/effective-datapoints.json`
- `GET /filings/{filing_id}/exports/validation-report.zip`

### Additional endpoints (CSV/JSON)

Sprint 2.1 adds direct download endpoints for validation issues (no zip required):

- `GET /filings/{filing_id}/exports/validation-issues.csv`
- `GET /filings/{filing_id}/exports/validation-issues.json`

Both accept:
- `run_id` (optional; defaults to latest completed)
- `severity` (optional)

### Effective datapoints export

The export uses the same precedence rule as the validation engine:

- persisted datapoints (uploaded) **override**
- derived datapoints (register bridge) which **fill gaps**

### Validation report pack

The zip contains:
- `report_metadata.json`
- `validation_run.json`
- `validation_issues.csv`
- (optional) `effective_datapoints.csv` / `effective_datapoints.json`
- (optional) `effective_datapoints_diff_summary.json` (helps explain mismatches between registers and uploaded datapoints)


## Quick start (local)

### 1) Start Postgres + API
```bash
docker compose up --build
```

The API will be available at:
- http://localhost:8000/docs (Swagger UI)
- http://localhost:8000/health

### Optional: seed a demo dataset
Once the stack is running, you can seed a small multi-filer dataset and run validations:

```bash
python scripts/seed_demo_sprint1_3.py --api http://localhost:8000
```

Or seed + download exports (Sprint 2.0):

```bash
python scripts/seed_demo_sprint2_0.py --api http://localhost:8000 --out ./out
```

Or seed + call reconciliation endpoints (Sprint 2.1):

```bash
python scripts/seed_demo_sprint2_1.py --api http://localhost:8000 --out ./out
```

### 2) List available config versions
```bash
curl http://localhost:8000/config/versions
```

### 3) Create a filing
```bash
curl -X POST http://localhost:8000/filings \
  -H "Content-Type: application/json" \
  -d '{
    "tenant_id": "demo",
    "config_version_id": "GIR_CONFIG_v1",
    "period_start": "2025-01-01",
    "period_end": "2025-12-31",
    "reporting_currency": "USD"
  }'
```

## Import a GIR XML file (customer-facing bridge)

For customer self-serve web tools (e.g., Anything.com), the backend provides a bridge
endpoint that accepts a publicly accessible file URL, downloads the XML server-side,
parses it, and loads registers + datapoints.

### Import only

```bash
curl -X POST "http://localhost:8000/filings/{filing_id}/imports/gir-xml" \
  -H "Content-Type: application/json" \
  -d '{
    "file_url": "https://your-upload-host/path/to/gir.xml",
    "source_system": "anything_upload",
    "replace_existing": true,
    "strict_xsd": false
  }'
```

### One-click import + validate

```bash
curl -X POST "http://localhost:8000/filings/{filing_id}/imports/gir-xml:validate" \
  -H "Content-Type: application/json" \
  -d '{
    "file_url": "https://your-upload-host/path/to/gir.xml",
    "source_system": "anything_upload",
    "replace_existing": true,
    "strict_xsd": false,
    "notes": "Run from web UI"
  }'

### Enable Stage 5 XSD validation (recommended for production)

To validate uploaded XML against the OECD GIR XSD bundle:

1) Put the OECD schema ZIP in the repo (example path):

```
oecd_schemas/oecd_gir_xml_schema.zip
```

2) Set Render environment variables:

- `XSD_VALIDATION_MODE=on` (runs XSD validation for all XML imports)
- `GIR_XSD_ZIP_PATH=oecd_schemas/oecd_gir_xml_schema.zip`

If auto-detection of the main XSD fails (bundle variations), set:

- `GIR_XSD_MAIN=<relative path to the entrypoint .xsd inside the bundle>`

When XSD validation fails, the `/imports/gir-xml:validate` endpoint returns a completed
validation run with a single **BLOCKING** issue carrying OECD code **50007**, including
the first XSD error messages for diagnostics.
```

## Get effective datapoints (Sprint 1.3.1+)

The validation engine is register-driven in Sprint 1.3+, so many values may be derived
without being stored as datapoints (e.g., FilingInfo dates/currency, filing CE identity,
jurisdiction headers, CorporateStructure identity/ownership).

To retrieve the exact dataset used by the validator:

```bash
curl "http://localhost:8000/filings/{filing_id}/datapoints:effective?include_persisted=true&include_virtual=true"
```

You can filter the result just like `/datapoints`:

```bash
curl "http://localhost:8000/filings/{filing_id}/datapoints:effective?xml_path_prefix=/GLOBE_OECD/GLOBEBody/FilingInfo"
```

Each returned datapoint includes:
- `is_virtual`: `true` if derived on-the-fly (not persisted)
- `source_system`: typically `register_bridge` for virtual datapoints

## Diff persisted vs derived datapoints (Sprint 1.3.2)

To make UI/tooling explanations easier, you can retrieve a side-by-side view
of persisted datapoints vs the values that would be derived from registers:

```bash
curl "http://localhost:8000/filings/{filing_id}/effective-datapoints:diff"
```

Useful filters:

```bash
# Only where persisted overrides a derived value
curl "http://localhost:8000/filings/{filing_id}/effective-datapoints:diff?only_overrides=true"

# Only where the two differ
curl "http://localhost:8000/filings/{filing_id}/effective-datapoints:diff?only_differences=true"

# Limit to a schema area
curl "http://localhost:8000/filings/{filing_id}/effective-datapoints:diff?xml_path_prefix=/GLOBE_OECD/GLOBEBody/FilingInfo"
```

Each row returns:
- `effective`: the value the engine will use (persisted wins)
- `persisted`: the stored datapoint (if any)
- `virtual`: the register-derived datapoint (if any), including a `notes` field
  like `filer.tin` or `auto_generated:jurisdiction.docspec.docrefid` to explain origin.

## Diff summary (Sprint 2.0)

For dashboards and fast diagnostics (without pulling the full diff list), use:

```bash
curl "http://localhost:8000/filings/{filing_id}/effective-datapoints:diff/summary"
```

The result includes:
- overall counts (keys with both, differences, persisted-only, virtual-only)
- top mismatches by section / filer / jurisdiction / entity
- top XML paths with the most differences

Useful filters:

```bash
# Only keys where both persisted and derived exist
curl "http://localhost:8000/filings/{filing_id}/effective-datapoints:diff/summary?only_overrides=true"

# Only keys where both exist and differ
curl "http://localhost:8000/filings/{filing_id}/effective-datapoints:diff/summary?only_differences=true"

# Limit summary to a schema area
curl "http://localhost:8000/filings/{filing_id}/effective-datapoints:diff/summary?xml_path_prefix=/GLOBE_OECD/GLOBEBody/FilingInfo"
```


## Sprint 2.1 — Reconciliation endpoints

Sprint 2.1 adds *UI-first reconciliation helpers* that make it easier to:
- see overall issue counts by dimension (section / filer / jurisdiction / entity)
- extract just the missing required datapoints (REQ*)
- check basic register completeness (UPE count, entity filed_by coverage, jurisdiction responsible filer coverage)

### Reconciliation summary

```bash
curl "http://localhost:8000/filings/{filing_id}/reconciliation/summary"
```

### Missing required datapoints list

```bash
curl "http://localhost:8000/filings/{filing_id}/reconciliation/missing-datapoints"
```

### Register coverage checks

```bash
curl "http://localhost:8000/filings/{filing_id}/reconciliation/register-coverage"
```


## Sprint 2.2 — Expected datapoints reconciliation

Sprint 2.2 adds a *true completeness* layer:
- compute **expected datapoints** from config
- expand them across the **registers** (per filer/jurisdiction/entity)
- report an explicit **missing vs present matrix**
- compute **per-jurisdiction entity-output completeness** against a required datapoint set

### Reconciliation set definitions

Expected datapoints are driven by `config/{config_version_id}/reconciliation_sets.json`.

For precise control (to match Excel "expected datapoints" packs), you can provide an
explicit `xpaths` allow-list per set. If `xpaths` is omitted, the engine uses
`xpath_includes` / `xpath_excludes` substring filters.

The included starter config provides:
- `JURIS_OVERALL_REQUIRED` (jurisdiction-level required leaves under `OverallComputation`)
- `JURIS_CE_REQUIRED` (entity-level required leaves under `CEComputation`)

You can refine these sets over time to match the exact Excel workbook logic.

### Expected datapoints matrix (API)

```bash
curl "http://localhost:8000/filings/{filing_id}/reconciliation/expected-datapoints?set_id=JURIS_CE_REQUIRED"
```

Useful options:
- `only_missing=true`
- `include_present_values=true`

### Jurisdiction entity-output completeness (API)

```bash
curl "http://localhost:8000/filings/{filing_id}/reconciliation/jurisdiction-entity-output-completeness?set_id=JURIS_CE_REQUIRED"
```

### Exports

```bash
curl -L "http://localhost:8000/filings/{filing_id}/exports/expected-datapoints-matrix.csv?set_id=JURIS_CE_REQUIRED" -o expected_matrix.csv
curl -L "http://localhost:8000/filings/{filing_id}/exports/expected-datapoints-matrix.json?set_id=JURIS_CE_REQUIRED" -o expected_matrix.json

curl -L "http://localhost:8000/filings/{filing_id}/exports/jurisdiction-entity-output-completeness.csv?set_id=JURIS_CE_REQUIRED" -o completeness.csv
curl -L "http://localhost:8000/filings/{filing_id}/exports/jurisdiction-entity-output-completeness.json?set_id=JURIS_CE_REQUIRED" -o completeness.json
```


## Sprint 2.3 — Packs + mode-aware activation + pivot exports

Sprint 2.3 extends Sprint 2.2 in three key ways:

### 1) Explicit pack definitions

`config/{config_version_id}/reconciliation_sets.json` now supports additional metadata fields
so you can treat reconciliation sets as **Excel-style packs** (Core/Full/QDMTT-only/UTPR-only, etc.).

New optional fields:
- `pack_family` / `pack_variant` / `pack_tags`
- `treat_included_as_required` (treat optional schema elements as required for pack completeness)

The starter config now includes example packs:
- `JURIS_CORE_PACK`
- `SUMMARY_CORE_PACK`
- `UTPR_CORE_PACK`
- `JURIS_QDMTT_ONLY_PACK`
- `JURIS_SAFEHARBOUR_PACK`
- `JURIS_DEMINIMIS_PACK`

### 2) Conditional set activation (mode-aware)

Sets can now specify jurisdiction gating rules:
- `computation_mode_in`: e.g. `["full_etr", "safe_harbour", "de_minimis"]`
- `qdmt_applicable`: `true`/`false`

The expected datapoints matrix and jurisdiction/entity completeness calculations will
**skip jurisdictions/entities** that do not match the set's activation conditions.

To debug which sets are active per jurisdiction:

```bash
curl "http://localhost:8000/filings/{filing_id}/reconciliation/active-sets"
```

### 3) Wide/pivot export option

For UI grids and Excel-friendly exports, you can request a *pivoted* expected datapoints matrix:

API:
```bash
curl "http://localhost:8000/filings/{filing_id}/reconciliation/expected-datapoints:pivot?set_id=JURIS_CORE_PACK&pivot=jurisdiction&cell=status"
```

Exports:
```bash
curl -L "http://localhost:8000/filings/{filing_id}/exports/expected-datapoints-matrix-pivot.csv?set_id=JURIS_CORE_PACK&pivot=jurisdiction" -o expected_pivot.csv
curl -L "http://localhost:8000/filings/{filing_id}/exports/expected-datapoints-matrix-pivot.json?set_id=JURIS_CORE_PACK&pivot=jurisdiction" -o expected_pivot.json
```

Supported pivot dimensions:
- `jurisdiction`
- `filer`
- `entity`
- `jurisdiction_entity`

Supported cell formats:
- `status` (P/M)
- `present` (1/0)
- `missing` (1/0 inverse)
- `value` (present_value_raw; requires `include_present_values=true`)


## Sprint 2.4 — Multi-pack completeness dashboards

Sprint 2.4 adds a single UI-friendly endpoint that evaluates **multiple packs at once** and returns
checklist-style completeness for:
- jurisdiction-scoped packs (per jurisdiction)
- entity-scoped packs (summarized per jurisdiction)
- filer-scoped packs (per filer)

### Multi-pack completeness dashboard (API)

```bash
curl "http://localhost:8000/filings/{filing_id}/reconciliation/pack-completeness-dashboard"
```

Optional filters:
- `set_ids=SUMMARY_CORE_PACK,UTPR_CORE_PACK` (comma-separated)
- `pack_family=Jurisdiction`
- `pack_tags=core` (repeatable; all requested tags must match)

Example: show only **core** packs and include inactive packs (activation=false):

```bash
curl "http://localhost:8000/filings/{filing_id}/reconciliation/pack-completeness-dashboard?pack_tags=core&include_inactive=true&missing_sample_n=5"
```


## Run validations (Sprint 1.3)

Create a validation run (executes synchronously and stores issues):
```bash
curl -X POST "http://localhost:8000/filings/{filing_id}/validation-runs" \
  -H "Content-Type: application/json" \
  -d '{"notes":"Initial check"}'
```

List issues for a run:
```bash
curl "http://localhost:8000/filings/{filing_id}/validation-runs/{run_id}/issues?severity=BLOCKING"
```

Validation rules in Sprint 1.3 include:
- **Conditional requiredness (container gating)**: required children inside optional blocks are only enforced if that block is active.
- **Better scoping**:
  - **Filer-scoped requiredness** for FilingInfo/General/Summary/UTPR sections (per filer in Filing Entity Register).
  - **Jurisdiction-scoped requiredness** now respects **responsible_filer_code** in the Jurisdiction register (if populated).
  - **Entity-scoped requiredness** for CorporateStructure/CE-style blocks when entity-scoped datapoints are present.
- Required leaf element presence (config-driven; now gated where applicable)
- Allowed-values (enum) checks (config-driven)
- Basic datatype sanity checks (best-effort)
- Bespoke governance checks (UPE count, entity->filer mapping integrity)
- **OECD error code mapping** for DocRefId/CorrDocRefId checks (where the OECD error catalog is unambiguous):
  - 60006 (CorrDocRefId used twice)
  - 60007 (duplicate DocRefId)
  - 60008 (CorrDocRefId refers to unknown record)
  - 60012 (CorrDocRefId present when DocTypeIndic is not correction/deletion)
  - 60015 (missing CorrDocRefId when DocTypeIndic indicates correction/deletion)

Note: not every missing required element maps cleanly to a single OECD error number; Sprint 1.3 maps error numbers conservatively.

## Config extraction

A config folder is included under `/config/GIR_CONFIG_v1` generated from the Excel workbook you provided.

To regenerate config from a workbook:
```bash
python scripts/extract_config_from_excel.py \
  --workbook /path/to/OECDPillars_GIR_Prep_Suite.xlsx \
  --config-version GIR_CONFIG_v1 \
  --outdir config/GIR_CONFIG_v1
```

## Design notes

### Canonical DataPoint key
A DataPoint is uniquely identified by:
- filing_id
- filer_code (nullable)
- jurisdiction_code (nullable)
- entity_code (nullable)
- context_key (nullable)
- xml_path (required)

This matches the "flat-file export" concept and supports repeatables.

### Sprint 1.3 scope
Sprint 1.3 still does **not** implement all OECD GIR business rules; it focuses on:
- config portability + versioning
- persistence model
- API scaffolding
and improves validation quality by reducing false blocking errors via better scoping and targeted OECD error code mapping.

## License / Disclaimer
This codebase is a template foundation. It is not tax advice and not filing software.


## OECD error codes (Stage 0)

The repository includes an OECD GIR error-code catalogue extracted from the OECD guidance workbook:

- `config/<config_version_id>/error_codes.json`

To help front-end tools display official OECD text (rule + remediation) next to issues that already include an `error_number`,
the API exposes the catalogue:

- `GET /config/versions/{config_version_id}/error-codes`
- `GET /config/versions/{config_version_id}/error-codes/{number}`

For convenience, `GET /filings/{filing_id}/validation-runs/{run_id}/issues` also attaches an `oecd` object to each issue when `error_number` is present.

Engineering progress tracking:
- `oecd_coverage_matrix.csv` tracks which OECD codes are implemented and tested.


## Config generation — adding XSD attribute xpaths (Stage 4.6)

The Excel GIR toolkit often omits **XML attributes** that exist in the OECD XSD (e.g. attributes on `TIN_Type`).
The backend importer can emit attribute datapoints as:

- `/.../TIN/@issuedBy`

and the validation engine can optionally enforce requiredness for such attribute paths (see `ATTRIBUTE_REQUIREDNESS_MODE`).

To add attribute entries into `config/<version>/elements.json`, download the OECD GIR XSD package (ZIP) and run either:

### Option A — regenerate the full config pack from Excel + XSD

```bash
python scripts/extract_config_from_excel.py \
  --workbook /path/to/OECDPillars_GIR_Prep_Suite.xlsx \
  --config-version GIR_CONFIG_v1 \
  --outdir config/GIR_CONFIG_v1 \
  --xsd-zip /path/to/globe-xsd.zip
```

### Option B — augment an existing config pack (elements.json only)

```bash
python scripts/augment_elements_with_xsd_attributes.py \
  --config-dir config/GIR_CONFIG_v1 \
  --xsd-zip /path/to/globe-xsd.zip
```

By default, only **required** attributes (XSD `use="required"`) are added. To include optional attributes too:

```bash
  --include-optional-attributes
```


## Optional: OECD 70004 local-jurisdiction TIN format checks

The OECD Status Message guidance includes rule **70004** for validating a TIN when `issuedBy` equals the *local jurisdiction* (typically applied by the issuing tax administration). This backend can run 70004 **only when you configure a local jurisdiction and a regex** (otherwise it is skipped to avoid false positives).

Set the following environment variables (e.g., in Render):

- `LOCAL_JURISDICTION_CODE` = a 2-letter ISO country code, e.g. `GB`
- `TIN_VALIDATION_REGEX_MAP_JSON` = JSON string mapping country code to a regex, e.g. `{"GB":"^[A-Z0-9]{1,20}$"}`

If either is missing/invalid, 70004 is not applied.