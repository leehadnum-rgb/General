// Minimal TypeScript declaration for the "uuid" package.
// This fixes TS7016 (no declaration file) in strict builds.

declare module "uuid" {
  export function v4(): string;
  export function v1(): string;
  export function v3(name: string | number[], namespace: string | number[]): string;
  export function v5(name: string | number[], namespace: string | number[]): string;

  export const NIL: string;
  export function validate(uuid: string): boolean;
  export function version(uuid: string): number;
}
