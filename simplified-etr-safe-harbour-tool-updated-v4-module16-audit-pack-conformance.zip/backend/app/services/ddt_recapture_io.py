from __future__ import annotations

import csv
import io
import re
from datetime import date
from typing import Dict, List, Optional

from pydantic import BaseModel, Field

from app.services.models_v2 import (
    DDTRecaptureAccountStateV2,
    DDTRecaptureAccountMovementV2,
)


_NUM_RE = re.compile(r"[^0-9eE+\-\.]")


def _norm_header(h: str) -> str:
    h = (h or "").strip().lower()
    h = re.sub(r"[\s\-]+", "_", h)
    return h


_OPENING_ALIASES: Dict[str, str] = {
    "tj": "tested_jurisdiction_id",
    "tj_id": "tested_jurisdiction_id",
    "tested_jurisdiction": "tested_jurisdiction_id",
    "opening_balance": "balance",
    "balance": "balance",
    "as_of": "as_of_fiscal_year_start",
    "fy_start": "as_of_fiscal_year_start",
}


_MOVEMENT_ALIASES: Dict[str, str] = {
    "tj": "tested_jurisdiction_id",
    "tj_id": "tested_jurisdiction_id",
    "tested_jurisdiction": "tested_jurisdiction_id",
    "fy_start": "fiscal_year_start",
    "year_start": "fiscal_year_start",
    "movement": "amount",
    "delta": "amount",
}


def _parse_float(raw: str) -> Optional[float]:
    if raw is None:
        return None
    s = str(raw).strip()
    if s == "":
        return None
    s = _NUM_RE.sub("", s)
    if s in {"", "+", "-", "."}:
        return None
    try:
        return float(s)
    except ValueError:
        return None


def _parse_date(raw: str) -> Optional[date]:
    if raw is None:
        return None
    s = str(raw).strip()
    if s == "":
        return None
    try:
        return date.fromisoformat(s)
    except ValueError:
        return None


class DDTRecaptureOpeningCsvIssue(BaseModel):
    severity: str = Field(..., description="'error' or 'warning'")
    row_number: int = Field(..., ge=1, description="1-indexed row number in the CSV (excluding header).")
    field: Optional[str] = None
    message: str


class DDTRecaptureOpeningCsvParseResult(BaseModel):
    ddt_recapture_account_state_opening: List[DDTRecaptureAccountStateV2] = Field(default_factory=list)
    issues: List[DDTRecaptureOpeningCsvIssue] = Field(default_factory=list)
    detected_columns: List[str] = Field(default_factory=list)
    ignored_columns: List[str] = Field(default_factory=list)


class DDTRecaptureMovementsCsvIssue(BaseModel):
    severity: str = Field(..., description="'error' or 'warning'")
    row_number: int = Field(..., ge=1, description="1-indexed row number in the CSV (excluding header).")
    field: Optional[str] = None
    message: str


class DDTRecaptureMovementsCsvParseResult(BaseModel):
    ddt_recapture_account_movements: List[DDTRecaptureAccountMovementV2] = Field(default_factory=list)
    issues: List[DDTRecaptureMovementsCsvIssue] = Field(default_factory=list)
    detected_columns: List[str] = Field(default_factory=list)
    ignored_columns: List[str] = Field(default_factory=list)


def generate_ddt_recapture_opening_csv_template() -> bytes:
    headers = [
        "tested_jurisdiction_id",
        "balance",
        "currency",
        "amount_scale",
        "as_of_fiscal_year_start",
        "note",
    ]

    example = {
        "tested_jurisdiction_id": "GB_MAIN",
        "balance": "0",
        "currency": "GBP",
        "amount_scale": "UNITS",
        "as_of_fiscal_year_start": "2027-01-01",
        "note": "Example: Article 7.3 DDT recapture account opening balance (nil).",
    }

    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=headers)
    w.writeheader()
    w.writerow(example)
    return buf.getvalue().encode("utf-8")


def parse_ddt_recapture_opening_csv(contents: bytes) -> DDTRecaptureOpeningCsvParseResult:
    text = contents.decode("utf-8-sig", errors="replace")
    buf = io.StringIO(text)
    reader = csv.DictReader(buf)
    if reader.fieldnames is None:
        return DDTRecaptureOpeningCsvParseResult(
            ddt_recapture_account_state_opening=[],
            issues=[DDTRecaptureOpeningCsvIssue(severity="error", row_number=1, message="CSV is missing a header row.")],
        )

    raw_headers = list(reader.fieldnames)
    norm_to_raw: Dict[str, str] = {}
    for h in raw_headers:
        nh = _OPENING_ALIASES.get(_norm_header(h), _norm_header(h))
        if nh and nh not in norm_to_raw:
            norm_to_raw[nh] = h

    allowed = set(DDTRecaptureAccountStateV2.model_fields.keys())
    ignored = [raw for nh, raw in norm_to_raw.items() if nh not in allowed]
    out = DDTRecaptureOpeningCsvParseResult(detected_columns=raw_headers, ignored_columns=ignored)

    rows: List[DDTRecaptureAccountStateV2] = []
    for idx, row in enumerate(reader, start=1):
        data: Dict[str, object] = {}
        issues: List[DDTRecaptureOpeningCsvIssue] = []

        for nh, raw in norm_to_raw.items():
            if nh not in allowed:
                continue
            val = row.get(raw)

            if nh == "balance":
                f = _parse_float(val)
                if f is not None:
                    data[nh] = f
            elif nh == "as_of_fiscal_year_start":
                d = _parse_date(val)
                if d is not None:
                    data[nh] = d
            else:
                if val is None:
                    continue
                s = str(val).strip()
                if s == "":
                    continue
                data[nh] = s

        if not data.get("tested_jurisdiction_id"):
            issues.append(
                DDTRecaptureOpeningCsvIssue(severity="error", row_number=idx, field="tested_jurisdiction_id", message="Missing tested_jurisdiction_id.")
            )
        if data.get("balance") is None:
            issues.append(DDTRecaptureOpeningCsvIssue(severity="error", row_number=idx, field="balance", message="Missing balance."))

        out.issues.extend(issues)

        try:
            if any(i.severity == "error" for i in issues):
                continue
            rows.append(DDTRecaptureAccountStateV2.model_validate(data))
        except Exception as e:
            out.issues.append(DDTRecaptureOpeningCsvIssue(severity="error", row_number=idx, message=f"Row validation failed: {e}"))

    out.ddt_recapture_account_state_opening = rows
    return out


def generate_ddt_recapture_movements_csv_template() -> bytes:
    headers = [
        "movement_id",
        "tested_jurisdiction_id",
        "fiscal_year_start",
        "amount",
        "reason",
        "currency",
        "amount_scale",
        "note",
    ]

    example = {
        "movement_id": "DDT-001",
        "tested_jurisdiction_id": "GB_MAIN",
        "fiscal_year_start": "2027-01-01",
        "amount": "-100000",
        "reason": "REDUCTION",
        "currency": "GBP",
        "amount_scale": "UNITS",
        "note": "Example: reduction in Article 7.3 DDT recapture account balance.",
    }

    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=headers)
    w.writeheader()
    w.writerow(example)
    return buf.getvalue().encode("utf-8")


def parse_ddt_recapture_movements_csv(contents: bytes) -> DDTRecaptureMovementsCsvParseResult:
    text = contents.decode("utf-8-sig", errors="replace")
    buf = io.StringIO(text)
    reader = csv.DictReader(buf)
    if reader.fieldnames is None:
        return DDTRecaptureMovementsCsvParseResult(
            ddt_recapture_account_movements=[],
            issues=[DDTRecaptureMovementsCsvIssue(severity="error", row_number=1, message="CSV is missing a header row.")],
        )

    raw_headers = list(reader.fieldnames)
    norm_to_raw: Dict[str, str] = {}
    for h in raw_headers:
        nh = _MOVEMENT_ALIASES.get(_norm_header(h), _norm_header(h))
        if nh and nh not in norm_to_raw:
            norm_to_raw[nh] = h

    allowed = set(DDTRecaptureAccountMovementV2.model_fields.keys())
    ignored = [raw for nh, raw in norm_to_raw.items() if nh not in allowed]
    out = DDTRecaptureMovementsCsvParseResult(detected_columns=raw_headers, ignored_columns=ignored)

    rows: List[DDTRecaptureAccountMovementV2] = []
    for idx, row in enumerate(reader, start=1):
        data: Dict[str, object] = {}
        issues: List[DDTRecaptureMovementsCsvIssue] = []

        for nh, raw in norm_to_raw.items():
            if nh not in allowed:
                continue
            val = row.get(raw)

            if nh == "amount":
                f = _parse_float(val)
                if f is not None:
                    data[nh] = f
            elif nh == "fiscal_year_start":
                d = _parse_date(val)
                if d is not None:
                    data[nh] = d
            else:
                if val is None:
                    continue
                s = str(val).strip()
                if s == "":
                    continue
                data[nh] = s

        if not data.get("tested_jurisdiction_id"):
            issues.append(
                DDTRecaptureMovementsCsvIssue(severity="error", row_number=idx, field="tested_jurisdiction_id", message="Missing tested_jurisdiction_id.")
            )
        if data.get("fiscal_year_start") is None:
            issues.append(
                DDTRecaptureMovementsCsvIssue(severity="error", row_number=idx, field="fiscal_year_start", message="Missing fiscal_year_start (YYYY-MM-DD).")
            )
        if data.get("amount") is None:
            issues.append(DDTRecaptureMovementsCsvIssue(severity="error", row_number=idx, field="amount", message="Missing amount."))

        out.issues.extend(issues)

        try:
            if any(i.severity == "error" for i in issues):
                continue
            rows.append(DDTRecaptureAccountMovementV2.model_validate(data))
        except Exception as e:
            out.issues.append(DDTRecaptureMovementsCsvIssue(severity="error", row_number=idx, message=f"Row validation failed: {e}"))

    out.ddt_recapture_account_movements = rows
    return out
