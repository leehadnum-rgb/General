from __future__ import annotations

import csv
import io
import re
from datetime import date
from typing import Dict, List, Optional

from pydantic import BaseModel, Field

from app.services.models_v2 import AfterYearEndAdjustmentV2


_NUM_RE = re.compile(r"[^0-9eE+\-\.]")

def _norm_header(h: str) -> str:
    h = (h or "").strip().lower()
    h = re.sub(r"[\s\-]+", "_", h)
    return h


_ALIASES: Dict[str, str] = {
    "tj_id": "tested_jurisdiction_id",
    "tested_jurisdiction": "tested_jurisdiction_id",
    "tested_jurisdictionid": "tested_jurisdiction_id",
    "transaction_year": "transaction_year_fy_start",
    "transaction_fy_start": "transaction_year_fy_start",
    "accrual_year": "accrual_year_fy_start",
    "accrual_fy_start": "accrual_year_fy_start",
    "months_after_year_end": "months_after_transaction_year_end",
    "within_12_months": "accrued_within_12_months",
    "tp_related": "is_transfer_pricing_related",
    "transfer_pricing_related": "is_transfer_pricing_related",
    "large_refund_exclusion": "apply_large_refund_exclusion",
    "qualified_refund_exclusion": "apply_large_refund_exclusion",
    "basis": "qualification_basis",
    "attestation": "attestation_prior_year_etr_not_below_minimum",

    "counterparty_tj_id": "tp_counterparty_tested_jurisdiction_id",
    "counterparty_tested_jurisdiction_id": "tp_counterparty_tested_jurisdiction_id",
    "tp_counterparty": "tp_counterparty_tested_jurisdiction_id",
    "tp_counterparty_id": "tp_counterparty_tested_jurisdiction_id",
    "tp_apply_counterparty": "tp_apply_counterparty_income",
    "tp_apply_counterparty_income": "tp_apply_counterparty_income",
    "tp_counterparty_income": "tp_counterparty_income_amount",
    "tp_counterparty_income_amount": "tp_counterparty_income_amount",
    "tp_counterparty_tax": "tp_counterparty_tax_amount",
    "tp_counterparty_tax_amount": "tp_counterparty_tax_amount",
    "tp_accounted_at_cost": "tp_accounted_at_cost",
    "tp_intangible_asset_related": "tp_intangible_asset_related",
    "tp_loss_disallowed": "tp_loss_disallowed_deemed_tp_adjustment",
    "tp_loss_disallowed_deemed_tp_adjustment": "tp_loss_disallowed_deemed_tp_adjustment",
}


def _parse_float(raw: str) -> Optional[float]:
    if raw is None:
        return None
    s = str(raw).strip()
    if s == "":
        return None
    s = _NUM_RE.sub("", s)
    if s in {"", "+", "-", "."}:
        return None
    try:
        return float(s)
    except ValueError:
        return None


def _parse_int(raw: str) -> Optional[int]:
    if raw is None:
        return None
    s = str(raw).strip()
    if s == "":
        return None
    try:
        return int(float(s))
    except ValueError:
        return None


def _parse_date(raw: str) -> Optional[date]:
    if raw is None:
        return None
    s = str(raw).strip()
    if s == "":
        return None
    try:
        return date.fromisoformat(s)
    except ValueError:
        return None


def _parse_bool(raw: str) -> Optional[bool]:
    if raw is None:
        return None
    s = str(raw).strip().lower()
    if s == "":
        return None
    if s in {"1", "true", "t", "yes", "y"}:
        return True
    if s in {"0", "false", "f", "no", "n"}:
        return False
    return None


class AfterYearEndCsvIssue(BaseModel):
    severity: str = Field(..., description="'error' or 'warning'")
    row_number: int = Field(..., ge=1, description="1-indexed row number in the CSV (excluding header).")
    field: Optional[str] = Field(default=None, description="Column/field associated with the issue (if known).")
    message: str


class AfterYearEndCsvParseResult(BaseModel):
    adjustments: List[AfterYearEndAdjustmentV2] = Field(default_factory=list)
    issues: List[AfterYearEndCsvIssue] = Field(default_factory=list)
    detected_columns: List[str] = Field(default_factory=list)
    ignored_columns: List[str] = Field(default_factory=list)


def generate_after_year_end_adjustments_csv_template() -> bytes:
    """Generate a CSV template for Box 4.6 after-year-end adjustments."""

    headers = [
        "adjustment_id",
        "label",
        "tested_jurisdiction_id",
        "kind",  # income|tax
        "amount",
        "transaction_year_fy_start",  # YYYY-MM-DD
        "accrual_year_fy_start",       # YYYY-MM-DD
        "months_after_transaction_year_end",
        "accrued_within_12_months",
        "is_transfer_pricing_related",
        "tp_counterparty_tested_jurisdiction_id",
        "tp_apply_counterparty_income",
        "tp_counterparty_income_amount",
        "tp_counterparty_tax_amount",
        "tp_accounted_at_cost",
        "tp_intangible_asset_related",
        "tp_loss_disallowed_deemed_tp_adjustment",
        "currency",
        "amount_scale",  # UNITS|THOUSANDS|MILLIONS
        "attributable_to_income_change",
        "apply_large_refund_exclusion",
        "qualification_basis",  # SIMPLIFIED_ETR|GLOBE_ETR|ATTESTATION
        "prior_year_simplified_income",
        "prior_year_simplified_taxes",
        "prior_year_deferred_tax_effect",
        "attestation_prior_year_etr_not_below_minimum",
        "note",
    ]

    sample = {
        "adjustment_id": "AYE-001",
        "label": "Tax true-up for prior year",
        "tested_jurisdiction_id": "TJ-DE",
        "kind": "tax",
        "amount": "-250000",
        "transaction_year_fy_start": "2026-01-01",
        "accrual_year_fy_start": "2027-01-01",
        "months_after_transaction_year_end": "15",
        "accrued_within_12_months": "",
        "is_transfer_pricing_related": "false",
        "tp_counterparty_tested_jurisdiction_id": "",
        "tp_apply_counterparty_income": "",
        "tp_counterparty_income_amount": "",
        "tp_counterparty_tax_amount": "",
        "tp_accounted_at_cost": "",
        "tp_intangible_asset_related": "",
        "tp_loss_disallowed_deemed_tp_adjustment": "",

        "currency": "EUR",
        "amount_scale": "UNITS",
        "attributable_to_income_change": "false",
        "apply_large_refund_exclusion": "true",
        "qualification_basis": "ATTESTATION",
        "prior_year_simplified_income": "",
        "prior_year_simplified_taxes": "",
        "prior_year_deferred_tax_effect": "",
        "attestation_prior_year_etr_not_below_minimum": "true",
        "note": "Example only",
    }

    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=headers)
    writer.writeheader()
    writer.writerow(sample)
    return buf.getvalue().encode("utf-8")


def parse_after_year_end_adjustments_csv(contents: bytes) -> AfterYearEndCsvParseResult:
    text = contents.decode("utf-8-sig", errors="replace")
    buf = io.StringIO(text)
    reader = csv.DictReader(buf)
    if reader.fieldnames is None:
        return AfterYearEndCsvParseResult(
            adjustments=[],
            issues=[AfterYearEndCsvIssue(severity="error", row_number=1, field=None, message="CSV is missing a header row.")],
        )

    raw_headers = list(reader.fieldnames)
    norm_to_raw: Dict[str, str] = {}
    for h in raw_headers:
        nh = _norm_header(h)
        nh = _ALIASES.get(nh, nh)
        if nh and nh not in norm_to_raw:
            norm_to_raw[nh] = h

    detected = list(norm_to_raw.keys())
    allowed = set(AfterYearEndAdjustmentV2.model_fields.keys())
    ignored_cols: List[str] = []
    for nh in detected:
        if nh not in allowed:
            ignored_cols.append(norm_to_raw.get(nh, nh))

    out = AfterYearEndCsvParseResult(detected_columns=raw_headers, ignored_columns=ignored_cols)

    adjustments: List[AfterYearEndAdjustmentV2] = []
    issues: List[AfterYearEndCsvIssue] = []

    # Required fields
    req_fields = {"tested_jurisdiction_id", "kind", "amount", "transaction_year_fy_start", "accrual_year_fy_start"}

    for i, row in enumerate(reader, start=1):
        rownum = i

        parsed: Dict[str, object] = {}
        for nh, raw in norm_to_raw.items():
            if nh in ignored_cols:
                continue
            val = row.get(raw)

            # Parse by column name
            if nh in {"amount", "prior_year_simplified_income", "prior_year_simplified_taxes", "prior_year_deferred_tax_effect", "tp_counterparty_income_amount", "tp_counterparty_tax_amount"}:
                parsed[nh] = _parse_float(val)
            elif nh in {"months_after_transaction_year_end"}:
                parsed[nh] = _parse_int(val)
            elif nh in {"transaction_year_fy_start", "accrual_year_fy_start"}:
                parsed[nh] = _parse_date(val)
            elif nh in {
                "accrued_within_12_months",
                "is_transfer_pricing_related",
                "attributable_to_income_change",
                "apply_large_refund_exclusion",
                "attestation_prior_year_etr_not_below_minimum",
                "tp_apply_counterparty_income",
                "tp_accounted_at_cost",
                "tp_intangible_asset_related",
                "tp_loss_disallowed_deemed_tp_adjustment",
            }:
                b = _parse_bool(val)
                if b is not None:
                    parsed[nh] = b
            else:
                parsed[nh] = (str(val).strip() if val is not None else "")

        # Required field checks
        missing = [f for f in req_fields if not parsed.get(f)]
        if missing:
            issues.append(
                AfterYearEndCsvIssue(
                    severity="error",
                    row_number=rownum,
                    field=",".join(missing),
                    message="Missing required field(s).",
                )
            )
            continue

        # kind normalisation
        parsed["kind"] = str(parsed.get("kind") or "").strip().lower()

        # Pass through empty strings as None for selected fields
        for f in ["adjustment_id", "label", "currency", "amount_scale", "qualification_basis", "tp_counterparty_tested_jurisdiction_id", "note"]:
            if f in parsed and isinstance(parsed[f], str) and parsed[f] == "":
                parsed[f] = None

        try:
            adj = AfterYearEndAdjustmentV2.model_validate(parsed)
            adjustments.append(adj)
        except Exception as e:
            issues.append(
                AfterYearEndCsvIssue(
                    severity="error",
                    row_number=rownum,
                    field=None,
                    message=str(e),
                )
            )

    out.adjustments = adjustments
    out.issues = issues
    return out
