import unittest
from datetime import date

from app.services.calculator_v2 import calculate_v2
from app.services.models_v2 import (
    CalculationRequestV2,
    FiscalYearV2,
    TestedJurisdictionInputV2,
    TestedJurisdictionCompositionV2,
    JurisdictionFactsV2,
    ElectionInstanceV2,
    AfterYearEndAdjustmentV2,
    TransferPricingAdjustmentV2,
)


class TransferPricingRegisterV2Tests(unittest.TestCase):
    def test_tp_register_transaction_year_method_and_default_symmetry(self):
        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            group_elections=[
                ElectionInstanceV2(
                    election_code="TP_FIVE_YEAR_ELECTION_TRANSACTION_YEAR_METHOD",
                    scope="metadata",
                    value_type="bool",
                    bool_value=True,
                    effective_fiscal_year_start=date(2027, 1, 1),
                )
            ],
            transfer_pricing_adjustments=[
                TransferPricingAdjustmentV2(
                    adjustment_id="TP-001",
                    label="TP income true-up",
                    seller_tested_jurisdiction_id="A",
                    buyer_tested_jurisdiction_id="B",
                    transaction_year_fy_start=date(2027, 1, 1),
                    accrual_year_fy_start=date(2028, 1, 1),
                    months_after_transaction_year_end=6,
                    seller_income_adjustment=100.0,
                    # buyer_income_adjustment omitted -> defaults to -100
                )
            ],
            tested_jurisdictions=[
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="A",
                    jurisdiction_code="AA",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    facts=JurisdictionFactsV2(jpbt=1000.0, current_tax_expense=200.0),
                ),
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="B",
                    jurisdiction_code="BB",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    facts=JurisdictionFactsV2(jpbt=1000.0, current_tax_expense=200.0),
                ),
            ],
        )

        resp = calculate_v2(req)
        by_id = {r.tested_jurisdiction_id: r for r in resp.results}

        self.assertAlmostEqual(by_id["A"].simplified_income, 1100.0)
        self.assertAlmostEqual(by_id["B"].simplified_income, 900.0)

        # Trace should show the register wording
        self.assertTrue(any("Transfer pricing register (section 5.2)" in t.step for t in by_id["A"].trace))
        self.assertTrue(any("Transfer pricing register (section 5.2)" in t.step for t in by_id["B"].trace))

    def test_tp_register_special_case_requires_explicit_buyer_income(self):
        with self.assertRaises(ValueError):
            TransferPricingAdjustmentV2(
                adjustment_id="TP-002",
                seller_tested_jurisdiction_id="A",
                buyer_tested_jurisdiction_id="B",
                transaction_year_fy_start=date(2027, 1, 1),
                accrual_year_fy_start=date(2028, 1, 1),
                seller_income_adjustment=100.0,
                tp_intangible_asset_related=True,
                # buyer_income_adjustment is required for special case
            )

    def test_tp_register_disallows_tp_rows_in_box46_when_register_present(self):
        # If register is used, TP after-year-end rows should be disallowed to avoid double counting.
        with self.assertRaises(ValueError):
            CalculationRequestV2(
                fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
                minimum_rate=0.15,
                transfer_pricing_adjustments=[
                    TransferPricingAdjustmentV2(
                        adjustment_id="TP-003",
                        seller_tested_jurisdiction_id="A",
                        buyer_tested_jurisdiction_id="B",
                        transaction_year_fy_start=date(2027, 1, 1),
                        accrual_year_fy_start=date(2028, 1, 1),
                        seller_income_adjustment=10.0,
                    )
                ],
                after_year_end_adjustments=[
                    AfterYearEndAdjustmentV2(
                        adjustment_id="TP-AYE-001",
                        tested_jurisdiction_id="A",
                        kind="income",
                        amount=10.0,
                        transaction_year_fy_start=date(2027, 1, 1),
                        accrual_year_fy_start=date(2028, 1, 1),
                        is_transfer_pricing_related=True,
                        months_after_transaction_year_end=6,
                        tp_counterparty_tested_jurisdiction_id="B",
                    )
                ],
                tested_jurisdictions=[
                    TestedJurisdictionInputV2(
                        tested_jurisdiction_id="A",
                        jurisdiction_code="AA",
                        composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                        facts=JurisdictionFactsV2(jpbt=1000.0, current_tax_expense=200.0),
                    ),
                    TestedJurisdictionInputV2(
                        tested_jurisdiction_id="B",
                        jurisdiction_code="BB",
                        composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                        facts=JurisdictionFactsV2(jpbt=1000.0, current_tax_expense=200.0),
                    ),
                ],
            )


if __name__ == "__main__":
    unittest.main()
