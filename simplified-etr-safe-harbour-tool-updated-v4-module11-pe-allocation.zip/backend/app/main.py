import os

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse

from app.api.routes import router as api_router

app = FastAPI(
    title="Simplified ETR Safe Harbour Tool (Prototype)",
    version="0.1.0",
    description=(
        "Prototype calculator aligned to the OECD Pillar Two Side-by-Side Package (Jan 2026). "
        "Provides Excel upload + JSON API calculation for Simplified ETR Safe Harbour."
    ),
)

# Optional CORS configuration. If you embed this tool into a site (e.g. WordPress)
# but run the API on a different domain/subdomain, browsers will enforce CORS.
#
# Set `CORS_ALLOW_ORIGINS` to a comma-separated list of allowed origins, e.g.:
#   CORS_ALLOW_ORIGINS="https://oecdpillars.com,https://www.oecdpillars.com"
#
# If not set, the prototype allows all origins for convenience.
_origins_env = os.getenv("CORS_ALLOW_ORIGINS", "").strip()
_origins = [o.strip() for o in _origins_env.split(",") if o.strip()] if _origins_env else ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=_origins,
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router, prefix="/api")


@app.get("/", response_class=HTMLResponse)
def home():
    # Demo-friendly UI that supports:
    #   (1) Excel template upload (incl. election adjustment table)
    #   (2) Manual guided entry (jurisdiction or entity roll-up)
    return HTMLResponse(
        """<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Simplified ETR Safe Harbour Tool (Prototype)</title>
  <style>
    body { font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial; margin: 2rem; }
    .container { max-width: 1100px; }
    .card { border: 1px solid #ddd; border-radius: 12px; padding: 1rem 1.25rem; }
    .tabs { display: flex; gap: 0.5rem; margin: 1rem 0; }
    .tab { border: 1px solid #ccc; padding: 0.5rem 0.75rem; border-radius: 999px; background: #fff; cursor: pointer; }
    .tab.active { border-color: #0b63ce; box-shadow: 0 0 0 2px rgba(11,99,206,0.15); }
    .row { display: flex; gap: 1rem; flex-wrap: wrap; }
    .col { flex: 1 1 360px; }
    label { display: block; font-size: 0.9rem; margin-top: 0.6rem; }
    input, select, textarea { width: 100%; padding: 0.45rem 0.55rem; border: 1px solid #ccc; border-radius: 10px; }
    input[type=checkbox] { width: auto; }
    button { margin-top: 0.75rem; padding: 0.55rem 0.95rem; border-radius: 10px; border: 1px solid #ccc; background: #fff; cursor: pointer; }
    button.primary { border-color: #0b63ce; }
    code { background: #f6f8fa; padding: 0.15rem 0.3rem; border-radius: 6px; }
    pre { white-space: pre-wrap; word-break: break-word; background: #0b1020; color: #d6e1ff; padding: 1rem; border-radius: 12px; }
    .muted { color: #666; }
    .pill { display: inline-block; padding: 0.15rem 0.5rem; border-radius: 999px; border: 1px solid #ddd; margin-right: 0.35rem; font-size: 0.85rem; }
    details { border: 1px solid #eee; border-radius: 12px; padding: 0.75rem; margin-top: 0.75rem; }
    summary { cursor: pointer; font-weight: 600; }
    table { border-collapse: collapse; width: 100%; }
    th, td { border-bottom: 1px solid #eee; text-align: left; padding: 0.4rem; font-size: 0.9rem; }
    .danger { color: #a30000; }
  </style>
</head>
<body>
  <div class="container">
    <h1>Simplified ETR Safe Harbour Tool (Prototype)</h1>
    <p class="muted">
      This prototype supports either <span class="pill">manual guided entry</span> or <span class="pill">Excel template upload</span>.
      The template includes an <code>ElectionAdjustments</code> table to record elections and net impacts.
    </p>

    <div class="card">
      <div class="row">
        <div class="col">
          <strong>Quick links</strong>
          <ul>
            <li>Download template: <a href="/api/v1/template">/api/v1/template</a></li>
            <li>Election catalog (JSON): <a href="/api/v1/election-catalog">/api/v1/election-catalog</a></li>
            <li>API docs: <a href="/docs">/docs</a></li>
          </ul>
        </div>
        <div class="col">
          <strong>How elections are handled</strong>
          <p class="muted" style="margin-top:0.25rem">
            Some elections map directly to dedicated fields (e.g. shipping 5-year election, AFXGL election, annual tax elections).
            All other elections/optional items can be recorded as <em>net signed</em> income/tax adjustments via:
            <code>ElectionAdjustments</code>, <code>IncomeAdjustments</code>, and <code>TaxAdjustments</code>.
          </p>
        </div>
      </div>

      <div class="tabs">
        <button class="tab active" id="tabUpload">Excel upload</button>
        <button class="tab" id="tabManual">Manual entry</button>
      </div>

      <div id="panelUpload">
        <h2 style="margin-top:0">Upload Excel template</h2>
        <p class="muted">Upload a filled template. Use <code>input_mode</code> in <code>Jurisdictions!C2</code> to switch between jurisdiction and entity roll-up.</p>
        <form id="uploadForm">
          <input type="file" id="file" name="file" accept=".xlsx" />
          <br />
          <button class="primary" type="submit">Calculate from Excel</button>
        </form>
      </div>

      <div id="panelManual" style="display:none">
        <h2 style="margin-top:0">Manual guided entry</h2>
        <div class="row">
          <div class="col">
            <label>Fiscal year start date</label>
            <input type="date" id="fyStart" value="2027-01-01" />

            <label>Minimum rate</label>
            <input type="number" id="minRate" step="0.0001" value="0.15" />

            <label>Input mode</label>
            <select id="inputMode">
              <option value="jurisdiction" selected>jurisdiction (jurisdictional inputs)</option>
              <option value="entity_rollup">entity_rollup (entity inputs + jurisdiction meta)</option>
            </select>

            <details>
              <summary>Applicability date options (advanced)</summary>
              <p class="muted">Required only if FY start is between 31 Dec 2025 and 30 Dec 2026 and you want to use the optional early-start rule.</p>
              <label><input type="checkbox" id="applyEarlyStart" /> apply_optional_2025_start_rule</label>
              <label><input type="checkbox" id="earlyQdmtt" /> early_start_qdmtt_safe_harbour_applies</label>
              <label><input type="checkbox" id="earlyOneJur" /> early_start_only_one_jurisdiction_has_taxing_rights</label>
              <label><input type="checkbox" id="earlyAllAllow" /> early_start_all_taxing_rights_jurisdictions_allow</label>
            </details>
          </div>

          <div class="col">
            <details open>
              <summary>Add / edit jurisdictions (and meta elections)</summary>
              <div id="jurisdictionForm"></div>
              <button id="addJurisdiction" type="button">Add jurisdiction</button>
              <div style="margin-top:0.75rem">
                <strong>Added jurisdictions</strong>
                <div class="muted" style="margin:0.25rem 0 0.5rem">(Meta flags matter in entity_rollup mode too.)</div>
                <table>
                  <thead><tr><th>Code</th><th>JPBT</th><th>JITE current</th><th>JITE deferred</th><th></th></tr></thead>
                  <tbody id="jurisdictionList"></tbody>
                </table>
              </div>
            </details>
          </div>
        </div>

        <div class="row">
          <div class="col" id="entityBlock" style="display:none">
            <details open>
              <summary>Add entities (entity_rollup mode)</summary>
              <div id="entityForm"></div>
              <button id="addEntity" type="button">Add entity</button>
              <div style="margin-top:0.75rem">
                <strong>Added entities</strong>
                <table>
                  <thead><tr><th>Entity</th><th>Jur</th><th>JPBT</th><th>Current tax</th><th>Deferred tax</th><th></th></tr></thead>
                  <tbody id="entityList"></tbody>
                </table>
              </div>
            </details>
          </div>

          <div class="col">
            <details open>
              <summary>Elections & net adjustments table</summary>
              <p class="muted">
                Use this to apply elections that map to fields (e.g. shipping 5-year election) or to record
                net income/tax impacts for elections not hard-coded in the prototype.
              </p>
              <div class="row">
                <div class="col">
                  <label>Jurisdiction code</label>
                  <select id="adjJur"></select>
                </div>
                <div class="col">
                  <label>Election / adjustment code</label>
                  <select id="adjCode"></select>
                  <label>Custom code (optional)</label>
                  <input type="text" id="adjCodeCustom" placeholder="e.g. ART_4_3_2_ELECTION_NET_IMPACT" />
                </div>
              </div>

              <div class="row">
                <div class="col">
                  <label>Scope</label>
                  <select id="adjScope">
                    <option value="income">income</option>
                    <option value="tax">tax</option>
                    <option value="eligibility">eligibility</option>
                    <option value="metadata">metadata</option>
                  </select>
                </div>
                <div class="col">
                  <label>Amount (signed)</label>
                  <input type="number" id="adjAmount" step="any" placeholder="e.g. -125000" />
                </div>
                <div class="col">
                  <label>Boolean value</label>
                  <select id="adjBool">
                    <option value="">(blank)</option>
                    <option value="true">true</option>
                    <option value="false">false</option>
                  </select>
                </div>
              </div>

              <label>Label / note</label>
              <input type="text" id="adjLabel" placeholder="Optional label" />
              <label>Note</label>
              <input type="text" id="adjNote" placeholder="Optional note" />

              <button id="applyElectionAdj" type="button">Apply to jurisdiction</button>

              <div style="margin-top:0.75rem">
                <strong>Recorded net adjustments</strong>
                <table>
                  <thead><tr><th>Jur</th><th>Scope</th><th>Code</th><th>Label</th><th>Bool</th><th>Amount</th><th></th></tr></thead>
                  <tbody id="adjList"></tbody>
                </table>
              </div>
            </details>
          </div>
        </div>

        <button class="primary" id="calcManual" type="button">Calculate from manual inputs</button>
        <button id="toggleJson" type="button">Show / hide JSON request</button>

        <details id="jsonBox" style="display:none">
          <summary>JSON request</summary>
          <pre id="jsonReq"></pre>
        </details>
      </div>

      <h2>Result</h2>
      <pre id="out">Fill inputs and calculate to see results.</pre>
    </div>
  </div>

<script>
  // ---------------------------------------------
  // Tabs
  // ---------------------------------------------
  const tabUpload = document.getElementById('tabUpload');
  const tabManual = document.getElementById('tabManual');
  const panelUpload = document.getElementById('panelUpload');
  const panelManual = document.getElementById('panelManual');
  function activate(tab) {
    if (tab === 'upload') {
      tabUpload.classList.add('active');
      tabManual.classList.remove('active');
      panelUpload.style.display = '';
      panelManual.style.display = 'none';
    } else {
      tabManual.classList.add('active');
      tabUpload.classList.remove('active');
      panelManual.style.display = '';
      panelUpload.style.display = 'none';
    }
  }
  tabUpload.addEventListener('click', () => activate('upload'));
  tabManual.addEventListener('click', () => activate('manual'));

  // ---------------------------------------------
  // Excel upload
  // ---------------------------------------------
  const out = document.getElementById('out');
  const uploadForm = document.getElementById('uploadForm');
  uploadForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fileInput = document.getElementById('file');
    if (!fileInput.files.length) {
      out.textContent = "Please choose an .xlsx file first.";
      return;
    }
    const fd = new FormData();
    fd.append('file', fileInput.files[0]);
    out.textContent = "Calculating...";
    try {
      const resp = await fetch('/api/v1/calc-from-excel', { method: 'POST', body: fd });
      let payload;
      try {
        payload = await resp.json();
      } catch {
        payload = {detail: await resp.text()};
      }
      if (!resp.ok) {
        out.textContent = JSON.stringify({error: 'Upload failed', ...payload}, null, 2);
        return;
      }
      out.textContent = JSON.stringify(payload, null, 2);
    } catch (err) {
      out.textContent = String(err);
    }
  });

  // ---------------------------------------------
  // Manual entry state
  // ---------------------------------------------
  const state = {
    jurisdictions: [],
    entities: [],
    // Election adjustments / net impacts recorded via the Election Adjustments panel.
    // For unmapped election codes:
    //  - income/tax scopes are translated into other_income_adjustments / other_tax_adjustments
    //  - all scopes are recorded into jurisdiction.election_records (audit trail)
    netAdjustments: [],  // {jur, scope, code, label, bool_value, amount, note}
    electionCatalog: [],
    electionByCode: {}
  };

  // Field definitions (subset is required, the rest is optional)
  const J_FIELDS = [
    {
      group: 'Core starting points',
      fields: [
        {name:'jurisdiction_code', label:'Jurisdiction code', type:'text', required:true},
        {name:'jpbt', label:'JPBT', type:'number', default:0},
      ]
    },
    {
      group: 'Basic adjustments (Box 3.2)',
      fields: [
        {name:'excluded_dividends', label:'Excluded dividends', type:'number', default:0},
        {name:'excluded_equity_gains_losses', label:'Excluded equity gains/losses', type:'number', default:0},
        {name:'illegal_payments', label:'Illegal payments (add-back)', type:'number', default:0},
        {name:'fines_penalties_ge_250k', label:'Fines/penalties >= 250k (add-back)', type:'number', default:0},
      ]
    },
    {
      group: 'Industry: financial services & shipping (Box 3.3)',
      fields: [
        {name:'insurance_company_income', label:'Insurance company income', type:'number', default:0},
        {name:'fs_annual_election_not_to_exclude_insurance_income', label:'FS annual election not to exclude insurance income', type:'bool', default:false},
        {name:'at1_rt1_payments_receipts_adjustment', label:'AT1/RT1 payments/receipts adjustment', type:'number', default:0},
        {name:'at1_rt1_corresponding_tax_in_equity', label:'AT1/RT1 corresponding tax in equity/OCI', type:'number', default:0},
        {name:'international_shipping_income', label:'International shipping income', type:'number', default:0},
        {name:'qualified_ancillary_international_shipping_income', label:'Qualified ancillary international shipping income', type:'number', default:0},
        {name:'shipping_five_year_election_not_to_exclude', label:'Shipping 5-year election not to exclude', type:'bool', default:false},
        {name:'taxes_on_excluded_shipping_income', label:'Taxes on excluded shipping income', type:'number', default:0},
      ]
    },
    {
      group: 'Conditional adjustments (Box 3.4)',
      fields: [
        {name:'equity_reported_items_amount', label:'Equity-reported items amount', type:'number', default:0},
        {name:'equity_reported_items_subject_to_tax_at_or_above_minimum_rate', label:'Equity items taxed >= minimum', type:'bool', default:false},
        {name:'equity_reported_items_related_taxes_accounted_in_equity_or_oci', label:'Equity item taxes in equity/OCI', type:'bool', default:false},
        {name:'equity_reported_items_related_tax_is_deferred_tax_liability', label:'Related tax is DTL', type:'bool', default:false},
        {name:'equity_reported_items_related_dtl_is_recapture_exception_accrual', label:'Related DTL is REA', type:'bool', default:false},
        {name:'mna_simplification_applied', label:'M&A simplification applies', type:'bool', default:false},
        {name:'mna_goodwill_impairment_or_amortisation_addback', label:'M&A goodwill impairment/amortisation add-back', type:'number', default:0},
        {name:'mna_article_6_3_4_election_amount', label:'Article 6.3.4 election amount', type:'number', default:0},
      ]
    },
    {
      group: 'Optional exclusions (Box 3.5.2)',
      fields: [
        {name:'asymmetric_fx_gain_loss', label:'Asymmetric FX gain/loss adjustment', type:'number', default:0},
        {name:'afxgl_five_year_election_not_to_apply', label:'AFXGL 5-year election not to apply', type:'bool', default:false},
        {name:'accrued_pension_expense_adjustment', label:'Accrued pension expense adjustment', type:'number', default:0},
        {name:'pension_five_year_election_not_to_apply', label:'Pension 5-year election not to apply', type:'bool', default:false},
      ]
    },
    {
      group: 'Taxes (starting point + adjustments)',
      fields: [
        {name:'current_tax_expense', label:'Current tax expense (JITE)', type:'number', default:0},
        {name:'deferred_tax_expense', label:'Deferred tax expense (JITE)', type:'number', default:0},
        {name:'consolidated_level_deferred_tax', label:'Consolidated-level deferred tax attributable', type:'number', default:0},
        {name:'taxes_not_covered', label:'Taxes not covered', type:'number', default:0},
        {name:'tax_refunds_and_credits_adjustment', label:'Tax refunds/credits adjustment', type:'number', default:0},
        {name:'taxes_on_excluded_income', label:'Taxes on excluded income', type:'number', default:0},
        {name:'uncertain_tax_positions_adjustment', label:'Uncertain tax positions adjustment', type:'number', default:0},
        {name:'current_tax_not_paid_within_3y', label:'Current tax not paid within 3 years', type:'number', default:0},
        {name:'accounted_tax_rate', label:'Accounted tax rate (for deferred recast)', type:'optionalNumber', default:null},
        {name:'valuation_allowance_impact', label:'Valuation allowance/recognition impact', type:'number', default:0},
        {name:'tax_rate_change_impact', label:'Impact of tax rate changes (exclude)', type:'number', default:0},
        {name:'deferred_tax_from_tax_credits', label:'Deferred tax from tax credits (exclude)', type:'number', default:0},
        {name:'non_rea_dtl_deferred_tax_expense', label:'Non-REA DTL deferred tax expense (exclude)', type:'number', default:0},
        {name:'non_rea_dtl_exception_applies', label:'Non-REA DTL exception applies', type:'bool', default:false},
        {name:'mna_deferred_tax_accruals_to_exclude', label:'M&A: deferred tax accruals to exclude', type:'number', default:0},
        {name:'mna_goodwill_related_dtl_reversal_to_exclude', label:'M&A: goodwill-related DTL reversal to exclude', type:'number', default:0},
      ]
    },
    {
      group: 'Annual elections (Box 4.4)',
      fields: [
        {name:'election_include_other_covered_taxes', label:'Include other covered taxes (amount)', type:'number', default:0},
        {name:'election_include_equity_reported_taxes', label:'Include equity-reported taxes (amount)', type:'number', default:0},
        {name:'election_include_qrtc_mttc_credits_in_income', label:'Include QRTC/MTTC credits in income (amount)', type:'number', default:0},
        {name:'election_include_qrtc_mttc_credits_in_taxes', label:'Include QRTC/MTTC credits in taxes (amount)', type:'number', default:0},
      ]
    },
    {
      group: 'Eligibility flags (Box 7)',
      fields: [
        {name:'ineligible_stateless', label:'Ineligible: stateless', type:'bool', default:false},
        {name:'stateless_exception_section_6_2_applies', label:'Exception: Section 6.2 applies (stateless)', type:'bool', default:false},
        {name:'ineligible_investment_entity', label:'Ineligible: investment entity', type:'bool', default:false},
        {name:'investment_entity_tax_transparency_election_applies', label:'Exception: Art 7.5 transparency election applies', type:'bool', default:false},
        {name:'ineligible_article7_3_outstanding_recapture', label:'Ineligible: Art 7.3 outstanding recapture', type:'bool', default:false},
        {name:'no_topup_tax_in_prior_24_months', label:'Entry condition: no top-up in prior 24 months', type:'bool', default:true},
        {name:'reentry_no_topup_tax_in_prior_24_months', label:'Re-entry condition (nullable)', type:'nullableBool', default:null},
        {name:'integrity_rules_satisfied', label:'Integrity rules satisfied', type:'bool', default:true},
      ]
    }
  ];

  const E_FIELDS = [
    {
      group: 'Entity starting points',
      fields: [
        {name:'entity_id', label:'Entity ID (optional)', type:'text', required:false},
        {name:'entity_name', label:'Entity name', type:'text', required:true},
        {name:'jurisdiction_code', label:'Jurisdiction code', type:'text', required:true},
        {name:'jpbt', label:'JPBT', type:'number', default:0},
      ]
    },
    {
      group: 'Entity basic adjustments (Box 3.2)',
      fields: [
        {name:'excluded_dividends', label:'Excluded dividends', type:'number', default:0},
        {name:'excluded_equity_gains_losses', label:'Excluded equity gains/losses', type:'number', default:0},
        {name:'illegal_payments', label:'Illegal payments (add-back)', type:'number', default:0},
        {name:'fines_penalties_ge_250k', label:'Fines/penalties >= 250k (add-back)', type:'number', default:0},
      ]
    },
    {
      group: 'Entity industry amounts (Box 3.3)',
      fields: [
        {name:'insurance_company_income', label:'Insurance company income', type:'number', default:0},
        {name:'at1_rt1_payments_receipts_adjustment', label:'AT1/RT1 payments/receipts adjustment', type:'number', default:0},
        {name:'at1_rt1_corresponding_tax_in_equity', label:'AT1/RT1 corresponding tax in equity/OCI', type:'number', default:0},
        {name:'international_shipping_income', label:'International shipping income', type:'number', default:0},
        {name:'qualified_ancillary_international_shipping_income', label:'Qualified ancillary international shipping income', type:'number', default:0},
        {name:'taxes_on_excluded_shipping_income', label:'Taxes on excluded shipping income', type:'number', default:0},
      ]
    },
    {
      group: 'Entity conditional/optional income amounts (Box 3.4 / 3.5)',
      fields: [
        {name:'equity_reported_items_amount', label:'Equity-reported items amount', type:'number', default:0},
        {name:'mna_goodwill_impairment_or_amortisation_addback', label:'M&A goodwill impairment/amortisation add-back', type:'number', default:0},
        {name:'mna_article_6_3_4_election_amount', label:'Article 6.3.4 election amount', type:'number', default:0},
        {name:'asymmetric_fx_gain_loss', label:'Asymmetric FX gain/loss adjustment', type:'number', default:0},
        {name:'accrued_pension_expense_adjustment', label:'Accrued pension expense adjustment', type:'number', default:0},
      ]
    },
    {
      group: 'Entity taxes (starting points)',
      fields: [
        {name:'current_tax_expense', label:'Current tax expense', type:'number', default:0},
        {name:'deferred_tax_expense', label:'Deferred tax expense', type:'number', default:0},
        {name:'consolidated_level_deferred_tax', label:'Consolidated-level deferred tax attributable', type:'number', default:0},
      ]
    },
    {
      group: 'Entity tax adjustments (Box 4)',
      fields: [
        {name:'taxes_not_covered', label:'Taxes not covered', type:'number', default:0},
        {name:'tax_refunds_and_credits_adjustment', label:'Tax refunds/credits adjustment', type:'number', default:0},
        {name:'taxes_on_excluded_income', label:'Taxes on excluded income', type:'number', default:0},
        {name:'uncertain_tax_positions_adjustment', label:'Uncertain tax positions adjustment', type:'number', default:0},
        {name:'current_tax_not_paid_within_3y', label:'Current tax not paid within 3 years', type:'number', default:0},
      ]
    },
    {
      group: 'Entity deferred tax adjustments (Box 4.2.4 / 4.2.5)',
      fields: [
        {name:'accounted_tax_rate', label:'Accounted tax rate (optional)', type:'optionalNumber', default:null},
        {name:'valuation_allowance_impact', label:'Valuation allowance/recognition impact', type:'number', default:0},
        {name:'tax_rate_change_impact', label:'Impact of tax rate changes (exclude)', type:'number', default:0},
        {name:'deferred_tax_from_tax_credits', label:'Deferred tax from tax credits (exclude)', type:'number', default:0},
        {name:'non_rea_dtl_deferred_tax_expense', label:'Non-REA DTL deferred tax expense', type:'number', default:0},
        {name:'non_rea_dtl_exception_applies', label:'Non-REA DTL exception applies', type:'bool', default:false},
      ]
    },
    {
      group: 'Entity M&A tax-side amounts (Box 3.4.2)',
      fields: [
        {name:'mna_deferred_tax_accruals_to_exclude', label:'M&A: deferred tax accruals to exclude', type:'number', default:0},
        {name:'mna_goodwill_related_dtl_reversal_to_exclude', label:'M&A: goodwill-related DTL reversal to exclude', type:'number', default:0},
      ]
    },
    {
      group: 'Entity election amounts (Box 4.4)',
      fields: [
        {name:'election_include_other_covered_taxes', label:'Include other covered taxes (amount)', type:'number', default:0},
        {name:'election_include_equity_reported_taxes', label:'Include equity-reported taxes (amount)', type:'number', default:0},
        {name:'election_include_qrtc_mttc_credits_in_income', label:'Include QRTC/MTTC credits in income (amount)', type:'number', default:0},
        {name:'election_include_qrtc_mttc_credits_in_taxes', label:'Include QRTC/MTTC credits in taxes (amount)', type:'number', default:0},
      ]
    }
  ];

  function el(tag, attrs={}, children=[]) {
    const node = document.createElement(tag);
    Object.entries(attrs).forEach(([k,v]) => {
      if (k === 'class') node.className = v;
      else if (k === 'html') node.innerHTML = v;
      else node.setAttribute(k, v);
    });
    children.forEach(c => node.appendChild(c));
    return node;
  }

  function renderForm(containerId, fields, prefix) {
    const container = document.getElementById(containerId);
    container.innerHTML = '';
    fields.forEach(group => {
      const d = el('details', {open: ''});
      const s = el('summary', {html: group.group});
      d.appendChild(s);
      group.fields.forEach(f => {
        const wrap = el('div');
        const id = `${prefix}${f.name}`;
        const lab = el('label', {for: id, html: f.label + (f.required ? ' <span class="danger">*</span>' : '')});
        wrap.appendChild(lab);

        let input;
        if (f.type === 'bool') {
          input = el('input', {id, type:'checkbox'});
          if (f.default === true) input.checked = true;
        } else if (f.type === 'nullableBool') {
          input = el('select', {id});
          input.appendChild(el('option', {value:'', html:'(blank)'}));
          input.appendChild(el('option', {value:'true', html:'true'}));
          input.appendChild(el('option', {value:'false', html:'false'}));
        } else {
          input = el('input', {id, type: f.type === 'number' || f.type === 'optionalNumber' ? 'number' : 'text'});
          if (f.type === 'number') {
            input.step = 'any';
            input.value = String(f.default ?? 0);
          } else if (f.type === 'optionalNumber') {
            input.step = 'any';
            input.placeholder = '(blank)';
          } else if (f.type === 'text') {
            input.value = String(f.default ?? '');
          }
        }
        wrap.appendChild(input);
        d.appendChild(wrap);
      });
      container.appendChild(d);
    });
  }

  function readForm(fields, prefix) {
    const obj = {};
    for (const group of fields) {
      for (const f of group.fields) {
        const id = `${prefix}${f.name}`;
        const node = document.getElementById(id);
        if (!node) continue;

        if (f.type === 'bool') {
          obj[f.name] = !!node.checked;
        } else if (f.type === 'nullableBool') {
          const v = node.value;
          if (v === '') obj[f.name] = null;
          else obj[f.name] = (v === 'true');
        } else if (f.type === 'number') {
          const v = node.value;
          obj[f.name] = v === '' ? 0 : Number(v);
        } else if (f.type === 'optionalNumber') {
          const v = node.value;
          obj[f.name] = v === '' ? null : Number(v);
        } else {
          obj[f.name] = (node.value ?? '').trim();
        }
      }
    }
    return obj;
  }

  function ensureJurList() {
    const sel = document.getElementById('adjJur');
    sel.innerHTML = '';
    if (!state.jurisdictions.length) {
      sel.appendChild(el('option', {value:'', html:'(add a jurisdiction first)'}));
      return;
    }
    state.jurisdictions.forEach(j => {
      sel.appendChild(el('option', {value: j.jurisdiction_code, html: j.jurisdiction_code}));
    });
  }

  function renderJurisdictionList() {
    const tbody = document.getElementById('jurisdictionList');
    tbody.innerHTML = '';
    state.jurisdictions.forEach((j, idx) => {
      const tr = document.createElement('tr');
      tr.appendChild(el('td', {html: j.jurisdiction_code}));
      tr.appendChild(el('td', {html: String(j.jpbt ?? 0)}));
      tr.appendChild(el('td', {html: String(j.current_tax_expense ?? 0)}));
      tr.appendChild(el('td', {html: String(j.deferred_tax_expense ?? 0)}));
      const btn = el('button', {type:'button', html:'Remove'});
      btn.addEventListener('click', () => {
        state.jurisdictions.splice(idx,1);
        // also purge net adjustments for that jurisdiction
        state.netAdjustments = state.netAdjustments.filter(a => a.jur !== j.jurisdiction_code);
        renderJurisdictionList();
        renderAdjList();
        ensureJurList();
      });
      const tdBtn = document.createElement('td');
      tdBtn.appendChild(btn);
      tr.appendChild(tdBtn);
      tbody.appendChild(tr);
    });
    ensureJurList();
  }

  function renderEntityList() {
    const tbody = document.getElementById('entityList');
    tbody.innerHTML = '';
    state.entities.forEach((e, idx) => {
      const tr = document.createElement('tr');
      tr.appendChild(el('td', {html: e.entity_name}));
      tr.appendChild(el('td', {html: e.jurisdiction_code}));
      tr.appendChild(el('td', {html: String(e.jpbt ?? 0)}));
      tr.appendChild(el('td', {html: String(e.current_tax_expense ?? 0)}));
      tr.appendChild(el('td', {html: String(e.deferred_tax_expense ?? 0)}));
      const btn = el('button', {type:'button', html:'Remove'});
      btn.addEventListener('click', () => {
        state.entities.splice(idx,1);
        renderEntityList();
      });
      const tdBtn = document.createElement('td');
      tdBtn.appendChild(btn);
      tr.appendChild(tdBtn);
      tbody.appendChild(tr);
    });
  }

  function renderAdjList() {
    const tbody = document.getElementById('adjList');
    tbody.innerHTML = '';
    state.netAdjustments.forEach((a, idx) => {
      const tr = document.createElement('tr');
      tr.appendChild(el('td', {html: a.jur}));
      tr.appendChild(el('td', {html: a.scope}));
      tr.appendChild(el('td', {html: a.code || ''}));
      tr.appendChild(el('td', {html: a.label || ''}));
      tr.appendChild(el('td', {html: (a.bool_value === true ? 'true' : a.bool_value === false ? 'false' : '')}));
      tr.appendChild(el('td', {html: (a.amount === null || a.amount === undefined ? '' : String(a.amount))}));
      const btn = el('button', {type:'button', html:'Remove'});
      btn.addEventListener('click', () => {
        state.netAdjustments.splice(idx,1);
        renderAdjList();
      });
      const tdBtn = document.createElement('td');
      tdBtn.appendChild(btn);
      tr.appendChild(tdBtn);
      tbody.appendChild(tr);
    });
  }

  // ---------------------------------------------
  // Election catalog loading
  // ---------------------------------------------
  async function loadCatalog() {
    try {
      const resp = await fetch('/api/v1/election-catalog');
      const data = await resp.json();
      state.electionCatalog = data;
      state.electionByCode = {};
      data.forEach(d => { state.electionByCode[d.code] = d; });

      const sel = document.getElementById('adjCode');
      sel.innerHTML = '';
      // group by group
      const groups = {};
      data.forEach(d => {
        groups[d.group] = groups[d.group] || [];
        groups[d.group].push(d);
      });
      Object.keys(groups).sort().forEach(g => {
        const optg = document.createElement('optgroup');
        optg.label = g;
        groups[g].forEach(d => {
          const opt = document.createElement('option');
          opt.value = d.code;
          opt.textContent = d.code;
          optg.appendChild(opt);
        });
        sel.appendChild(optg);
      });

      sel.addEventListener('change', () => {
        const code = sel.value;
        const defn = state.electionByCode[code];
        if (!defn) return;
        // set scope default
        document.getElementById('adjScope').value = defn.scope || 'income';
        // helper placeholders
        const amount = document.getElementById('adjAmount');
        const boolSel = document.getElementById('adjBool');
        if (defn.value_type === 'bool') {
          boolSel.value = 'true';
          amount.value = '';
        } else if (defn.value_type === 'amount') {
          boolSel.value = '';
        }
      });
    } catch (e) {
      // ignore
    }
  }

  // ---------------------------------------------
  // Manual entry handlers
  // ---------------------------------------------
  renderForm('jurisdictionForm', J_FIELDS, 'j_');
  renderForm('entityForm', E_FIELDS, 'e_');
  loadCatalog();
  ensureJurList();

  const inputModeSel = document.getElementById('inputMode');
  const entityBlock = document.getElementById('entityBlock');
  inputModeSel.addEventListener('change', () => {
    const m = inputModeSel.value;
    entityBlock.style.display = (m === 'entity_rollup') ? '' : 'none';
  });

  document.getElementById('addJurisdiction').addEventListener('click', () => {
    const j = readForm(J_FIELDS, 'j_');
    if (!j.jurisdiction_code) {
      alert('Jurisdiction code is required.');
      return;
    }
    // de-dup by code (replace existing)
    const idx = state.jurisdictions.findIndex(x => x.jurisdiction_code === j.jurisdiction_code);
    if (idx >= 0) state.jurisdictions[idx] = j; else state.jurisdictions.push(j);

    renderJurisdictionList();
  });

  document.getElementById('addEntity').addEventListener('click', () => {
    const e = readForm(E_FIELDS, 'e_');
    if (!e.entity_name || !e.jurisdiction_code) {
      alert('Entity name and jurisdiction code are required.');
      return;
    }
    state.entities.push(e);
    renderEntityList();
  });

  document.getElementById('applyElectionAdj').addEventListener('click', () => {
    const jur = document.getElementById('adjJur').value;
    const custom = (document.getElementById('adjCodeCustom').value || '').trim();
    const code = custom || document.getElementById('adjCode').value;
    if (!jur) { alert('Add at least one jurisdiction first.'); return; }
    if (!code) { alert('Choose an election/adjustment code.'); return; }

    const scope = document.getElementById('adjScope').value;
    const amountStr = document.getElementById('adjAmount').value;
    const boolStr = document.getElementById('adjBool').value;
    const label = (document.getElementById('adjLabel').value || '').trim();
    const note = (document.getElementById('adjNote').value || '').trim();

    const defn = state.electionByCode[code];
    const j = state.jurisdictions.find(x => x.jurisdiction_code === jur);
    if (!j) { alert('Unknown jurisdiction.'); return; }

    if (defn && defn.target_field) {
      if (defn.value_type === 'bool') {
        j[defn.target_field] = (boolStr === 'true');
      } else if (defn.value_type === 'amount') {
        j[defn.target_field] = amountStr === '' ? 0 : Number(amountStr);
      }
      renderJurisdictionList();
      return;
    }

    // Otherwise record an unmapped election row.
    const amt = (amountStr === '' ? null : Number(amountStr));
    const bv = (boolStr === '' ? null : (boolStr === 'true'));

    if ((scope === 'income' || scope === 'tax') && (amt === null || Number.isNaN(amt))) {
      alert('For unmapped income/tax codes, please provide an amount (signed).');
      return;
    }
    if ((scope === 'metadata' || scope === 'eligibility') && bv === null && (amt === null || Number.isNaN(amt)) && !note && !label) {
      alert('For unmapped metadata/eligibility rows, provide a bool value and/or a note.');
      return;
    }

    state.netAdjustments.push({jur, scope, code, label: label || '', bool_value: bv, amount: amt, note});
    renderAdjList();
  });

  function buildRequest() {
    const req = {
      fiscal_year_start_date: document.getElementById('fyStart').value,
      minimum_rate: Number(document.getElementById('minRate').value),
      input_mode: document.getElementById('inputMode').value,
      apply_optional_2025_start_rule: !!document.getElementById('applyEarlyStart').checked,
      early_start_qdmtt_safe_harbour_applies: !!document.getElementById('earlyQdmtt').checked,
      early_start_only_one_jurisdiction_has_taxing_rights: !!document.getElementById('earlyOneJur').checked,
      early_start_all_taxing_rights_jurisdictions_allow: !!document.getElementById('earlyAllAllow').checked,
      jurisdictions: JSON.parse(JSON.stringify(state.jurisdictions)),
      entities: JSON.parse(JSON.stringify(state.entities)),
    };

    // Apply election rows:
    //  - Always record election_records (audit trail)
    //  - For income/tax scopes, also translate into other_*_adjustments if the code is unmapped
    for (const a of state.netAdjustments) {
      const j = req.jurisdictions.find(x => x.jurisdiction_code === a.jur);
      if (!j) continue;

      j.election_records = j.election_records || [];
      j.election_records.push({
        scope: a.scope,
        election_code: a.code,
        label: a.label || null,
        bool_value: (a.bool_value === undefined ? null : a.bool_value),
        amount: (a.amount === undefined ? null : a.amount),
        note: a.note || null
      });

      const fullLabel = (a.label && a.label.trim()) ? `${a.code}: ${a.label}` : a.code;
      if (a.scope === 'income') {
        j.other_income_adjustments = j.other_income_adjustments || [];
        j.other_income_adjustments.push({label: fullLabel, amount: a.amount, note: a.note || null});
      } else if (a.scope === 'tax') {
        j.other_tax_adjustments = j.other_tax_adjustments || [];
        j.other_tax_adjustments.push({label: fullLabel, amount: a.amount, note: a.note || null});
      }
    }

    return req;
  }

  document.getElementById('calcManual').addEventListener('click', async () => {
    const req = buildRequest();
    document.getElementById('jsonReq').textContent = JSON.stringify(req, null, 2);
    out.textContent = 'Calculating...';
    try {
      const resp = await fetch('/api/v1/calc', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(req)
      });
      let payload;
      try {
        payload = await resp.json();
      } catch {
        payload = {detail: await resp.text()};
      }
      if (!resp.ok) {
        out.textContent = JSON.stringify({error: 'Calculation failed', ...payload}, null, 2);
        return;
      }
      out.textContent = JSON.stringify(payload, null, 2);
    } catch (err) {
      out.textContent = String(err);
    }
  });

  const jsonBox = document.getElementById('jsonBox');
  document.getElementById('toggleJson').addEventListener('click', () => {
    jsonBox.style.display = (jsonBox.style.display === 'none') ? '' : 'none';
  });
</script>
</body>
</html>"""
    )
