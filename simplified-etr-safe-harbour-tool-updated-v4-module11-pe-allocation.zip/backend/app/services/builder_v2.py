from __future__ import annotations

import re
from typing import Dict, List, Tuple

from app.services.models_v2 import (
    EntityFactsV2,
    TestedJurisdictionInputV2,
    TestedJurisdictionCompositionV2,
    AccountingBasisV2,
    TransitionYearV2,
    TestedJurisdictionsBuildRequestV2,
    TestedJurisdictionsBuildResponseV2,
    TestedJurisdictionsBuildAssignmentV2,
)

def _slug(s: str) -> str:
    s = (s or "").strip().upper()
    s = re.sub(r"[^A-Z0-9]+", "_", s)
    s = re.sub(r"_+", "_", s).strip("_")
    return s or "X"

def _bucket_for_entity(e: EntityFactsV2, req: TestedJurisdictionsBuildRequestV2) -> Tuple[str, str, str]:
    """Return (tested_jurisdiction_id, jurisdiction_code, tested_jurisdiction_type)."""
    code = (e.jurisdiction_code or "").strip().upper()
    et = getattr(e, "entity_type", None) or "STANDARD_CE"
    opt = req.options

    # Stateless bucket
    if et == "STATELESS" and opt.separate_stateless:
        return ("STATELESS", None, "stateless")

    # Default bucket id base
    base = _slug(code) if code else "UNSPECIFIED"

    # Type-specific bucketing
    if et == "INVESTMENT_ENTITY" and opt.separate_investment_entities:
        return (f"{base}_INVEST", base, "investment_entity")
    if et == "INSURANCE_INVESTMENT_ENTITY" and opt.separate_investment_entities:
        return (f"{base}_INS_INVEST", base, "insurance_investment_entity")
    if et == "TAX_NEUTRAL_UPE" and opt.separate_tax_neutral_upe:
        return (f"{base}_TNUPE", base, "tax_neutral_upe")
    if et == "TAX_TRANSPARENT_ENTITY" and opt.separate_tax_transparent_entities:
        return (f"{base}_TTE", base, "tax_transparent")
    if et == "FLOW_THROUGH_ENTITY" and opt.separate_flow_through_entities:
        return (f"{base}_FTE", base, "flow_through")

    return (f"{base}_MAIN", base, "standard")

def build_tested_jurisdictions_from_entities(payload: TestedJurisdictionsBuildRequestV2) -> TestedJurisdictionsBuildResponseV2:
    """Build TestedJurisdictionInputV2 buckets from entity rows (UI helper).

    This is an opinionated convenience function designed for UI clients.
    It does not replace the OECD Tested Jurisdiction definition logic; it gives users a
    consistent starting structure.

    Bucketing rules (default):
      - One TJ per jurisdiction_code (CODE_MAIN)
      - Separate buckets for investment entities, tax-neutral UPE, tax-transparent, flow-through if enabled
      - Stateless bucket if entity_type=STATELESS and option enabled

    Each TJ uses aggregation_method='ENTITY_ROLLUP' with the supplied entities attached.
    """

    warnings: List[str] = []
    groups: Dict[str, List[EntityFactsV2]] = {}
    meta: Dict[str, Tuple[str, str]] = {}  # tj_id -> (jurisdiction_code, tj_type)

    # Ensure entities have basic identifiers
    for i, e in enumerate(payload.entities or [], start=1):
        if not e.entity_name or str(e.entity_name).strip() == "":
            warnings.append(f"Entity row {i}: missing entity_name; setting to 'Entity {i}'.")
            e.entity_name = f"Entity {i}"
        if not getattr(e, "entity_id", None):
            # derive a stable-ish id
            derived = _slug(e.entity_name)
            e.entity_id = derived
            warnings.append(f"Entity '{e.entity_name}': entity_id missing; derived entity_id='{derived}'.")

        tj_id, j_code, tj_type = _bucket_for_entity(e, payload)
        groups.setdefault(tj_id, []).append(e)
        meta[tj_id] = (j_code, tj_type)

    tested_jurisdictions: List[TestedJurisdictionInputV2] = []
    assignments: List[TestedJurisdictionsBuildAssignmentV2] = []

    for tj_id, ents in sorted(groups.items(), key=lambda kv: kv[0]):
        j_code, tj_type = meta.get(tj_id, (None, None))

        label = tj_id
        if j_code and tj_id.endswith("_MAIN"):
            label = f"{j_code} – Main"
        elif j_code and tj_id.endswith("_INVEST"):
            label = f"{j_code} – Investment Entities"
        elif j_code and tj_id.endswith("_INS_INVEST"):
            label = f"{j_code} – Insurance Investment Entities"
        elif j_code and tj_id.endswith("_TNUPE"):
            label = f"{j_code} – Tax Neutral UPE"
        elif j_code and tj_id.endswith("_TTE"):
            label = f"{j_code} – Tax Transparent"
        elif j_code and tj_id.endswith("_FTE"):
            label = f"{j_code} – Flow-through"
        elif tj_id == "STATELESS":
            label = "Stateless"

        tj = TestedJurisdictionInputV2(
            tested_jurisdiction_id=tj_id,
            jurisdiction_code=j_code,
            label=label,
            tested_jurisdiction_type=tj_type,
            accounting_basis=AccountingBasisV2(currency=None, amount_scale="UNITS"),
            composition=TestedJurisdictionCompositionV2(aggregation_method="ENTITY_ROLLUP"),
            facts=None,
            entities=ents,
            transition_year=TransitionYearV2(),
        )
        tested_jurisdictions.append(tj)

        for e in ents:
            assignments.append(
                TestedJurisdictionsBuildAssignmentV2(
                    entity_id=e.entity_id,
                    entity_name=e.entity_name,
                    entity_type=getattr(e, "entity_type", None),
                    tested_jurisdiction_id=tj_id,
                    jurisdiction_code=j_code,
                )
            )

    if not tested_jurisdictions:
        warnings.append("No entities provided; no Tested Jurisdictions were built.")

    return TestedJurisdictionsBuildResponseV2(
        tested_jurisdictions=tested_jurisdictions,
        assignments=assignments,
        warnings=warnings,
    )
