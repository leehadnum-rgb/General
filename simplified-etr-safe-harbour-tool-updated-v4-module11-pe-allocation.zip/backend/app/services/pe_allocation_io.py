from __future__ import annotations

import csv
import io
import re
from datetime import date
from typing import Dict, List, Optional

from pydantic import BaseModel, Field

from app.services.models_v2 import PEAllocationLineV2

_NUM_RE = re.compile(r"[^0-9eE+\-\.]")


def _norm_header(h: str) -> str:
    h = (h or "").strip().lower()
    h = re.sub(r"[\s\-]+", "_", h)
    return h


_ALIASES: Dict[str, str] = {
    "id": "line_id",
    "allocation_id": "line_id",
    "pe": "pe_id",
    "pe_identifier": "pe_id",
    "fy_start": "fiscal_year_start",
    "main_tj": "main_entity_tested_jurisdiction_id",
    "main_entity_tj": "main_entity_tested_jurisdiction_id",
    "head_office_tj": "main_entity_tested_jurisdiction_id",
    "pe_tj": "pe_tested_jurisdiction_id",
    "included_income": "pe_income_included_in_main",
    "pe_income_included": "pe_income_included_in_main",
    "pe_income_included_in_main": "pe_income_included_in_main",
    "main_taxes": "main_entity_taxes_related_to_pe",
    "main_entity_taxes": "main_entity_taxes_related_to_pe",
    "ftc_used": "foreign_tax_credit_used",
    "foreign_tax_credit": "foreign_tax_credit_used",
    "nominal_rate": "main_nominal_tax_rate",
    "main_nominal_rate": "main_nominal_tax_rate",
}


def _parse_float(raw: str) -> Optional[float]:
    if raw is None:
        return None
    s = str(raw).strip()
    if s == "":
        return None
    s = _NUM_RE.sub("", s)
    if s in {"", "+", "-", "."}:
        return None
    try:
        return float(s)
    except ValueError:
        return None


def _parse_date(raw: str) -> Optional[date]:
    if raw is None:
        return None
    s = str(raw).strip()
    if s == "":
        return None
    try:
        return date.fromisoformat(s)
    except ValueError:
        return None


class PEAllocationLinesCsvIssue(BaseModel):
    severity: str = Field(..., description="'error' or 'warning'")
    row_number: int = Field(..., ge=1, description="1-indexed row number in the CSV (excluding header).")
    field: Optional[str] = None
    message: str


class PEAllocationLinesCsvParseResult(BaseModel):
    pe_allocation_lines: List[PEAllocationLineV2] = Field(default_factory=list)
    issues: List[PEAllocationLinesCsvIssue] = Field(default_factory=list)
    detected_columns: List[str] = Field(default_factory=list)
    ignored_columns: List[str] = Field(default_factory=list)


def generate_pe_allocation_lines_csv_template() -> bytes:
    headers = [
        "line_id",
        "pe_id",
        "fiscal_year_start",
        "main_entity_tested_jurisdiction_id",
        "pe_tested_jurisdiction_id",
        "pe_income_included_in_main",
        "main_entity_taxes_related_to_pe",
        "foreign_tax_credit_used",
        "main_nominal_tax_rate",
        "currency",
        "amount_scale",
        "note",
    ]

    example = {
        "line_id": "PEA-001",
        "pe_id": "PE-DE-BRANCH-1",
        "fiscal_year_start": "2027-01-01",
        "main_entity_tested_jurisdiction_id": "GB_MAIN",
        "pe_tested_jurisdiction_id": "DE_PE",
        "pe_income_included_in_main": "2000000",
        "main_entity_taxes_related_to_pe": "180000",
        "foreign_tax_credit_used": "20000",
        "main_nominal_tax_rate": "0.25",
        "currency": "GBP",
        "amount_scale": "UNITS",
        "note": "Example: PE simplification inclusion amounts (OECD 5.1)"
    }

    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=headers)
    w.writeheader()
    w.writerow(example)
    return buf.getvalue().encode("utf-8")


def parse_pe_allocation_lines_csv(contents: bytes) -> PEAllocationLinesCsvParseResult:
    text = contents.decode("utf-8-sig", errors="replace")
    buf = io.StringIO(text)
    reader = csv.DictReader(buf)
    if reader.fieldnames is None:
        return PEAllocationLinesCsvParseResult(
            pe_allocation_lines=[],
            issues=[PEAllocationLinesCsvIssue(severity="error", row_number=1, message="CSV is missing a header row.")],
        )

    raw_headers = list(reader.fieldnames)
    norm_to_raw: Dict[str, str] = {}
    for h in raw_headers:
        nh = _ALIASES.get(_norm_header(h), _norm_header(h))
        if nh and nh not in norm_to_raw:
            norm_to_raw[nh] = h

    allowed = set(PEAllocationLineV2.model_fields.keys())
    ignored = [raw for nh, raw in norm_to_raw.items() if nh not in allowed]
    out = PEAllocationLinesCsvParseResult(detected_columns=raw_headers, ignored_columns=ignored)

    rows: List[PEAllocationLineV2] = []
    for idx, row in enumerate(reader, start=1):
        data: Dict[str, object] = {}
        issues: List[PEAllocationLinesCsvIssue] = []

        for nh, raw in norm_to_raw.items():
            if nh not in allowed:
                continue
            val = row.get(raw)

            if nh in {"pe_income_included_in_main", "main_entity_taxes_related_to_pe", "foreign_tax_credit_used", "main_nominal_tax_rate"}:
                f = _parse_float(val)
                if f is not None:
                    data[nh] = f
            elif nh == "fiscal_year_start":
                d = _parse_date(val)
                if d is not None:
                    data[nh] = d
            else:
                if val is None:
                    continue
                s = str(val).strip()
                if s == "":
                    continue
                data[nh] = s

        if not data.get("pe_id"):
            issues.append(PEAllocationLinesCsvIssue(severity="error", row_number=idx, field="pe_id", message="Missing pe_id."))

        # If all monetary fields are missing/zero, warn (but still allow row)
        amt_fields = [
            float(data.get("pe_income_included_in_main") or 0.0),
            float(data.get("main_entity_taxes_related_to_pe") or 0.0),
            float(data.get("foreign_tax_credit_used") or 0.0),
        ]
        if all(abs(x) < 1e-12 for x in amt_fields):
            issues.append(
                PEAllocationLinesCsvIssue(
                    severity="warning",
                    row_number=idx,
                    message="All amount fields are blank/zero; row will have no effect unless edited.",
                )
            )

        out.issues.extend(issues)

        try:
            if any(i.severity == "error" for i in issues):
                continue
            rows.append(PEAllocationLineV2.model_validate(data))
        except Exception as e:
            out.issues.append(PEAllocationLinesCsvIssue(severity="error", row_number=idx, message=f"Row validation failed: {e}"))

    out.pe_allocation_lines = rows
    return out
