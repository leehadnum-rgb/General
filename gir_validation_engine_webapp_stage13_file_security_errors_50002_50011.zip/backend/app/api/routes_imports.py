from __future__ import annotations

import re
import zipfile
from datetime import date, datetime
from hashlib import sha1
from io import BytesIO
from typing import Iterable, List, Optional, Set, Tuple

import requests
import xml.etree.ElementTree as ET

from lxml import etree

from openpyxl import load_workbook

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import Session

from app.api.schemas import (
    ImportGirXmlRequest,
    ImportGirXmlResponse,
    ImportGirXmlStats,
    ImportGirXmlWarning,
    ImportGirXmlValidateRequest,
    ImportGirXmlValidateResponse,
    ImportGirToolkitXlsxRequest,
    ImportGirToolkitXlsxResponse,
    ImportGirToolkitXlsxValidateRequest,
    ImportGirToolkitXlsxValidateResponse,
    ValidationRunCreate,
    ValidationRunRead,
    StatusMessageValidateRequest,
    StatusMessageValidateResponse,
    StatusMessageParsed,
    StatusMessageFileError,
    StatusMessageRecordError,
)
from app.db import models
from app.db.session import get_db
from app.services.utils import try_parse_date, try_parse_decimal
from app.core.settings import settings
from app.services.config_loader import load_config
from app.services.submission_history import record_submission_from_import
from app.services.xsd_validator import validate_xml_against_gir_xsd, validate_xml_against_status_message_xsd

# Reuse the existing validation run implementation for consistent persistence + outputs.
from app.api.routes_validation import create_validation_run as _create_validation_run


router = APIRouter(prefix="/filings/{filing_id}/imports", tags=["imports"])


def _local(tag: str) -> str:
    """Return localname for XML tags with namespaces."""
    if "}" in tag:
        return tag.split("}", 1)[1]
    return tag


def _child(parent: ET.Element, name: str) -> Optional[ET.Element]:
    for ch in list(parent):
        if isinstance(ch.tag, str) and _local(ch.tag) == name:
            return ch
    return None


def _child_text(parent: ET.Element, name: str) -> Optional[str]:
    ch = _child(parent, name)
    if ch is None:
        return None
    t = (ch.text or "").strip()
    return t or None


def _find_text(root: ET.Element, parts: List[str]) -> Optional[str]:
    cur = root
    for p in parts:
        nxt = _child(cur, p)
        if nxt is None:
            return None
        cur = nxt
    t = (cur.text or "").strip()
    return t or None

# ---
# File-level helpers for OECD File Error codes (5000x)
# ---

_EICAR_TEST_STRING = (
    b"X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*"
)

_SUSPICIOUS_EXTS = {
    ".exe", ".dll", ".bat", ".cmd", ".ps1", ".js", ".vbs", ".jar", ".msi", ".scr", ".com", ".vbe", ".wsf",
}


def _strip_bom_and_ws(b: bytes) -> bytes:
    if not b:
        return b
    # UTF-8 BOM
    if b.startswith(b"\xef\xbb\xbf"):
        b = b[3:]
    return b.lstrip()


def _is_probably_xml_bytes(b: bytes) -> bool:
    bb = _strip_bom_and_ws(b or b"")
    return bool(bb.startswith(b"<"))


def _printable_ratio(b: bytes, sample: int = 4096) -> float:
    if not b:
        return 1.0
    s = b[:sample]
    # Printable-ish ASCII: tab, newline, carriage return, and 0x20-0x7E.
    printable = 0
    for x in s:
        if x in (9, 10, 13) or 32 <= x <= 126:
            printable += 1
    return printable / max(1, len(s))


def _looks_encrypted_or_binary(b: bytes) -> bool:
    # If it isn't XML or ZIP and is mostly non-printable, treat as encrypted/binary.
    if not b:
        return False
    return _printable_ratio(b) < 0.60


def _looks_like_ecb_ciphertext(b: bytes, max_bytes: int = 4096 * 16) -> bool:
    """Heuristic for OECD 50011 ECB-mode detection.

    ECB encryption often yields repeated 16-byte blocks for structured plaintext.
    This is NOT a definitive cryptographic test, but provides a reasonable hint.
    """
    if not b:
        return False
    s = b[:max_bytes]
    if len(s) < 16 * 12:
        return False
    blocks = [s[i : i + 16] for i in range(0, len(s) - (len(s) % 16), 16)]
    if len(blocks) < 12:
        return False
    unique = len(set(blocks))
    ratio = unique / max(1, len(blocks))
    return ratio < 0.70


def _looks_like_signature_payload(url: str, content_type: str, b: bytes) -> bool:
    u = (url or "").lower()
    ct = (content_type or "").lower()
    if any(u.endswith(ext) for ext in (".p7m", ".p7s", ".sig", ".cms", ".pkcs7")):
        return True
    if any(k in ct for k in ("pkcs7", "cms", "signature", "application/pkcs7", "application/x-pkcs7")):
        return True
    # Very loose ASN.1 signature-ish hint: starts with SEQUENCE 0x30 and is non-printable.
    if b and b[:1] == b"\x30" and _printable_ratio(b) < 0.30:
        return True
    return False


def _scan_xml_for_security_threats(b: bytes, max_scan_bytes: int = 2 * 1024 * 1024) -> List[str]:
    """Best-effort scan for OECD 50005 (security threats) within XML text.

    OECD examples include hyperlinks, JavaScript, and executable files.
    We purposely DO NOT flag plain-text URLs (http://...) unless they appear as hyperlinks.
    """
    if not b:
        return []
    sample = b[:max_scan_bytes]
    try:
        s = sample.decode("utf-8", errors="ignore").lower()
    except Exception:
        return []

    threats: List[str] = []
    if re.search(r"<\s*a\b[^>]*\bhref\s*=", s):
        threats.append("HTML hyperlink (<a href=...>)")
    if "xlink:href=" in s:
        threats.append("xlink:href hyperlink")
    if "javascript:" in s:
        threats.append("javascript: URI")
    if re.search(r"<\s*script\b", s):
        threats.append("<script> tag")
    return threats


def _zip_entry_is_suspicious(name: str) -> Optional[str]:
    n = (name or "").strip()
    if not n or n.endswith("/"):
        return None
    low = n.lower()
    # Ignore macOS metadata folders
    if low.startswith("__macosx/"):
        return None
    for ext in _SUSPICIOUS_EXTS:
        if low.endswith(ext):
            return f"suspicious file extension: {ext}"
    return None


def _zip_contains_eicar(zf: zipfile.ZipFile, max_read: int = 512 * 1024) -> bool:
    try:
        for n in zf.namelist():
            if not n or n.endswith("/"):
                continue
            if n.lower().startswith("__macosx/"):
                continue
            try:
                data = zf.read(n)
            except Exception:
                continue
            if _EICAR_TEST_STRING in data[: max_read + len(_EICAR_TEST_STRING)]:
                return True
    except Exception:
        return False
    return False



def _norm_xpath(xp: Optional[str]) -> str:
    """Normalize xpaths to be robust across the optional eForm/Payload wrapper.

    Some GIR XML files are wrapped like:
      /GLOBE_OECD/GLOBEBody/eForm/Payload/GLOBE_OECD/GLOBEBody/...

    The toolkit/extracted config typically uses the unwrapped form.
    """
    if not xp:
        return ""
    x = xp.strip()
    x = x.replace(
        "/GLOBE_OECD/GLOBEBody/eForm/Payload/GLOBE_OECD/GLOBEBody",
        "/GLOBE_OECD/GLOBEBody",
    )
    x = x.replace(
        "/eForm/Payload/GLOBE_OECD/GLOBEBody",
        "/GLOBE_OECD/GLOBEBody",
    )
    x = re.sub(r"/{2,}", "/", x)
    return x


def _find_docref_id_in_subtree(node: ET.Element) -> Optional[str]:
    """Return the first DocSpec/DocRefId value found under `node` (if any)."""
    stack = [node]
    while stack:
        cur = stack.pop()
        if not isinstance(getattr(cur, "tag", None), str):
            continue
        if _local(cur.tag) == "DocSpec":
            v = _child_text(cur, "DocRefId")
            if v:
                return v.strip()
        for ch in list(cur):
            if isinstance(getattr(ch, "tag", None), str):
                stack.append(ch)
    return None


def _safe_code(seed: Optional[str], prefix: str, max_len: int = 64) -> str:
    base = (seed or "").strip()
    cleaned = re.sub(r"[^A-Za-z0-9]+", "", base).upper()
    if not cleaned:
        return f"{prefix}01"
    if len(cleaned) <= max_len:
        return cleaned
    h = sha1(base.encode("utf-8")).hexdigest()[:12].upper()
    return (prefix + h)[:max_len]


def _chunked(it: List[dict], n: int) -> Iterable[List[dict]]:
    for i in range(0, len(it), n):
        yield it[i : i + n]


def _ensure_filing(db: Session, filing_id: str) -> models.Filing:
    filing = db.get(models.Filing, filing_id)
    if filing is None:
        raise HTTPException(status_code=404, detail="Filing not found")
    return filing


@router.post("/gir-xml", response_model=ImportGirXmlResponse)
def import_gir_xml(filing_id: str, payload: ImportGirXmlRequest, db: Session = Depends(get_db)):
    """Import a GIR XML file into registers + datapoints.

    This is a pragmatic bridge endpoint intended for customer-facing web tools
    (Anything.com, etc.). The API accepts a file URL, downloads it server-side,
    parses XML, and loads:
      - Filer register (single filer from FilingCE)
      - Jurisdiction register (from JurisdictionSection, plus RecJurCode fallbacks)
      - Constituent Entity register (from GeneralSection/CorporateStructure/CE)
      - Datapoints (flattened leaf nodes)
    """

    filing = _ensure_filing(db, filing_id)

    import_id = f"IMP-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}-{sha1(f'{filing_id}'.encode('utf-8')).hexdigest()[:8].upper()}"
    warnings: List[ImportGirXmlWarning] = []

    url = (payload.file_url or "").strip()
    if not url.lower().startswith(("https://", "http://")):
        raise HTTPException(status_code=400, detail="file_url must start with http:// or https://")

    # Download XML
    try:
        resp = requests.get(url, timeout=60)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Could not download file_url: {e}")

    if resp.status_code >= 400:
        raise HTTPException(status_code=400, detail=f"Could not download file_url: HTTP {resp.status_code}")
    content = resp.content or b""
    content_type = (resp.headers.get("content-type") or "").strip()
    max_bytes = 50 * 1024 * 1024
    if len(content) > max_bytes:
        raise HTTPException(status_code=413, detail=f"File too large ({len(content)} bytes). Max {max_bytes} bytes")


    # Stage 6+: accept ZIP payloads (OECD file error 50003 when decompression fails)
    #
    # In CTS exchanges, payloads are typically compressed before encryption. For domestic/customer
    # uploads we allow a simple ZIP that contains the GIR XML as a convenience.
    is_zip = (
        url.lower().endswith(".zip")
        or content_type.lower().startswith("application/zip")
        or (len(content) >= 4 and content[:2] == b"PK")
    )
    if is_zip:
        try:
            zf = zipfile.ZipFile(BytesIO(content))
            # Prefer an .xml payload if present; otherwise take the first file entry.
            names = [n for n in zf.namelist() if n and not n.endswith("/") and not n.startswith("__MACOSX")]

            # Stage 13: basic security scanning (OECD 50005/50006).
            # We only flag obvious threats (javascript/executables) and the EICAR test string.
            suspicious = []
            for n in names:
                reason = _zip_entry_is_suspicious(n)
                if reason:
                    suspicious.append(f"{n} ({reason})")
            has_eicar = _zip_contains_eicar(zf)

            if has_eicar:
                warnings.append(ImportGirXmlWarning(
                    code="OECD_FILE_ERROR_50006",
                    message=(
                        "OECD 50006: One or more known viruses were detected in the decrypted version of the referenced file. "
                        "(This tool currently detects the EICAR test string as a safe stand-in for AV scanning.)"
                    ),
                ))
            if suspicious:
                warnings.append(ImportGirXmlWarning(
                    code="OECD_FILE_ERROR_50005",
                    message=(
                        "OECD 50005: One or more potential security threats were detected within the referenced file (ZIP payload). "
                        "Threats include JavaScript or executable files. Detected: " + ", ".join(suspicious[:20])
                        + (" …" if len(suspicious) > 20 else "")
                    ),
                ))
            if has_eicar or suspicious:
                stats = ImportGirXmlStats(
                    filers_total=0,
                    jurisdictions_total=0,
                    entities_total=0,
                    datapoints_total=0,
                )
                return ImportGirXmlResponse(
                    import_id=import_id,
                    filing_id=filing_id,
                    status="file_failed",
                    stats=stats,
                    warnings=warnings,
                )

            xml_names = [n for n in names if n.lower().endswith(".xml")]
            pick = (xml_names[0] if xml_names else (names[0] if names else None))
            if not pick:
                raise ValueError("ZIP archive is empty (no files found).")
            content = zf.read(pick)
            if len(xml_names) > 1:
                warnings.append(ImportGirXmlWarning(
                    code="ZIP_MULTIPLE_XML",
                    message=f"ZIP contained multiple XML files; extracted the first: {pick}",
                ))
            else:
                warnings.append(ImportGirXmlWarning(
                    code="ZIP_DECOMPRESSED",
                    message=f"ZIP decompressed; extracted: {pick}",
                ))
        except Exception as e:
            # Map to OECD 50003
            warnings.append(ImportGirXmlWarning(
                code="OECD_FILE_ERROR_50003",
                message=(
                    "OECD 50003: The receiving Competent Authority could not decompress the referenced file. "
                    f"Details: {e}"
                ),
            ))
            stats = ImportGirXmlStats(
                filers_total=0,
                jurisdictions_total=0,
                entities_total=0,
                datapoints_total=0,
            )
            return ImportGirXmlResponse(
                import_id=import_id,
                filing_id=filing_id,
                status="file_failed",
                stats=stats,
                warnings=warnings,
            )

    # Stage 13: classify non-XML payloads to OECD file errors.
    # This is a best-effort approach for domestic/self-serve validators (CTS encryption/signature handling is out of scope).
    if not _is_probably_xml_bytes(content):
        if _looks_like_signature_payload(url, content_type, content):
            code = 50004
            msg = (
                "OECD 50004: The receiving Competent Authority could not validate the digital signature on the referenced file. "
                "This tool received a payload that appears to be a signature container rather than a GIR XML. "
                "Please re-sign the file using the CTS procedures and resubmit."
            )
        elif _looks_like_ecb_ciphertext(content):
            code = 50011
            msg = (
                "OECD 50011: The recipient detected encryption/key packaging errors (e.g. ECB cipher mode or missing IV/key material). "
                "This tool received a payload that looks like ciphertext (ECB-like repeating blocks detected). "
                "Please resend the file newly encrypted (CBC mode) with a new unique MessageRefID and correct AES key/IV packaging."
            )
        elif _looks_encrypted_or_binary(content):
            code = 50002
            msg = (
                "OECD 50002: The receiving Competent Authority could not decrypt the referenced file. "
                "This tool received a payload that is not readable as XML/ZIP and appears encrypted/binary. "
                "Please (re-)encrypt the file with a valid key and resubmit."
            )
        else:
            code = 50007
            msg = (
                "OECD 50007: The referenced file failed validation against the GIR XML Schema. "
                "This tool could not read the payload as XML. Please provide a valid GIR XML (or a ZIP containing a GIR XML) and resubmit."
            )

        warnings.append(ImportGirXmlWarning(code=f"OECD_FILE_ERROR_{code}", message=msg))
        stats = ImportGirXmlStats(
            filers_total=0,
            jurisdictions_total=0,
            entities_total=0,
            datapoints_total=0,
        )
        return ImportGirXmlResponse(
            import_id=import_id,
            filing_id=filing_id,
            status="file_failed",
            stats=stats,
            warnings=warnings,
        )

    # Stage 13: security threat scanning for plain XML payloads (OECD 50005/50006).
    threats = _scan_xml_for_security_threats(content)
    if _EICAR_TEST_STRING in content:
        warnings.append(ImportGirXmlWarning(
            code="OECD_FILE_ERROR_50006",
            message=(
                "OECD 50006: One or more known viruses were detected in the referenced file. "
                "(This tool currently detects the EICAR test string as a safe stand-in for AV scanning.)"
            ),
        ))
    if threats:
        warnings.append(ImportGirXmlWarning(
            code="OECD_FILE_ERROR_50005",
            message=(
                "OECD 50005: One or more potential security threats were detected within the referenced file. "
                "Threats include but are not limited to hyperlinks and JavaScript. Detected: " + ", ".join(threats)
            ),
        ))
    if any((w.code or "").startswith("OECD_FILE_ERROR_50005") or (w.code or "").startswith("OECD_FILE_ERROR_50006") for w in warnings):
        stats = ImportGirXmlStats(
            filers_total=0,
            jurisdictions_total=0,
            entities_total=0,
            datapoints_total=0,
        )
        return ImportGirXmlResponse(
            import_id=import_id,
            filing_id=filing_id,
            status="file_failed",
            stats=stats,
            warnings=warnings,
        )

    # Stage 5: optional XSD validation (OECD file error 50007)
    #
    # Enabled when either:
    #   - request.strict_xsd is true (UI toggle)
    #   - XSD_VALIDATION_MODE=on (server default)
    do_xsd = bool(payload.strict_xsd) or (settings.xsd_validation_mode == "on")
    if do_xsd:
        try:
            xsd_res = validate_xml_against_gir_xsd(
                content,
                xsd_zip_path=settings.gir_xsd_zip_path,
                xsd_dir=settings.gir_xsd_dir,
                main_xsd=settings.gir_xsd_main,
                max_errors=30,
            )
        except FileNotFoundError as e:
            raise HTTPException(
                status_code=500,
                detail=(
                    f"XSD validation is enabled but the schema bundle cannot be found: {e}. "
                    "Set GIR_XSD_ZIP_PATH (or GIR_XSD_DIR) and redeploy."
                ),
            )
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"XSD validation failed unexpectedly: {e}")

        if not xsd_res.valid:
            # Do not delete/replace existing filing data if schema validation fails.
            preview = "\n".join([f"- {m}" for m in (xsd_res.errors or [])])
            warnings.append(ImportGirXmlWarning(
                code="XSD_VALIDATION_FAILED",
                message=(
                    "File failed OECD GIR XSD validation. "
                    f"MainXSD={xsd_res.main_xsd_path or 'unknown'}\n" + preview
                ),
            ))
            stats = ImportGirXmlStats(
                filers_total=0,
                jurisdictions_total=0,
                entities_total=0,
                datapoints_total=0,
            )
            return ImportGirXmlResponse(
                import_id=import_id,
                filing_id=filing_id,
                status="xsd_failed",
                stats=stats,
                warnings=warnings,
            )

    # Parse XML
    try:
        root = ET.fromstring(content)
    except Exception as e:
        # OECD 50007: schema/structure validation failure (non-wellformed XML is not schema-valid)
        warnings.append(ImportGirXmlWarning(
            code="OECD_FILE_ERROR_50007",
            message=(
                "OECD 50007: The referenced file failed validation against the GIR XML Schema. "
                f"Invalid XML: {e}"
            ),
        ))
        stats = ImportGirXmlStats(
            filers_total=0,
            jurisdictions_total=0,
            entities_total=0,
            datapoints_total=0,
        )
        return ImportGirXmlResponse(
            import_id=import_id,
            filing_id=filing_id,
            status="file_failed",
            stats=stats,
            warnings=warnings,
        )


    # Stage 6: OECD file-level validations that should short-circuit the import.
    # These map to OECD file error codes (Part 4 of the GIR Status Message User Guide).
    env_mode = (payload.environment or settings.gir_environment or "prod").strip().lower()
    expected_rc = payload.expected_receiving_country or settings.expected_receiving_country
    expected_rc = expected_rc.strip().upper() if isinstance(expected_rc, str) and expected_rc.strip() else None

    # Collect DocTypeIndic values anywhere in the payload (namespace-agnostic).
    dt_vals = []
    for el in root.iter():
        if not isinstance(getattr(el, "tag", None), str):
            continue
        if _local(el.tag) != "DocTypeIndic":
            continue
        v = (el.text or "").strip()
        if v:
            dt_vals.append(v.strip().upper())

    def _oecd_num(v: str):
        mm = re.match(r"^OECD(\d+)$", (v or "").strip().upper())
        if not mm:
            return None
        try:
            return int(mm.group(1))
        except Exception:
            return None

    nums = [_oecd_num(v) for v in dt_vals]
    has_prod_docs = any(n is not None and 0 <= n <= 3 for n in nums)
    has_test_docs = any(n is not None and 10 <= n <= 13 for n in nums)

    file_errors: List[ImportGirXmlWarning] = []

    # OECD 50008: test environment should only include OECD10-OECD13.
    if env_mode == "test" and has_prod_docs:
        file_errors.append(ImportGirXmlWarning(
            code="OECD_FILE_ERROR_50008",
            message=(
                "OECD 50008: File was processed as TEST environment, but one or more records have DocTypeIndic in "
                "the range OECD0–OECD3. Test submissions should only include DocTypeIndic in the range OECD10–OECD13."
            ),
        ))

    # OECD 50009: test DocTypeIndic values cannot be accepted as a valid GIR submission (production/default).
    if env_mode != "test" and has_test_docs:
        file_errors.append(ImportGirXmlWarning(
            code="OECD_FILE_ERROR_50009",
            message=(
                "OECD 50009: File contains one or more records with DocTypeIndic in the range OECD10–OECD13 (test data). "
                "This file cannot be accepted as a valid GIR submission. If intended as a valid filing, use DocTypeIndic "
                "values in the range OECD0–OECD3."
            ),
        ))

    # OECD 50010: payload ReceivingCountry is not meant for this receiver.
    rc = _find_text(root, ["MessageSpec", "ReceivingCountry"])
    rc = rc.strip().upper() if isinstance(rc, str) and rc.strip() else None
    if expected_rc and rc and rc != expected_rc:
        file_errors.append(ImportGirXmlWarning(
            code="OECD_FILE_ERROR_50010",
            message=(
                f"OECD 50010: MessageSpec/ReceivingCountry is '{rc}', but this tool was configured/used expecting "
                f"'{expected_rc}'. The records may be intended for another jurisdiction."
            ),
        ))

    if file_errors:
        warnings.extend(file_errors)
        stats = ImportGirXmlStats(
            filers_total=0,
            jurisdictions_total=0,
            entities_total=0,
            datapoints_total=0,
        )
        return ImportGirXmlResponse(
            import_id=import_id,
            filing_id=filing_id,
            status="file_failed",
            stats=stats,
            warnings=warnings,
        )

    # Optional replacement (recommended for web UX: re-upload replaces prior state).
    # We only replace after we know the file is a valid XML (and passes XSD validation when enabled).
    if payload.replace_existing:
        db.query(models.DataPoint).filter(models.DataPoint.filing_id == filing_id).delete(synchronize_session=False)
        db.query(models.Filer).filter(models.Filer.filing_id == filing_id).delete(synchronize_session=False)
        db.query(models.Jurisdiction).filter(models.Jurisdiction.filing_id == filing_id).delete(synchronize_session=False)
        db.query(models.ConstituentEntity).filter(models.ConstituentEntity.filing_id == filing_id).delete(synchronize_session=False)
        db.commit()

    # Extract FilingCE details for a single 'primary filer'
    filing_ce_name = _find_text(root, ["GLOBEBody", "FilingInfo", "FilingCE", "Name"])
    filing_ce_tin = _find_text(root, ["GLOBEBody", "FilingInfo", "FilingCE", "TIN"])
    filing_ce_role = _find_text(root, ["GLOBEBody", "FilingInfo", "FilingCE", "Role"])
    filing_ce_res = _find_text(root, ["GLOBEBody", "FilingInfo", "FilingCE", "ResCountryCode"])
    filing_ce_res = (filing_ce_res or "").strip().upper() if filing_ce_res else None
    if filing_ce_res and (len(filing_ce_res) != 2 or not filing_ce_res.isalpha()):
        filing_ce_res = None

    # Derive a stable filer_code
    filer_code = _safe_code(filing_ce_tin or filing_ce_name or filing.tenant_id, prefix="FE")

    now = datetime.utcnow()

    # Upsert filer register (single entry)
    filer_row = {
        "filing_id": filing_id,
        "filer_code": filer_code,
        "legal_name": filing_ce_name,
        "role": "FILING_CE",
        "jurisdiction_code": filing_ce_res,
        "tin": filing_ce_tin,
        "filing_ce_role": filing_ce_role,
        "updated_at": now,
        "created_at": now,
    }
    stmt = insert(models.Filer).values([filer_row])
    update_cols = {c.name: getattr(stmt.excluded, c.name) for c in models.Filer.__table__.columns if c.name not in ("id", "created_at")}
    stmt = stmt.on_conflict_do_update(constraint="uq_filer_filing_code", set_=update_cols)
    db.execute(stmt)
    db.commit()

    # Collect jurisdictions from JurisdictionSection and RecJurCode fallbacks.
    jurisdiction_rows: List[dict] = []
    jurisdiction_codes: Set[str] = set()

    gbody = _child(root, "GLOBEBody")
    if gbody is not None:
        for ch in list(gbody):
            if not isinstance(ch.tag, str):
                continue
            if _local(ch.tag) != "JurisdictionSection":
                continue
            jc = (_child_text(ch, "Jurisdiction") or "").strip().upper()
            if len(jc) != 2:
                continue
            jurisdiction_codes.add(jc)
            local_cur = _child_text(ch, "LocalCurrency")
            jurisdiction_rows.append({
                "filing_id": filing_id,
                "jurisdiction_code": jc,
                "local_currency": local_cur,
                "responsible_filer_code": filer_code,
                "computation_mode": None,
                "qdmt_applicable": None,
                "status": None,
                "notes": None,
                "updated_at": now,
                "created_at": now,
            })

    # Parse Constituent Entities from CorporateStructure/CE
    entity_rows: List[dict] = []
    entity_by_key: dict = {}

    def _entity_code_for(name: Optional[str], res: Optional[str], tin: Optional[str]) -> str:
        seed = f"{(res or '').strip().upper()}|{(tin or '').strip()}|{(name or '').strip()}"
        h = sha1(seed.encode("utf-8")).hexdigest()[:12].upper()
        return f"E{h}"

    if gbody is not None:
        general = _child(gbody, "GeneralSection")
        if general is not None:
            corp = _child(general, "CorporateStructure")
            if corp is not None:
                for ce in list(corp):
                    if not isinstance(ce.tag, str) or _local(ce.tag) != "CE":
                        continue
                    id_node = _child(ce, "ID")
                    name = _child_text(id_node, "Name") if id_node is not None else None
                    res = _child_text(id_node, "ResCountryCode") if id_node is not None else None
                    tin = _child_text(id_node, "TIN") if id_node is not None else None
                    id_rules = _child_text(id_node, "Rules") if id_node is not None else None
                    globe_status = _child_text(id_node, "GlobeStatus") if id_node is not None else None

                    entity_code = _entity_code_for(name, res, tin)
                    entity_by_key[id(ce)] = entity_code
                    jcode = (res or "").strip().upper() if res else None
                    if jcode and len(jcode) != 2:
                        jcode = None

                    entity_rows.append({
                        "filing_id": filing_id,
                        "entity_code": entity_code,
                        "legal_name": name,
                        "jurisdiction_code": jcode,
                        "tin": tin,
                        "included_in_gir": True,
                        "filed_by_filer_code": filer_code,
                        "id_rules": id_rules,
                        "globe_status": globe_status,
                        "parent_entity_code": None,
                        "ownership_type": None,
                        "ownership_percentage": None,
                        "owner_tin_override": None,
                        "updated_at": now,
                        "created_at": now,
                    })

                    if jcode:
                        jurisdiction_codes.add(jcode)

    # Build convenience indexes for scoping repeatable computation rows (CEComputation)
    entity_code_by_tin: dict = {}
    for row in entity_rows:
        tin_v = (row.get("tin") or "").strip()
        if tin_v:
            entity_code_by_tin[tin_v] = row.get("entity_code")

    # Also index entities by (Name, ResCountryCode) when available for stable matching across sections.
    entity_code_by_name_res: dict = {}
    for row in entity_rows:
        nm = (row.get("legal_name") or "").strip()
        rs = (row.get("jurisdiction_code") or "").strip().upper()
        if nm and rs and len(rs) == 2:
            entity_code_by_name_res[(nm.upper(), rs)] = row.get("entity_code")

    # Identify repeatable containers inside CEComputation so repeated rows don't overwrite each other.
    cfg_cached = None
    repeatable_ce_xpaths: Set[str] = set()
    try:
        cfg_cached = load_config(settings.config_root, filing.config_version_id)
        for el in cfg_cached.elements:
            if getattr(el, "repeatable", False) and getattr(el, "is_container", False) and "/CEComputation" in (el.xpath or ""):
                repeatable_ce_xpaths.add(_norm_xpath(el.xpath))
    except Exception:
        cfg_cached = None
        repeatable_ce_xpaths = set()


    # Import datapoints (flattened leaf nodes)
    recjur_codes: Set[str] = set()
    datapoint_rows: List[dict] = []

    def _add_dp(xml_path: str, raw: str, juris_code: Optional[str], entity_code: Optional[str], ctx: Optional[str]):
        """Append a datapoint row (parsing numeric/date) if raw is non-empty."""
        s = (raw or "").strip()
        if not s:
            return
        dec = try_parse_decimal(s)
        dt = try_parse_date(s)
        datapoint_rows.append({
            "filing_id": filing_id,
            "filer_code": filer_code,
            "jurisdiction_code": juris_code,
            "entity_code": entity_code,
            "context_key": ctx,
            "xml_path": xml_path,
            "value_raw": s,
            "value_numeric": dec,
            "value_date": dt,
            "currency": None,
            "source": "import",
            "source_system": payload.source_system or "gir_xml_import",
            "notes": None,
            "updated_at": now,
            "created_at": now,
        })

    def _ctx_extend(base: Optional[str], token: str) -> Optional[str]:
        """Extend a datapoint context key while respecting the DB length limit.

        We keep the *base* context (e.g., the CEComputation row identity) stable, and
        append repeat-instance markers for nested repeatable containers.
        """
        token = (token or "").strip()
        if not token:
            return base
        if not base:
            return token
        merged = f"{base}|{token}"
        if len(merged) <= 128:
            return merged
        # Preserve the base (before the first '|') so validators can group by it.
        base_root = base.split("|", 1)[0]
        h = sha1(merged.encode("utf-8")).hexdigest()[:12].upper()
        short = f"{base_root}|H{h}"
        return short[:128]


    def walk(
        node: ET.Element,
        path_parts: List[str],
        juris_code: Optional[str],
        entity_code: Optional[str],
        ctx: Optional[str],
    ):
        tag = _local(node.tag) if isinstance(node.tag, str) else ""
        new_parts = path_parts + ([tag] if tag else [])

        # Children elements only
        children = [c for c in list(node) if isinstance(c.tag, str)]


        # Heuristic: derive a stable entity_code for entity-like blocks beyond CorporateStructure/CE.
        # Many GIR sections contain entity identifiers (e.g., LTCE, ParentEntity) that should scope
        # datapoints to an entity when possible.
        if tag:
            looks_entity = (tag in {"LTCE", "ParentEntity", "UPE", "OtherUPE", "ExcludedUPE", "ExcludedEntity"} or tag.endswith("Entity") or tag.startswith("Entity"))
            if looks_entity:
                # Prefer an <ID> container when present; otherwise look for direct Name/TIN/ResCountryCode.
                id_node = _child(node, "ID")
                if id_node is not None:
                    nm = _child_text(id_node, "Name")
                    rs = _child_text(id_node, "ResCountryCode")
                    tn = _child_text(id_node, "TIN")
                else:
                    nm = _child_text(node, "Name")
                    rs = _child_text(node, "ResCountryCode")
                    tn = _child_text(node, "TIN")

                nm = (nm or "").strip() or None
                tn_norm = (tn or "").strip() or None
                rs_norm = (rs or "").strip().upper() if rs else None
                if rs_norm and (len(rs_norm) != 2 or not rs_norm.isalpha()):
                    rs_norm = None

                if tn_norm or (nm and rs_norm):
                    # Try to match to an existing CorporateStructure/CE entity first.
                    ecode = None
                    if tn_norm and tn_norm in entity_code_by_tin:
                        ecode = entity_code_by_tin[tn_norm]
                    elif nm and rs_norm and (nm.upper(), rs_norm) in entity_code_by_name_res:
                        ecode = entity_code_by_name_res[(nm.upper(), rs_norm)]
                    else:
                        ecode = _entity_code_for(nm, rs_norm, tn_norm)

                    # Cache discovered identity so downstream blocks share the same entity_code.
                    if tn_norm and tn_norm not in entity_code_by_tin:
                        entity_code_by_tin[tn_norm] = ecode
                    if nm and rs_norm and (nm.upper(), rs_norm) not in entity_code_by_name_res:
                        entity_code_by_name_res[(nm.upper(), rs_norm)] = ecode

                    entity_code = ecode

        # Capture attributes as datapoints (important for TIN/TypeOfTIN and other attribute-based rules)
        # even when an element has no text content.
        base_path = "/" + "/".join([p for p in new_parts if p])
        if base_path and isinstance(node.tag, str) and getattr(node, "attrib", None):
            for ak, av in node.attrib.items():
                if av is None:
                    continue
                aval = str(av).strip()
                if not aval:
                    continue
                alocal = _local(ak)
                # Skip common schema-location attributes if present.
                if alocal in {"schemaLocation", "noNamespaceSchemaLocation"}:
                    continue
                _add_dp(f"{base_path}/@{alocal}", aval, juris_code, entity_code, ctx)

        # Mixed-content edge case: if an element has both children and meaningful direct text, capture
        # the text node separately so it isn't lost.
        if children:
            t0 = (node.text or "").strip()
            if t0:
                _add_dp(f"{base_path}/text()", t0, juris_code, entity_code, ctx)

        # Special scoping: entering JurisdictionSection (direct child of GLOBEBody)
                # Special scoping: entering GLOBEBody (top-level record containers)
        if tag == "GLOBEBody":
            # Preserve repeatable sibling record blocks that carry DocSpec/DocRefId (e.g., Summary,
            # UTPRAttribution, multiple JurisdictionSection blocks) by scoping each instance with a
            # stable context_key derived from its DocRefId. Without this, repeated record blocks can
            # overwrite each other in the datapoint upsert key.
            counts_by_tag: dict = {}
            for ch in children:
                ch_tag = _local(ch.tag)
                counts_by_tag[ch_tag] = counts_by_tag.get(ch_tag, 0) + 1

            repeating_tags = {t for t, c in counts_by_tag.items() if c > 1}
            docref_by_child: dict = {}
            if repeating_tags:
                for ch in children:
                    ch_tag = _local(ch.tag)
                    if ch_tag not in repeating_tags:
                        continue
                    dr = _find_docref_id_in_subtree(ch)
                    if dr:
                        docref_by_child[id(ch)] = dr

            seen_by_tag: dict = {}

            for ch in children:
                ch_tag = _local(ch.tag)
                child_ctx = ctx

                if counts_by_tag.get(ch_tag, 0) > 1:
                    dr = docref_by_child.get(id(ch))
                    if dr:
                        h = sha1(dr.encode("utf-8")).hexdigest()[:12].upper()
                        child_ctx = _ctx_extend(child_ctx, f"DOCREF:{ch_tag}:{h}")
                    else:
                        seen_by_tag[ch_tag] = seen_by_tag.get(ch_tag, 0) + 1
                        child_ctx = _ctx_extend(child_ctx, f"IDX:{ch_tag}:{seen_by_tag[ch_tag]}")

                if ch_tag == "JurisdictionSection":
                    jc = (_child_text(ch, "Jurisdiction") or "").strip().upper()
                    jc = jc if len(jc) == 2 and jc.isalpha() else None
                    walk(ch, new_parts, juris_code=jc, entity_code=None, ctx=child_ctx)
                else:
                    walk(ch, new_parts, juris_code=None, entity_code=None, ctx=child_ctx)
            return

        # Special scoping: entering CorporateStructure/CE
        if tag == "CorporateStructure":
            # CorporateStructure contains several repeatable containers beyond CE (e.g., UPE,
            # ExcludedEntity). Because this branch bypasses the generic repeat-preserving recursion,
            # repeated non-CE blocks could overwrite each other. Apply DocRefId/IDX scoping here so
            # all repeated corporate-structure blocks are preserved.

            counts_by_tag: dict = {}
            for ch in children:
                ch_tag = _local(ch.tag)
                counts_by_tag[ch_tag] = counts_by_tag.get(ch_tag, 0) + 1

            repeating_tags = {t for t, c in counts_by_tag.items() if c > 1}
            docref_by_child: dict = {}
            if repeating_tags:
                for ch in children:
                    ch_tag = _local(ch.tag)
                    if ch_tag not in repeating_tags:
                        continue
                    dr = _find_docref_id_in_subtree(ch)
                    if dr:
                        docref_by_child[id(ch)] = dr

            seen_by_tag: dict = {}

            for ch in children:
                ch_tag = _local(ch.tag)
                child_ctx = ctx

                if counts_by_tag.get(ch_tag, 0) > 1:
                    dr = docref_by_child.get(id(ch))
                    if dr:
                        h = sha1(dr.encode("utf-8")).hexdigest()[:12].upper()
                        child_ctx = _ctx_extend(child_ctx, f"DOCREF:{ch_tag}:{h}")
                    else:
                        seen_by_tag[ch_tag] = seen_by_tag.get(ch_tag, 0) + 1
                        child_ctx = _ctx_extend(child_ctx, f"IDX:{ch_tag}:{seen_by_tag[ch_tag]}")

                if ch_tag == "CE":
                    ecode = entity_by_key.get(id(ch))
                    if not ecode:
                        # Fallback if CE list parsing missed it
                        id_node = _child(ch, "ID")
                        name = _child_text(id_node, "Name") if id_node is not None else None
                        res = _child_text(id_node, "ResCountryCode") if id_node is not None else None
                        tin = _child_text(id_node, "TIN") if id_node is not None else None
                        ecode = _entity_code_for(name, res, tin)
                        entity_by_key[id(ch)] = ecode
                    walk(ch, new_parts, juris_code=None, entity_code=ecode, ctx=child_ctx)
                else:
                    walk(ch, new_parts, juris_code=None, entity_code=None, ctx=child_ctx)
            return

        # Special scoping: CEComputation rows (repeatable)
        # These must be preserved; otherwise, repeated CEComputation blocks overwrite each other
        # due to the (filing_id, filer_code, jurisdiction_code, entity_code, context_key, xml_path) key.
        if tag == "ETRComputation":
            # ETRComputation can contain repeatable container blocks beyond CEComputation depending
            # on the schema / filing. Apply repeat-preserving scoping at this level too (DocRefId
            # where available, otherwise deterministic indexing) so sibling repeats don't overwrite.

            counts_by_tag: dict = {}
            for ch in children:
                ch_tag = _local(ch.tag)
                counts_by_tag[ch_tag] = counts_by_tag.get(ch_tag, 0) + 1

            repeating_tags = {t for t, c in counts_by_tag.items() if c > 1}
            docref_by_child: dict = {}
            if repeating_tags:
                for ch in children:
                    ch_tag = _local(ch.tag)
                    if ch_tag not in repeating_tags:
                        continue
                    dr = _find_docref_id_in_subtree(ch)
                    if dr:
                        docref_by_child[id(ch)] = dr

            seen_by_tag: dict = {}

            ce_idx = 0
            for ch in children:
                ch_tag = _local(ch.tag)
                child_ctx = ctx

                if counts_by_tag.get(ch_tag, 0) > 1:
                    dr = docref_by_child.get(id(ch))
                    if dr:
                        h = sha1(dr.encode("utf-8")).hexdigest()[:12].upper()
                        child_ctx = _ctx_extend(child_ctx, f"DOCREF:{ch_tag}:{h}")
                    else:
                        seen_by_tag[ch_tag] = seen_by_tag.get(ch_tag, 0) + 1
                        child_ctx = _ctx_extend(child_ctx, f"IDX:{ch_tag}:{seen_by_tag[ch_tag]}")

                if ch_tag == "CEComputation":
                    ce_idx += 1
                    ce_tin = _child_text(ch, "TIN")
                    ce_tin_norm = (ce_tin or "").strip()

                    ecode = entity_code_by_tin.get(ce_tin_norm) if ce_tin_norm else None
                    if not ecode:
                        # Generate a stable-ish entity code even if the CorporateStructure block is absent.
                        ecode = _entity_code_for(None, None, ce_tin_norm or None)

                    token = ecode or _safe_code(ce_tin_norm, prefix="E", max_len=20)

                    # Preserve the CEComputation base identity as the *first* context segment so
                    # validators that group by base context (e.g., 60028) remain correct. At the
                    # same time, incorporate the parent record scope (docref/idx context) so that
                    # CEComputation rows do not collide across repeated record blocks.
                    parent_scope = ctx or ""
                    scope_hash = sha1(parent_scope.encode("utf-8")).hexdigest()[:8].upper() if parent_scope else None
                    base_ctx = f"CECOMP:{(juris_code or 'XX')}:{token}:{ce_idx}"
                    if scope_hash:
                        base_ctx = f"{base_ctx}:S{scope_hash}"

                    walk(ch, new_parts, juris_code=juris_code, entity_code=ecode, ctx=base_ctx)
                else:
                    walk(ch, new_parts, juris_code=juris_code, entity_code=entity_code, ctx=child_ctx)
            return

        if not children:
            text = (node.text or "").strip()
            if not text:
                return

            xml_path = "/" + "/".join([p for p in new_parts if p])

            context_key: Optional[str] = ctx
            if tag == "RecJurCode":
                code = text.strip().upper()
                if len(code) == 2 and code.isalpha():
                    recjur_codes.add(code)

            _add_dp(xml_path, text, juris_code, entity_code, context_key)
            return

                # Default recursion.
        #
        # 1) Preserve repeating sibling *record blocks* that include DocSpec/DocRefId by scoping each
        #    instance with a stable context_key derived from its DocRefId. This prevents overwrites
        #    in the datapoint upsert key when e.g. multiple Summary or UTPRAttribution records exist.
        # 2) Inside a CEComputation row, also apply repeatable-container indexing for nested
        #    repeatable containers (e.g., multiple MainEntityPEandFTE or CrossBorderAdjustments),
        #    so their leaf datapoints are not overwritten.

        # Repeat-preserving for DocSpec-bearing sibling records (generic, not CEComputation-specific).
        counts_by_tag: dict = {}
        for ch in children:
            ch_tag = _local(ch.tag)
            counts_by_tag[ch_tag] = counts_by_tag.get(ch_tag, 0) + 1

        repeating_tags = {t for t, c in counts_by_tag.items() if c > 1}
        docref_by_child: dict = {}
        if repeating_tags:
            for ch in children:
                ch_tag = _local(ch.tag)
                if ch_tag not in repeating_tags:
                    continue
                dr = _find_docref_id_in_subtree(ch)
                if dr:
                    docref_by_child[id(ch)] = dr

        seen_by_tag: dict = {}

        # CEComputation nested repeatable container indexing
        apply_repeat = bool(ctx) and str(ctx).startswith("CECOMP:") and bool(repeatable_ce_xpaths)

        counts: dict = {}
        if apply_repeat:
            for ch in children:
                ch_tag = _local(ch.tag)
                child_path = _norm_xpath("/" + "/".join([p for p in (new_parts + [ch_tag]) if p]))
                if child_path in repeatable_ce_xpaths:
                    counts[child_path] = counts.get(child_path, 0) + 1

        seen: dict = {}
        for ch in children:
            ch_tag = _local(ch.tag)

            child_ctx = ctx

            # DocSpec/DocRefId-based scoping (only if multiple siblings of this tag exist)
            if counts_by_tag.get(ch_tag, 0) > 1:
                dr = docref_by_child.get(id(ch))
                if dr:
                    h = sha1(dr.encode("utf-8")).hexdigest()[:12].upper()
                    child_ctx = _ctx_extend(child_ctx, f"DOCREF:{ch_tag}:{h}")
                else:
                    seen_by_tag[ch_tag] = seen_by_tag.get(ch_tag, 0) + 1
                    child_ctx = _ctx_extend(child_ctx, f"IDX:{ch_tag}:{seen_by_tag[ch_tag]}")

            # Nested repeatable-container indexing inside a CEComputation row
            if apply_repeat:
                child_path = _norm_xpath("/" + "/".join([p for p in (new_parts + [ch_tag]) if p]))
                if child_path in repeatable_ce_xpaths and counts.get(child_path, 0) > 1:
                    seen[child_path] = seen.get(child_path, 0) + 1
                    idx = seen[child_path]
                    child_ctx = _ctx_extend(child_ctx, f"{ch_tag}:{idx}")

            walk(ch, new_parts, juris_code=juris_code, entity_code=entity_code, ctx=child_ctx)


# Start traversal from root
    walk(root, [], juris_code=None, entity_code=None)

    # Fallback jurisdictions from RecJurCode values
    for code in sorted(recjur_codes):
        if code and len(code) == 2 and code.isalpha():
            jurisdiction_codes.add(code)

    # Upsert jurisdictions
    if jurisdiction_codes and not jurisdiction_rows:
        # If we have codes but no JurisdictionSection blocks, create minimal register rows.
        for jc in sorted(jurisdiction_codes):
            jurisdiction_rows.append({
                "filing_id": filing_id,
                "jurisdiction_code": jc,
                "local_currency": None,
                "responsible_filer_code": filer_code,
                "computation_mode": None,
                "qdmt_applicable": None,
                "status": None,
                "notes": "Derived from RecJurCode values",
                "updated_at": now,
                "created_at": now,
            })

    if jurisdiction_rows:
        stmt = insert(models.Jurisdiction).values(jurisdiction_rows)
        update_cols = {c.name: getattr(stmt.excluded, c.name) for c in models.Jurisdiction.__table__.columns if c.name not in ("id", "created_at")}
        stmt = stmt.on_conflict_do_update(constraint="uq_juris_filing_code", set_=update_cols)
        db.execute(stmt)
        db.commit()

    # Upsert entities
    if entity_rows:
        stmt = insert(models.ConstituentEntity).values(entity_rows)
        update_cols = {c.name: getattr(stmt.excluded, c.name) for c in models.ConstituentEntity.__table__.columns if c.name not in ("id", "created_at")}
        stmt = stmt.on_conflict_do_update(constraint="uq_entity_filing_code", set_=update_cols)
        db.execute(stmt)
        db.commit()

    # Upsert datapoints (chunked)
    if datapoint_rows:
        for chunk in _chunked(datapoint_rows, 5000):
            stmt = insert(models.DataPoint).values(chunk)
            update_cols = {c.name: getattr(stmt.excluded, c.name) for c in models.DataPoint.__table__.columns if c.name not in ("id", "created_at")}
            stmt = stmt.on_conflict_do_update(constraint="uq_datapoint_key", set_=update_cols)
            db.execute(stmt)
        db.commit()

    # Basic sanity warning: filing currency mismatch vs XML if present
    xml_currency = _find_text(root, ["GLOBEBody", "FilingInfo", "AccountingInfo", "Currency"])
    if xml_currency and filing.reporting_currency and xml_currency.strip().upper() != filing.reporting_currency.strip().upper():
        warnings.append(ImportGirXmlWarning(
            code="CURRENCY_MISMATCH",
            message=f"XML currency={xml_currency.strip().upper()} differs from filing.reporting_currency={filing.reporting_currency.strip().upper()}",
        ))

    # Update filing timestamp
    filing.updated_at = now
    db.add(filing)
    db.commit()

    # Stage 3: persist submission history (for cross-submission OECD validations like 60002/60009/60014)
    try:
        cfg = cfg_cached or load_config(settings.config_root, filing.config_version_id)
        msg_ref = _find_text(root, ["GLOBEHeader", "MessageRefId"])
        rp_start_raw = _find_text(root, ["GLOBEHeader", "ReportingPeriod", "StartDate"])
        rp_end_raw = _find_text(root, ["GLOBEHeader", "ReportingPeriod", "EndDate"])
        rp_start = try_parse_date(rp_start_raw) if rp_start_raw else None
        rp_end = try_parse_date(rp_end_raw) if rp_end_raw else None

        record_submission_from_import(
            db=db,
            filing=filing,
            config=cfg,
            source_type="xml",
            file_url=url,
            file_bytes=content,
            datapoint_rows=datapoint_rows,
            message_ref_id=msg_ref,
            reporting_period_start=rp_start,
            reporting_period_end=rp_end,
            notes=f"import_id={import_id}; source_system={payload.source_system or 'gir_xml_import'}",
        )
    except Exception as e:
        warnings.append(ImportGirXmlWarning(
            code="SUBMISSION_HISTORY_FAILED",
            message=f"Could not record submission history: {e}",
        ))

    stats = ImportGirXmlStats(
        filers_total=1,
        jurisdictions_total=len(jurisdiction_codes),
        entities_total=len(entity_rows),
        datapoints_total=len(datapoint_rows),
    )

    return ImportGirXmlResponse(
        import_id=import_id,
        filing_id=filing_id,
        status="completed",
        stats=stats,
        warnings=warnings,
    )


@router.post("/gir-xml:validate", response_model=ImportGirXmlValidateResponse)
def import_gir_xml_and_validate(
    filing_id: str,
    payload: ImportGirXmlValidateRequest,
    db: Session = Depends(get_db),
):
    """One-click import + validate endpoint.

    This is designed specifically for customer-facing self-serve flows (Anything.com, etc.)
    where the UI wants to:
      1) upload XML
      2) import it into the engine
      3) run validations

    ...all in a single API call.
    """

    def _how_to_fix_for(code: int) -> Optional[str]:
        """Best-effort lookup of OECD guidance text from the loaded config error catalogue."""
        try:
            cfg = load_config(settings.config_root, _ensure_filing(db, filing_id).config_version_id)
            for ec in (cfg.error_codes or []):
                if int(ec.number or 0) == int(code) and (ec.validation_description or "").strip():
                    return ec.validation_description
        except Exception:
            return None
        return None

    def _create_file_error_run(error_items: List[Tuple[int, str, str]]) -> ValidationRunRead:
        """Create a completed validation run containing only file-level OECD errors."""
        filing = _ensure_filing(db, filing_id)
        now = datetime.utcnow()

        run = models.ValidationRun(
            filing_id=filing_id,
            config_version_id=filing.config_version_id,
            status="completed",
            started_at=now,
            completed_at=now,
            message=(payload.notes or "") + "\nFile-level OECD validation failed; created blocking issue(s).",
        )
        db.add(run)
        db.commit()
        db.refresh(run)

        for (code, msg, xp) in error_items:
            db.add(models.ValidationIssue(
                validation_run_id=run.id,
                severity="BLOCKING",
                rule_id=f"OECD-{code}-{sha1((run.id or '').encode('utf-8')).hexdigest()[:10].upper()}",
                error_number=int(code),
                section="File",
                xml_path=xp or "/",
                message=msg,
                how_to_fix=_how_to_fix_for(int(code)),
                filer_code=None,
                jurisdiction_code=None,
                entity_code=None,
                context_key=None,
                created_at=now,
            ))
        db.commit()

        return ValidationRunRead(
            id=run.id,
            filing_id=run.filing_id,
            config_version_id=run.config_version_id,
            status=run.status,
            started_at=run.started_at,
            completed_at=run.completed_at,
            message=run.message,
            total_issues=len(error_items),
            blocking_issues=len(error_items),
            warning_issues=0,
            info_issues=0,
        )

    # First import
    import_payload = ImportGirXmlRequest(
        file_url=payload.file_url,
        source_system=payload.source_system,
        replace_existing=payload.replace_existing,
        strict_xsd=payload.strict_xsd,
        environment=payload.environment,
        expected_receiving_country=payload.expected_receiving_country,
    )

    try:
        import_result = import_gir_xml(filing_id, import_payload, db)
    except HTTPException as he:
        # Map "import could not be performed" cases to OECD file errors for a smoother customer UX.
        detail = str(he.detail)
        dlow = detail.lower()
        code = None
        if "download" in dlow:
            code = 50001  # could not download referenced file
        elif "decompress" in dlow:
            code = 50003  # could not decompress referenced file
        elif "invalid xml" in dlow:
            code = 50007  # treat non-wellformed XML as schema validation failure
        if code is None:
            raise

        now = datetime.utcnow()
        imp_id = f"IMP-FAILED-{now.strftime('%Y%m%d-%H%M%S')}-{sha1(filing_id.encode('utf-8')).hexdigest()[:8].upper()}"
        import_result = ImportGirXmlResponse(
            import_id=imp_id,
            filing_id=filing_id,
            status="file_failed",
            stats=ImportGirXmlStats(filers_total=0, jurisdictions_total=0, entities_total=0, datapoints_total=0),
            warnings=[ImportGirXmlWarning(code=f"OECD_FILE_ERROR_{code}", message=detail)],
        )

        run_read = _create_file_error_run([(int(code), detail, "/")])
        return ImportGirXmlValidateResponse(import_result=import_result, validation_run=run_read)

    # Short-circuit: file-level errors should be returned as a completed validation run with OECD codes.
    st = (import_result.status or "").strip().lower()

    if st in {"xsd_failed", "file_failed"}:
        # Convert import warnings into file-level OECD errors.
        err_items: List[Tuple[int, str, str]] = []

        if st == "xsd_failed":
            # Stage 5: XSD validation failure => OECD 50007
            detail_lines = []
            for w in (import_result.warnings or []):
                if (w.code or "").strip().upper() == "XSD_VALIDATION_FAILED":
                    detail_lines.append(w.message or "")
            detail = "\n".join([x for x in detail_lines if x.strip()])
            msg = "OECD 50007: GIR XML failed validation against the OECD GIR XML Schema (XSD)."
            if detail:
                msg = msg + "\n" + detail
            err_items.append((50007, msg, "/"))

        else:
            # Stage 6: 50008 / 50009 / 50010 (plus any future file error codes surfaced by the importer)
            path_map = {
                50008: ".//DocTypeIndic",
                50009: "//DocTypeIndic",
                50010: "MessageSpec/ReceivingCountry",
                50001: "/",
                50002: "/",
                50003: "/",
                50004: "/",
                50005: "/",
                50006: "/",
                50007: "/",
                50011: "/",
            }
            for w in (import_result.warnings or []):
                mm = re.match(r"^OECD_FILE_ERROR_(\d{5})$", (w.code or "").strip().upper())
                if not mm:
                    continue
                code = int(mm.group(1))
                err_items.append((code, w.message or f"OECD {code} file error", path_map.get(code, "/")))

        # If we didn't extract any codes (unexpected), fall back to a generic 50007 for safety.
        if not err_items:
            err_items = [(50007, "OECD 50007: File failed schema/structure validation (no further details).", "/")]

        run_read = _create_file_error_run(err_items)
        return ImportGirXmlValidateResponse(import_result=import_result, validation_run=run_read)

    # Otherwise run the full engine (reuse existing implementation for consistent persistence)
    try:
        run_dict = _create_validation_run(
            filing_id,
            ValidationRunCreate(notes=payload.notes),
            db,
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Validation failed: {e}")

    return ImportGirXmlValidateResponse(
        import_result=import_result,
        validation_run=ValidationRunRead(**run_dict),
    )


# -----------------------------
# GIR Toolkit XLSX import
# -----------------------------

_HEADER_SCAN_MAX_ROWS = 80
_DATA_MAX_ROWS = 250000
_CONSEC_EMPTY_STOP = 50


def _norm_header(h: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", (h or "").strip().lower())


def _cell_to_text(v) -> Optional[str]:
    """Convert common Excel cell types to a clean string."""
    if v is None:
        return None
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, datetime):
        return v.date().isoformat()
    if isinstance(v, date):
        return v.isoformat()
    s = str(v).strip()
    return s if s != "" else None


def _parse_yes_no(v) -> Optional[bool]:
    s = _cell_to_text(v)
    if s is None:
        return None
    s2 = s.strip().lower()
    if s2 in {"y", "yes", "true", "1"}:
        return True
    if s2 in {"n", "no", "false", "0"}:
        return False
    return None


def _juris_code(v) -> Optional[str]:
    s = _cell_to_text(v)
    if not s:
        return None
    s = s.strip().upper()
    # Keep common 2-char ISO codes; if longer, keep first 2 for robustness.
    return s[:2] if len(s) >= 2 else None


def _find_header_row(ws, required_norm_cols: Set[str]) -> Tuple[int, dict]:
    """Return (header_row_index, norm_col_to_index). header_row_index is 1-based."""
    for r_idx, row in enumerate(ws.iter_rows(min_row=1, max_row=_HEADER_SCAN_MAX_ROWS, values_only=True), start=1):
        norm_to_idx = {}
        for c_idx, v in enumerate(row or [], start=1):
            s = _cell_to_text(v)
            if not s:
                continue
            nh = _norm_header(s)
            if nh:
                # if duplicate header appears, keep first
                norm_to_idx.setdefault(nh, c_idx)
        if required_norm_cols.issubset(set(norm_to_idx.keys())):
            return r_idx, norm_to_idx
    raise ValueError(f"Could not find a header row containing required columns: {sorted(required_norm_cols)}")


def _iter_datapoint_rows_flatfile(ws, header_row: int, colmap: dict) -> Tuple[List[dict], Set[str], Set[str], Set[str]]:
    datapoints: List[dict] = []
    filer_codes: Set[str] = set()
    entity_codes: Set[str] = set()
    juris_codes: Set[str] = set()

    now = datetime.utcnow()

    # Candidate columns (normalized)
    c_filer = colmap.get(_norm_header("FilingEntity_ID"))
    c_entity = colmap.get(_norm_header("Entity_ID"))
    c_juris = colmap.get(_norm_header("Jurisdiction"))
    c_path = colmap.get(_norm_header("XML_Path"))
    c_value = colmap.get(_norm_header("Value"))
    c_ccy = colmap.get(_norm_header("Currency"))
    c_notes = colmap.get(_norm_header("Notes"))
    c_src = colmap.get(_norm_header("Source"))
    c_pby = colmap.get(_norm_header("Prepared_By"))
    c_pdt = colmap.get(_norm_header("Prepared_Date"))

    if not c_path or not c_value:
        raise ValueError("Flatfile sheet is missing required columns XML_Path and Value.")

    empty_run = 0
    for i, row in enumerate(ws.iter_rows(min_row=header_row + 1, max_row=header_row + _DATA_MAX_ROWS, values_only=True), start=1):
        # Stop after enough consecutive blank rows
        if row is None or all(v is None or (isinstance(v, str) and v.strip() == "") for v in row):
            empty_run += 1
            if empty_run >= _CONSEC_EMPTY_STOP:
                break
            continue
        empty_run = 0

        xml_path = _cell_to_text(row[c_path - 1] if c_path <= len(row) else None)
        if not xml_path:
            continue
        xml_path = xml_path.strip()
        if not xml_path.startswith("/"):
            xml_path = "/" + xml_path

        value = _cell_to_text(row[c_value - 1] if c_value <= len(row) else None)
        if value is None or value.strip() == "":
            # Treat blank as not provided
            continue
        value = value.strip()

        filer_code = _cell_to_text(row[c_filer - 1] if c_filer and c_filer <= len(row) else None)
        entity_code = _cell_to_text(row[c_entity - 1] if c_entity and c_entity <= len(row) else None)
        juris = _juris_code(row[c_juris - 1] if c_juris and c_juris <= len(row) else None)
        ccy = _cell_to_text(row[c_ccy - 1] if c_ccy and c_ccy <= len(row) else None)
        src = _cell_to_text(row[c_src - 1] if c_src and c_src <= len(row) else None)
        notes = _cell_to_text(row[c_notes - 1] if c_notes and c_notes <= len(row) else None)

        prepared_by = _cell_to_text(row[c_pby - 1] if c_pby and c_pby <= len(row) else None)
        prepared_date = _cell_to_text(row[c_pdt - 1] if c_pdt and c_pdt <= len(row) else None)

        extra_bits = []
        if prepared_by:
            extra_bits.append(f"prepared_by={prepared_by}")
        if prepared_date:
            extra_bits.append(f"prepared_date={prepared_date}")
        if src:
            extra_bits.append(f"source={src}")
        if extra_bits:
            notes = (notes + " | " if notes else "") + "; ".join(extra_bits)

        if filer_code:
            filer_codes.add(filer_code)
        if entity_code:
            entity_codes.add(entity_code)
        if juris:
            juris_codes.add(juris)

        datapoints.append({
            "filing_id": None,  # fill later
            "filer_code": filer_code,
            "jurisdiction_code": juris,
            "entity_code": entity_code,
            "context_key": None,
            "xml_path": xml_path,
            "value_raw": value,
            "value_numeric": try_parse_decimal(value),
            "value_date": try_parse_date(value),
            "currency": ccy,
            "source": "import",
            "source_system": None,  # fill later
            "notes": notes,
            "created_at": now,
            "updated_at": now,
        })

    return datapoints, filer_codes, juris_codes, entity_codes


def _iter_datapoint_rows_normalised(ws, header_row: int, colmap: dict) -> Tuple[List[dict], Set[str], Set[str], Set[str]]:
    datapoints: List[dict] = []
    filer_codes: Set[str] = set()
    entity_codes: Set[str] = set()
    juris_codes: Set[str] = set()

    now = datetime.utcnow()

    c_filer = colmap.get(_norm_header("FilingEntity_ID"))
    c_entity = colmap.get(_norm_header("Entity_ID"))
    c_juris = colmap.get(_norm_header("Jurisdiction"))
    c_ctx = colmap.get(_norm_header("Context_Key"))
    c_path = colmap.get(_norm_header("XML_Path"))
    c_value = colmap.get(_norm_header("Value"))
    c_ccy = colmap.get(_norm_header("Currency"))
    c_notes = colmap.get(_norm_header("Notes"))
    c_src = colmap.get(_norm_header("Source_Tool"))
    c_tax = colmap.get(_norm_header("Tax_Label"))

    if not c_path or not c_value:
        raise ValueError("Normalised output sheet is missing required columns XML_Path and Value.")

    empty_run = 0
    for row in ws.iter_rows(min_row=header_row + 1, max_row=header_row + _DATA_MAX_ROWS, values_only=True):
        if row is None or all(v is None or (isinstance(v, str) and v.strip() == "") for v in row):
            empty_run += 1
            if empty_run >= _CONSEC_EMPTY_STOP:
                break
            continue
        empty_run = 0

        xml_path = _cell_to_text(row[c_path - 1] if c_path <= len(row) else None)
        if not xml_path:
            continue
        xml_path = xml_path.strip()
        if not xml_path.startswith("/"):
            xml_path = "/" + xml_path

        value = _cell_to_text(row[c_value - 1] if c_value <= len(row) else None)
        if value is None or value.strip() == "":
            continue
        value = value.strip()

        filer_code = _cell_to_text(row[c_filer - 1] if c_filer and c_filer <= len(row) else None)
        entity_code = _cell_to_text(row[c_entity - 1] if c_entity and c_entity <= len(row) else None)
        juris = _juris_code(row[c_juris - 1] if c_juris and c_juris <= len(row) else None)
        ctx = _cell_to_text(row[c_ctx - 1] if c_ctx and c_ctx <= len(row) else None)
        ccy = _cell_to_text(row[c_ccy - 1] if c_ccy and c_ccy <= len(row) else None)
        notes = _cell_to_text(row[c_notes - 1] if c_notes and c_notes <= len(row) else None)
        src = _cell_to_text(row[c_src - 1] if c_src and c_src <= len(row) else None)
        tax_label = _cell_to_text(row[c_tax - 1] if c_tax and c_tax <= len(row) else None)

        extra_bits = []
        if tax_label:
            extra_bits.append(f"tax_label={tax_label}")
        if src:
            extra_bits.append(f"source={src}")
        if extra_bits:
            notes = (notes + " | " if notes else "") + "; ".join(extra_bits)

        if filer_code:
            filer_codes.add(filer_code)
        if entity_code:
            entity_codes.add(entity_code)
        if juris:
            juris_codes.add(juris)

        datapoints.append({
            "filing_id": None,
            "filer_code": filer_code,
            "jurisdiction_code": juris,
            "entity_code": entity_code,
            "context_key": ctx,
            "xml_path": xml_path,
            "value_raw": value,
            "value_numeric": try_parse_decimal(value),
            "value_date": try_parse_date(value),
            "currency": ccy,
            "source": "import",
            "source_system": None,
            "notes": notes,
            "created_at": now,
            "updated_at": now,
        })

    return datapoints, filer_codes, juris_codes, entity_codes


def _read_register_table(ws, required_norm_cols: Set[str]) -> Tuple[int, dict]:
    return _find_header_row(ws, required_norm_cols)


def _parse_filer_register(wb) -> List[dict]:
    if "Filing_Entity_Register" not in wb.sheetnames:
        return []
    ws = wb["Filing_Entity_Register"]
    # Header is usually row 1, but scan anyway.
    required = {_norm_header("FilingEntity_ID")}
    header_row, colmap = _read_register_table(ws, required)
    rows: List[dict] = []
    now = datetime.utcnow()

    def col(name: str) -> Optional[int]:
        return colmap.get(_norm_header(name))

    c_id = col("FilingEntity_ID")
    c_name = col("Legal_Name")
    c_role = col("Role")
    c_juris = col("Jurisdiction")
    c_tin = col("Tax_ID")
    c_ccy = col("Reporting_Currency")
    c_scope = col("Filing_Scope")
    c_owner = col("Contact_Owner")
    c_status = col("Status")
    c_id_rules = col("ID_Rules (default GIR205)")
    c_globe = col("GloBE_Status (default GIR301)")

    empty_run = 0
    for row in ws.iter_rows(min_row=header_row + 1, max_row=header_row + 5000, values_only=True):
        if row is None or all(v is None or (isinstance(v, str) and v.strip() == "") for v in row):
            empty_run += 1
            if empty_run >= _CONSEC_EMPTY_STOP:
                break
            continue
        empty_run = 0

        filer_code = _cell_to_text(row[c_id - 1] if c_id and c_id <= len(row) else None)
        if not filer_code:
            continue

        rows.append({
            "filing_id": None,
            "filer_code": filer_code,
            "legal_name": _cell_to_text(row[c_name - 1]) if c_name and c_name <= len(row) else None,
            "role": _cell_to_text(row[c_role - 1]) if c_role and c_role <= len(row) else None,
            "jurisdiction_code": _juris_code(row[c_juris - 1]) if c_juris and c_juris <= len(row) else None,
            "tin": _cell_to_text(row[c_tin - 1]) if c_tin and c_tin <= len(row) else None,
            "reporting_currency": (_cell_to_text(row[c_ccy - 1]) if c_ccy and c_ccy <= len(row) else None),
            "scope": _cell_to_text(row[c_scope - 1]) if c_scope and c_scope <= len(row) else None,
            "owner": _cell_to_text(row[c_owner - 1]) if c_owner and c_owner <= len(row) else None,
            "status": _cell_to_text(row[c_status - 1]) if c_status and c_status <= len(row) else None,
            "id_rules": _cell_to_text(row[c_id_rules - 1]) if c_id_rules and c_id_rules <= len(row) else None,
            "globe_status": _cell_to_text(row[c_globe - 1]) if c_globe and c_globe <= len(row) else None,
            "created_at": now,
            "updated_at": now,
        })
    return rows


def _parse_entity_register(wb) -> List[dict]:
    if "Constituent_Entity_Register" not in wb.sheetnames:
        return []
    ws = wb["Constituent_Entity_Register"]
    required = {_norm_header("Entity_ID")}
    header_row, colmap = _read_register_table(ws, required)
    rows: List[dict] = []
    now = datetime.utcnow()

    def col(name: str) -> Optional[int]:
        return colmap.get(_norm_header(name))

    c_id = col("Entity_ID")
    c_name = col("Legal_Name")
    c_juris = col("Jurisdiction")
    c_tin = col("Entity_TIN")
    c_incl = col("Included_in_GIR (Y/N)")
    c_filed_by = col("Filed_by (FilingEntity_ID)")
    c_parent = col("Immediate_Parent")
    c_own_pct = col("Ownership_%")
    c_id_rules = col("ID_Rules (default GIR205)")
    c_globe = col("GloBE_Status (default GIR301)")
    c_owner_type = col("Owner_Type_override")
    c_owner_tin = col("Owner_TIN_override")
    c_derived_owner_type = col("Derived_Owner_Type")

    empty_run = 0
    for row in ws.iter_rows(min_row=header_row + 1, max_row=header_row + 20000, values_only=True):
        if row is None or all(v is None or (isinstance(v, str) and v.strip() == "") for v in row):
            empty_run += 1
            if empty_run >= _CONSEC_EMPTY_STOP:
                break
            continue
        empty_run = 0

        entity_code = _cell_to_text(row[c_id - 1] if c_id and c_id <= len(row) else None)
        if not entity_code:
            continue

        own_pct_raw = _cell_to_text(row[c_own_pct - 1]) if c_own_pct and c_own_pct <= len(row) else None
        own_pct = try_parse_decimal(own_pct_raw) if own_pct_raw else None

        ownership_type = _cell_to_text(row[c_owner_type - 1]) if c_owner_type and c_owner_type <= len(row) else None
        if not ownership_type:
            ownership_type = _cell_to_text(row[c_derived_owner_type - 1]) if c_derived_owner_type and c_derived_owner_type <= len(row) else None

        rows.append({
            "filing_id": None,
            "entity_code": entity_code,
            "legal_name": _cell_to_text(row[c_name - 1]) if c_name and c_name <= len(row) else None,
            "jurisdiction_code": _juris_code(row[c_juris - 1]) if c_juris and c_juris <= len(row) else None,
            "tin": _cell_to_text(row[c_tin - 1]) if c_tin and c_tin <= len(row) else None,
            "included_in_gir": (_parse_yes_no(row[c_incl - 1]) if c_incl and c_incl <= len(row) else True),
            "filed_by_filer_code": _cell_to_text(row[c_filed_by - 1]) if c_filed_by and c_filed_by <= len(row) else None,
            "parent_entity_code": _cell_to_text(row[c_parent - 1]) if c_parent and c_parent <= len(row) else None,
            "ownership_percentage": own_pct,
            "ownership_type": ownership_type,
            "owner_tin_override": _cell_to_text(row[c_owner_tin - 1]) if c_owner_tin and c_owner_tin <= len(row) else None,
            "id_rules": _cell_to_text(row[c_id_rules - 1]) if c_id_rules and c_id_rules <= len(row) else None,
            "globe_status": _cell_to_text(row[c_globe - 1]) if c_globe and c_globe <= len(row) else None,
            "created_at": now,
            "updated_at": now,
        })
    return rows


def _parse_jurisdiction_register(wb) -> List[dict]:
    if "Jurisdiction_Register" not in wb.sheetnames:
        return []
    ws = wb["Jurisdiction_Register"]
    required = {_norm_header("Jurisdiction (ISO)")}
    header_row, colmap = _read_register_table(ws, required)
    rows: List[dict] = []
    now = datetime.utcnow()

    def col(name: str) -> Optional[int]:
        return colmap.get(_norm_header(name))

    c_j = col("Jurisdiction (ISO)")
    c_ccy = col("Local Currency (ISO)")
    c_resp = col("Responsible Filer (FilingEntity_ID)")
    c_mode = col("Computation Mode")
    c_qdmt = col("QDMTT applicable? (Y/N)")
    c_status = col("Status")
    c_notes = col("Notes")

    empty_run = 0
    for row in ws.iter_rows(min_row=header_row + 1, max_row=header_row + 5000, values_only=True):
        if row is None or all(v is None or (isinstance(v, str) and v.strip() == "") for v in row):
            empty_run += 1
            if empty_run >= _CONSEC_EMPTY_STOP:
                break
            continue
        empty_run = 0

        j = _juris_code(row[c_j - 1] if c_j and c_j <= len(row) else None)
        if not j:
            continue

        rows.append({
            "filing_id": None,
            "jurisdiction_code": j,
            "local_currency": _cell_to_text(row[c_ccy - 1]) if c_ccy and c_ccy <= len(row) else None,
            "responsible_filer_code": _cell_to_text(row[c_resp - 1]) if c_resp and c_resp <= len(row) else None,
            "computation_mode": _cell_to_text(row[c_mode - 1]) if c_mode and c_mode <= len(row) else None,
            "qdmt_applicable": _parse_yes_no(row[c_qdmt - 1]) if c_qdmt and c_qdmt <= len(row) else None,
            "status": _cell_to_text(row[c_status - 1]) if c_status and c_status <= len(row) else None,
            "notes": _cell_to_text(row[c_notes - 1]) if c_notes and c_notes <= len(row) else None,
            "created_at": now,
            "updated_at": now,
        })
    return rows


@router.post("/gir-toolkit-xlsx", response_model=ImportGirToolkitXlsxResponse)
def import_gir_toolkit_xlsx(filing_id: str, payload: ImportGirToolkitXlsxRequest, db: Session = Depends(get_db)):
    """Import an OECD Pillars GIR Prep Suite workbook (.xlsx) into registers + datapoints.

    Recommended ingestion sources (in priority order):
      1) GIR_Export_FlatFile (flat table: FilingEntity_ID, Jurisdiction, Entity_ID, XML_Path, Value, Currency, ...)
      2) Engine_Normalised_Output (normalized datapoints: includes Context_Key)
    """

    filing = _ensure_filing(db, filing_id)

    import_id = f"IMPX-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}-{sha1(f'{filing_id}'.encode('utf-8')).hexdigest()[:8].upper()}"
    warnings: List[ImportGirXmlWarning] = []

    url = (payload.file_url or "").strip()
    if not url.lower().startswith(("https://", "http://")):
        raise HTTPException(status_code=400, detail="file_url must start with http:// or https://")

    if payload.replace_existing:
        db.query(models.DataPoint).filter(models.DataPoint.filing_id == filing_id).delete(synchronize_session=False)
        db.query(models.Filer).filter(models.Filer.filing_id == filing_id).delete(synchronize_session=False)
        db.query(models.Jurisdiction).filter(models.Jurisdiction.filing_id == filing_id).delete(synchronize_session=False)
        db.query(models.ConstituentEntity).filter(models.ConstituentEntity.filing_id == filing_id).delete(synchronize_session=False)
        db.commit()

    try:
        resp = requests.get(url, timeout=(5, 120))
        resp.raise_for_status()
        content = resp.content
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to download file_url: {e}")

    try:
        wb = load_workbook(BytesIO(content), read_only=True, data_only=True)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to read .xlsx: {e}")

    # Choose sheet
    sheet_used: Optional[str] = None
    candidates = []
    if payload.preferred_sheet:
        candidates = [payload.preferred_sheet]
    else:
        candidates = ["GIR_Export_FlatFile", "Engine_Normalised_Output"]

    datapoint_rows: List[dict] = []


    filer_codes: Set[str] = set()
    juris_codes: Set[str] = set()
    entity_codes: Set[str] = set()

    last_err: Optional[str] = None
    for s in candidates:
        if s not in wb.sheetnames:
            last_err = f"Sheet {s} not present"
            continue
        ws = wb[s]
        try:
            if s == "GIR_Export_FlatFile":
                header_row, colmap = _find_header_row(ws, {_norm_header("XML_Path"), _norm_header("Value")})
                dps, fset, jset, eset = _iter_datapoint_rows_flatfile(ws, header_row, colmap)
            else:
                header_row, colmap = _find_header_row(ws, {_norm_header("XML_Path"), _norm_header("Value")})
                dps, fset, jset, eset = _iter_datapoint_rows_normalised(ws, header_row, colmap)
            if dps:
                datapoint_rows = dps
                filer_codes = fset
                juris_codes = jset
                entity_codes = eset
                sheet_used = s
                break
            else:
                last_err = f"Sheet {s} found but contains no datapoint rows (data_only mode may see blanks if formulas are not cached)."
        except Exception as e:
            last_err = str(e)

    if sheet_used is None:
        detail = (
            "No datapoints found in the workbook export sheets. "
            "Tried: " + ", ".join(candidates) + ". "
            + (f"Last error: {last_err}. " if last_err else "")
            + "Note: the server does not recalculate Excel formulas. "
            "Open the workbook in Excel, allow calculation to complete, save, and upload again; "
            "or export the flatfile to CSV and import that."
        )
        raise HTTPException(status_code=400, detail=detail)

    # Parse registers (best effort)
    filer_rows = _parse_filer_register(wb)
    entity_rows = _parse_entity_register(wb)
    juris_rows = _parse_jurisdiction_register(wb)

    # Fallback placeholders for codes referenced in datapoints but missing from registers
    now = datetime.utcnow()
    existing_filer_codes = {r.get("filer_code") for r in filer_rows if r.get("filer_code")}
    for fc in sorted(filer_codes - existing_filer_codes):
        filer_rows.append({
            "filing_id": None,
            "filer_code": fc,
            "reporting_currency": filing.reporting_currency,
            "created_at": now,
            "updated_at": now,
        })

    existing_entity_codes = {r.get("entity_code") for r in entity_rows if r.get("entity_code")}
    for ec in sorted(entity_codes - existing_entity_codes):
        entity_rows.append({
            "filing_id": None,
            "entity_code": ec,
            "included_in_gir": True,
            "created_at": now,
            "updated_at": now,
        })

    existing_juris_codes = {r.get("jurisdiction_code") for r in juris_rows if r.get("jurisdiction_code")}
    for jc in sorted(juris_codes - existing_juris_codes):
        juris_rows.append({
            "filing_id": None,
            "jurisdiction_code": jc,
            "created_at": now,
            "updated_at": now,
        })

    # Fill filing_id + source_system into row dicts
    for r in filer_rows:
        r["filing_id"] = filing_id
    for r in entity_rows:
        r["filing_id"] = filing_id
    for r in juris_rows:
        r["filing_id"] = filing_id
    for dp in datapoint_rows:
        dp["filing_id"] = filing_id
        dp["source_system"] = payload.source_system or "gir_toolkit_xlsx"

    # Upserts (same strategy as XML import)
    if filer_rows:
        stmt = insert(models.Filer).values(filer_rows)
        update_cols = {c.name: getattr(stmt.excluded, c.name) for c in models.Filer.__table__.columns if c.name not in ("id", "created_at")}
        stmt = stmt.on_conflict_do_update(constraint="uq_filer_filing_code", set_=update_cols)
        db.execute(stmt)
        db.commit()

    if juris_rows:
        stmt = insert(models.Jurisdiction).values(juris_rows)
        update_cols = {c.name: getattr(stmt.excluded, c.name) for c in models.Jurisdiction.__table__.columns if c.name not in ("id", "created_at")}
        stmt = stmt.on_conflict_do_update(constraint="uq_juris_filing_code", set_=update_cols)
        db.execute(stmt)
        db.commit()

    if entity_rows:
        stmt = insert(models.ConstituentEntity).values(entity_rows)
        update_cols = {c.name: getattr(stmt.excluded, c.name) for c in models.ConstituentEntity.__table__.columns if c.name not in ("id", "created_at")}
        stmt = stmt.on_conflict_do_update(constraint="uq_entity_filing_code", set_=update_cols)
        db.execute(stmt)
        db.commit()

    if datapoint_rows:
        for chunk in _chunked(datapoint_rows, 5000):
            stmt = insert(models.DataPoint).values(chunk)
            update_cols = {c.name: getattr(stmt.excluded, c.name) for c in models.DataPoint.__table__.columns if c.name not in ("id", "created_at")}
            stmt = stmt.on_conflict_do_update(constraint="uq_datapoint_key", set_=update_cols)
            db.execute(stmt)
        db.commit()

    filing.updated_at = datetime.utcnow()
    db.add(filing)
    db.commit()

            # Stage 3: persist submission history (for cross-submission OECD validations like 60002/60009/60014)
    try:
        cfg = load_config(settings.config_root, filing.config_version_id)
        record_submission_from_import(
            db=db,
            filing=filing,
            config=cfg,
            source_type="xlsx",
            file_url=url,
            file_bytes=content,
            datapoint_rows=datapoint_rows,
            message_ref_id=None,
            reporting_period_start=filing.period_start,
            reporting_period_end=filing.period_end,
            notes=f"import_id={import_id}; source_system={payload.source_system or 'gir_toolkit_xlsx'}; sheet={sheet_used}",
        )
    except Exception as e:
        warnings.append(ImportGirXmlWarning(
            code="SUBMISSION_HISTORY_FAILED",
            message=f"Could not record submission history: {e}",
        ))

    stats = ImportGirXmlStats(
        filers_total=len({r.get("filer_code") for r in filer_rows if r.get("filer_code")}),
        jurisdictions_total=len({r.get("jurisdiction_code") for r in juris_rows if r.get("jurisdiction_code")}),
        entities_total=len({r.get("entity_code") for r in entity_rows if r.get("entity_code")}),
        datapoints_total=len(datapoint_rows),
    )

    return ImportGirToolkitXlsxResponse(
        import_id=import_id,
        filing_id=filing_id,
        status="completed",
        sheet_used=sheet_used,
        stats=stats,
        warnings=warnings,
    )


@router.post("/gir-toolkit-xlsx:validate", response_model=ImportGirToolkitXlsxValidateResponse)
def import_gir_toolkit_xlsx_and_validate(
    filing_id: str,
    payload: ImportGirToolkitXlsxValidateRequest,
    db: Session = Depends(get_db),
):
    """One-click import + validate for GIR Toolkit workbooks."""

    import_payload = ImportGirToolkitXlsxRequest(
        file_url=payload.file_url,
        source_system=payload.source_system,
        replace_existing=payload.replace_existing,
        preferred_sheet=payload.preferred_sheet,
    )
    import_result = import_gir_toolkit_xlsx(filing_id, import_payload, db)

    try:
        run_dict = _create_validation_run(
            filing_id,
            ValidationRunCreate(notes=payload.notes),
            db,
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Validation failed: {e}")

    return ImportGirToolkitXlsxValidateResponse(
        import_result=import_result,
        validation_run=ValidationRunRead(**run_dict),
    )


@router.post("/status-message-xml:validate", response_model=StatusMessageValidateResponse)
def validate_status_message_xml(
    filing_id: str,
    payload: StatusMessageValidateRequest,
    db: Session = Depends(get_db),
):
    """Validate (schema-check) and parse a GIR Status Message XML file.

    This endpoint is useful if you receive a Status Message from a tax administration
    and want to:
      - Verify it is schema-valid (if you have added the Status Message XSD bundle), and
      - Extract file/record error codes + details into a JSON shape for dashboards.

    Note: Status Messages are *not* imported into datapoints; they are parsed and returned.
    """

    # Filing context is optional, but keeping it consistent with other /imports routes.
    _ensure_filing(db, filing_id)

    url = (payload.file_url or "").strip()
    if not url.lower().startswith(("https://", "http://")):
        raise HTTPException(status_code=400, detail="file_url must start with http:// or https://")

    try:
        resp = requests.get(url, timeout=60)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Could not download file_url: {e}")

    if resp.status_code >= 400:
        raise HTTPException(status_code=400, detail=f"Could not download file_url: HTTP {resp.status_code}")

    content = resp.content or b""
    max_bytes = 20 * 1024 * 1024
    if len(content) > max_bytes:
        raise HTTPException(status_code=413, detail=f"File too large ({len(content)} bytes). Max {max_bytes} bytes")

    # Allow ZIP convenience wrapper (same logic as GIR importer)
    is_zip = (
        url.lower().endswith(".zip")
        or (resp.headers.get("content-type") or "").lower().startswith("application/zip")
        or (len(content) >= 4 and content[:2] == b"PK")
    )
    if is_zip:
        try:
            zf = zipfile.ZipFile(BytesIO(content))
            names = [n for n in zf.namelist() if n and not n.endswith("/") and not n.startswith("__MACOSX")]
            xml_names = [n for n in names if n.lower().endswith(".xml")]
            pick = (xml_names[0] if xml_names else (names[0] if names else None))
            if not pick:
                raise ValueError("ZIP archive is empty (no files found).")
            content = zf.read(pick)
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Could not decompress referenced file: {e}")

    # Optional Status Message XSD validation
    do_xsd = bool(payload.strict_xsd) or (settings.status_xsd_validation_mode == "on")
    schema_valid = True
    schema_errors: List[str] = []
    if do_xsd:
        try:
            res = validate_xml_against_status_message_xsd(
                content,
                xsd_zip_path=settings.status_xsd_zip_path,
                xsd_dir=settings.status_xsd_dir,
                main_xsd=settings.status_xsd_main,
                max_errors=50,
            )
            schema_valid = bool(res.valid)
            schema_errors = res.errors
        except FileNotFoundError as e:
            schema_valid = False
            schema_errors = [str(e)]

    # Parse (best-effort, even if schema invalid)
    parsed: StatusMessageParsed | None = None
    try:
        root = etree.fromstring(content)

        def _first_text(node, local_name: str) -> str | None:
            els = node.xpath(f"./*[local-name()='{local_name}']")
            if not els:
                return None
            return (els[0].text or "").strip() or None

        ms_nodes = root.xpath("./*[local-name()='MessageSpec']")
        body_nodes = root.xpath("./*[local-name()='GIRStatusMessage']")

        ms = ms_nodes[0] if ms_nodes else None
        body = body_nodes[0] if body_nodes else None

        out = StatusMessageParsed()

        if ms is not None:
            out.transmitting_country = _first_text(ms, "TransmittingCountry")
            out.receiving_country = _first_text(ms, "ReceivingCountry")
            out.message_type = _first_text(ms, "MessageType")
            out.message_ref_id = _first_text(ms, "MessageRefID")
            ts = _first_text(ms, "Timestamp")
            if ts:
                try:
                    out.timestamp = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                except Exception:
                    out.timestamp = None

        if body is not None:
            orig = body.xpath("./*[local-name()='OriginalMessage']")
            if orig:
                out.original_message_ref_id = _first_text(orig[0], "OriginalMessageRefID")

            # ValidationErrors
            verr = body.xpath("./*[local-name()='ValidationErrors']")
            if verr:
                verr0 = verr[0]

                # FileError
                for fe in verr0.xpath("./*[local-name()='FileError']"):
                    code = _first_text(fe, "Code")
                    det_el = fe.xpath("./*[local-name()='Details']")
                    det = (det_el[0].text or "").strip() if det_el else None
                    lang = det_el[0].get("Language") if det_el else None
                    if code:
                        out.file_errors.append(StatusMessageFileError(code=code, details=det or None, language=lang or None))

                # RecordError
                for re0 in verr0.xpath("./*[local-name()='RecordError']"):
                    code = _first_text(re0, "Code")
                    det_el = re0.xpath("./*[local-name()='Details']")
                    det = (det_el[0].text or "").strip() if det_el else None
                    lang = det_el[0].get("Language") if det_el else None

                    docrefs = [
                        (x.text or "").strip()
                        for x in re0.xpath("./*[local-name()='DocRefIDInError']")
                        if (x.text or "").strip()
                    ]
                    fps: List[str] = []
                    for fie in re0.xpath("./*[local-name()='FieldsInError']"):
                        for fp in fie.xpath("./*[local-name()='FieldPath']"):
                            t = (fp.text or "").strip()
                            if t:
                                fps.append(t)

                    if code:
                        out.record_errors.append(
                            StatusMessageRecordError(
                                code=code,
                                details=det or None,
                                language=lang or None,
                                doc_ref_ids_in_error=docrefs,
                                field_paths_in_error=fps,
                            )
                        )

            # ValidationResult
            vr = body.xpath("./*[local-name()='ValidationResult']")
            if vr:
                vr0 = vr[0]
                out.validation_status = _first_text(vr0, "Status")
                out.validated_by = [
                    (x.text or "").strip()
                    for x in vr0.xpath("./*[local-name()='ValidatedBy']")
                    if (x.text or "").strip()
                ]

        parsed = out

    except Exception:
        parsed = None

    return StatusMessageValidateResponse(schema_valid=schema_valid, schema_errors=schema_errors, parsed=parsed)
