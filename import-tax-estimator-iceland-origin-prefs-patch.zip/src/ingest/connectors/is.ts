import { v4 as uuidv4 } from "uuid";
import unzipper from "unzipper";

import type { Connector, ConnectorResult, RunContext } from "./base";
import { parseRateToAst } from "../lib/parseRateToAst";

/**
 * Iceland (IS) — Customs tariff connector.
 *
 * Data source: Skatturinn (Iceland tax/customs authority) publishes "Tollskrárlyklar"
 * (tariff keys) as a zipped ASCII text file.
 *
 * Notes:
 * - The tariff keys file contains duty codes and rates, but NOT commodity descriptions.
 * - Duties are expressed as:
 *   - a percent duty (ad valorem) applied to customs value, and/or
 *   - a specific duty amount (ISK) applied per net kg.
 *
 * This connector ingests:
 * - MFN duty using a configurable duty code (default: "A")
 * - Preferential duty for:
 *   - EU origins (default duty code: "B") encoded as a single group measure
 *   - EFTA origins (default duty code: "EF") encoded as a single group measure
 */

const DEFAULT_TARIFF_KEYS_URL = "https://www.skatturinn.is/media/tollamal/TSKINN01032026.zip";
const OPEN_END = process.env.OPEN_END_DATE ?? "9999-12-31";

const EU_ISO2 = [
  "AT","BE","BG","HR","CY","CZ","DK","EE","FI","FR","DE","GR","HU","IE","IT","LV","LT","LU","MT","NL","PL","PT","RO","SK","SI","ES","SE",
];

// EFTA members (excluding IS itself when used as an origin set for imports into IS)
const EFTA_ORIGINS = ["CH", "LI", "NO"]; // Iceland itself is not a meaningful "origin" for imports into IS
/**
 * Additional preferential duty codes by origin (ISO alpha-2).
 *
 * Skatturinn tariff keys sometimes encode FTA/bilateral preferences using "Y*" duty codes.
 * Examples:
 * - YC: EFTA–Canada FTA
 * - YL: Iceland–China FTA
 *
 * Configure/override via IS_PREF_ORIGIN_DUTY_MAP_JSON.
 * Format: {"CN":"YL","CA":"YC","ID":["YT"]}.
 */
const DEFAULT_PREF_ORIGIN_DUTY_CODES: Record<string, string[]> = {
  CN: ["YL"],
  CA: ["YC"],
};

function parsePrefOriginDutyMap(): Record<string, string[]> {
  const out: Record<string, string[]> = { ...DEFAULT_PREF_ORIGIN_DUTY_CODES };
  const raw = process.env.IS_PREF_ORIGIN_DUTY_MAP_JSON;
  if (!raw) return out;

  let parsed: any;
  try {
    parsed = JSON.parse(raw);
  } catch (e: any) {
    throw new Error(`IS: Invalid JSON in IS_PREF_ORIGIN_DUTY_MAP_JSON (${String(e?.message ?? e)})`);
  }
  if (!parsed || typeof parsed !== "object") return out;

  for (const [k, v] of Object.entries(parsed)) {
    const origin = String(k ?? "").trim().toUpperCase();
    if (!/^[A-Z]{2}$/.test(origin)) continue;

    const codes: string[] = [];
    const pushCode = (val: any) => {
      const c = String(val ?? "").trim().toUpperCase();
      if (!c) return;
      if (!/^[A-Z0-9]{1,2}$/.test(c)) return;
      codes.push(c);
    };

    if (typeof v === "string") {
      pushCode(v);
    } else if (Array.isArray(v)) {
      for (const item of v) pushCode(item);
    }

    if (codes.length) out[origin] = codes;
  }

  return out;
}

function normalizeCode(code: any): string {
  return String(code ?? "").replace(/[^0-9]/g, "");
}

async function fetchBuffer(url: string, timeoutMs: number): Promise<Buffer> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { signal: ctrl.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status} fetching ${url}`);
    const ab = await res.arrayBuffer();
    return Buffer.from(ab);
  } finally {
    clearTimeout(t);
  }
}

function parseFixedNumber(raw: string): number {
  const s = String(raw ?? "").trim();
  if (!s) return 0;
  const n = Number(s);
  if (!Number.isFinite(n)) return 0;
  return n;
}

type DutyRate = { pct: number; iskPerKg: number };

function upsertDuty(map: Map<string, DutyRate>, dutyCode: string, pct: number, iskPerKg: number) {
  const code = String(dutyCode ?? "").trim().toUpperCase();
  if (!code) return;
  const prev = map.get(code);
  if (!prev) {
    map.set(code, { pct, iskPerKg });
    return;
  }
  // Best-effort merge (the format should not normally repeat a duty code)
  map.set(code, {
    pct: Math.max(prev.pct, pct),
    iskPerKg: Math.max(prev.iskPerKg, iskPerKg),
  });
}

function dutyToText(d: DutyRate): string {
  const pct = Number(d.pct);
  const spec = Number(d.iskPerKg);

  const pctText = pct > 0 ? `${pct}%` : "";
  const specText = spec > 0 ? `${spec} ISK / kg` : "";

  if (pctText && specText) return `${pctText} + ${specText}`;
  if (pctText) return pctText;
  if (specText) return specText;
  return "0%";
}

function extractTextFileFromZip(buf: Buffer): Promise<{ filename: string; text: string }> {
  return new Promise(async (resolve, reject) => {
    try {
      const dir = await unzipper.Open.buffer(buf);
      const files = dir.files.filter((f) => f.type === "File");
      if (!files.length) throw new Error("IS: No files found inside tariff keys zip");

      const pick =
        files.find((f) => f.path.toLowerCase().endsWith(".txt")) ??
        files.find((f) => f.path.toLowerCase().endsWith(".asc")) ??
        files.find((f) => f.path.toLowerCase().endsWith(".dat")) ??
        files[0]!;

      const fileBuf = await pick.buffer();
      // The spec says ASCII. We decode as latin1 for safety (ASCII is a subset).
      const text = fileBuf.toString("latin1");
      resolve({ filename: pick.path, text });
    } catch (e) {
      reject(e);
    }
  });
}

export class IsConnector implements Connector {
  readonly sourceName = "IS Skatturinn tariff keys (Tollskrárlyklar)";

  async run(ctx: RunContext): Promise<ConnectorResult> {
    const timeoutMs = Number(process.env.IS_HTTP_TIMEOUT_MS ?? process.env.HTTP_TIMEOUT_MS ?? "30000");

    const url = process.env.IS_TARIFF_KEYS_URL ?? DEFAULT_TARIFF_KEYS_URL;
    const mfnDutyCode = String(process.env.IS_MFN_DUTY_CODE ?? "A").trim().toUpperCase();
    const euPrefDutyCode = String(process.env.IS_PREF_EU_DUTY_CODE ?? "B").trim().toUpperCase();
    const eftaPrefDutyCode = String(process.env.IS_PREF_EFTA_DUTY_CODE ?? "EF").trim().toUpperCase();

    const prefOriginDutyMap = parsePrefOriginDutyMap();

    const vatRatePct = String(process.env.IS_VAT_RATE_PCT ?? "24");

    const zipBuf = await fetchBuffer(url, timeoutMs);
    const extracted = await extractTextFileFromZip(zipBuf);

    // Accumulate duty codes/rates per tariff number.
    const byTariff = new Map<string, Map<string, DutyRate>>();

    const lines = extracted.text.split(/\r?\n/g);

    // The 2013 spec shows duty blocks at positions 10–243 (1-based) with 18 slots.
    // We parse the line as fixed-width and pad to 243 chars to handle short lines.
    const LINE_LEN = 243;
    const DUTY_BLOCK_START = 9; // 0-based index for position 10
    const DUTY_BLOCK_END = 243; // slice end (exclusive)
    const DUTY_SLOTS = 18;
    const DUTY_SLOT_LEN = 13;

    for (const rawLine of lines) {
      const line = String(rawLine ?? "");
      if (!line) continue;

      const recordType = line[0];
      if (recordType !== "1" && recordType !== "2" && recordType !== "3") continue;

      const padded = line.padEnd(LINE_LEN, " ");
      const code = normalizeCode(padded.slice(1, 9));
      if (!code) continue;

      const dutyMap = byTariff.get(code) ?? new Map<string, DutyRate>();

      const dutiesStr = padded.slice(DUTY_BLOCK_START, DUTY_BLOCK_END);
      for (let i = 0; i < DUTY_SLOTS; i++) {
        const block = dutiesStr.slice(i * DUTY_SLOT_LEN, (i + 1) * DUTY_SLOT_LEN);
        if (!block || !block.trim()) continue;

        const dutyCode = block.slice(0, 2).trim().toUpperCase();
        if (!dutyCode) continue;

        const pctRaw = block.slice(2, 7);
        const specRaw = block.slice(7, 13);

        // n3,2 and n4,2 are stored as integers with implied 2 decimals.
        const pctInt = parseFixedNumber(pctRaw);
        const specInt = parseFixedNumber(specRaw);

        const pct = pctInt / 100;
        const iskPerKg = specInt / 100;

        upsertDuty(dutyMap, dutyCode, pct, iskPerKg);
      }

      byTariff.set(code, dutyMap);
    }

    if (byTariff.size === 0) {
      throw new Error(`IS: No tariff duty records parsed from ${url} (file=${extracted.filename}).`);
    }

    const tariffLines: any[] = [];
    const expressions: any[] = [];
    const measures: any[] = [];

    // Simple in-run cache to reuse identical expressions.
    const exprCache = new Map<string, string>(); // normalizedRateText -> expressionId

    function getOrCreateExpression(rateText: string, sourceRef: string): string {
      const key = rateText;
      const hit = exprCache.get(key);
      if (hit) return hit;

      const expressionId = uuidv4();
      const parsed = parseRateToAst(rateText, {
        defaultCurrency: "ISK",
        defaultMassField: "net_mass_kg",
        defaultCountField: "quantity",
        defaultVolumeField: "volume_litre",
      });

      if (parsed.ok) {
        expressions.push({
          expressionId,
          exprType: parsed.exprType,
          astJson: parsed.ast,
          currency: parsed.exprType === "SPECIFIC" || parsed.exprType === "COMPOUND" ? "ISK" : null,
          unitCode: null,
          sourceRef,
        });
      } else {
        expressions.push({
          expressionId,
          exprType: "CUSTOM",
          astJson: { op: "manual_required", raw: rateText, reason: parsed.reason, message: parsed.message },
          currency: null,
          unitCode: null,
          sourceRef,
        });
      }

      exprCache.set(key, expressionId);
      return expressionId;
    }

    for (const [code, dutyMap] of byTariff.entries()) {
      const tariffLineId = uuidv4();

      tariffLines.push({
        tariffLineId,
        jurisdictionId: "IS",
        code,
        codeLen: code.length,
        description: null,
        validFrom: ctx.asOfDate,
        validTo: OPEN_END,
        sourceRef: `${url}#${extracted.filename}`,
      });

      // MFN duty (default: A)
      const mfnDuty = dutyMap.get(mfnDutyCode) ?? null;
      if (mfnDuty) {
        const mfnText = dutyToText(mfnDuty);
        const expressionId = getOrCreateExpression(mfnText, `IS:${mfnDutyCode}:${mfnText}`);
        measures.push({
          measureId: uuidv4(),
          tariffLineId,
          expressionId,
          measureType: "CUSTOMS_DUTY",
          originScope: "MFN",
          originCode: "ALL",
          validFrom: ctx.asOfDate,
          validTo: OPEN_END,
          sourceRef: `IS duty code ${mfnDutyCode}`,
        });
      }

      // Preferential: EU group (default: B)
      const euDuty = dutyMap.get(euPrefDutyCode) ?? null;
      if (euDuty) {
        const txt = dutyToText(euDuty);
        const expressionId = getOrCreateExpression(txt, `IS:${euPrefDutyCode}:${txt}`);
        measures.push({
          measureId: uuidv4(),
          tariffLineId,
          expressionId,
          measureType: "CUSTOMS_DUTY",
          originScope: "PREFERENTIAL",
          originCode: "EU",
          conditionsJson: { originMemberCodes: EU_ISO2 },
          validFrom: ctx.asOfDate,
          validTo: OPEN_END,
          sourceRef: `IS duty code ${euPrefDutyCode} (EU)`,
        });
      }

      // Preferential: EFTA group (default: EF)
      const eftaDuty = dutyMap.get(eftaPrefDutyCode) ?? null;
      if (eftaDuty) {
        const txt = dutyToText(eftaDuty);
        const expressionId = getOrCreateExpression(txt, `IS:${eftaPrefDutyCode}:${txt}`);
        measures.push({
          measureId: uuidv4(),
          tariffLineId,
          expressionId,
          measureType: "CUSTOMS_DUTY",
          originScope: "PREFERENTIAL",
          originCode: "EFTA",
          conditionsJson: { originMemberCodes: EFTA_ORIGINS },
          validFrom: ctx.asOfDate,
          validTo: OPEN_END,
          sourceRef: `IS duty code ${eftaPrefDutyCode} (EFTA)`,
        });
      }


// Preferential: additional origin-specific mappings (e.g., FTA partners like CN/CA)
for (const [originIso2, dutyCodes] of Object.entries(prefOriginDutyMap)) {
  for (const dutyCode of dutyCodes) {
    const prefDuty = dutyMap.get(dutyCode) ?? null;
    if (!prefDuty) continue;

    const txt = dutyToText(prefDuty);
    const expressionId = getOrCreateExpression(txt, `IS:${dutyCode}:${txt}`);
    measures.push({
      measureId: uuidv4(),
      tariffLineId,
      expressionId,
      measureType: "CUSTOMS_DUTY",
      originScope: "PREFERENTIAL",
      originCode: originIso2,
      validFrom: ctx.asOfDate,
      validTo: OPEN_END,
      sourceRef: `IS duty code ${dutyCode} (${originIso2})`,
    });
  }
}
    }

    const vatRules = [
      {
        vatRuleId: uuidv4(),
        jurisdictionId: "IS",
        rateType: "STANDARD" as const,
        ratePct: vatRatePct,
        validFrom: ctx.asOfDate,
        validTo: OPEN_END,
        sourceRef: "IS VAT standard (MVP)",
      },
    ];

    const vatBaseFormulas = [
      {
        vatBaseFormulaId: uuidv4(),
        jurisdictionId: "IS",
        astJson: {
          op: "add",
          terms: [
            { op: "field", name: "customs_value" },
            { op: "field", name: "customs_duty_total" },
            { op: "field", name: "fees_total" },
            { op: "field", name: "freight_to_border" },
            { op: "field", name: "insurance_to_border" },
          ],
        },
        validFrom: ctx.asOfDate,
        validTo: OPEN_END,
        sourceRef: "IS VAT base (MVP)",
      },
    ];

    return {
      canonical: {
        tariffLines,
        expressions,
        measures,
        vatRules,
        vatBaseFormulas,
        thresholdRules: [],
      },
      manifest: {
        runId: ctx.runId,
        jurisdictionId: ctx.jurisdictionId,
        asOfDate: ctx.asOfDate,
        sourceName: this.sourceName,
        urls: [url],
        file: extracted.filename,
        insertedLines: tariffLines.length,
      },
    };
  }
}
