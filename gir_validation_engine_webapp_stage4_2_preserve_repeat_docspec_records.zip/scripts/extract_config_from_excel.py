#!/usr/bin/env python3
"""Extract GIR configuration JSON from the Excel GIR toolkit.

This script is intentionally **data-driven**:
- It reads the master element library (paths, requiredness, allowed values, etc.)
- It reads section cardinality
- It reads lists/codelists
- It reads OECD error codes

Usage:
  python scripts/extract_config_from_excel.py --workbook <file.xlsx> --config-version GIR_CONFIG_v1 --outdir config/GIR_CONFIG_v1
"""

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
import pandas as pd
import numpy as np

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def yn_to_bool(v: Any) -> bool:
    if isinstance(v, str):
        return v.strip().lower() in ("y", "yes", "true", "1")
    if isinstance(v, (int, float)) and not np.isnan(v):
        return bool(v)
    return False

def parse_max_occurs(v: Any) -> Optional[Union[int, str]]:
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return None
    if isinstance(v, str):
        s = v.strip()
        if s == "":
            return None
        if s.lower() == "unbounded":
            return "unbounded"
        # numeric string
        try:
            return int(float(s))
        except Exception:
            return s
    if isinstance(v, (int, np.integer)):
        return int(v)
    if isinstance(v, float):
        if np.isnan(v):
            return None
        return int(v)
    return str(v)

def parse_min_occurs(v: Any) -> Optional[int]:
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return None
    try:
        return int(float(v))
    except Exception:
        return None

def parse_allowed_values(dropdown_codes: Any, codes: Any) -> List[str]:
    # Prefer the dropdown-code field if present (it is already pipe-delimited)
    raw = None
    if isinstance(dropdown_codes, str) and dropdown_codes.strip():
        raw = dropdown_codes.strip()
        parts = [p.strip() for p in raw.split("|") if p.strip()]
        return sorted(list(dict.fromkeys(parts)))
    # Fallback: parse the long 'Allowed Values (Codes)' which is usually line-delimited
    if isinstance(codes, str) and codes.strip():
        lines = [ln.strip() for ln in codes.splitlines() if ln.strip()]
        # Many lines are like "GIR401 – Ultimate Parent Entity" -> take the code before the dash.
        out = []
        for ln in lines:
            code = ln.split("–")[0].strip()
            code = code.split("-")[0].strip()
            if code:
                out.append(code)
        return sorted(list(dict.fromkeys(out)))
    return []

def export_json(obj: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--workbook", required=True, help="Path to the Excel workbook")
    ap.add_argument("--config-version", required=True, help="Config version id (folder name)")
    ap.add_argument("--outdir", required=True, help="Output directory (e.g., config/GIR_CONFIG_v1)")
    args = ap.parse_args()

    wb_path = Path(args.workbook).expanduser().resolve()
    outdir = Path(args.outdir).expanduser().resolve()

    if not wb_path.exists():
        raise SystemExit(f"Workbook not found: {wb_path}")

    wb_hash = sha256_file(wb_path)
    generated_at = datetime.now(timezone.utc).isoformat()

    # Load sheets
    elements_df = pd.read_excel(wb_path, sheet_name="Master_All_Elements")
    cardinality_df = pd.read_excel(wb_path, sheet_name="Section_Cardinality")
    lists_df = pd.read_excel(wb_path, sheet_name="Lists")
    errors_df = pd.read_excel(wb_path, sheet_name="Error_Code_Library")

    # Elements
    elements: List[Dict[str, Any]] = []
    for _, r in elements_df.iterrows():
        xpath = r.get("XSD XPath (absolute)") or r.get("XML Hierarchy (Path)") or r.get("XSD XPath (relative)")
        if not isinstance(xpath, str) or not xpath.strip():
            continue
        el = {
            "section": str(r.get("Section", "")).strip(),
            "element_name": str(r.get("Element Name", "")).strip(),
            "tax_label": str(r.get("Tax-Friendly Label (v1)", "")).strip(),
            "guidance": None if pd.isna(r.get("OECD Guidance Explanation")) else str(r.get("OECD Guidance Explanation")),
            "input_field": yn_to_bool(r.get("Input Field?")),
            "example_value": None if pd.isna(r.get("Example Value")) else str(r.get("Example Value")),
            "required": yn_to_bool(r.get("Required?")),
            "repeatable": yn_to_bool(r.get("Repeatable?")),
            "repeatability_scope": None if pd.isna(r.get("Repeatability Scope")) else str(r.get("Repeatability Scope")),
            "allowed_values": parse_allowed_values(r.get("Allowed Values (Dropdown Codes)"), r.get("Allowed Values (Codes)")),
            "is_container": yn_to_bool(r.get("Is Container?")),
            "xsd_type": None if pd.isna(r.get("XSD Type")) else str(r.get("XSD Type")),
            "min_occurs": parse_min_occurs(r.get("minOccurs")),
            "max_occurs": parse_max_occurs(r.get("maxOccurs")),
            "xpath": xpath.strip(),
            "hierarchy_level": None if pd.isna(r.get("Hierarchy Level")) else int(r.get("Hierarchy Level")),
            "xml_hierarchy_path": None if pd.isna(r.get("XML Hierarchy (Path)")) else str(r.get("XML Hierarchy (Path)")),
        }
        elements.append(el)

    # Section cardinality
    section_cardinality: List[Dict[str, Any]] = []
    for _, r in cardinality_df.iterrows():
        section_cardinality.append({
            "section": str(r.get("Section", "")).strip(),
            "container_xpath": str(r.get("Container XPath", "")).strip(),
            "xsd_type": None if pd.isna(r.get("XSD Type")) else str(r.get("XSD Type")),
            "min_occurs": parse_min_occurs(r.get("minOccurs")),
            "max_occurs": parse_max_occurs(r.get("maxOccurs")),
            "repeatable": yn_to_bool(r.get("Repeatable?")),
        })

    # Codelists (each column is a list)
    codelists: Dict[str, List[str]] = {}
    for col in lists_df.columns:
        values = [str(x).strip() for x in lists_df[col].dropna().tolist() if str(x).strip() != ""]
        # Deduplicate but preserve order
        dedup = list(dict.fromkeys(values))
        if dedup:
            codelists[col] = dedup

    # Error codes
    error_codes: List[Dict[str, Any]] = []
    for _, r in errors_df.iterrows():
        if pd.isna(r.get("Number")):
            continue
        try:
            num = int(r.get("Number"))
        except Exception:
            continue
        error_codes.append({
            "section": str(r.get("Section", "")).strip(),
            "number": num,
            "path_target": None if pd.isna(r.get("Path (Target)")) else str(r.get("Path (Target)")),
            "path_reference": None if pd.isna(r.get("Path (Reference)")) else str(r.get("Path (Reference)")),
            "element_name": None if pd.isna(r.get("Element Name")) else str(r.get("Element Name")),
            "validation_rule": None if pd.isna(r.get("Validation Rule")) else str(r.get("Validation Rule")),
            "validation_description": None if pd.isna(r.get("Validation Description")) else str(r.get("Validation Description")),
        })

    # Config meta
    meta = {
        "config_version_id": args.config_version,
        "generated_at_utc": generated_at,
        "source_workbook_sha256": wb_hash,
        "notes": "Generated from Excel toolkit",
    }

    # Write files
    export_json(meta, outdir / "config.json")
    export_json(elements, outdir / "elements.json")
    export_json(section_cardinality, outdir / "section_cardinality.json")
    export_json(codelists, outdir / "codelists.json")
    export_json(error_codes, outdir / "error_codes.json")

    # Sprint 2.2: starter reconciliation set definitions.
    # These can be refined by clients to match workbook 'expected datapoints' logic.
    reconciliation_sets = {
        "version": "1",
        "sets": [
            {
                "set_id": "JURIS_OVERALL_REQUIRED",
                "description": "Jurisdiction-level required outputs under OverallComputation (minOccurs>=1, non-repeatable leaves).",
                "section": "Jurisdiction",
                "scope": "jurisdiction",
                "xpath_includes": ["/OverallComputation/"],
                "required_only": True,
                "exclude_repeatable": True,
            },
            {
                "set_id": "JURIS_CE_REQUIRED",
                "description": "Entity-level required outputs under CEComputation (minOccurs>=1, non-repeatable leaves).",
                "section": "Jurisdiction",
                "scope": "entity",
                "xpath_includes": ["/CEComputation/"],
                "required_only": True,
                "exclude_repeatable": True,
            },
        ],
    }
    export_json(reconciliation_sets, outdir / "reconciliation_sets.json")

    print(f"Wrote config to: {outdir}")
    print(f"Elements: {len(elements)} | Error codes: {len(error_codes)} | Codelists: {len(codelists)}")

if __name__ == "__main__":
    main()
