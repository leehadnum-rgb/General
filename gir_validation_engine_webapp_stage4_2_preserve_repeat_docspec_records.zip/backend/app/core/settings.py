from __future__ import annotations

from typing import Optional

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings.

    Notes:
    - Render provides Postgres URLs like: postgresql://... (or postgres://...)
      whereas SQLAlchemy with psycopg expects: postgresql+psycopg://...
      We normalize automatically.
    - For local Docker, CONFIG_ROOT defaults to /app/config.
    """

    model_config = SettingsConfigDict(env_file=None, extra="ignore")

    database_url: str = Field(..., alias="DATABASE_URL")
    config_root: str = Field("/app/config", alias="CONFIG_ROOT")

    # Optional API key (if set, enforced via X-API-Key header).
    api_key: Optional[str] = Field(default=None, alias="GIR_API_KEY")

    # CORS allowlist for browser-based front ends (Anything.com, etc.).
    # Use "*" for MVP; for production provide a comma-separated list.
    cors_allow_origins: str = Field(default="*", alias="CORS_ALLOW_ORIGINS")

    @field_validator("database_url", mode="before")
    @classmethod
    def normalize_database_url(cls, v):
        if not isinstance(v, str):
            return v
        if v.startswith("postgresql://"):
            return v.replace("postgresql://", "postgresql+psycopg://", 1)
        if v.startswith("postgres://"):
            return v.replace("postgres://", "postgresql+psycopg://", 1)
        return v


settings = Settings()
