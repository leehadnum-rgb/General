from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from datetime import datetime
from typing import Optional

from app.db.session import get_db
from app.db import models
from app.api.schemas import (
    ValidationRunCreate,
    ValidationRunRead,
    ValidationIssueQueryResult,
    ValidationIssueRead,
)
from app.services.config_loader import load_config
from app.services.validation_engine import run_validations
from app.core.settings import settings

router = APIRouter(prefix="/filings/{filing_id}", tags=["validation"])


def _ensure_filing(db: Session, filing_id: str) -> models.Filing:
    filing = db.get(models.Filing, filing_id)
    if filing is None:
        raise HTTPException(status_code=404, detail="Filing not found")
    return filing


def _issue_counts(db: Session, run_id: str) -> dict:
    q = db.query(models.ValidationIssue).filter(models.ValidationIssue.validation_run_id == run_id)
    total = q.count()
    blocking = q.filter(models.ValidationIssue.severity == "BLOCKING").count()
    warning = q.filter(models.ValidationIssue.severity == "WARNING").count()
    info = q.filter(models.ValidationIssue.severity == "INFO").count()
    return {
        "total_issues": total,
        "blocking_issues": blocking,
        "warning_issues": warning,
        "info_issues": info,
    }


@router.post("/validation-runs", response_model=ValidationRunRead)
def create_validation_run(
    filing_id: str,
    payload: ValidationRunCreate,
    db: Session = Depends(get_db),
):
    filing = _ensure_filing(db, filing_id)

    # Validate that the referenced config can be loaded.
    try:
        config = load_config(settings.config_root, filing.config_version_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Cannot load config: {e}")

    run = models.ValidationRun(
        filing_id=filing_id,
        config_version_id=filing.config_version_id,
        status="running",
        started_at=datetime.utcnow(),
        message=payload.notes,
    )
    db.add(run)
    db.commit()
    db.refresh(run)

    try:
        issues = run_validations(db, filing_id=filing_id, config=config)

        # Persist issues
        for iss in issues:
            db.add(models.ValidationIssue(
                validation_run_id=run.id,
                severity=iss.severity,
                rule_id=iss.rule_id,
                error_number=iss.error_number,
                section=iss.section,
                xml_path=iss.xml_path,
                message=iss.message,
                how_to_fix=iss.how_to_fix,
                filer_code=iss.filer_code,
                jurisdiction_code=iss.jurisdiction_code,
                entity_code=iss.entity_code,
                context_key=iss.context_key,
                created_at=datetime.utcnow(),
            ))

        run.status = "completed"
        run.completed_at = datetime.utcnow()

        counts = {
            "BLOCKING": sum(1 for x in issues if x.severity == "BLOCKING"),
            "WARNING": sum(1 for x in issues if x.severity == "WARNING"),
            "INFO": sum(1 for x in issues if x.severity == "INFO"),
            "TOTAL": len(issues),
        }
        run.message = (run.message or "") + (
            f"\nSprint 1.2: validation completed. "
            f"Total={counts['TOTAL']}, Blocking={counts['BLOCKING']}, Warning={counts['WARNING']}, Info={counts['INFO']}."
        )

        db.add(run)
        db.commit()
        db.refresh(run)

        return {
            "id": run.id,
            "filing_id": run.filing_id,
            "config_version_id": run.config_version_id,
            "status": run.status,
            "started_at": run.started_at,
            "completed_at": run.completed_at,
            "message": run.message,
            "total_issues": counts["TOTAL"],
            "blocking_issues": counts["BLOCKING"],
            "warning_issues": counts["WARNING"],
            "info_issues": counts["INFO"],
        }

    except Exception as e:
        run.status = "failed"
        run.completed_at = datetime.utcnow()
        run.message = f"Sprint 1.2: validation failed: {e}"
        db.add(run)
        db.commit()
        raise


@router.get("/validation-runs/{run_id}", response_model=ValidationRunRead)
def get_validation_run(filing_id: str, run_id: str, db: Session = Depends(get_db)):
    _ensure_filing(db, filing_id)
    run = db.get(models.ValidationRun, run_id)
    if run is None or run.filing_id != filing_id:
        raise HTTPException(status_code=404, detail="Validation run not found")

    counts = _issue_counts(db, run_id)
    return {
        "id": run.id,
        "filing_id": run.filing_id,
        "config_version_id": run.config_version_id,
        "status": run.status,
        "started_at": run.started_at,
        "completed_at": run.completed_at,
        "message": run.message,
        **counts,
    }


@router.get("/validation-runs/{run_id}/issues", response_model=ValidationIssueQueryResult)
def list_validation_issues(
    filing_id: str,
    run_id: str,
    severity: Optional[str] = Query(default=None, description="Filter by severity: BLOCKING/WARNING/INFO"),
    limit: int = Query(default=2000, ge=1, le=20000),
    offset: int = Query(default=0, ge=0),
    db: Session = Depends(get_db),
):
    _ensure_filing(db, filing_id)
    run = db.get(models.ValidationRun, run_id)
    if run is None or run.filing_id != filing_id:
        raise HTTPException(status_code=404, detail="Validation run not found")

    q = db.query(models.ValidationIssue).filter(models.ValidationIssue.validation_run_id == run_id)
    if severity:
        q = q.filter(models.ValidationIssue.severity == severity)

    rows = (
        q.order_by(models.ValidationIssue.severity.asc(), models.ValidationIssue.section.asc(), models.ValidationIssue.xml_path.asc())
        .offset(offset)
        .limit(limit)
        .all()
    )

    
    # OECD code catalogue lookup (Stage 0): attach OECD metadata for any issues that already carry `error_number`.
    oecd_map = {}
    try:
        cfg = load_config(settings.config_root, run.config_version_id)
        oecd_map = {int(ec.number): ec.model_dump() for ec in (cfg.error_codes or [])}
    except Exception:
        # Non-fatal: issues can still be returned without OECD metadata.
        oecd_map = {}

    items = [
        ValidationIssueRead(
            id=r.id,
            validation_run_id=r.validation_run_id,
            severity=r.severity,
            rule_id=r.rule_id,
            error_number=int(r.error_number) if r.error_number is not None else None,
            oecd=oecd_map.get(int(r.error_number)) if r.error_number is not None else None,
            section=r.section,
            xml_path=r.xml_path,
            message=r.message,
            how_to_fix=r.how_to_fix,
            filer_code=r.filer_code,
            jurisdiction_code=r.jurisdiction_code,
            entity_code=r.entity_code,
            context_key=r.context_key,
            created_at=r.created_at,
        )
        for r in rows
    ]

    return ValidationIssueQueryResult(count=len(items), items=items)
