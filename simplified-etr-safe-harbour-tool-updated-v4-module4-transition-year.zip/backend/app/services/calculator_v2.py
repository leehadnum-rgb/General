from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Dict, Any, Optional

from app.services.models import CalculationRequest as CalculationRequestV1
from app.services.models import JurisdictionInput as JurisdictionInputV1
from app.services.models import EntityInput as EntityInputV1
from app.services.models import TraceLine

from app.services.calculator import calculate as calculate_v1
from app.services.election_catalog import ELECTIONS_BY_CODE
from app.services.elections_v2 import (
    resolve_effective_elections,
    apply_effective_elections_to_meta,
    get_effective_election_amount,
    get_effective_election_bool,
)
from app.services.models_v2 import (
    CalculationRequestV2,
    CalculationResponseV2,
    TestedJurisdictionResultV2,
    CarryforwardBalanceV2,
    CarryforwardMovementV2,
    TestedJurisdictionInputV2,
    CrossBorderTaxItemV2,
    AmountScale,
)


def _scale_multiplier(scale: Optional[AmountScale]) -> float:
    if not scale or scale == "UNITS":
        return 1.0
    if scale == "THOUSANDS":
        return 1000.0
    if scale == "MILLIONS":
        return 1000000.0
    return 1.0


def _convert_nested_amounts(obj: Any, *, multiplier: float, skip_keys: set[str]) -> Any:
    """Recursively multiply numeric values by multiplier.

    Used for amount scale + currency translation pre-processing.
    Conservative rules:
      - booleans are not modified
      - keys in skip_keys are not modified (e.g., accounted_tax_rate)
    """

    if obj is None:
        return None
    if isinstance(obj, bool):
        return obj
    if isinstance(obj, (int, float)):
        return float(obj) * multiplier
    if isinstance(obj, list):
        return [_convert_nested_amounts(v, multiplier=multiplier, skip_keys=skip_keys) for v in obj]
    if isinstance(obj, dict):
        out: dict[str, Any] = {}
        for k, v in obj.items():
            if k in skip_keys:
                out[k] = v
            else:
                out[k] = _convert_nested_amounts(v, multiplier=multiplier, skip_keys=skip_keys)
        return out
    return obj


def _fx_lookup_avg(req: CalculationRequestV2, currency: str, fy_start: date) -> Optional[float]:
    """Find average FX rate (P&L translation convention).

    Matching priority:
      1) exact currency + fiscal_year_start
      2) currency + fiscal_year_start=None (default)
    """

    cur = (currency or "").upper().strip()
    if not cur:
        return None
    for r in (req.fx_rates or []):
        if (r.currency or "").upper().strip() == cur and r.fiscal_year_start == fy_start:
            return float(r.avg_rate_to_reporting)
    for r in (req.fx_rates or []):
        if (r.currency or "").upper().strip() == cur and r.fiscal_year_start is None:
            return float(r.avg_rate_to_reporting)
    return None


def _fx_lookup_spot(req: CalculationRequestV2, currency: str, fy_start: date) -> Optional[float]:
    """Find spot/closing FX rate (balance sheet translation convention).

    Matching priority matches average FX lookup.
    """

    cur = (currency or "").upper().strip()
    if not cur:
        return None
    for r in (req.fx_rates or []):
        if (r.currency or "").upper().strip() == cur and r.fiscal_year_start == fy_start:
            return float(r.spot_rate_to_reporting) if r.spot_rate_to_reporting is not None else None
    for r in (req.fx_rates or []):
        if (r.currency or "").upper().strip() == cur and r.fiscal_year_start is None:
            return float(r.spot_rate_to_reporting) if r.spot_rate_to_reporting is not None else None
    return None

def _convert_amount_fx(
    req: CalculationRequestV2,
    *,
    amount: float,
    currency: Optional[str],
    amount_scale: Optional[str],
    reporting_currency: Optional[str],
    fy_start: date,
    use_spot: bool,
) -> tuple[float, Optional[str]]:
    """Convert an amount into reporting currency, applying scaling and FX.

    Returns (converted_amount, note) where note describes any fallback behaviour.

    FX conventions:
      - use_spot=True -> spot/closing FX (balance sheet translation)
      - use_spot=False -> average FX (P&L translation)
    """

    mult = _scale_multiplier(amount_scale)
    amt = float(amount) * float(mult)

    if not (reporting_currency and currency):
        return float(amt), None

    cur = str(currency).upper().strip() or None
    rep = str(reporting_currency).upper().strip() or None
    if not cur or not rep or cur == rep:
        return float(amt), None

    note = None
    if use_spot:
        fx = _fx_lookup_spot(req, cur, fy_start)
        if fx is None:
            fx2 = _fx_lookup_avg(req, cur, fy_start)
            if fx2 is None:
                raise ValueError(
                    f"Missing FX rate for currency '{cur}' to reporting currency '{rep}' for FY start {fy_start}. "
                    "Provide request.fx_rates with avg_rate_to_reporting (and optionally spot_rate_to_reporting)."
                )
            fx = fx2
            note = f"Spot FX missing for {cur}; used avg FX {fx2} as fallback."
        return float(amt) * float(fx), note

    fx = _fx_lookup_avg(req, cur, fy_start)
    if fx is None:
        raise ValueError(
            f"Missing FX rate for currency '{cur}' to reporting currency '{rep}' for FY start {fy_start}. "
            "Provide request.fx_rates with avg_rate_to_reporting."
        )
    return float(amt) * float(fx), note



@dataclass
class _TJWork:
    tj: TestedJurisdictionInputV2
    bucket_id: str
    reporting_currency: Optional[str]
    input_currency: Optional[str]
    fx_rate_avg: float
    fx_rate_spot: float
    amount_scale: Optional[str]
    currency_multiplier_pl: float
    currency_multiplier_bs: float
    spot_rate_provided: bool
    effective_elections: list
    eligible: bool
    ineligibility_reasons: list[str]
    election_records: list
    trace: list[TraceLine]
    simplified_income: float
    simplified_taxes: float
    opening_balances: list[CarryforwardBalanceV2]


def _convert_carryforwards(
    req: CalculationRequestV2,
    opening: list[CarryforwardBalanceV2],
    *,
    reporting_currency: Optional[str],
    input_currency: Optional[str],
    scale_multiplier: float,
    fy_start: date,
) -> tuple[list[CarryforwardBalanceV2], list[TraceLine]]:
    """Convert carryforward balances into reporting currency (and apply amount scale).

    v4 module 3 enhancement:
    - If a carryforward balance includes origin_fiscal_year_start, translate that balance using
      the average FX rate for the origin fiscal year (if available).
    - Otherwise translate using the current fiscal year's average FX rate.

    This is a pragmatic approximation of the OECD requirement that currency translation rules apply.
    """

    if not opening:
        return [], []

    needs_fx = bool(reporting_currency and input_currency and input_currency != reporting_currency)
    input_currency_u = (input_currency or "").upper().strip() or None

    out: list[CarryforwardBalanceV2] = []
    trace: list[TraceLine] = []

    used_origin_years: list[str] = []
    fx_fallbacks: list[str] = []

    for b in (opening or []):
        origin_fy = b.origin_fiscal_year_start or fy_start
        fx_avg = 1.0
        if needs_fx:
            r = _fx_lookup_avg(req, input_currency_u, origin_fy)
            if r is None:
                # Fallback to current FY rate if origin-year rate is not provided
                r2 = _fx_lookup_avg(req, input_currency_u, fy_start)
                if r2 is None:
                    raise ValueError(
                        f"Missing FX rate for currency '{input_currency_u}' to reporting currency '{reporting_currency}' for carryforward translation. "
                        f"Provide request.fx_rates with avg_rate_to_reporting (currency={input_currency_u})."
                    )
                fx_avg = float(r2)
                if b.origin_fiscal_year_start is not None and b.origin_fiscal_year_start != fy_start:
                    fx_fallbacks.append(f"{b.kind}@{b.origin_fiscal_year_start}")
            else:
                fx_avg = float(r)

        mult = float(scale_multiplier) * float(fx_avg)
        if mult == 1.0:
            out.append(b.model_copy())
            continue

        updates: dict[str, Any] = {"amount": float(b.amount) * mult}
        if b.remaining_amount is not None:
            updates["remaining_amount"] = float(b.remaining_amount) * mult
        out.append(b.model_copy(update=updates))

        if b.origin_fiscal_year_start is not None and b.origin_fiscal_year_start != fy_start:
            used_origin_years.append(f"{b.kind}@{b.origin_fiscal_year_start}")

    if used_origin_years:
        trace.append(
            TraceLine(
                section="eligibility",
                step="Carryforward translated using origin-year FX",
                amount=0.0,
                note=(
                    f"Applied avg FX translation for carryforward balances using their origin_fiscal_year_start where provided. "
                    f"Examples: {', '.join(used_origin_years[:6])}" + ("" if len(used_origin_years) <= 6 else f" (+{len(used_origin_years)-6} more)")
                ),
            )
        )

    if fx_fallbacks:
        trace.append(
            TraceLine(
                section="eligibility",
                step="Carryforward FX fallback used",
                amount=0.0,
                note=(
                    "No origin-year FX rate was provided for some carryforward balances; the current fiscal year's avg FX rate was used as a fallback. "
                    f"Examples: {', '.join(fx_fallbacks[:6])}" + ("" if len(fx_fallbacks) <= 6 else f" (+{len(fx_fallbacks)-6} more)")
                ),
            )
        )

    return out, trace


def _build_meta_row(
    tj: TestedJurisdictionInputV2,
    bucket_id: str,
    fy_start: date,
    *,
    currency_multiplier_pl: float,
    reporting_currency: Optional[str],
    input_currency: Optional[str],
    fx_rate_avg: float,
    fx_rate_spot: float,
    spot_rate_provided: bool,
    amount_scale: Optional[str],
) -> tuple[JurisdictionInputV1, list, list[TraceLine], list[TraceLine]]:
    """Build a v1 JurisdictionInput row used as calculation row (jurisdiction mode)
    or as 'meta' row (entity roll-up mode)."""

    conversion_trace: list[TraceLine] = []

    if reporting_currency and input_currency and input_currency != reporting_currency and fx_rate_avg != 1.0:
        conversion_trace.append(
            TraceLine(
                section="eligibility",
                step="Currency translated to reporting currency",
                amount=0.0,
                note=(
                    f"{input_currency} -> {reporting_currency} at avg FX rate {fx_rate_avg} (P&L). "
                    + (
                        f"Spot FX rate {fx_rate_spot} (balance sheet)."
                        if spot_rate_provided
                        else "Spot FX rate not provided; avg used as fallback for balance sheet items."
                    )
                ),
            )
        )
    if amount_scale and amount_scale != "UNITS" and currency_multiplier_pl != 1.0:
        conversion_trace.append(
            TraceLine(
                section="eligibility",
                step="Amount scale normalised",
                amount=0.0,
                note=f"Input scale={amount_scale}. Amounts multiplied by {_scale_multiplier(amount_scale)} before FX.",
            )
        )

    if tj.facts is not None:
        data = tj.facts.model_dump()
        # Apply amount scale + FX conversion to monetary fields
        if currency_multiplier_pl != 1.0:
            data = _convert_nested_amounts(data, multiplier=currency_multiplier_pl, skip_keys={"accounted_tax_rate"})
        # v2 uses tested_jurisdiction_id as the internal key (bucket)
        data["jurisdiction_code"] = bucket_id
        meta = JurisdictionInputV1(**data)
    else:
        # For entity roll-up, a minimal meta row is still useful to carry elections and eligibility flags.
        meta = JurisdictionInputV1(jurisdiction_code=bucket_id, jpbt=0.0)

    # Eligibility flags from v2
    ei = tj.eligibility_inputs
    meta.ineligible_stateless = bool(ei.ineligible_stateless)
    meta.ineligible_investment_entity = bool(ei.ineligible_investment_entity)
    meta.ineligible_article7_3_outstanding_recapture = bool(ei.ineligible_article7_3_outstanding_recapture)
    meta.stateless_exception_section_6_2_applies = bool(ei.stateless_exception_section_6_2_applies)
    meta.investment_entity_tax_transparency_election_applies = bool(ei.investment_entity_tax_transparency_election_applies)
    meta.no_topup_tax_in_prior_24_months = bool(ei.no_topup_tax_in_prior_24_months)
    meta.reentry_no_topup_tax_in_prior_24_months = ei.reentry_no_topup_tax_in_prior_24_months
    meta.integrity_rules_satisfied = bool(ei.integrity_rules_satisfied)

    # Resolve and apply elections for this FY
    effective = resolve_effective_elections(tj.elections, fy_start)

    # Convert amount-valued elections into reporting currency so they line up with translated facts.
    if currency_multiplier_pl != 1.0:
        converted_effective = []
        for e in effective:
            if getattr(e, "action", "ELECT") == "REVOKE":
                converted_effective.append(e)
                continue
            if getattr(e, "value_type", None) == "amount" and getattr(e, "amount", None) is not None:
                converted_effective.append(e.model_copy(update={"amount": float(e.amount) * currency_multiplier_pl}))
            else:
                converted_effective.append(e)
        effective = converted_effective
    meta, election_trace = apply_effective_elections_to_meta(meta, effective)

    return meta, effective, election_trace, conversion_trace


def _build_entities(tj: TestedJurisdictionInputV2, bucket_id: str, *, currency_multiplier_pl: float) -> list[EntityInputV1]:
    ents: list[EntityInputV1] = []
    for e in tj.entities:
        data = e.model_dump()
        if currency_multiplier_pl != 1.0:
            data = _convert_nested_amounts(data, multiplier=currency_multiplier_pl, skip_keys={"accounted_tax_rate"})
        # Override group key
        data["jurisdiction_code"] = bucket_id
        ents.append(EntityInputV1(**data))
    return ents


def _normalise_balances(opening: list[CarryforwardBalanceV2]) -> list[CarryforwardBalanceV2]:
    # Ensure positive amounts and defaults are applied (Pydantic validator already does this).
    out: list[CarryforwardBalanceV2] = []
    for b in opening:
        out.append(b.model_copy())
    return out


def _apply_carryforwards(
    *,
    fy_start: date,
    minimum_rate: float,
    simplified_income: float,
    simplified_taxes: float,
    opening: list[CarryforwardBalanceV2],
    effective_elections: list,
    trace: list[TraceLine],
) -> tuple[float, list[CarryforwardBalanceV2], list[CarryforwardMovementV2]]:
    """Apply carryforwards to Simplified Taxes (OECD Box 4.3 and Article 4.1.5 symmetry).

    Implementation notes (pragmatic):
    - Carryforward balances are entered as POSITIVE amounts representing a reduction to Simplified Taxes.
    - Utilisation is only applied in years with positive Simplified Income and positive Simplified Taxes,
      consistent with typical utilisation mechanics for Excess Negative Tax carry-forwards.
    - Tax is not reduced below zero.
    - Loss DTA Adjustment utilisation can optionally be capped by LOSS_DTA_REVERSAL_TENTATIVE_AMOUNT.
    """

    taxes = float(simplified_taxes)
    balances = _normalise_balances(opening)
    moves: list[CarryforwardMovementV2] = []

    if simplified_income <= 0 or taxes <= 0:
        return taxes, balances, moves

    # Optional cap for Loss DTA Adjustment utilisation
    loss_dta_reversal_cap = get_effective_election_amount(effective_elections, "LOSS_DTA_REVERSAL_TENTATIVE_AMOUNT")
    if loss_dta_reversal_cap is not None:
        loss_dta_reversal_cap = max(0.0, float(loss_dta_reversal_cap))

    def use_balance(kind: str, cap_amount: float | None = None, note: str | None = None):
        nonlocal taxes, balances, moves, loss_dta_reversal_cap

        for b in balances:
            if b.kind != kind:
                continue
            if taxes <= 0:
                break
            if (b.remaining_amount or 0.0) <= 0:
                continue

            cap = taxes
            if cap_amount is not None:
                cap = min(cap, cap_amount)
            used = min(float(b.remaining_amount or 0.0), cap)

            if used <= 0:
                continue

            taxes = max(0.0, taxes - used)
            b.remaining_amount = max(0.0, float(b.remaining_amount or 0.0) - used)

            if kind == "LOSS_DTA_ADJUSTMENT" and loss_dta_reversal_cap is not None:
                loss_dta_reversal_cap = max(0.0, loss_dta_reversal_cap - used)

            moves.append(
                CarryforwardMovementV2(
                    kind=kind, used_amount=float(used), remaining_amount=float(b.remaining_amount or 0.0), note=note
                )
            )
            trace.append(
                TraceLine(
                    section="tax",
                    step=f"Carryforward utilised: {kind}",
                    amount=-float(used),
                    running_total=taxes,
                    note=note,
                )
            )

    # Order (pragmatic):
    #   1) Loss DTA Adjustment (alternative method; can be capped)
    #   2) Simplified negative tax adjustment (Box 4.3)
    #   3) Excess negative tax carry-forward (GloBE Article 4.1.5)
    if loss_dta_reversal_cap is not None and loss_dta_reversal_cap > 0:
        use_balance(
            "LOSS_DTA_ADJUSTMENT",
            cap_amount=loss_dta_reversal_cap,
            note="Capped by LOSS_DTA_REVERSAL_TENTATIVE_AMOUNT; taxes not reduced below zero.",
        )
    else:
        use_balance(
            "LOSS_DTA_ADJUSTMENT",
            cap_amount=None,
            note="No loss DTA reversal cap provided; taxes not reduced below zero.",
        )

    use_balance(
        "SIMPLIFIED_NEGATIVE_TAX_ADJUSTMENT",
        cap_amount=None,
        note="Applied as a reduction to Simplified Taxes; taxes not reduced below zero.",
    )
    use_balance(
        "EXCESS_NEGATIVE_TAX_CARRYFORWARD",
        cap_amount=None,
        note="Applied as a reduction to Simplified Taxes; taxes not reduced below zero.",
    )

    return taxes, balances, moves
def _apply_owner_addbacks(work: _TJWork) -> None:
    """Apply structured owner addbacks (Articles 7.5/7.6).

    These are treated as signed adjustments to Simplified Income or Simplified Taxes.
    """

    for a in (work.tj.owner_addbacks or []):
        amt = float(a.amount) * float(work.currency_multiplier_pl or 1.0)
        if a.kind == "income":
            work.simplified_income += amt
            work.trace.append(
                TraceLine(
                    section="income",
                    step=f"Investment entity owner addback (Art {a.article})",
                    amount=float(amt),
                    running_total=float(work.simplified_income),
                    note=a.label + (f" | {a.note}" if a.note else ""),
                )
            )
        else:
            work.simplified_taxes += amt
            work.trace.append(
                TraceLine(
                    section="tax",
                    step=f"Investment entity owner addback (Art {a.article})",
                    amount=float(amt),
                    running_total=float(work.simplified_taxes),
                    note=a.label + (f" | {a.note}" if a.note else ""),
                )
            )


def _apply_cross_border_tax_items(
    works: Dict[str, _TJWork],
    items: list[CrossBorderTaxItemV2],
    fy_start: date,
) -> None:
    """Apply cross-border tax item exclusion/allocation adjustments.

    The adjustments are applied after base Simplified Taxes have been computed, but before
    carryforwards, so they affect Simplified ETR.
    """

    if not items:
        return

    # Helper: check deemed-zero conflicts
    deemed_zero_ids = {k for k, w in works.items() if w.tj.deemed_zero_rules.apply_deemed_zero}

    for item in items:
        src = item.source_tested_jurisdiction_id
        tgt = item.target_tested_jurisdiction_id

        # Validate IDs
        if src and src not in works:
            raise ValueError(f"Cross-border tax item '{item.label or item.item_id or ''}': source_tested_jurisdiction_id '{src}' not found.")
        if tgt and tgt not in works:
            raise ValueError(f"Cross-border tax item '{item.label or item.item_id or ''}': target_tested_jurisdiction_id '{tgt}' not found.")

        if src in deemed_zero_ids or tgt in deemed_zero_ids:
            raise ValueError(
                "Cross-border tax items cannot reference a Tested Jurisdiction where deemed-zero is applied. "
                f"(item={item.label or item.item_id or 'unnamed'}, source={src}, target={tgt})"
            )

        amount = float(item.amount)

        # Infer default treatment if not provided
        treatment = item.treatment
        if not treatment:
            if tgt:
                treatment = "ALLOCATE"
            else:
                keep = False
                if src:
                    keep = bool(get_effective_election_bool(works[src].effective_elections, "CROSS_BORDER_FIVE_YEAR_ELECTION_KEEP_ALLOCABLE_TAXES") or False)
                treatment = "KEEP_IN_SOURCE" if keep else "EXCLUDE_FROM_ALL"

        # PE election enforcement (if requested)
        if getattr(item, "requires_pe_simplification_election", False):
            pe_ok = False
            if src and bool(get_effective_election_bool(works[src].effective_elections, "PE_SIMPLIFICATION_ELECTION_NOTE") or False):
                pe_ok = True
            if tgt and bool(get_effective_election_bool(works[tgt].effective_elections, "PE_SIMPLIFICATION_ELECTION_NOTE") or False):
                pe_ok = True
            if not pe_ok:
                raise ValueError(
                    "Cross-border tax item requires PE simplification election, but PE_SIMPLIFICATION_ELECTION_NOTE is not effective "
                    f"for source/target Tested Jurisdiction(s). (item={item.label or item.item_id or 'unnamed'})"
                )

        label = item.label or item.item_id or "Cross-border tax item"
        note = item.note

        if treatment == "KEEP_IN_SOURCE":
            if src:
                works[src].trace.append(
                    TraceLine(
                        section="tax",
                        step="Cross-border tax item kept in source",
                        amount=0.0,
                        running_total=float(works[src].simplified_taxes),
                        note=f"{label}" + (f" | {note}" if note else ""),
                    )
                )
            continue

        if treatment == "EXCLUDE_FROM_ALL":
            if not src:
                # nothing to exclude if no source provided
                continue
            w = works[src]
            w.simplified_taxes -= amount
            w.trace.append(
                TraceLine(
                    section="tax",
                    step="Cross-border tax excluded (allocable tax removed)",
                    amount=-amount,
                    running_total=float(w.simplified_taxes),
                    note=f"{label}" + (f" | {note}" if note else ""),
                )
            )
            continue

        if treatment == "ALLOCATE":
            if tgt is None:
                raise ValueError(f"Cross-border tax item '{label}': treatment='ALLOCATE' requires target_tested_jurisdiction_id.")

            if src:
                ws = works[src]
                ws.simplified_taxes -= amount
                ws.trace.append(
                    TraceLine(
                        section="tax",
                        step="Cross-border tax allocated out of source",
                        amount=-amount,
                        running_total=float(ws.simplified_taxes),
                        note=f"{label} -> {tgt}" + (f" | {note}" if note else ""),
                    )
                )

            wt = works[tgt]
            wt.simplified_taxes += amount
            wt.trace.append(
                TraceLine(
                    section="tax",
                    step="Cross-border tax allocated into target",
                    amount=amount,
                    running_total=float(wt.simplified_taxes),
                    note=f"{label} (from {src or 'external'})" + (f" | {note}" if note else ""),
                )
            )
            continue

        raise ValueError(f"Cross-border tax item '{label}': unknown treatment '{treatment}'.")




def _convert_amount_with_fx(
    req: CalculationRequestV2,
    *,
    amount: float,
    currency: Optional[str],
    amount_scale: Optional[AmountScale],
    fy_start: date,
    reporting_currency: Optional[str],
    use_spot: bool,
) -> tuple[float, Optional[str]]:
    """Convert a monetary amount into the reporting currency.

    Returns (converted_amount, note).
    - Applies amount_scale first
    - Applies FX translation only when reporting_currency and currency differ
    - Uses spot FX for balance-sheet items when available; otherwise falls back to avg FX.
    """

    mult = float(_scale_multiplier(amount_scale))
    amt = float(amount) * mult

    cur = (currency or "").upper().strip() or None
    rep = (reporting_currency or "").upper().strip() or None

    if not rep or not cur or cur == rep:
        return amt, None

    if use_spot:
        fx = _fx_lookup_spot(req, cur, fy_start)
        if fx is not None:
            return amt * float(fx), f"FX spot {cur}->{rep}={fx}"
        fx2 = _fx_lookup_avg(req, cur, fy_start)
        if fx2 is None:
            raise ValueError(
                f"Missing FX rate for currency '{cur}' to reporting currency '{rep}' for FY start {fy_start}. "
                "Provide request.fx_rates with avg_rate_to_reporting and (optionally) spot_rate_to_reporting."
            )
        return amt * float(fx2), f"FX spot missing; used avg {cur}->{rep}={fx2}"

    fx = _fx_lookup_avg(req, cur, fy_start)
    if fx is None:
        raise ValueError(
            f"Missing FX rate for currency '{cur}' to reporting currency '{rep}' for FY start {fy_start}. "
            "Provide request.fx_rates with avg_rate_to_reporting."
        )
    return amt * float(fx), f"FX avg {cur}->{rep}={fx}"


def _apply_transition_year_adjustments(
    work: _TJWork,
    req: CalculationRequestV2,
    *,
    fy_start: date,
    minimum_rate: float,
) -> None:
    """Apply Transition Year rules (Box 4.5) to a Tested Jurisdiction.

    Implemented in v4 Module 4:
      - Structured handling of Article 9.1.2 disallowed opening DTAs (Transition Year only)
      - Structured net adjustments for Article 9.1.3 transfers (Transition Year and post-Transition years)
      - First real use of balance-sheet FX translation (spot rate) for opening DTAs/DTLs

    Notes:
      - This tool is stateless; it cannot infer Transition Year from multi-year history.
        The user must provide transition_year.transition_year_fy_start.
      - Where transition_year is provided but the date is omitted, the tool assumes the current
        fiscal year is the Transition Year and records this in trace.
    """

    ty = getattr(work.tj, "transition_year", None)
    if ty is None:
        return

    ty_start = getattr(ty, "transition_year_fy_start", None) or fy_start
    if getattr(ty, "transition_year_fy_start", None) is None:
        work.trace.append(
            TraceLine(
                section="eligibility",
                step="Transition Year start date assumed",
                amount=0.0,
                note=(
                    "transition_year.transition_year_fy_start was not provided; assuming the request fiscal year is the Transition Year for this Tested Jurisdiction."
                ),
            )
        )

    if fy_start < ty_start:
        status = "pre-Transition Year"
    elif fy_start == ty_start:
        status = "Transition Year"
    else:
        status = "post-Transition Year"

    work.trace.append(
        TraceLine(
            section="eligibility",
            step="Transition Year context (Box 4.5)",
            amount=0.0,
            note=f"Transition Year FY start={ty_start}. Current FY start={fy_start} => {status}.",
        )
    )

    # 1) Article 9.1.2 disallowed opening DTAs — applied in the Transition Year only.
    if fy_start == ty_start and getattr(ty, "opening_deferred_tax_items", None):
        for item in (ty.opening_deferred_tax_items or []):
            # Convert opening balance using balance-sheet translation convention (spot)
            cur = getattr(item, "currency", None) or work.input_currency or work.reporting_currency
            scale = getattr(item, "amount_scale", None)

            # If the user provided an amount already on a minimum-rate basis, we still treat it as a balance-sheet amount.
            base_amt = getattr(item, "opening_balance_at_minimum_rate", None)
            is_min_basis = base_amt is not None
            if base_amt is None:
                base_amt = float(getattr(item, "opening_balance", 0.0) or 0.0)

            converted, fx_note = _convert_amount_with_fx(
                req,
                amount=float(base_amt),
                currency=str(cur).upper().strip() if cur else None,
                amount_scale=scale,
                fy_start=fy_start,
                reporting_currency=work.reporting_currency,
                use_spot=True,
            )

            opening_min = float(converted)

            # If not already on a minimum-rate basis, apply a recast-down to Minimum Rate when tax_rate > minimum_rate.
            if not is_min_basis:
                tax_rate = getattr(item, "tax_rate", None)
                if tax_rate is None:
                    # Fallback: jurisdiction accounted tax rate (if supplied)
                    if work.tj.facts is not None and getattr(work.tj.facts, "accounted_tax_rate", None) is not None:
                        tax_rate = float(work.tj.facts.accounted_tax_rate)
                if tax_rate is not None and float(tax_rate) > 0 and float(tax_rate) > float(minimum_rate):
                    opening_min = float(opening_min) * (float(minimum_rate) / float(tax_rate))

            allowed_opening_min = float(opening_min)
            disallowed = bool(getattr(item, "disallowed_under_article_9_1_2", False))
            if getattr(item, "item_type", None) == "DTA" and disallowed:
                allowed_opening_min = 0.0

            adjustment = float(opening_min) - float(allowed_opening_min)

            if adjustment != 0.0:
                work.simplified_taxes += adjustment
                work.trace.append(
                    TraceLine(
                        section="tax",
                        step="Transition Year: disallowed opening DTA adjustment (Art 9.1.2)",
                        amount=float(adjustment),
                        running_total=float(work.simplified_taxes),
                        note=(
                            (item.label or item.item_id or "Opening deferred tax item")
                            + (" | " + fx_note if fx_note else "")
                        ),
                    )
                )
            else:
                # Keep a lightweight trace marker for audit, but avoid noise when no adjustment.
                if disallowed and getattr(item, "item_type", None) == "DTA":
                    work.trace.append(
                        TraceLine(
                            section="tax",
                            step="Transition Year: disallowed opening DTA (no adjustment computed)",
                            amount=0.0,
                            running_total=float(work.simplified_taxes),
                            note=(
                                (item.label or item.item_id or "Opening deferred tax item")
                                + " | opening amount treated as 0."
                                + (" | " + fx_note if fx_note else "")
                            ),
                        )
                    )

    # 2) Article 9.1.3 transfers — apply from Transition Year onwards (fy_start >= ty_start).
    if fy_start >= ty_start and getattr(ty, "article_9_1_3_transfers", None):
        for tr in (ty.article_9_1_3_transfers or []):
            cur = getattr(tr, "currency", None) or work.input_currency or work.reporting_currency
            scale = getattr(tr, "amount_scale", None)

            inc_adj, fx_note_i = _convert_amount_with_fx(
                req,
                amount=float(getattr(tr, "income_adjustment", 0.0) or 0.0),
                currency=str(cur).upper().strip() if cur else None,
                amount_scale=scale,
                fy_start=fy_start,
                reporting_currency=work.reporting_currency,
                use_spot=False,
            )
            tax_adj, fx_note_t = _convert_amount_with_fx(
                req,
                amount=float(getattr(tr, "tax_adjustment", 0.0) or 0.0),
                currency=str(cur).upper().strip() if cur else None,
                amount_scale=scale,
                fy_start=fy_start,
                reporting_currency=work.reporting_currency,
                use_spot=False,
            )

            if inc_adj != 0.0:
                work.simplified_income += float(inc_adj)
                work.trace.append(
                    TraceLine(
                        section="income",
                        step="Article 9.1.3 transfer adjustment",
                        amount=float(inc_adj),
                        running_total=float(work.simplified_income),
                        note=(
                            (tr.label or tr.transfer_id or "Transfer")
                            + (" | " + fx_note_i if fx_note_i else "")
                            + (" | " + (tr.note or "") if tr.note else "")
                        ),
                    )
                )

            if tax_adj != 0.0:
                work.simplified_taxes += float(tax_adj)
                work.trace.append(
                    TraceLine(
                        section="tax",
                        step="Article 9.1.3 transfer adjustment",
                        amount=float(tax_adj),
                        running_total=float(work.simplified_taxes),
                        note=(
                            (tr.label or tr.transfer_id or "Transfer")
                            + (" | " + fx_note_t if fx_note_t else "")
                            + (" | " + (tr.note or "") if tr.note else "")
                        ),
                    )
                )
def calculate_v2(req: CalculationRequestV2) -> CalculationResponseV2:
    fy_start = req.fiscal_year.start_date

    reporting_currency: Optional[str] = None
    if req.group_profile and req.group_profile.reporting_currency:
        reporting_currency = str(req.group_profile.reporting_currency).upper().strip() or None

    # -----------------------------
    # First pass: compute base numbers per Tested Jurisdiction (pre cross-border / owner addbacks)
    # -----------------------------
    works: Dict[str, _TJWork] = {}
    for tj in req.tested_jurisdictions:
        bucket_id = tj.tested_jurisdiction_id

        # Currency translation / amount scaling (v4 module 2)
        basis = tj.accounting_basis
        input_currency = (basis.currency or reporting_currency)
        if input_currency is not None:
            input_currency = str(input_currency).upper().strip() or None
        amount_scale = basis.amount_scale
        scale_mult = _scale_multiplier(amount_scale)

        # FX translation conventions (v4 module 3)
        # - P&L items use average FX
        # - balance sheet items use spot/closing FX (when available; otherwise avg is used as a fallback)
        fx_avg = 1.0
        fx_spot = 1.0
        spot_provided = True
        if reporting_currency and input_currency and input_currency != reporting_currency:
            r_avg = _fx_lookup_avg(req, input_currency, fy_start)
            if r_avg is None:
                raise ValueError(
                    f"Missing FX rate for currency '{input_currency}' to reporting currency '{reporting_currency}' for FY start {fy_start}. "
                    "Provide request.fx_rates with avg_rate_to_reporting."
                )
            fx_avg = float(r_avg)
            r_spot = _fx_lookup_spot(req, input_currency, fy_start)
            if r_spot is None:
                # No spot provided; we keep going using avg as a fallback for balance sheet items.
                fx_spot = float(fx_avg)
                spot_provided = False
            else:
                fx_spot = float(r_spot)

        currency_multiplier_pl = float(scale_mult) * float(fx_avg)
        currency_multiplier_bs = float(scale_mult) * float(fx_spot)

        # Determine input mode
        m = tj.composition.aggregation_method
        if m == "JURISDICTION_FACTS":
            input_mode = "jurisdiction"
        elif m == "ENTITY_ROLLUP":
            input_mode = "entity_rollup"
        else:
            # MIXED: if entities exist, roll-up; else jurisdiction facts
            input_mode = "entity_rollup" if tj.entities else "jurisdiction"

        meta, effective_elections, election_trace, conversion_trace = _build_meta_row(
            tj,
            bucket_id,
            fy_start,
            currency_multiplier_pl=currency_multiplier_pl,
            reporting_currency=reporting_currency,
            input_currency=input_currency,
            fx_rate_avg=fx_avg,
            fx_rate_spot=fx_spot,
            spot_rate_provided=spot_provided,
            amount_scale=amount_scale,
        )
        entities = _build_entities(tj, bucket_id, currency_multiplier_pl=currency_multiplier_pl) if input_mode == "entity_rollup" else []

        req_v1 = CalculationRequestV1(
            fiscal_year_start_date=fy_start,
            minimum_rate=req.minimum_rate,
            input_mode=input_mode,
            apply_optional_2025_start_rule=req.applicability.apply_optional_2025_start_rule,
            early_start_qdmtt_safe_harbour_applies=req.applicability.early_start_qdmtt_safe_harbour_applies,
            early_start_only_one_jurisdiction_has_taxing_rights=req.applicability.early_start_only_one_jurisdiction_has_taxing_rights,
            early_start_all_taxing_rights_jurisdictions_allow=req.applicability.early_start_all_taxing_rights_jurisdictions_allow,
            jurisdictions=[meta],
            entities=entities,
        )

        base_resp = calculate_v1(req_v1)
        base_r = base_resp.results[0]

        opening_balances, carryforward_conversion_trace = _convert_carryforwards(
            req,
            tj.carryforwards_opening,
            reporting_currency=reporting_currency,
            input_currency=input_currency,
            scale_multiplier=float(scale_mult),
            fy_start=fy_start,
        )

        trace: list[TraceLine] = list(conversion_trace) + list(carryforward_conversion_trace) + list(base_r.trace) + list(election_trace)

        works[bucket_id] = _TJWork(
            tj=tj,
            bucket_id=bucket_id,
            reporting_currency=reporting_currency,
            input_currency=input_currency,
            fx_rate_avg=float(fx_avg),
            fx_rate_spot=float(fx_spot),
            amount_scale=str(amount_scale) if amount_scale is not None else None,
            currency_multiplier_pl=float(currency_multiplier_pl),
            currency_multiplier_bs=float(currency_multiplier_bs),
            spot_rate_provided=bool(spot_provided),
            effective_elections=effective_elections,
            eligible=bool(base_r.eligible),
            ineligibility_reasons=list(base_r.ineligibility_reasons),
            election_records=list(base_r.election_records),
            trace=trace,
            simplified_income=float(base_r.simplified_income),
            simplified_taxes=float(base_r.simplified_taxes),
            opening_balances=opening_balances,
        )

    # -----------------------------
    # Apply structured adjustments that can affect multiple TJs
    # -----------------------------
    for w in works.values():
        _apply_transition_year_adjustments(w, req, fy_start=fy_start, minimum_rate=req.minimum_rate)

    for w in works.values():
        _apply_owner_addbacks(w)

    # Normalise cross-border tax items (scale + optional FX translation)
    cb_items: list[CrossBorderTaxItemV2] = []
    for item in (req.cross_border_tax_items or []):
        amt = float(item.amount) * float(_scale_multiplier(getattr(item, "amount_scale", "UNITS")))
        cur = getattr(item, "currency", None)
        if reporting_currency and cur:
            cur_u = str(cur).upper().strip() or None
            if cur_u and cur_u != reporting_currency:
                r = _fx_lookup_avg(req, cur_u, fy_start)
                if r is None:
                    raise ValueError(
                        f"Missing FX rate for cross-border tax item currency '{cur_u}' to reporting currency '{reporting_currency}' for FY start {fy_start}. "
                        "Provide request.fx_rates with avg_rate_to_reporting or omit currency to indicate the amount is already in reporting currency."
                    )
                amt = amt * float(r)
        cb_items.append(item.model_copy(update={"amount": float(amt)}))

    _apply_cross_border_tax_items(works, cb_items, fy_start)

    # -----------------------------
    # Final pass: carryforwards + deemed-zero + compute outcomes
    # -----------------------------
    results: list[TestedJurisdictionResultV2] = []

    # Preserve request ordering
    for tj in req.tested_jurisdictions:
        bucket_id = tj.tested_jurisdiction_id
        w = works[bucket_id]

        trace = w.trace

        # Deemed-zero override (only if eligible)
        if tj.deemed_zero_rules.apply_deemed_zero:
            trace.append(
                TraceLine(
                    section="eligibility",
                    step="Deemed-zero rule applied",
                    amount=0.0,
                    note=tj.deemed_zero_rules.rationale or "Simplified Income and Simplified Taxes treated as zero.",
                )
            )
            if w.eligible:
                results.append(
                    TestedJurisdictionResultV2(
                        tested_jurisdiction_id=bucket_id,
                        jurisdiction_code=tj.jurisdiction_code,
                        label=tj.label,
                        transition_year_fy_start=(tj.transition_year.transition_year_fy_start or fy_start) if tj.transition_year else None,
                        is_transition_year=(fy_start == (tj.transition_year.transition_year_fy_start or fy_start)) if tj.transition_year else None,
                        eligible=True,
                        ineligibility_reasons=[],
                        simplified_income=0.0,
                        simplified_taxes=0.0,
                        simplified_etr=None,
                        simplified_loss=0.0,
                        safe_harbour_applies=True,
                        safe_harbour_reason="PASS: deemed-zero rule applies.",
                        simplified_adjustment_for_negative_taxes=0.0,
                        effective_elections=w.effective_elections,
                        election_records=list(w.election_records),
                        trace=trace,
                        carryforwards_opening=w.opening_balances,
                        carryforward_movements=[],
                        carryforwards_closing=w.opening_balances,
                    )
                )
                continue
            # If not eligible, fall through with normal numbers but explain.
            trace.append(
                TraceLine(
                    section="eligibility",
                    step="Deemed-zero requested but eligibility failed",
                    amount=0.0,
                    note="Safe harbour is not available where eligibility restrictions are not met.",
                )
            )

        # Apply carryforwards to taxes (after cross-border / addbacks)
        taxes_after_cf, balances_after, movements = _apply_carryforwards(
            fy_start=fy_start,
            minimum_rate=req.minimum_rate,
            simplified_income=w.simplified_income,
            simplified_taxes=w.simplified_taxes,
            opening=w.opening_balances,
            effective_elections=w.effective_elections,
            trace=trace,
        )

        simplified_income = float(w.simplified_income)
        simplified_taxes = float(taxes_after_cf)

        simplified_loss = 0.0
        simplified_etr = None
        if simplified_income <= 0:
            simplified_loss = max(0.0, -simplified_income)
        else:
            simplified_etr = simplified_taxes / simplified_income if simplified_income != 0 else None

        # Loss-year negative-tax adjustment / Loss DTA method
        simplified_adjustment_for_negative_taxes = 0.0
        closing_additions: list[CarryforwardBalanceV2] = []

        loss_dta_method = bool(get_effective_election_bool(w.effective_elections, "LOSS_DTA_ADJUSTMENT_METHOD_ELECTED") or False)
        loss_dta_generated = get_effective_election_amount(w.effective_elections, "LOSS_DTA_ADJUSTMENT_GENERATED_AMOUNT")
        if loss_dta_generated is not None:
            loss_dta_generated = float(loss_dta_generated)

        if loss_dta_method and loss_dta_generated and loss_dta_generated > 0 and simplified_loss > 0:
            closing_additions.append(
                CarryforwardBalanceV2(
                    kind="LOSS_DTA_ADJUSTMENT",
                    origin_fiscal_year_start=fy_start,
                    amount=abs(loss_dta_generated),
                    remaining_amount=abs(loss_dta_generated),
                    note="Generated under Loss DTA Adjustment methodology (input amount).",
                )
            )
            trace.append(
                TraceLine(
                    section="tax",
                    step="Loss-year: Loss DTA Adjustment generated (carryforward)",
                    amount=0.0,
                    note=f"Amount created = {abs(loss_dta_generated):.2f}",
                )
            )
        else:
            if simplified_loss > 0 and simplified_taxes < 0:
                simplified_adjustment_for_negative_taxes = simplified_taxes - (simplified_loss * req.minimum_rate)
                cf_amt = abs(simplified_adjustment_for_negative_taxes)
                if cf_amt > 0:
                    closing_additions.append(
                        CarryforwardBalanceV2(
                            kind="SIMPLIFIED_NEGATIVE_TAX_ADJUSTMENT",
                            origin_fiscal_year_start=fy_start,
                            amount=cf_amt,
                            remaining_amount=cf_amt,
                            note="Computed as abs(Simplified Taxes – (Simplified Loss * Minimum Rate)).",
                        )
                    )
                    trace.append(
                        TraceLine(
                            section="tax",
                            step="Loss-year: Simplified Adjustment for Negative Taxes computed (carryforward)",
                            amount=simplified_adjustment_for_negative_taxes,
                            note="Computed as Simplified Taxes – (Simplified Loss * Minimum Rate). Stored as a positive carryforward amount.",
                        )
                    )

        # Safe harbour outcome (recomputed after adjustments)
        if simplified_income <= 0:
            safe_harbour_pass = True
            reason = "PASS: Simplified Loss (or non-positive Simplified Income)."
        else:
            safe_harbour_pass = (simplified_etr is not None) and simplified_etr >= req.minimum_rate
            reason = (
                "PASS: Simplified ETR >= Minimum Rate."
                if safe_harbour_pass
                else "FAIL: Simplified ETR < Minimum Rate and no Simplified Loss."
            )

        if not w.eligible:
            safe_harbour_pass = False
            reason = "NOT AVAILABLE: jurisdiction fails eligibility criteria (see reasons)."

        closing = [b for b in balances_after if (b.remaining_amount or 0.0) > 0] + closing_additions

        results.append(
            TestedJurisdictionResultV2(
                tested_jurisdiction_id=bucket_id,
                jurisdiction_code=tj.jurisdiction_code,
                label=tj.label,
                        transition_year_fy_start=(tj.transition_year.transition_year_fy_start or fy_start) if tj.transition_year else None,
                        is_transition_year=(fy_start == (tj.transition_year.transition_year_fy_start or fy_start)) if tj.transition_year else None,
                eligible=w.eligible,
                ineligibility_reasons=list(w.ineligibility_reasons),
                simplified_income=simplified_income,
                simplified_taxes=simplified_taxes,
                simplified_etr=simplified_etr,
                simplified_loss=simplified_loss,
                safe_harbour_applies=safe_harbour_pass,
                safe_harbour_reason=reason,
                simplified_adjustment_for_negative_taxes=float(simplified_adjustment_for_negative_taxes),
                effective_elections=w.effective_elections,
                election_records=list(w.election_records),
                trace=trace,
                carryforwards_opening=w.opening_balances,
                carryforward_movements=movements,
                carryforwards_closing=closing,
            )
        )

    return CalculationResponseV2(
        ruleset_version=req.ruleset_version,
        fiscal_year=req.fiscal_year,
        minimum_rate=req.minimum_rate,
        reporting_currency=reporting_currency,
        results=results,
    )
