import unittest
from datetime import date

from app.services.models_v2 import (
    CalculationRequestV2,
    FiscalYearV2,
    TestedJurisdictionInputV2,
    TestedJurisdictionCompositionV2,
    JurisdictionFactsV2,
    CarryforwardBalanceV2,
    CrossBorderTaxItemV2,
    ElectionInstanceV2,
    InvestmentEntityOwnerAddbackV2,
    GroupProfileV2,
    FxRateV2,
    AccountingBasisV2,
    TransitionYearV2,
    TransitionDeferredTaxItemV2,
    Article913TransferV2,
)
from app.services.calculator_v2 import calculate_v2


class CalculatorV2Tests(unittest.TestCase):
    def test_two_tested_jurisdictions_same_country(self):
        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            tested_jurisdictions=[
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="GB_MAIN",
                    jurisdiction_code="GB",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    facts=JurisdictionFactsV2(jpbt=100.0, current_tax_expense=20.0),
                ),
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="GB_INVEST",
                    jurisdiction_code="GB",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    facts=JurisdictionFactsV2(jpbt=100.0, current_tax_expense=10.0),
                ),
            ],
        )
        resp = calculate_v2(req)
        self.assertEqual(len(resp.results), 2)
        ids = {r.tested_jurisdiction_id for r in resp.results}
        self.assertEqual(ids, {"GB_MAIN", "GB_INVEST"})

    def test_carryforward_reduces_taxes(self):
        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            tested_jurisdictions=[
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="DE_MAIN",
                    jurisdiction_code="DE",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    facts=JurisdictionFactsV2(jpbt=100.0, current_tax_expense=20.0),
                    carryforwards_opening=[
                        CarryforwardBalanceV2(kind="SIMPLIFIED_NEGATIVE_TAX_ADJUSTMENT", amount=10.0)
                    ],
                )
            ],
        )
        resp = calculate_v2(req)
        r = resp.results[0]
        self.assertAlmostEqual(r.simplified_taxes, 10.0)
        self.assertFalse(r.safe_harbour_applies)

    def test_loss_year_generates_negative_tax_adjustment(self):
        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            tested_jurisdictions=[
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="FR_MAIN",
                    jurisdiction_code="FR",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    facts=JurisdictionFactsV2(jpbt=-100.0, current_tax_expense=-5.0),
                )
            ],
        )
        resp = calculate_v2(req)
        r = resp.results[0]
        self.assertTrue(r.safe_harbour_applies)
        self.assertAlmostEqual(r.simplified_loss, 100.0)
        self.assertAlmostEqual(r.simplified_adjustment_for_negative_taxes, -20.0)
        kinds = [b.kind for b in r.carryforwards_closing]
        self.assertIn("SIMPLIFIED_NEGATIVE_TAX_ADJUSTMENT", kinds)
        bal = [b for b in r.carryforwards_closing if b.kind == "SIMPLIFIED_NEGATIVE_TAX_ADJUSTMENT"][0]
        self.assertAlmostEqual(bal.amount, 20.0)

    def test_cross_border_tax_allocation(self):
        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            cross_border_tax_items=[
                CrossBorderTaxItemV2(
                    item_id="CB1",
                    label="Withholding tax allocated",
                    amount=10.0,
                    source_tested_jurisdiction_id="A",
                    target_tested_jurisdiction_id="B",
                    treatment="ALLOCATE",
                )
            ],
            tested_jurisdictions=[
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="A",
                    jurisdiction_code="AA",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    facts=JurisdictionFactsV2(jpbt=100.0, current_tax_expense=20.0),
                ),
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="B",
                    jurisdiction_code="BB",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    facts=JurisdictionFactsV2(jpbt=100.0, current_tax_expense=5.0),
                ),
            ],
        )
        resp = calculate_v2(req)
        by_id = {r.tested_jurisdiction_id: r for r in resp.results}
        self.assertAlmostEqual(by_id["A"].simplified_taxes, 10.0)
        self.assertAlmostEqual(by_id["B"].simplified_taxes, 15.0)
        # B should pass exactly at 15%
        self.assertTrue(by_id["B"].safe_harbour_applies)

    def test_cross_border_default_exclude_when_no_keep_election(self):
        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            cross_border_tax_items=[
                CrossBorderTaxItemV2(
                    item_id="CB2",
                    label="Allocable tax excluded",
                    amount=5.0,
                    source_tested_jurisdiction_id="A",
                )
            ],
            tested_jurisdictions=[
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="A",
                    jurisdiction_code="AA",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    facts=JurisdictionFactsV2(jpbt=100.0, current_tax_expense=20.0),
                )
            ],
        )
        resp = calculate_v2(req)
        r = resp.results[0]
        self.assertAlmostEqual(r.simplified_taxes, 15.0)

    def test_cross_border_default_keep_when_keep_allocable_election(self):
        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            cross_border_tax_items=[
                CrossBorderTaxItemV2(
                    item_id="CB3",
                    label="Allocable tax kept",
                    amount=5.0,
                    source_tested_jurisdiction_id="A",
                )
            ],
            tested_jurisdictions=[
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="A",
                    jurisdiction_code="AA",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    facts=JurisdictionFactsV2(jpbt=100.0, current_tax_expense=20.0),
                    elections=[
                        ElectionInstanceV2(
                            election_code="CROSS_BORDER_FIVE_YEAR_ELECTION_KEEP_ALLOCABLE_TAXES",
                            scope="metadata",
                            value_type="bool",
                            bool_value=True,
                            effective_fiscal_year_start=date(2027, 1, 1),
                        )
                    ],
                )
            ],
        )
        resp = calculate_v2(req)
        r = resp.results[0]
        self.assertAlmostEqual(r.simplified_taxes, 20.0)

    def test_investment_entity_owner_addback_tax_increases_taxes(self):
        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            tested_jurisdictions=[
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="IE1",
                    jurisdiction_code="IE",
                    tested_jurisdiction_type="investment_entity",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    facts=JurisdictionFactsV2(jpbt=100.0, current_tax_expense=0.0),
                    owner_addbacks=[
                        InvestmentEntityOwnerAddbackV2(
                            label="Owner addback tax",
                            article="7.5",
                            kind="tax",
                            amount=20.0,
                        )
                    ],
                )
            ],
        )
        resp = calculate_v2(req)
        r = resp.results[0]
        self.assertAlmostEqual(r.simplified_taxes, 20.0)

    def test_multi_year_election_overlap_raises(self):
        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            tested_jurisdictions=[
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="X",
                    jurisdiction_code="XX",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    facts=JurisdictionFactsV2(jpbt=100.0, current_tax_expense=20.0),
                    elections=[
                        ElectionInstanceV2(
                            election_code="SHIPPING_FIVE_YEAR_ELECTION_NOT_TO_EXCLUDE",
                            scope="income",
                            value_type="bool",
                            bool_value=True,
                            effective_fiscal_year_start=date(2027, 1, 1),
                        ),
                        ElectionInstanceV2(
                            election_code="SHIPPING_FIVE_YEAR_ELECTION_NOT_TO_EXCLUDE",
                            scope="income",
                            value_type="bool",
                            action="REVOKE",
                            effective_fiscal_year_start=date(2029, 1, 1),
                        ),
                    ],
                )
            ],
        )
        with self.assertRaises(ValueError):
            calculate_v2(req)

    def test_five_year_election_continues_until_revoked(self):
        """A FIVE_YEAR election should remain effective after 5 years unless revoked (OECD 'until revoked')."""

        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2034, 1, 1)),
            minimum_rate=0.15,
            tested_jurisdictions=[
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="X",
                    jurisdiction_code="XX",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    facts=JurisdictionFactsV2(jpbt=100.0, current_tax_expense=20.0),
                    elections=[
                        ElectionInstanceV2(
                            election_code="AFXGL_FIVE_YEAR_ELECTION_NOT_TO_APPLY",
                            scope="income",
                            value_type="bool",
                            bool_value=True,
                            effective_fiscal_year_start=date(2027, 1, 1),
                        )
                    ],
                )
            ],
        )
        resp = calculate_v2(req)
        eff = [e.election_code for e in resp.results[0].effective_elections]
        self.assertIn("AFXGL_FIVE_YEAR_ELECTION_NOT_TO_APPLY", eff)

    def test_shipping_cooldown_after_revocation(self):
        """Shipping election: after revocation, cannot make a new election for four succeeding FYs."""

        # Revocation in Year 6 (2032) is allowed; re-election in 2035 is not.
        req_bad = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2035, 1, 1)),
            minimum_rate=0.15,
            tested_jurisdictions=[
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="X",
                    jurisdiction_code="XX",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    facts=JurisdictionFactsV2(jpbt=100.0, current_tax_expense=20.0),
                    elections=[
                        ElectionInstanceV2(
                            election_code="SHIPPING_FIVE_YEAR_ELECTION_NOT_TO_EXCLUDE",
                            scope="income",
                            value_type="bool",
                            bool_value=True,
                            effective_fiscal_year_start=date(2027, 1, 1),
                        ),
                        ElectionInstanceV2(
                            election_code="SHIPPING_FIVE_YEAR_ELECTION_NOT_TO_EXCLUDE",
                            scope="income",
                            value_type="bool",
                            action="REVOKE",
                            effective_fiscal_year_start=date(2032, 1, 1),
                        ),
                        ElectionInstanceV2(
                            election_code="SHIPPING_FIVE_YEAR_ELECTION_NOT_TO_EXCLUDE",
                            scope="income",
                            value_type="bool",
                            bool_value=True,
                            effective_fiscal_year_start=date(2035, 1, 1),
                        ),
                    ],
                )
            ],
        )
        with self.assertRaises(ValueError):
            calculate_v2(req_bad)

        # Re-election in 2037 is permitted (2033-2036 are the four succeeding FYs).
        req_ok = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2037, 1, 1)),
            minimum_rate=0.15,
            tested_jurisdictions=[
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="X",
                    jurisdiction_code="XX",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    facts=JurisdictionFactsV2(jpbt=100.0, current_tax_expense=20.0),
                    elections=[
                        ElectionInstanceV2(
                            election_code="SHIPPING_FIVE_YEAR_ELECTION_NOT_TO_EXCLUDE",
                            scope="income",
                            value_type="bool",
                            bool_value=True,
                            effective_fiscal_year_start=date(2027, 1, 1),
                        ),
                        ElectionInstanceV2(
                            election_code="SHIPPING_FIVE_YEAR_ELECTION_NOT_TO_EXCLUDE",
                            scope="income",
                            value_type="bool",
                            action="REVOKE",
                            effective_fiscal_year_start=date(2032, 1, 1),
                        ),
                        ElectionInstanceV2(
                            election_code="SHIPPING_FIVE_YEAR_ELECTION_NOT_TO_EXCLUDE",
                            scope="income",
                            value_type="bool",
                            bool_value=True,
                            effective_fiscal_year_start=date(2037, 1, 1),
                        ),
                    ],
                )
            ],
        )
        resp_ok = calculate_v2(req_ok)
        self.assertEqual(len(resp_ok.results), 1)

    def test_fx_translation_applies_to_inputs(self):
        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            group_profile=GroupProfileV2(reporting_currency="EUR"),
            fx_rates=[FxRateV2(currency="USD", avg_rate_to_reporting=0.5, fiscal_year_start=date(2027, 1, 1))],
            tested_jurisdictions=[
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="US1",
                    jurisdiction_code="US",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    accounting_basis=AccountingBasisV2(currency="USD", amount_scale="UNITS"),
                    facts=JurisdictionFactsV2(jpbt=100.0, current_tax_expense=20.0),
                )
            ],
        )
        resp = calculate_v2(req)
        r = resp.results[0]
        self.assertAlmostEqual(r.simplified_income, 50.0)
        self.assertAlmostEqual(r.simplified_taxes, 10.0)
        self.assertTrue(r.safe_harbour_applies)

    def test_carryforward_origin_year_fx_is_used_when_provided(self):
        """Carryforwards with origin_fiscal_year_start should be translated using origin-year avg FX (v4 module 3)."""

        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            group_profile=GroupProfileV2(reporting_currency="EUR"),
            fx_rates=[
                FxRateV2(currency="USD", avg_rate_to_reporting=0.5, fiscal_year_start=date(2027, 1, 1)),
                FxRateV2(currency="USD", avg_rate_to_reporting=0.4, fiscal_year_start=date(2026, 1, 1)),
            ],
            tested_jurisdictions=[
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="US1",
                    jurisdiction_code="US",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    accounting_basis=AccountingBasisV2(currency="USD", amount_scale="UNITS"),
                    facts=JurisdictionFactsV2(jpbt=100.0, current_tax_expense=20.0),
                    carryforwards_opening=[
                        CarryforwardBalanceV2(
                            kind="SIMPLIFIED_NEGATIVE_TAX_ADJUSTMENT",
                            amount=10.0,
                            origin_fiscal_year_start=date(2026, 1, 1),
                        )
                    ],
                )
            ],
        )

        resp = calculate_v2(req)
        r = resp.results[0]
        # Taxes: 20 USD -> 10 EUR at 0.5; carryforward 10 USD -> 4 EUR at origin-year 0.4 => 6 EUR
        self.assertAlmostEqual(r.simplified_taxes, 6.0)

    def test_lfas_groupwide_consistency_enforced_when_cfs_used(self):
        """If a permitted CFS-basis LFAS election is used in one jurisdiction, require all eligible LFAS jurisdictions to use it."""

        with self.assertRaises(ValueError):
            CalculationRequestV2(
                fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
                minimum_rate=0.15,
                tested_jurisdictions=[
                    TestedJurisdictionInputV2(
                        tested_jurisdiction_id="J1",
                        jurisdiction_code="AA",
                        composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                        accounting_basis=AccountingBasisV2(
                            basis_source="CFS",
                            lfas_qdmtt_applies=True,
                            lfas_requires_local_gaap=True,
                            jurisdiction_allows_cfs_gaap_for_qdmtt=True,
                        ),
                        facts=JurisdictionFactsV2(jpbt=100.0, current_tax_expense=20.0),
                    ),
                    TestedJurisdictionInputV2(
                        tested_jurisdiction_id="J2",
                        jurisdiction_code="BB",
                        composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                        accounting_basis=AccountingBasisV2(
                            basis_source="LOCAL_GAAP",
                            lfas_qdmtt_applies=True,
                            lfas_requires_local_gaap=True,
                            jurisdiction_allows_cfs_gaap_for_qdmtt=True,
                        ),
                        facts=JurisdictionFactsV2(jpbt=100.0, current_tax_expense=20.0),
                    ),
                ],
            )

    def test_lfas_validation_blocks_cfs_when_local_required(self):
        with self.assertRaises(ValueError):
            AccountingBasisV2(
                basis_source="CFS",
                lfas_qdmtt_applies=True,
                lfas_requires_local_gaap=True,
                jurisdiction_allows_cfs_gaap_for_qdmtt=False,
            )


    def test_transition_year_disallowed_opening_dta_increases_taxes(self):
        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            tested_jurisdictions=[
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="TY1",
                    jurisdiction_code="TY",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    facts=JurisdictionFactsV2(jpbt=100.0, current_tax_expense=0.0, deferred_tax_expense=0.0, accounted_tax_rate=0.25),
                    transition_year=TransitionYearV2(
                        transition_year_fy_start=date(2027, 1, 1),
                        opening_deferred_tax_items=[
                            TransitionDeferredTaxItemV2(
                                label="Disallowed opening DTA",
                                item_type="DTA",
                                opening_balance=100.0,
                                tax_rate=0.25,
                                disallowed_under_article_9_1_2=True,
                            )
                        ],
                    ),
                )
            ],
        )
        resp = calculate_v2(req)
        r = resp.results[0]
        # Opening 100 at 25% recast to 15% => 60 tax adjustment
        self.assertAlmostEqual(r.simplified_taxes, 60.0)
        self.assertTrue(r.safe_harbour_applies)

    def test_transition_year_uses_spot_fx_for_opening_dta(self):
        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            group_profile=GroupProfileV2(reporting_currency="EUR"),
            fx_rates=[
                FxRateV2(currency="USD", avg_rate_to_reporting=0.5, spot_rate_to_reporting=0.4, fiscal_year_start=date(2027, 1, 1)),
            ],
            tested_jurisdictions=[
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="TY_US",
                    jurisdiction_code="US",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    accounting_basis=AccountingBasisV2(currency="USD", amount_scale="UNITS"),
                    facts=JurisdictionFactsV2(jpbt=100.0, current_tax_expense=0.0, deferred_tax_expense=0.0, accounted_tax_rate=0.25),
                    transition_year=TransitionYearV2(
                        transition_year_fy_start=date(2027, 1, 1),
                        opening_deferred_tax_items=[
                            TransitionDeferredTaxItemV2(
                                label="Disallowed opening DTA USD",
                                item_type="DTA",
                                opening_balance=100.0,
                                tax_rate=0.25,
                                disallowed_under_article_9_1_2=True,
                            )
                        ],
                    ),
                )
            ],
        )
        resp = calculate_v2(req)
        r = resp.results[0]
        # Income 100 USD -> 50 EUR at avg 0.5. Opening DTA 100 USD -> 40 EUR at spot 0.4. Recast to 15% => 24 EUR.
        self.assertAlmostEqual(r.simplified_income, 50.0)
        self.assertAlmostEqual(r.simplified_taxes, 24.0)

    def test_article_9_1_3_transfer_adjustment_applies_post_transition(self):
        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2028, 1, 1)),
            minimum_rate=0.15,
            tested_jurisdictions=[
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="TJ",
                    jurisdiction_code="TT",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    facts=JurisdictionFactsV2(jpbt=100.0, current_tax_expense=15.0, deferred_tax_expense=0.0),
                    transition_year=TransitionYearV2(
                        transition_year_fy_start=date(2027, 1, 1),
                        article_9_1_3_transfers=[
                            Article913TransferV2(label="9.1.3 adjustment", income_adjustment=-10.0, tax_adjustment=2.0)
                        ],
                    ),
                )
            ],
        )
        resp = calculate_v2(req)
        r = resp.results[0]
        # Income reduced by 10, taxes increased by 2
        self.assertAlmostEqual(r.simplified_income, 90.0)
        self.assertAlmostEqual(r.simplified_taxes, 17.0)
        self.assertTrue(r.safe_harbour_applies)
if __name__ == "__main__":
    unittest.main()