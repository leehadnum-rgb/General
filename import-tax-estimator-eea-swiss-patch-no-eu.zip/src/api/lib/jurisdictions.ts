/**
 * Central registry of supported jurisdictions.
 *
 * - US/NZ/CH/NO are ingested into Postgres by the cron job.
 * - GB and EU member states (in this MVP) are looked up live.
 */

export const EU_JURISDICTIONS = [
  "AT",
  "BE",
  "BG",
  "CY",
  "CZ",
  "DE",
  "DK",
  "EE",
  "ES",
  "FI",
  "FR",
  "GR",
  "HR",
  "HU",
  "IE",
  "IT",
  "LT",
  "LU",
  "LV",
  "MT",
  "NL",
  "PL",
  "PT",
  "RO",
  "SE",
  "SI",
  "SK",
] as const;

export const EEA_NON_EU_JURISDICTIONS = [
  "IS", // Iceland
  "LI", // Liechtenstein (customs/VAT territory with Switzerland; handled as an alias to CH for duty)
  "NO", // Norway (already supported, ingested)
] as const;

export const SUPPORTED_JURISDICTIONS = [
  "US",
  "NZ",
  "CH",
  "LI",
  "GB",
  "NO",
  "IS",
  ...EU_JURISDICTIONS,
] as const;

export type SupportedJurisdictionId = (typeof SUPPORTED_JURISDICTIONS)[number];

export function isEuJurisdiction(jurisdictionId: string): jurisdictionId is (typeof EU_JURISDICTIONS)[number] {
  return (EU_JURISDICTIONS as readonly string[]).includes(String(jurisdictionId ?? "").toUpperCase());
}


export function isEeaNonEuJurisdiction(
  jurisdictionId: string
): jurisdictionId is (typeof EEA_NON_EU_JURISDICTIONS)[number] {
  return (EEA_NON_EU_JURISDICTIONS as readonly string[]).includes(
    String(jurisdictionId ?? "").toUpperCase()
  );
}
