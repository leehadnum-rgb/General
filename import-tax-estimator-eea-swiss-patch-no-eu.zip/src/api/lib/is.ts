import { Expr } from "../../core/ast";

/**
 * Iceland (IS) — MVP implementation.
 *
 * We currently support:
 * - Import VAT (standard rate) on a standard VAT base formula.
 *
 * We currently do NOT support:
 * - Customs duty lookup by HS code (tariff database integration pending).
 *
 * Data notes:
 * - Standard VAT rate in Iceland is 24% (reduced 11% for certain goods/services).
 *   This MVP uses the standard rate.
 */
export type IsLiveMeasure = {
  measureId: string;
  measureType: "CUSTOMS_DUTY";
  originScope: "MFN" | "PREFERENTIAL" | "ALL";
  originCode: string;
  expression: {
    expressionId: string;
    exprType: "AST" | "CUSTOM";
    ast: Expr;
    sourceRef?: string | null;
    raw?: any;
  };
};

export type IsLiveTariff = {
  code: string;
  description: string;
  currency: string;
  vatLabel: string;
  vatRatePct: number;
  vatBaseAst: Expr;
  measures: IsLiveMeasure[];
  unsupported: any[];
  sourceRef: string;
};

const VAT_BASE_AST: Expr = {
  op: "add",
  terms: [
    { op: "field", name: "customs_value" },
    { op: "field", name: "customs_duty_total" },
    { op: "field", name: "fees_total" },
    { op: "field", name: "freight_to_border" },
    { op: "field", name: "insurance_to_border" },
  ],
};

function normalizeCode(code: string): string {
  return (code ?? "").replace(/[^0-9]/g, "");
}

function vatRatePct(): number {
  const raw = process.env.IS_VAT_RATE_PCT;
  if (raw != null && raw !== "") {
    const n = Number(raw);
    if (Number.isFinite(n)) return n;
  }
  return 24;
}

export async function fetchIsVatOnlyTariff(codeInput: string, asOfDate: string): Promise<IsLiveTariff> {
  const code = normalizeCode(codeInput);

  return {
    code,
    description: `Iceland HS ${code} (VAT-only MVP)`,
    currency: "ISK",
    vatLabel: "VAT",
    vatRatePct: vatRatePct(),
    vatBaseAst: VAT_BASE_AST,
    measures: [],
    unsupported: [
      {
        measureType: "CUSTOMS_DUTY",
        reason: "not_supported_for_jurisdiction",
        message: "Customs duty lookup is not yet supported for Iceland in this MVP. VAT is estimated on customs value + freight/insurance (and would be higher if duties apply).",
        asOfDate,
        sourceRef: "Skatturinn / Tollskrá (Iceland)",
      },
    ],
    sourceRef: "Skatturinn / Tollskrá (Iceland)",
  };
}
