/**
 * Some jurisdictions share a customs/VAT territory with another jurisdiction.
 * We represent this by mapping the *requested* jurisdiction to a *data* jurisdiction
 * for tariff lookup and calculation.
 */
export function resolveDataJurisdictionId(requestedJurisdictionId: string): string {
  const j = String(requestedJurisdictionId ?? "").trim().toUpperCase();
  // Liechtenstein is in a customs and VAT territory with Switzerland (CH).
  if (j === "LI") return "CH";
  return j;
}
