import { FastifyInstance } from "fastify";
import { Pool } from "pg";
import { z } from "zod";
import { calculateEstimate } from "../../core/calc";
import { fetchGbLiveTariff } from "../lib/gb";
import { fetchEuLiveTariff } from "../lib/eu";
import { fetchIsVatOnlyTariff } from "../lib/is";
import { resolveDataJurisdictionId } from "../lib/aliases";
import { SUPPORTED_JURISDICTIONS, isEuJurisdiction } from "../lib/jurisdictions";

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const Body = z.object({
  jurisdictionId: z.enum(SUPPORTED_JURISDICTIONS),
  code: z.string(),
  asOfDate: z.string().optional(),
  originCountry: z.string().optional(),
  currency: z.string(),
  customsValue: z.object({ amount: z.string(), currency: z.string() }),
  freightToBorder: z.object({ amount: z.string(), currency: z.string() }).optional(),
  insuranceToBorder: z.object({ amount: z.string(), currency: z.string() }).optional(),

  netMassKg: z.string().optional(),
  grossMassKg: z.string().optional(),
  volumeLitre: z.string().optional(),
  quantity: z.object({ amount: z.string(), unit: z.string() }).optional(),
});

function normalizeCode(code: string): string {
  return (code ?? "").replace(/[^0-9]/g, "");
}

const AST_SUPPORTED_OPS = new Set([
  "field",
  "const_money",
  "const_number",
  "add",
  "mul",
  "min",
  "max",
  "ad_valorem",
  "specific",
]);

function isSupportedAst(ast: any): boolean {
  if (!ast || typeof ast !== "object") return false;
  if (typeof ast.op !== "string") return false;
  if (!AST_SUPPORTED_OPS.has(ast.op)) return false;

  if (ast.op === "add" || ast.op === "min" || ast.op === "max") {
    return Array.isArray(ast.terms) && ast.terms.every(isSupportedAst);
  }
  if (ast.op === "mul") return isSupportedAst(ast.left) && isSupportedAst(ast.right);
  return true;
}

export async function estimateRoute(app: FastifyInstance) {
  app.post("/estimate", async (req, reply) => {
    const body = Body.parse(req.body);
    const requestedJurisdictionId = body.jurisdictionId;
    const dataJurisdictionId = resolveDataJurisdictionId(requestedJurisdictionId);
    const asOfDate = body.asOfDate ?? new Date().toISOString().slice(0, 10);
    const originCountry = body.originCountry ? body.originCountry.trim().toUpperCase() : undefined;
    if (originCountry && !/^[A-Z]{2}$/.test(originCountry)) {
      return reply.code(400).send({ error: "invalid_origin_country", expected: "ISO alpha-2", got: body.originCountry });
    }
    let code = normalizeCode(body.code);
    if (requestedJurisdictionId === "NO" && code.length > 0 && code.length < 8) code = code.padEnd(8, "0");


    // Iceland (IS): VAT-only (customs duty integration pending)
    if (requestedJurisdictionId === "IS") {
      const live = await fetchIsVatOnlyTariff(code, asOfDate);

      if (body.customsValue.currency !== live.currency) {
        return reply.code(400).send({ error: "currency_mismatch", expected: live.currency, got: body.customsValue.currency });
      }
      if (body.freightToBorder && body.freightToBorder.currency !== live.currency) {
        return reply.code(400).send({ error: "currency_mismatch", expected: live.currency, got: body.freightToBorder.currency });
      }
      if (body.insuranceToBorder && body.insuranceToBorder.currency !== live.currency) {
        return reply.code(400).send({ error: "currency_mismatch", expected: live.currency, got: body.insuranceToBorder.currency });
      }

      const measures: any[] = [];
      const vatRule = { ratePct: live.vatRatePct, label: live.vatLabel };
      const vatBase = { ast: live.vatBaseAst };

      const result = calculateEstimate(
        {
          jurisdictionId: requestedJurisdictionId,
          currency: live.currency,
          code: live.code,
          asOfDate,
          originCountry,
          customsValue: body.customsValue,
          freightToBorder: body.freightToBorder,
          insuranceToBorder: body.insuranceToBorder,
          netMassKg: body.netMassKg,
          grossMassKg: body.grossMassKg,
          volumeLitre: body.volumeLitre,
          quantity: body.quantity,
        },
        measures,
        vatRule,
        vatBase
      );

      // Make it explicit that duty was not calculated.
      result.assumptions.push({
        code: "IS_DUTY_NOT_INCLUDED",
        message: "Customs duty is not calculated for Iceland in this MVP. The VAT estimate may be understated if duty applies for the HS code.",
      });

      return reply.send({
        dataVersionId: "LIVE",
        tariffLine: { description: live.description },
        unsupported: live.unsupported,
        result,
      });
    }


    // EU member states: live lookup via ISZTAR4 REST API
    if (isEuJurisdiction(requestedJurisdictionId)) {
      const live = await fetchEuLiveTariff(code, asOfDate, requestedJurisdictionId, { expandGroups: true });

      if (body.customsValue.currency !== live.currency) {
        return reply.code(400).send({ error: "currency_mismatch", expected: live.currency, got: body.customsValue.currency });
      }
      if (body.freightToBorder && body.freightToBorder.currency !== live.currency) {
        return reply.code(400).send({ error: "currency_mismatch", expected: live.currency, got: body.freightToBorder.currency });
      }
      if (body.insuranceToBorder && body.insuranceToBorder.currency !== live.currency) {
        return reply.code(400).send({ error: "currency_mismatch", expected: live.currency, got: body.insuranceToBorder.currency });
      }

      const unsupported: any[] = [...(live.unsupported ?? [])];
      const measures = live.measures
        .filter((m) => {
          if (m.expression.exprType === "CUSTOM" || !isSupportedAst(m.expression.ast)) {
            unsupported.push({
              measureId: m.measureId,
              reason: "manual_or_unsupported_expression",
              exprType: m.expression.exprType,
              ast: m.expression.ast,
            });
            return false;
          }
          return true;
        })
        .map((m) => ({
          measureId: m.measureId,
          measureType: m.measureType,
          originScope: m.originScope,
          originCode: m.originCode,
          excludedOriginCodes: m.excludedOriginCodes ?? null,
          originMemberCodes: m.originMemberCodes ?? null,
          expression: { expressionId: m.expression.expressionId, ast: m.expression.ast },
        }));

      const vatRule = { ratePct: live.vatRatePct, label: live.vatLabel };
      const vatBase = { ast: live.vatBaseAst };

      const result = calculateEstimate(
        {
          jurisdictionId: requestedJurisdictionId,
          currency: live.currency,
          code: live.code,
          asOfDate,
          originCountry,
          customsValue: body.customsValue,
          freightToBorder: body.freightToBorder,
          insuranceToBorder: body.insuranceToBorder,
          netMassKg: body.netMassKg,
          grossMassKg: body.grossMassKg,
          volumeLitre: body.volumeLitre,
          quantity: body.quantity,
        },
        measures,
        vatRule,
        vatBase
      );

      return reply.send({
        dataVersionId: "LIVE",
        tariffLine: { description: live.description },
        unsupported,
        result,
      });
    }

    // GB: live lookup from Trade Tariff Public API
    if (requestedJurisdictionId === "GB") {
      const live = await fetchGbLiveTariff(code);

      // Guardrail: this MVP assumes the user provides values in the jurisdiction currency.
      if (body.customsValue.currency !== live.currency) {
        return reply.code(400).send({
          error: "currency_mismatch",
          expected: live.currency,
          got: body.customsValue.currency,
        });
      }
      if (body.freightToBorder && body.freightToBorder.currency !== live.currency) {
        return reply.code(400).send({ error: "currency_mismatch", expected: live.currency, got: body.freightToBorder.currency });
      }
      if (body.insuranceToBorder && body.insuranceToBorder.currency !== live.currency) {
        return reply.code(400).send({ error: "currency_mismatch", expected: live.currency, got: body.insuranceToBorder.currency });
      }

      const unsupported: any[] = [...(live.unsupported ?? [])];
      const measures = live.measures
        .filter((m) => {
          if (m.expression.exprType === "CUSTOM" || !isSupportedAst(m.expression.ast)) {
            unsupported.push({
              measureId: m.measureId,
              reason: "manual_or_unsupported_expression",
              exprType: m.expression.exprType,
              ast: m.expression.ast,
            });
            return false;
          }
          return true;
        })
        .map((m) => ({
          measureId: m.measureId,
          measureType: m.measureType,
          originScope: m.originScope,
          originCode: m.originCode,
          excludedOriginCodes: m.excludedOriginCodes ?? null,
          originMemberCodes: null,
          expression: { expressionId: m.expression.expressionId, ast: m.expression.ast },
        }));

      const vatRule = { ratePct: live.vatRatePct, label: live.vatLabel };
      const vatBase = { ast: live.vatBaseAst };

      const result = calculateEstimate(
        {
          jurisdictionId: "GB",
          currency: live.currency,
          code: live.code,
          asOfDate,
          originCountry,
          customsValue: body.customsValue,
          freightToBorder: body.freightToBorder,
          insuranceToBorder: body.insuranceToBorder,
          netMassKg: body.netMassKg,
          grossMassKg: body.grossMassKg,
          volumeLitre: body.volumeLitre,
          quantity: body.quantity,
        },
        measures,
        vatRule,
        vatBase
      );

      return reply.send({
        dataVersionId: "LIVE",
        tariffLine: { description: live.description },
        unsupported,
        result,
      });
    }

    const dv = await pool.query<{ data_version_id: string }>(
      `SELECT data_version_id FROM data_version WHERE jurisdiction_id=$1 AND is_active LIMIT 1`,
      [dataJurisdictionId]
    );
    if (dv.rowCount === 0) return reply.code(404).send({ error: "no_data_for_jurisdiction" });
    const dataVersionId = dv.rows[0]!.data_version_id;

    const tl = await pool.query<{ tariff_line_id: string; description: string }>(
      `SELECT tariff_line_id, description
       FROM tariff_line
       WHERE data_version_id=$1 AND jurisdiction_id=$2 AND code=$3 AND valid_range @> $4::date
       LIMIT 1`,
      [dataVersionId, dataJurisdictionId, code, asOfDate]
    );
    if (tl.rowCount === 0) return reply.code(404).send({ error: "code_not_found" });
    const tariffLineId = tl.rows[0]!.tariff_line_id;

    const ms = await pool.query<any>(
      `SELECT m.measure_id, m.measure_type, m.origin_scope, m.origin_code,
              e.expression_id, e.expr_type, e.ast_json
       FROM measure m
       JOIN expression e
         ON e.data_version_id=m.data_version_id AND e.expression_id=m.expression_id
       WHERE m.data_version_id=$1 AND m.tariff_line_id=$2 AND m.valid_range @> $3::date`,
      [dataVersionId, tariffLineId, asOfDate]
    );

    const unsupported: any[] = [];
    const measures = ms.rows
      .filter((r: any) => {
        if (String(r.expr_type) === "CUSTOM" || !isSupportedAst(r.ast_json)) {
          unsupported.push({ measureId: r.measure_id, reason: "manual_or_unsupported_expression", exprType: r.expr_type, ast: r.ast_json });
          return false;
        }
        return true;
      })
      .map((r: any) => ({
        measureId: r.measure_id,
        measureType: r.measure_type,
        originScope: r.origin_scope,
        originCode: r.origin_code,
        expression: { expressionId: r.expression_id, ast: r.ast_json },
      }));

    const vat = await pool.query<any>(
      `SELECT rate_pct
       FROM vat_rule
       WHERE data_version_id=$1 AND jurisdiction_id=$2 AND rate_type='STANDARD' AND valid_range @> $3::date
       LIMIT 1`,
      [dataVersionId, dataJurisdictionId, asOfDate]
    );
    const vatRate = vat.rowCount ? Number(vat.rows[0]!.rate_pct) : null;

    const vb = await pool.query<any>(
      `SELECT ast_json
       FROM vat_base_formula
       WHERE data_version_id=$1 AND jurisdiction_id=$2 AND valid_range @> $3::date
       LIMIT 1`,
      [dataVersionId, dataJurisdictionId, asOfDate]
    );
    const vatBaseAst = vb.rowCount ? vb.rows[0]!.ast_json : null;

    const j = await pool.query<{ vat_label: string }>(
      `SELECT vat_label FROM jurisdiction WHERE jurisdiction_id=$1 LIMIT 1`,
      [dataJurisdictionId]
    );
    const vatLabel = j.rowCount ? j.rows[0]!.vat_label : (requestedJurisdictionId === "NZ" ? "GST" : "VAT");
    const vatRule = vatRate == null ? null : { ratePct: vatRate, label: vatLabel };
    const vatBase = vatBaseAst ? { ast: vatBaseAst } : null;

    const result = calculateEstimate(
      {
        jurisdictionId: requestedJurisdictionId,
        currency: body.currency,
        code,
        asOfDate,
        originCountry,
        customsValue: body.customsValue,
        freightToBorder: body.freightToBorder,
        insuranceToBorder: body.insuranceToBorder,
        netMassKg: body.netMassKg,
        grossMassKg: body.grossMassKg,
        volumeLitre: body.volumeLitre,
        quantity: body.quantity,
      },
      measures,
      vatRule,
      vatBase
    );

    if (requestedJurisdictionId === "LI") {
      result.assumptions.push({
        code: "LI_ALIASED_TO_CH",
        message: "Liechtenstein shares a customs/VAT territory with Switzerland. This estimate uses Switzerland (CH) tariff and VAT rules for LI.",
      });
    }

    return reply.send({
      dataVersionId,
      tariffLine: { description: tl.rows[0]!.description },
      unsupported,
      result,
    });
  });
}