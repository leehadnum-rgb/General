import { FastifyInstance } from "fastify";
import { z } from "zod";
import { Pool } from "pg";
import { fetchGbLiveTariff } from "../lib/gb";
import { fetchEuLiveTariff } from "../lib/eu";
import { fetchIsVatOnlyTariff } from "../lib/is";
import { resolveDataJurisdictionId } from "../lib/aliases";
import { SUPPORTED_JURISDICTIONS, isEuJurisdiction } from "../lib/jurisdictions";

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const Body = z.object({
  jurisdictionId: z.enum(SUPPORTED_JURISDICTIONS),
  code: z.string(),
  asOfDate: z.string().optional(),
  originCountry: z.string().optional(),
});

function normalizeCode(code: string): string {
  return (code ?? "").replace(/[^0-9]/g, "");
}

const AST_SUPPORTED_OPS = new Set([
  "field",
  "const_money",
  "const_number",
  "add",
  "mul",
  "min",
  "max",
  "ad_valorem",
  "specific",
]);

type InputSpec = {
  field: string;
  type: "money" | "number" | "string";
  unit?: string;
  label: string;
  required: boolean;
  reason?: string;
  placeholder?: string;
  example?: string;
};

const FIELD_META: Record<string, { field: string; type: "number"; unit: string; label: string }> = {
  net_mass_kg:   { field: "netMassKg",     type: "number", unit: "kg",  label: "Net mass" },
  gross_mass_kg: { field: "grossMassKg",   type: "number", unit: "kg",  label: "Gross mass" },
  volume_litre:  { field: "volumeLitre",   type: "number", unit: "L",   label: "Volume" },
  quantity:      { field: "quantity.amount", type: "number", unit: "item", label: "Quantity" },
};

function collectAstFields(ast: any, out: Set<string>) {
  if (!ast || typeof ast !== "object") return;
  const op = ast.op;
  if (!op || typeof op !== "string") return;

  if (op === "field") {
    if (typeof ast.name === "string") out.add(ast.name);
    return;
  }
  if (op === "ad_valorem") {
    if (typeof ast.base === "string") out.add(ast.base);
    return;
  }
  if (op === "specific") {
    if (ast.per && typeof ast.per.qty_field === "string") out.add(ast.per.qty_field);
    return;
  }
  if (op === "add" || op === "min" || op === "max") {
    for (const t of (ast.terms ?? [])) collectAstFields(t, out);
    return;
  }
  if (op === "mul") {
    collectAstFields(ast.left, out);
    collectAstFields(ast.right, out);
    return;
  }
}

function isSupportedAst(ast: any): boolean {
  if (!ast || typeof ast !== "object") return false;
  if (typeof ast.op !== "string") return false;
  if (!AST_SUPPORTED_OPS.has(ast.op)) return false;

  if (ast.op === "add" || ast.op === "min" || ast.op === "max") {
    return Array.isArray(ast.terms) && ast.terms.every(isSupportedAst);
  }
  if (ast.op === "mul") return isSupportedAst(ast.left) && isSupportedAst(ast.right);
  return true;
}

export async function requirementsRoute(app: FastifyInstance) {
  app.post("/requirements", async (req, reply) => {
    const body = Body.parse(req.body);
    const requestedJurisdictionId = body.jurisdictionId;
    const dataJurisdictionId = resolveDataJurisdictionId(requestedJurisdictionId);
    const asOfDate = body.asOfDate ?? new Date().toISOString().slice(0, 10);
    const originCountry = body.originCountry ? body.originCountry.trim().toUpperCase() : undefined;
    if (originCountry && !/^[A-Z]{2}$/.test(originCountry)) {
      return reply.code(400).send({ error: "invalid_origin_country", expected: "ISO alpha-2", got: body.originCountry });
    }
    let code = normalizeCode(body.code);
    if (requestedJurisdictionId === "NO" && code.length > 0 && code.length < 8) code = code.padEnd(8, "0");


    // Iceland (IS): VAT-only (customs duty integration pending)
    if (requestedJurisdictionId === "IS") {
      const live = await fetchIsVatOnlyTariff(code, asOfDate);

      const inputs: InputSpec[] = [];
      inputs.push({
        field: "originCountry",
        type: "string",
        label: "Country of origin (ISO alpha-2)",
        required: true,
        reason: "Captured for consistency across jurisdictions (duty preferences not yet applied for IS in this MVP).",
        placeholder: "e.g., CN",
        example: "CN",
      });
      inputs.push({
        field: "customsValue",
        type: "money",
        label: "Customs value",
        required: true,
        reason: `${live.vatLabel} is calculated on customs value (and may also include duty where applicable)`,
      });

      const recommended: InputSpec[] = [
        {
          field: "freightToBorder",
          type: "money",
          label: "Freight to border",
          required: false,
          reason: `${live.vatLabel} base typically includes freight`,
        },
        {
          field: "insuranceToBorder",
          type: "money",
          label: "Insurance to border",
          required: false,
          reason: `${live.vatLabel} base typically includes insurance`,
        },
      ];

      return reply.send({
        jurisdiction: { id: requestedJurisdictionId, currency: live.currency, vatLabel: live.vatLabel, vatRatePct: live.vatRatePct },
        dataVersionId: "LIVE",
        asOfDate,
        tariffLine: { code: live.code, description: live.description },
        inputs: { required: inputs, recommended },
        unsupported: live.unsupported,
      });
    }


    // EU member states: live lookup via ISZTAR4 REST API
    if (isEuJurisdiction(requestedJurisdictionId)) {
      const live = await fetchEuLiveTariff(code, asOfDate, requestedJurisdictionId);

      const requiredFields = new Set<string>();
      requiredFields.add("customs_value");

      const unsupported: any[] = [...(live.unsupported ?? [])];

      for (const m of live.measures) {
        if (m.expression.exprType === "CUSTOM" || !isSupportedAst(m.expression.ast)) {
          unsupported.push({
            measureId: m.measureId,
            measureType: m.measureType,
            reason: "manual_or_unsupported_expression",
            sourceRef: m.expression.sourceRef ?? live.sourceRef,
            ast: m.expression.ast,
          });
          continue;
        }
        collectAstFields(m.expression.ast, requiredFields);
      }

      const inputs: InputSpec[] = [];
      inputs.push({
        field: "originCountry",
        type: "string",
        label: "Country of origin (ISO alpha-2)",
        required: true,
        reason: "Used to select preferential duty rates when available",
        placeholder: "e.g., CN",
        example: "CN",
      });
      inputs.push({
        field: "customsValue",
        type: "money",
        label: "Customs value",
        required: true,
        reason: "Required for duty/VAT calculation",
      });

      for (const f of requiredFields) {
        if (f === "customs_value") continue;
        const meta = FIELD_META[f];
        if (!meta) continue;
        inputs.push({
          field: meta.field,
          type: meta.type,
          unit: meta.unit,
          label: meta.label,
          required: true,
          reason: "Required by duty expression",
        });
      }

      const recommended: InputSpec[] = [];
      if (live.vatBaseAst) {
        const vatFields = new Set<string>();
        collectAstFields(live.vatBaseAst, vatFields);

        if (vatFields.has("freight_to_border")) {
          recommended.push({
            field: "freightToBorder",
            type: "money",
            label: "Freight to border",
            required: false,
            reason: `${live.vatLabel} base includes freight`,
          });
        }
        if (vatFields.has("insurance_to_border")) {
          recommended.push({
            field: "insuranceToBorder",
            type: "money",
            label: "Insurance to border",
            required: false,
            reason: `${live.vatLabel} base includes insurance`,
          });
        }
      }

      return reply.send({
        jurisdiction: { id: requestedJurisdictionId, currency: live.currency, vatLabel: live.vatLabel, vatRatePct: live.vatRatePct },
        dataVersionId: "LIVE",
        asOfDate,
        tariffLine: { code: live.code, description: live.description },
        inputs: { required: inputs, recommended },
        unsupported,
      });
    }

    // GB: live lookup from Trade Tariff Public API
    if (requestedJurisdictionId === "GB") {
      const live = await fetchGbLiveTariff(code);

      const requiredFields = new Set<string>();
      requiredFields.add("customs_value");

      const unsupported: any[] = [...(live.unsupported ?? [])];

      for (const m of live.measures) {
        if (m.expression.exprType === "CUSTOM" || !isSupportedAst(m.expression.ast)) {
          unsupported.push({
            measureId: m.measureId,
            measureType: m.measureType,
            reason: "manual_or_unsupported_expression",
            sourceRef: m.expression.sourceRef ?? live.sourceRef,
            ast: m.expression.ast,
          });
          continue;
        }
        collectAstFields(m.expression.ast, requiredFields);
      }

      const inputs: InputSpec[] = [];
      inputs.push({
        field: "originCountry",
        type: "string",
        label: "Country of origin (ISO alpha-2)",
        required: true,
        reason: "Used to select preferential duty rates when available",
        placeholder: "e.g., CN",
        example: "CN",
      });
      inputs.push({
        field: "customsValue",
        type: "money",
        label: "Customs value",
        required: true,
        reason: "Required for duty/VAT calculation",
      });

      for (const f of requiredFields) {
        if (f === "customs_value") continue;
        const meta = FIELD_META[f];
        if (!meta) continue;
        inputs.push({
          field: meta.field,
          type: meta.type,
          unit: meta.unit,
          label: meta.label,
          required: true,
          reason: "Required by duty expression",
        });
      }

      const recommended: InputSpec[] = [];
      if (live.vatBaseAst) {
        const vatFields = new Set<string>();
        collectAstFields(live.vatBaseAst, vatFields);

        if (vatFields.has("freight_to_border")) {
          recommended.push({
            field: "freightToBorder",
            type: "money",
            label: "Freight to border",
            required: false,
            reason: `${live.vatLabel} base includes freight`,
          });
        }
        if (vatFields.has("insurance_to_border")) {
          recommended.push({
            field: "insuranceToBorder",
            type: "money",
            label: "Insurance to border",
            required: false,
            reason: `${live.vatLabel} base includes insurance`,
          });
        }
      }

      return reply.send({
        jurisdiction: { id: "GB", currency: live.currency, vatLabel: live.vatLabel, vatRatePct: live.vatRatePct },
        dataVersionId: "LIVE",
        asOfDate,
        tariffLine: { code: live.code, description: live.description },
        inputs: { required: inputs, recommended },
        unsupported,
      });
    }

    // Active data version
    const dv = await pool.query<{ data_version_id: string }>(
      `SELECT data_version_id FROM data_version WHERE jurisdiction_id=$1 AND is_active LIMIT 1`,
      [dataJurisdictionId]
    );
    if (dv.rowCount === 0) return reply.code(404).send({ error: "no_data_for_jurisdiction" });
    const dataVersionId = dv.rows[0]!.data_version_id;

    // Jurisdiction metadata
    const j = await pool.query<{ currency: string; vat_label: string }>(
      `SELECT currency, vat_label FROM jurisdiction WHERE jurisdiction_id=$1 LIMIT 1`,
      [requestedJurisdictionId]
    );
    const currency = j.rowCount
      ? j.rows[0]!.currency
      : requestedJurisdictionId === "US"
        ? "USD"
        : requestedJurisdictionId === "NZ"
          ? "NZD"
          : requestedJurisdictionId === "NO"
            ? "NOK"
            : "CHF";
    const vatLabel = j.rowCount ? j.rows[0]!.vat_label : (requestedJurisdictionId === "NZ" ? "GST" : "VAT");

    // Tariff line
    const tl = await pool.query<{ tariff_line_id: string; description: string; code: string }>(
      `SELECT tariff_line_id, description, code
       FROM tariff_line
       WHERE data_version_id=$1 AND jurisdiction_id=$2 AND code=$3 AND valid_range @> $4::date
       LIMIT 1`,
      [dataVersionId, dataJurisdictionId, code, asOfDate]
    );
    if (tl.rowCount === 0) return reply.code(404).send({ error: "code_not_found" });
    const tariffLineId = tl.rows[0]!.tariff_line_id;

    // Measures + expressions
    const ms = await pool.query<any>(
      `SELECT m.measure_id, m.measure_type, e.expr_type, e.ast_json, e.source_ref
       FROM measure m
       JOIN expression e
         ON e.data_version_id=m.data_version_id AND e.expression_id=m.expression_id
       WHERE m.data_version_id=$1 AND m.tariff_line_id=$2 AND m.valid_range @> $3::date`,
      [dataVersionId, tariffLineId, asOfDate]
    );

    // VAT rule + base formula (optional)
    const vat = await pool.query<any>(
      `SELECT rate_pct
       FROM vat_rule
       WHERE data_version_id=$1 AND jurisdiction_id=$2 AND rate_type='STANDARD' AND valid_range @> $3::date
       LIMIT 1`,
      [dataVersionId, dataJurisdictionId, asOfDate]
    );
    const vatRatePct = vat.rowCount ? Number(vat.rows[0]!.rate_pct) : 0;

    const vb = await pool.query<any>(
      `SELECT ast_json
       FROM vat_base_formula
       WHERE data_version_id=$1 AND jurisdiction_id=$2 AND valid_range @> $3::date
       LIMIT 1`,
      [dataVersionId, dataJurisdictionId, asOfDate]
    );
    const vatBaseAst = vb.rowCount ? vb.rows[0]!.ast_json : null;

    // Required fields from measures
    const requiredFields = new Set<string>();
    requiredFields.add("customs_value");

    const unsupported: any[] = [];

    for (const r of ms.rows) {
      const ast = r.ast_json;
      const exprType = String(r.expr_type ?? "");

      if (exprType === "CUSTOM" || !isSupportedAst(ast)) {
        unsupported.push({
          measureId: r.measure_id,
          measureType: r.measure_type,
          reason: "manual_or_unsupported_expression",
          sourceRef: r.source_ref ?? null,
          ast,
        });
        continue;
      }
      collectAstFields(ast, requiredFields);
    }

    const inputs: InputSpec[] = [];
    inputs.push({
      field: "originCountry",
      type: "string",
      label: "Country of origin (ISO alpha-2)",
      required: true,
      reason: "Used to select preferential duty rates when available",
      placeholder: "e.g., CN",
      example: "CN",
    });
    inputs.push({
      field: "customsValue",
      type: "money",
      label: "Customs value",
      required: true,
      reason: "Required for duty/VAT calculation",
    });

    for (const f of requiredFields) {
      if (f === "customs_value") continue;
      const meta = FIELD_META[f];
      if (!meta) continue;
      inputs.push({
        field: meta.field,
        type: meta.type,
        unit: meta.unit,
        label: meta.label,
        required: true,
        reason: "Required by duty expression",
      });
    }

    const recommended: InputSpec[] = [];
    if (vatBaseAst) {
      const vatFields = new Set<string>();
      collectAstFields(vatBaseAst, vatFields);

      if (vatFields.has("freight_to_border")) {
        recommended.push({
          field: "freightToBorder",
          type: "money",
          label: "Freight to border",
          required: false,
          reason: `${vatLabel} base includes freight`,
        });
      }
      if (vatFields.has("insurance_to_border")) {
        recommended.push({
          field: "insuranceToBorder",
          type: "money",
          label: "Insurance to border",
          required: false,
          reason: `${vatLabel} base includes insurance`,
        });
      }
    }

    return reply.send({
      jurisdiction: { id: requestedJurisdictionId, currency, vatLabel, vatRatePct },
      dataVersionId,
      asOfDate,
      tariffLine: { code: tl.rows[0]!.code, description: tl.rows[0]!.description },
      inputs: { required: inputs, recommended },
      unsupported,
    });
  });
}