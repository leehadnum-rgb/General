from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha1
import re
from typing import Dict, List, Optional, Set, Tuple, Iterable
from datetime import datetime

from sqlalchemy.orm import Session

from app.db import models
from app.services.config_models import GIRConfig, Element, ErrorCode
from app.services.utils import try_parse_decimal, try_parse_date


@dataclass(frozen=True)
class Issue:
    severity: str  # BLOCKING/WARNING/INFO
    rule_id: str
    message: str
    how_to_fix: Optional[str] = None
    error_number: Optional[int] = None
    section: Optional[str] = None
    xml_path: Optional[str] = None
    filer_code: Optional[str] = None
    jurisdiction_code: Optional[str] = None
    entity_code: Optional[str] = None
    context_key: Optional[str] = None


def _rid(prefix: str, key: str) -> str:
    h = sha1(key.encode("utf-8")).hexdigest()[:10].upper()
    return f"{prefix}-{h}"


def _ancestors(xpath: str) -> List[str]:
    """Return all ancestor xpaths (excluding the xpath itself).

    Example: /a/b/c -> [/a/b, /a]
    """
    out: List[str] = []
    cur = xpath
    while "/" in cur:
        cur = cur.rsplit("/", 1)[0]
        if cur:
            out.append(cur)
        else:
            break
    return out



# -----------------------------
# Choice container overrides
# -----------------------------
#
# The extracted Excel config does not model XSD <choice> groups. In the OECD GIR
# schema, certain sibling containers (e.g., UPE/ExcludedUPE vs UPE/OtherUPE) are
# mutually exclusive. Without special handling, both branches appear 'required'
# and the engine produces false missing-required errors.
#
# Sprint 1.3: treat known choice-branches as optional 'gates'. Required leaf
# elements under these containers are only enforced when the branch is active
# (i.e., any datapoint exists beneath it).
CHOICE_CONTAINER_MIN_OCCURS_OVERRIDES: Dict[str, int] = {
    "/GLOBE_OECD/GLOBEBody/GeneralSection/CorporateStructure/UPE/ExcludedUPE": 0,
    "/GLOBE_OECD/GLOBEBody/GeneralSection/CorporateStructure/UPE/OtherUPE": 0,
}

def _build_container_index(config: GIRConfig) -> Dict[str, int]:
    """Map container xpath -> min_occurs.

    Includes:
    - container elements (complex types) from elements.json
    - section root containers from section_cardinality.json
    """
    containers: Dict[str, int] = {}
    for e in config.elements:
        if e.is_container and e.xpath:
            containers[e.xpath] = int(e.min_occurs or 0)
    for s in config.section_cardinality:
        if s.container_xpath:
            containers[s.container_xpath] = int(s.min_occurs or 0)
    # Apply choice overrides (see CHOICE_CONTAINER_MIN_OCCURS_OVERRIDES).
    for xp, mo in CHOICE_CONTAINER_MIN_OCCURS_OVERRIDES.items():
        containers[xp] = int(mo)

    return containers


def _deepest_optional_gate(leaf_xpath: str, containers_min_occurs: Dict[str, int]) -> Optional[str]:
    """Find the deepest optional container (minOccurs=0) in the leaf's ancestor chain.

    This is the container we use to gate requiredness to reduce false positives for
    optional blocks.
    """
    for anc in _ancestors(leaf_xpath):
        mo = containers_min_occurs.get(anc)
        if mo is None:
            continue
        if mo == 0:
            return anc
    return None


# -----------------------------
# Error code mapping helpers
# -----------------------------

def _error_by_number(config: GIRConfig) -> Dict[int, ErrorCode]:
    out: Dict[int, ErrorCode] = {}
    for ec in config.error_codes:
        if ec.number is None:
            continue
        out[int(ec.number)] = ec
    return out


def _oecd_fix_text(error_map: Dict[int, ErrorCode], number: int) -> Optional[str]:
    ec = error_map.get(number)
    if ec and ec.validation_description:
        return ec.validation_description
    return None



# -----------------------------
# Record type mapping helpers (DocSpec)
# -----------------------------
#
# Several OECD severe record errors refer to the DocTypeIndic of specific "record types"
# (FilingInfo, GeneralSection, Summary, JurisdictionSection, UTPRAttribution). Early
# versions of this engine used substring matching on xml_path, which can be brittle
# (eForm wrappers, variant roots, etc.). These helpers map record types explicitly
# using config-derived container xpaths and DocSpec/DocTypeIndic xpaths.

@dataclass(frozen=True)
class RecordTypeSpec:
    record_type: str
    section: str
    container_xpaths_lc: Set[str]
    doctypeindic_xpaths_lc: Set[str]


def _norm_xpath(xp: Optional[str]) -> str:
    """Normalize xpaths for robust matching across wrapper variants.

    The config extracted from the Excel/XSD toolkit sometimes includes an eForm wrapper
    segment like:
      /GLOBE_OECD/GLOBEBody/eForm/Payload/GLOBE_OECD/GLOBEBody/...

    while XML imports may produce:
      /GLOBE_OECD/GLOBEBody/...

    We collapse the wrapper segment when present.
    """
    if not xp:
        return ""
    x = xp.strip()
    x = x.replace(
        "/GLOBE_OECD/GLOBEBody/eForm/Payload/GLOBE_OECD/GLOBEBody",
        "/GLOBE_OECD/GLOBEBody",
    )
    x = x.replace(
        "/eForm/Payload/GLOBE_OECD/GLOBEBody",
        "/GLOBE_OECD/GLOBEBody",
    )
    x = re.sub(r"/{2,}", "/", x)
    return x


def _build_record_type_specs(config: GIRConfig) -> Dict[str, RecordTypeSpec]:
    """Build explicit record-type specifications from config.

    Returns a dict with keys:
      - FilingInfo
      - GeneralSection
      - Summary
      - JurisdictionSection
      - UTPRAttribution
    """
    containers_by_section: Dict[str, str] = {}
    for s in config.section_cardinality:
        if s.section and s.container_xpath:
            containers_by_section[s.section] = _norm_xpath(s.container_xpath).lower()

    doctype_by_section: Dict[str, Set[str]] = {}
    for e in config.elements:
        if not e.xpath:
            continue
        if (e.element_name or "").strip().lower() != "doctypeindic":
            continue
        sec = (e.section or "").strip()
        doctype_by_section.setdefault(sec, set()).add(_norm_xpath(e.xpath).lower())

    def _mk(record_type: str, section: str) -> RecordTypeSpec:
        cx = containers_by_section.get(section, "")
        dx = doctype_by_section.get(section, set())
        return RecordTypeSpec(
            record_type=record_type,
            section=section,
            container_xpaths_lc={cx} if cx else set(),
            doctypeindic_xpaths_lc=set(dx),
        )

    return {
        "FilingInfo": _mk("FilingInfo", "FilingInfo"),
        "GeneralSection": _mk("GeneralSection", "General"),
        "Summary": _mk("Summary", "Summary"),
        "JurisdictionSection": _mk("JurisdictionSection", "Jurisdiction"),
        "UTPRAttribution": _mk("UTPRAttribution", "UTPRAttribution"),
    }


def _filer_matches(dp_filer: Optional[str], filer: Optional[str]) -> bool:
    """Treat missing dp.filer_code as 'global' (matches any filer)."""
    if not filer:
        return True
    if not (dp_filer or "").strip():
        return True
    return dp_filer == filer


def _dp_xpath_lc(dp: models.DataPoint) -> str:
    return _norm_xpath(dp.xml_path).lower() if dp.xml_path else ""


def _record_present(dps: List[models.DataPoint], spec: RecordTypeSpec, filer: Optional[str]) -> bool:
    """Return True if any datapoint exists under the record container for the filer."""
    if not spec.container_xpaths_lc:
        return False
    for dp in dps:
        if not _filer_matches(dp.filer_code, filer):
            continue
        xp = _dp_xpath_lc(dp)
        for cx in spec.container_xpaths_lc:
            if cx and xp.startswith(cx):
                return True
    return False


def _record_doctype_dps(dps: List[models.DataPoint], spec: RecordTypeSpec, filer: Optional[str]) -> List[models.DataPoint]:
    """Return datapoints that correspond to DocSpec/DocTypeIndic for the record type."""
    if not spec.doctypeindic_xpaths_lc:
        return []
    out: List[models.DataPoint] = []
    for dp in dps:
        if not _filer_matches(dp.filer_code, filer):
            continue
        xp = _dp_xpath_lc(dp)
        if xp in spec.doctypeindic_xpaths_lc:
            out.append(dp)
    return out


# -----------------------------
# Scoping helpers
# -----------------------------

ScopeKind = str  # "filing" | "filer" | "jurisdiction" | "entity"


def _infer_scope(e: Element) -> ScopeKind:
    """Best-effort scope inference based on section and xpath.

    Sprint 1.2 goal: improve scoping so requiredness is not just "present somewhere".

    Principles:
    - Jurisdiction section is jurisdiction-scoped.
    - CE/ConstituentEntity/CEComputation blocks are entity-scoped.
    - FilingInfo is filer-scoped.
    - General/Summary/UTPRAttribution default to filer-scoped (but filing-level values
      satisfy all filers).
    """
    sec = (e.section or "").strip().lower()
    xp = (e.xpath or "").lower()

    if sec == "jurisdiction" or "jurisdictionsection" in xp:
        return "jurisdiction"

    # Entity-level constructs
    if any(tok in xp for tok in ["/cecomputation/", "/constituententity", "/corporatestructure/ce/", "nonmaterial"]):
        return "entity"

    if sec == "filinginfo" or "filingce" in xp:
        return "filer"

    if sec in {"general", "summary", "utprattribution"}:
        return "filer"

    return "filing"


def _build_presence_indexes(non_empty_dps: List[models.DataPoint]) -> dict:
    """Build sets for fast presence checks across scopes."""
    present_paths_global: Set[str] = set()
    present_by_filer: Set[Tuple[str, str]] = set()
    present_by_juris: Set[Tuple[str, str]] = set()
    present_by_entity: Set[Tuple[str, str]] = set()

    present_by_filer_juris: Set[Tuple[str, str, str]] = set()
    present_by_filer_entity: Set[Tuple[str, str, str]] = set()

    # Track "no-filer" subsets for jurisdiction/entity so filer-scoped checks can accept shared values.
    present_juris_no_filer: Set[Tuple[str, str]] = set()
    present_entity_no_filer: Set[Tuple[str, str]] = set()

    for dp in non_empty_dps:
        present_paths_global.add(dp.xml_path)

        if dp.filer_code:
            present_by_filer.add((dp.filer_code, dp.xml_path))

        if dp.jurisdiction_code:
            present_by_juris.add((dp.jurisdiction_code, dp.xml_path))
            if not dp.filer_code:
                present_juris_no_filer.add((dp.jurisdiction_code, dp.xml_path))

        if dp.entity_code:
            present_by_entity.add((dp.entity_code, dp.xml_path))
            if not dp.filer_code:
                present_entity_no_filer.add((dp.entity_code, dp.xml_path))

        if dp.filer_code and dp.jurisdiction_code:
            present_by_filer_juris.add((dp.filer_code, dp.jurisdiction_code, dp.xml_path))

        if dp.filer_code and dp.entity_code:
            present_by_filer_entity.add((dp.filer_code, dp.entity_code, dp.xml_path))

    return {
        "present_paths_global": present_paths_global,
        "present_by_filer": present_by_filer,
        "present_by_juris": present_by_juris,
        "present_by_entity": present_by_entity,
        "present_by_filer_juris": present_by_filer_juris,
        "present_by_filer_entity": present_by_filer_entity,
        "present_juris_no_filer": present_juris_no_filer,
        "present_entity_no_filer": present_entity_no_filer,
    }


def _build_activation_indexes(non_empty_dps: List[models.DataPoint], optional_containers: Set[str]) -> dict:
    """Build activation sets for optional blocks across scopes.

    A block is "active" for a scope if any non-empty datapoint exists under that container.
    """
    active_optional_global: Set[str] = set()
    active_optional_by_filer: Dict[str, Set[str]] = {}
    active_optional_by_juris: Dict[str, Set[str]] = {}
    active_optional_by_entity: Dict[str, Set[str]] = {}
    active_optional_by_filer_juris: Dict[Tuple[str, str], Set[str]] = {}
    active_optional_by_filer_entity: Dict[Tuple[str, str], Set[str]] = {}

    for dp in non_empty_dps:
        for anc in _ancestors(dp.xml_path):
            if anc not in optional_containers:
                continue
            active_optional_global.add(anc)
            if dp.filer_code:
                active_optional_by_filer.setdefault(dp.filer_code, set()).add(anc)
            if dp.jurisdiction_code:
                active_optional_by_juris.setdefault(dp.jurisdiction_code, set()).add(anc)
            if dp.entity_code:
                active_optional_by_entity.setdefault(dp.entity_code, set()).add(anc)
            if dp.filer_code and dp.jurisdiction_code:
                active_optional_by_filer_juris.setdefault((dp.filer_code, dp.jurisdiction_code), set()).add(anc)
            if dp.filer_code and dp.entity_code:
                active_optional_by_filer_entity.setdefault((dp.filer_code, dp.entity_code), set()).add(anc)

    return {
        "active_optional_global": active_optional_global,
        "active_optional_by_filer": active_optional_by_filer,
        "active_optional_by_juris": active_optional_by_juris,
        "active_optional_by_entity": active_optional_by_entity,
        "active_optional_by_filer_juris": active_optional_by_filer_juris,
        "active_optional_by_filer_entity": active_optional_by_filer_entity,
    }


def _is_gate_active(
    gate: Optional[str],
    *,
    filer: Optional[str],
    juris: Optional[str],
    entity: Optional[str],
    activation: dict,
    force_active: bool = False,
) -> bool:
    if gate is None:
        return True
    if force_active:
        return True

    if gate in activation["active_optional_global"]:
        return True

    if filer and gate in activation["active_optional_by_filer"].get(filer, set()):
        return True

    if juris and gate in activation["active_optional_by_juris"].get(juris, set()):
        return True

    if entity and gate in activation["active_optional_by_entity"].get(entity, set()):
        return True

    if filer and juris and gate in activation["active_optional_by_filer_juris"].get((filer, juris), set()):
        return True

    if filer and entity and gate in activation["active_optional_by_filer_entity"].get((filer, entity), set()):
        return True

    return False



# -----------------------------
# Register-driven datapoint bridge (Sprint 1.3)
# -----------------------------

DEFAULT_ID_RULES = "GIR201"
DEFAULT_GLOBE_STATUS = "GIR301"
DEFAULT_OWNERSHIP_TYPE = "GIR801"

def _dp_key(dp: models.DataPoint) -> Tuple[Optional[str], Optional[str], Optional[str], Optional[str], str]:
    return (dp.filer_code, dp.jurisdiction_code, dp.entity_code, dp.context_key, dp.xml_path)

def _make_virtual_dp(
    *,
    filing_id: str,
    xml_path: str,
    value_raw: str,
    filer_code: Optional[str] = None,
    jurisdiction_code: Optional[str] = None,
    entity_code: Optional[str] = None,
    context_key: Optional[str] = None,
    source_system: str = "register_bridge",
    notes: Optional[str] = None,
) -> models.DataPoint:
    now = datetime.utcnow()
    dp = models.DataPoint(
        filing_id=filing_id,
        filer_code=filer_code,
        jurisdiction_code=jurisdiction_code,
        entity_code=entity_code,
        context_key=context_key,
        xml_path=xml_path,
        value_raw=value_raw,
        source="derived",
        source_system=source_system,
        notes=notes,
        updated_at=now,
        created_at=now,
    )
    dp.value_numeric = try_parse_decimal(value_raw)
    dp.value_date = try_parse_date(value_raw)
    return dp

def _find_xpath(
    config: GIRConfig,
    *,
    section: Optional[str] = None,
    endswith: Optional[str] = None,
    contains: Optional[str] = None,
) -> Optional[str]:
    for e in config.elements:
        if section and (e.section or "") != section:
            continue
        xp = (e.xpath or "").strip()
        if not xp:
            continue
        if endswith and not xp.endswith(endswith):
            continue
        if contains and contains not in xp:
            continue
        return xp
    return None

def _gen_docrefid(prefix: str, filing_id: str, scope_key: str) -> str:
    """Generate a schema-friendly DocRefId.

    OECD severe record error **60011** expects a high-level format:
      [CountryCode][ReportingYear][UniqueID]

    For this web tool we generate a deterministic value that:
      - stays within the XSD 200 char max
      - matches the expected high-level pattern
      - is stable for a given (prefix, filing_id, scope_key)

    The `prefix` parameter is overloaded:
      - If prefix matches /^[A-Z]{2}\d{4}$/ then we treat it as CCYYYY
      - Otherwise we fall back to CC=XX and YYYY=1900

    Callers that *know* the CCYYYY should pass it via prefix.
    """
    key = f"{prefix}|{filing_id}|{scope_key}"
    h = sha1(key.encode("utf-8")).hexdigest()[:20].upper()

    cc = "XX"
    yyyy = "1900"
    if re.match(r"^[A-Z]{2}\d{4}$", (prefix or "")):
        cc = prefix[:2]
        yyyy = prefix[2:6]

    docref = f"{cc}{yyyy}{h}"
    return docref[:200]

def _map_filing_ce_role(filer: models.Filer) -> Optional[str]:
    # Prefer explicit GIR code if provided.
    if (filer.filing_ce_role or "").strip():
        return filer.filing_ce_role.strip()
    r = (filer.role or "").strip().upper()
    if r == "UPE":
        return "GIR401"
    if "DESIGNATED" in r:
        return "GIR402"
    if "LOCAL" in r:
        return "GIR403"
    if r in {"POPE", "CE", "CONSTITUENT"}:
        return "GIR404"
    if r:
        return "GIR405"
    return None

def _register_hint_for_xpath(xpath: str) -> Optional[str]:
    xp = xpath or ""
    # Filing register
    if xp.endswith("/FilingCE/Name"):
        return "Populate legal_name in the Filing Entity Register."
    if xp.endswith("/FilingCE/TIN"):
        return "Populate tin in the Filing Entity Register (or use NOTIN if applicable)."
    if xp.endswith("/FilingCE/Role"):
        return "Populate filing_ce_role (preferred) or role in the Filing Entity Register."
    if xp.endswith("/FilingInfo/Period/Start"):
        return "Populate period_start on the Filing record (or submit a datapoint for Period/Start)."
    if xp.endswith("/FilingInfo/Period/End"):
        return "Populate period_end on the Filing record (or submit a datapoint for Period/End)."
    if xp.endswith("/FilingInfo/AccountingInfo/Currency"):
        return "Populate reporting_currency on the Filing record (or submit a datapoint for AccountingInfo/Currency)."
    if xp.endswith("/DocSpec/DocTypeIndic") or xp.endswith("/DocSpec/DocRefId"):
        return "DocSpec values are auto-generated by the engine unless you override them via datapoints."

    # Constituent entity register
    if "/CorporateStructure/CE/ID/Name" in xp:
        return "Populate legal_name in the Constituent Entity Register for this entity."
    if "/CorporateStructure/CE/ID/ResCountryCode" in xp:
        return "Populate jurisdiction_code in the Constituent Entity Register for this entity."
    if "/CorporateStructure/CE/ID/TIN" in xp:
        return "Populate tin in the Constituent Entity Register for this entity (or use NOTIN if applicable)."
    if "/CorporateStructure/CE/ID/Rules" in xp:
        return "Populate id_rules in the Constituent Entity Register for this entity."
    if "/CorporateStructure/CE/ID/GlobeStatus" in xp:
        return "Populate globe_status in the Constituent Entity Register for this entity."
    if "/CorporateStructure/CE/Ownership/OwnershipType" in xp:
        return "Populate ownership_type (GIR801..GIR806) in the Constituent Entity Register for this entity."
    if "/CorporateStructure/CE/Ownership/OwnershipPercentage" in xp:
        return "Populate ownership_percentage in the Constituent Entity Register for this entity."
    if "/CorporateStructure/CE/Ownership/TIN" in xp:
        return "Provide owner_tin_override, or set parent_entity_code (with a TIN present on the parent), so the engine can derive the ownership holder TIN."

    # Jurisdiction register
    if xp.endswith("/JurisdictionSection/Jurisdiction"):
        return "Ensure this jurisdiction is present in the Jurisdiction Register."
    if xp.endswith("/JurisdictionSection/LocalCurrency"):
        return "Populate local_currency in the Jurisdiction Register (if required for your facts)."
    if xp.endswith("/JurisdictionSection/RecJurCode"):
        return "Populate the receiving jurisdiction(s). By default the engine uses the responsible filer's jurisdiction_code."

    return None

def derive_virtual_datapoints_from_registers(
    *,
    db: Session,
    filing: models.Filing,
    config: GIRConfig,
    filers: List[models.Filer],
    jurisdictions: List[models.Jurisdiction],
    entities: List[models.ConstituentEntity],
    existing_datapoints: List[models.DataPoint],
    suppress_if_exists: bool = True,
) -> List[models.DataPoint]:
    """Create non-persisted datapoints from registers (and filing header fields).

    These derived datapoints are used for validation scope/presence checks, so the
    engine can be 'register driven' rather than requiring users to manually
    populate datapoints for obvious header / identity fields.

    The rule is: *never override an explicit datapoint* (same key).
    """
    # Keys already explicitly provided by the user (persisted datapoints).
    # By default we suppress derived datapoints that would collide with these keys.
    occupied_keys: Set[Tuple[Optional[str], Optional[str], Optional[str], Optional[str], str]] = (
        {_dp_key(dp) for dp in existing_datapoints} if suppress_if_exists else set()
    )

    # Avoid duplicates in the derived output itself.
    seen_keys: Set[Tuple[Optional[str], Optional[str], Optional[str], Optional[str], str]] = set()

    out: List[models.DataPoint] = []

    def add(
        *,
        xml_path: Optional[str],
        value: Optional[str],
        filer_code: Optional[str] = None,
        jurisdiction_code: Optional[str] = None,
        entity_code: Optional[str] = None,
        context_key: Optional[str] = None,
        origin: Optional[str] = None,
    ):
        if not xml_path:
            return
        v = (value or "").strip()
        if v == "":
            return
        dp = _make_virtual_dp(
            filing_id=filing.id,
            xml_path=xml_path,
            value_raw=v,
            filer_code=filer_code,
            jurisdiction_code=jurisdiction_code,
            entity_code=entity_code,
            context_key=context_key,
            notes=origin,
        )
        k = _dp_key(dp)
        if k in occupied_keys:
            return
        if k in seen_keys:
            return
        seen_keys.add(k)
        out.append(dp)

    # --- XPaths (config driven) ---
    xp_filingce_name = _find_xpath(config, section="FilingInfo", endswith="/FilingCE/Name")
    xp_filingce_tin = _find_xpath(config, section="FilingInfo", endswith="/FilingCE/TIN")
    xp_filingce_role = _find_xpath(config, section="FilingInfo", endswith="/FilingCE/Role")

    xp_filing_period_start = _find_xpath(config, section="FilingInfo", endswith="/FilingInfo/Period/Start")
    xp_filing_period_end = _find_xpath(config, section="FilingInfo", endswith="/FilingInfo/Period/End")
    xp_filing_currency = _find_xpath(config, section="FilingInfo", endswith="/FilingInfo/AccountingInfo/Currency")

    xp_filing_doc_type = _find_xpath(config, section="FilingInfo", endswith="/DocSpec/DocTypeIndic")
    xp_filing_doc_ref = _find_xpath(config, section="FilingInfo", endswith="/DocSpec/DocRefId")

    xp_summary_recjur = _find_xpath(config, section="Summary", endswith="/Summary/RecJurCode")
    xp_summary_doc_type = _find_xpath(config, section="Summary", endswith="/Summary/DocSpec/DocTypeIndic")
    xp_summary_doc_ref = _find_xpath(config, section="Summary", endswith="/Summary/DocSpec/DocRefId")

    xp_general_recjur = _find_xpath(config, section="General", endswith="/GeneralSection/RecJurCode")

    xp_juris = _find_xpath(config, section="Jurisdiction", endswith="/JurisdictionSection/Jurisdiction")
    xp_juris_recjur = _find_xpath(config, section="Jurisdiction", endswith="/JurisdictionSection/RecJurCode")
    xp_juris_local_cur = _find_xpath(config, section="Jurisdiction", endswith="/JurisdictionSection/LocalCurrency")
    xp_juris_doc_type = _find_xpath(config, section="Jurisdiction", endswith="/JurisdictionSection/DocSpec/DocTypeIndic")
    xp_juris_doc_ref = _find_xpath(config, section="Jurisdiction", endswith="/JurisdictionSection/DocSpec/DocRefId")

    # CorporateStructure (UPE branch - OtherUPE)
    xp_upe_name = _find_xpath(config, section="General", contains="/CorporateStructure/UPE/OtherUPE/ID/Name")
    xp_upe_res = _find_xpath(config, section="General", contains="/CorporateStructure/UPE/OtherUPE/ID/ResCountryCode")
    xp_upe_tin = _find_xpath(config, section="General", contains="/CorporateStructure/UPE/OtherUPE/ID/TIN")
    xp_upe_rules = _find_xpath(config, section="General", contains="/CorporateStructure/UPE/OtherUPE/ID/Rules")
    xp_upe_status = _find_xpath(config, section="General", contains="/CorporateStructure/UPE/OtherUPE/ID/GlobeStatus")

    # CorporateStructure (CE)
    xp_ce_name = _find_xpath(config, section="General", contains="/CorporateStructure/CE/ID/Name")
    xp_ce_res = _find_xpath(config, section="General", contains="/CorporateStructure/CE/ID/ResCountryCode")
    xp_ce_tin = _find_xpath(config, section="General", contains="/CorporateStructure/CE/ID/TIN")
    xp_ce_rules = _find_xpath(config, section="General", contains="/CorporateStructure/CE/ID/Rules")
    xp_ce_status = _find_xpath(config, section="General", contains="/CorporateStructure/CE/ID/GlobeStatus")

    xp_own_type = _find_xpath(config, section="General", contains="/CorporateStructure/CE/Ownership/OwnershipType")
    xp_own_tin = _find_xpath(config, section="General", contains="/CorporateStructure/CE/Ownership/TIN")
    xp_own_pct = _find_xpath(config, section="General", contains="/CorporateStructure/CE/Ownership/OwnershipPercentage")

    # --- Filing header datapoints (global; satisfy all filers) ---
    add(xml_path=xp_filing_period_start, value=filing.period_start.isoformat() if filing.period_start else None, origin="filing.period_start")
    add(xml_path=xp_filing_period_end, value=filing.period_end.isoformat() if filing.period_end else None, origin="filing.period_end")
    add(xml_path=xp_filing_currency, value=filing.reporting_currency, origin="filing.reporting_currency")

    # --- Best-effort CCYYYY prefix for DocRefId generation ---
    # Prefer the UPE jurisdiction, then any filer jurisdiction, then infer from TIN.
    def _best_effort_ccyyyy() -> str:
        # 1) UPE filer jurisdiction
        upe = next((f for f in filers if (f.role or "").strip().upper() == "UPE" and (f.jurisdiction_code or "").strip()), None)
        if upe and (upe.jurisdiction_code or "").strip():
            cc = upe.jurisdiction_code.strip().upper()[:2]
        else:
            # 2) any filer jurisdiction
            any_f = next((f for f in filers if (f.jurisdiction_code or "").strip()), None)
            if any_f and (any_f.jurisdiction_code or "").strip():
                cc = any_f.jurisdiction_code.strip().upper()[:2]
            else:
                # 3) infer from TIN prefix (e.g. "US-...")
                tin = (filers[0].tin or "").strip() if filers else ""
                cc = (tin[:2].upper() if len(tin) >= 2 and tin[:2].isalpha() else "XX")

        year = (filing.period_end.year if filing.period_end else datetime.utcnow().year)
        return f"{cc}{year:04d}"

    ccyyyy = _best_effort_ccyyyy()

    # --- FilingInfo per filer ---
    for f in filers:
        fc = (f.filer_code or "").strip()
        if not fc:
            continue
        add(xml_path=xp_filingce_name, value=f.legal_name, filer_code=fc, origin="filer.legal_name")
        add(xml_path=xp_filingce_tin, value=f.tin, filer_code=fc, origin="filer.tin")
        add(xml_path=xp_filingce_role, value=_map_filing_ce_role(f), filer_code=fc, origin="filer.filing_ce_role_or_role_map")

        # DocSpec (auto-generated) for FilingInfo
        # Default to OECD1 (new record) for self-serve validation.
        add(xml_path=xp_filing_doc_type, value="OECD1", filer_code=fc, origin="auto_generated:filinginfo.docspec.doctype")
        add(xml_path=xp_filing_doc_ref, value=_gen_docrefid(ccyyyy, filing.id, f"FILINFO:{fc}"), filer_code=fc, origin="auto_generated:filinginfo.docspec.docrefid")

    # --- Summary (global) ---
    add(xml_path=xp_summary_doc_type, value="OECD1", origin="auto_generated:summary.docspec.doctype")
    add(xml_path=xp_summary_doc_ref, value=_gen_docrefid(ccyyyy, filing.id, "SUMMARY:GLOBAL"), origin="auto_generated:summary.docspec.docrefid")

    # --- Receiving jurisdiction codes (global, repeatable) ---
    juris_codes = sorted({(j.jurisdiction_code or "").strip().upper() for j in jurisdictions if (j.jurisdiction_code or "").strip()})
    for code in juris_codes:
        add(xml_path=xp_general_recjur, value=code, context_key=f"GEN_RECJUR:{code}", origin="jurisdiction_register.jurisdiction_code")
        add(xml_path=xp_summary_recjur, value=code, context_key=f"SUM_RECJUR:{code}", origin="jurisdiction_register.jurisdiction_code")

    # --- JurisdictionSection (per jurisdiction) ---
    filers_by_code: Dict[str, models.Filer] = {f.filer_code: f for f in filers if f.filer_code}
    for j in jurisdictions:
        jc = (j.jurisdiction_code or "").strip().upper()
        if not jc:
            continue
        responsible = (j.responsible_filer_code or "").strip() or None
        responsible_filer = filers_by_code.get(responsible) if responsible else None
        rec = (responsible_filer.jurisdiction_code or "").strip().upper() if responsible_filer else None
        add(xml_path=xp_juris, value=jc, jurisdiction_code=jc, filer_code=responsible, origin="jurisdiction_register.jurisdiction_code")
        add(xml_path=xp_juris_recjur, value=rec or jc, jurisdiction_code=jc, filer_code=responsible, origin="jurisdiction_register.responsible_filer_or_jurisdiction")
        add(xml_path=xp_juris_local_cur, value=j.local_currency, jurisdiction_code=jc, filer_code=responsible, origin="jurisdiction_register.local_currency")
        add(xml_path=xp_juris_doc_type, value="OECD1", jurisdiction_code=jc, filer_code=responsible, origin="auto_generated:jurisdiction.docspec.doctype")
        add(xml_path=xp_juris_doc_ref, value=_gen_docrefid(ccyyyy, filing.id, f"JUR:{jc}:{responsible or 'GLOBAL'}"), jurisdiction_code=jc, filer_code=responsible, origin="auto_generated:jurisdiction.docspec.docrefid")

    # --- CorporateStructure: UPE ---
    upe_filers = [f for f in filers if (f.role or "").strip().upper() == "UPE"]
    for upe in upe_filers:
        u_code = (upe.filer_code or "").strip() or "UPE"
        ctx = f"UPE:{u_code}"
        add(xml_path=xp_upe_name, value=upe.legal_name, context_key=ctx, origin="filer_register(role=UPE).legal_name")
        add(xml_path=xp_upe_res, value=upe.jurisdiction_code, context_key=ctx, origin="filer_register(role=UPE).jurisdiction_code")
        add(xml_path=xp_upe_tin, value=upe.tin, context_key=ctx, origin="filer_register(role=UPE).tin")
        add(xml_path=xp_upe_rules, value=(upe.id_rules or DEFAULT_ID_RULES), context_key=ctx, origin="filer_register(role=UPE).id_rules_or_default")
        add(xml_path=xp_upe_status, value=(upe.globe_status or DEFAULT_GLOBE_STATUS), context_key=ctx, origin="filer_register(role=UPE).globe_status_or_default")

    # --- CorporateStructure: Constituent entities (included) ---
    entities_by_code: Dict[str, models.ConstituentEntity] = {e.entity_code: e for e in entities if e.entity_code}
    upe_tin = (upe_filers[0].tin or "").strip() if upe_filers else None

    def owner_tin(ent: models.ConstituentEntity) -> Tuple[Optional[str], str]:
        """Return (owner_tin_value, origin_string)."""
        if (ent.owner_tin_override or "").strip():
            return ent.owner_tin_override.strip(), "entity_register.owner_tin_override"
        p = (ent.parent_entity_code or "").strip()
        if p and p in entities_by_code and (entities_by_code[p].tin or "").strip():
            return entities_by_code[p].tin.strip(), f"entity_register.parent_entity_code({p}).tin"
        fb = (ent.filed_by_filer_code or "").strip()
        if fb and fb in filers_by_code and (filers_by_code[fb].tin or "").strip():
            return filers_by_code[fb].tin.strip(), f"filer_register({fb}).tin"
        if upe_tin and upe_tin.strip():
            return upe_tin.strip(), "filer_register(role=UPE).tin"
        return None, "unresolved"

    for ent in entities:
        if not ent.included_in_gir:
            continue
        ec = (ent.entity_code or "").strip()
        if not ec:
            continue
        ctx = f"CE:{ec}"
        fc = (ent.filed_by_filer_code or "").strip() or None
        add(xml_path=xp_ce_name, value=ent.legal_name, entity_code=ec, filer_code=fc, context_key=ctx, origin="entity_register.legal_name")
        add(xml_path=xp_ce_res, value=ent.jurisdiction_code, entity_code=ec, filer_code=fc, context_key=ctx, origin="entity_register.jurisdiction_code")
        add(xml_path=xp_ce_tin, value=ent.tin, entity_code=ec, filer_code=fc, context_key=ctx, origin="entity_register.tin")
        add(xml_path=xp_ce_rules, value=(ent.id_rules or DEFAULT_ID_RULES), entity_code=ec, filer_code=fc, context_key=ctx, origin="entity_register.id_rules_or_default")
        add(xml_path=xp_ce_status, value=(ent.globe_status or DEFAULT_GLOBE_STATUS), entity_code=ec, filer_code=fc, context_key=ctx, origin="entity_register.globe_status_or_default")

        add(xml_path=xp_own_type, value=(ent.ownership_type or DEFAULT_OWNERSHIP_TYPE), entity_code=ec, filer_code=fc, context_key=ctx, origin="entity_register.ownership_type_or_default")
        own_tin_val, own_tin_origin = owner_tin(ent)
        add(xml_path=xp_own_tin, value=own_tin_val, entity_code=ec, filer_code=fc, context_key=ctx, origin=own_tin_origin)
        add(
            xml_path=xp_own_pct,
            value=str(ent.ownership_percentage) if ent.ownership_percentage is not None else None,
            entity_code=ec,
            filer_code=fc,
            context_key=ctx,
            origin="entity_register.ownership_percentage",
        )

    return out

def run_validations(db: Session, filing_id: str, config: GIRConfig) -> List[Issue]:
    # Load filing + registers + datapoints.
    filing = db.get(models.Filing, filing_id)
    if filing is None:
        # Should be prevented by the API layer, but keep validation_engine robust.
        return [Issue(
            severity="BLOCKING",
            rule_id=_rid("SYS", f"missing_filing|{filing_id}"),
            section="General",
            message="Filing not found.",
            how_to_fix="Create the filing first, then retry validation.",
        )]

    dps: List[models.DataPoint] = (
        db.query(models.DataPoint)
        .filter(models.DataPoint.filing_id == filing_id)
        .all()
    )

    filers: List[models.Filer] = (
        db.query(models.Filer).filter(models.Filer.filing_id == filing_id).all()
    )
    juris_rows: List[models.Jurisdiction] = (
        db.query(models.Jurisdiction).filter(models.Jurisdiction.filing_id == filing_id).all()
    )
    entity_rows: List[models.ConstituentEntity] = (
        db.query(models.ConstituentEntity).filter(models.ConstituentEntity.filing_id == filing_id).all()
    )

    # Sprint 1.3: derive datapoints from registers so validations can be register-driven.
    virtual_dps = derive_virtual_datapoints_from_registers(
        db=db,
        filing=filing,
        config=config,
        filers=filers,
        jurisdictions=juris_rows,
        entities=entity_rows,
        existing_datapoints=dps,
    )
    all_dps: List[models.DataPoint] = list(dps) + list(virtual_dps)
    # "Submission view" datapoints: excludes engine-derived helper datapoints.
    # Many OECD severe record errors are defined against the submitted XML.
    submission_dps: List[models.DataPoint] = [dp for dp in all_dps if (dp.source or "").lower() != "derived"]

    # Build element lookup for type / allowed values checks.
    elements_by_path: Dict[str, Element] = {e.xpath: e for e in config.elements if e.xpath}

    non_empty_dps: List[models.DataPoint] = [dp for dp in all_dps if (dp.value_raw or "").strip() != ""]
    presence = _build_presence_indexes(non_empty_dps)

    issues: List[Issue] = []

    # -----------------------------
    # 0) Precompute config-driven helper indexes
    # -----------------------------
    containers_min_occurs = _build_container_index(config)
    optional_containers: Set[str] = {xp for xp, mo in containers_min_occurs.items() if mo == 0}
    activation = _build_activation_indexes(non_empty_dps, optional_containers)

    error_map = _error_by_number(config)

    # Expected filers (prefer register; fallback to datapoints)
    expected_filers: List[str] = sorted({f.filer_code for f in filers if (f.filer_code or "").strip()})
    if not expected_filers:
        expected_filers = sorted({dp.filer_code for dp in all_dps if dp.filer_code})

    # Expected jurisdictions (prefer register; fallback to datapoints)
    responsible_by_juris: Dict[str, Optional[str]] = {
        j.jurisdiction_code: (j.responsible_filer_code or None)
        for j in juris_rows
    }
    expected_jurisdictions: List[str] = sorted({j.jurisdiction_code for j in juris_rows})
    if not expected_jurisdictions:
        expected_jurisdictions = sorted({dp.jurisdiction_code for dp in all_dps if dp.jurisdiction_code})

    # Expected entities (prefer register; fallback to datapoints)
    filed_by_entity: Dict[str, Optional[str]] = {
        e.entity_code: (e.filed_by_filer_code or None)
        for e in entity_rows
        if e.entity_code
    }
    expected_entities: List[str] = sorted({e.entity_code for e in entity_rows if e.included_in_gir and e.entity_code})
    if not expected_entities:
        expected_entities = sorted({dp.entity_code for dp in all_dps if dp.entity_code})

    # Jurisdiction section root container (optional overall, but can be expected per jurisdiction)
    juris_section_container = next(
        (s.container_xpath for s in config.section_cardinality if s.section == "Jurisdiction"),
        None,
    )

    # Helpful inference: if jurisdiction_code is not set on the datapoint but the
    # value of RecJurCode/Jurisdiction looks like an ISO-2 code, treat it as
    # belonging to that jurisdiction for scoping checks.
    # (We add these to presence indexes in a minimal way.)
    for dp in non_empty_dps:
        if dp.jurisdiction_code:
            continue
        if not dp.xml_path:
            continue
        if not (dp.xml_path.endswith("/RecJurCode") or dp.xml_path.endswith("/Jurisdiction")):
            continue
        code = (dp.value_raw or "").strip().upper()
        if len(code) == 2 and code.isalpha():
            presence["present_by_juris"].add((code, dp.xml_path))
            if dp.filer_code:
                presence["present_by_filer_juris"].add((dp.filer_code, code, dp.xml_path))
            else:
                presence["present_juris_no_filer"].add((code, dp.xml_path))

    # -----------------------------
    # 1) Generated validations (Sprint 1.2)
    # -----------------------------

    # 1a) Required leaf element presence (scope-aware)
    required_elements = [
        e for e in config.elements
        if (not e.is_container) and (e.min_occurs or 0) >= 1 and e.required
    ]

    def _present_for_filer(filer: str, xpath: str) -> bool:
        return (
            xpath in presence["present_paths_global"]
            or (filer, xpath) in presence["present_by_filer"]
        )

    def _present_for_juris(juris: str, xpath: str, filer: Optional[str]) -> bool:
        if filer:
            # Prefer scoped datapoints for the responsible filer; allow "no-filer" shared datapoints.
            return (
                (filer, juris, xpath) in presence["present_by_filer_juris"]
                or (juris, xpath) in presence["present_juris_no_filer"]
            )
        # If no responsible filer is defined, accept any filer scoped to that jurisdiction.
        return (juris, xpath) in presence["present_by_juris"]

    def _present_for_entity(entity: str, xpath: str, filer: Optional[str]) -> bool:
        if filer:
            return (
                (filer, entity, xpath) in presence["present_by_filer_entity"]
                or (entity, xpath) in presence["present_entity_no_filer"]
            )
        return (entity, xpath) in presence["present_by_entity"]

    for e in required_elements:
        scope = _infer_scope(e)
        gate = _deepest_optional_gate(e.xpath, containers_min_occurs)

        if scope == "jurisdiction" and expected_jurisdictions:
            for juris in expected_jurisdictions:
                responsible = responsible_by_juris.get(juris)
                filer_for_scope = responsible

                # Special case: treat JurisdictionSection root as active if the jurisdiction is expected.
                force_active = bool(juris_section_container and gate == juris_section_container)

                if not _is_gate_active(
                    gate,
                    filer=filer_for_scope,
                    juris=juris,
                    entity=None,
                    activation=activation,
                    force_active=force_active,
                ):
                    continue

                if not _present_for_juris(juris, e.xpath, filer_for_scope):
                    issues.append(Issue(
                        severity="BLOCKING",
                        rule_id=_rid("REQJ", f"{e.xpath}|{juris}|{filer_for_scope or ''}"),
                        section=e.section,
                        xml_path=e.xpath,
                        filer_code=filer_for_scope,
                        jurisdiction_code=juris,
                        message=(
                            f"Missing required element for jurisdiction {juris}"
                            + (f" (responsible filer {filer_for_scope})" if filer_for_scope else "")
                            + f": {e.tax_label} ({e.xpath})"
                        ),
                        how_to_fix=_register_hint_for_xpath(e.xpath) or "Provide a value for this required field for the jurisdiction.",
                    ))
            continue

        if scope == "entity" and expected_entities:
            for entity in expected_entities:
                filer_for_scope = filed_by_entity.get(entity)

                if not _is_gate_active(
                    gate,
                    filer=filer_for_scope,
                    juris=None,
                    entity=entity,
                    activation=activation,
                ):
                    continue

                if not _present_for_entity(entity, e.xpath, filer_for_scope):
                    issues.append(Issue(
                        severity="BLOCKING",
                        rule_id=_rid("REQE", f"{e.xpath}|{entity}|{filer_for_scope or ''}"),
                        section=e.section,
                        xml_path=e.xpath,
                        filer_code=filer_for_scope,
                        entity_code=entity,
                        message=(
                            f"Missing required element for entity {entity}"
                            + (f" (filed by {filer_for_scope})" if filer_for_scope else "")
                            + f": {e.tax_label} ({e.xpath})"
                        ),
                        how_to_fix=_register_hint_for_xpath(e.xpath) or "Provide a value for this required field for the entity.",
                    ))
            continue

        if scope == "filer" and expected_filers:
            for filer in expected_filers:
                if not _is_gate_active(
                    gate,
                    filer=filer,
                    juris=None,
                    entity=None,
                    activation=activation,
                ):
                    continue

                if not _present_for_filer(filer, e.xpath):
                    issues.append(Issue(
                        severity="BLOCKING",
                        rule_id=_rid("REQF", f"{e.xpath}|{filer}"),
                        section=e.section,
                        xml_path=e.xpath,
                        filer_code=filer,
                        message=f"Missing required element for filer {filer}: {e.tax_label} ({e.xpath})",
                        how_to_fix=_register_hint_for_xpath(e.xpath) or "Provide a value for this required field for the filing entity.",
                    ))
            continue

        # Filing-level presence (gated by optional containers)
        if not _is_gate_active(
            gate,
            filer=None,
            juris=None,
            entity=None,
            activation=activation,
        ):
            continue

        if e.xpath not in presence["present_paths_global"]:
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("REQ", e.xpath),
                section=e.section,
                xml_path=e.xpath,
                message=f"Missing required element: {e.tax_label} ({e.xpath})",
                how_to_fix=_register_hint_for_xpath(e.xpath) or "Provide a value for this required field.",
            ))

    # 1b) Allowed values (enums / code lists)
    for dp in all_dps:
        e = elements_by_path.get(dp.xml_path)
        if e is None:
            continue  # unknown path
        allowed = list(e.allowed_values or [])
        if not allowed:
            continue
        v = (dp.value_raw or "").strip()
        if v == "":
            continue
        if v not in allowed:
            preview = ", ".join(allowed[:20])
            more = "" if len(allowed) <= 20 else f" (+{len(allowed)-20} more)"
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("ENUM", f"{dp.xml_path}|{v}|{dp.filer_code}|{dp.jurisdiction_code}|{dp.entity_code}|{dp.context_key}"),
                section=e.section,
                xml_path=dp.xml_path,
                filer_code=dp.filer_code,
                jurisdiction_code=dp.jurisdiction_code,
                entity_code=dp.entity_code,
                context_key=dp.context_key,
                message=f"Invalid value '{v}' for {e.tax_label}. Allowed: {preview}{more}",
                how_to_fix="Select/submit a value from the allowed code list.",
            ))

    # 1c) Basic datatype sanity (best-effort)
    for dp in all_dps:
        e = elements_by_path.get(dp.xml_path)
        if e is None or not e.xsd_type:
            continue
        v = (dp.value_raw or "").strip()
        if v == "":
            continue
        t = e.xsd_type.lower()
        if "date" in t and dp.value_date is None:
            issues.append(Issue(
                severity="WARNING",
                rule_id=_rid("TYPE", f"date|{dp.xml_path}|{v}|{dp.filer_code}|{dp.jurisdiction_code}|{dp.entity_code}|{dp.context_key}"),
                section=e.section,
                xml_path=dp.xml_path,
                filer_code=dp.filer_code,
                jurisdiction_code=dp.jurisdiction_code,
                entity_code=dp.entity_code,
                context_key=dp.context_key,
                message=f"Value '{v}' does not look like a valid date for {e.tax_label}.",
                how_to_fix="Provide the date in ISO format (YYYY-MM-DD) or as required by your data source.",
            ))
        if any(x in t for x in ["decimal", "integer", "nonnegativeinteger", "positiveinteger"]) and dp.value_numeric is None:
            issues.append(Issue(
                severity="WARNING",
                rule_id=_rid("TYPE", f"num|{dp.xml_path}|{v}|{dp.filer_code}|{dp.jurisdiction_code}|{dp.entity_code}|{dp.context_key}"),
                section=e.section,
                xml_path=dp.xml_path,
                filer_code=dp.filer_code,
                jurisdiction_code=dp.jurisdiction_code,
                entity_code=dp.entity_code,
                context_key=dp.context_key,
                message=f"Value '{v}' does not look like a valid number for {e.tax_label}.",
                how_to_fix="Provide a numeric value (e.g., 123.45).",
            ))

    # -----------------------------
    # 2) Bespoke validations (expanded / scoped)
    # -----------------------------

    filer_codes = {f.filer_code for f in filers}

    # 2a) Exactly one UPE filer (best-effort; assumes role='UPE')
    upe_filers = [f for f in filers if (f.role or "").strip().upper() == "UPE"]
    if len(upe_filers) != 1:
        issues.append(Issue(
            severity="BLOCKING",
            rule_id=_rid("BIZ", "upe_count"),
            section="General",
            message=f"Expected exactly 1 UPE filer in Filing Entity Register, found {len(upe_filers)}.",
            how_to_fix="Ensure one (and only one) filer has role 'UPE'.",
        ))

    # 2b) Included entities must map to an existing filer when multiple filers exist
    multi_filer = len(filers) > 1
    for ent in entity_rows:
        if not ent.included_in_gir:
            continue
        fb = (ent.filed_by_filer_code or "").strip()
        if fb == "":
            if multi_filer:
                issues.append(Issue(
                    severity="BLOCKING",
                    rule_id=_rid("BIZ", f"missing_filed_by|{ent.entity_code}"),
                    section="General",
                    entity_code=ent.entity_code,
                    message=f"Included entity '{ent.entity_code}' is missing filed_by_filer_code in a multi-filer filing.",
                    how_to_fix="Populate filed_by_filer_code for this entity to assign it to a filing entity (UPE/POPE/designated).",
                ))
            continue
        if fb not in filer_codes:
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("BIZ", f"invalid_filed_by|{ent.entity_code}|{fb}"),
                section="General",
                entity_code=ent.entity_code,
                message=f"Included entity '{ent.entity_code}' references unknown filer '{fb}'.",
                how_to_fix="Fix filed_by_filer_code to match a filer_code in the Filing Entity Register.",
            ))

    # 2c) DocRefId uniqueness and CorrDocRefId referential integrity (scoped per filer)
    #      This avoids false positives when one Filing contains multiple filer submissions.
    docref_paths = [p for p in {dp.xml_path for dp in all_dps} if p.lower().endswith("docrefid") and not p.lower().endswith("corrdocrefid")]
    corr_paths = [p for p in {dp.xml_path for dp in all_dps} if p.lower().endswith("corrdocrefid")]

    # Group datapoints by filer_code (None is its own group)
    def _filer_group(dp: models.DataPoint) -> Optional[str]:
        return dp.filer_code

    dps_by_filer: Dict[Optional[str], List[models.DataPoint]] = {}
    for dp in all_dps:
        dps_by_filer.setdefault(_filer_group(dp), []).append(dp)

    from collections import Counter

    for filer, rows in dps_by_filer.items():
        # Collect DocRefId
        docref_values: List[str] = []
        for dp in rows:
            if dp.xml_path not in docref_paths:
                continue
            v = (dp.value_raw or "").strip()
            if v:
                docref_values.append(v)

        docref_counter = Counter(docref_values)
        duplicates = [v for v, c in docref_counter.items() if c > 1]
        if duplicates:
            preview = ", ".join(duplicates[:10])
            more = "" if len(duplicates) <= 10 else f" (+{len(duplicates)-10} more)"
            num = 60007 if 60007 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("DOC", f"dup_docrefid|{filer or 'GLOBAL'}"),
                section="FilingInfo",
                filer_code=filer,
                error_number=num,
                message=(
                    f"Duplicate DocRefId values detected for filer {filer or 'GLOBAL'}: {preview}{more}."
                ),
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure every DocRefId is unique within the submission.",
            ))

        docref_set = set(docref_counter.keys())

        # Collect CorrDocRefId
        corr_values: List[str] = []
        for dp in rows:
            if dp.xml_path not in corr_paths:
                continue
            v = (dp.value_raw or "").strip()
            if v:
                corr_values.append(v)

        # 60006: same docref corrected/deleted twice in same message
        corr_counter = Counter(corr_values)
        corr_dups = [v for v, c in corr_counter.items() if c > 1]
        if corr_dups:
            preview = ", ".join(corr_dups[:10])
            more = "" if len(corr_dups) <= 10 else f" (+{len(corr_dups)-10} more)"
            num = 60006 if 60006 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("DOC", f"dup_corrdocrefid|{filer or 'GLOBAL'}"),
                section="FilingInfo",
                filer_code=filer,
                error_number=num,
                message=f"The same CorrDocRefId is used more than once for filer {filer or 'GLOBAL'}: {preview}{more}.",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure each DocRefId is corrected/deleted at most once per submission.",
            ))

        # 60008: CorrDocRefId refers to an unknown record
        missing_corr_refs = sorted({v for v in corr_values if v not in docref_set})
        if missing_corr_refs:
            preview = ", ".join(missing_corr_refs[:10])
            more = "" if len(missing_corr_refs) <= 10 else f" (+{len(missing_corr_refs)-10} more)"
            num = 60008 if 60008 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("DOC", f"missing_corr_ref|{filer or 'GLOBAL'}"),
                section="FilingInfo",
                filer_code=filer,
                error_number=num,
                message=f"CorrDocRefId values not found among DocRefId values for filer {filer or 'GLOBAL'}: {preview}{more}.",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "CorrDocRefId must reference an existing DocRefId from a previous submission.",
            ))

    # 2d) DocTypeIndic <-> CorrDocRefId consistency (scoped to the same DocSpec container)
    correction_types = {"OECD2", "OECD3", "OECD12", "OECD13"}

    # Build fast lookup by full key (filer/juris/entity/context + xml_path)
    key_to_dp: Dict[Tuple[Optional[str], Optional[str], Optional[str], Optional[str], str], models.DataPoint] = {}
    for dp in all_dps:
        key_to_dp[(dp.filer_code, dp.jurisdiction_code, dp.entity_code, dp.context_key, dp.xml_path)] = dp

    # CorrDocRefId present but DocTypeIndic is OECD0/OECD1 (OECD 60012)
    for dp in all_dps:
        if not dp.xml_path.lower().endswith("corrdocrefid"):
            continue
        corr_val = (dp.value_raw or "").strip()
        if not corr_val:
            continue
        base = dp.xml_path.rsplit("/", 1)[0]
        doc_type_path = base + "/DocTypeIndic"
        doc_type_dp = key_to_dp.get((dp.filer_code, dp.jurisdiction_code, dp.entity_code, dp.context_key, doc_type_path))
        if doc_type_dp is None:
            continue
        dt = (doc_type_dp.value_raw or "").strip()
        if dt in {"OECD0", "OECD1"}:
            num = 60012 if 60012 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("DOC", f"corr_present_non_correction|{dp.filer_code}|{dp.jurisdiction_code}|{dp.entity_code}|{dp.context_key}|{dp.xml_path}"),
                section="FilingInfo",
                filer_code=dp.filer_code,
                jurisdiction_code=dp.jurisdiction_code,
                entity_code=dp.entity_code,
                context_key=dp.context_key,
                xml_path=dp.xml_path,
                error_number=num,
                message=f"CorrDocRefId must be omitted when DocTypeIndic is '{dt}'.",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Remove CorrDocRefId or set DocTypeIndic to a correction/deletion code.",
            ))

    # DocTypeIndic indicates correction but CorrDocRefId missing
    for dp in all_dps:
        if not dp.xml_path.lower().endswith("doctypeindic"):
            continue
        dt = (dp.value_raw or "").strip()
        if dt not in correction_types:
            continue

        base = dp.xml_path.rsplit("/", 1)[0]
        corr_path = base + "/CorrDocRefId"
        corr_dp = key_to_dp.get((dp.filer_code, dp.jurisdiction_code, dp.entity_code, dp.context_key, corr_path))
        corr_val = (corr_dp.value_raw or "").strip() if corr_dp else ""
        if not corr_val:
            num = 60015 if 60015 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("DOC", f"missing_corrdocrefid|{dp.filer_code}|{dp.jurisdiction_code}|{dp.entity_code}|{dp.context_key}|{corr_path}|{dt}"),
                section="FilingInfo",
                filer_code=dp.filer_code,
                jurisdiction_code=dp.jurisdiction_code,
                entity_code=dp.entity_code,
                context_key=dp.context_key,
                xml_path=corr_path,
                error_number=num,
                message=f"DocTypeIndic='{dt}' indicates a correction/deletion but CorrDocRefId is missing.",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Provide CorrDocRefId referencing the prior DocRefId.",
            ))

    # -----------------------------
    # 2e) OECD 600xx severe record errors (single-file, best-effort)
    # -----------------------------

    # Helper: string value
    def _v(dp: models.DataPoint) -> str:
        return (dp.value_raw or "").strip()

    # 60001: MessageRefId format
    msgref_dps = [dp for dp in submission_dps if (dp.xml_path or "").endswith("/MessageRefId")]
    # Accept a high-level pattern: CCYYYYCCUnique (<= 200 chars)
    msgref_re = re.compile(r"^[A-Z]{2}\d{4}[A-Z]{2}[A-Za-z0-9][A-Za-z0-9\-_.:]{0,193}$")
    for dp in msgref_dps:
        val = _v(dp)
        if not val:
            continue
        if len(val) > 200 or not msgref_re.match(val):
            num = 60001 if 60001 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("OECD", f"60001|{dp.xml_path}|{val}"),
                section="GLOBEHeader",
                xml_path=dp.xml_path,
                filer_code=dp.filer_code,
                error_number=num,
                message=f"MessageRefId '{val}' does not match the expected format (CCYYYYCCUniqueID).",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure MessageRefId follows the OECD structure and is <= 200 characters.",
            ))

    # Extract header reporting period end date / year (best-effort)
    header_period_end = None
    # Prefer explicit EndDate within GLOBEHeader/ReportingPeriod
    for dp in submission_dps:
        p = (dp.xml_path or "").lower()
        if "globeheader" not in p or "reportingperiod" not in p:
            continue
        if not (p.endswith("enddate") or p.endswith("/enddate") or p.endswith("/end")):
            continue
        if dp.value_date:
            header_period_end = dp.value_date
            break
    # Fallback: any date under GLOBEHeader/ReportingPeriod
    if header_period_end is None:
        for dp in submission_dps:
            p = (dp.xml_path or "").lower()
            if "globeheader" not in p or "reportingperiod" not in p:
                continue
            if dp.value_date:
                header_period_end = dp.value_date
                break

    # 60003: ReportingPeriod year <= current year
    if header_period_end is not None:
        current_year = datetime.utcnow().year
        if header_period_end.year > current_year:
            num = 60003 if 60003 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("OECD", f"60003|{header_period_end.isoformat()}"),
                section="GLOBEHeader",
                error_number=num,
                message=f"ReportingPeriod year {header_period_end.year} is later than the current year {current_year}.",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Set ReportingPeriod to the correct year (<= current year).",
            ))

    # 60004: mixture of new (OECD1) and corrections (OECD2/OECD3) in a message
    doc_types = {(_v(dp)) for dp in all_dps if (dp.xml_path or "").lower().endswith("doctypeindic") and _v(dp)}
    has_new = "OECD1" in doc_types
    has_corr = any(dt in {"OECD2", "OECD3", "OECD12", "OECD13"} for dt in doc_types)
    if has_new and has_corr:
        num = 60004 if 60004 in error_map else None
        issues.append(Issue(
            severity="BLOCKING",
            rule_id=_rid("OECD", f"60004|{sorted(doc_types)}"),
            section="FilingInfo",
            error_number=num,
            message="This message contains a mix of new records (OECD1) and correction/deletion records (OECD2/OECD3).",
            how_to_fix=_oecd_fix_text(error_map, num) if num else "Do not mix new records and corrections in the same message; submit separate messages.",
        ))

    # 60011: DocRefId format (CCYYYYUniqueID)
    docref_re = re.compile(r"^[A-Z]{2}\d{4}[A-Za-z0-9][A-Za-z0-9\-_.:]{0,193}$")
    for dp in all_dps:
        p = (dp.xml_path or "").lower()
        if not p.endswith("docrefid") or p.endswith("corrdocrefid"):
            continue
        val = _v(dp)
        if not val:
            continue
        if len(val) > 200 or not docref_re.match(val):
            num = 60011 if 60011 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("OECD", f"60011|{dp.xml_path}|{val}|{dp.filer_code}|{dp.jurisdiction_code}|{dp.entity_code}|{dp.context_key}"),
                section=dp.xml_path.split("/")[3] if dp.xml_path.startswith("/") and len(dp.xml_path.split("/")) > 3 else "FilingInfo",
                xml_path=dp.xml_path,
                filer_code=dp.filer_code,
                jurisdiction_code=dp.jurisdiction_code,
                entity_code=dp.entity_code,
                context_key=dp.context_key,
                error_number=num,
                message=f"DocRefId '{val}' does not match the expected format (CCYYYYUniqueID).",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure DocRefId begins with a 2-letter country code and 4-digit year.",
            ))

    # 60013: OECD0 (Resend) is only allowed for FilingInfo
    for dp in all_dps:
        p = (dp.xml_path or "").lower()
        if not p.endswith("doctypeindic"):
            continue
        if _v(dp) != "OECD0":
            continue
        if "/filinginfo/" in p:
            continue
        num = 60013 if 60013 in error_map else None
        issues.append(Issue(
            severity="BLOCKING",
            rule_id=_rid("OECD", f"60013|{dp.xml_path}|{dp.filer_code}|{dp.jurisdiction_code}|{dp.entity_code}|{dp.context_key}"),
            section="General",
            xml_path=dp.xml_path,
            filer_code=dp.filer_code,
            jurisdiction_code=dp.jurisdiction_code,
            entity_code=dp.entity_code,
            context_key=dp.context_key,
            error_number=num,
            message="DocTypeIndic 'OECD0' (Resend) may only be used for FilingInfo.",
            how_to_fix=_oecd_fix_text(error_map, num) if num else "Use OECD0 only for FilingInfo; use OECD1/2/3 as appropriate for other records.",
        ))

    # 60016 / 60017: FilingInfo <-> GeneralSection relationship (record-type mapped)
    # These rules reference the DocSpec/DocTypeIndic of the FilingInfo and GeneralSection records.
    record_specs = _build_record_type_specs(config)
    filing_spec = record_specs.get("FilingInfo")
    general_spec = record_specs.get("GeneralSection")

    filing_doctype_dps: List[models.DataPoint] = []
    if filing_spec and filing_spec.doctypeindic_xpaths_lc:
        # filer=None here means "include all filers"; we will group by filer_code below.
        filing_doctype_dps = _record_doctype_dps(submission_dps, filing_spec, filer=None)

    filing_dt_by_filer: Dict[str, Set[str]] = {}
    for dp in filing_doctype_dps:
        fk = (dp.filer_code or "").strip() or "GLOBAL"
        filing_dt_by_filer.setdefault(fk, set()).add(_v(dp))

    def _general_present_for(filer_code: Optional[str]) -> bool:
        if not general_spec:
            return False
        return _record_present(submission_dps, general_spec, filer=filer_code)

    def _general_doctypes_for(filer_code: Optional[str]) -> Set[str]:
        if not general_spec:
            return set()
        return {(_v(dp)) for dp in _record_doctype_dps(submission_dps, general_spec, filer=filer_code) if _v(dp)}

    for fk, dts in filing_dt_by_filer.items():
        filer_code = None if fk == "GLOBAL" else fk

        # 60017: if FilingInfo DocTypeIndic is OECD1 (new filing), GeneralSection must be provided.
        if "OECD1" in dts and not _general_present_for(filer_code):
            num = 60017 if 60017 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("OECD", f"60017|{fk}"),
                section="General",
                filer_code=filer_code,
                error_number=num,
                message="FilingInfo DocTypeIndic is OECD1 (new filing) but GeneralSection is missing.",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Provide GeneralSection when submitting a new GIR (OECD1).",
            ))

        # 60016: if FilingInfo DocTypeIndic is OECD0 (resend), GeneralSection DocTypeIndic must not be OECD1 (new).
        if "OECD0" in dts:
            gen_dts = _general_doctypes_for(filer_code)
            if "OECD1" in gen_dts:
                num = 60016 if 60016 in error_map else None
                issues.append(Issue(
                    severity="BLOCKING",
                    rule_id=_rid("OECD", f"60016|{fk}"),
                    section="General",
                    filer_code=filer_code,
                    error_number=num,
                    message="FilingInfo DocTypeIndic is OECD0 (resend) but GeneralSection DocTypeIndic is OECD1 (new).",
                    how_to_fix=_oecd_fix_text(error_map, num) if num else "Do not include a new GeneralSection (OECD1) when resending FilingInfo (OECD0).",
                ))

    # 60018: at least one RecJurCode must match ReceivingCountry (best-effort)
    receiving_country = None
    for dp in submission_dps:
        p = (dp.xml_path or "").lower()
        if p.endswith("/receivingcountry") or p.endswith("receivingcountry"):
            rc = _v(dp).upper()
            if len(rc) >= 2 and rc[:2].isalpha():
                receiving_country = rc[:2]
                break
    if receiving_country:
        recjur = {(_v(dp).upper()[:2]) for dp in submission_dps if (dp.xml_path or "").endswith("/RecJurCode") and len(_v(dp)) >= 2}
        if receiving_country not in recjur:
            num = 60018 if 60018 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("OECD", f"60018|{receiving_country}|{sorted(recjur)}"),
                section="GLOBEHeader",
                error_number=num,
                message=f"No RecJurCode matches ReceivingCountry '{receiving_country}'.",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure at least one RecJurCode equals ReceivingCountry.",
            ))

    # 60019: Local lodgement roles must not be exchanged (informational in this web tool)
    filing_ce_role = None
    filing_ce_tin = None
    for dp in all_dps:
        p = (dp.xml_path or "").lower()
        if "/filinginfo/" in p and p.endswith("/filingce/role"):
            filing_ce_role = _v(dp)
        if "/filinginfo/" in p and p.endswith("/filingce/tin"):
            filing_ce_tin = _v(dp)
    if filing_ce_role in {"GIR403", "GIR404", "GIR405"}:
        num = 60019 if 60019 in error_map else None
        issues.append(Issue(
            severity="WARNING",
            rule_id=_rid("OECD", f"60019|{filing_ce_role}"),
            section="FilingInfo",
            error_number=num,
            message=f"Filing CE role '{filing_ce_role}' indicates a local lodgement GIR that should not be exchanged.",
            how_to_fix=_oecd_fix_text(error_map, num) if num else "If this is a local lodgement, do not exchange the GIR; file locally as required.",
        ))

    # 60020: FilingInfo period start must not be later than period end
    if filing.period_start and filing.period_end and filing.period_start > filing.period_end:
        num = 60020 if 60020 in error_map else None
        xp_start = _find_xpath(config, section="FilingInfo", endswith="/FilingInfo/Period/Start") or "/GLOBE_OECD/GLOBEBody/FilingInfo/Period/Start"
        xp_end = _find_xpath(config, section="FilingInfo", endswith="/FilingInfo/Period/End") or "/GLOBE_OECD/GLOBEBody/FilingInfo/Period/End"
        issues.append(Issue(
            severity="BLOCKING",
            rule_id=_rid("OECD", f"60020|{filing.period_start.isoformat()}|{filing.period_end.isoformat()}"),
            section="FilingInfo",
            xml_path=xp_start,
            error_number=num,
            message=f"Period start date {filing.period_start.isoformat()} is later than period end date {filing.period_end.isoformat()}.",
            how_to_fix=_oecd_fix_text(error_map, num) if num else f"Ensure Period/Start <= Period/End (currently {xp_start} > {xp_end}).",
        ))

    # 60021: FilingInfo Period/End must not be later than header ReportingPeriod
    if filing.period_end and header_period_end and filing.period_end > header_period_end:
        num = 60021 if 60021 in error_map else None
        xp_end = _find_xpath(config, section="FilingInfo", endswith="/FilingInfo/Period/End") or "/GLOBE_OECD/GLOBEBody/FilingInfo/Period/End"
        issues.append(Issue(
            severity="BLOCKING",
            rule_id=_rid("OECD", f"60021|{filing.period_end.isoformat()}|{header_period_end.isoformat()}"),
            section="FilingInfo",
            xml_path=xp_end,
            error_number=num,
            message=f"FilingInfo Period/End {filing.period_end.isoformat()} is later than header ReportingPeriod {header_period_end.isoformat()}.",
            how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure FilingInfo Period/End is within the header ReportingPeriod.",
        ))

    # 60022: If Filing CE role is GIR401, FilingCE TIN should match a UPE TIN
    if filing_ce_role == "GIR401" and filing_ce_tin:
        upe_tins = {(_v(dp)) for dp in all_dps if "/corporatestructure/upe/" in (dp.xml_path or "").lower() and (dp.xml_path or "").lower().endswith("/tin") and _v(dp)}
        if upe_tins and filing_ce_tin not in upe_tins:
            num = 60022 if 60022 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("OECD", f"60022|{filing_ce_tin}|{sorted(upe_tins)}"),
                section="FilingInfo",
                error_number=num,
                message="When Filing CE role is GIR401, FilingCE TIN should match a TIN provided in the UPE ID.",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure the FilingCE/TIN equals one of the UPE/ID/TIN values.",
            ))

    # 60023: FilingCE ResCountryCode must match TransmittingCountry (best-effort)
    transmitting_country = None
    for dp in submission_dps:
        p = (dp.xml_path or "").lower()
        if p.endswith("/transmittingcountry") or p.endswith("transmittingcountry"):
            tc = _v(dp).upper()
            if len(tc) >= 2 and tc[:2].isalpha():
                transmitting_country = tc[:2]
                break
    filing_ce_res = None
    # Prefer explicit element if present in the submission
    for dp in submission_dps:
        p = (dp.xml_path or "").lower()
        if "/filinginfo/" in p and p.endswith("/filingce/rescountrycode"):
            fc = _v(dp).upper()
            if len(fc) >= 2 and fc[:2].isalpha():
                filing_ce_res = fc[:2]
                break
    # Fallback to filer register jurisdiction_code
    if filing_ce_res is None and filers:
        f0 = next((f for f in filers if (f.jurisdiction_code or "").strip()), None)
        if f0 and (f0.jurisdiction_code or "").strip():
            filing_ce_res = f0.jurisdiction_code.strip().upper()[:2]
    if transmitting_country and filing_ce_res and transmitting_country != filing_ce_res:
        num = 60023 if 60023 in error_map else None
        issues.append(Issue(
            severity="BLOCKING",
            rule_id=_rid("OECD", f"60023|{filing_ce_res}|{transmitting_country}"),
            section="FilingInfo",
            error_number=num,
            message=f"FilingCE ResCountryCode '{filing_ce_res}' does not match TransmittingCountry '{transmitting_country}'.",
            how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure FilingCE ResCountryCode matches the TransmittingCountry in the header.",
        ))

    # 60010: FilingInfo deletion requires deletion of related records (single-file only, record-type mapped)
    deletion_types = {"OECD3", "OECD13"}

    record_specs = _build_record_type_specs(config)
    filing_spec = record_specs.get("FilingInfo")
    related_specs: List[RecordTypeSpec] = [
        record_specs.get("GeneralSection"),
        record_specs.get("Summary"),
        record_specs.get("JurisdictionSection"),
        record_specs.get("UTPRAttribution"),
    ]
    related_specs = [s for s in related_specs if s is not None]

    filing_doctype_dps: List[models.DataPoint] = []
    if filing_spec and filing_spec.doctypeindic_xpaths_lc:
        filing_doctype_dps = _record_doctype_dps(submission_dps, filing_spec, filer=None)

    filing_dt_by_filer: Dict[str, Set[str]] = {}
    for dp in filing_doctype_dps:
        fk = (dp.filer_code or "").strip() or "GLOBAL"
        filing_dt_by_filer.setdefault(fk, set()).add(_v(dp))

    for fk, dts in filing_dt_by_filer.items():
        if not any(dt in deletion_types for dt in dts):
            continue
        filer_code = None if fk == "GLOBAL" else fk

        violations: List[Tuple[str, str]] = []
        for spec in related_specs:
            for dp in _record_doctype_dps(submission_dps, spec, filer=filer_code):
                dt = _v(dp)
                if dt and dt not in deletion_types:
                    violations.append((spec.record_type, dt))

        if violations:
            # Collapse to a compact summary for the message.
            uniq = sorted({f"{rt}:{dt}" for (rt, dt) in violations})
            preview = ", ".join(uniq[:8])
            suffix = "..." if len(uniq) > 8 else ""
            num = 60010 if 60010 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("OECD", f"60010|{fk}|{preview}"),
                section="FilingInfo",
                filer_code=filer_code,
                error_number=num,
                message=(
                    "FilingInfo is marked for deletion, but one or more related records are not deleted "
                    + f"in this message: {preview}{suffix}"
                ),
                how_to_fix=_oecd_fix_text(error_map, num) if num else "If deleting FilingInfo, also delete all related GeneralSection/Summary/JurisdictionSection/UTPRAttribution records.",
            ))

    return issues
