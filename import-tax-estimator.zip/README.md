# Import Tax Estimator (US, NZ, CH)

This repo contains:
- A Render-deployable **Fastify** API (`/v1/requirements`, `/v1/estimate`)
- A Render **cron ingestion job** that downloads & normalizes tariff datasets for:
  - United States (USITC HTS REST API or bulk JSON)
  - New Zealand (NZ Customs CusMod tariff `tar.gz`)
  - Switzerland (BAZG/FOCBS duty rate XLSX files)
- A deterministic AST-based rule engine for duty + VAT/GST estimation.

## Endpoints

### `POST /v1/requirements`
Input:
```json
{ "jurisdictionId": "US|NZ|CH", "code": "0101210000", "asOfDate": "YYYY-MM-DD?" }
```

Output:
- required inputs (e.g. `grossMassKg`, `netMassKg`, `volumeLitre`, `quantity.amount`)
- recommended inputs for VAT base (`freightToBorder`, `insuranceToBorder`)
- unsupported/manual expressions for the selected code

### `POST /v1/estimate`
Input:
```json
{
  "jurisdictionId": "US|NZ|CH",
  "code": "0101210000",
  "asOfDate": "YYYY-MM-DD?",
  "currency": "USD|NZD|CHF",
  "customsValue": { "amount": "10000", "currency": "USD" },
  "freightToBorder": { "amount": "200", "currency": "USD" },
  "insuranceToBorder": { "amount": "0", "currency": "USD" },
  "netMassKg": "12.5",
  "grossMassKg": "13.0",
  "volumeLitre": "2.0",
  "quantity": { "amount": "10", "unit": "item" }
}
```

## Local dev

```bash
npm install
npm run build
npm run migrate
API_KEY=dev DATABASE_URL=postgres://... npm start
```

To run ingestion locally:
```bash
DATABASE_URL=postgres://... NZ_TARIFF_URL="https://..." CH_DUTY_RATES_URLS="https://...,https://..." npm run build && npm run ingest
```

## Render deployment

This repo includes a `render.yaml` Blueprint.
1. Push to GitHub
2. Render → New → Blueprint → select repo
3. Set secrets:
   - API service: `API_KEY`
   - Cron job: `NZ_TARIFF_URL`, `CH_DUTY_RATES_URLS`

## Anything.com UI integration

Recommended flow:
1. Step 1 collects `jurisdictionId`, `code`, `customsValue`, optional freight/insurance
2. Call `/v1/requirements` to learn which extra fields are required
3. Show those fields (weight/volume/qty)
4. Call `/v1/estimate` and display breakdown

Security: call the Render API from Anything backend routes and keep `API_KEY` in Anything Saved Secrets.
