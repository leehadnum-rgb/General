import { FastifyInstance } from "fastify";
import { Pool } from "pg";
import { z } from "zod";
import { calculateEstimate } from "../../core/calc";

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const Body = z.object({
  jurisdictionId: z.enum(["US", "NZ", "CH"]),
  code: z.string(),
  asOfDate: z.string().optional(),
  currency: z.string(),
  customsValue: z.object({ amount: z.string(), currency: z.string() }),
  freightToBorder: z.object({ amount: z.string(), currency: z.string() }).optional(),
  insuranceToBorder: z.object({ amount: z.string(), currency: z.string() }).optional(),

  netMassKg: z.string().optional(),
  grossMassKg: z.string().optional(),
  volumeLitre: z.string().optional(),
  quantity: z.object({ amount: z.string(), unit: z.string() }).optional(),
});

function normalizeCode(code: string): string {
  return (code ?? "").replace(/[^0-9]/g, "");
}

const AST_SUPPORTED_OPS = new Set([
  "field",
  "const_money",
  "const_number",
  "add",
  "mul",
  "min",
  "max",
  "ad_valorem",
  "specific",
]);

function isSupportedAst(ast: any): boolean {
  if (!ast || typeof ast !== "object") return false;
  if (typeof ast.op !== "string") return false;
  if (!AST_SUPPORTED_OPS.has(ast.op)) return false;

  if (ast.op === "add" || ast.op === "min" || ast.op === "max") {
    return Array.isArray(ast.terms) && ast.terms.every(isSupportedAst);
  }
  if (ast.op === "mul") return isSupportedAst(ast.left) && isSupportedAst(ast.right);
  return true;
}

export async function estimateRoute(app: FastifyInstance) {
  app.post("/estimate", async (req, reply) => {
    const body = Body.parse(req.body);
    const asOfDate = body.asOfDate ?? new Date().toISOString().slice(0, 10);
    const code = normalizeCode(body.code);

    const dv = await pool.query<{ data_version_id: string }>(
      `SELECT data_version_id FROM data_version WHERE jurisdiction_id=$1 AND is_active LIMIT 1`,
      [body.jurisdictionId]
    );
    if (dv.rowCount === 0) return reply.code(404).send({ error: "no_data_for_jurisdiction" });
    const dataVersionId = dv.rows[0]!.data_version_id;

    const tl = await pool.query<{ tariff_line_id: string; description: string }>(
      `SELECT tariff_line_id, description
       FROM tariff_line
       WHERE data_version_id=$1 AND jurisdiction_id=$2 AND code=$3 AND valid_range @> $4::date
       LIMIT 1`,
      [dataVersionId, body.jurisdictionId, code, asOfDate]
    );
    if (tl.rowCount === 0) return reply.code(404).send({ error: "code_not_found" });
    const tariffLineId = tl.rows[0]!.tariff_line_id;

    const ms = await pool.query<any>(
      `SELECT m.measure_id, m.measure_type, m.origin_scope, m.origin_code,
              e.expression_id, e.expr_type, e.ast_json
       FROM measure m
       JOIN expression e
         ON e.data_version_id=m.data_version_id AND e.expression_id=m.expression_id
       WHERE m.data_version_id=$1 AND m.tariff_line_id=$2 AND m.valid_range @> $3::date`,
      [dataVersionId, tariffLineId, asOfDate]
    );

    const unsupported: any[] = [];
    const measures = ms.rows
      .filter((r: any) => {
        if (String(r.expr_type) === "CUSTOM" || !isSupportedAst(r.ast_json)) {
          unsupported.push({ measureId: r.measure_id, reason: "manual_or_unsupported_expression", exprType: r.expr_type, ast: r.ast_json });
          return false;
        }
        return true;
      })
      .map((r: any) => ({
        measureId: r.measure_id,
        measureType: r.measure_type,
        originScope: r.origin_scope,
        originCode: r.origin_code,
        expression: { expressionId: r.expression_id, ast: r.ast_json },
      }));

    const vat = await pool.query<any>(
      `SELECT rate_pct
       FROM vat_rule
       WHERE data_version_id=$1 AND jurisdiction_id=$2 AND rate_type='STANDARD' AND valid_range @> $3::date
       LIMIT 1`,
      [dataVersionId, body.jurisdictionId, asOfDate]
    );
    const vatRate = vat.rowCount ? Number(vat.rows[0]!.rate_pct) : null;

    const vb = await pool.query<any>(
      `SELECT ast_json
       FROM vat_base_formula
       WHERE data_version_id=$1 AND jurisdiction_id=$2 AND valid_range @> $3::date
       LIMIT 1`,
      [dataVersionId, body.jurisdictionId, asOfDate]
    );
    const vatBaseAst = vb.rowCount ? vb.rows[0]!.ast_json : null;

    const vatRule = vatRate == null ? null : { ratePct: vatRate, label: body.jurisdictionId === "NZ" ? "GST" : "VAT" };
    const vatBase = vatBaseAst ? { ast: vatBaseAst } : null;

    const result = calculateEstimate(
      {
        jurisdictionId: body.jurisdictionId,
        currency: body.currency,
        code,
        asOfDate,
        customsValue: body.customsValue,
        freightToBorder: body.freightToBorder,
        insuranceToBorder: body.insuranceToBorder,
        netMassKg: body.netMassKg,
        grossMassKg: body.grossMassKg,
        volumeLitre: body.volumeLitre,
        quantity: body.quantity,
      },
      measures,
      vatRule,
      vatBase
    );

    return reply.send({
      dataVersionId,
      tariffLine: { description: tl.rows[0]!.description },
      unsupported,
      result,
    });
  });
}
