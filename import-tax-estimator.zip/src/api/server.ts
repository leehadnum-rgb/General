import Fastify from "fastify";
import { estimateRoute } from "./routes/estimate";
import { requirementsRoute } from "./routes/requirements";

const app = Fastify({ logger: true });

app.get("/health", async () => ({ ok: true }));

app.addHook("onRequest", async (req, reply) => {
  const expected = process.env.API_KEY;
  if (!expected) return; // allow if not set (local)
  const got = req.headers["x-api-key"];
  if (got !== expected) return reply.code(401).send({ error: "unauthorized" });
});

app.register(requirementsRoute, { prefix: "/v1" });
app.register(estimateRoute, { prefix: "/v1" });

const port = Number(process.env.PORT ?? 10000);
app.listen({ port, host: "0.0.0.0" }).catch((e) => {
  app.log.error(e);
  process.exit(1);
});
