import Decimal from "decimal.js";
import { Expr, Money, Value } from "./ast";
import { evalExpr } from "./evaluator";

export type Measure = {
  measureId: string;
  measureType: "CUSTOMS_DUTY" | "EXCISE" | "FEE";
  originScope: "MFN" | "PREFERENTIAL" | "ALL";
  originCode: string;
  expression: { expressionId: string; ast: Expr };
};

export type VatRule = { ratePct: number; label: string } | null;
export type VatBaseFormula = { ast: Expr } | null;

export type CalcInput = {
  jurisdictionId: string;
  currency: string;
  code: string;
  asOfDate: string;

  customsValue: Money;
  freightToBorder?: Money;
  insuranceToBorder?: Money;

  quantity?: { amount: string; unit: string };
  netMassKg?: string;
  grossMassKg?: string;
  volumeLitre?: string;
};

export type CalcOutput = {
  missingInputs: string[];
  assumptions: { code: string; message: string }[];
  warnings: { code: string; message: string }[];
  charges: any[];
  totalTax: Money | null;
  trace: any;
};

export function calculateEstimate(
  input: CalcInput,
  measures: Measure[],
  vatRule: VatRule,
  vatBase: VatBaseFormula
): CalcOutput {
  const missing = new Set<string>();
  const assumptions: { code: string; message: string }[] = [
    { code: "ORIGIN_SCOPE", message: "MFN rates applied (no preferential claim)." },
  ];
  const warnings: { code: string; message: string }[] = [
    { code: "SCOPE_LIMIT", message: "Trade remedy duties / special programs not included unless encoded in measures." },
  ];

  const fields: Record<string, Value | undefined> = {
    customs_value: { kind: "money", money: input.customsValue },
    freight_to_border: input.freightToBorder
      ? { kind: "money", money: input.freightToBorder }
      : { kind: "money", money: { amount: "0", currency: input.currency } },
    insurance_to_border: input.insuranceToBorder
      ? { kind: "money", money: input.insuranceToBorder }
      : { kind: "money", money: { amount: "0", currency: input.currency } },

    quantity: input.quantity ? { kind: "number", value: input.quantity.amount } : undefined,
    net_mass_kg: input.netMassKg ? { kind: "number", value: input.netMassKg } : undefined,
    gross_mass_kg: input.grossMassKg ? { kind: "number", value: input.grossMassKg } : undefined,
    volume_litre: input.volumeLitre ? { kind: "number", value: input.volumeLitre } : undefined,
  };

  const steps: any[] = [];

  // 1) Duty measures (MFN only for MVP)
  let dutyTotal = new Decimal(0);
  const dutyComponents: any[] = [];

  for (const m of measures.filter((x) => x.measureType === "CUSTOMS_DUTY" && x.originScope === "MFN")) {
    const res = evalExpr(m.expression.ast, { fields });
    steps.push({
      kind: "EVALUATE_MEASURE",
      measureId: m.measureId,
      expressionId: m.expression.expressionId,
      ok: res.ok,
      meta: res.meta,
      exprTrace: res.trace,
    });

    if (!res.ok) {
      res.meta.missingFields.forEach((f) => missing.add(f));
      continue;
    }
    if (res.value.kind !== "money") {
      missing.add(`unsupported_expression:${m.expression.expressionId}`);
      continue;
    }
    const amt = new Decimal(res.value.money.amount);
    dutyTotal = dutyTotal.add(amt);
    dutyComponents.push({
      measureId: m.measureId,
      expressionId: m.expression.expressionId,
      amount: res.value.money,
    });
  }

  fields["customs_duty_total"] = { kind: "money", money: { amount: dutyTotal.toFixed(), currency: input.currency } };
  fields["fees_total"] = { kind: "money", money: { amount: "0", currency: input.currency } }; // MVP

  const charges: any[] = [
    {
      type: "CUSTOMS_DUTY",
      label: "Customs duty",
      amount: { amount: dutyTotal.toFixed(), currency: input.currency },
      components: dutyComponents,
    },
  ];

  // 2) VAT/GST (if configured)
  let vatAmount = new Decimal(0);
  let vatBaseMoney: Money | null = null;

  if (vatRule && vatBase) {
    assumptions.push({ code: "VAT_RATE", message: "Standard VAT/GST rate applied." });

    const vatBaseRes = evalExpr(vatBase.ast, { fields });
    steps.push({
      kind: "EVALUATE_VAT_BASE",
      ok: vatBaseRes.ok,
      meta: vatBaseRes.meta,
      exprTrace: vatBaseRes.trace,
    });

    if (!vatBaseRes.ok) {
      vatBaseRes.meta.missingFields.forEach((f) => missing.add(f));
    } else if (vatBaseRes.value.kind === "money") {
      vatBaseMoney = vatBaseRes.value.money;
      vatAmount = new Decimal(vatBaseMoney.amount).mul(new Decimal(vatRule.ratePct)).div(100);
    } else {
      missing.add("vat_base_not_money");
    }

    charges.push({
      type: "VAT",
      label: vatRule.label,
      ratePct: vatRule.ratePct,
      base: vatBaseMoney,
      amount: { amount: vatAmount.toFixed(), currency: input.currency },
    });
  }

  const totalTax = missing.size === 0 ? dutyTotal.add(vatAmount) : null;

  return {
    missingInputs: [...missing],
    assumptions,
    warnings,
    charges,
    totalTax: totalTax ? { amount: totalTax.toFixed(), currency: input.currency } : null,
    trace: {
      meta: { jurisdictionId: input.jurisdictionId, asOfDate: input.asOfDate },
      steps,
    },
  };
}
