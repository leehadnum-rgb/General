import { v4 as uuidv4 } from "uuid";
import { Connector, ConnectorResult, RunContext } from "./base";
import { compileNzFormulaToAst } from "../lib/compileNzFormulaToAst";
import { createGunzip } from "node:zlib";
import { Readable } from "node:stream";
import * as tar from "tar-stream";
import { parse as parseCsv } from "csv-parse/sync";

const OPEN_END = process.env.OPEN_END_DATE ?? "9999-12-31";

function timeoutMs() {
  return Number(process.env.HTTP_TIMEOUT_MS ?? "30000");
}

async function downloadBuffer(url: string): Promise<Buffer> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs());
  try {
    const res = await fetch(url, { signal: ctrl.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
    const ab = await res.arrayBuffer();
    return Buffer.from(ab);
  } finally {
    clearTimeout(t);
  }
}

async function extractTarGz(buf: Buffer): Promise<Map<string, Buffer>> {
  const extract = tar.extract();
  const files = new Map<string, Buffer>();

  return await new Promise((resolve, reject) => {
    extract.on("entry", (header, stream, next) => {
      const chunks: Buffer[] = [];
      stream.on("data", (c) => chunks.push(Buffer.isBuffer(c) ? c : Buffer.from(c)));
      stream.on("end", () => {
        files.set(header.name, Buffer.concat(chunks));
        next();
      });
      stream.on("error", reject);
      stream.resume();
    });

    extract.on("finish", () => resolve(files));
    extract.on("error", reject);

    Readable.from(buf).pipe(createGunzip()).pipe(extract).on("error", reject);
  });
}

function findFile(files: Map<string, Buffer>, patterns: RegExp[]): { name: string; buf: Buffer } {
  for (const re of patterns) {
    for (const [name, buf] of files.entries()) {
      if (re.test(name)) return { name, buf };
    }
  }
  throw new Error(`Required file not found in tar.gz. Tried: ${patterns.map((p) => p.toString()).join(", ")}`);
}

function parseNzDate(s: string): string {
  const m = String(s ?? "").match(/^(\d{4}-\d{2}-\d{2})/);
  if (!m) return "";
  return m[1];
}

function yearOf(dateIso: string): number {
  return Number(dateIso.slice(0, 4));
}

function addDaysIso(dateIso: string, days: number): string {
  const d = new Date(dateIso + "T00:00:00Z");
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

function toExclusiveEnd(expiryIso: string): string {
  if (!expiryIso) return OPEN_END;
  if (yearOf(expiryIso) >= 3000) return OPEN_END; // open-ended convention
  return addDaysIso(expiryIso, 1);                 // inclusive end -> exclusive end
}

function buildNzCode(l1: string, l2: string, l3: string, l4: string, l5: string): string {
  const pad2 = (x: string) => String(x ?? "").trim().padStart(2, "0");
  return `${pad2(l1)}${pad2(l2)}${pad2(l3)}${pad2(l4)}${pad2(l5)}`;
}

function unitToQtyFieldAndUnit(u: string | null | undefined): { qtyField: string; qtyUnit: "kg" | "L" | "item" } | null {
  const unit = String(u ?? "").trim().toUpperCase();
  if (!unit) return null;

  if (unit === "LTR" || unit === "L") return { qtyField: "volume_litre", qtyUnit: "L" };
  if (unit === "KG" || unit === "KGM") return { qtyField: "net_mass_kg", qtyUnit: "kg" };
  if (unit === "NO" || unit === "NMB" || unit === "PCS") return { qtyField: "quantity", qtyUnit: "item" };

  return null;
}

export class NzConnector implements Connector {
  public readonly sourceName = "NZ_CUSMOD_TARIFF";

  async run(ctx: RunContext): Promise<ConnectorResult> {
    const url = process.env.NZ_TARIFF_URL;
    if (!url) throw new Error("NZ_TARIFF_URL is required");

    const rateGroup = (process.env.NZ_RATE_GROUP ?? "NML").toUpperCase();
    const dutyCurrency = (process.env.NZ_DUTY_CURRENCY ?? "NZD").toUpperCase();
    const gstRatePct = String(process.env.NZ_GST_RATE_PCT ?? "15");

    const buf = await downloadBuffer(url);
    const files = await extractTarGz(buf);

    const detailsFile = findFile(files, [/tariff.*details.*\.csv$/i, /TariffDetails.*\.csv$/i]);
    const ratesFile = findFile(files, [/tariff.*rates.*\.csv$/i, /TariffRates.*\.csv$/i]);

    const detailsRows = parseCsv(detailsFile.buf, {
      columns: true,
      delimiter: "~",
      skip_empty_lines: true,
      relax_quotes: true,
      relax_column_count: true,
      trim: true,
    }) as Record<string, string>[];

    const ratesRows = parseCsv(ratesFile.buf, {
      columns: true,
      delimiter: "~",
      skip_empty_lines: true,
      relax_quotes: true,
      relax_column_count: true,
      trim: true,
    }) as Record<string, string>[];

    type DetailPeriod = {
      startIso: string;
      endExclusiveIso: string;
      description: string | null;
      statUnit: string | null;
      suppUnit: string | null;
    };

    const detailsByCode = new Map<string, DetailPeriod[]>();

    for (const r of detailsRows) {
      const code = buildNzCode(
        r["Tic Tariff Level 1"], r["Tic Tariff Level 2"], r["Tic Tariff Level 3"], r["Tic Tariff Level 4"], r["Tic Tariff Level 5"]
      );
      const startIso = parseNzDate(r["Tic Start Date"]);
      const endIso = parseNzDate(r["Tic Expiry Date"]);
      const endExclusive = toExclusiveEnd(endIso);

      const desc = (r["Tic Tariff Description"] ?? "").trim() || null;

      const p: DetailPeriod = {
        startIso: startIso || ctx.asOfDate,
        endExclusiveIso: endExclusive || OPEN_END,
        description: desc,
        statUnit: (r["Tic Statistical Unit"] ?? "").trim() || null,
        suppUnit: (r["Tic Supplementary Unit"] ?? "").trim() || null,
      };

      if (!detailsByCode.has(code)) detailsByCode.set(code, []);
      detailsByCode.get(code)!.push(p);
    }

    function findCoveringDetail(code: string, startIso: string, endExclusiveIso: string): DetailPeriod | null {
      const list = detailsByCode.get(code) ?? [];
      for (const d of list) {
        if (d.startIso <= startIso) {
          const dEnd = d.endExclusiveIso || OPEN_END;
          if (dEnd === OPEN_END || dEnd >= endExclusiveIso) return d;
        }
      }
      return list[0] ?? null;
    }

    const tariffLines: any[] = [];
    const expressions: any[] = [];
    const measures: any[] = [];
    const tariffLineIdByKey = new Map<string, string>();

    for (const r of ratesRows) {
      const rg = String(r["Tdrc Rate Group"] ?? "").trim().toUpperCase();
      if (rg !== rateGroup) continue;

      const code = buildNzCode(
        r["Tdrc Tariff Level 1"], r["Tdrc Tariff Level 2"], r["Tdrc Tariff Level 3"], r["Tdrc Tariff Level 4"], r["Tdrc Tariff Level 5"]
      );

      const startIso = parseNzDate(r["Tdrc Start Date"]) || ctx.asOfDate;
      const endIso = parseNzDate(r["Tdrc Expiry Date"]);
      const endExclusive = toExclusiveEnd(endIso);

      const formula = r["Tdrc Rate Formula"] ?? "";
      const factorA = (r["Tdrc Factor A"] ?? "").trim() || null;
      const factorB = (r["Tdrc Factor B"] ?? "").trim() || null;

      const detail = findCoveringDetail(code, startIso, endExclusive);
      const unit = detail?.statUnit ?? detail?.suppUnit ?? null;
      const qtyInfo = unitToQtyFieldAndUnit(unit);

      const compiled = compileNzFormulaToAst({
        formulaCode: formula,
        factorA,
        factorB,
        dutyCurrency,
        qtyField: qtyInfo?.qtyField ?? null,
        qtyUnit: qtyInfo?.qtyUnit,
      });

      const tlKey = `${code}|${startIso}|${endExclusive}`;
      let tariffLineId = tariffLineIdByKey.get(tlKey);
      if (!tariffLineId) {
        tariffLineId = uuidv4();
        tariffLineIdByKey.set(tlKey, tariffLineId);

        tariffLines.push({
          tariffLineId,
          jurisdictionId: "NZ",
          code,
          codeLen: code.length,
          description: detail?.description ?? null,
          validFrom: startIso,
          validTo: endExclusive,
          sourceRef: `${detailsFile.name};${ratesFile.name}`,
        });
      }

      const expressionId = uuidv4();
      const measureId = uuidv4();

      if (compiled.ok) {
        expressions.push({
          expressionId,
          exprType: compiled.exprType,
          astJson: compiled.ast,
          currency: compiled.exprType === "SPECIFIC" ? dutyCurrency : null,
          unitCode: null,
          sourceRef: `NZ formula ${String(formula).padStart(2, "0")}`,
        });

        measures.push({
          measureId,
          tariffLineId,
          expressionId,
          measureType: "CUSTOMS_DUTY",
          originScope: "MFN",
          originCode: "ALL",
          validFrom: startIso,
          validTo: endExclusive,
          sourceRef: rg,
        });
      } else {
        expressions.push({
          expressionId,
          exprType: "CUSTOM",
          astJson: { op: "manual_required", reason: compiled.reason, message: compiled.message, raw: compiled.raw },
          currency: null,
          unitCode: null,
          sourceRef: `NZ formula ${String(formula).padStart(2, "0")}`,
        });

        measures.push({
          measureId,
          tariffLineId,
          expressionId,
          measureType: "CUSTOMS_DUTY",
          originScope: "MFN",
          originCode: "ALL",
          validFrom: startIso,
          validTo: endExclusive,
          sourceRef: "manual_required",
        });
      }
    }

    const vatRules = [{
      vatRuleId: uuidv4(),
      jurisdictionId: "NZ",
      rateType: "STANDARD",
      ratePct: gstRatePct,
      validFrom: ctx.asOfDate,
      validTo: OPEN_END,
      sourceRef: "NZ GST standard (MVP)",
    }];

    const vatBaseFormulas = [{
      vatBaseFormulaId: uuidv4(),
      jurisdictionId: "NZ",
      astJson: {
        op: "add",
        terms: [
          { op: "field", name: "customs_value" },
          { op: "field", name: "customs_duty_total" },
          { op: "field", name: "freight_to_border" },
          { op: "field", name: "insurance_to_border" },
        ],
      },
      validFrom: ctx.asOfDate,
      validTo: OPEN_END,
      sourceRef: "NZ GST base (MVP)",
    }];

    return {
      canonical: {
        tariffLines,
        expressions,
        measures,
        vatRules,
        vatBaseFormulas,
        thresholdRules: [],
      },
      manifest: {
        runId: ctx.runId,
        jurisdictionId: ctx.jurisdictionId,
        asOfDate: ctx.asOfDate,
        sourceName: this.sourceName,
        url,
        files: [detailsFile.name, ratesFile.name],
        detailRows: detailsRows.length,
        rateRows: ratesRows.length,
        insertedLines: tariffLines.length,
      },
    };
  }
}
