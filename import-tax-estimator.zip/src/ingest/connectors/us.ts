import { v4 as uuidv4 } from "uuid";
import { Connector, ConnectorResult, RunContext } from "./base";
import { parseRateToAst } from "../lib/parseRateToAst";

const OPEN_END = process.env.OPEN_END_DATE ?? "9999-12-31";

function timeoutMs() {
  return Number(process.env.HTTP_TIMEOUT_MS ?? "30000");
}

async function fetchJson(url: string): Promise<any> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs());
  try {
    const res = await fetch(url, { signal: ctrl.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
    return await res.json();
  } finally {
    clearTimeout(t);
  }
}

function normalizeDigits(code: string): string {
  return (code ?? "").replace(/[^0-9]/g, "");
}

function pickDutyField(rec: any): string | null {
  const wanted = (process.env.US_DUTY_FIELD ?? "general").toLowerCase();
  for (const k of Object.keys(rec)) {
    if (k.toLowerCase() === wanted) return rec[k] ?? null;
  }
  const candidates = ["general", "col1_general", "col1", "general_rate", "rate_general"];
  for (const c of candidates) {
    for (const k of Object.keys(rec)) {
      if (k.toLowerCase() === c) return rec[k] ?? null;
    }
  }
  return null;
}

function getIndent(rec: any): number | null {
  const keys = ["indent", "level", "indentation", "depth"];
  for (const k of keys) {
    if (rec[k] != null) {
      const n = Number(rec[k]);
      if (Number.isFinite(n)) return n;
    }
  }
  return null;
}

export class UsConnector implements Connector {
  public readonly sourceName = "US_HTS";

  async run(ctx: RunContext): Promise<ConnectorResult> {
    const source = (process.env.US_SOURCE ?? "").toUpperCase();
    if (source !== "API" && source !== "BULK") throw new Error("US_SOURCE must be API or BULK");

    let obj: any;
    const manifest: any = {
      runId: ctx.runId,
      jurisdictionId: ctx.jurisdictionId,
      asOfDate: ctx.asOfDate,
      sourceName: this.sourceName,
      mode: source,
    };

    if (source === "API") {
      const base = process.env.US_API_BASE_URL ?? "https://hts.usitc.gov/reststop";
      const from = process.env.US_API_FROM ?? "0100";
      const to = process.env.US_API_TO ?? "9999";
      const format = (process.env.US_API_FORMAT ?? "JSON").toUpperCase();
      const styles = (process.env.US_API_STYLES ?? "false").toLowerCase();
      const url = `${base.replace(/\/$/, "")}/exportList?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}&format=${encodeURIComponent(format)}&styles=${encodeURIComponent(styles)}`;
      obj = await fetchJson(url);
      manifest.apiUrl = url;
    } else {
      const url = process.env.US_BULK_URL;
      if (!url) throw new Error("US_BULK_URL is required when US_SOURCE=BULK");
      obj = await fetchJson(url);
      manifest.bulkUrl = url;
    }

    const records: any[] = Array.isArray(obj) ? obj
      : Array.isArray(obj.data) ? obj.data
      : Array.isArray(obj.rows) ? obj.rows
      : Array.isArray(obj.items) ? obj.items
      : [];

    const tariffLines: any[] = [];
    const expressions: any[] = [];
    const measures: any[] = [];

    const massField = (process.env.US_MASS_FIELD ?? "net_mass_kg") as any;

    // best-effort duty inheritance by indentation
    const indentRateStack = new Map<number, string>();

    for (const rec of records) {
      const rawCode = rec.htsno ?? rec.hts_number ?? rec.hts ?? rec.number ?? rec.code ?? "";
      const codeDigits = normalizeDigits(String(rawCode));
      if (!codeDigits || codeDigits.length < 4) continue;

      const desc = rec.description ?? rec.desc ?? rec.text ?? null;

      let dutyText = pickDutyField(rec);
      dutyText = dutyText == null ? "" : String(dutyText);

      const indent = getIndent(rec);
      if (indent != null) {
        const d = dutyText.trim();
        if (d) indentRateStack.set(indent, d);
        if (!d) {
          for (let i = indent - 1; i >= 0; i--) {
            const inherited = indentRateStack.get(i);
            if (inherited) { dutyText = inherited; break; }
          }
        }
      }

      const tariffLineId = uuidv4();

      tariffLines.push({
        tariffLineId,
        jurisdictionId: "US",
        code: codeDigits,
        codeLen: codeDigits.length,
        description: desc,
        validFrom: ctx.asOfDate,
        validTo: OPEN_END,
        sourceRef: rawCode ? String(rawCode) : null,
      });

      const parsed = parseRateToAst(String(dutyText ?? ""), {
        defaultCurrency: "USD",
        defaultMassField: massField,
      });

      const expressionId = uuidv4();
      const measureId = uuidv4();

      if (parsed.ok) {
        expressions.push({
          expressionId,
          exprType: parsed.exprType,
          astJson: parsed.ast,
          currency: parsed.exprType === "SPECIFIC" ? "USD" : null,
          unitCode: null,
          sourceRef: parsed.normalized,
        });

        measures.push({
          measureId,
          tariffLineId,
          expressionId,
          measureType: "CUSTOMS_DUTY",
          originScope: "MFN",
          originCode: "ALL",
          validFrom: ctx.asOfDate,
          validTo: OPEN_END,
          sourceRef: null,
        });
      } else {
        expressions.push({
          expressionId,
          exprType: "CUSTOM",
          astJson: { op: "manual_required", raw: dutyText, reason: parsed.reason, message: parsed.message },
          currency: null,
          unitCode: null,
          sourceRef: null,
        });

        measures.push({
          measureId,
          tariffLineId,
          expressionId,
          measureType: "CUSTOMS_DUTY",
          originScope: "MFN",
          originCode: "ALL",
          validFrom: ctx.asOfDate,
          validTo: OPEN_END,
          sourceRef: "manual_required",
        });
      }
    }

    return {
      canonical: {
        tariffLines,
        expressions,
        measures,
        vatRules: [],
        vatBaseFormulas: [],
        thresholdRules: [],
      },
      manifest: {
        ...manifest,
        recordCount: records.length,
        insertedLines: tariffLines.length,
      },
    };
  }
}
