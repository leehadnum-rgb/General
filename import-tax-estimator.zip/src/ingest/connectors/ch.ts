import { v4 as uuidv4 } from "uuid";
import { Connector, ConnectorResult, RunContext } from "./base";
import * as XLSX from "xlsx";
import { parseRateToAst } from "../lib/parseRateToAst";

const OPEN_END = process.env.OPEN_END_DATE ?? "9999-12-31";

function timeoutMs() {
  return Number(process.env.HTTP_TIMEOUT_MS ?? "30000");
}

async function downloadBuffer(url: string): Promise<Buffer> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs());
  try {
    const res = await fetch(url, { signal: ctrl.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
    const ab = await res.arrayBuffer();
    return Buffer.from(ab);
  } finally {
    clearTimeout(t);
  }
}

function normalizeDigits(code: string): string {
  return (code ?? "").replace(/[^0-9]/g, "");
}

function detectColumns(rows: Record<string, any>[]) {
  const env = {
    code: process.env.CH_COL_CODE,
    desc: process.env.CH_COL_DESCRIPTION,
    duty: process.env.CH_COL_DUTY,
    unit: process.env.CH_COL_UNIT,
  };

  if (env.code && env.duty) {
    return { codeCol: env.code, descCol: env.desc ?? null, dutyCol: env.duty, unitCol: env.unit ?? null };
  }

  const keys = rows.length ? Object.keys(rows[0]) : [];
  const lower = (s: string) => s.toLowerCase();

  let codeCol: string | null = null;
  for (const k of keys) {
    let hits = 0;
    for (let i = 0; i < Math.min(rows.length, 50); i++) {
      const v = rows[i]?.[k];
      const d = normalizeDigits(String(v ?? ""));
      if (d.length >= 6 && d.length <= 12) hits++;
    }
    if (hits >= 10) { codeCol = k; break; }
  }

  let dutyCol: string | null = null;
  for (const k of keys) {
    const lk = lower(k);
    if (lk.includes("ansatz") || lk.includes("duty") || lk.includes("rate") || lk.includes("zoll")) { dutyCol = k; break; }
  }
  if (!dutyCol) {
    for (const k of keys) {
      let hits = 0;
      for (let i = 0; i < Math.min(rows.length, 50); i++) {
        const v = rows[i]?.[k];
        if (v == null) continue;
        const n = Number(String(v).replace(",", "."));
        if (Number.isFinite(n)) hits++;
      }
      if (hits >= 10) { dutyCol = k; break; }
    }
  }

  let unitCol: string | null = null;
  for (const k of keys) {
    const lk = lower(k);
    if (lk.includes("unit") || lk.includes("einheit") || lk.includes("pro")) { unitCol = k; break; }
  }

  let descCol: string | null = null;
  for (const k of keys) {
    const lk = lower(k);
    if (lk.includes("description") || lk.includes("bezeichnung") || lk.includes("text")) { descCol = k; break; }
  }

  if (!codeCol || !dutyCol) {
    throw new Error("CH column detection failed. Provide CH_COL_CODE + CH_COL_DUTY (and optionally CH_COL_UNIT/CH_COL_DESCRIPTION).");
  }

  return { codeCol, descCol, dutyCol, unitCol };
}

export class ChConnector implements Connector {
  public readonly sourceName = "CH_TARES_XLSX";

  async run(ctx: RunContext): Promise<ConnectorResult> {
    const urlsRaw = process.env.CH_DUTY_RATES_URLS;
    if (!urlsRaw) throw new Error("CH_DUTY_RATES_URLS is required");

    const urls = urlsRaw.split(",").map((s) => s.trim()).filter(Boolean);
    const currency = (process.env.CH_CURRENCY ?? "CHF").toUpperCase();
    const vatRatePct = String(process.env.CH_VAT_RATE_PCT ?? "8.1");
    const sheetNameOverride = process.env.CH_SHEET_NAME || null;
    const defaultMassField = (process.env.CH_MASS_FIELD_DEFAULT ?? "gross_mass_kg") as any;

    const tariffLines: any[] = [];
    const expressions: any[] = [];
    const measures: any[] = [];

    for (const url of urls) {
      const buf = await downloadBuffer(url);
      const wb = XLSX.read(buf, { type: "buffer" });

      const sheetName = sheetNameOverride ?? wb.SheetNames[0];
      if (!sheetName) throw new Error(`CH XLSX had no sheets: ${url}`);
      const sheet = wb.Sheets[sheetName]!;
      const rows = XLSX.utils.sheet_to_json<Record<string, any>>(sheet, { defval: null });

      const { codeCol, descCol, dutyCol, unitCol } = detectColumns(rows);

      for (const r of rows) {
        const codeDigits = normalizeDigits(String(r[codeCol] ?? ""));
        if (!codeDigits || codeDigits.length < 6) continue;

        const desc = descCol ? (String(r[descCol] ?? "").trim() || null) : null;

        const dutyVal = r[dutyCol];
        const unitVal = unitCol ? r[unitCol] : null;

        const dutyText =
          unitVal != null && unitVal !== ""
            ? `${currency} ${String(dutyVal).replace(",", ".")} / ${String(unitVal)}`
            : `${currency} ${String(dutyVal).replace(",", ".")}`;

        const tariffLineId = uuidv4();
        tariffLines.push({
          tariffLineId,
          jurisdictionId: "CH",
          code: codeDigits,
          codeLen: codeDigits.length,
          description: desc,
          validFrom: ctx.asOfDate,
          validTo: OPEN_END,
          sourceRef: url,
        });

        const parsed = parseRateToAst(dutyText, {
          defaultCurrency: currency,
          defaultMassField,
        });

        const expressionId = uuidv4();
        const measureId = uuidv4();

        if (parsed.ok) {
          expressions.push({
            expressionId,
            exprType: parsed.exprType,
            astJson: parsed.ast,
            currency: parsed.exprType === "SPECIFIC" ? currency : null,
            unitCode: null,
            sourceRef: parsed.normalized,
          });

          measures.push({
            measureId,
            tariffLineId,
            expressionId,
            measureType: "CUSTOMS_DUTY",
            originScope: "MFN",
            originCode: "ALL",
            validFrom: ctx.asOfDate,
            validTo: OPEN_END,
            sourceRef: url,
          });
        } else {
          expressions.push({
            expressionId,
            exprType: "CUSTOM",
            astJson: { op: "manual_required", raw: dutyText, reason: parsed.reason, message: parsed.message },
            currency: null,
            unitCode: null,
            sourceRef: url,
          });

          measures.push({
            measureId,
            tariffLineId,
            expressionId,
            measureType: "CUSTOMS_DUTY",
            originScope: "MFN",
            originCode: "ALL",
            validFrom: ctx.asOfDate,
            validTo: OPEN_END,
            sourceRef: "manual_required",
          });
        }
      }
    }

    const vatRules = [{
      vatRuleId: uuidv4(),
      jurisdictionId: "CH",
      rateType: "STANDARD",
      ratePct: vatRatePct,
      validFrom: ctx.asOfDate,
      validTo: OPEN_END,
      sourceRef: "CH VAT standard (MVP)",
    }];

    const vatBaseFormulas = [{
      vatBaseFormulaId: uuidv4(),
      jurisdictionId: "CH",
      astJson: {
        op: "add",
        terms: [
          { op: "field", name: "customs_value" },
          { op: "field", name: "customs_duty_total" },
          { op: "field", name: "fees_total" },
          { op: "field", name: "freight_to_border" },
          { op: "field", name: "insurance_to_border" },
        ],
      },
      validFrom: ctx.asOfDate,
      validTo: OPEN_END,
      sourceRef: "CH VAT base (MVP)",
    }];

    return {
      canonical: {
        tariffLines,
        expressions,
        measures,
        vatRules,
        vatBaseFormulas,
        thresholdRules: [],
      },
      manifest: {
        runId: ctx.runId,
        jurisdictionId: ctx.jurisdictionId,
        asOfDate: ctx.asOfDate,
        sourceName: this.sourceName,
        urls,
        insertedLines: tariffLines.length,
      },
    };
  }
}
