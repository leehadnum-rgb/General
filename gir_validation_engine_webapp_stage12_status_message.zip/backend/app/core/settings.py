from __future__ import annotations

from typing import Optional

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings.

    Notes:
    - Render provides Postgres URLs like: postgresql://... (or postgres://...)
      whereas SQLAlchemy with psycopg expects: postgresql+psycopg://...
      We normalize automatically.
    - For local Docker, CONFIG_ROOT defaults to /app/config.
    """

    model_config = SettingsConfigDict(env_file=None, extra="ignore")

    database_url: str = Field(..., alias="DATABASE_URL")
    config_root: str = Field("/app/config", alias="CONFIG_ROOT")

    # Optional API key (if set, enforced via X-API-Key header).
    api_key: Optional[str] = Field(default=None, alias="GIR_API_KEY")

    # CORS allowlist for browser-based front ends (Anything.com, etc.).
    # Use "*" for MVP; for production provide a comma-separated list.
    cors_allow_origins: str = Field(default="*", alias="CORS_ALLOW_ORIGINS")

    # Attribute-path requiredness (Stage 4.5)
    #
    # The XML importer can emit attribute datapoints with xml_path like:
    #   /.../TIN/@issuedBy
    # Some OECD/XSD-derived configs may also include attributes as required leaf nodes.
    #
    # Modes:
    #   - off  : never enforce requiredness for attribute xpaths
    #   - auto : enforce only when the latest Submission source_type is "xml"
    #   - on   : always enforce (even for xlsx/csv submissions)
    attribute_requiredness_mode: str = Field(
        default="auto",
        alias="ATTRIBUTE_REQUIREDNESS_MODE",
        description="Controls whether requiredness checks include attribute xpaths (/@...). Values: off|auto|on",
    )

    # GIR XSD validation (Stage 5 / OECD 50007)
    #
    # When enabled, the importer validates uploaded GIR XML files against the OECD GIR XML Schema (XSD bundle).
    # This is the most comprehensive way to catch schema-level issues (including required attributes such as currCode)
    # and maps failures to OECD file error code 50007 in the validation results.
    #
    # Modes:
    #   - off : do not run XSD validation unless the request explicitly sets strict_xsd=true
    #   - on  : always run XSD validation for XML imports
    xsd_validation_mode: str = Field(
        default="off",
        alias="XSD_VALIDATION_MODE",
        description="Controls default XSD validation on XML import. Values: off|on",
    )

    # Path to the OECD GIR XSD bundle (ZIP) or extracted directory.
    # Recommended repo path: oecd_schemas/oecd_gir_xml_schema.zip
    gir_xsd_zip_path: str = Field(
        default="oecd_schemas/oecd_gir_xml_schema.zip",
        alias="GIR_XSD_ZIP_PATH",
        description="Path to the OECD GIR XSD ZIP bundle used for schema validation",
    )
    gir_xsd_dir: Optional[str] = Field(
        default=None,
        alias="GIR_XSD_DIR",
        description="Optional path to an extracted folder of .xsd files (overrides GIR_XSD_ZIP_PATH)",
    )
    gir_xsd_main: Optional[str] = Field(
        default=None,
        alias="GIR_XSD_MAIN",
        description="Optional main XSD filename/path within the bundle (if auto-detection fails)",
    )

    # GIR Status Message XSD validation (Stage 12)
    #
    # Optional: validate generated/received GIR Status Messages against the OECD GIR Status Message XML Schema.
    # This is useful if you want the engine to emit schema-valid status messages for downstream systems.
    #
    # Modes:
    #   - off : do not run Status Message XSD validation by default
    #   - on  : run Status Message XSD validation on generation/validation endpoints
    status_xsd_validation_mode: str = Field(
        default="off",
        alias="STATUS_XSD_VALIDATION_MODE",
        description="Controls default XSD validation for GIR Status Messages. Values: off|on",
    )

    # Path to the OECD GIR Status Message XSD bundle (ZIP) or extracted directory.
    # Recommended repo path: oecd_schemas/oecd_gir_status_message_xml_schema.zip
    status_xsd_zip_path: str = Field(
        default="oecd_schemas/xml-schema-gir-status-message.zip",
        alias="STATUS_XSD_ZIP_PATH",
        description="Path to the OECD GIR Status Message XSD ZIP bundle used for schema validation",
    )
    status_xsd_dir: Optional[str] = Field(
        default=None,
        alias="STATUS_XSD_DIR",
        description="Optional path to an extracted folder of status-message .xsd files (overrides STATUS_XSD_ZIP_PATH)",
    )
    status_xsd_main: Optional[str] = Field(
        default=None,
        alias="STATUS_XSD_MAIN",
        description="Optional main Status Message XSD filename/path within the bundle (if auto-detection fails)",
    )

    # OECD file-level validations that depend on "test vs prod" context (OECD 50008/50009)
    gir_environment: str = Field(
        default="prod",
        alias="GIR_ENVIRONMENT",
        description="Environment hint for file-level OECD validations. Values: prod|test",
    )

    # Optional expected ReceivingCountry for OECD file error 50010 (MessageSpec/ReceivingCountry mismatch)
    expected_receiving_country: Optional[str] = Field(
        default=None,
        alias="EXPECTED_RECEIVING_COUNTRY",
        description="If set, validates MessageSpec/ReceivingCountry and maps mismatch to OECD 50010",
    )

    @field_validator("attribute_requiredness_mode", mode="before")
    @classmethod
    def normalize_attribute_requiredness_mode(cls, v):
        if not isinstance(v, str):
            return "auto"
        vv = v.strip().lower()
        if vv not in {"off", "auto", "on"}:
            return "auto"
        return vv

    @field_validator("xsd_validation_mode", mode="before")
    @classmethod
    def normalize_xsd_validation_mode(cls, v):
        if not isinstance(v, str):
            return "off"
        vv = v.strip().lower()
        if vv not in {"off", "on"}:
            return "off"
        return vv


    @field_validator("status_xsd_validation_mode", mode="before")
    @classmethod
    def normalize_status_xsd_validation_mode(cls, v):
        if not isinstance(v, str):
            return "off"
        vv = v.strip().lower()
        if vv not in {"off", "on"}:
            return "off"
        return vv

    @field_validator("gir_environment", mode="before")
    @classmethod
    def normalize_gir_environment(cls, v):
        if not isinstance(v, str):
            return "prod"
        vv = v.strip().lower()
        if vv not in {"prod", "test"}:
            return "prod"
        return vv

    @field_validator("expected_receiving_country", mode="before")
    @classmethod
    def normalize_expected_receiving_country(cls, v):
        if v is None:
            return None
        if not isinstance(v, str):
            return None
        s = v.strip().upper()
        if len(s) < 2:
            return None
        s2 = s[:2]
        if not s2.isalpha():
            return None
        return s2


    @field_validator("database_url", mode="before")
    @classmethod
    def normalize_database_url(cls, v):
        if not isinstance(v, str):
            return v
        if v.startswith("postgresql://"):
            return v.replace("postgresql://", "postgresql+psycopg://", 1)
        if v.startswith("postgres://"):
            return v.replace("postgres://", "postgresql+psycopg://", 1)
        return v


settings = Settings()
