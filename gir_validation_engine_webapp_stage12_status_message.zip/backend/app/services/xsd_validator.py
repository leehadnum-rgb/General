from __future__ import annotations

"""OECD XML Schema validation helpers (Stage 5 + Stage 12).

This module validates XML documents against OECD XSD bundles:
  - GIR XML Schema (root element: GLOBE_OECD)  -> Stage 5 (OECD 50007)
  - GIR Status Message XML Schema (root element: GIRStatusMessage_OECD) -> Stage 12

Design goals:
  - Works with OECD-provided schema ZIPs (multiple .xsd files with includes/imports)
  - Caches extraction + compiled schema for performance
  - Returns a compact list of human-friendly errors

Notes:
  - Validators are only used when explicitly enabled (env or request flag)
    to avoid hard failures for deployments that don't ship the schema bundles.
"""

from dataclasses import dataclass
from functools import lru_cache
from hashlib import sha1
from pathlib import Path
import os
import re
import shutil
import zipfile
from typing import List, Optional, Tuple


@dataclass(frozen=True)
class XsdValidationResult:
    valid: bool
    errors: List[str]
    main_xsd_path: Optional[str] = None


def _cache_key_for_file(path: Path) -> str:
    st = path.stat()
    key = f"{str(path.resolve())}|{st.st_mtime_ns}|{st.st_size}"
    return sha1(key.encode("utf-8")).hexdigest()[:16]


def _ensure_extracted_zip(zip_path: Path, *, cache_env_var: str) -> Path:
    """Extract an XSD ZIP into a stable cache directory and return the extracted folder."""
    if not zip_path.exists():
        raise FileNotFoundError(f"XSD zip not found: {zip_path}")

    cache_root = Path(os.getenv(cache_env_var) or "/tmp/gir_xsd_cache")
    cache_root.mkdir(parents=True, exist_ok=True)

    key = _cache_key_for_file(zip_path)
    out_dir = cache_root / key
    marker = out_dir / ".extracted"
    if marker.exists():
        return out_dir

    # Re-extract (clean slate)
    if out_dir.exists():
        shutil.rmtree(out_dir, ignore_errors=True)
    out_dir.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(zip_path, "r") as z:
        z.extractall(out_dir)

    marker.write_text("ok")
    return out_dir


def _auto_find_main_xsd(schema_dir: Path, *, root_element_name: str) -> Path:
    """Best-effort: find an XSD file that declares the given root element."""
    candidates: List[Path] = []
    for p in schema_dir.rglob("*.xsd"):
        if not p.is_file():
            continue
        try:
            txt = p.read_text(errors="ignore")
        except Exception:
            continue
        if root_element_name not in txt:
            continue
        # Heuristic: look for element declaration with name="<root>".
        if re.search(r"<\\w*:element[^>]+name\\s*=\\s*['\"]" + re.escape(root_element_name) + r"['\"]", txt):
            candidates.append(p)

    if candidates:
        # Prefer the shallowest (often the entrypoint) and then the largest (most references).
        candidates.sort(key=lambda x: (len(x.parts), -x.stat().st_size))
        return candidates[0]

    # Fallback: use the largest XSD in the directory.
    all_xsds = [p for p in schema_dir.rglob("*.xsd") if p.is_file()]
    if not all_xsds:
        raise FileNotFoundError("No .xsd files found in schema directory")
    all_xsds.sort(key=lambda x: -x.stat().st_size)
    return all_xsds[0]


def _resolve_schema_sources(
    *,
    xsd_zip_path: Optional[str],
    xsd_dir: Optional[str],
    main_xsd: Optional[str],
    root_element_name: str,
    cache_env_var: str,
) -> Tuple[Path, Path]:
    """Return (schema_dir, main_xsd_path)."""

    if xsd_dir:
        schema_dir = Path(xsd_dir)
        if not schema_dir.exists():
            raise FileNotFoundError(f"XSD dir not found: {schema_dir}")

        if main_xsd:
            mp = Path(main_xsd)
            main_path = mp if mp.is_absolute() else (schema_dir / mp)
        else:
            main_path = _auto_find_main_xsd(schema_dir, root_element_name=root_element_name)

        if not main_path.exists():
            raise FileNotFoundError(f"Main XSD not found: {main_path}")

        return schema_dir, main_path

    if not xsd_zip_path:
        raise FileNotFoundError("No XSD schema source configured")

    zp = Path(xsd_zip_path)
    schema_dir = _ensure_extracted_zip(zp, cache_env_var=cache_env_var)

    if main_xsd:
        mp = Path(main_xsd)
        main_path = mp if mp.is_absolute() else (schema_dir / mp)
    else:
        main_path = _auto_find_main_xsd(schema_dir, root_element_name=root_element_name)

    if not main_path.exists():
        raise FileNotFoundError(f"Main XSD not found: {main_path}")

    return schema_dir, main_path


@lru_cache(maxsize=8)
def _compiled_schema(
    xsd_zip_path: Optional[str],
    xsd_dir: Optional[str],
    main_xsd: Optional[str],
    root_element_name: str,
    cache_env_var: str,
):
    """Load and compile an lxml XMLSchema.

    Cached across validations for performance.
    """
    from lxml import etree

    _schema_dir, main_path = _resolve_schema_sources(
        xsd_zip_path=xsd_zip_path,
        xsd_dir=xsd_dir,
        main_xsd=main_xsd,
        root_element_name=root_element_name,
        cache_env_var=cache_env_var,
    )

    schema_doc = etree.parse(str(main_path))
    schema = etree.XMLSchema(schema_doc)
    return schema, str(main_path)


def validate_xml_against_xsd_bundle(
    xml_bytes: bytes,
    *,
    root_element_name: str,
    xsd_zip_path: Optional[str] = None,
    xsd_dir: Optional[str] = None,
    main_xsd: Optional[str] = None,
    cache_env_var: str = "GIR_XSD_CACHE_DIR",
    max_errors: int = 40,
) -> XsdValidationResult:
    """Validate an XML payload against an OECD XSD bundle.

    root_element_name is only used for auto-detecting the bundle entrypoint when main_xsd is not supplied.
    """
    from lxml import etree

    if not isinstance(xml_bytes, (bytes, bytearray)):
        raise TypeError("xml_bytes must be bytes")

    schema, main_path = _compiled_schema(xsd_zip_path, xsd_dir, main_xsd, root_element_name, cache_env_var)

    # Parse XML
    try:
        parser = etree.XMLParser(huge_tree=True, recover=False)
        doc = etree.fromstring(xml_bytes, parser=parser)
        tree = etree.ElementTree(doc)
    except Exception as e:
        return XsdValidationResult(valid=False, errors=[f"Invalid XML: {e}"], main_xsd_path=main_path)

    ok = schema.validate(tree)
    if ok:
        return XsdValidationResult(valid=True, errors=[], main_xsd_path=main_path)

    errs: List[str] = []
    for e in list(schema.error_log)[: max(1, int(max_errors))]:
        loc = []
        if getattr(e, "line", None):
            loc.append(f"line {e.line}")
        if getattr(e, "column", None):
            loc.append(f"col {e.column}")
        loc_s = (" (" + ", ".join(loc) + ")") if loc else ""
        msg = (getattr(e, "message", None) or str(e)).strip()
        errs.append(f"{msg}{loc_s}")

    total = len(schema.error_log)
    if total > len(errs):
        errs.append(f"… plus {total - len(errs)} more XSD validation error(s).")

    return XsdValidationResult(valid=False, errors=errs, main_xsd_path=main_path)


def validate_xml_against_gir_xsd(
    xml_bytes: bytes,
    *,
    xsd_zip_path: Optional[str] = None,
    xsd_dir: Optional[str] = None,
    main_xsd: Optional[str] = None,
    max_errors: int = 40,
) -> XsdValidationResult:
    """Validate a GIR XML payload against the configured GIR XSD schema bundle.

    Root element: GLOBE_OECD
    """
    return validate_xml_against_xsd_bundle(
        xml_bytes,
        root_element_name="GLOBE_OECD",
        xsd_zip_path=xsd_zip_path,
        xsd_dir=xsd_dir,
        main_xsd=main_xsd,
        cache_env_var="GIR_XSD_CACHE_DIR",
        max_errors=max_errors,
    )


def validate_xml_against_status_message_xsd(
    xml_bytes: bytes,
    *,
    xsd_zip_path: Optional[str] = None,
    xsd_dir: Optional[str] = None,
    main_xsd: Optional[str] = None,
    max_errors: int = 40,
) -> XsdValidationResult:
    """Validate a GIR Status Message XML payload against the configured Status Message XSD schema bundle.

    Root element: GIRStatusMessage_OECD
    """
    return validate_xml_against_xsd_bundle(
        xml_bytes,
        root_element_name="GIRStatusMessage_OECD",
        xsd_zip_path=xsd_zip_path,
        xsd_dir=xsd_dir,
        main_xsd=main_xsd,
        cache_env_var="STATUS_XSD_CACHE_DIR",
        max_errors=max_errors,
    )
