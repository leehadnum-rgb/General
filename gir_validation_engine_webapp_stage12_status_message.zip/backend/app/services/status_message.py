from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from hashlib import sha1
import re
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple

from lxml import etree
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core.settings import settings
from app.db import models
from app.services.xsd_validator import validate_xml_against_status_message_xsd, _resolve_schema_sources


@dataclass(frozen=True)
class StatusMessageMeta:
    transmitting_country: Optional[str]
    receiving_country: Optional[str]
    original_message_ref_id: Optional[str]
    status_message_ref_id: str
    validation_status: str  # Accepted|Rejected
    used_namespace: Optional[str]


_MSGREF_RE = re.compile(r"^(?P<send>[A-Z]{2})(?P<year>\d{4})(?P<recv>[A-Z]{2})(?P<rest>.+)$")


def infer_countries_from_gir_message_ref_id(message_ref_id: Optional[str]) -> Tuple[Optional[str], Optional[str], Optional[int]]:
    """Infer (transmitting_country, receiving_country, year) for the Status Message.

    For CA-to-CA exchange, the Status Message is sent by the *receiving* CA of the original GIR.

    OECD GIR MessageRefId convention used by our validator: CCYYYYCCUniqueID.
      - First CC: sender of original GIR
      - Second CC: receiver of original GIR

    Therefore:
      - TransmittingCountry (Status Message sender) = original receiver CC
      - ReceivingCountry (Status Message recipient) = original sender CC
    """
    if not message_ref_id:
        return None, None, None
    m = _MSGREF_RE.match(message_ref_id.strip().upper())
    if not m:
        return None, None, None
    send = m.group("send")
    year = int(m.group("year"))
    recv = m.group("recv")
    return recv, send, year


def build_status_message_ref_id(
    *,
    transmitting_country: str,
    receiving_country: str,
    year: int,
    unique: str,
) -> str:
    """Build a Status Message MessageRefID following OECD guidance.

    Guidance: start with "Status", then sender country, year, receiver country, then unique identifier.
    Example: StatusFR2027CA123456789.
    """
    tc = (transmitting_country or "").strip().upper()[:2]
    rc = (receiving_country or "").strip().upper()[:2]
    u = re.sub(r"[^A-Za-z0-9]", "", (unique or ""))
    if not u:
        u = sha1(f"{tc}{year}{rc}".encode("utf-8")).hexdigest()[:12].upper()

    ref = f"Status{tc}{int(year):04d}{rc}{u}"
    # Schema limit is 170 chars.
    return ref[:170]


def _norm_xpath(xp: Optional[str]) -> str:
    if not xp:
        return ""
    x = xp.strip()
    x = x.replace(
        "/GLOBE_OECD/GLOBEBody/eForm/Payload/GLOBE_OECD/GLOBEBody",
        "/GLOBE_OECD/GLOBEBody",
    )
    x = x.replace(
        "/eForm/Payload/GLOBE_OECD/GLOBEBody",
        "/GLOBE_OECD/GLOBEBody",
    )
    x = re.sub(r"/{2,}", "/", x)
    return x


def to_status_field_path(xp: Optional[str]) -> Optional[str]:
    """Convert engine xml_path to a Status Message FieldPath.

    OECD validation tables refer to paths like:
      - MessageSpec/MessageRefId
      - GLOBEBody/FilingInfo/...

    Our importer stores paths like:
      - /GLOBE_OECD/MessageSpec/MessageRefId
      - /GLOBE_OECD/GLOBEBody/FilingInfo/...

    We strip the leading /GLOBE_OECD so FieldPath matches OECD guidance.
    """
    if not xp:
        return None
    x = _norm_xpath(xp)
    if x.startswith("/GLOBE_OECD/"):
        x = "/" + x[len("/GLOBE_OECD/") :]
    # Ensure leading slash
    if not x.startswith("/"):
        x = "/" + x
    # Status Message schema limits FieldPath to 400 chars.
    if len(x) > 400:
        x = "/" + x[-399:]
    return x


def _details_text(issue: models.ValidationIssue) -> str:
    parts: List[str] = []
    if (issue.message or "").strip():
        parts.append(issue.message.strip())
    if (issue.how_to_fix or "").strip():
        parts.append("How to fix: " + issue.how_to_fix.strip())
    txt = "\n".join(parts).strip()
    # Schema limit is 4000 chars.
    return txt[:4000]


def _docref_ids_for_issue(db: Session, *, filing_id: str, issue: models.ValidationIssue) -> List[str]:
    """Best-effort find DocRefId(s) associated with a ValidationIssue.

    We try exact scope match first (filer/juris/entity/context_key), then
    fall back to prefix matching using issue.xml_path.
    """
    # Base filters
    q = db.query(models.DataPoint.xml_path, models.DataPoint.value_raw).filter(models.DataPoint.filing_id == filing_id)

    def _match_nullable(col, val):
        return col.is_(None) if val is None else col == val

    q = q.filter(_match_nullable(models.DataPoint.filer_code, issue.filer_code))
    q = q.filter(_match_nullable(models.DataPoint.jurisdiction_code, issue.jurisdiction_code))
    q = q.filter(_match_nullable(models.DataPoint.entity_code, issue.entity_code))

    # DocRefId leaf (but not CorrDocRefId)
    p = func.lower(models.DataPoint.xml_path)
    q = q.filter(p.like("%/docrefid")).filter(~p.like("%/corrdocrefid"))

    # 1) Exact context_key match (best)
    q1 = q.filter(_match_nullable(models.DataPoint.context_key, issue.context_key))
    rows = q1.limit(50).all()
    vals = { (v or "").strip() for (_xp, v) in rows if (v or "").strip() }
    if vals:
        return sorted(vals)

    # 2) Prefix match using the issue xml_path (fallback)
    issue_xp = _norm_xpath(issue.xml_path or "")
    if not issue_xp:
        return []

    rows2 = q.limit(200).all()
    out: Set[str] = set()
    for xp, v in rows2:
        vv = (v or "").strip()
        if not vv:
            continue
        base = _norm_xpath(xp or "")
        if base.lower().endswith("/docrefid"):
            base = base[: -len("/DocRefId")]
        if base and issue_xp.startswith(base):
            out.add(vv)
    return sorted(out)


def _get_status_message_target_namespace() -> Optional[str]:
    """Return the targetNamespace for the Status Message XSD bundle (if configured/present)."""
    try:
        _schema_dir, main_path = _resolve_schema_sources(
            xsd_zip_path=settings.status_xsd_zip_path,
            xsd_dir=settings.status_xsd_dir,
            main_xsd=settings.status_xsd_main,
            root_element_name="GIRStatusMessage_OECD",
            cache_env_var="STATUS_XSD_CACHE_DIR",
        )
        doc = etree.parse(str(main_path))
        root = doc.getroot()
        tn = (root.attrib.get("targetNamespace") or "").strip()
        return tn or None
    except Exception:
        return None


def determine_validation_status(issues: Sequence[models.ValidationIssue]) -> str:
    """Determine Accepted/Rejected following OECD Status Message relationship guidance."""
    codes = [int(i.error_number) for i in issues if i.error_number is not None]
    # If any file error or severe record error => reject.
    for c in codes:
        if 50000 <= c <= 69999:
            return "Rejected"
    # Otherwise, if there are any issues at all (e.g., 700xx) you *could* still accept.
    # OECD guidance says if no file/severe/other record errors -> Accepted. If errors indicated -> can still accept.
    # Here we accept by default when only 700xx are present.
    return "Accepted"


def generate_status_message_xml(
    *,
    db: Session,
    filing: models.Filing,
    run: models.ValidationRun,
    issues: Sequence[models.ValidationIssue],
    language: str = "EN",
    warning: Optional[str] = None,
    contact: Optional[str] = None,
    validated_by: Optional[List[str]] = None,
    transmitting_country: Optional[str] = None,
    receiving_country: Optional[str] = None,
    original_message_ref_id: Optional[str] = None,
    include_record_errors: bool = True,
    include_other_record_errors_700xx: bool = True,
    xsd_validate: Optional[bool] = None,
) -> Tuple[bytes, StatusMessageMeta]:
    """Generate a GIR Status Message XML from a completed ValidationRun.

    This is primarily intended for demo/self-check flows (customers validating their own GIR) but can also be
    used by tax administrations as a basis for producing schema-valid status messages.
    """

    lang = (language or "EN").strip().upper()[:2] or "EN"

    # Determine original message ref id from latest submission (best-effort)
    if original_message_ref_id is None:
        sub = (
            db.query(models.Submission)
            .filter(models.Submission.filing_id == filing.id)
            .order_by(models.Submission.imported_at.desc())
            .first()
        )
        if sub and (sub.message_ref_id or "").strip():
            original_message_ref_id = (sub.message_ref_id or "").strip()

    # Infer countries from message ref id if not provided
    inferred_tc, inferred_rc, inferred_year = infer_countries_from_gir_message_ref_id(original_message_ref_id)
    transmitting_country = (transmitting_country or inferred_tc or "").strip().upper()[:2] or None
    receiving_country = (receiving_country or inferred_rc or "").strip().upper()[:2] or None

    year = inferred_year or (filing.period_end.year if filing.period_end else datetime.utcnow().year)
    unique = sha1(f"{run.id}|{filing.id}".encode("utf-8")).hexdigest()[:12].upper()

    status_message_ref_id = build_status_message_ref_id(
        transmitting_country=transmitting_country or "XX",
        receiving_country=receiving_country or "XX",
        year=year,
        unique=unique,
    )

    # Decide Accepted/Rejected
    validation_status = determine_validation_status(issues)

    # OECD guidance: If rejected, at least one error must be specified.
    # If accepted, no errors is OK.

    # Default validated_by
    vb = validated_by[:] if validated_by else ["GIR Validation Engine"]
    vb = [x.strip() for x in vb if (x or "").strip()] or ["GIR Validation Engine"]

    # Group issues
    coded_issues = [i for i in issues if i.error_number is not None]

    file_issues = [i for i in coded_issues if 50000 <= int(i.error_number) <= 59999]

    record_issues_all = [i for i in coded_issues if int(i.error_number) >= 60000]
    if not include_record_errors:
        record_issues_all = []

    if not include_other_record_errors_700xx:
        record_issues_all = [i for i in record_issues_all if int(i.error_number) < 70000]

    # Determine namespace (if we can)
    tn = _get_status_message_target_namespace()

    def qname(local: str) -> str:
        return f"{{{tn}}}{local}" if tn else local

    # Root element + ns declarations
    nsmap = {None: tn} if tn else None
    root = etree.Element(qname("GIRStatusMessage_OECD"), nsmap=nsmap)

    # -----------------
    # MessageSpec
    # -----------------
    ms = etree.SubElement(root, qname("MessageSpec"))

    # SendingEntityIN is only for domestic use; we omit by default.
    if transmitting_country:
        etree.SubElement(ms, qname("TransmittingCountry")).text = transmitting_country
    if receiving_country:
        etree.SubElement(ms, qname("ReceivingCountry")).text = receiving_country

    etree.SubElement(ms, qname("MessageType")).text = "GIRMessageStatus"

    if warning:
        etree.SubElement(ms, qname("Warning")).text = (warning or "")[:4000]
    if contact:
        etree.SubElement(ms, qname("Contact")).text = (contact or "")[:4000]

    etree.SubElement(ms, qname("MessageRefID")).text = status_message_ref_id

    # MessageTypeIndic / CorrMessageRefID / ReportingPeriod are not used for the Status Message schema.

    etree.SubElement(ms, qname("Timestamp")).text = datetime.utcnow().replace(microsecond=0).isoformat()

    # -----------------
    # GIRStatusMessage body
    # -----------------
    body = etree.SubElement(root, qname("GIRStatusMessage"))

    # OriginalMessage
    orig = etree.SubElement(body, qname("OriginalMessage"))
    if original_message_ref_id:
        etree.SubElement(orig, qname("OriginalMessageRefID")).text = original_message_ref_id[:170]

    # ValidationErrors
    verr = etree.SubElement(body, qname("ValidationErrors"))

    # FileError elements (one per issue, de-duplicated)
    seen_file: Set[Tuple[int, str]] = set()
    for i in file_issues:
        code = int(i.error_number)
        det = _details_text(i)
        key = (code, det)
        if key in seen_file:
            continue
        seen_file.add(key)

        fe = etree.SubElement(verr, qname("FileError"))
        etree.SubElement(fe, qname("Code")).text = str(code)
        if det:
            d = etree.SubElement(fe, qname("Details"))
            d.text = det
            d.set("Language", lang)

    # RecordError elements (group by code)
    rec_by_code: Dict[int, List[models.ValidationIssue]] = {}
    for i in record_issues_all:
        code = int(i.error_number)
        rec_by_code.setdefault(code, []).append(i)

    for code in sorted(rec_by_code.keys()):
        group = rec_by_code[code]
        relem = etree.SubElement(verr, qname("RecordError"))
        etree.SubElement(relem, qname("Code")).text = str(code)

        # Details: combine distinct messages, bounded by 4000.
        details_parts: List[str] = []
        seen_det: Set[str] = set()
        for i in group:
            det = _details_text(i)
            if det and det not in seen_det:
                seen_det.add(det)
                details_parts.append(det)
        det_all = "\n---\n".join(details_parts)[:4000]
        if det_all:
            d = etree.SubElement(relem, qname("Details"))
            d.text = det_all
            d.set("Language", lang)

        # DocRefIDInError (best-effort union)
        docrefs: Set[str] = set()
        for i in group:
            for dr in _docref_ids_for_issue(db, filing_id=filing.id, issue=i):
                if dr:
                    docrefs.add(dr[:170])
        for dr in sorted(docrefs):
            etree.SubElement(relem, qname("DocRefIDInError")).text = dr

        # FieldsInError / FieldPath (best-effort union)
        field_paths: Set[str] = set()
        for i in group:
            fp = to_status_field_path(i.xml_path)
            if fp:
                field_paths.add(fp)
        for fp in sorted(field_paths):
            fie = etree.SubElement(relem, qname("FieldsInError"))
            etree.SubElement(fie, qname("FieldPath")).text = fp

    # ValidationResult
    vr = etree.SubElement(body, qname("ValidationResult"))
    etree.SubElement(vr, qname("Status")).text = validation_status
    for who in vb:
        etree.SubElement(vr, qname("ValidatedBy")).text = who[:4000]

    # Serialize
    xml_bytes = etree.tostring(
        root,
        xml_declaration=True,
        encoding="UTF-8",
        pretty_print=True,
    )

    # Optionally validate against Status Message XSD
    if xsd_validate is None:
        xsd_validate = (settings.status_xsd_validation_mode or "off").strip().lower() == "on"

    if xsd_validate:
        try:
            res = validate_xml_against_status_message_xsd(
                xml_bytes,
                xsd_zip_path=settings.status_xsd_zip_path,
                xsd_dir=settings.status_xsd_dir,
                main_xsd=settings.status_xsd_main,
                max_errors=50,
            )
            if not res.valid:
                # If namespacing is the issue, try a no-namespace variant as a fallback.
                if tn:
                    root2 = etree.fromstring(xml_bytes)
                    # Strip namespaces (best-effort)
                    for el in root2.iter():
                        if isinstance(el.tag, str) and el.tag.startswith("{"):
                            el.tag = el.tag.split("}", 1)[1]
                    xml2 = etree.tostring(root2, xml_declaration=True, encoding="UTF-8", pretty_print=True)
                    res2 = validate_xml_against_status_message_xsd(
                        xml2,
                        xsd_zip_path=settings.status_xsd_zip_path,
                        xsd_dir=settings.status_xsd_dir,
                        main_xsd=settings.status_xsd_main,
                        max_errors=50,
                    )
                    if res2.valid:
                        xml_bytes = xml2
                        tn = None
                    else:
                        raise ValueError("; ".join(res.errors[:5]))
                else:
                    raise ValueError("; ".join(res.errors[:5]))
        except FileNotFoundError:
            # Schema not present; ignore when xsd_validate requested.
            pass

    meta = StatusMessageMeta(
        transmitting_country=transmitting_country,
        receiving_country=receiving_country,
        original_message_ref_id=original_message_ref_id,
        status_message_ref_id=status_message_ref_id,
        validation_status=validation_status,
        used_namespace=tn,
    )

    return xml_bytes, meta
