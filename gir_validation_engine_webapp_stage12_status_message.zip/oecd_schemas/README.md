# OECD schema ZIPs

This folder is intentionally kept in the repo so optional XSD validation can run on Render.

## 1) GIR XML Schema (for validating GIR submissions)

Download the **GloBE Information Return (Pillar Two) XML Schema** bundle from the OECD (XML Schema ZIP) and place it here as:

- `oecd_schemas/oecd_gir_xml_schema.zip`

Then enable GIR XSD validation via:

- `XSD_VALIDATION_MODE=on` (server default), or
- per-request `strict_xsd=true` on the import/validate endpoints.

## 2) GIR Status Message XML Schema (for validating/generating Status Messages)

Download the **GloBE Information Return (Pillar Two) Status Message XML Schema** bundle (XML Schema ZIP) and place it here as:

- `oecd_schemas/xml-schema-gir-status-message.zip`

(That filename matches the OECD download name; you can rename it if you prefer, but then set `STATUS_XSD_ZIP_PATH` accordingly.)

Then enable Status Message XSD validation via:

- `STATUS_XSD_VALIDATION_MODE=on` (server default), or
- per-request `xsd_validate=true` on the Status Message export endpoint, or
- per-request `strict_xsd=true` on `/imports/status-message-xml:validate`.
