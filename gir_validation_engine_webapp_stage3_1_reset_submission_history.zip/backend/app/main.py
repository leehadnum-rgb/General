from __future__ import annotations

from fastapi import Depends, FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.auth import require_api_key
from app.core.settings import settings
from app.db.base import Base
from app.db.session import engine

from app.api.routes_health import router as health_router
from app.api.routes_config import router as config_router
from app.api.routes_filings import router as filings_router
from app.api.routes_registers import router as registers_router
from app.api.routes_datapoints import router as datapoints_router
from app.api.routes_imports import router as imports_router
from app.api.routes_validation import router as validation_router
from app.api.routes_exports import router as exports_router
from app.api.routes_reconciliation import router as reconciliation_router
from app.api.routes_submissions import router as submissions_router


app = FastAPI(
    title="GIR Validation Engine (Sprint 2.5 Dashboards Cache + Exports)",
    version="0.3.6",
)


# -----------------------------
# CORS (browser-based frontends)
# -----------------------------

origins_raw = (settings.cors_allow_origins or "*").strip()
if origins_raw == "*":
    allow_origins = ["*"]
else:
    allow_origins = [o.strip() for o in origins_raw.split(",") if o.strip()]

app.add_middleware(
    CORSMiddleware,
    allow_origins=allow_origins,
    allow_credentials=False if allow_origins == ["*"] else True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def startup():
    # Convenience for the current sprint. For production, use Alembic migrations.
    Base.metadata.create_all(bind=engine)


# Public
app.include_router(health_router)


# Protected (only when GIR_API_KEY is set)
protected = [Depends(require_api_key)]
app.include_router(config_router, dependencies=protected)
app.include_router(filings_router, dependencies=protected)
app.include_router(registers_router, dependencies=protected)
app.include_router(datapoints_router, dependencies=protected)
app.include_router(imports_router, dependencies=protected)
app.include_router(validation_router, dependencies=protected)
app.include_router(exports_router, dependencies=protected)
app.include_router(reconciliation_router, dependencies=protected)
app.include_router(submissions_router, dependencies=protected)
