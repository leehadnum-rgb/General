from __future__ import annotations

import csv
import io
import re
from typing import Any, Dict, List, Optional, Tuple

from pydantic import BaseModel, Field

from app.services.models_v2 import EntityFactsV2


class CsvRowIssue(BaseModel):
    """Issue encountered while parsing a CSV row."""

    severity: str = Field(..., description="'error' or 'warning'")
    row_number: int = Field(..., ge=1, description="1-indexed row number in the CSV (excluding header).")
    field: Optional[str] = Field(default=None, description="Field name (if applicable).")
    message: str


class EntitiesCsvParseResult(BaseModel):
    """Structured parse result returned by /api/v2/entities/parse-csv."""

    entities: List[EntityFactsV2] = Field(default_factory=list)
    grouped_entities: Dict[str, List[EntityFactsV2]] = Field(
        default_factory=dict,
        description=(
            "If the CSV provides tested_jurisdiction_id, parsed entities are also grouped here by that id. "
            "Rows without a tested_jurisdiction_id are grouped under '__UNASSIGNED__'."
        ),
    )
    issues: List[CsvRowIssue] = Field(default_factory=list)
    detected_columns: List[str] = Field(default_factory=list)
    ignored_columns: List[str] = Field(default_factory=list)
    rows_with_tested_jurisdiction_id: bool = False


_NUM_RE = re.compile(r"[^0-9eE+\-\.]")


def _norm_header(h: str) -> str:
    # Lowercase, trim, replace spaces/dashes with underscores
    h = (h or "").strip().lower()
    h = re.sub(r"[\s\-]+", "_", h)
    return h


# Common aliases to make uploads more forgiving
_ALIASES: Dict[str, str] = {
    "pbt": "jpbt",
    "profit_before_tax": "jpbt",
    "profit_or_loss_before_tax": "jpbt",
    "current_tax": "current_tax_expense",
    "current_tax_charge": "current_tax_expense",
    "deferred_tax": "deferred_tax_expense",
    "deferred_tax_charge": "deferred_tax_expense",
    "entity": "entity_name",
    "name": "entity_name",
    "jurisdiction": "jurisdiction_code",
    "country": "jurisdiction_code",
}


def _parse_bool(raw: str) -> Optional[bool]:
    s = (raw or "").strip().lower()
    if s == "":
        return None
    if s in {"true", "t", "yes", "y", "1"}:
        return True
    if s in {"false", "f", "no", "n", "0"}:
        return False
    return None


def _parse_float(raw: str) -> Optional[float]:
    """Parse float from a CSV cell.

    Supports:
    - thousand separators
    - currency symbols
    - parentheses for negatives
    """

    if raw is None:
        return None
    s = str(raw).strip()
    if s == "":
        return None

    neg = False
    if s.startswith("(") and s.endswith(")"):
        neg = True
        s = s[1:-1]

    # remove non-numeric characters except + - . e E
    s = _NUM_RE.sub("", s)
    if s in {"", "+", "-", "."}:
        return None
    try:
        v = float(s)
        return -v if neg else v
    except ValueError:
        return None


def generate_entities_csv_template() -> bytes:
    """Generate a CSV template for Entity roll-up uploads."""

    headers = [
        "tested_jurisdiction_id",
        "jurisdiction_code",
        "entity_id",
        "entity_name",
        "jpbt",
        "current_tax_expense",
        "deferred_tax_expense",
        "accounted_tax_rate",
        "excluded_dividends",
        "excluded_equity_gains_losses",
        "taxes_not_covered",
        "tax_refunds_and_credits_adjustment",
    ]

    example = {
        "tested_jurisdiction_id": "GB_MAIN",
        "jurisdiction_code": "GB",
        "entity_id": "GB-1",
        "entity_name": "Example Entity 1",
        "jpbt": "1000",
        "current_tax_expense": "160",
        "deferred_tax_expense": "0",
        "accounted_tax_rate": "0.25",
        "excluded_dividends": "",
        "excluded_equity_gains_losses": "",
        "taxes_not_covered": "",
        "tax_refunds_and_credits_adjustment": "",
    }

    buf = io.StringIO(newline="")
    writer = csv.DictWriter(buf, fieldnames=headers)
    writer.writeheader()
    writer.writerow(example)
    return buf.getvalue().encode("utf-8")


def parse_entities_csv(
    contents: bytes,
    *,
    default_tested_jurisdiction_id: Optional[str] = None,
    default_jurisdiction_code: Optional[str] = None,
) -> EntitiesCsvParseResult:
    """Parse entity roll-up CSV into EntityFactsV2 rows.

    Notes:
    - The v2 engine groups entities by tested_jurisdiction_id (bucket) rather than jurisdiction_code.
    - If a CSV includes tested_jurisdiction_id, it is carried through only as metadata for the UI.
      (EntityFactsV2 does not include tested_jurisdiction_id itself.)
    """

    text = contents.decode("utf-8-sig", errors="replace")
    buf = io.StringIO(text)

    reader = csv.DictReader(buf)
    if reader.fieldnames is None:
        return EntitiesCsvParseResult(
            entities=[],
            issues=[CsvRowIssue(severity="error", row_number=1, field=None, message="CSV is missing a header row.")],
        )

    # Build header mapping
    raw_headers = list(reader.fieldnames)
    norm_to_raw: Dict[str, str] = {}
    for h in raw_headers:
        nh = _norm_header(h)
        nh = _ALIASES.get(nh, nh)
        # first wins
        if nh and nh not in norm_to_raw:
            norm_to_raw[nh] = h

    detected = list(norm_to_raw.keys())
    out = EntitiesCsvParseResult(detected_columns=raw_headers)

    # Figure out which columns we can map to EntityFactsV2 scalar fields
    model_fields = EntityFactsV2.model_fields
    scalar_fields: set[str] = set()
    for fname, finfo in model_fields.items():
        ann = finfo.annotation
        # allow the common scalar fields
        if ann in {str, float, bool, Optional[str], Optional[float], Optional[bool], Optional[int], int}:
            scalar_fields.add(fname)

    # tested_jurisdiction_id is handled separately
    has_tj_col = "tested_jurisdiction_id" in detected
    out.rows_with_tested_jurisdiction_id = bool(has_tj_col or default_tested_jurisdiction_id)

    ignored_cols: List[str] = []
    for nh in detected:
        if nh in {"tested_jurisdiction_id"}:
            continue
        if nh not in scalar_fields and nh not in {"entity", "name", "pbt", "profit_before_tax"}:
            ignored_cols.append(norm_to_raw.get(nh, nh))
    out.ignored_columns = ignored_cols

    # Parse rows
    entities: List[EntityFactsV2] = []
    grouped: Dict[str, List[EntityFactsV2]] = {}
    issues: List[CsvRowIssue] = []

    for i, row in enumerate(reader, start=1):
        # 1-indexed data row number
        rownum = i
        data: Dict[str, Any] = {}

        # tested_jurisdiction_id meta
        tj_from_row = None
        if has_tj_col:
            tj_from_row = (row.get(norm_to_raw["tested_jurisdiction_id"]) or "").strip() or None
        tj_effective = default_tested_jurisdiction_id or tj_from_row

        # Map scalar fields
        for nh, raw_h in norm_to_raw.items():
            if nh == "tested_jurisdiction_id":
                continue
            if nh in _ALIASES:
                nh = _ALIASES[nh]

            if nh not in scalar_fields:
                continue

            raw_val = row.get(raw_h)
            ann = model_fields[nh].annotation
            if ann in {float, Optional[float], int, Optional[int]}:
                v = _parse_float(raw_val)
                if v is None:
                    continue
                data[nh] = float(v)
            elif ann in {bool, Optional[bool]}:
                bv = _parse_bool(str(raw_val) if raw_val is not None else "")
                if bv is None:
                    continue
                data[nh] = bool(bv)
            else:
                sv = ("" if raw_val is None else str(raw_val)).strip()
                if sv == "":
                    continue
                data[nh] = sv

        # Apply defaults for jurisdiction_code if provided
        if default_jurisdiction_code and not data.get("jurisdiction_code"):
            data["jurisdiction_code"] = default_jurisdiction_code

        # Required fields
        if not data.get("entity_name"):
            # Try entity_id, else fallback
            fallback = data.get("entity_id") or f"Entity {rownum}"
            data["entity_name"] = str(fallback)
            issues.append(
                CsvRowIssue(
                    severity="warning",
                    row_number=rownum,
                    field="entity_name",
                    message="entity_name missing; populated from entity_id/row number.",
                )
            )

        if data.get("jpbt") is None:
            issues.append(
                CsvRowIssue(
                    severity="error",
                    row_number=rownum,
                    field="jpbt",
                    message="jpbt is required and was not provided or could not be parsed as a number.",
                )
            )
            continue

        # Even though v2 allows jurisdiction_code=None, it can help the UI to carry it through.
        # If neither row nor default provides it, warn (but do not fail).
        if not data.get("jurisdiction_code"):
            issues.append(
                CsvRowIssue(
                    severity="warning",
                    row_number=rownum,
                    field="jurisdiction_code",
                    message=(
                        "jurisdiction_code missing. This is OK for v2 roll-up inside a Tested Jurisdiction, "
                        "but providing it helps validation and reporting."
                    ),
                )
            )

        # Build entity
        try:
            ent = EntityFactsV2(**data)
            entities.append(ent)
            key = tj_effective or "__UNASSIGNED__"
            grouped.setdefault(key, []).append(ent)

            if has_tj_col and not tj_effective:
                issues.append(
                    CsvRowIssue(
                        severity="warning",
                        row_number=rownum,
                        field="tested_jurisdiction_id",
                        message="tested_jurisdiction_id column exists but this row is blank; grouped under '__UNASSIGNED__'.",
                    )
                )
        except Exception as e:
            issues.append(
                CsvRowIssue(
                    severity="error",
                    row_number=rownum,
                    field=None,
                    message=f"Row could not be parsed into an entity: {e}",
                )
            )

    out.entities = entities
    out.grouped_entities = grouped
    out.issues = issues
    return out
