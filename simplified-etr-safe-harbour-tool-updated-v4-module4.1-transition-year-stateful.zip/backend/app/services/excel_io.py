from __future__ import annotations

import io
import tempfile
from datetime import date
from typing import Any

import openpyxl
from openpyxl import Workbook
from openpyxl.utils import get_column_letter

from openpyxl.worksheet.datavalidation import DataValidation

from app.services.models import CalculationRequest, JurisdictionInput, EntityInput, AdjustmentLine, ElectionRecord
from app.services.election_catalog import ELECTION_DEFS, ELECTIONS_BY_CODE


def _autosize(ws):
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            if cell.value is None:
                continue
            max_len = max(max_len, len(str(cell.value)))
        ws.column_dimensions[col_letter].width = min(60, max(12, max_len + 2))


def build_template_xlsx() -> str:
    """Create an Excel template and return a file path."""
    wb: Workbook = openpyxl.Workbook()

    # Instructions
    ws0 = wb.active
    ws0.title = "Instructions"
    ws0["A1"] = "Simplified ETR Safe Harbour Tool - Input Template (Prototype)"
    ws0["A3"] = "Choose an input mode in Jurisdictions!C2: 'jurisdiction' (default) or 'entity_rollup'."
    ws0["A4"] = "If using 'jurisdiction' mode: fill the Jurisdictions sheet (one row per Tested Jurisdiction)."
    ws0["A5"] = "If using 'entity_rollup' mode: fill the Entities sheet (one row per Constituent Entity) and (optionally) provide elections/eligibility in Jurisdictions."
    ws0["A6"] = "Optional: add additional income/tax adjustments in the IncomeAdjustments / TaxAdjustments sheets (jurisdiction-level)."
    ws0["A7"] = "Optional: record elections and add net impacts in the ElectionAdjustments sheet (jurisdiction-level)."
    ws0["A8"] = "Key fields:"
    ws0["A9"] = "- fiscal_year_start_date: YYYY-MM-DD (in Jurisdictions sheet, cell A2)"
    ws0["A10"] = "- minimum_rate: default 0.15 (cell B2)"
    ws0["A11"] = "- input_mode: 'jurisdiction' or 'entity_rollup' (cell C2)"
    ws0["A13"] = "Notes:"
    ws0["A14"] = "- JPBT is Jurisdictional Profit (or Loss) before Income Tax (PBT analogue)."
    ws0["A15"] = "- Enter Excluded Dividends / Excluded Equity Gains as positive numbers; tool subtracts them from income."
    ws0["A16"] = "- Enter illegal payments and fines/penalties (>=250k) as positive numbers; tool adds them back to income."
    ws0["A17"] = "- Shipping / financial services industry adjustments are supported via dedicated columns."
    ws0["A18"] = "- Conditional/optional adjustments supported: equity-reported items, M&A simplification inputs, AFXGL, accrued pension adjustment."
    ws0["A19"] = "- Additional elections (incl. Chapter 3 elections, cross-border and TP elections) can be recorded via ElectionAdjustments."
    ws0["A20"] = "Sign convention:"
    ws0["A21"] = "- Most 'amount' fields are entered as signed values (+/-) unless a column says otherwise."
    ws0["A22"] = "- For 'taxes_on_excluded_*' enter as a positive amount; the tool subtracts it when the exclusion applies."
    ws0["A25"] = "This template is a starter. For production, build a UI wizard, richer validations, and store elections by year."

    _autosize(ws0)

    # Jurisdictions sheet
    ws = wb.create_sheet("Jurisdictions")
    ws["A1"] = "fiscal_year_start_date"
    ws["B1"] = "minimum_rate"
    ws["C1"] = "input_mode"
    # Optional early-start rule fields (applicability date)
    ws["D1"] = "apply_optional_2025_start_rule"
    ws["E1"] = "early_start_qdmtt_safe_harbour_applies"
    ws["F1"] = "early_start_only_one_jurisdiction_has_taxing_rights"
    ws["G1"] = "early_start_all_taxing_rights_jurisdictions_allow"
    ws["A2"] = "2027-01-01"
    ws["B2"] = 0.15
    ws["C2"] = "jurisdiction"
    ws["D2"] = False
    ws["E2"] = False
    ws["F2"] = False
    ws["G2"] = False

    # Helpful dropdown for input_mode
    try:
        dv_mode = DataValidation(type="list", formula1='"jurisdiction,entity_rollup"', allow_blank=False)
        ws.add_data_validation(dv_mode)
        dv_mode.add("C2")
    except Exception:
        pass

    headers = [
        "jurisdiction_code",
        "jpbt",

        # Basic adjustments (Box 3.2)
        "excluded_dividends",
        "excluded_equity_gains_losses",
        "illegal_payments",
        "fines_penalties_ge_250k",

        # Industry adjustments (Box 3.3)
        "insurance_company_income",
        "fs_annual_election_not_to_exclude_insurance_income",
        "at1_rt1_payments_receipts_adjustment",
        "at1_rt1_corresponding_tax_in_equity",
        "international_shipping_income",
        "qualified_ancillary_international_shipping_income",
        "shipping_five_year_election_not_to_exclude",
        "taxes_on_excluded_shipping_income",

        # Conditional adjustments (Box 3.4)
        "equity_reported_items_amount",
        "equity_reported_items_subject_to_tax_at_or_above_minimum_rate",
        "equity_reported_items_related_taxes_accounted_in_equity_or_oci",
        "equity_reported_items_related_tax_is_deferred_tax_liability",
        "equity_reported_items_related_dtl_is_recapture_exception_accrual",
        "mna_simplification_applied",
        "mna_goodwill_impairment_or_amortisation_addback",
        "mna_article_6_3_4_election_amount",

        # Optional exclusions (Box 3.5.2)
        "asymmetric_fx_gain_loss",
        "afxgl_five_year_election_not_to_apply",
        "accrued_pension_expense_adjustment",
        "pension_five_year_election_not_to_apply",

        # Taxes
        "current_tax_expense",
        "deferred_tax_expense",
        "consolidated_level_deferred_tax",
        "taxes_not_covered",
        "tax_refunds_and_credits_adjustment",
        "taxes_on_excluded_income",
        "uncertain_tax_positions_adjustment",
        "current_tax_not_paid_within_3y",
        "accounted_tax_rate",
        "valuation_allowance_impact",
        "tax_rate_change_impact",
        "deferred_tax_from_tax_credits",
        "non_rea_dtl_deferred_tax_expense",
        "non_rea_dtl_exception_applies",

        # M&A tax-side exclusions (used only when mna_simplification_applied=True)
        "mna_deferred_tax_accruals_to_exclude",
        "mna_goodwill_related_dtl_reversal_to_exclude",

        # Elections (Box 4.4, simplified)
        "election_include_other_covered_taxes",
        "election_include_equity_reported_taxes",
        "election_include_qrtc_mttc_credits_in_income",
        "election_include_qrtc_mttc_credits_in_taxes",

        # Eligibility / integrity (prototype)
        "ineligible_stateless",
        "ineligible_investment_entity",
        "ineligible_article7_3_outstanding_recapture",
        "stateless_exception_section_6_2_applies",
        "investment_entity_tax_transparency_election_applies",
        "no_topup_tax_in_prior_24_months",
        "reentry_no_topup_tax_in_prior_24_months",
        "integrity_rules_satisfied",
    ]
    for i, h in enumerate(headers, start=1):
        ws.cell(row=4, column=i, value=h)

    # Sample row
    sample = [
        "GB",
        1000000,
        0,
        0,
        0,
        0,
        # Industry adjustments
        0,
        False,
        0,
        0,
        0,
        0,
        False,
        0,
        # Conditional
        0,
        False,
        False,
        False,
        False,
        False,
        0,
        0,
        # Optional exclusions
        0,
        False,
        0,
        False,
        # Taxes
        180000,
        20000,
        0,
        0,
        0,
        0,
        0,
        0,
        0.25,
        0,
        0,
        0,
        0,
        False,
        # M&A tax-side
        0,
        0,
        # Elections
        0,
        0,
        0,
        0,
        # Eligibility / integrity
        False,
        False,
        False,
        False,
        False,
        True,
        None,
        True,
    ]
    for i, v in enumerate(sample, start=1):
        ws.cell(row=5, column=i, value=v)

    _autosize(ws)

    # Entities sheet (for input_mode = 'entity_rollup')
    ws_e = wb.create_sheet("Entities")
    entity_headers = [
        "entity_id",
        "entity_name",
        "jurisdiction_code",
        "jpbt",
        # Basic adjustments
        "excluded_dividends",
        "excluded_equity_gains_losses",
        "illegal_payments",
        "fines_penalties_ge_250k",
        # Industry amounts
        "insurance_company_income",
        "at1_rt1_payments_receipts_adjustment",
        "at1_rt1_corresponding_tax_in_equity",
        "international_shipping_income",
        "qualified_ancillary_international_shipping_income",
        "taxes_on_excluded_shipping_income",
        # Conditional/optional income amounts (aggregated)
        "equity_reported_items_amount",
        "mna_goodwill_impairment_or_amortisation_addback",
        "mna_article_6_3_4_election_amount",
        "asymmetric_fx_gain_loss",
        "accrued_pension_expense_adjustment",
        # Taxes
        "current_tax_expense",
        "deferred_tax_expense",
        "consolidated_level_deferred_tax",
        "taxes_not_covered",
        "tax_refunds_and_credits_adjustment",
        "taxes_on_excluded_income",
        "uncertain_tax_positions_adjustment",
        "current_tax_not_paid_within_3y",
        "accounted_tax_rate",
        "valuation_allowance_impact",
        "tax_rate_change_impact",
        "deferred_tax_from_tax_credits",
        "non_rea_dtl_deferred_tax_expense",
        "non_rea_dtl_exception_applies",
        # M&A tax-side amounts (aggregated; flags at jurisdiction meta level)
        "mna_deferred_tax_accruals_to_exclude",
        "mna_goodwill_related_dtl_reversal_to_exclude",
        # Elections (amounts)
        "election_include_other_covered_taxes",
        "election_include_equity_reported_taxes",
        "election_include_qrtc_mttc_credits_in_income",
        "election_include_qrtc_mttc_credits_in_taxes",
    ]
    ws_e.append(entity_headers)
    ws_e.append(
        [
            "GB-1",
            "Example UK Entity",
            "GB",
            1000000,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            180000,
            20000,
            0,
            0,
            0,
            0,
            0,
            0,
            0.25,
            0,
            0,
            0,
            0,
            False,
            0,
            0,
            0,
            0,
            0,
            0,
        ]
    )
    _autosize(ws_e)

    # Income adjustments sheet (optional)
    ws_i = wb.create_sheet("IncomeAdjustments")
    ws_i.append(["jurisdiction_code", "label", "amount", "note"])
    ws_i.append(["GB", "Example: bespoke election impact", 0, "Enter + / - amount"])
    _autosize(ws_i)

    # Tax adjustments sheet (optional)
    ws_t = wb.create_sheet("TaxAdjustments")
    ws_t.append(["jurisdiction_code", "label", "amount", "note"])
    ws_t.append(["GB", "Example: bespoke tax adjustment", 0, "Enter + / - amount"])
    _autosize(ws_t)

    # Election catalog + election adjustments
    ws_cat = wb.create_sheet("ElectionCatalog")
    ws_cat.append(["election_code", "group", "scope", "value_type", "term_type", "target_field", "description"])
    for e in ELECTION_DEFS:
        ws_cat.append([e.code, e.group, e.scope, e.value_type, getattr(e, "term_type", "ANNUAL"), e.target_field or "", e.description or ""])
    _autosize(ws_cat)

    ws_elec = wb.create_sheet("ElectionAdjustments")
    ws_elec.append(["jurisdiction_code", "scope", "election_code", "label", "bool_value", "amount", "note"])
    ws_elec.append(
        [
            "GB",
            "income",
            "CH3_GLOBE_ELECTION_NET_INCOME_ADJUSTMENT",
            "Example: Chapter 3 election net income impact",
            "",
            0,
            "Enter signed amount (+/-).",
        ]
    )
    ws_elec.append(
        [
            "GB",
            "tax",
            "ELECTION_INCLUDE_OTHER_COVERED_TAXES",
            "Annual election: other covered taxes",
            "",
            0,
            "Enter the amount to include in Simplified Taxes.",
        ]
    )

    # Add a drop-down list for election_code based on ElectionCatalog!
    try:
        n = 1 + len(ELECTION_DEFS)
        dv = DataValidation(
            type="list",
            formula1=f"=ElectionCatalog!$A$2:$A${n}",
            allow_blank=True,
        )
        ws_elec.add_data_validation(dv)
        # Apply to election_code column (C) for a reasonable number of rows.
        dv.add(f"C2:C1000")
    except Exception:
        # Data validation is nice-to-have only.
        pass

    _autosize(ws_elec)

    fd, path = tempfile.mkstemp(prefix="simplified_etr_template_", suffix=".xlsx")
    # Close the low-level fd, openpyxl will write to path.
    import os
    os.close(fd)
    wb.save(path)
    return path


def _as_bool(v: Any) -> bool | None:
    if v is None:
        return None
    if isinstance(v, bool):
        return v
    s = str(v).strip().lower()
    if s in {"true", "t", "yes", "y", "1"}:
        return True
    if s in {"false", "f", "no", "n", "0"}:
        return False
    return None


def parse_template_xlsx(contents: bytes) -> CalculationRequest:
    """Parse the Excel template into a CalculationRequest."""
    wb = openpyxl.load_workbook(io.BytesIO(contents), data_only=True)

    if "Jurisdictions" not in wb.sheetnames:
        raise ValueError("Template missing 'Jurisdictions' sheet.")

    ws = wb["Jurisdictions"]
    fy_str = ws["A2"].value
    min_rate = ws["B2"].value
    mode_raw = ws["C2"].value

    # Optional applicability date settings (if cells are blank, defaults remain False)
    apply_early = _as_bool(ws["D2"].value) or False
    early_qdmtt = _as_bool(ws["E2"].value) or False
    early_one_jur = _as_bool(ws["F2"].value) or False
    early_all_allow = _as_bool(ws["G2"].value) or False

    if not fy_str:
        raise ValueError("Missing fiscal_year_start_date in Jurisdictions!A2")
    fy = date.fromisoformat(str(fy_str))

    if min_rate is None:
        min_rate = 0.15
    min_rate = float(min_rate)

    input_mode = str(mode_raw).strip().lower() if mode_raw is not None else ""
    if input_mode not in {"jurisdiction", "entity_rollup"}:
        # Backward compatible inference if user uploads an older template.
        if "Entities" in wb.sheetnames:
            ws_e = wb["Entities"]
            has_entities = any(
                (r and any(v is not None and str(v).strip() != "" for v in r))
                for r in ws_e.iter_rows(min_row=2, values_only=True)
            )
            input_mode = "entity_rollup" if has_entities else "jurisdiction"
        else:
            input_mode = "jurisdiction"

    # headers at row 4, data from row 5 onwards
    headers = [c.value for c in ws[4] if c.value is not None]
    col_index = {h: i for i, h in enumerate(headers)}

    jurisdictions: list[JurisdictionInput] = []

    def cell(row, key):
        idx = col_index.get(key)
        if idx is None:
            return None
        return row[idx]

    for row in ws.iter_rows(min_row=5, values_only=True):
        if row is None:
            continue
        jcode = cell(row, "jurisdiction_code")
        if jcode is None or str(jcode).strip() == "":
            continue

        j = JurisdictionInput(
            jurisdiction_code=str(jcode).strip(),
            jpbt=float(cell(row, "jpbt") or 0.0),

            # Basic
            excluded_dividends=float(cell(row, "excluded_dividends") or 0.0),
            excluded_equity_gains_losses=float(cell(row, "excluded_equity_gains_losses") or 0.0),
            illegal_payments=float(cell(row, "illegal_payments") or 0.0),
            fines_penalties_ge_250k=float(cell(row, "fines_penalties_ge_250k") or 0.0),

            # Industry
            insurance_company_income=float(cell(row, "insurance_company_income") or 0.0),
            fs_annual_election_not_to_exclude_insurance_income=bool(
                _as_bool(cell(row, "fs_annual_election_not_to_exclude_insurance_income")) or False
            ),
            at1_rt1_payments_receipts_adjustment=float(cell(row, "at1_rt1_payments_receipts_adjustment") or 0.0),
            at1_rt1_corresponding_tax_in_equity=float(cell(row, "at1_rt1_corresponding_tax_in_equity") or 0.0),
            international_shipping_income=float(cell(row, "international_shipping_income") or 0.0),
            qualified_ancillary_international_shipping_income=float(
                cell(row, "qualified_ancillary_international_shipping_income") or 0.0
            ),
            shipping_five_year_election_not_to_exclude=bool(
                _as_bool(cell(row, "shipping_five_year_election_not_to_exclude")) or False
            ),
            taxes_on_excluded_shipping_income=float(cell(row, "taxes_on_excluded_shipping_income") or 0.0),

            # Conditional / optional income
            equity_reported_items_amount=float(cell(row, "equity_reported_items_amount") or 0.0),
            equity_reported_items_subject_to_tax_at_or_above_minimum_rate=bool(
                _as_bool(cell(row, "equity_reported_items_subject_to_tax_at_or_above_minimum_rate")) or False
            ),
            equity_reported_items_related_taxes_accounted_in_equity_or_oci=bool(
                _as_bool(cell(row, "equity_reported_items_related_taxes_accounted_in_equity_or_oci")) or False
            ),
            equity_reported_items_related_tax_is_deferred_tax_liability=bool(
                _as_bool(cell(row, "equity_reported_items_related_tax_is_deferred_tax_liability")) or False
            ),
            equity_reported_items_related_dtl_is_recapture_exception_accrual=bool(
                _as_bool(cell(row, "equity_reported_items_related_dtl_is_recapture_exception_accrual")) or False
            ),

            mna_simplification_applied=bool(_as_bool(cell(row, "mna_simplification_applied")) or False),
            mna_goodwill_impairment_or_amortisation_addback=float(
                cell(row, "mna_goodwill_impairment_or_amortisation_addback") or 0.0
            ),
            mna_article_6_3_4_election_amount=float(cell(row, "mna_article_6_3_4_election_amount") or 0.0),

            asymmetric_fx_gain_loss=float(cell(row, "asymmetric_fx_gain_loss") or 0.0),
            afxgl_five_year_election_not_to_apply=bool(
                _as_bool(cell(row, "afxgl_five_year_election_not_to_apply")) or False
            ),
            accrued_pension_expense_adjustment=float(cell(row, "accrued_pension_expense_adjustment") or 0.0),
            pension_five_year_election_not_to_apply=bool(
                _as_bool(cell(row, "pension_five_year_election_not_to_apply")) or False
            ),

            # Taxes
            current_tax_expense=float(cell(row, "current_tax_expense") or 0.0),
            deferred_tax_expense=float(cell(row, "deferred_tax_expense") or 0.0),
            consolidated_level_deferred_tax=float(cell(row, "consolidated_level_deferred_tax") or 0.0),
            taxes_not_covered=float(cell(row, "taxes_not_covered") or 0.0),
            tax_refunds_and_credits_adjustment=float(cell(row, "tax_refunds_and_credits_adjustment") or 0.0),
            taxes_on_excluded_income=float(cell(row, "taxes_on_excluded_income") or 0.0),
            uncertain_tax_positions_adjustment=float(cell(row, "uncertain_tax_positions_adjustment") or 0.0),
            current_tax_not_paid_within_3y=float(cell(row, "current_tax_not_paid_within_3y") or 0.0),
            accounted_tax_rate=float(cell(row, "accounted_tax_rate"))
            if cell(row, "accounted_tax_rate") is not None
            else None,
            valuation_allowance_impact=float(cell(row, "valuation_allowance_impact") or 0.0),
            tax_rate_change_impact=float(cell(row, "tax_rate_change_impact") or 0.0),
            deferred_tax_from_tax_credits=float(cell(row, "deferred_tax_from_tax_credits") or 0.0),
            non_rea_dtl_deferred_tax_expense=float(cell(row, "non_rea_dtl_deferred_tax_expense") or 0.0),
            non_rea_dtl_exception_applies=bool(_as_bool(cell(row, "non_rea_dtl_exception_applies")) or False),

            mna_deferred_tax_accruals_to_exclude=float(cell(row, "mna_deferred_tax_accruals_to_exclude") or 0.0),
            mna_goodwill_related_dtl_reversal_to_exclude=float(
                cell(row, "mna_goodwill_related_dtl_reversal_to_exclude") or 0.0
            ),

            # Elections
            election_include_other_covered_taxes=float(cell(row, "election_include_other_covered_taxes") or 0.0),
            election_include_equity_reported_taxes=float(cell(row, "election_include_equity_reported_taxes") or 0.0),
            election_include_qrtc_mttc_credits_in_income=float(
                cell(row, "election_include_qrtc_mttc_credits_in_income") or 0.0
            ),
            election_include_qrtc_mttc_credits_in_taxes=float(
                cell(row, "election_include_qrtc_mttc_credits_in_taxes") or 0.0
            ),

            # Eligibility / integrity
            ineligible_stateless=bool(_as_bool(cell(row, "ineligible_stateless")) or False),
            ineligible_investment_entity=bool(_as_bool(cell(row, "ineligible_investment_entity")) or False),
            ineligible_article7_3_outstanding_recapture=bool(
                _as_bool(cell(row, "ineligible_article7_3_outstanding_recapture")) or False
            ),
            stateless_exception_section_6_2_applies=bool(
                _as_bool(cell(row, "stateless_exception_section_6_2_applies")) or False
            ),
            investment_entity_tax_transparency_election_applies=bool(
                _as_bool(cell(row, "investment_entity_tax_transparency_election_applies")) or False
            ),
            no_topup_tax_in_prior_24_months=bool(
                _as_bool(cell(row, "no_topup_tax_in_prior_24_months"))
                if cell(row, "no_topup_tax_in_prior_24_months") is not None
                else True
            ),
            reentry_no_topup_tax_in_prior_24_months=_as_bool(cell(row, "reentry_no_topup_tax_in_prior_24_months")),
            integrity_rules_satisfied=bool(
                _as_bool(cell(row, "integrity_rules_satisfied"))
                if cell(row, "integrity_rules_satisfied") is not None
                else True
            ),
        )
        jurisdictions.append(j)

    def _get_or_create_jurisdiction(code: str) -> JurisdictionInput:
        code = str(code).strip()
        for j in jurisdictions:
            if j.jurisdiction_code == code:
                return j
        # Create a stub meta row so adjustments/elections can be provided even in entity_rollup mode.
        j = JurisdictionInput(jurisdiction_code=code, jpbt=0.0)
        jurisdictions.append(j)
        return j

    # Entity roll-up inputs (optional)
    entities: list[EntityInput] = []
    if input_mode == "entity_rollup":
        if "Entities" not in wb.sheetnames:
            raise ValueError("input_mode='entity_rollup' but workbook is missing 'Entities' sheet.")

        ws_e = wb["Entities"]
        e_headers = [c.value for c in ws_e[1] if c.value is not None]
        e_col_index = {h: i for i, h in enumerate(e_headers)}

        def e_cell(row, key):
            idx = e_col_index.get(key)
            if idx is None:
                return None
            return row[idx]

        for row in ws_e.iter_rows(min_row=2, values_only=True):
            if not row:
                continue
            jcode = e_cell(row, "jurisdiction_code")
            name = e_cell(row, "entity_name")
            if jcode is None or str(jcode).strip() == "" or name is None or str(name).strip() == "":
                continue

            entities.append(
                EntityInput(
                    entity_id=str(e_cell(row, "entity_id")).strip()
                    if e_cell(row, "entity_id") not in {None, ""}
                    else None,
                    entity_name=str(name).strip(),
                    jurisdiction_code=str(jcode).strip(),
                    jpbt=float(e_cell(row, "jpbt") or 0.0),

                    excluded_dividends=float(e_cell(row, "excluded_dividends") or 0.0),
                    excluded_equity_gains_losses=float(e_cell(row, "excluded_equity_gains_losses") or 0.0),
                    illegal_payments=float(e_cell(row, "illegal_payments") or 0.0),
                    fines_penalties_ge_250k=float(e_cell(row, "fines_penalties_ge_250k") or 0.0),

                    insurance_company_income=float(e_cell(row, "insurance_company_income") or 0.0),
                    at1_rt1_payments_receipts_adjustment=float(e_cell(row, "at1_rt1_payments_receipts_adjustment") or 0.0),
                    at1_rt1_corresponding_tax_in_equity=float(e_cell(row, "at1_rt1_corresponding_tax_in_equity") or 0.0),
                    international_shipping_income=float(e_cell(row, "international_shipping_income") or 0.0),
                    qualified_ancillary_international_shipping_income=float(
                        e_cell(row, "qualified_ancillary_international_shipping_income") or 0.0
                    ),
                    taxes_on_excluded_shipping_income=float(e_cell(row, "taxes_on_excluded_shipping_income") or 0.0),

                    equity_reported_items_amount=float(e_cell(row, "equity_reported_items_amount") or 0.0),
                    mna_goodwill_impairment_or_amortisation_addback=float(
                        e_cell(row, "mna_goodwill_impairment_or_amortisation_addback") or 0.0
                    ),
                    mna_article_6_3_4_election_amount=float(e_cell(row, "mna_article_6_3_4_election_amount") or 0.0),
                    asymmetric_fx_gain_loss=float(e_cell(row, "asymmetric_fx_gain_loss") or 0.0),
                    accrued_pension_expense_adjustment=float(e_cell(row, "accrued_pension_expense_adjustment") or 0.0),

                    current_tax_expense=float(e_cell(row, "current_tax_expense") or 0.0),
                    deferred_tax_expense=float(e_cell(row, "deferred_tax_expense") or 0.0),
                    consolidated_level_deferred_tax=float(e_cell(row, "consolidated_level_deferred_tax") or 0.0),
                    taxes_not_covered=float(e_cell(row, "taxes_not_covered") or 0.0),
                    tax_refunds_and_credits_adjustment=float(e_cell(row, "tax_refunds_and_credits_adjustment") or 0.0),
                    taxes_on_excluded_income=float(e_cell(row, "taxes_on_excluded_income") or 0.0),
                    uncertain_tax_positions_adjustment=float(e_cell(row, "uncertain_tax_positions_adjustment") or 0.0),
                    current_tax_not_paid_within_3y=float(e_cell(row, "current_tax_not_paid_within_3y") or 0.0),
                    accounted_tax_rate=float(e_cell(row, "accounted_tax_rate"))
                    if e_cell(row, "accounted_tax_rate") is not None
                    else None,
                    valuation_allowance_impact=float(e_cell(row, "valuation_allowance_impact") or 0.0),
                    tax_rate_change_impact=float(e_cell(row, "tax_rate_change_impact") or 0.0),
                    deferred_tax_from_tax_credits=float(e_cell(row, "deferred_tax_from_tax_credits") or 0.0),
                    non_rea_dtl_deferred_tax_expense=float(e_cell(row, "non_rea_dtl_deferred_tax_expense") or 0.0),
                    non_rea_dtl_exception_applies=bool(_as_bool(e_cell(row, "non_rea_dtl_exception_applies")) or False),

                    mna_deferred_tax_accruals_to_exclude=float(e_cell(row, "mna_deferred_tax_accruals_to_exclude") or 0.0),
                    mna_goodwill_related_dtl_reversal_to_exclude=float(
                        e_cell(row, "mna_goodwill_related_dtl_reversal_to_exclude") or 0.0
                    ),

                    election_include_other_covered_taxes=float(e_cell(row, "election_include_other_covered_taxes") or 0.0),
                    election_include_equity_reported_taxes=float(e_cell(row, "election_include_equity_reported_taxes") or 0.0),
                    election_include_qrtc_mttc_credits_in_income=float(
                        e_cell(row, "election_include_qrtc_mttc_credits_in_income") or 0.0
                    ),
                    election_include_qrtc_mttc_credits_in_taxes=float(
                        e_cell(row, "election_include_qrtc_mttc_credits_in_taxes") or 0.0
                    ),
                )
            )

    # Optional adjustments sheets
    if "IncomeAdjustments" in wb.sheetnames:
        ws_i = wb["IncomeAdjustments"]
        for r in ws_i.iter_rows(min_row=2, values_only=True):
            if not r or not r[0]:
                continue
            jcode, label, amt, note = r[0], r[1], r[2], r[3]
            if label is None or amt is None:
                continue
            j = _get_or_create_jurisdiction(str(jcode))
            j.other_income_adjustments.append(
                AdjustmentLine(label=str(label), amount=float(amt), note=str(note) if note else None)
            )

    if "TaxAdjustments" in wb.sheetnames:
        ws_t = wb["TaxAdjustments"]
        for r in ws_t.iter_rows(min_row=2, values_only=True):
            if not r or not r[0]:
                continue
            jcode, label, amt, note = r[0], r[1], r[2], r[3]
            if label is None or amt is None:
                continue
            j = _get_or_create_jurisdiction(str(jcode))
            j.other_tax_adjustments.append(
                AdjustmentLine(label=str(label), amount=float(amt), note=str(note) if note else None)
            )

    # Election adjustments sheet (optional)
    # Each row is recorded in `JurisdictionInput.election_records` for auditability.
    # Additionally, a row can either:
    #  - map directly to a known JurisdictionInput field (when election_code is in ElectionCatalog and has a target_field), or
    #  - if no mapping exists and scope is income/tax, be treated as a net AdjustmentLine based on the provided amount.
    if "ElectionAdjustments" in wb.sheetnames:
        ws_el = wb["ElectionAdjustments"]
        h = [c.value for c in ws_el[1] if c.value is not None]
        col = {name: i for i, name in enumerate(h)}

        def g(row, key):
            idx = col.get(key)
            if idx is None:
                return None
            return row[idx]

        for r in ws_el.iter_rows(min_row=2, values_only=True):
            if not r:
                continue
            jcode = g(r, "jurisdiction_code")
            code = g(r, "election_code")
            if jcode is None or str(jcode).strip() == "" or code is None or str(code).strip() == "":
                continue

            scope_raw = g(r, "scope")
            label = g(r, "label")
            bool_value = g(r, "bool_value")
            amt = g(r, "amount")
            note = g(r, "note")

            code_s = str(code).strip()
            defn = ELECTIONS_BY_CODE.get(code_s)

            # default scope from the catalogue, else use the sheet value
            scope = str(scope_raw).strip().lower() if scope_raw is not None else (defn.scope if defn else "")
            if isinstance(scope, str):
                scope = scope.lower()

            j = _get_or_create_jurisdiction(str(jcode))

            # Always record as an election record (audit trail)
            rec_bool = _as_bool(bool_value)
            rec_amount = float(amt) if amt not in {None, ""} else None
            rec_label = str(label).strip() if label not in {None, ""} else None
            rec_note = str(note) if note not in {None, ""} else None
            j.election_records.append(
                ElectionRecord(
                    scope=scope if scope in {"income", "tax", "eligibility", "metadata"} else "metadata",
                    election_code=code_s,
                    label=rec_label,
                    bool_value=rec_bool,
                    amount=rec_amount,
                    note=rec_note,
                )
            )

            if defn and defn.target_field:
                if defn.value_type == "bool":
                    setattr(j, defn.target_field, bool(_as_bool(bool_value)) or False)
                elif defn.value_type == "amount":
                    setattr(j, defn.target_field, float(amt or 0.0))
                else:
                    # text/other – ignore for prototype
                    pass
                continue

            # Unmapped codes: if scope is income/tax and an amount is provided, treat as net adjustment line.
            if scope in {"income", "tax"} and amt is not None:
                adj_label = str(label).strip() if label not in {None, ""} else code_s
                full_label = f"{code_s}: {adj_label}" if adj_label != code_s else code_s
                adj_note = str(note) if note not in {None, ""} else None

                if scope == "income":
                    j.other_income_adjustments.append(
                        AdjustmentLine(label=full_label, amount=float(amt), note=adj_note)
                    )
                elif scope == "tax":
                    j.other_tax_adjustments.append(
                        AdjustmentLine(label=full_label, amount=float(amt), note=adj_note)
                    )

    return CalculationRequest(
        fiscal_year_start_date=fy,
        minimum_rate=min_rate,
        input_mode=input_mode,
        apply_optional_2025_start_rule=apply_early,
        early_start_qdmtt_safe_harbour_applies=early_qdmtt,
        early_start_only_one_jurisdiction_has_taxing_rights=early_one_jur,
        early_start_all_taxing_rights_jurisdictions_allow=early_all_allow,
        jurisdictions=jurisdictions,
        entities=entities,
    )
