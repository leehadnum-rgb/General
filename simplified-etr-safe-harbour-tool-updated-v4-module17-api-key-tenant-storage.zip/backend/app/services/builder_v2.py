from __future__ import annotations

import re
from typing import Dict, List, Tuple, Optional

from app.services.models_v2 import (
    EntityFactsV2,
    TestedJurisdictionInputV2,
    TestedJurisdictionCompositionV2,
    AccountingBasisV2,
    TransitionYearV2,
    TestedJurisdictionsBuildRequestV2,
    TestedJurisdictionsBuildResponseV2,
    TestedJurisdictionsBuildAssignmentV2,
)

def _slug(s: str) -> str:
    s = (s or "").strip().upper()
    s = re.sub(r"[^A-Z0-9]+", "_", s)
    s = re.sub(r"_+", "_", s).strip("_")
    return s or "X"

def _bucket_for_entity(e: EntityFactsV2, req: TestedJurisdictionsBuildRequestV2) -> Tuple[str, Optional[str], str, str, Optional[str]]:
    """Return (tested_jurisdiction_id, jurisdiction_code, tested_jurisdiction_type, scope_context, scope_context_id).

    Module 15:
      - Supports separate scoping for Joint Venture Groups (JV) and Minority-Owned Constituent Entity groups (MOCE).
      - Within each scope context, entities may still be separated into investment-entity / tax-neutral / tax-transparent buckets.
    """
    code = (e.jurisdiction_code or "").strip().upper()
    et = getattr(e, "entity_type", None) or "STANDARD_CE"
    opt = req.options

    # Stateless bucket (group context not applicable)
    if et == "STATELESS" and opt.separate_stateless:
        return ("STATELESS", None, "stateless", "stateless", None)

    base = _slug(code) if code else "UNSPECIFIED"

    # Scope context
    scope_context = "main_group"
    scope_id: Optional[str] = None
    prefix = base

    jv = getattr(e, "jv_group_id", None)
    moce = getattr(e, "moce_group_id", None)

    if jv and opt.separate_joint_venture_groups:
        scope_context = "joint_venture_group"
        scope_id = str(jv)
        prefix = f"{base}_JV_{_slug(scope_id)}"
    elif moce and opt.separate_moce_groups:
        scope_context = "minority_owned_group"
        scope_id = str(moce)
        prefix = f"{base}_MOCE_{_slug(scope_id)}"

    # Type-specific bucketing within the scope context
    if et == "INVESTMENT_ENTITY" and opt.separate_investment_entities:
        return (f"{prefix}_INVEST", base if code else None, "investment_entity", scope_context, scope_id)
    if et == "INSURANCE_INVESTMENT_ENTITY" and opt.separate_investment_entities:
        return (f"{prefix}_INS_INVEST", base if code else None, "insurance_investment_entity", scope_context, scope_id)
    if et == "TAX_NEUTRAL_UPE" and opt.separate_tax_neutral_upe:
        return (f"{prefix}_TNUPE", base if code else None, "tax_neutral_upe", scope_context, scope_id)
    if et == "TAX_TRANSPARENT_ENTITY" and opt.separate_tax_transparent_entities:
        return (f"{prefix}_TTE", base if code else None, "tax_transparent", scope_context, scope_id)
    if et == "FLOW_THROUGH_ENTITY" and opt.separate_flow_through_entities:
        return (f"{prefix}_FTE", base if code else None, "flow_through", scope_context, scope_id)

    return (f"{prefix}_MAIN", base if code else None, "standard", scope_context, scope_id)



def build_tested_jurisdictions_from_entities(payload: TestedJurisdictionsBuildRequestV2) -> TestedJurisdictionsBuildResponseV2:
    """Build TestedJurisdictionInputV2 buckets from entity rows (UI helper).

    This is an opinionated convenience function designed for UI clients.
    It does not replace the OECD Tested Jurisdiction definition logic; it gives users a
    consistent starting structure.

    Bucketing rules (default):
      - One TJ per jurisdiction_code (CODE_MAIN)
      - Separate buckets for investment entities, tax-neutral UPE, tax-transparent, flow-through if enabled
      - Stateless bucket if entity_type=STATELESS and option enabled

    Each TJ uses aggregation_method='ENTITY_ROLLUP' with the supplied entities attached.
    """

    warnings: List[str] = []
    groups: Dict[str, List[EntityFactsV2]] = {}
    meta: Dict[str, Tuple[Optional[str], str, str, Optional[str]]] = {}  # tj_id -> (jurisdiction_code, tj_type, scope_context, scope_id)

    # Ensure entities have basic identifiers
    for i, e in enumerate(payload.entities or [], start=1):
        if not e.entity_name or str(e.entity_name).strip() == "":
            warnings.append(f"Entity row {i}: missing entity_name; setting to 'Entity {i}'.")
            e.entity_name = f"Entity {i}"
        if not getattr(e, "entity_id", None):
            # derive a stable-ish id
            derived = _slug(e.entity_name)
            e.entity_id = derived
            warnings.append(f"Entity '{e.entity_name}': entity_id missing; derived entity_id='{derived}'.")

        # Module 15 scoping warnings (if ids provided but separation disabled)
        if getattr(e, 'jv_group_id', None) and not payload.options.separate_joint_venture_groups:
            warnings.append(
                f"Entity '{e.entity_name}' has jv_group_id='{getattr(e, 'jv_group_id')}' but separate_joint_venture_groups is false; it will be included in the main Tested Jurisdiction bucket."
            )
        if getattr(e, 'moce_group_id', None) and not payload.options.separate_moce_groups:
            warnings.append(
                f"Entity '{e.entity_name}' has moce_group_id='{getattr(e, 'moce_group_id')}' but separate_moce_groups is false; it will be included in the main Tested Jurisdiction bucket."
            )

        tj_id, j_code, tj_type, scope_ctx, scope_id = _bucket_for_entity(e, payload)
        groups.setdefault(tj_id, []).append(e)
        meta[tj_id] = (j_code, tj_type, scope_ctx, scope_id)

    tested_jurisdictions: List[TestedJurisdictionInputV2] = []
    assignments: List[TestedJurisdictionsBuildAssignmentV2] = []

    for tj_id, ents in sorted(groups.items(), key=lambda kv: kv[0]):
        j_code, tj_type, scope_ctx, scope_id = meta.get(tj_id, (None, None, 'main_group', None))

        # Build a friendly label incorporating scoping context (Module 15)
        label_prefix = j_code or ("Unspecified" if tj_id != "STATELESS" else "Stateless")
        if scope_ctx == "joint_venture_group" and scope_id:
            label_prefix = f"{label_prefix} – JV {scope_id}"
        elif scope_ctx == "minority_owned_group" and scope_id:
            label_prefix = f"{label_prefix} – MOCE {scope_id}"
        elif tj_id == "STATELESS":
            label_prefix = "Stateless"

        label = tj_id
        if tj_id == "STATELESS":
            label = "Stateless"
        elif tj_id.endswith("_MAIN"):
            label = f"{label_prefix} – Main"
        elif tj_id.endswith("_INVEST"):
            label = f"{label_prefix} – Investment Entities"
        elif tj_id.endswith("_INS_INVEST"):
            label = f"{label_prefix} – Insurance Investment Entities"
        elif tj_id.endswith("_TNUPE"):
            label = f"{label_prefix} – Tax Neutral UPE"
        elif tj_id.endswith("_TTE"):
            label = f"{label_prefix} – Tax Transparent"
        elif tj_id.endswith("_FTE"):
            label = f"{label_prefix} – Flow-through"

        tj = TestedJurisdictionInputV2(
            tested_jurisdiction_id=tj_id,
            jurisdiction_code=j_code,
            label=label,
            tested_jurisdiction_type=tj_type,
            accounting_basis=AccountingBasisV2(currency=None, amount_scale="UNITS"),
            composition=TestedJurisdictionCompositionV2(aggregation_method="ENTITY_ROLLUP"),
            facts=None,
            entities=ents,
            transition_year=TransitionYearV2(),
        )
        tested_jurisdictions.append(tj)

        for e in ents:
            assignments.append(
                TestedJurisdictionsBuildAssignmentV2(
                    entity_id=e.entity_id,
                    entity_name=e.entity_name,
                    entity_type=getattr(e, "entity_type", None),
                    jv_group_id=getattr(e, "jv_group_id", None),
                    moce_group_id=getattr(e, "moce_group_id", None),
                    tested_jurisdiction_id=tj_id,
                    jurisdiction_code=j_code,
                    note=(
                        (f"JV group: {getattr(e, 'jv_group_id', None)}" if getattr(e, 'jv_group_id', None) else None)
                        or (f"MOCE group: {getattr(e, 'moce_group_id', None)}" if getattr(e, 'moce_group_id', None) else None)
                    ),
                )
            )

    if not tested_jurisdictions:
        warnings.append("No entities provided; no Tested Jurisdictions were built.")

    return TestedJurisdictionsBuildResponseV2(
        tested_jurisdictions=tested_jurisdictions,
        assignments=assignments,
        warnings=warnings,
    )
