from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import List, Optional

from app.services.models_v2 import EngineMetaV2

from app.services.auth_v2 import get_auth_config
from app.services.storage_v2 import _db_path


ENGINE_VERSION = os.getenv("ENGINE_VERSION", "0.1.0")


def get_engine_meta() -> EngineMetaV2:
    git_commit = (
        os.getenv("RENDER_GIT_COMMIT")
        or os.getenv("GIT_COMMIT")
        or os.getenv("COMMIT_SHA")
        or None
    )
    build_time = os.getenv("BUILD_TIMESTAMP") or None
    if build_time is None:
        # Best-effort; this is runtime time, not build time.
        build_time = datetime.now(timezone.utc).replace(microsecond=0).isoformat()

    auth_cfg = get_auth_config()

    return EngineMetaV2(
        api_version="v2",
        engine_version=ENGINE_VERSION,
        supported_schema_versions=EngineMetaV2.supported_schema_versions_default(),
        default_ruleset_version="OECD_SBS_2026_01",
        git_commit=git_commit,
        build_timestamp=build_time,

        auth_enabled=auth_cfg.enabled,
        api_key_header_name=auth_cfg.header_name if auth_cfg.enabled else None,
        storage_enabled=True,
        storage_backend="sqlite",
        storage_location=_db_path(),
    )
