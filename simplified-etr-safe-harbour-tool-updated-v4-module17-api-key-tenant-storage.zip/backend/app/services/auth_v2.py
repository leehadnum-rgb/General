from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Dict, Optional, Tuple

from fastapi import FastAPI, Request
from starlette.responses import JSONResponse


@dataclass(frozen=True)
class ApiKeyAuthConfig:
    """Configuration for lightweight API-key authentication.

    This module is intentionally dependency-free (no external auth libraries) so it
    works well on Render and is easy to reason about.
    """

    enabled: bool
    header_name: str
    key_to_tenant: Dict[str, str]
    exempt_paths: Tuple[str, ...]


def _parse_api_keys_env() -> Dict[str, str]:
    """Parse API keys from environment.

    Supported formats:
      - API_KEY="<key>" with DEFAULT_TENANT_ID (defaults to "default")
      - API_KEYS="tenantA:<keyA>,tenantB:<keyB>" (also supports tenant=<key>)
      - API_KEYS="<key>" (treated as default tenant)
    """

    key_to_tenant: Dict[str, str] = {}

    single = (os.getenv("API_KEY") or "").strip()
    if single:
        tenant = (os.getenv("DEFAULT_TENANT_ID") or "default").strip() or "default"
        key_to_tenant[single] = tenant

    multi = (os.getenv("API_KEYS") or "").strip()
    if not multi:
        return key_to_tenant

    parts = [p.strip() for p in multi.split(",") if p.strip()]
    for p in parts:
        if ":" in p:
            tenant, key = p.split(":", 1)
        elif "=" in p:
            tenant, key = p.split("=", 1)
        else:
            tenant, key = (os.getenv("DEFAULT_TENANT_ID") or "default"), p
        tenant = (tenant or "default").strip() or "default"
        key = (key or "").strip()
        if key:
            key_to_tenant[key] = tenant

    return key_to_tenant


def get_auth_config() -> ApiKeyAuthConfig:
    if (os.getenv("DISABLE_AUTH") or "").strip().lower() in {"1", "true", "yes"}:
        return ApiKeyAuthConfig(
            enabled=False,
            header_name=os.getenv("API_KEY_HEADER", "X-API-Key"),
            key_to_tenant={},
            exempt_paths=tuple(),
        )

    key_to_tenant = _parse_api_keys_env()
    enabled = len(key_to_tenant) > 0

    exempt = (os.getenv("AUTH_EXEMPT_PATHS") or "/api/v2/health").strip()
    exempt_paths = tuple([p.strip() for p in exempt.split(",") if p.strip()])

    return ApiKeyAuthConfig(
        enabled=enabled,
        header_name=os.getenv("API_KEY_HEADER", "X-API-Key"),
        key_to_tenant=key_to_tenant,
        exempt_paths=exempt_paths,
    )


def is_auth_enabled() -> bool:
    return get_auth_config().enabled


def _extract_api_key(request: Request, header_name: str) -> Optional[str]:
    # Primary: explicit header (default X-API-Key)
    key = request.headers.get(header_name)
    if key and key.strip():
        return key.strip()

    # Secondary: Bearer token
    auth = request.headers.get("Authorization") or ""
    if auth.lower().startswith("bearer "):
        token = auth.split(" ", 1)[1].strip()
        return token or None
    return None


def _unauthorized(detail: str, error_code: str = "AUTH_REQUIRED") -> JSONResponse:
    return JSONResponse(
        status_code=401,
        content={"detail": detail, "error_code": error_code},
        headers={"WWW-Authenticate": "Bearer"},
    )


def get_tenant_id_from_request(request: Request) -> str:
    """Return tenant_id for the request.

    If auth is disabled, this returns "public".
    """

    tenant = getattr(request.state, "tenant_id", None)
    if tenant:
        return str(tenant)
    return "public"


def add_api_key_auth_middleware(app: FastAPI) -> None:
    """Install lightweight API-key auth middleware.

    Auth is enforced only if API_KEY / API_KEYS env vars are set.
    """

    cfg = get_auth_config()

    @app.middleware("http")
    async def _api_key_auth(request: Request, call_next):
        # Always allow CORS preflight
        if request.method.upper() == "OPTIONS":
            return await call_next(request)

        # Only protect API routes (under /api). Docs and /openapi.json remain public.
        path = request.url.path
        if not path.startswith("/api"):
            return await call_next(request)

        # Exempt paths are always public
        if path in cfg.exempt_paths:
            request.state.tenant_id = "public"
            return await call_next(request)

        if not cfg.enabled:
            request.state.tenant_id = "public"
            return await call_next(request)

        key = _extract_api_key(request, cfg.header_name)
        if not key:
            return _unauthorized(
                f"Unauthorized: missing API key. Provide header '{cfg.header_name}' or Authorization: Bearer <token>."
            )

        tenant = cfg.key_to_tenant.get(key)
        if not tenant:
            return _unauthorized("Unauthorized: invalid API key.", error_code="AUTH_INVALID")

        request.state.tenant_id = tenant
        return await call_next(request)
