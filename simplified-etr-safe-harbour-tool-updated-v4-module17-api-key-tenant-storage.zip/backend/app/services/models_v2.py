from __future__ import annotations

from datetime import date
from typing import List, Optional, Literal, Any

from pydantic import BaseModel, Field, model_validator

from app.services.models import (
    AdjustmentLine,
    ElectionRecord,
    TraceLine,
    JurisdictionInput as JurisdictionInputV1,
    EntityInput as EntityInputV1,
)


# ---------------------------------------------------------------------------
# Accounting basis / currency translation scaffolding (v4 module 2)
# ---------------------------------------------------------------------------

AmountScale = Literal["UNITS", "THOUSANDS", "MILLIONS"]
AccountingBasisSource = Literal["CFS", "LOCAL_GAAP", "OTHER"]


class AccountingBasisV2(BaseModel):
    """Accounting basis / currency metadata.

    This tool is a *calculator* and cannot determine accounting standards or currency translation
    independently. The OECD guidance requires that currency translation rules apply, and that
    certain jurisdictions subject to QDMTT LFAS rules may require local accounting standards.

    v4 module 2 introduces lightweight scaffolding to:
      - record the accounting basis assumptions,
      - normalise monetary inputs to a reporting currency when FX rates are provided, and
      - raise errors for obvious LFAS conflicts.
    """

    basis_source: AccountingBasisSource = Field(
        default="CFS",
        description=(
            "Source of accounting basis used for the figures supplied (e.g., CFS or local GAAP). "
            "This is used for validation and audit trail only."
        ),
    )

    standard: Optional[str] = Field(
        default=None,
        description="Optional label for the accounting standard used (e.g., IFRS, US GAAP, UK GAAP, local GAAP).",
    )

    currency: Optional[str] = Field(
        default=None,
        description=(
            "Currency code for monetary inputs provided for this Tested Jurisdiction (e.g., 'EUR', 'USD'). "
            "If omitted, and a request.group_profile.reporting_currency is provided, the tool assumes amounts "
            "are already in that reporting currency."
        ),
    )

    amount_scale: AmountScale = Field(
        default="UNITS",
        description="Scale applied to monetary inputs: UNITS (as entered), THOUSANDS (x1,000), or MILLIONS (x1,000,000).",
    )

    # LFAS / QDMTT scaffolding
    lfas_qdmtt_applies: bool = Field(
        default=False,
        description=(
            "If True, the Tested Jurisdiction is subject to a QDMTT LFAS requirement (jurisdiction requires local financial accounting standards)."
        ),
    )
    lfas_requires_local_gaap: bool = Field(
        default=False,
        description=(
            "If True, the user asserts that the jurisdiction requires using local GAAP for QDMTT LFAS purposes. "
            "If basis_source='CFS' and the jurisdiction does not allow CFS GAAP, the tool will raise an error."
        ),
    )
    jurisdiction_allows_cfs_gaap_for_qdmtt: Optional[bool] = Field(
        default=None,
        description=(
            "If True, the jurisdiction allows using the CFS accounting standard for QDMTT even if LFAS would otherwise apply. "
            "If omitted, treated as False for validation when lfas_requires_local_gaap=True."
        ),
    )

    note: Optional[str] = None

    @model_validator(mode="after")
    def _validate_lfas(self) -> "AccountingBasisV2":
        """Tighter LFAS / QDMTT gating rules (v4 module 3).

        Practical implementation:
        - If the user asserts local GAAP is required (lfas_requires_local_gaap=True), then:
            * basis_source must be either LOCAL_GAAP, or CFS where the jurisdiction explicitly allows it.
            * basis_source='OTHER' is not accepted (too ambiguous for a determinate tool).
        - If basis_source='CFS' under a local GAAP requirement, jurisdiction_allows_cfs_gaap_for_qdmtt must be True.
        """

        if self.lfas_requires_local_gaap:
            if self.basis_source == "OTHER":
                raise ValueError(
                    "LFAS validation: lfas_requires_local_gaap=true but basis_source='OTHER'. Use basis_source='LOCAL_GAAP' (or 'CFS' if explicitly allowed)."
                )

            if self.basis_source == "CFS" and not bool(self.jurisdiction_allows_cfs_gaap_for_qdmtt):
                raise ValueError(
                    "LFAS validation: lfas_requires_local_gaap=true but basis_source='CFS' and jurisdiction_allows_cfs_gaap_for_qdmtt is not true."
                )
        return self


class GroupProfileV2(BaseModel):
    reporting_currency: Optional[str] = Field(
        default=None,
        description="Group reporting currency used for results (e.g., 'EUR'). If provided, FX rates may be used to translate inputs.",
    )
    default_accounting_standard: Optional[str] = Field(
        default=None,
        description="Optional label for group default accounting standard (e.g., IFRS).",
    )
    fx_translation_convention: Optional[str] = Field(
        default="PL_AVG_BS_SPOT",
        description=(
            "Currency translation convention used when FX rates are supplied. "
            "This tool applies average FX rates to P&L-type items (income/taxes) and spot FX rates to balance sheet items "
            "(when/if such items are introduced, e.g., Transition Year opening DTAs/DTLs)."
        ),
    )
    note: Optional[str] = None


class FxRateV2(BaseModel):
    """FX rate to translate from a local currency into the reporting currency."""

    currency: str = Field(..., description="Local currency code (e.g., 'USD').")
    avg_rate_to_reporting: float = Field(..., gt=0.0, description="Average FX rate to reporting currency for P&L items.")
    spot_rate_to_reporting: Optional[float] = Field(
        default=None,
        gt=0.0,
        description=(
            "Optional spot / closing FX rate to reporting currency. "
            "Used for balance sheet translation conventions (v4 module 3 and later modules)."
        ),
    )
    fiscal_year_start: Optional[date] = Field(
        default=None,
        description="Optional fiscal year start date that this FX rate applies to. If omitted, used as a default rate for that currency.",
    )
    note: Optional[str] = None


# ---------------------------------------------------------------------------
# Transition Year rules (v4 module 4)
# ---------------------------------------------------------------------------

DeferredTaxItemType = Literal["DTA", "DTL"]
DeferredTaxCategory = Literal["TEMPORARY_DIFFERENCE", "TAX_LOSS", "TAX_CREDIT", "OTHER"]


class TransitionDeferredTaxItemV2(BaseModel):
    """Opening deferred tax item for Transition Year (Articles 9.1.1 / 9.1.2).

    This is balance-sheet oriented data and is translated using spot/closing FX (when provided).

    The Simplified ETR Safe Harbour requires that Articles 9.1.1 to 9.1.3 and related Commentary
    apply for Transition Year purposes (Box 4.5). In practice, the detailed GloBE deferred tax
    computations can be complex; this model provides a structured way to represent key inputs.

    In v4 Module 4, this data is used primarily to model Article 9.1.2 "disallowed opening DTA"
    effects for the Transition Year.
    """

    item_id: Optional[str] = None
    label: Optional[str] = None

    item_type: DeferredTaxItemType = Field(..., description="Deferred tax item type: DTA or DTL.")
    category: DeferredTaxCategory = Field(
        default="TEMPORARY_DIFFERENCE",
        description="High-level category used for audit and user review.",
    )

    opening_balance: float = Field(
        ...,
        ge=0.0,
        description="Opening deferred tax balance per financial accounts (positive amount).",
    )

    opening_balance_at_minimum_rate: Optional[float] = Field(
        default=None,
        ge=0.0,
        description=(
            "Optional opening balance already expressed on a Minimum Rate basis. "
            "If provided, tax_rate is ignored for recast purposes."
        ),
    )

    tax_rate: Optional[float] = Field(
        default=None,
        ge=0.0,
        le=1.0,
        description=(
            "Tax rate used to measure the opening_balance in the financial accounts (used to recast to Minimum Rate). "
            "If omitted, the tool will attempt to use the jurisdiction accounted_tax_rate (if supplied)."
        ),
    )

    disallowed_under_article_9_1_2: bool = Field(
        default=False,
        description=(
            "If True and item_type='DTA', the opening DTA is not allowed under Article 9.1.2 and is treated as zero "
            "for GloBE purposes."
        ),
    )

    # DTL-specific meta (used in later modules / audit)
    is_recapture_exception_accrual: bool = Field(
        default=False,
        description="For DTL items: whether the DTL is a Recapture Exception Accrual (REA).",
    )
    included_in_prior_globe_or_qdmtt: bool = Field(
        default=False,
        description=(
            "For DTL items: indicates the deferred tax liability was included in Adjusted Covered Taxes under full GloBE "
            "or a QDMTT in a prior year (relevant to whether reversals are excluded)."
        ),
    )

    # Currency/scaling (optional override)
    currency: Optional[str] = Field(
        default=None,
        description=(
            "Optional currency code for this balance. If omitted, uses Tested Jurisdiction accounting_basis.currency "
            "(or the request reporting currency if no currency is provided)."
        ),
    )
    amount_scale: AmountScale = Field(
        default="UNITS",
        description="Scale applied to the opening_balance: UNITS/THOUSANDS/MILLIONS.",
    )

    note: Optional[str] = None

    @model_validator(mode="after")
    def _validate(self) -> "TransitionDeferredTaxItemV2":
        if self.disallowed_under_article_9_1_2 and self.item_type != "DTA":
            raise ValueError(
                "TransitionDeferredTaxItemV2: disallowed_under_article_9_1_2 can only be true for item_type='DTA'."
            )
        return self


class Article913TransferV2(BaseModel):
    """Article 9.1.3 transfer adjustment scaffolding.

    In v4 Module 4, this is implemented as structured net adjustments to Simplified Income and
    Simplified Taxes for the current fiscal year.

    Currency translation follows the tool convention:
      - Income/Tax adjustments are P&L-type items -> average FX.
    """

    transfer_id: Optional[str] = None
    label: str = Field(..., description="Short label for the transfer adjustment.")

    transfer_fiscal_year_start: Optional[date] = Field(
        default=None,
        description="Fiscal year start date when the transfer occurred (optional; audit trail).",
    )

    income_adjustment: float = Field(
        default=0.0,
        description="Signed adjustment to Simplified Income for the current fiscal year.",
    )
    tax_adjustment: float = Field(
        default=0.0,
        description="Signed adjustment to Simplified Taxes for the current fiscal year.",
    )

    # Optional audit-only DTA amount at Minimum Rate (balance sheet)
    deferred_tax_asset_amount: Optional[float] = Field(
        default=None,
        ge=0.0,
        description=(
            "Optional DTA amount at Minimum Rate recognised/used under Article 9.1.3 commentary. "
            "This is audit metadata in Module 4 and is not used to compute Simplified Taxes unless the user "
            "reflects it in tax_adjustment."
        ),
    )

    currency: Optional[str] = Field(
        default=None,
        description=(
            "Optional currency code for income_adjustment / tax_adjustment. If omitted, uses Tested Jurisdiction currency."
        ),
    )
    amount_scale: AmountScale = Field(default="UNITS")

    note: Optional[str] = None


class TransitionYearV2(BaseModel):
    """Transition Year configuration (Box 4.5).

    The Transition Year for a Tested Jurisdiction is the first year the MNE Group elects the Simplified
    ETR Safe Harbour for that Tested Jurisdiction (or an earlier Transition Year otherwise determined
    under the GloBE Model Rules).

    In this stateless tool, the Transition Year date is supplied by the user.
    """

    transition_year_fy_start: Optional[date] = Field(
        default=None,
        description=(
            "Fiscal year start date of the Transition Year for this Tested Jurisdiction. "
            "If omitted but transition_year is provided, the tool assumes the current request fiscal year is the Transition Year."
        ),
    )

    opening_deferred_tax_items: List[TransitionDeferredTaxItemV2] = Field(
        default_factory=list,
        description=(
            "Opening DTAs/DTLs relevant under Articles 9.1.1 / 9.1.2. "
            "These are balance-sheet items and translated using spot FX (if provided)."
        ),
    )

    article_9_1_3_transfers: List[Article913TransferV2] = Field(
        default_factory=list,
        description="Optional structured net adjustments for Article 9.1.3 asset transfers.",
    )

    note: Optional[str] = None



# ---------------------------------------------------------------------------
# Transition Year state (v4 module 4.1)
# ---------------------------------------------------------------------------

class TransitionDeferredTaxRegisterItemV2(BaseModel):
    """Computed register item for Transition Year opening deferred tax balances.

    Purpose:
    - Capture Transition Year opening DTAs/DTLs after scaling and currency translation.
    - Persist the computed Minimum Rate basis amounts for later multi-year use.

    Amount conventions:
    - Amounts are stored in the "state currency" (typically the request reporting currency if FX translation is enabled;
      otherwise the Tested Jurisdiction input currency).
    """

    item_id: Optional[str] = None
    label: Optional[str] = None

    item_type: DeferredTaxItemType
    category: DeferredTaxCategory = 'TEMPORARY_DIFFERENCE'

    disallowed_under_article_9_1_2: bool = False

    # Computed amounts (state currency)
    opening_balance_state_currency: float = 0.0
    opening_balance_minimum_rate_state_currency: float = 0.0
    allowed_opening_balance_minimum_rate_state_currency: float = 0.0

    # If the opening DTA is disallowed, this is the tax increase applied in Transition Year
    disallowed_adjustment_state_currency: float = 0.0

    # Audit metadata
    tax_rate_used: Optional[float] = None
    was_provided_at_minimum_rate: bool = False
    fx_note: Optional[str] = None

    source_currency: Optional[str] = None
    source_amount_scale: AmountScale = 'UNITS'
    note: Optional[str] = None


class TransitionYearStateV2(BaseModel):
    """State object to carry Transition Year deferred tax register forward across fiscal years.

    This enables a stateless API to behave "statefully" across years by returning a state payload
    that the client stores and supplies in later-year requests.

    The state is scoped to one Tested Jurisdiction.
    """

    state_version: Literal['1'] = '1'

    transition_year_fy_start: date

    # Currency that register amounts are expressed in.
    # Typically equals request.group_profile.reporting_currency when FX translation is used.
    state_currency: Optional[str] = None

    # Fiscal year when the state was computed (useful for audit)
    computed_in_fiscal_year_start: Optional[date] = None

    opening_deferred_tax_register: List[TransitionDeferredTaxRegisterItemV2] = Field(default_factory=list)

    note: Optional[str] = None

    @model_validator(mode='after')
    def _normalise(self) -> 'TransitionYearStateV2':
        if self.state_currency:
            self.state_currency = str(self.state_currency).upper().strip() or None
        return self

# ---------------------------------------------------------------------------
# v2 wrappers around v1 input models
# ---------------------------------------------------------------------------

class JurisdictionFactsV2(JurisdictionInputV1):
    """Jurisdiction facts (v2).

    This model inherits the existing v1 JurisdictionInput for maximum re-use, but makes
    jurisdiction_code optional so UI clients do not need to duplicate it. The API will override
    the internal bucket id with tested_jurisdiction_id when running calculations.
    """

    jurisdiction_code: Optional[str] = Field(
        default=None,
        description=(
            "Optional. UI may omit this; the server will fill it internally. "
            "In v2, tested_jurisdiction_id is used as the internal grouping key."
        ),
    )



# ---------------------------------------------------------------------------
# Entity classification scaffolding (v4 module 5)
# ---------------------------------------------------------------------------

EntityTypeV2 = Literal[
    "STANDARD_CE",
    "PERMANENT_ESTABLISHMENT",
    "FLOW_THROUGH_ENTITY",
    "TAX_TRANSPARENT_ENTITY",
    "INVESTMENT_ENTITY",
    "INSURANCE_INVESTMENT_ENTITY",
    "TAX_NEUTRAL_UPE",
    "STATELESS",
    "OTHER",
]


class EntityFactsV2(EntityInputV1):
    """Entity facts (v2).

    In v2, entities are typically nested under a Tested Jurisdiction. The server will override
    the internal grouping key with tested_jurisdiction_id when running calculations.
    """

    jurisdiction_code: Optional[str] = Field(
        default=None,
        description=(
            "Optional. This tool groups entities by tested_jurisdiction_id (not jurisdiction_code) in v2. "
            "Use tested_jurisdiction.jurisdiction_code for the country/territory code."
        ),
    )

    entity_type: EntityTypeV2 = Field(
    default="STANDARD_CE",
    description=(
        "Entity classification used for OECD Safe Harbour operational rules (sections 5 and 6), "
        "including cross-border allocations and deemed-zero determinations."
    ),
    )

    is_upe: bool = Field(
    default=False,
    description="If true, indicates the entity is (or is treated as) the Ultimate Parent Entity (UPE).",
    )

    qualified_persons_ownership_percentage: Optional[float] = Field(
    default=None,
    ge=0.0,
    le=1.0,
    description=(
        "For Tax-Neutral UPE / Tax-Neutral Entity scenarios: proportion (0–1) of Ownership Interests held by Qualified Persons. "
        "Used for Section 6.1 deeming rules and validation."
    ),
    )

    # PE / allocation linkage scaffolding
    pe_id: Optional[str] = Field(
    default=None,
    description="Optional PE identifier (links to permanent_establishments register). Used when entity_type='PERMANENT_ESTABLISHMENT'.",
    )

    main_entity_id: Optional[str] = Field(
    default=None,
    description="For a Permanent Establishment, the entity_id of the Main Entity / Head Office to which the PE relates (if known).",
    )

    # GloBE scoping / Tested Jurisdiction context (Module 15)
    jv_group_id: Optional[str] = Field(
        default=None,
        description=(
            "Optional Joint Venture Group identifier. If provided, the entity is treated as belonging to a Joint Venture Group "
            "for Tested Jurisdiction scoping. Entities with the same (jurisdiction_code, jv_group_id) are bucketed into a "
            "separate Tested Jurisdiction (e.g., 'GB_JV_<ID>_MAIN') by the /api/v2/tested-jurisdictions/build helper."
        ),
    )

    moce_group_id: Optional[str] = Field(
        default=None,
        description=(
            "Optional Minority-Owned Constituent Entities (MOCE) group identifier. If provided, the entity is treated as belonging to a "
            "Minority-Owned group for Tested Jurisdiction scoping. Entities with the same (jurisdiction_code, moce_group_id) are bucketed "
            "into a separate Tested Jurisdiction (e.g., 'GB_MOCE_<ID>_MAIN') by the /api/v2/tested-jurisdictions/build helper."
        ),
    )

    @model_validator(mode="after")
    def _validate_scoping_group_ids(self) -> "EntityFactsV2":
        if self.jv_group_id and self.moce_group_id:
            raise ValueError("Provide only one of jv_group_id or moce_group_id (an entity cannot be both JV and MOCE).")
        return self




# ---------------------------------------------------------------------------
# Elections (v2)
# ---------------------------------------------------------------------------

Scope = Literal["income", "tax", "eligibility", "metadata"]
ValueType = Literal["bool", "amount", "text"]
TermType = Literal["ANNUAL", "FIVE_YEAR"]
ElectionAction = Literal["ELECT", "REVOKE"]


class ElectionInstanceV2(BaseModel):
    """An election or adjustment selection associated with a Tested Jurisdiction."""

    action: ElectionAction = Field(
        default="ELECT",
        description=(
            "Election register event type. 'ELECT' records that the election is made; 'REVOKE' records that it is revoked "
            "(used for FIVE_YEAR elections which continue until revoked in the OECD guidance)."
        ),
    )

    election_code: str = Field(..., description="Election/adjustment code (see /api/v2/election-catalog).")
    scope: Scope = Field(..., description="Which part of the safe harbour it relates to.")
    value_type: ValueType = Field(..., description="Value type for the election.")
    # Optional term type on instance; if omitted, the server will infer from election catalog when possible.
    term_type: Optional[TermType] = Field(
        default=None,
        description="ANNUAL or FIVE_YEAR. If omitted, server will infer from the election catalog.",
    )
    effective_fiscal_year_start: Optional[date] = Field(
        default=None,
        description="Fiscal year start date when this election starts. Defaults to the request fiscal year start date.",
    )
    # Values
    bool_value: Optional[bool] = None
    amount: Optional[float] = Field(default=None, description="Signed amount (+/-) if value_type='amount'.")
    text_value: Optional[str] = None
    label: Optional[str] = None
    note: Optional[str] = None

    @model_validator(mode="after")
    def _validate_value(self) -> "ElectionInstanceV2":
        # Revocation events act as a timeline marker. They do not carry a value.
        if self.action == "REVOKE":
            return self
        vt = self.value_type
        if vt == "bool" and self.bool_value is None:
            raise ValueError(f"Election {self.election_code}: value_type='bool' requires bool_value.")
        if vt == "amount" and self.amount is None:
            raise ValueError(f"Election {self.election_code}: value_type='amount' requires amount.")
        if vt == "text" and (self.text_value is None or str(self.text_value).strip() == ""):
            raise ValueError(f"Election {self.election_code}: value_type='text' requires text_value.")
        return self


# ---------------------------------------------------------------------------
# Carryforwards (v2)
# ---------------------------------------------------------------------------

CarryforwardKind = Literal[
    "SIMPLIFIED_NEGATIVE_TAX_ADJUSTMENT",  # Box 4.3 (paragraphs 1-3)
    "EXCESS_NEGATIVE_TAX_CARRYFORWARD",    # GloBE Article 4.1.5 carry-forward (input)
    "LOSS_DTA_ADJUSTMENT",                 # Box 4.3 (paragraph 4) alternative methodology
]


class CarryforwardBalanceV2(BaseModel):
    kind: CarryforwardKind
    origin_fiscal_year_start: Optional[date] = Field(
        default=None, description="Fiscal year start date when the balance was generated (if known)."
    )
    amount: float = Field(
        ...,
        description=(
            "Opening amount of the carryforward. Enter as a positive number. "
            "The tool applies it as a reduction to Simplified Taxes, subject to OECD limits."
        ),
    )
    remaining_amount: Optional[float] = Field(
        default=None,
        description="If omitted, defaults to amount. Must be >= 0.",
    )
    note: Optional[str] = None

    @model_validator(mode="after")
    def _normalise(self) -> "CarryforwardBalanceV2":
        # Normalise negative values to positive to avoid sign confusion.
        if self.amount < 0:
            self.amount = abs(self.amount)
        if self.remaining_amount is None:
            self.remaining_amount = float(self.amount)
        if self.remaining_amount < 0:
            self.remaining_amount = abs(self.remaining_amount)
        return self


class CarryforwardMovementV2(BaseModel):
    kind: CarryforwardKind
    used_amount: float = Field(..., ge=0.0, description="Amount utilised in the current fiscal year (>= 0).")
    remaining_amount: float = Field(..., ge=0.0, description="Remaining amount after utilisation (>= 0).")
    note: Optional[str] = None


# ---------------------------------------------------------------------------
# Cross-border adjustments (v2)
# ---------------------------------------------------------------------------

CrossBorderTaxTreatment = Literal[
    "ALLOCATE",          # subtract from source and add to target
    "EXCLUDE_FROM_ALL",  # subtract from source and add to no Tested Jurisdiction
    "KEEP_IN_SOURCE",    # do not adjust (i.e., keep where recorded)
]


class CrossBorderTaxItemV2(BaseModel):
    """Cross-border allocable tax item.

    This is a *structured* way to handle the OECD cross-border tax exclusion/allocation concept.
    The user provides the tax amount and where it is recorded (source) and optionally where it
    should be allocated (target).

    The engine applies the adjustment after the base v1 Simplified Taxes computation, and before
    carryforwards, so it affects Simplified ETR.
    """

    item_id: Optional[str] = None
    label: Optional[str] = None
    category: Optional[str] = Field(
        default=None,
        description="Optional category label (e.g., withholding, CFC, PE, hybrid, other).",
    )

    amount: float = Field(..., ge=0.0, description="Tax amount (positive).")

    currency: Optional[str] = Field(
        default=None,
        description=(
            "Optional currency code for the amount (e.g., 'USD'). If request.group_profile.reporting_currency is provided "
            "and currency differs, the engine will translate this amount using request.fx_rates. "
            "If omitted, the tool assumes the amount is already in the reporting currency (when provided)."
        ),
    )

    amount_scale: AmountScale = Field(
        default="UNITS",
        description="Scale applied to the amount: UNITS/THOUSANDS/MILLIONS. Applied before FX translation.",
    )

    source_tested_jurisdiction_id: Optional[str] = Field(
        default=None,
        description="Tested Jurisdiction where the tax is currently recorded (for safe harbour purposes).",
    )
    target_tested_jurisdiction_id: Optional[str] = Field(
        default=None,
        description="Tested Jurisdiction to which the tax should be allocated (if applicable).",
    )

    treatment: Optional[CrossBorderTaxTreatment] = Field(
        default=None,
        description=(
            "How to treat the tax item. If omitted, the engine infers a default based on whether a target is provided "
            "and whether the cross-border 'keep allocable taxes' election is in effect for the source jurisdiction."
        ),
    )

    requires_pe_simplification_election: bool = Field(
        default=False,
        description=(
            "If True, the engine requires the PE simplification election to be effective for the relevant Tested Jurisdiction(s). "
            "Use this when the allocation relies on the PE simplification election."  
        ),
    )

    note: Optional[str] = None

    @model_validator(mode="after")
    def _validate(self) -> "CrossBorderTaxItemV2":
        if self.treatment == "ALLOCATE" and not self.target_tested_jurisdiction_id:
            raise ValueError("CrossBorderTaxItemV2: treatment='ALLOCATE' requires target_tested_jurisdiction_id.")
        return self




# ---------------------------------------------------------------------------
# Allocation-ready registers (v4 module 5)
# ---------------------------------------------------------------------------

GlobeArticle432Ref = Literal["4.3.2(a)", "4.3.2(b)", "4.3.2(c)", "4.3.2(d)", "4.3.2(e)"]


class PermanentEstablishmentV2(BaseModel):
    """Permanent Establishment linkage register (allocation-ready scaffolding).

    Captures relationship between a PE and its Main Entity / Head Office.
    Used by /api/v2/validate today and will be used by the cross-border allocation engine (OECD section 5.1) in later modules.
    """

    pe_id: str = Field(..., description="Unique identifier for the PE (stable across years).")
    pe_entity_id: Optional[str] = Field(
        default=None,
        description="Optional entity_id of the PE entity row (if entities are provided).",
    )
    main_entity_id: Optional[str] = Field(
        default=None,
        description="Optional entity_id of the Main Entity / Head Office related to the PE.",
    )

    pe_tested_jurisdiction_id: Optional[str] = Field(
        default=None,
        description="Tested Jurisdiction bucket where the PE is located / taxed (host jurisdiction).",
    )
    main_entity_tested_jurisdiction_id: Optional[str] = Field(
        default=None,
        description="Tested Jurisdiction bucket of the Main Entity / Head Office (if known).",
    )

    pe_jurisdiction_code: Optional[str] = Field(
        default=None,
        description="Optional jurisdiction code where the PE is located.",
    )
    main_entity_jurisdiction_code: Optional[str] = Field(
        default=None,
        description="Optional jurisdiction code of the Main Entity / Head Office.",
    )

    taxable_branch_regime_applies: Optional[bool] = Field(
        default=None,
        description="Optional flag indicating whether a taxable branch regime applies (PE simplification election scaffolding).",
    )

    note: Optional[str] = None


class FlowThroughEntityAllocationV2(BaseModel):
    """Flow-through / tax-transparent entity allocation line (allocation-ready scaffolding).

    One row represents an allocation from a flow-through entity to one owner Tested Jurisdiction.
    Used by /api/v2/validate today and will be used by OECD section 5.1 in later modules.
    """

    line_id: Optional[str] = None
    flow_through_entity_id: str = Field(..., description="Entity identifier of the flow-through / tax-transparent entity.")
    flow_through_entity_name: Optional[str] = None

    flow_through_tested_jurisdiction_id: Optional[str] = Field(
        default=None,
        description="Tested Jurisdiction bucket where the flow-through entity is recorded (if applicable).",
    )
    owner_tested_jurisdiction_id: str = Field(..., description="Owner Tested Jurisdiction bucket receiving allocation.")

    fiscal_year_start: Optional[date] = Field(
        default=None,
        description="Optional fiscal year start date the allocation line applies to. If omitted, assumed to apply to the request fiscal year.",
    )

    income_allocated_amount: Optional[float] = Field(
        default=None,
        description="Optional signed income allocation amount to the owner TJ. If omitted, treated as 0 for validation.",
    )
    tax_allocated_amount: Optional[float] = Field(
        default=None,
        description="Optional signed tax allocation amount to the owner TJ. If omitted, treated as 0 for validation.",
    )

    currency: Optional[str] = Field(default=None, description="Optional currency code for allocated amounts.")
    amount_scale: AmountScale = Field(default="UNITS")

    note: Optional[str] = None


class AllocableTaxItemV2(BaseModel):
    """Allocable tax item register (allocation-ready scaffolding).

    OECD section 5.1-aligned alternative to cross_border_tax_items.
    Supports explicit Article 4.3.2 tagging for allocation/exclusion logic in later modules.
    """

    item_id: Optional[str] = None
    label: Optional[str] = None

    globe_article: GlobeArticle432Ref = Field(
        ...,
        description="GloBE Model Rules Article reference for the allocable tax item (4.3.2(a)-(e)).",
    )

    amount: float = Field(..., gt=0.0, description="Tax amount (positive).")
    currency: Optional[str] = Field(default=None, description="Optional currency code for the amount.")
    amount_scale: AmountScale = Field(default="UNITS")

    fiscal_year_start: Optional[date] = Field(
        default=None,
        description="Optional fiscal year start date the tax item relates to. If omitted, assumed to relate to the request fiscal year.",
    )

    source_tested_jurisdiction_id: Optional[str] = Field(
        default=None,
        description="Tested Jurisdiction where the tax is currently recorded.",
    )
    target_tested_jurisdiction_id: Optional[str] = Field(
        default=None,
        description="Optional Tested Jurisdiction where the tax is allocable under Article 4.3.2(b) or election-based allocation.",
    )

    is_withholding_on_distribution: bool = Field(
        default=False,
        description="If true, indicates withholding tax on distributions (special handling in Box 5.1).",
    )

    related_pe_id: Optional[str] = Field(default=None, description="Optional link to PermanentEstablishmentV2.pe_id.")
    related_flow_through_entity_id: Optional[str] = Field(
        default=None,
        description="Optional link to a flow-through entity id (Article 3.5 / 5.1 allocations).",
    )

    note: Optional[str] = None


# ---------------------------------------------------------------------------
# PE allocation / PE simplification election register (v4 module 11)
# ---------------------------------------------------------------------------


class PEAllocationLineV2(BaseModel):
    """Permanent Establishment allocation / PE simplification election line.

    This register supports the *PE Simplification Election* mechanics described in OECD
    section 5.1 (in lieu of Articles 3.4.4 and 3.4.5).

    The election is made on a jurisdictional basis (Main Entity Tested Jurisdiction). When
    effective, the Main Entity Tested Jurisdiction includes the PE's Simplified Income or Loss
    (to the extent included in domestic taxable income under a taxable branch regime) and
    includes the Main Entity's current/deferred taxes related to that PE income/loss, plus
    any foreign tax credit used to reduce that current tax expense.

    The engine is stateless; multi-year continuation for PE losses is handled via
    pe_simplification_state_opening/closing on the request/response.

    Notes on sign conventions:
      - pe_income_included_in_main is signed (profit positive, loss negative).
      - main_entity_taxes_related_to_pe and foreign_tax_credit_used are generally positive.
    """

    line_id: Optional[str] = None

    pe_id: str = Field(..., description="Permanent Establishment identifier (links to PermanentEstablishmentV2.pe_id).")

    fiscal_year_start: Optional[date] = Field(
        default=None,
        description=(
            "Optional fiscal year start date the line applies to. If omitted, assumed to apply to the request fiscal year."
        ),
    )

    # Optional explicit TJ linkage (otherwise inferred from permanent_establishments register)
    main_entity_tested_jurisdiction_id: Optional[str] = Field(
        default=None,
        description="Main Entity / Head Office Tested Jurisdiction bucket (where the PE Simplification Election is made).",
    )
    pe_tested_jurisdiction_id: Optional[str] = Field(
        default=None,
        description="PE Tested Jurisdiction bucket (host jurisdiction). Used for validation/trace only.",
    )

    pe_income_included_in_main: float = Field(
        default=0.0,
        description=(
            "Signed amount of the PE's Simplified Income or Loss that is included in the Simplified Income of the Main Entity Tested Jurisdiction "
            "under the PE Simplification Election (positive income, negative loss)."
        ),
    )

    main_entity_taxes_related_to_pe: float = Field(
        default=0.0,
        description=(
            "Signed amount of the Main Entity's current + deferred taxes related to the PE income/loss included in the Main Entity Tested Jurisdiction "
            "(typically positive)."
        ),
    )

    foreign_tax_credit_used: float = Field(
        default=0.0,
        description=(
            "Foreign tax credit amount used by the Main Entity to reduce its current tax expense related to including the PE income. "
            "Included in Simplified Taxes for the Main Entity Tested Jurisdiction under the election."
        ),
    )

    main_nominal_tax_rate: Optional[float] = Field(
        default=None,
        ge=0.0,
        le=1.0,
        description=(
            "Optional nominal tax rate of the Main Entity jurisdiction (0-1). If provided, the engine caps foreign_tax_credit_used inclusion "
            "to main_nominal_tax_rate × max(0, pe_income_included_in_main) (OECD section 5.1 PE Simplification Election cap)."
        ),
    )

    currency: Optional[str] = Field(
        default=None,
        description=(
            "Optional currency code for amounts. If group_profile.reporting_currency is set and currency differs, the engine translates using fx_rates." 
            "If omitted, the engine assumes amounts are already in reporting currency (when provided)."
        ),
    )

    amount_scale: AmountScale = Field(
        default="UNITS",
        description="Scale applied to the amounts: UNITS/THOUSANDS/MILLIONS. Applied before FX translation.",
    )

    note: Optional[str] = None


class PESimplificationStateItemV2(BaseModel):
    """Client-managed state for PE Simplification Election continuation.

    OECD rule (simplified): if a PE loss has been included in a Main Entity jurisdiction under the
    PE Simplification Election, the election must continue to be made in subsequent years until
    the year after an equal amount of PE income has been included.

    We model this as:
      - unrecouped_loss_balance: cumulative PE losses included but not yet matched by included PE income.
      - tail_years_remaining: 1 when the 'year-after' continuation requirement is outstanding.
    """

    pe_id: str
    main_entity_tested_jurisdiction_id: Optional[str] = None

    unrecouped_loss_balance: float = Field(default=0.0, ge=0.0)
    tail_years_remaining: int = Field(default=0, ge=0, le=1)

    last_fiscal_year_start: Optional[date] = None
    note: Optional[str] = None


# ---------------------------------------------------------------------------
# Deemed Distribution Tax Recapture Account (Article 7.3) (v4 module 14)
# ---------------------------------------------------------------------------

DDTRecaptureMovementReasonV2 = Literal[
    "DEEMED_DISTRIBUTION_TAX",
    "REDUCTION",
    "OTHER",
]


class DDTRecaptureAccountStateV2(BaseModel):
    """Opening/closing balance for the Deemed Distribution Tax Recapture Account (Article 7.3).

    OECD rule (summarised): where a Tested Jurisdiction has an outstanding Deemed Distribution Tax
    Recapture Account balance at the beginning of the Fiscal Year, the MNE cannot elect the
    Simplified ETR Safe Harbour for that Tested Jurisdiction until the balance is reduced to nil.

    This tool is a calculator and cannot compute this account from source systems; the user supplies
    the opening balance and (optionally) annual movement lines to compute a closing balance for
    multi-year scenario planning.
    """

    tested_jurisdiction_id: str
    balance: float = Field(..., ge=0.0, description="Non-negative balance. Interpreted in the given currency/scale (then FX translated to reporting currency if needed).")

    currency: Optional[str] = Field(
        default=None,
        description=(
            "Optional currency code for the balance. If omitted, assumed to be the Tested Jurisdiction accounting currency "
            "(or reporting currency when provided)."
        ),
    )
    amount_scale: AmountScale = Field(
        default="UNITS",
        description="Scale applied to the balance: UNITS/THOUSANDS/MILLIONS. Applied before FX translation.",
    )

    as_of_fiscal_year_start: Optional[date] = Field(
        default=None,
        description="Optional fiscal year start date that this balance applies to (opening balance at start of that year).",
    )
    note: Optional[str] = None

    @model_validator(mode="after")
    def _norm(self) -> "DDTRecaptureAccountStateV2":
        self.tested_jurisdiction_id = str(self.tested_jurisdiction_id).strip()
        if self.currency:
            self.currency = str(self.currency).upper().strip() or None
        return self


class DDTRecaptureAccountMovementV2(BaseModel):
    """Annual movement line for the Deemed Distribution Tax Recapture Account.

    Notes:
      - amount is signed: positive increases the balance; negative reduces the balance.
      - movements are used only to compute a closing balance for roll-forward; they do not affect
        eligibility for the current year (eligibility is based on the opening balance).
    """

    movement_id: Optional[str] = None
    tested_jurisdiction_id: str
    fiscal_year_start: date
    amount: float

    reason: DDTRecaptureMovementReasonV2 = Field(default="OTHER")

    currency: Optional[str] = Field(
        default=None,
        description="Optional currency code for amount. If omitted, assumed to match the opening balance currency (or TJ/reporting currency context).",
    )
    amount_scale: AmountScale = Field(default="UNITS")

    note: Optional[str] = None

    @model_validator(mode="after")
    def _norm(self) -> "DDTRecaptureAccountMovementV2":
        self.tested_jurisdiction_id = str(self.tested_jurisdiction_id).strip()
        if self.movement_id:
            self.movement_id = str(self.movement_id).strip() or None
        if self.currency:
            self.currency = str(self.currency).upper().strip() or None
        return self


# ---------------------------------------------------------------------------
# Allocation ledger (OECD section 5.1) (v4 module 6)
# ---------------------------------------------------------------------------

AllocationLedgerSourceType = Literal["FLOW_THROUGH", "ALLOCABLE_TAX_ITEM", "PE_SIMPLIFICATION", "OTHER"]
AllocationLedgerKind = Literal["income", "tax"]
AllocationLedgerOperation = Literal["ALLOCATE", "EXCLUDE", "KEEP"]


class AllocationLedgerEntryV2(BaseModel):
    """Audit record for a Section 5.1 allocation/exclusion event.

    Semantics:
      - amount is expressed in the request reporting currency (if provided) and already reflects any amount scaling and FX translation.
      - amount is *signed* and represents the amount applied to the target Tested Jurisdiction (if any).
        The source Tested Jurisdiction change is the negation of this amount when operation='ALLOCATE'.
      - For operation='EXCLUDE', only the source Tested Jurisdiction is reduced by abs(amount).
    """

    entry_id: Optional[str] = None
    source_type: AllocationLedgerSourceType = Field(..., description="Source register/type that generated the entry.")
    operation: AllocationLedgerOperation = Field(..., description="How the item was treated under section 5.1 rules.")
    kind: AllocationLedgerKind = Field(..., description="Whether the ledger entry impacts income or taxes.")

    amount: float = Field(..., description="Signed amount applied under the chosen operation (in reporting currency).")

    source_tested_jurisdiction_id: Optional[str] = Field(default=None, description="Tested Jurisdiction where the item was recorded before allocation.")
    target_tested_jurisdiction_id: Optional[str] = Field(default=None, description="Tested Jurisdiction receiving the allocated amount (if operation='ALLOCATE').")

    reference_id: Optional[str] = Field(default=None, description="Reference id of the source record (e.g., line_id, item_id).")
    label: Optional[str] = Field(default=None, description="Short label for the ledger entry.")
    note: Optional[str] = None
# ---------------------------------------------------------------------------
# After-year-end adjustments (OECD Box 4.6) (v4 phase 4.4)
# ---------------------------------------------------------------------------

AfterYearEndAdjustmentKind = Literal["income", "tax"]
QualifiedRefundCheckBasis = Literal["SIMPLIFIED_ETR", "GLOBE_ETR", "ATTESTATION"]


class AfterYearEndAdjustmentV2(BaseModel):
    """Change to Covered Tax liability or income for a Fiscal Year accrued after year end (Box 4.6).

    Each record links:
      - transaction_year: the Fiscal Year to which the tax/income relates, and
      - accrual_year: the Fiscal Year in which the adjustment is reflected in the financial accounts.

    Default rule (Box 4.6(1)):
      - include in the accrual year.

    Optional Five-Year Election (Box 4.6(2)):
      - for adjustments that accrue within the 12 months following the end of the transaction year,
        include them in the transaction year (group-wide election; excludes TP-related adjustments).

    Downward tax adjustment more than 12 months after year end (Box 4.6(3)):
      - when flagged by the user (apply_large_refund_exclusion=True), the engine can exclude certain
        net decreases from the accrual year to avoid losing the safe harbour, subject to conditions.
    """

    adjustment_id: Optional[str] = None
    label: Optional[str] = None
    tested_jurisdiction_id: str = Field(..., description="Target Tested Jurisdiction receiving the adjustment.")

    kind: AfterYearEndAdjustmentKind = Field(..., description="'income' affects Simplified Income; 'tax' affects Simplified Taxes.")
    amount: float = Field(..., description="Signed amount (+/-). For tax, negative = decrease/refund; positive = increase.")

    transaction_year_fy_start: date = Field(..., description="Fiscal year start date of the transaction year.")
    accrual_year_fy_start: date = Field(..., description="Fiscal year start date of the accrual year (where the adjustment is booked).")

    # Timing metadata for applying the 12-month election and Box 4.6(3) rule
    months_after_transaction_year_end: Optional[int] = Field(
        default=None,
        ge=0,
        description=(
            "Months after the end of the transaction year when the adjustment accrued. "
            "Used to determine whether it is within 12 months (for the Five-Year election) "
            "and whether it is more than 12 months (for Box 4.6(3))."
        ),
    )
    accrued_within_12_months: Optional[bool] = Field(
        default=None,
        description="Optional override for whether the adjustment accrued within 12 months of transaction year end.",
    )

    is_transfer_pricing_related: bool = Field(
        default=False,
        description="If True, the Box 4.6(2) election does not apply. (TP adjustments are handled under section 5.2.)",
    )


    # Transfer pricing (section 5.2) structured counterparty metadata.
    # When is_transfer_pricing_related=True, these fields enable the engine to apply the adjustment
    # to the relevant counterparty Tested Jurisdiction as well (symmetry).
    tp_counterparty_tested_jurisdiction_id: Optional[str] = Field(
        default=None,
        description=(
            "Optional counterparty Tested Jurisdiction for TP-related adjustments. "
            "For kind='income', if provided, the engine will apply a corresponding counterparty income adjustment "
            "(defaulting to the negative of the primary amount unless tp_counterparty_income_amount is provided). "
            "For kind='tax', if tp_counterparty_tax_amount is provided, it will be applied to this counterparty."
        ),
    )
    tp_apply_counterparty_income: bool = Field(
        default=True,
        description=(
            "For TP-related income adjustments: if True (default) and a counterparty Tested Jurisdiction is provided, "
            "apply a corresponding income adjustment to the counterparty (symmetry)."
        ),
    )
    tp_counterparty_income_amount: Optional[float] = Field(
        default=None,
        description=(
            "Optional explicit counterparty income adjustment amount (signed). If omitted and tp_apply_counterparty_income=True, "
            "the engine uses -amount for the counterparty."
        ),
    )
    tp_counterparty_tax_amount: Optional[float] = Field(
        default=None,
        description=(
            "Optional explicit counterparty tax adjustment amount (signed) to apply to tp_counterparty_tested_jurisdiction_id "
            "for TP-related tax adjustments."
        ),
    )

    # Optional TP special-case flags (audit / trace metadata).
    tp_accounted_at_cost: bool = Field(
        default=False,
        description="If True, indicates the relevant intra-group transfer is accounted at cost (OECD section 5.2 special case).",
    )
    tp_intangible_asset_related: bool = Field(
        default=False,
        description="If True, indicates the adjustment relates to an intangible asset transfer (OECD section 5.2 special case).",
    )
    tp_loss_disallowed_deemed_tp_adjustment: bool = Field(
        default=False,
        description="If True, indicates a deemed TP adjustment arises due to a disallowed loss on an intra-group transfer (OECD section 5.2).",
    )

    # Optional currency/scaling if different from the Tested Jurisdiction default
    currency: Optional[str] = Field(
        default=None,
        description=(
            "Optional currency code for this adjustment amount. If omitted, the tool assumes the amount is expressed "
            "in the Tested Jurisdiction's accounting_basis.currency (or reporting currency if none is provided)."
        ),
    )
    amount_scale: Optional[AmountScale] = Field(
        default=None,
        description="Optional scale for this adjustment amount. If omitted, uses the Tested Jurisdiction amount_scale.",
    )

    note: Optional[str] = None

    # Box 4.6(3) large downward tax adjustment handling
    attributable_to_income_change: bool = Field(
        default=False,
        description="For Box 4.6(3): True if the tax decrease is attributable to a decrease in Simplified Income.",
    )
    apply_large_refund_exclusion: bool = Field(
        default=False,
        description="If True and Box 4.6(3) conditions are met, the engine may exclude this net tax decrease from the accrual year.",
    )
    qualification_basis: Optional[QualifiedRefundCheckBasis] = Field(
        default=None,
        description="How the user demonstrates that Box 4.6(3)(a) or (b) conditions are met.",
    )
    prior_year_simplified_income: Optional[float] = Field(
        default=None,
        description="If qualification_basis='SIMPLIFIED_ETR', provide the transaction year's Simplified Income before this adjustment.",
    )
    prior_year_simplified_taxes: Optional[float] = Field(
        default=None,
        description="If qualification_basis='SIMPLIFIED_ETR', provide the transaction year's Simplified Taxes before this adjustment.",
    )
    prior_year_deferred_tax_effect: Optional[float] = Field(
        default=None,
        description="Optional deferred tax effect (signed) for the transaction year associated with this adjustment, for Box 4.6(3) testing.",
    )
    attestation_prior_year_etr_not_below_minimum: Optional[bool] = Field(
        default=None,
        description="If qualification_basis is not SIMPLIFIED_ETR, set True to attest the transaction year's (Simplified or GloBE) ETR after adjustment is not below the Minimum Rate.",
    )

    @model_validator(mode="after")
    def _validate_aye(self) -> "AfterYearEndAdjustmentV2":
        # Normalise currency
        if self.currency:
            self.currency = str(self.currency).upper().strip() or None

        
        # Transfer pricing validations (section 5.2)
        if self.is_transfer_pricing_related:
            # Box 4.6(3) qualified refund exclusion is not intended to apply to TP adjustments (handled under section 5.2).
            if self.apply_large_refund_exclusion:
                raise ValueError("Box 4.6(3) exclusion is not applicable to transfer pricing-related adjustments (section 5.2).")

        # Counterparty field consistency (used when is_transfer_pricing_related=True)
        if self.tp_counterparty_tested_jurisdiction_id is None:
            if self.tp_counterparty_income_amount is not None or self.tp_counterparty_tax_amount is not None:
                raise ValueError(
                    "TP counterparty amounts provided but tp_counterparty_tested_jurisdiction_id is missing."
                )
        if not self.tp_apply_counterparty_income and self.tp_counterparty_income_amount is not None:
            raise ValueError("tp_counterparty_income_amount is set but tp_apply_counterparty_income=false.")
# If user requests Box 4.6(3) exclusion, enforce minimal structured inputs
        if self.apply_large_refund_exclusion:
            if self.kind != "tax":
                raise ValueError("Box 4.6(3) exclusion can only be applied to kind='tax' adjustments.")
            if self.amount >= 0:
                raise ValueError("Box 4.6(3) exclusion requires a net tax decrease (amount < 0).")
            if self.attributable_to_income_change:
                raise ValueError("Box 4.6(3) exclusion is not available where the decrease is attributable to a decrease in Simplified Income.")
            if self.months_after_transaction_year_end is None or self.months_after_transaction_year_end <= 12:
                raise ValueError("Box 4.6(3) exclusion requires months_after_transaction_year_end > 12.")
            if not self.qualification_basis:
                raise ValueError("Box 4.6(3) exclusion requires qualification_basis.")
            if self.qualification_basis == "SIMPLIFIED_ETR":
                if self.prior_year_simplified_income is None or self.prior_year_simplified_taxes is None:
                    raise ValueError("qualification_basis='SIMPLIFIED_ETR' requires prior_year_simplified_income and prior_year_simplified_taxes.")
            else:
                if self.attestation_prior_year_etr_not_below_minimum is not True:
                    raise ValueError("qualification_basis requires attestation_prior_year_etr_not_below_minimum=True when not using SIMPLIFIED_ETR numeric test.")
        return self



# ---------------------------------------------------------------------------
# Transfer pricing adjustments register (OECD section 5.2) (v4 phase 4.5 add-on)
# ---------------------------------------------------------------------------

class TransferPricingAdjustmentV2(BaseModel):
    """Transfer pricing adjustment register entry (OECD section 5.2).

    This is a dedicated register *separate* from Box 4.6 after-year-end adjustments.

    A single register entry represents one linked event across a seller and buyer Tested Jurisdiction,
    and can include both:
      - income adjustments (P&L), and
      - tax adjustments (Covered Tax liability changes),
    as a single coherent record with counterparty symmetry and stronger validation.

    Timing (OECD section 5.2):
      - Default (Box 5.2(1)): include in accrual year.
      - Optional Five-Year election (Box 5.2(2)): where the adjustment accrues within 12 months after the end
        of the transaction year, include in the transaction year (group-wide election).

    Currency translation convention:
      - Income and tax amounts are treated as P&L-type items -> average FX when reporting currency translation applies.
    """

    adjustment_id: Optional[str] = Field(default=None, description="Optional unique id for the TP adjustment.")
    label: Optional[str] = Field(default=None, description="Optional label for display/audit.")

    seller_tested_jurisdiction_id: str = Field(..., description="Seller Tested Jurisdiction (primary side).")
    buyer_tested_jurisdiction_id: str = Field(..., description="Buyer Tested Jurisdiction (counterparty side).")

    transaction_year_fy_start: date = Field(..., description="Fiscal year start date of the transaction year.")
    accrual_year_fy_start: date = Field(..., description="Fiscal year start date of the accrual year (where booked).")

    months_after_transaction_year_end: Optional[int] = Field(
        default=None,
        ge=0,
        description="Months after the end of the transaction year when the adjustment accrued (for the 12-month timing election).",
    )
    accrued_within_12_months: Optional[bool] = Field(
        default=None,
        description="Optional override for whether the adjustment accrued within 12 months of transaction year end.",
    )

    # Seller-side amounts (signed)
    seller_income_adjustment: float = Field(
        default=0.0,
        description="Signed income adjustment for the seller Tested Jurisdiction (P&L).",
    )
    seller_tax_adjustment: float = Field(
        default=0.0,
        description="Signed tax adjustment for the seller Tested Jurisdiction (Covered Tax liability change).",
    )

    # Buyer-side amounts (optional; defaulting rules apply)
    buyer_income_adjustment: Optional[float] = Field(
        default=None,
        description=(
            "Optional signed income adjustment for the buyer Tested Jurisdiction. "
            "If omitted, the tool defaults this to the negative of the seller_income_adjustment (symmetry), "
            "unless a special-case flag requires explicit counterparty treatment."
        ),
    )
    buyer_tax_adjustment: Optional[float] = Field(
        default=None,
        description="Optional signed tax adjustment for the buyer Tested Jurisdiction (if applicable). If omitted, defaults to 0.0.",
    )

    # Special-case flags (audit + validation)
    tp_accounted_at_cost: bool = Field(
        default=False,
        description="If True, indicates the intra-group transfer is accounted at cost (OECD section 5.2 special case).",
    )
    tp_intangible_asset_related: bool = Field(
        default=False,
        description="If True, indicates the adjustment relates to an intangible asset transfer (OECD section 5.2 special case).",
    )
    tp_loss_disallowed_deemed_tp_adjustment: bool = Field(
        default=False,
        description="If True, indicates a deemed TP adjustment arises due to a disallowed loss on an intra-group transfer (OECD section 5.2).",
    )

    # Optional currency/scaling if different from the seller Tested Jurisdiction default
    currency: Optional[str] = Field(
        default=None,
        description=(
            "Optional currency code for this TP adjustment amounts. If omitted, the tool assumes the amounts are expressed "
            "in the seller Tested Jurisdiction accounting_basis.currency (or reporting currency if none is provided)."
        ),
    )
    amount_scale: Optional[AmountScale] = Field(
        default=None,
        description="Optional scale for this adjustment. If omitted, uses the seller Tested Jurisdiction amount_scale.",
    )

    note: Optional[str] = None

    @model_validator(mode="after")
    def _validate_tp(self) -> "TransferPricingAdjustmentV2":
        # Normalise currency
        if self.currency:
            self.currency = str(self.currency).upper().strip() or None

        # Basic sanity: must have a non-zero effect
        total = abs(float(self.seller_income_adjustment or 0.0)) + abs(float(self.seller_tax_adjustment or 0.0))
        total += abs(float(self.buyer_income_adjustment or 0.0)) + abs(float(self.buyer_tax_adjustment or 0.0))
        if total == 0.0:
            raise ValueError("TransferPricingAdjustmentV2: at least one of the income/tax adjustments must be non-zero.")

        # Stronger validations for special cases: require explicit counterparty income treatment
        if (self.tp_accounted_at_cost or self.tp_intangible_asset_related or self.tp_loss_disallowed_deemed_tp_adjustment):
            if self.buyer_income_adjustment is None:
                raise ValueError(
                    "TransferPricingAdjustmentV2: buyer_income_adjustment is required when any TP special-case flag is set "
                    "(tp_accounted_at_cost / tp_intangible_asset_related / tp_loss_disallowed_deemed_tp_adjustment). "
                    "Provide explicit counterparty income treatment rather than relying on default symmetry."
                )

        return self



# ---------------------------------------------------------------------------
# TP migration helper (convert TP-tagged Box 4.6 rows into TP register entries)
# ---------------------------------------------------------------------------

TPMigrationIssueSeverity = Literal["error", "warning"]


class TPMigrationIssueV2(BaseModel):
    severity: TPMigrationIssueSeverity = Field(..., description="'error' or 'warning'")
    row_number: int = Field(..., ge=1, description="1-indexed index of the source AYE row in after_year_end_adjustments.")
    source_adjustment_id: Optional[str] = Field(default=None, description="Source AYE adjustment_id (if any).")
    message: str


class TPMigrateFromAYEOptionsV2(BaseModel):
    allow_partial: bool = Field(
        default=True,
        description=(
            "If true (default), returns migrated entries plus issues; rows that cannot be migrated are left in remaining_after_year_end_adjustments. "
            "If false, any migration errors cause HTTP 400 (the response payload is returned as the error detail)."
        ),
    )

    combine_income_and_tax: bool = Field(
        default=True,
        description=(
            "If true (default), attempts to combine income and tax TP rows that share the same adjustment_id/label and timing into a single TP register entry. "
            "If false, creates a separate TP register entry per TP-tagged AYE row."
        ),
    )

    drop_unmigrated_tp_rows: bool = Field(
        default=False,
        description=(
            "If true, TP-tagged AYE rows that cannot be migrated are dropped from remaining_after_year_end_adjustments (still reported as issues). "
            "If false (default), they remain in remaining_after_year_end_adjustments."
        ),
    )


class TPMigrateFromAYERequestV2(BaseModel):
    """Input payload for /api/v2/transfer-pricing-adjustments/migrate-from-aye.

    The endpoint converts TP-tagged Box 4.6 rows (AfterYearEndAdjustmentV2 with is_transfer_pricing_related=true)
    into TransferPricingAdjustmentV2 register entries.

    This request model is intentionally *lenient* and does not enforce the "no double counting" validation that
    CalculationRequestV2 applies, so that clients can call this endpoint even when they still have TP-tagged AYE rows.
    """

    after_year_end_adjustments: List[AfterYearEndAdjustmentV2] = Field(default_factory=list)
    tested_jurisdiction_ids: Optional[List[str]] = Field(
        default=None,
        description=(
            "Optional list of valid tested_jurisdiction_id values. If provided, the migrator will validate that seller/buyer ids exist."
        ),
    )
    existing_transfer_pricing_adjustments: List[TransferPricingAdjustmentV2] = Field(
        default_factory=list,
        description="Optional existing TP register entries. The migrated entries will be appended to these.",
    )
    options: TPMigrateFromAYEOptionsV2 = Field(default_factory=TPMigrateFromAYEOptionsV2)


class TPMigrateFromAYEResponseV2(BaseModel):
    transfer_pricing_adjustments: List[TransferPricingAdjustmentV2] = Field(default_factory=list)
    remaining_after_year_end_adjustments: List[AfterYearEndAdjustmentV2] = Field(default_factory=list)
    issues: List[TPMigrationIssueV2] = Field(default_factory=list)

    migrated_tp_rows: int = 0
    combined_register_entries: int = 0
    skipped_tp_rows: int = 0



# ---------------------------------------------------------------------------
# Investment entity owner addbacks (v2)
# ---------------------------------------------------------------------------

OwnerAddbackKind = Literal["tax", "income"]
InvestmentEntityArticle = Literal["7.5", "7.6"]


class InvestmentEntityOwnerAddbackV2(BaseModel):
    """Structured owner addback line for Investment Entity rules (Articles 7.5 and 7.6).

    The OECD investment entity rules can require adding certain owner-level taxes (and in some cases
    related income) back into the Tested Jurisdiction's Simplified Taxes/Simplified Income.

    This tool models the addback as a signed amount applied to Simplified Taxes or Simplified Income.
    """

    addback_id: Optional[str] = None
    label: str = Field(..., description="Short label for the addback.")
    article: InvestmentEntityArticle = Field(..., description="OECD rule reference: '7.5' or '7.6'.")
    kind: OwnerAddbackKind = Field(..., description="Whether this addback adjusts Simplified Taxes or Simplified Income.")
    amount: float = Field(..., description="Signed amount (+/-) to apply.")

    owner_name: Optional[str] = None
    owner_jurisdiction_code: Optional[str] = None
    note: Optional[str] = None


# ---------------------------------------------------------------------------
# Tested Jurisdiction wrapper
# ---------------------------------------------------------------------------

AggregationMethod = Literal["JURISDICTION_FACTS", "ENTITY_ROLLUP", "MIXED"]


class TestedJurisdictionCompositionV2(BaseModel):
    aggregation_method: AggregationMethod = Field(
        default="JURISDICTION_FACTS",
        description="How inputs are provided for the Tested Jurisdiction.",
    )


class EligibilityInputsV2(BaseModel):
    ineligible_stateless: bool = False
    ineligible_investment_entity: bool = False
    ineligible_article7_3_outstanding_recapture: bool = False

    stateless_exception_section_6_2_applies: bool = False
    investment_entity_tax_transparency_election_applies: bool = False

    no_topup_tax_in_prior_24_months: bool = True
    reentry_no_topup_tax_in_prior_24_months: Optional[bool] = None

    integrity_rules_satisfied: bool = True



# ---------------------------------------------------------------------------
# Integrity rules scaffolding (Box 7.3) (v4 module 10)
# ---------------------------------------------------------------------------

IntegrityPrincipleV2 = Literal[
    "MATCHING",
    "FULL_ALLOCATION",
    "SINGLE_EXPENSE_LOSS",
    "SINGLE_TAX",
    "FINANCIAL_INSTRUMENT_CLASSIFICATION",
    "OTHER",
]

IntegrityIssueSeverityV2 = Literal["error", "warning", "info"]
IntegrityAdjustmentKindV2 = Literal["income", "tax"]


class IntegrityAutomationOptionsV2(BaseModel):
    """Controls automated integrity checks under OECD Box 7.3.

    Notes:
      - The tool can only check a subset of integrity principles deterministically.
      - 'fail_on_errors' (default True) makes integrity errors disqualify the safe harbour (eligibility).
      - 'treat_warnings_as_errors' can be enabled for conservative workflows.
    """

    enable_integrity_checks: bool = Field(
        default=True,
        description="If True (default), run automated integrity checks and include an integrity assessment in results.",
    )
    tolerance: float = Field(
        default=1e-6,
        ge=0.0,
        description="Absolute tolerance used for numeric comparisons in integrity checks (rounding / FX noise).",
    )
    fail_on_errors: bool = Field(
        default=True,
        description="If True (default), integrity issues with severity='error' cause eligible=False for the Tested Jurisdiction.",
    )
    treat_warnings_as_errors: bool = Field(
        default=False,
        description="If True, integrity warnings are treated as errors for eligibility purposes (conservative).",
    )


class IntegrityAdjustmentV2(BaseModel):
    """Manual integrity adjustment register entry.

    Purpose:
      - Provide a structured way to record user-driven adjustments made to satisfy Box 7.3 integrity principles.
      - Adjustments can affect Simplified Income or Simplified Taxes and are applied before final ETR and safe harbour tests.
      - Optionally, an adjustment can be used to mark a specific integrity issue code as 'resolved' (audit trail).

    Important:
      - This is a modelling tool. Users must ensure the adjustment reflects the OECD rules and their facts.
    """

    adjustment_id: Optional[str] = Field(default=None, description="Optional unique id for the integrity adjustment.")
    tested_jurisdiction_id: str = Field(..., description="Tested Jurisdiction to which the adjustment is applied.")
    principle: IntegrityPrincipleV2 = Field(
        default="OTHER",
        description="Integrity principle this adjustment relates to (Box 7.3).",
    )
    kind: IntegrityAdjustmentKindV2 = Field(..., description="'income' or 'tax'.")
    amount: float = Field(..., description="Signed adjustment amount (+/-).")

    currency: Optional[str] = Field(
        default=None,
        description="Optional currency code for the adjustment amount. If omitted, assumed to be in the TJ currency / reporting currency context.",
    )
    amount_scale: AmountScale = Field(default="UNITS", description="Scale applied to the amount: UNITS/THOUSANDS/MILLIONS.")

    resolves_issue_code: Optional[str] = Field(
        default=None,
        description="Optional integrity issue code that this adjustment is intended to resolve (audit trail).",
    )
    evidence_ref: Optional[str] = Field(
        default=None,
        description="Optional reference to supporting documentation (workpaper id, memo ref, file name).",
    )
    note: Optional[str] = None

    @model_validator(mode="after")
    def _norm(self) -> "IntegrityAdjustmentV2":
        if self.currency:
            self.currency = str(self.currency).upper().strip() or None
        if self.adjustment_id:
            self.adjustment_id = str(self.adjustment_id).strip() or None
        if self.resolves_issue_code:
            self.resolves_issue_code = str(self.resolves_issue_code).strip() or None
        return self


class IntegrityIssueV2(BaseModel):
    severity: IntegrityIssueSeverityV2
    principle: IntegrityPrincipleV2
    code: str
    message: str
    tested_jurisdiction_id: Optional[str] = None
    reference_id: Optional[str] = None
    path: Optional[str] = None

    # v4 Module 10.1 (Resolve helper): UI hinting so clients can offer a one-click
    # "Resolve" action for issues that can be documented via the integrity_adjustments register.
    resolvable: bool = Field(
        default=False,
        description=(
            "True if this issue can be downgraded to info by adding an integrity_adjustment with resolves_issue_code=<code>. "
            "This is intended as an audit trail mechanism (documented exception) rather than an automatic numeric correction."
        ),
    )
    resolution_default_kind: Optional[Literal["income", "tax"]] = Field(
        default=None,
        description="Suggested integrity adjustment kind to document/resolve the issue (income or tax).",
    )
    resolution_guidance: Optional[str] = Field(
        default=None,
        description="Short guidance text for UIs explaining how to document/resolve the issue.",
    )


class IntegrityAssessmentV2(BaseModel):
    passed: bool = Field(..., description="True if integrity checks pass under the configured automation options.")
    issues: List[IntegrityIssueV2] = Field(default_factory=list)
    notes: List[str] = Field(default_factory=list)


class IntegrityResolutionCatalogItemV2(BaseModel):
    """Describes a resolvable integrity issue code and how to document it.

    v4 Module 10.1: used by UI builders (e.g., Anything.com) to offer a guided 'Resolve' action.
    """

    code: str
    principle: IntegrityPrincipleV2
    default_kind: Literal["income", "tax"]
    title: str
    guidance: str


class IntegrityResolveTemplateRequestV2(BaseModel):
    """Build a draft IntegrityAdjustmentV2 row to document/resolve an integrity issue."""

    tested_jurisdiction_id: str
    issue_code: str
    reference_id: Optional[str] = None
    path: Optional[str] = None
    currency: Optional[str] = None
    amount_scale: AmountScale = "UNITS"
    evidence_ref: Optional[str] = None
    note: Optional[str] = None


class IntegrityResolveTemplateResponseV2(BaseModel):
    template: IntegrityAdjustmentV2
    notes: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)


class DeemedZeroRulesV2(BaseModel):
    apply_deemed_zero: bool = Field(
        default=False,
        description=(
            "If True, treat Simplified Income and Simplified Taxes as zero for the Tested Jurisdiction "
            "(deemed-zero rule). This is intended for certain Tax-Neutral Entity scenarios."
        ),
    )
    rationale: Optional[str] = None



class DeemedZeroAutomationOptionsV2(BaseModel):
    """Controls automatic deemed-zero determinations (OECD section 6).

    v4 Module 7: automatically determine when Simplified Income / Simplified Taxes (and thus Top-up Tax) are
    deemed to be zero for certain Tax-Neutral UPE and Tax-Transparent / Flow-through scenarios, using
    the now-live section 5.1 allocation outputs.
    """

    enable_auto_deemed_zero: bool = Field(
        default=True,
        description="If True (default), the engine will automatically apply section 6 deemed-zero rules when conditions are met.",
    )
    zero_tolerance: float = Field(
        default=1e-6,
        ge=0.0,
        description="Absolute tolerance used when evaluating whether post-allocation Simplified Income/Taxes are effectively zero.",
    )
    qualified_persons_threshold: float = Field(
        default=0.9999,
        ge=0.0,
        le=1.0,
        description="Threshold (0–1) for Qualified Persons ownership used in the Tax-Neutral UPE deemed-zero test.",
    )



# ---------------------------------------------------------------------------
# Entry / re-entry criteria scaffolding (Box 7.2) (v4 module 8)
# ---------------------------------------------------------------------------

PriorYearRegimeV2 = Literal[
    "FULL_GLOBE",
    "SIMPLIFIED_ETR_SAFE_HARBOUR",
    "SPECIFIED_SAFE_HARBOUR",
    "TRANSITIONAL_CBCR_SAFE_HARBOUR",
    "QDMTT_SAFE_HARBOUR",
    "OTHER",
]

TopupTaxStatusV2 = Literal["NONE", "TOPUP_TAX", "UNKNOWN"]


class PriorYearStatusV2(BaseModel):
    """Prior-year status register row used for Box 7.2 entry / re-entry criteria.

    This tool cannot access historical filings. Users provide an explicit register of prior-year
    outcomes for a Tested Jurisdiction. The engine then deterministically evaluates the OECD
    24-month entry and re-entry criteria.

    Practical scope:
      - Top-up tax in prior years is considered only for FULL_GLOBE and SPECIFIED_SAFE_HARBOUR regimes.
      - Transitional CbCR Safe Harbour and QDMTT Safe Harbour are not treated as "Specified Safe Harbours"
        for re-entry criteria purposes.
      - Additional Current Top-up Tax for a prior year can be flagged and (optionally) ignored.
    """

    tested_jurisdiction_id: str
    fiscal_year_start: date

    regime: PriorYearRegimeV2 = Field(
        default="FULL_GLOBE",
        description=(
            "Regime under which the Tested Jurisdiction's position is determined for this prior year. "
            "Use FULL_GLOBE for full GloBE computations; SPECIFIED_SAFE_HARBOUR for OECD-defined specified safe harbours; "
            "TRANSITIONAL_CBCR_SAFE_HARBOUR and QDMTT_SAFE_HARBOUR are recorded but not treated as specified safe harbours for Box 7.2." 
        ),
    )

    topup_tax_status: TopupTaxStatusV2 = Field(
        default="UNKNOWN",
        description="Whether a Top-up Tax liability existed for that Tested Jurisdiction for that fiscal year.",
    )

    additional_current_topup_tax_for_prior_year: bool = Field(
        default=False,
        description=(
            "If True, indicates that the Top-up Tax reflected here is an 'Additional Current Top-up Tax' for a prior year "
            "(treated as arising in a later year). For Box 7.2 re-entry criteria, this may be ignored depending on policy."
        ),
    )

    specified_safe_harbour_name: Optional[str] = Field(
        default=None,
        description="Optional label for the specified safe harbour applied (if regime='SPECIFIED_SAFE_HARBOUR').",
    )

    note: Optional[str] = None

    @model_validator(mode='after')
    def _norm(self) -> 'PriorYearStatusV2':
        self.tested_jurisdiction_id = str(self.tested_jurisdiction_id).strip()
        if self.specified_safe_harbour_name:
            self.specified_safe_harbour_name = str(self.specified_safe_harbour_name).strip() or None
        return self


EntryReentryModeV2 = Literal["FIRST_ELECTION", "CONTINUATION", "REENTRY"]


class EntryReentryAutomationOptionsV2(BaseModel):
    """Controls automatic Box 7.2 entry / re-entry determinations."""

    enable_auto_entry_reentry: bool = Field(
        default=True,
        description="If True, compute Box 7.2 entry/re-entry criteria using prior_years_status where provided.",
    )

    lookback_months: int = Field(
        default=24,
        ge=0,
        description="Lookback period in months for Box 7.2 (default 24 months).",
    )

    require_complete_lookback_coverage: bool = Field(
        default=True,
        description=(
            "If True (default), the engine requires that a prior_years_status row exists for each expected fiscal year start within the lookback window "
            "(computed as 12-month steps back from the anchor). If missing, the criteria fails unless a v2 eligibility input attestation is provided." 
        ),
    )

    ignore_additional_current_topup_tax_for_prior_year: bool = Field(
        default=True,
        description=(
            "If True (default), a prior-year row flagged as additional_current_topup_tax_for_prior_year will not be treated as tainting the entry/re-entry criteria." 
        ),
    )


class EntryReentryStatusV2(BaseModel):
    """Computed Box 7.2 entry/re-entry evaluation for a Tested Jurisdiction."""

    mode: EntryReentryModeV2

    # Anchor year used for the 24-month lookback.
    anchor_fiscal_year_start: date

    lookback_window_start: date
    lookback_window_end: date
    lookback_months: int

    required_prior_fiscal_year_starts: List[date] = Field(default_factory=list)
    missing_prior_fiscal_year_starts: List[date] = Field(default_factory=list)

    tainting_fiscal_year_starts: List[date] = Field(default_factory=list)

    entry_criteria_satisfied: Optional[bool] = None
    reentry_criteria_satisfied: Optional[bool] = None

    used_fallback_attestation: bool = False

    notes: List[str] = Field(default_factory=list)

class TestedJurisdictionInputV2(BaseModel):
    tested_jurisdiction_id: str = Field(..., description="Unique identifier for this Tested Jurisdiction.")
    jurisdiction_code: Optional[str] = Field(
        default=None, description="Country/territory code (e.g. 'GB', 'DE'). Multiple Tested Jurisdictions may share a code."
    )
    label: Optional[str] = Field(default=None, description="Optional display label.")
    tested_jurisdiction_type: Optional[str] = Field(
        default=None,
        description="Optional classification (e.g., 'standard', 'stateless', 'investment_entity'). Informational.",
    )

    accounting_basis: AccountingBasisV2 = Field(
        default_factory=AccountingBasisV2,
        description=(
            "Accounting basis and currency metadata. If request.group_profile.reporting_currency is provided "
            "and accounting_basis.currency differs, inputs will be translated using request.fx_rates." 
        ),
    )

    composition: TestedJurisdictionCompositionV2 = Field(default_factory=TestedJurisdictionCompositionV2)

    # Inputs (either provide facts or entities depending on composition method)
    facts: Optional[JurisdictionFactsV2] = None
    entities: List[EntityFactsV2] = Field(default_factory=list)

    # Elections and carryforwards
    elections: List[ElectionInstanceV2] = Field(default_factory=list)
    owner_addbacks: List[InvestmentEntityOwnerAddbackV2] = Field(
        default_factory=list,
        description="Structured owner addbacks (Articles 7.5/7.6) applied to this Tested Jurisdiction.",
    )
    carryforwards_opening: List[CarryforwardBalanceV2] = Field(default_factory=list)

    # Transition Year (Box 4.5)
    transition_year: Optional[TransitionYearV2] = Field(
        default=None,
        description=(
            "Optional Transition Year configuration. If provided, the engine applies Transition Year rules (Box 4.5) "
            "including Articles 9.1.1-9.1.3 scaffolding."
        ),
    )

    transition_year_state_opening: Optional[TransitionYearStateV2] = Field(
        default=None,
        description=(
            "Optional Transition Year deferred-tax state carried forward from a prior computation. "
            "If provided, the engine uses it to determine the Transition Year start date (when transition_year is omitted) "
            "and to re-apply Article 9.1.2 disallowed opening DTA adjustments in the Transition Year without re-entering opening balances."
        ),
    )

    # Eligibility & deemed-zero
    eligibility_inputs: EligibilityInputsV2 = Field(default_factory=EligibilityInputsV2)
    deemed_zero_rules: DeemedZeroRulesV2 = Field(default_factory=DeemedZeroRulesV2)

    @model_validator(mode="after")
    def _validate_composition(self) -> "TestedJurisdictionInputV2":
        m = self.composition.aggregation_method
        if m == "JURISDICTION_FACTS":
            if self.facts is None:
                raise ValueError(f"{self.tested_jurisdiction_id}: aggregation_method='JURISDICTION_FACTS' requires facts.")
        elif m == "ENTITY_ROLLUP":
            if not self.entities:
                raise ValueError(f"{self.tested_jurisdiction_id}: aggregation_method='ENTITY_ROLLUP' requires entities[].")
        elif m == "MIXED":
            if self.facts is None and not self.entities:
                raise ValueError(f"{self.tested_jurisdiction_id}: aggregation_method='MIXED' requires facts and/or entities[].")
        return self


# ---------------------------------------------------------------------------
# Request / Response (v2)
# ---------------------------------------------------------------------------

class ApplicabilityOptionsV2(BaseModel):
    apply_optional_2025_start_rule: bool = False
    early_start_qdmtt_safe_harbour_applies: bool = False
    early_start_only_one_jurisdiction_has_taxing_rights: bool = False
    early_start_all_taxing_rights_jurisdictions_allow: bool = False


class FiscalYearV2(BaseModel):
    start_date: date
    end_date: Optional[date] = None


class CalculationRequestV2(BaseModel):
    schema_version: Literal["2.0", "2.1", "2.2", "2.3", "2.4", "2.5", "2.6", "2.7"] = "2.7"
    ruleset_version: str = Field(default="OECD_SBS_2026_01", description="OECD Side-by-Side Package (Jan 2026).")

    fiscal_year: FiscalYearV2
    minimum_rate: float = Field(default=0.15, ge=0.0, le=1.0)

    group_profile: Optional[GroupProfileV2] = Field(
        default=None,
        description="Optional group profile metadata (reporting currency and accounting standard).",
    )
    fx_rates: List[FxRateV2] = Field(
        default_factory=list,
        description=(
            "Optional FX rates used to translate Tested Jurisdiction inputs into the reporting currency. "
            "If group_profile.reporting_currency is provided and a Tested Jurisdiction declares a different currency, "
            "a matching FX rate must be provided."
        ),
    )

    applicability: ApplicabilityOptionsV2 = Field(default_factory=ApplicabilityOptionsV2)

    deemed_zero_automation: DeemedZeroAutomationOptionsV2 = Field(
        default_factory=DeemedZeroAutomationOptionsV2,
        description="Controls automatic OECD section 6 deemed-zero determinations. Manual override remains available via tested_jurisdiction.deemed_zero_rules.",
    )




    entry_reentry_automation: EntryReentryAutomationOptionsV2 = Field(
        default_factory=EntryReentryAutomationOptionsV2,
        description=(
            "Controls automatic Box 7.2 entry/re-entry determinations using prior_years_status. "
            "EligibilityInputsV2 booleans remain available as a fallback attestation path."
        ),
    )

    prior_years_status: List[PriorYearStatusV2] = Field(
        default_factory=list,
        description=(
            "Optional register of prior-year Tested Jurisdiction outcomes used to compute Box 7.2 entry and re-entry criteria. "
            "Provide one row per Tested Jurisdiction per fiscal year start."
        ),
    )

    integrity_automation: IntegrityAutomationOptionsV2 = Field(
        default_factory=IntegrityAutomationOptionsV2,
        description=(
            "Controls automated integrity checks under OECD Box 7.3. "
            "Integrity errors can disqualify the safe harbour (eligibility) depending on configuration."
        ),
    )

    integrity_adjustments: List[IntegrityAdjustmentV2] = Field(
        default_factory=list,
        description=(
            "Optional integrity adjustment register (Box 7.3). "
            "Applied before final ETR and safe harbour tests. "
            "Use resolves_issue_code to document which integrity issue an adjustment addresses."
        ),
    )


    group_elections: List[ElectionInstanceV2] = Field(
        default_factory=list,
        description=(
            "Optional group-wide election register events. Use this for elections that apply across all Tested Jurisdictions "
            "(e.g., Box 4.6 after-year-end adjustments timing election)."
        ),
    )

    after_year_end_adjustments: List[AfterYearEndAdjustmentV2] = Field(
        default_factory=list,
        description="Optional after-year-end tax/income adjustments under OECD Box 4.6.",
    )

    transfer_pricing_adjustments: List[TransferPricingAdjustmentV2] = Field(
        default_factory=list,
        description="Optional transfer pricing adjustment register entries under OECD section 5.2 (separate from Box 4.6).",
    )

    cross_border_tax_items: List[CrossBorderTaxItemV2] = Field(
        default_factory=list,
        description="Optional cross-border tax items that require exclusion/allocation between Tested Jurisdictions.",
    )

    

    permanent_establishments: List[PermanentEstablishmentV2] = Field(
    default_factory=list,
    description="Optional Permanent Establishment linkage register (allocation-ready scaffolding for OECD section 5.1).",
)

    flow_through_entities: List[FlowThroughEntityAllocationV2] = Field(
    default_factory=list,
    description="Optional flow-through / tax-transparent entity allocation lines (allocation-ready scaffolding for OECD section 5.1).",
)

    allocable_tax_items: List[AllocableTaxItemV2] = Field(
    default_factory=list,
    description="Optional allocable tax item register with explicit Article 4.3.2 references (allocation-ready scaffolding for OECD section 5.1).",
)

    pe_allocation_lines: List[PEAllocationLineV2] = Field(
        default_factory=list,
        description=(
            "Optional Permanent Establishment allocation lines for the PE Simplification Election (OECD section 5.1). "
            "These lines specify the PE income/tax components included in the Main Entity Tested Jurisdiction when the election is effective."
        ),
    )

    pe_simplification_state_opening: List[PESimplificationStateItemV2] = Field(
        default_factory=list,
        description=(
            "Optional client-managed state for PE Simplification Election continuation (loss recapture tracking). "
            "Supply the prior-year pe_simplification_state_closing to enforce the OECD continuation requirement."
        ),
    )

    # ------------------------------------------------------------------
    # Deemed Distribution Tax Recapture Account (Article 7.3) (v4 module 14)
    # ------------------------------------------------------------------
    ddt_recapture_account_state_opening: List["DDTRecaptureAccountStateV2"] = Field(
        default_factory=list,
        description=(
            "Optional Deemed Distribution Tax Recapture Account opening balances per Tested Jurisdiction (Article 7.3). "
            "If an opening balance is outstanding (>0) at the beginning of the Fiscal Year, the Tested Jurisdiction is not eligible "
            "to elect the Simplified ETR Safe Harbour until the balance is reduced to nil."
        ),
    )

    ddt_recapture_account_movements: List["DDTRecaptureAccountMovementV2"] = Field(
        default_factory=list,
        description=(
            "Optional Deemed Distribution Tax Recapture Account movement lines for the current Fiscal Year. "
            "These are used to compute a closing balance for scenario roll-forward. They do not affect eligibility for the current Fiscal Year "
            "(eligibility is determined based on the opening balance at FY start)."
        ),
    )

    tested_jurisdictions: List[TestedJurisdictionInputV2] = Field(default_factory=list)

    @model_validator(mode="after")
    def _validate(self) -> "CalculationRequestV2":
        if not self.tested_jurisdictions:
            raise ValueError("tested_jurisdictions[] must contain at least one Tested Jurisdiction.")

        # Normalise reporting currency to uppercase (if provided)
        if self.group_profile and self.group_profile.reporting_currency:
            self.group_profile.reporting_currency = str(self.group_profile.reporting_currency).upper().strip() or None

        # Normalise FX currencies and validate duplicates
        seen_fx: set[tuple[str, Optional[date]]] = set()
        for r in (self.fx_rates or []):
            r.currency = str(r.currency).upper().strip()
            key = (r.currency, r.fiscal_year_start)
            if key in seen_fx:
                raise ValueError(f"Duplicate FX rate entry for currency '{r.currency}' and fiscal_year_start={r.fiscal_year_start}.")
            seen_fx.add(key)

        # LFAS / QDMTT group-wide gating (v4 module 3)
        # OECD requires that if an MNE uses a permitted CFS GAAP election in one QDMTT LFAS jurisdiction,
        # it should apply consistently across all QDMTT LFAS jurisdictions that provide the same election.
        lfas_allow_election: list[TestedJurisdictionInputV2] = []
        for tj in self.tested_jurisdictions:
            b = tj.accounting_basis
            if bool(b.lfas_qdmtt_applies) and bool(b.lfas_requires_local_gaap) and bool(b.jurisdiction_allows_cfs_gaap_for_qdmtt):
                lfas_allow_election.append(tj)

        cfs_used = any(tj.accounting_basis.basis_source == "CFS" for tj in lfas_allow_election)
        if cfs_used:
            # If CFS basis is used in any LFAS jurisdiction where an election is available, require all such jurisdictions to use it.
            offenders = [tj.tested_jurisdiction_id for tj in lfas_allow_election if tj.accounting_basis.basis_source != "CFS"]
            if offenders:
                raise ValueError(
                    "LFAS consistency: basis_source='CFS' is used in at least one QDMTT LFAS jurisdiction where an election is available. "
                    "OECD consistency requires applying the election to all such jurisdictions. "
                    f"Set basis_source='CFS' for: {', '.join(offenders)} (or use LOCAL_GAAP for all)."
                )

        # Prevent accidental double counting: if users supply the explicit TP register,
        # do not allow TP rows inside after_year_end_adjustments at the same time.
        if self.transfer_pricing_adjustments:
            tp_in_aye = any(bool(getattr(a, "is_transfer_pricing_related", False)) for a in (self.after_year_end_adjustments or []))
            if tp_in_aye:
                raise ValueError(
                    "Transfer pricing inputs: transfer_pricing_adjustments[] is provided, but after_year_end_adjustments[] also contains "
                    "transfer pricing-related rows (is_transfer_pricing_related=true). "
                    "Use the explicit transfer_pricing_adjustments register (section 5.2) instead of Box 4.6 TP rows to avoid double counting."
                )

        

        # Allocation-ready register validation (v4 module 5)
        tj_ids = {tj.tested_jurisdiction_id for tj in self.tested_jurisdictions}

        # Deemed Distribution Tax Recapture Account register validation (Article 7.3) (v4 module 14)
        if getattr(self, "ddt_recapture_account_state_opening", None):
            seen_state_tjs: set[str] = set()
            for s in (self.ddt_recapture_account_state_opening or []):
                if s.tested_jurisdiction_id not in tj_ids:
                    raise ValueError(
                        f"DDTRecaptureAccountStateV2: tested_jurisdiction_id '{s.tested_jurisdiction_id}' is not a tested_jurisdiction_id in this request."
                    )
                if s.tested_jurisdiction_id in seen_state_tjs:
                    raise ValueError(
                        f"Duplicate DDTRecaptureAccountStateV2 for tested_jurisdiction_id '{s.tested_jurisdiction_id}'. Provide at most one opening balance per TJ."
                    )
                seen_state_tjs.add(s.tested_jurisdiction_id)

        if getattr(self, "ddt_recapture_account_movements", None):
            seen_move_ids: set[str] = set()
            for m in (self.ddt_recapture_account_movements or []):
                if m.tested_jurisdiction_id not in tj_ids:
                    raise ValueError(
                        f"DDTRecaptureAccountMovementV2: tested_jurisdiction_id '{m.tested_jurisdiction_id}' is not a tested_jurisdiction_id in this request."
                    )
                if m.movement_id:
                    if m.movement_id in seen_move_ids:
                        raise ValueError(f"Duplicate DDTRecaptureAccountMovementV2 movement_id '{m.movement_id}'.")
                    seen_move_ids.add(m.movement_id)

        # Integrity adjustment register validation (Box 7.3) (v4 module 10)
        if getattr(self, "integrity_adjustments", None):
            seen_adj_ids: set[str] = set()
            for adj in (self.integrity_adjustments or []):
                if adj.tested_jurisdiction_id not in tj_ids:
                    raise ValueError(
                        f"IntegrityAdjustmentV2: tested_jurisdiction_id '{adj.tested_jurisdiction_id}' is not a tested_jurisdiction_id in this request."
                    )
                if adj.adjustment_id:
                    if adj.adjustment_id in seen_adj_ids:
                        raise ValueError(f"Duplicate IntegrityAdjustmentV2 adjustment_id '{adj.adjustment_id}'.")
                    seen_adj_ids.add(adj.adjustment_id)

        # Prior-year status register validation (Box 7.2) (v4 module 8)
        if getattr(self, 'prior_years_status', None):
            seen_py: set[tuple[str, date]] = set()
            for row in (self.prior_years_status or []):
                if row.tested_jurisdiction_id not in tj_ids:
                    raise ValueError(
                        f"PriorYearStatusV2: tested_jurisdiction_id '{row.tested_jurisdiction_id}' is not a tested_jurisdiction_id in this request."
                    )
                key = (row.tested_jurisdiction_id, row.fiscal_year_start)
                if key in seen_py:
                    raise ValueError(
                        f"Duplicate PriorYearStatusV2 row for tested_jurisdiction_id='{row.tested_jurisdiction_id}' and fiscal_year_start={row.fiscal_year_start}."
                    )
                seen_py.add(key)

        for pe in getattr(self, "permanent_establishments", None) or []:
            if pe.pe_tested_jurisdiction_id and pe.pe_tested_jurisdiction_id not in tj_ids:
                raise ValueError(
                    f"PermanentEstablishmentV2: pe_tested_jurisdiction_id '{pe.pe_tested_jurisdiction_id}' is not a tested_jurisdiction_id in this request."
                )
            if pe.main_entity_tested_jurisdiction_id and pe.main_entity_tested_jurisdiction_id not in tj_ids:
                raise ValueError(
                    f"PermanentEstablishmentV2: main_entity_tested_jurisdiction_id '{pe.main_entity_tested_jurisdiction_id}' is not a tested_jurisdiction_id in this request."
                )

        for line in getattr(self, "flow_through_entities", None) or []:
            if line.flow_through_tested_jurisdiction_id and line.flow_through_tested_jurisdiction_id not in tj_ids:
                raise ValueError(
                    f"FlowThroughEntityAllocationV2: flow_through_tested_jurisdiction_id '{line.flow_through_tested_jurisdiction_id}' is not a tested_jurisdiction_id in this request."
                )
            if line.owner_tested_jurisdiction_id and line.owner_tested_jurisdiction_id not in tj_ids:
                raise ValueError(
                    f"FlowThroughEntityAllocationV2: owner_tested_jurisdiction_id '{line.owner_tested_jurisdiction_id}' is not a tested_jurisdiction_id in this request."
                )

        for item in getattr(self, "allocable_tax_items", None) or []:
            if item.source_tested_jurisdiction_id and item.source_tested_jurisdiction_id not in tj_ids:
                raise ValueError(
                    f"AllocableTaxItemV2: source_tested_jurisdiction_id '{item.source_tested_jurisdiction_id}' is not a tested_jurisdiction_id in this request."
                )
            if item.target_tested_jurisdiction_id and item.target_tested_jurisdiction_id not in tj_ids:
                raise ValueError(
                    f"AllocableTaxItemV2: target_tested_jurisdiction_id '{item.target_tested_jurisdiction_id}' is not a tested_jurisdiction_id in this request."
                )

        for line in getattr(self, "pe_allocation_lines", None) or []:
            if line.main_entity_tested_jurisdiction_id and line.main_entity_tested_jurisdiction_id not in tj_ids:
                raise ValueError(
                    f"PEAllocationLineV2: main_entity_tested_jurisdiction_id '{line.main_entity_tested_jurisdiction_id}' is not a tested_jurisdiction_id in this request."
                )
            if line.pe_tested_jurisdiction_id and line.pe_tested_jurisdiction_id not in tj_ids:
                raise ValueError(
                    f"PEAllocationLineV2: pe_tested_jurisdiction_id '{line.pe_tested_jurisdiction_id}' is not a tested_jurisdiction_id in this request."
                )

        return self


class TestedJurisdictionResultV2(BaseModel):
    tested_jurisdiction_id: str
    jurisdiction_code: Optional[str] = None
    label: Optional[str] = None

    transition_year_fy_start: Optional[date] = None
    is_transition_year: Optional[bool] = None

    transition_year_state_closing: Optional[TransitionYearStateV2] = Field(
        default=None,
        description="State payload to carry Transition Year deferred-tax register forward to later fiscal years. Store and feed back as transition_year_state_opening.",
    )

    eligible: bool
    ineligibility_reasons: List[str] = Field(default_factory=list)

    entry_reentry_status: Optional[EntryReentryStatusV2] = Field(
        default=None,
        description="Computed Box 7.2 entry/re-entry evaluation for this Tested Jurisdiction (Module 8).",
    )

    integrity_assessment: Optional[IntegrityAssessmentV2] = Field(
        default=None,
        description="Automated integrity assessment under OECD Box 7.3 (matching/allocation/single expense/single tax).",
    )

    simplified_income: float
    simplified_taxes: float
    simplified_etr: Optional[float] = None
    simplified_loss: float = 0.0

    safe_harbour_applies: bool
    safe_harbour_reason: str

    deemed_zero_applied: bool = Field(
        default=False,
        description="True if Simplified Income and Simplified Taxes were treated as zero due to a deemed-zero rule (manual or automatic).",
    )
    deemed_zero_basis: Optional[str] = Field(
        default=None,
        description="Basis for deemed-zero determination (e.g., MANUAL, SECTION_6_1_TAX_NEUTRAL_UPE, SECTION_6_2_TAX_TRANSPARENT).",
    )
    deemed_zero_reason: Optional[str] = Field(
        default=None,
        description="Explanation for why deemed-zero was applied (or would have been applied).",
    )


    # Allocation audit (OECD section 5.1)
    simplified_income_pre_allocations: Optional[float] = Field(
        default=None,
        description="Simplified Income immediately before section 5.1 allocations/exclusions (pre carryforwards).",
    )
    simplified_taxes_pre_allocations: Optional[float] = Field(
        default=None,
        description="Simplified Taxes immediately before section 5.1 allocations/exclusions (pre carryforwards).",
    )
    simplified_income_post_allocations: Optional[float] = Field(
        default=None,
        description="Simplified Income immediately after section 5.1 allocations/exclusions (pre carryforwards).",
    )
    simplified_taxes_post_allocations: Optional[float] = Field(
        default=None,
        description="Simplified Taxes immediately after section 5.1 allocations/exclusions (pre carryforwards).",
    )
    allocation_ledger: List[AllocationLedgerEntryV2] = Field(
        default_factory=list,
        description="Allocation ledger entries impacting this Tested Jurisdiction (section 5.1).",
    )
    allocation_warnings: List[str] = Field(
        default_factory=list,
        description="Non-fatal warnings related to allocations/exclusions applied under section 5.1.",
    )

    # Negative tax adjustment proxy (for transparency)
    simplified_adjustment_for_negative_taxes: float = 0.0

    # Elections and trace
    effective_elections: List[ElectionInstanceV2] = Field(default_factory=list)
    election_records: List[ElectionRecord] = Field(default_factory=list)
    trace: List[TraceLine] = Field(default_factory=list)

    # Carryforwards
    carryforwards_opening: List[CarryforwardBalanceV2] = Field(default_factory=list)
    carryforward_movements: List[CarryforwardMovementV2] = Field(default_factory=list)
    carryforwards_closing: List[CarryforwardBalanceV2] = Field(default_factory=list)


class CalculationResponseV2(BaseModel):
    schema_version: Literal["2.0", "2.1", "2.2", "2.3", "2.4", "2.5", "2.6", "2.7"] = "2.7"
    ruleset_version: str

    fiscal_year: FiscalYearV2
    minimum_rate: float

    reporting_currency: Optional[str] = Field(
        default=None,
        description="Echo of group_profile.reporting_currency if provided; results are expressed in this currency when FX translation is applied.",
    )

    results: List[TestedJurisdictionResultV2]

    pe_simplification_state_closing: List[PESimplificationStateItemV2] = Field(
        default_factory=list,
        description=(
            "Client-managed state for PE Simplification Election continuation (loss recapture tracking). "
            "Store this and supply it as pe_simplification_state_opening in the next-year request (or use /api/v2/scenario/advance-year)."
        ),
    )

    ddt_recapture_account_state_closing: List["DDTRecaptureAccountStateV2"] = Field(
        default_factory=list,
        description=(
            "Computed Deemed Distribution Tax Recapture Account closing balances per Tested Jurisdiction (Article 7.3). "
            "Store this and supply it as ddt_recapture_account_state_opening in the next-year request (or use /api/v2/scenario/advance-year)."
        ),
    )



# ---------------------------------------------------------------------------
# Allocation preview helpers (v4 module 6)
# ---------------------------------------------------------------------------


class AllocationPreviewItemV2(BaseModel):
    tested_jurisdiction_id: str
    jurisdiction_code: Optional[str] = None
    label: Optional[str] = None

    simplified_income_pre_allocations: float
    simplified_taxes_pre_allocations: float
    simplified_income_post_allocations: float
    simplified_taxes_post_allocations: float

    allocation_ledger: List[AllocationLedgerEntryV2] = Field(default_factory=list)
    allocation_warnings: List[str] = Field(default_factory=list)


class AllocationPreviewResponseV2(BaseModel):
    fiscal_year: FiscalYearV2
    reporting_currency: Optional[str] = None
    items: List[AllocationPreviewItemV2]
# ---------------------------------------------------------------------------
# Scenario helpers (v4 add-on): advance-year request builder
# ---------------------------------------------------------------------------


class ScenarioAdvanceYearOptionsV2(BaseModel):
    """Options controlling how the next-year scenario request is generated.

    This API is intentionally stateless. The client supplies the last request and last response.
    The server returns a new request payload for the next fiscal year.
    """

    # Fiscal-year control
    advance_to_fiscal_year_start: Optional[date] = Field(
        default=None,
        description="Optional override for the next fiscal year start date. If omitted, adds 1 year to last_request.fiscal_year.start_date.",
    )

    # Roll-forward controls
    carry_forward_transition_year_state: bool = Field(
        default=True,
        description="If true (default), sets transition_year_state_opening to last_response transition_year_state_closing for each Tested Jurisdiction.",
    )
    carry_forward_carryforwards: bool = Field(
        default=True,
        description="If true (default), sets carryforwards_opening to last_response carryforwards_closing for each Tested Jurisdiction.",
    )

    carry_forward_pe_simplification_state: bool = Field(
        default=True,
        description=(
            "If true (default), sets request.pe_simplification_state_opening to last_response.pe_simplification_state_closing. "
            "This supports the OECD PE Simplification Election continuation requirement in multi-year planner workflows."
        ),
    )

    carry_forward_ddt_recapture_account_state: bool = Field(
        default=True,
        description=(
            "If true (default), sets request.ddt_recapture_account_state_opening to last_response.ddt_recapture_account_state_closing. "
            "This supports multi-year tracking of the Article 7.3 Deemed Distribution Tax Recapture Account eligibility gate."
        ),
    )

    # Inputs reset controls
    clear_transition_year_inputs: bool = Field(
        default=True,
        description=(
            "If true (default), clears transition_year.opening_deferred_tax_items and transition_year.article_9_1_3_transfers in the next-year request. "
            "Transition Year state is carried separately via transition_year_state_opening."
        ),
    )


    clear_after_year_end_adjustments: bool = Field(
        default=True,
        description="If true (default), clears request.after_year_end_adjustments in the next-year request (year-specific input).",
    )

    clear_transfer_pricing_adjustments: bool = Field(
        default=True,
        description="If true (default), clears request.transfer_pricing_adjustments in the next-year request (year-specific input).",
    )

    clear_pe_allocation_lines: bool = Field(
        default=True,
        description="If true (default), clears request.pe_allocation_lines in the next-year request (year-specific input).",
    )

    clear_ddt_recapture_account_movements: bool = Field(
        default=True,
        description=(
            "If true (default), clears request.ddt_recapture_account_movements in the next-year request (year-specific input). "
            "Opening balances are carried separately via ddt_recapture_account_state_opening."
        ),
    )

    clear_allocable_tax_items: bool = Field(
    default=True,
    description="If true (default), clears request.allocable_tax_items in the next-year request (year-specific input).",
)

    clear_flow_through_entities: bool = Field(
    default=True,
    description=(
        "If true (default), clears request.flow_through_entities allocation lines in the next-year request (often year-specific). "
        "If you use this as a structural register, set this to false in scenario.advance-year options."
    ),
)



    # FX placeholders
    include_fx_placeholders: bool = Field(
        default=True,
        description=(
            "If true (default) and reporting currency translation is enabled, ensures the next-year request contains year-specific FX rate rows "
            "for currencies used by Tested Jurisdictions and cross-border items. If a next-year rate is missing, the tool copies the last-year rate "
            "when available or inserts a placeholder rate (1.0) with a warning."
        ),
    )

    # Prior-year status auto-builder (v4 module 9)
    append_prior_year_status: bool = Field(
        default=True,
        description=(
            "If true (default), appends PriorYearStatusV2 rows to next_request.prior_years_status for the fiscal year just calculated. "
            "This enables scenario planning workflows to build the Box 7.2 prior-year register automatically over time. "
            "Rows are added per Tested Jurisdiction based on the last_response safe_harbour_applies outcome."
        ),
    )

    append_prior_year_status_include_non_safe_harbour_years: bool = Field(
        default=False,
        description=(
            "If true, also appends prior-year status rows for Tested Jurisdictions where safe_harbour_applies=false, "
            "recording regime='FULL_GLOBE' with topup_tax_status='UNKNOWN'. If false (default), those rows are skipped and a warning is emitted."
        ),
    )


class ScenarioAdvanceYearRequestV2(BaseModel):
    last_request: CalculationRequestV2
    last_response: CalculationResponseV2
    options: ScenarioAdvanceYearOptionsV2 = Field(default_factory=ScenarioAdvanceYearOptionsV2)


class ScenarioAdvanceYearResponseV2(BaseModel):
    next_request: CalculationRequestV2
    warnings: List[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Validation helper (v4 module 5): /api/v2/validate
# ---------------------------------------------------------------------------

ValidationSeverity = Literal["error", "warning"]


class ValidationIssueV2(BaseModel):
    severity: ValidationSeverity
    code: str = Field(..., description="Machine-readable code for the issue.")
    message: str = Field(..., description="Human-readable message.")
    path: Optional[str] = Field(default=None, description="JSON path / location reference (if applicable).")
    tested_jurisdiction_id: Optional[str] = Field(default=None)
    entity_id: Optional[str] = Field(default=None)


class ValidationResponseV2(BaseModel):
    issues: List[ValidationIssueV2] = Field(default_factory=list)
    error_count: int = 0
    warning_count: int = 0

    @model_validator(mode="after")
    def _counts(self) -> "ValidationResponseV2":
        self.error_count = sum(1 for i in self.issues if i.severity == "error")
        self.warning_count = sum(1 for i in self.issues if i.severity == "warning")
        return self


# ---------------------------------------------------------------------------
# Tested Jurisdiction builder (v4 module 5): /api/v2/tested-jurisdictions/build
# ---------------------------------------------------------------------------


class TestedJurisdictionsBuildOptionsV2(BaseModel):
    default_aggregation_method: AggregationMethod = Field(default="ENTITY_ROLLUP")
    separate_investment_entities: bool = True
    separate_tax_neutral_upe: bool = True
    separate_tax_transparent_entities: bool = True
    separate_flow_through_entities: bool = True
    separate_stateless: bool = True
    separate_joint_venture_groups: bool = True
    separate_moce_groups: bool = True


class TestedJurisdictionsBuildRequestV2(BaseModel):
    entities: List[EntityFactsV2] = Field(default_factory=list)
    options: TestedJurisdictionsBuildOptionsV2 = Field(default_factory=TestedJurisdictionsBuildOptionsV2)


class TestedJurisdictionsBuildAssignmentV2(BaseModel):
    entity_id: Optional[str] = None
    entity_name: str
    entity_type: Optional[str] = None
    jv_group_id: Optional[str] = None
    moce_group_id: Optional[str] = None
    tested_jurisdiction_id: str
    jurisdiction_code: Optional[str] = None
    note: Optional[str] = None


class TestedJurisdictionsBuildResponseV2(BaseModel):
    tested_jurisdictions: List[TestedJurisdictionInputV2] = Field(default_factory=list)
    assignments: List[TestedJurisdictionsBuildAssignmentV2] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
# ---------------------------------------------------------------------------
# Module 16: Audit pack export + metadata endpoints (launch hardening)
# ---------------------------------------------------------------------------


class AuditPackOptionsV2(BaseModel):
    """Controls what files to include in the audit pack export.

    The backend remains stateless; the audit pack is generated from the request/response payload
    supplied by the client (Anything UI) and returned as a ZIP.
    """

    include_excel: bool = True
    include_pdf: bool = True
    include_json: bool = True

    include_trace: bool = True
    include_registers: bool = True

    max_trace_rows_per_tj: Optional[int] = Field(
        default=None,
        description="Optional cap on trace rows per Tested Jurisdiction in the Excel workbook. None means include all.",
    )

    filename_prefix: str = Field(
        default="simplified_etr_safe_harbour_audit_pack",
        description="Prefix used when generating the downloadable ZIP filename.",
    )


class AuditPackRequestV2(BaseModel):
    """Audit pack export request.

    The UI is expected to provide the last /api/v2/calc request and response.
    """

    request: CalculationRequestV2
    response: Optional[CalculationResponseV2] = None
    options: AuditPackOptionsV2 = Field(default_factory=AuditPackOptionsV2)


class EngineMetaV2(BaseModel):
    api_version: str = "v2"
    engine_version: str = "0.1.0"
    supported_schema_versions: List[str] = Field(default_factory=list)
    default_ruleset_version: str = "OECD_SBS_2026_01"
    git_commit: Optional[str] = None
    build_timestamp: Optional[str] = None

    # Module 17
    auth_enabled: bool = False
    api_key_header_name: Optional[str] = None
    storage_enabled: bool = True
    storage_backend: str = "sqlite"
    storage_location: Optional[str] = None

    @staticmethod
    def supported_schema_versions_default() -> List[str]:
        # Keep in sync with CalculationRequestV2.schema_version allowed values.
        return ["2.0", "2.1", "2.2", "2.3", "2.4", "2.5", "2.6", "2.7"]


class HealthResponseV2(BaseModel):
    status: str = "ok"


# ----------------------------
# Module 17: Tenant-safe storage-lite
# ----------------------------


class StoredScenarioCreateRequestV2(BaseModel):
    """Create a new stored scenario for the authenticated tenant."""

    scenario_id: Optional[str] = Field(
        default=None,
        description="Optional client-specified scenario id (UUID recommended). If omitted, server generates one.",
    )
    label: Optional[str] = Field(default=None, description="Human-friendly label.")
    description: Optional[str] = Field(default=None, description="Optional description.")
    tags: List[str] = Field(default_factory=list)
    draft_request: Optional[CalculationRequestV2] = Field(
        default=None,
        description="Optional draft request payload associated with this scenario.",
    )


class StoredScenarioUpdateRequestV2(BaseModel):
    label: Optional[str] = None
    description: Optional[str] = None
    tags: Optional[List[str]] = None
    draft_request: Optional[CalculationRequestV2] = None


class StoredScenarioRunCreateRequestV2(BaseModel):
    """Append a calculation run to a stored scenario."""

    run_id: Optional[str] = Field(
        default=None,
        description="Optional client-specified run id (UUID recommended). If omitted, server generates one.",
    )
    request: CalculationRequestV2
    response: CalculationResponseV2
    note: Optional[str] = None


class StoredScenarioSummaryV2(BaseModel):
    scenario_id: str
    label: Optional[str] = None
    description: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    created_at: str
    updated_at: str
    run_count: int = 0
    latest_fiscal_year_start: Optional[str] = None


class StoredScenarioRunSummaryV2(BaseModel):
    run_id: str
    fiscal_year_start: Optional[str] = None
    created_at: str
    note: Optional[str] = None


class StoredScenarioDetailV2(BaseModel):
    scenario_id: str
    label: Optional[str] = None
    description: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    created_at: str
    updated_at: str
    draft_request: Optional[CalculationRequestV2] = None
    latest_run: Optional[StoredScenarioRunSummaryV2] = None


class StoredScenarioRunDetailV2(BaseModel):
    scenario_id: str
    run_id: str
    fiscal_year_start: Optional[str] = None
    created_at: str
    note: Optional[str] = None
    request: CalculationRequestV2
    response: CalculationResponseV2


class StoredScenarioListResponseV2(BaseModel):
    scenarios: List[StoredScenarioSummaryV2] = Field(default_factory=list)
    limit: int = 50
    offset: int = 0


class StoredScenarioRunListResponseV2(BaseModel):
    scenario_id: str
    runs: List[StoredScenarioRunSummaryV2] = Field(default_factory=list)
    limit: int = 50
    offset: int = 0
