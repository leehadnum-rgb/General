from __future__ import annotations

import json
import os
import sqlite3
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from app.services.models_v2 import (
    CalculationRequestV2,
    CalculationResponseV2,
    StoredScenarioCreateRequestV2,
    StoredScenarioDetailV2,
    StoredScenarioListResponseV2,
    StoredScenarioRunCreateRequestV2,
    StoredScenarioRunDetailV2,
    StoredScenarioRunListResponseV2,
    StoredScenarioRunSummaryV2,
    StoredScenarioSummaryV2,
    StoredScenarioUpdateRequestV2,
)


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _data_dir() -> str:
    # Render containers always have a writable /tmp.
    return (os.getenv("DATA_DIR") or "/tmp/etr_safe_harbour").strip() or "/tmp/etr_safe_harbour"


def _db_path() -> str:
    p = os.getenv("STORAGE_DB_PATH")
    if p and p.strip():
        return p.strip()
    return os.path.join(_data_dir(), "storage.sqlite3")


def _ensure_dir(path: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)


def _connect() -> sqlite3.Connection:
    db = _db_path()
    _ensure_dir(db)
    conn = sqlite3.connect(db, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def _init(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS scenarios (
          scenario_id TEXT PRIMARY KEY,
          tenant_id TEXT NOT NULL,
          label TEXT,
          description TEXT,
          tags_json TEXT,
          draft_request_json TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_scenarios_tenant_updated
        ON scenarios(tenant_id, updated_at);
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS scenario_runs (
          run_id TEXT PRIMARY KEY,
          scenario_id TEXT NOT NULL,
          tenant_id TEXT NOT NULL,
          fiscal_year_start TEXT,
          request_json TEXT NOT NULL,
          response_json TEXT NOT NULL,
          note TEXT,
          created_at TEXT NOT NULL,
          FOREIGN KEY(scenario_id) REFERENCES scenarios(scenario_id)
        );
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_runs_tenant_scenario_created
        ON scenario_runs(tenant_id, scenario_id, created_at);
        """
    )
    conn.commit()


def _json_dumps(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"))


def _json_loads(s: Optional[str]) -> Any:
    if s is None:
        return None
    s = s.strip()
    if not s:
        return None
    return json.loads(s)


def _max_runs_per_scenario() -> int:
    v = (os.getenv("MAX_RUNS_PER_SCENARIO") or "50").strip()
    try:
        n = int(v)
        return max(1, min(500, n))
    except ValueError:
        return 50


def create_scenario(tenant_id: str, payload: StoredScenarioCreateRequestV2) -> StoredScenarioDetailV2:
    scenario_id = payload.scenario_id or str(uuid.uuid4())
    now = _now_iso()

    draft_json = None
    if payload.draft_request is not None:
        draft_json = _json_dumps(payload.draft_request.model_dump(mode="json"))

    with _connect() as conn:
        _init(conn)
        conn.execute(
            """
            INSERT INTO scenarios (scenario_id, tenant_id, label, description, tags_json, draft_request_json, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                scenario_id,
                tenant_id,
                payload.label,
                payload.description,
                _json_dumps(payload.tags or []),
                draft_json,
                now,
                now,
            ),
        )
        conn.commit()

    return get_scenario(tenant_id, scenario_id)


def list_scenarios(tenant_id: str, limit: int = 50, offset: int = 0) -> StoredScenarioListResponseV2:
    limit = max(1, min(200, int(limit)))
    offset = max(0, int(offset))

    with _connect() as conn:
        _init(conn)
        rows = conn.execute(
            """
            SELECT s.scenario_id, s.label, s.description, s.tags_json, s.created_at, s.updated_at,
              (SELECT COUNT(*) FROM scenario_runs r WHERE r.tenant_id = s.tenant_id AND r.scenario_id = s.scenario_id) AS run_count,
              (SELECT r.fiscal_year_start FROM scenario_runs r WHERE r.tenant_id = s.tenant_id AND r.scenario_id = s.scenario_id ORDER BY r.created_at DESC LIMIT 1) AS latest_fiscal_year_start
            FROM scenarios s
            WHERE s.tenant_id = ?
            ORDER BY s.updated_at DESC
            LIMIT ? OFFSET ?;
            """,
            (tenant_id, limit, offset),
        ).fetchall()

        scenarios: List[StoredScenarioSummaryV2] = []
        for r in rows:
            scenarios.append(
                StoredScenarioSummaryV2(
                    scenario_id=r["scenario_id"],
                    label=r["label"],
                    description=r["description"],
                    tags=_json_loads(r["tags_json"]) or [],
                    created_at=r["created_at"],
                    updated_at=r["updated_at"],
                    run_count=int(r["run_count"] or 0),
                    latest_fiscal_year_start=r["latest_fiscal_year_start"],
                )
            )
        return StoredScenarioListResponseV2(scenarios=scenarios, limit=limit, offset=offset)


def get_scenario(tenant_id: str, scenario_id: str) -> StoredScenarioDetailV2:
    with _connect() as conn:
        _init(conn)
        row = conn.execute(
            """
            SELECT scenario_id, tenant_id, label, description, tags_json, draft_request_json, created_at, updated_at
            FROM scenarios
            WHERE tenant_id = ? AND scenario_id = ?
            """,
            (tenant_id, scenario_id),
        ).fetchone()

        if row is None:
            raise ValueError("Scenario not found")

        draft = _json_loads(row["draft_request_json"])
        draft_req = CalculationRequestV2.model_validate(draft) if draft is not None else None

        latest_run = _get_latest_run_summary(conn, tenant_id, scenario_id)

        return StoredScenarioDetailV2(
            scenario_id=row["scenario_id"],
            label=row["label"],
            description=row["description"],
            tags=_json_loads(row["tags_json"]) or [],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            draft_request=draft_req,
            latest_run=latest_run,
        )


def update_scenario(tenant_id: str, scenario_id: str, payload: StoredScenarioUpdateRequestV2) -> StoredScenarioDetailV2:
    now = _now_iso()
    with _connect() as conn:
        _init(conn)
        # Ensure exists
        row = conn.execute(
            "SELECT scenario_id FROM scenarios WHERE tenant_id = ? AND scenario_id = ?",
            (tenant_id, scenario_id),
        ).fetchone()
        if row is None:
            raise ValueError("Scenario not found")

        draft_json = None
        if payload.draft_request is not None:
            draft_json = _json_dumps(payload.draft_request.model_dump(mode="json"))

        conn.execute(
            """
            UPDATE scenarios
            SET label = COALESCE(?, label),
                description = COALESCE(?, description),
                tags_json = COALESCE(?, tags_json),
                draft_request_json = COALESCE(?, draft_request_json),
                updated_at = ?
            WHERE tenant_id = ? AND scenario_id = ?
            """,
            (
                payload.label,
                payload.description,
                _json_dumps(payload.tags) if payload.tags is not None else None,
                draft_json,
                now,
                tenant_id,
                scenario_id,
            ),
        )
        conn.commit()

    return get_scenario(tenant_id, scenario_id)


def delete_scenario(tenant_id: str, scenario_id: str) -> None:
    with _connect() as conn:
        _init(conn)
        conn.execute(
            "DELETE FROM scenario_runs WHERE tenant_id = ? AND scenario_id = ?",
            (tenant_id, scenario_id),
        )
        cur = conn.execute(
            "DELETE FROM scenarios WHERE tenant_id = ? AND scenario_id = ?",
            (tenant_id, scenario_id),
        )
        conn.commit()
        if cur.rowcount == 0:
            raise ValueError("Scenario not found")


def create_run(tenant_id: str, scenario_id: str, payload: StoredScenarioRunCreateRequestV2) -> StoredScenarioRunDetailV2:
    run_id = payload.run_id or str(uuid.uuid4())
    now = _now_iso()

    req_json = _json_dumps(payload.request.model_dump(mode="json"))
    resp_json = _json_dumps(payload.response.model_dump(mode="json"))
    fy = payload.request.fiscal_year.start_date

    with _connect() as conn:
        _init(conn)
        # Ensure scenario belongs to tenant
        row = conn.execute(
            "SELECT scenario_id FROM scenarios WHERE tenant_id = ? AND scenario_id = ?",
            (tenant_id, scenario_id),
        ).fetchone()
        if row is None:
            raise ValueError("Scenario not found")

        conn.execute(
            """
            INSERT INTO scenario_runs (run_id, scenario_id, tenant_id, fiscal_year_start, request_json, response_json, note, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (run_id, scenario_id, tenant_id, str(fy), req_json, resp_json, payload.note, now),
        )
        conn.execute(
            "UPDATE scenarios SET updated_at = ? WHERE tenant_id = ? AND scenario_id = ?",
            (now, tenant_id, scenario_id),
        )
        conn.commit()

        _prune_runs(conn, tenant_id, scenario_id)

    return get_run(tenant_id, scenario_id, run_id)


def list_runs(tenant_id: str, scenario_id: str, limit: int = 50, offset: int = 0) -> StoredScenarioRunListResponseV2:
    limit = max(1, min(200, int(limit)))
    offset = max(0, int(offset))
    with _connect() as conn:
        _init(conn)
        _assert_scenario_exists(conn, tenant_id, scenario_id)

        rows = conn.execute(
            """
            SELECT run_id, fiscal_year_start, created_at, note
            FROM scenario_runs
            WHERE tenant_id = ? AND scenario_id = ?
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
            """,
            (tenant_id, scenario_id, limit, offset),
        ).fetchall()

        runs: List[StoredScenarioRunSummaryV2] = []
        for r in rows:
            runs.append(
                StoredScenarioRunSummaryV2(
                    run_id=r["run_id"],
                    fiscal_year_start=r["fiscal_year_start"],
                    created_at=r["created_at"],
                    note=r["note"],
                )
            )
        return StoredScenarioRunListResponseV2(
            scenario_id=scenario_id,
            runs=runs,
            limit=limit,
            offset=offset,
        )


def get_run(tenant_id: str, scenario_id: str, run_id: str) -> StoredScenarioRunDetailV2:
    with _connect() as conn:
        _init(conn)
        _assert_scenario_exists(conn, tenant_id, scenario_id)

        row = conn.execute(
            """
            SELECT run_id, fiscal_year_start, request_json, response_json, created_at, note
            FROM scenario_runs
            WHERE tenant_id = ? AND scenario_id = ? AND run_id = ?
            """,
            (tenant_id, scenario_id, run_id),
        ).fetchone()
        if row is None:
            raise ValueError("Run not found")

        req_obj = _json_loads(row["request_json"])
        resp_obj = _json_loads(row["response_json"])
        req = CalculationRequestV2.model_validate(req_obj)
        resp = CalculationResponseV2.model_validate(resp_obj)

        return StoredScenarioRunDetailV2(
            scenario_id=scenario_id,
            run_id=row["run_id"],
            fiscal_year_start=row["fiscal_year_start"],
            created_at=row["created_at"],
            note=row["note"],
            request=req,
            response=resp,
        )


def _assert_scenario_exists(conn: sqlite3.Connection, tenant_id: str, scenario_id: str) -> None:
    row = conn.execute(
        "SELECT scenario_id FROM scenarios WHERE tenant_id = ? AND scenario_id = ?",
        (tenant_id, scenario_id),
    ).fetchone()
    if row is None:
        raise ValueError("Scenario not found")


def _get_latest_run_summary(conn: sqlite3.Connection, tenant_id: str, scenario_id: str) -> Optional[StoredScenarioRunSummaryV2]:
    row = conn.execute(
        """
        SELECT run_id, fiscal_year_start, created_at, note
        FROM scenario_runs
        WHERE tenant_id = ? AND scenario_id = ?
        ORDER BY created_at DESC
        LIMIT 1
        """,
        (tenant_id, scenario_id),
    ).fetchone()
    if row is None:
        return None
    return StoredScenarioRunSummaryV2(
        run_id=row["run_id"],
        fiscal_year_start=row["fiscal_year_start"],
        created_at=row["created_at"],
        note=row["note"],
    )


def _prune_runs(conn: sqlite3.Connection, tenant_id: str, scenario_id: str) -> None:
    max_runs = _max_runs_per_scenario()
    rows = conn.execute(
        """
        SELECT run_id
        FROM scenario_runs
        WHERE tenant_id = ? AND scenario_id = ?
        ORDER BY created_at DESC
        """,
        (tenant_id, scenario_id),
    ).fetchall()
    if len(rows) <= max_runs:
        return

    # Delete oldest runs beyond max_runs
    to_delete = [r["run_id"] for r in rows[max_runs:]]
    conn.executemany(
        "DELETE FROM scenario_runs WHERE tenant_id = ? AND scenario_id = ? AND run_id = ?",
        [(tenant_id, scenario_id, rid) for rid in to_delete],
    )
    conn.commit()
