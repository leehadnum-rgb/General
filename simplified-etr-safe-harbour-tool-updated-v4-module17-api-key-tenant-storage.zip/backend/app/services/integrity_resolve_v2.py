from __future__ import annotations

"""Integrity 'Resolve helper' (v4 Module 10.1).

This module supports a guided UX for OECD Box 7.3 integrity warnings.

The core idea:
  - Certain integrity warnings can be *documented* (not necessarily numerically corrected)
    by adding an IntegrityAdjustmentV2 row with resolves_issue_code=<issue code>.
  - The calculator will then downgrade that warning to 'info' for eligibility purposes,
    leaving a clear audit trail.

UIs (e.g., Anything.com) can use:
  - GET /api/v2/integrity/resolution-catalog
  - POST /api/v2/integrity/resolve-template

to offer a one-click "Resolve" action that inserts a draft IntegrityAdjustmentV2.
"""

import re
from typing import Dict, List

from app.services.models_v2 import (
    IntegrityAdjustmentV2,
    IntegrityResolutionCatalogItemV2,
    IntegrityResolveTemplateRequestV2,
    IntegrityResolveTemplateResponseV2,
)


# IMPORTANT: These codes must be kept consistent with calculator_v2._RESOLVABLE_INTEGRITY_CODES.
_CATALOG: List[IntegrityResolutionCatalogItemV2] = [
    IntegrityResolutionCatalogItemV2(
        code="MATCHING_INCOME_ALLOCATED_TAX_NOT_ALLOCATED",
        principle="MATCHING",
        default_kind="tax",
        title="Income allocated without matching tax (flow-through line)",
        guidance=(
            "If the tax consequence is genuinely not allocable (or is captured elsewhere), document the rationale and evidence. "
            "If taxes should move with the income, prefer fixing the flow-through allocation lines (tax_allocated_amount) rather than using an integrity adjustment."
        ),
    ),
    IntegrityResolutionCatalogItemV2(
        code="FULL_ALLOCATION_FLOW_THROUGH_ENTITY_NOT_FULLY_ALLOCATED",
        principle="FULL_ALLOCATION",
        default_kind="income",
        title="Flow-through / tax-transparent entity not fully allocated",
        guidance=(
            "If the entity is not fully allocated by design (e.g., retention, timing, or classification exception), document why. "
            "Otherwise, fix the allocation register so all income (and relevant taxes) are allocated to owners."
        ),
    ),
    IntegrityResolutionCatalogItemV2(
        code="MATCHING_TP_ASYMMETRIC_INCOME",
        principle="MATCHING",
        default_kind="income",
        title="Transfer pricing income asymmetry",
        guidance=(
            "If TP income is intentionally not symmetric (e.g., special cases or local treatment), document the reason and supporting workpaper. "
            "If unintended, update the TP register (seller/buyer income amounts) so the adjustment is symmetric."
        ),
    ),
    IntegrityResolutionCatalogItemV2(
        code="MATCHING_TP_ASYMMETRIC_TAX",
        principle="MATCHING",
        default_kind="tax",
        title="Transfer pricing tax asymmetry",
        guidance=(
            "If TP tax is intentionally not symmetric (e.g., different covered-tax treatment), document the reason and supporting workpaper. "
            "If unintended, update the TP register (seller/buyer tax amounts) so the adjustment is symmetric."
        ),
    ),
]

_CATALOG_BY_CODE: Dict[str, IntegrityResolutionCatalogItemV2] = {c.code: c for c in _CATALOG}


def get_resolution_catalog() -> List[IntegrityResolutionCatalogItemV2]:
    """Return the list of resolvable integrity codes and guidance."""

    return list(_CATALOG)


def build_integrity_resolve_template(payload: IntegrityResolveTemplateRequestV2) -> IntegrityResolveTemplateResponseV2:
    """Build a draft IntegrityAdjustmentV2 for a resolvable integrity warning."""

    code = str(payload.issue_code or "").strip()
    if not code:
        raise ValueError("issue_code is required.")
    if code not in _CATALOG_BY_CODE:
        raise ValueError(
            f"Integrity issue_code '{code}' is not supported by the Resolve helper. "
            "Only resolvable warning codes are supported."
        )

    cat = _CATALOG_BY_CODE[code]

    # Make a stable-but-readable adjustment_id suggestion.
    def _slug(s: str) -> str:
        s = re.sub(r"[^A-Za-z0-9_-]+", "_", s or "")
        return s.strip("_")[:40]

    adj_id = f"RESOLVE-{_slug(code)}"
    if payload.reference_id:
        adj_id = f"{adj_id}-{_slug(str(payload.reference_id))}"

    notes: List[str] = [
        "This draft integrity adjustment is intended as an audit-trail / documentation mechanism.",
        "If a numeric correction is required, prefer correcting the underlying register (allocations / TP / allocable tax items) and re-running.",
    ]

    # If user provided a custom note, keep it; else draft a default.
    default_note = (
        f"AUTO: Resolve integrity issue {code}. {cat.title}. "
        f"Provide evidence_ref and narrative justification."
    )
    if payload.reference_id:
        default_note += f" Reference: {payload.reference_id}."
    if payload.path:
        default_note += f" Path: {payload.path}."

    template = IntegrityAdjustmentV2(
        adjustment_id=adj_id,
        tested_jurisdiction_id=payload.tested_jurisdiction_id,
        principle=cat.principle,
        kind=cat.default_kind,
        amount=0.0,
        currency=(payload.currency.upper().strip() if payload.currency else None),
        amount_scale=(payload.amount_scale or "UNITS"),
        resolves_issue_code=code,
        evidence_ref=payload.evidence_ref,
        note=(payload.note or default_note),
    )

    return IntegrityResolveTemplateResponseV2(template=template, notes=notes)
