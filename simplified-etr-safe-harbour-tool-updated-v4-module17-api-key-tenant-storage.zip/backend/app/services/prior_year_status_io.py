from __future__ import annotations

import csv
import io
import re
from datetime import date
from typing import Dict, List, Optional

from pydantic import BaseModel, Field

from app.services.models_v2 import PriorYearStatusV2

_NUM_RE = re.compile(r"[^0-9eE+\-\.]")


def _norm_header(h: str) -> str:
    h = (h or "").strip().lower()
    h = re.sub(r"[\s\-]+", "_", h)
    return h


_ALIASES: Dict[str, str] = {
    "tj_id": "tested_jurisdiction_id",
    "tested_jurisdiction": "tested_jurisdiction_id",
    "fy_start": "fiscal_year_start",
    "fy": "fiscal_year_start",
    "regime_name": "specified_safe_harbour_name",
    "safe_harbour_name": "specified_safe_harbour_name",
    "topup_tax": "topup_tax_status",
    "top_up_tax_status": "topup_tax_status",
    "additional_current_topup_tax": "additional_current_topup_tax_for_prior_year",
}


def _parse_date(raw: str) -> Optional[date]:
    if raw is None:
        return None
    s = str(raw).strip()
    if s == "":
        return None
    try:
        return date.fromisoformat(s)
    except ValueError:
        return None


def _parse_bool(raw: str) -> Optional[bool]:
    if raw is None:
        return None
    s = str(raw).strip().lower()
    if s == "":
        return None
    if s in {"true", "t", "yes", "y", "1"}:
        return True
    if s in {"false", "f", "no", "n", "0"}:
        return False
    return None


class PriorYearStatusCsvIssue(BaseModel):
    severity: str = Field(..., description="'error' or 'warning'")
    row_number: int = Field(..., ge=1, description="1-indexed row number in the CSV (excluding header).")
    field: Optional[str] = None
    message: str


class PriorYearStatusCsvParseResult(BaseModel):
    prior_years_status: List[PriorYearStatusV2] = Field(default_factory=list)
    issues: List[PriorYearStatusCsvIssue] = Field(default_factory=list)
    detected_columns: List[str] = Field(default_factory=list)
    ignored_columns: List[str] = Field(default_factory=list)


def generate_prior_year_status_csv_template() -> bytes:
    headers = [
        "tested_jurisdiction_id",
        "fiscal_year_start",
        "regime",
        "topup_tax_status",
        "additional_current_topup_tax_for_prior_year",
        "specified_safe_harbour_name",
        "note",
    ]

    example = {
        "tested_jurisdiction_id": "US_MAIN",
        "fiscal_year_start": "2026-01-01",
        "regime": "FULL_GLOBE",
        "topup_tax_status": "NONE",
        "additional_current_topup_tax_for_prior_year": "false",
        "specified_safe_harbour_name": "",
        "note": "Example only",
    }

    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=headers)
    w.writeheader()
    w.writerow(example)
    return buf.getvalue().encode("utf-8")


def parse_prior_year_status_csv(contents: bytes) -> PriorYearStatusCsvParseResult:
    text = contents.decode("utf-8-sig", errors="replace")
    buf = io.StringIO(text)
    reader = csv.DictReader(buf)
    if reader.fieldnames is None:
        return PriorYearStatusCsvParseResult(
            prior_years_status=[],
            issues=[PriorYearStatusCsvIssue(severity="error", row_number=1, message="CSV is missing a header row.")],
        )

    raw_headers = list(reader.fieldnames)
    norm_to_raw: Dict[str, str] = {}
    for h in raw_headers:
        nh0 = _norm_header(h)
        nh = _ALIASES.get(nh0, nh0)
        if nh and nh not in norm_to_raw:
            norm_to_raw[nh] = h

    allowed = set(PriorYearStatusV2.model_fields.keys())
    ignored = [raw for nh, raw in norm_to_raw.items() if nh not in allowed]

    out = PriorYearStatusCsvParseResult(detected_columns=raw_headers, ignored_columns=ignored)

    for i, row in enumerate(reader, start=1):
        data: Dict[str, object] = {}

        def raw(field: str) -> Optional[str]:
            rkey = norm_to_raw.get(field)
            return row.get(rkey) if rkey else None

        tj_id = (raw("tested_jurisdiction_id") or "").strip()
        fy = _parse_date(raw("fiscal_year_start") or "")
        regime = (raw("regime") or "").strip() or "FULL_GLOBE"
        top = (raw("topup_tax_status") or "").strip() or "UNKNOWN"

        add_cur = _parse_bool(raw("additional_current_topup_tax_for_prior_year") or "")
        sh_name = (raw("specified_safe_harbour_name") or "").strip() or None
        note = (raw("note") or "").strip() or None

        if not tj_id:
            out.issues.append(PriorYearStatusCsvIssue(severity="error", row_number=i, field="tested_jurisdiction_id", message="Missing tested_jurisdiction_id."))
            continue
        if fy is None:
            out.issues.append(PriorYearStatusCsvIssue(severity="error", row_number=i, field="fiscal_year_start", message="Invalid or missing fiscal_year_start (expected YYYY-MM-DD)."))
            continue

        data["tested_jurisdiction_id"] = tj_id
        data["fiscal_year_start"] = fy
        data["regime"] = regime
        data["topup_tax_status"] = top
        if add_cur is not None:
            data["additional_current_topup_tax_for_prior_year"] = bool(add_cur)
        if sh_name is not None:
            data["specified_safe_harbour_name"] = sh_name
        if note is not None:
            data["note"] = note

        try:
            out.prior_years_status.append(PriorYearStatusV2(**data))
        except Exception as e:
            out.issues.append(PriorYearStatusCsvIssue(severity="error", row_number=i, message=str(e)))

    return out
