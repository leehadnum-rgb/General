from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Dict, Any, Optional, List, Tuple, Set

from app.services.models import CalculationRequest as CalculationRequestV1
from app.services.models import JurisdictionInput as JurisdictionInputV1
from app.services.models import EntityInput as EntityInputV1
from app.services.models import TraceLine, ElectionRecord

from app.services.calculator import calculate as calculate_v1
from app.services.election_catalog import ELECTIONS_BY_CODE
from app.services.elections_v2 import (
    resolve_effective_elections,
    apply_effective_elections_to_meta,
    get_effective_election_amount,
    get_effective_election_bool,
)
from app.services.entry_reentry_v2 import evaluate_entry_reentry

from app.services.models_v2 import (
    CalculationRequestV2,
    CalculationResponseV2,
    TestedJurisdictionResultV2,
    EntryReentryStatusV2,
    CarryforwardBalanceV2,
    CarryforwardMovementV2,
    TestedJurisdictionInputV2,
    CrossBorderTaxItemV2,
    AmountScale,
    TransitionYearStateV2,
    TransitionDeferredTaxRegisterItemV2,
    AfterYearEndAdjustmentV2,
    TransferPricingAdjustmentV2,
    ElectionInstanceV2,
    AllocationLedgerEntryV2,
    FlowThroughEntityAllocationV2,
    AllocableTaxItemV2,
    PEAllocationLineV2,
    PESimplificationStateItemV2,
    DDTRecaptureAccountStateV2,
    DDTRecaptureAccountMovementV2,
    PermanentEstablishmentV2,
    IntegrityAdjustmentV2,
    IntegrityAssessmentV2,
    IntegrityIssueV2,
)



def _scale_multiplier(scale: Optional[AmountScale]) -> float:
    if not scale or scale == "UNITS":
        return 1.0
    if scale == "THOUSANDS":
        return 1000.0
    if scale == "MILLIONS":
        return 1000000.0
    return 1.0


def _convert_nested_amounts(obj: Any, *, multiplier: float, skip_keys: set[str]) -> Any:
    """Recursively multiply numeric values by multiplier.

    Used for amount scale + currency translation pre-processing.
    Conservative rules:
      - booleans are not modified
      - keys in skip_keys are not modified (e.g., accounted_tax_rate)
    """

    if obj is None:
        return None
    if isinstance(obj, bool):
        return obj
    if isinstance(obj, (int, float)):
        return float(obj) * multiplier
    if isinstance(obj, list):
        return [_convert_nested_amounts(v, multiplier=multiplier, skip_keys=skip_keys) for v in obj]
    if isinstance(obj, dict):
        out: dict[str, Any] = {}
        for k, v in obj.items():
            if k in skip_keys:
                out[k] = v
            else:
                out[k] = _convert_nested_amounts(v, multiplier=multiplier, skip_keys=skip_keys)
        return out
    return obj


def _fx_lookup_avg(req: CalculationRequestV2, currency: str, fy_start: date) -> Optional[float]:
    """Find average FX rate (P&L translation convention).

    Matching priority:
      1) exact currency + fiscal_year_start
      2) currency + fiscal_year_start=None (default)
    """

    cur = (currency or "").upper().strip()
    if not cur:
        return None
    for r in (req.fx_rates or []):
        if (r.currency or "").upper().strip() == cur and r.fiscal_year_start == fy_start:
            return float(r.avg_rate_to_reporting)
    for r in (req.fx_rates or []):
        if (r.currency or "").upper().strip() == cur and r.fiscal_year_start is None:
            return float(r.avg_rate_to_reporting)
    return None


def _fx_lookup_spot(req: CalculationRequestV2, currency: str, fy_start: date) -> Optional[float]:
    """Find spot/closing FX rate (balance sheet translation convention).

    Matching priority matches average FX lookup.
    """

    cur = (currency or "").upper().strip()
    if not cur:
        return None
    for r in (req.fx_rates or []):
        if (r.currency or "").upper().strip() == cur and r.fiscal_year_start == fy_start:
            return float(r.spot_rate_to_reporting) if r.spot_rate_to_reporting is not None else None
    for r in (req.fx_rates or []):
        if (r.currency or "").upper().strip() == cur and r.fiscal_year_start is None:
            return float(r.spot_rate_to_reporting) if r.spot_rate_to_reporting is not None else None
    return None

def _convert_amount_fx(
    req: CalculationRequestV2,
    *,
    amount: float,
    currency: Optional[str],
    amount_scale: Optional[str],
    reporting_currency: Optional[str],
    fy_start: date,
    use_spot: bool,
) -> tuple[float, Optional[str]]:
    """Convert an amount into reporting currency, applying scaling and FX.

    Returns (converted_amount, note) where note describes any fallback behaviour.

    FX conventions:
      - use_spot=True -> spot/closing FX (balance sheet translation)
      - use_spot=False -> average FX (P&L translation)
    """

    mult = _scale_multiplier(amount_scale)
    amt = float(amount) * float(mult)

    if not (reporting_currency and currency):
        return float(amt), None

    cur = str(currency).upper().strip() or None
    rep = str(reporting_currency).upper().strip() or None
    if not cur or not rep or cur == rep:
        return float(amt), None

    note = None
    if use_spot:
        fx = _fx_lookup_spot(req, cur, fy_start)
        if fx is None:
            fx2 = _fx_lookup_avg(req, cur, fy_start)
            if fx2 is None:
                raise ValueError(
                    f"Missing FX rate for currency '{cur}' to reporting currency '{rep}' for FY start {fy_start}. "
                    "Provide request.fx_rates with avg_rate_to_reporting (and optionally spot_rate_to_reporting)."
                )
            fx = fx2
            note = f"Spot FX missing for {cur}; used avg FX {fx2} as fallback."
        return float(amt) * float(fx), note

    fx = _fx_lookup_avg(req, cur, fy_start)
    if fx is None:
        raise ValueError(
            f"Missing FX rate for currency '{cur}' to reporting currency '{rep}' for FY start {fy_start}. "
            "Provide request.fx_rates with avg_rate_to_reporting."
        )
    return float(amt) * float(fx), note



@dataclass
class _TJWork:
    tj: TestedJurisdictionInputV2
    bucket_id: str
    reporting_currency: Optional[str]
    input_currency: Optional[str]
    fx_rate_avg: float
    fx_rate_spot: float
    amount_scale: Optional[str]
    currency_multiplier_pl: float
    currency_multiplier_bs: float
    spot_rate_provided: bool
    effective_elections: list
    eligible: bool
    ineligibility_reasons: list[str]
    election_records: list
    trace: list[TraceLine]
    simplified_income: float
    simplified_taxes: float
    opening_balances: list[CarryforwardBalanceV2]

    # Section 5.1 allocation audit (pre carryforwards)
    simplified_income_pre_allocations: Optional[float] = None
    simplified_taxes_pre_allocations: Optional[float] = None
    simplified_income_post_allocations: Optional[float] = None
    simplified_taxes_post_allocations: Optional[float] = None
    allocation_ledger: list[AllocationLedgerEntryV2] = None
    allocation_warnings: list[str] = None

    # Integrity assessment (Box 7.3) (v4 module 10)
    integrity_assessment: Optional[IntegrityAssessmentV2] = None

    # Transition Year derived context / state
    transition_year_fy_start: Optional[date] = None
    is_transition_year: Optional[bool] = None
    transition_year_state_closing: Optional[TransitionYearStateV2] = None

    # Box 7.2 entry/re-entry computed status (v4 module 8)
    entry_reentry_status: Optional[EntryReentryStatusV2] = None


def _convert_carryforwards(
    req: CalculationRequestV2,
    opening: list[CarryforwardBalanceV2],
    *,
    reporting_currency: Optional[str],
    input_currency: Optional[str],
    scale_multiplier: float,
    fy_start: date,
) -> tuple[list[CarryforwardBalanceV2], list[TraceLine]]:
    """Convert carryforward balances into reporting currency (and apply amount scale).

    v4 module 3 enhancement:
    - If a carryforward balance includes origin_fiscal_year_start, translate that balance using
      the average FX rate for the origin fiscal year (if available).
    - Otherwise translate using the current fiscal year's average FX rate.

    This is a pragmatic approximation of the OECD requirement that currency translation rules apply.
    """

    if not opening:
        return [], []

    needs_fx = bool(reporting_currency and input_currency and input_currency != reporting_currency)
    input_currency_u = (input_currency or "").upper().strip() or None

    out: list[CarryforwardBalanceV2] = []
    trace: list[TraceLine] = []

    used_origin_years: list[str] = []
    fx_fallbacks: list[str] = []

    for b in (opening or []):
        origin_fy = b.origin_fiscal_year_start or fy_start
        fx_avg = 1.0
        if needs_fx:
            r = _fx_lookup_avg(req, input_currency_u, origin_fy)
            if r is None:
                # Fallback to current FY rate if origin-year rate is not provided
                r2 = _fx_lookup_avg(req, input_currency_u, fy_start)
                if r2 is None:
                    raise ValueError(
                        f"Missing FX rate for currency '{input_currency_u}' to reporting currency '{reporting_currency}' for carryforward translation. "
                        f"Provide request.fx_rates with avg_rate_to_reporting (currency={input_currency_u})."
                    )
                fx_avg = float(r2)
                if b.origin_fiscal_year_start is not None and b.origin_fiscal_year_start != fy_start:
                    fx_fallbacks.append(f"{b.kind}@{b.origin_fiscal_year_start}")
            else:
                fx_avg = float(r)

        mult = float(scale_multiplier) * float(fx_avg)
        if mult == 1.0:
            out.append(b.model_copy())
            continue

        updates: dict[str, Any] = {"amount": float(b.amount) * mult}
        if b.remaining_amount is not None:
            updates["remaining_amount"] = float(b.remaining_amount) * mult
        out.append(b.model_copy(update=updates))

        if b.origin_fiscal_year_start is not None and b.origin_fiscal_year_start != fy_start:
            used_origin_years.append(f"{b.kind}@{b.origin_fiscal_year_start}")

    if used_origin_years:
        trace.append(
            TraceLine(
                section="eligibility",
                step="Carryforward translated using origin-year FX",
                amount=0.0,
                note=(
                    f"Applied avg FX translation for carryforward balances using their origin_fiscal_year_start where provided. "
                    f"Examples: {', '.join(used_origin_years[:6])}" + ("" if len(used_origin_years) <= 6 else f" (+{len(used_origin_years)-6} more)")
                ),
            )
        )

    if fx_fallbacks:
        trace.append(
            TraceLine(
                section="eligibility",
                step="Carryforward FX fallback used",
                amount=0.0,
                note=(
                    "No origin-year FX rate was provided for some carryforward balances; the current fiscal year's avg FX rate was used as a fallback. "
                    f"Examples: {', '.join(fx_fallbacks[:6])}" + ("" if len(fx_fallbacks) <= 6 else f" (+{len(fx_fallbacks)-6} more)")
                ),
            )
        )

    return out, trace


def _build_meta_row(
    tj: TestedJurisdictionInputV2,
    bucket_id: str,
    fy_start: date,
    *,
    currency_multiplier_pl: float,
    reporting_currency: Optional[str],
    input_currency: Optional[str],
    fx_rate_avg: float,
    fx_rate_spot: float,
    spot_rate_provided: bool,
    amount_scale: Optional[str],
    entry_no_topup_override: Optional[bool] = None,
    reentry_no_topup_override: Optional[bool] = None,
) -> tuple[JurisdictionInputV1, list, list[TraceLine], list[TraceLine]]:
    """Build a v1 JurisdictionInput row used as calculation row (jurisdiction mode)
    or as 'meta' row (entity roll-up mode)."""

    conversion_trace: list[TraceLine] = []

    if reporting_currency and input_currency and input_currency != reporting_currency and fx_rate_avg != 1.0:
        conversion_trace.append(
            TraceLine(
                section="eligibility",
                step="Currency translated to reporting currency",
                amount=0.0,
                note=(
                    f"{input_currency} -> {reporting_currency} at avg FX rate {fx_rate_avg} (P&L). "
                    + (
                        f"Spot FX rate {fx_rate_spot} (balance sheet)."
                        if spot_rate_provided
                        else "Spot FX rate not provided; avg used as fallback for balance sheet items."
                    )
                ),
            )
        )
    if amount_scale and amount_scale != "UNITS" and currency_multiplier_pl != 1.0:
        conversion_trace.append(
            TraceLine(
                section="eligibility",
                step="Amount scale normalised",
                amount=0.0,
                note=f"Input scale={amount_scale}. Amounts multiplied by {_scale_multiplier(amount_scale)} before FX.",
            )
        )

    if tj.facts is not None:
        data = tj.facts.model_dump()
        # Apply amount scale + FX conversion to monetary fields
        if currency_multiplier_pl != 1.0:
            data = _convert_nested_amounts(data, multiplier=currency_multiplier_pl, skip_keys={"accounted_tax_rate"})
        # v2 uses tested_jurisdiction_id as the internal key (bucket)
        data["jurisdiction_code"] = bucket_id
        meta = JurisdictionInputV1(**data)
    else:
        # For entity roll-up, a minimal meta row is still useful to carry elections and eligibility flags.
        meta = JurisdictionInputV1(jurisdiction_code=bucket_id, jpbt=0.0)

    # Eligibility flags from v2
    ei = tj.eligibility_inputs
    meta.ineligible_stateless = bool(ei.ineligible_stateless)
    meta.ineligible_investment_entity = bool(ei.ineligible_investment_entity)
    meta.ineligible_article7_3_outstanding_recapture = bool(ei.ineligible_article7_3_outstanding_recapture)
    meta.stateless_exception_section_6_2_applies = bool(ei.stateless_exception_section_6_2_applies)
    meta.investment_entity_tax_transparency_election_applies = bool(ei.investment_entity_tax_transparency_election_applies)
    meta.no_topup_tax_in_prior_24_months = bool(ei.no_topup_tax_in_prior_24_months)
    meta.reentry_no_topup_tax_in_prior_24_months = ei.reentry_no_topup_tax_in_prior_24_months

    # Box 7.2 automated overrides (v4 module 8)
    if entry_no_topup_override is not None:
        meta.no_topup_tax_in_prior_24_months = bool(entry_no_topup_override)
    if reentry_no_topup_override is not None:
        meta.reentry_no_topup_tax_in_prior_24_months = bool(reentry_no_topup_override)
    meta.integrity_rules_satisfied = bool(ei.integrity_rules_satisfied)

    # Resolve and apply elections for this FY
    effective = resolve_effective_elections(tj.elections, fy_start)

    # Convert amount-valued elections into reporting currency so they line up with translated facts.
    if currency_multiplier_pl != 1.0:
        converted_effective = []
        for e in effective:
            if getattr(e, "action", "ELECT") == "REVOKE":
                converted_effective.append(e)
                continue
            if getattr(e, "value_type", None) == "amount" and getattr(e, "amount", None) is not None:
                converted_effective.append(e.model_copy(update={"amount": float(e.amount) * currency_multiplier_pl}))
            else:
                converted_effective.append(e)
        effective = converted_effective
    meta, election_trace = apply_effective_elections_to_meta(meta, effective)

    return meta, effective, election_trace, conversion_trace


def _build_entities(
    tj: TestedJurisdictionInputV2,
    bucket_id: str,
    *,
    currency_multiplier_pl: float,
    deemed_zero_qp_threshold: float = 0.9999,
) -> list[EntityInputV1]:
    """Build v1 EntityInput rows from v2 entity facts.

    v4 Module 7 note:
      - For TAX_NEUTRAL_UPE entities held entirely by Qualified Persons (>= threshold),
        Section 6.1 provides that Simplified Income and Simplified Taxes are deemed to be zero.
        Practically, we zero out the entity's monetary fields when building the v1 roll-up inputs,
        so the TJ baseline reflects the deeming without requiring a separate manual override.
    """
    ents: list[EntityInputV1] = []
    allowed = set(EntityInputV1.model_fields.keys())
    for e in tj.entities:
        data = e.model_dump()
        if currency_multiplier_pl != 1.0:
            data = _convert_nested_amounts(data, multiplier=currency_multiplier_pl, skip_keys={"accounted_tax_rate"})

        # Override group key to v2 tested_jurisdiction_id bucket
        data["jurisdiction_code"] = bucket_id

        # Section 6.1 Tax-Neutral UPE deeming (entity-level)
        et = getattr(e, "entity_type", None)
        qp = getattr(e, "qualified_persons_ownership_percentage", None)
        if et == "TAX_NEUTRAL_UPE" and qp is not None and float(qp) >= float(deemed_zero_qp_threshold):
            for k, v in list(data.items()):
                if k in {"entity_id", "entity_name", "jurisdiction_code"}:
                    continue
                if isinstance(v, (int, float)) and k != "accounted_tax_rate":
                    data[k] = 0.0

        # Filter to v1 model fields (ignore v2-only fields like entity_type)
        filtered = {k: data.get(k) for k in allowed if k in data}
        ents.append(EntityInputV1(**filtered))
    return ents

def _normalise_balances(opening: list[CarryforwardBalanceV2]) -> list[CarryforwardBalanceV2]:
    # Ensure positive amounts and defaults are applied (Pydantic validator already does this).
    out: list[CarryforwardBalanceV2] = []
    for b in opening:
        out.append(b.model_copy())
    return out


def _apply_carryforwards(
    *,
    fy_start: date,
    minimum_rate: float,
    simplified_income: float,
    simplified_taxes: float,
    opening: list[CarryforwardBalanceV2],
    effective_elections: list,
    trace: list[TraceLine],
) -> tuple[float, list[CarryforwardBalanceV2], list[CarryforwardMovementV2]]:
    """Apply carryforwards to Simplified Taxes (OECD Box 4.3 and Article 4.1.5 symmetry).

    Implementation notes (pragmatic):
    - Carryforward balances are entered as POSITIVE amounts representing a reduction to Simplified Taxes.
    - Utilisation is only applied in years with positive Simplified Income and positive Simplified Taxes,
      consistent with typical utilisation mechanics for Excess Negative Tax carry-forwards.
    - Tax is not reduced below zero.
    - Loss DTA Adjustment utilisation can optionally be capped by LOSS_DTA_REVERSAL_TENTATIVE_AMOUNT.
    """

    taxes = float(simplified_taxes)
    balances = _normalise_balances(opening)
    moves: list[CarryforwardMovementV2] = []

    if simplified_income <= 0 or taxes <= 0:
        return taxes, balances, moves

    # Optional cap for Loss DTA Adjustment utilisation
    loss_dta_reversal_cap = get_effective_election_amount(effective_elections, "LOSS_DTA_REVERSAL_TENTATIVE_AMOUNT")
    if loss_dta_reversal_cap is not None:
        loss_dta_reversal_cap = max(0.0, float(loss_dta_reversal_cap))

    def use_balance(kind: str, cap_amount: float | None = None, note: str | None = None):
        nonlocal taxes, balances, moves, loss_dta_reversal_cap

        for b in balances:
            if b.kind != kind:
                continue
            if taxes <= 0:
                break
            if (b.remaining_amount or 0.0) <= 0:
                continue

            cap = taxes
            if cap_amount is not None:
                cap = min(cap, cap_amount)
            used = min(float(b.remaining_amount or 0.0), cap)

            if used <= 0:
                continue

            taxes = max(0.0, taxes - used)
            b.remaining_amount = max(0.0, float(b.remaining_amount or 0.0) - used)

            if kind == "LOSS_DTA_ADJUSTMENT" and loss_dta_reversal_cap is not None:
                loss_dta_reversal_cap = max(0.0, loss_dta_reversal_cap - used)

            moves.append(
                CarryforwardMovementV2(
                    kind=kind, used_amount=float(used), remaining_amount=float(b.remaining_amount or 0.0), note=note
                )
            )
            trace.append(
                TraceLine(
                    section="tax",
                    step=f"Carryforward utilised: {kind}",
                    amount=-float(used),
                    running_total=taxes,
                    note=note,
                )
            )

    # Order (pragmatic):
    #   1) Loss DTA Adjustment (alternative method; can be capped)
    #   2) Simplified negative tax adjustment (Box 4.3)
    #   3) Excess negative tax carry-forward (GloBE Article 4.1.5)
    if loss_dta_reversal_cap is not None and loss_dta_reversal_cap > 0:
        use_balance(
            "LOSS_DTA_ADJUSTMENT",
            cap_amount=loss_dta_reversal_cap,
            note="Capped by LOSS_DTA_REVERSAL_TENTATIVE_AMOUNT; taxes not reduced below zero.",
        )
    else:
        use_balance(
            "LOSS_DTA_ADJUSTMENT",
            cap_amount=None,
            note="No loss DTA reversal cap provided; taxes not reduced below zero.",
        )

    use_balance(
        "SIMPLIFIED_NEGATIVE_TAX_ADJUSTMENT",
        cap_amount=None,
        note="Applied as a reduction to Simplified Taxes; taxes not reduced below zero.",
    )
    use_balance(
        "EXCESS_NEGATIVE_TAX_CARRYFORWARD",
        cap_amount=None,
        note="Applied as a reduction to Simplified Taxes; taxes not reduced below zero.",
    )

    return taxes, balances, moves
def _apply_owner_addbacks(work: _TJWork) -> None:
    """Apply structured owner addbacks (Articles 7.5/7.6).

    These are treated as signed adjustments to Simplified Income or Simplified Taxes.
    """

    for a in (work.tj.owner_addbacks or []):
        amt = float(a.amount) * float(work.currency_multiplier_pl or 1.0)
        if a.kind == "income":
            work.simplified_income += amt
            work.trace.append(
                TraceLine(
                    section="income",
                    step=f"Investment entity owner addback (Art {a.article})",
                    amount=float(amt),
                    running_total=float(work.simplified_income),
                    note=a.label + (f" | {a.note}" if a.note else ""),
                )
            )
        else:
            work.simplified_taxes += amt
            work.trace.append(
                TraceLine(
                    section="tax",
                    step=f"Investment entity owner addback (Art {a.article})",
                    amount=float(amt),
                    running_total=float(work.simplified_taxes),
                    note=a.label + (f" | {a.note}" if a.note else ""),
                )
            )


def _apply_cross_border_tax_items(
    works: Dict[str, _TJWork],
    items: list[CrossBorderTaxItemV2],
    fy_start: date,
) -> None:
    """Apply cross-border tax item exclusion/allocation adjustments.

    The adjustments are applied after base Simplified Taxes have been computed, but before
    carryforwards, so they affect Simplified ETR.
    """

    if not items:
        return

    # Helper: check deemed-zero conflicts
    deemed_zero_ids = {k for k, w in works.items() if w.tj.deemed_zero_rules.apply_deemed_zero}

    for item in items:
        src = item.source_tested_jurisdiction_id
        tgt = item.target_tested_jurisdiction_id

        # Validate IDs
        if src and src not in works:
            raise ValueError(f"Cross-border tax item '{item.label or item.item_id or ''}': source_tested_jurisdiction_id '{src}' not found.")
        if tgt and tgt not in works:
            raise ValueError(f"Cross-border tax item '{item.label or item.item_id or ''}': target_tested_jurisdiction_id '{tgt}' not found.")

        if src in deemed_zero_ids or tgt in deemed_zero_ids:
            raise ValueError(
                "Cross-border tax items cannot reference a Tested Jurisdiction where deemed-zero is applied. "
                f"(item={item.label or item.item_id or 'unnamed'}, source={src}, target={tgt})"
            )

        amount = float(item.amount)

        # Infer default treatment if not provided
        treatment = item.treatment
        if not treatment:
            if tgt:
                treatment = "ALLOCATE"
            else:
                keep = False
                if src:
                    keep = bool(get_effective_election_bool(works[src].effective_elections, "CROSS_BORDER_FIVE_YEAR_ELECTION_KEEP_ALLOCABLE_TAXES") or False)
                treatment = "KEEP_IN_SOURCE" if keep else "EXCLUDE_FROM_ALL"

        # PE election enforcement (if requested)
        if getattr(item, "requires_pe_simplification_election", False):
            pe_ok = False
            if src and bool(get_effective_election_bool(works[src].effective_elections, "PE_SIMPLIFICATION_ELECTION_NOTE") or False):
                pe_ok = True
            if tgt and bool(get_effective_election_bool(works[tgt].effective_elections, "PE_SIMPLIFICATION_ELECTION_NOTE") or False):
                pe_ok = True
            if not pe_ok:
                raise ValueError(
                    "Cross-border tax item requires PE simplification election, but PE_SIMPLIFICATION_ELECTION_NOTE is not effective "
                    f"for source/target Tested Jurisdiction(s). (item={item.label or item.item_id or 'unnamed'})"
                )

        label = item.label or item.item_id or "Cross-border tax item"
        note = item.note

        if treatment == "KEEP_IN_SOURCE":
            if src:
                works[src].trace.append(
                    TraceLine(
                        section="tax",
                        step="Cross-border tax item kept in source",
                        amount=0.0,
                        running_total=float(works[src].simplified_taxes),
                        note=f"{label}" + (f" | {note}" if note else ""),
                    )
                )
            continue

        if treatment == "EXCLUDE_FROM_ALL":
            if not src:
                # nothing to exclude if no source provided
                continue
            w = works[src]
            w.simplified_taxes -= amount
            w.trace.append(
                TraceLine(
                    section="tax",
                    step="Cross-border tax excluded (allocable tax removed)",
                    amount=-amount,
                    running_total=float(w.simplified_taxes),
                    note=f"{label}" + (f" | {note}" if note else ""),
                )
            )
            continue

        if treatment == "ALLOCATE":
            if tgt is None:
                raise ValueError(f"Cross-border tax item '{label}': treatment='ALLOCATE' requires target_tested_jurisdiction_id.")

            if src:
                ws = works[src]
                ws.simplified_taxes -= amount
                ws.trace.append(
                    TraceLine(
                        section="tax",
                        step="Cross-border tax allocated out of source",
                        amount=-amount,
                        running_total=float(ws.simplified_taxes),
                        note=f"{label} -> {tgt}" + (f" | {note}" if note else ""),
                    )
                )

            wt = works[tgt]
            wt.simplified_taxes += amount
            wt.trace.append(
                TraceLine(
                    section="tax",
                    step="Cross-border tax allocated into target",
                    amount=amount,
                    running_total=float(wt.simplified_taxes),
                    note=f"{label} (from {src or 'external'})" + (f" | {note}" if note else ""),
                )
            )
            continue

        raise ValueError(f"Cross-border tax item '{label}': unknown treatment '{treatment}'.")



# ---------------------------------------------------------------------------
# Integrity rules (OECD Box 7.3) (v4 module 10)
# ---------------------------------------------------------------------------

# Some integrity issues can be addressed by a documented integrity adjustment.
# For these codes, providing an IntegrityAdjustmentV2 with resolves_issue_code=<code>
# will downgrade the issue to 'info' for eligibility purposes (audit trail).
_RESOLVABLE_INTEGRITY_CODES: Set[str] = {
    "MATCHING_INCOME_ALLOCATED_TAX_NOT_ALLOCATED",
    "FULL_ALLOCATION_FLOW_THROUGH_ENTITY_NOT_FULLY_ALLOCATED",
    "MATCHING_TP_ASYMMETRIC_INCOME",
    "MATCHING_TP_ASYMMETRIC_TAX",
}


# v4 Module 10.1 (Resolve helper): short UI guidance for resolvable codes.
_INTEGRITY_RESOLVE_HINTS: Dict[str, Tuple[str, str]] = {
    "MATCHING_INCOME_ALLOCATED_TAX_NOT_ALLOCATED": (
        "tax",
        "Document why no taxes are allocated with the income (or correct the flow-through allocation line to allocate taxes).",
    ),
    "FULL_ALLOCATION_FLOW_THROUGH_ENTITY_NOT_FULLY_ALLOCATED": (
        "income",
        "Document why the entity is not fully allocated (or correct the flow-through allocation register so all income is allocated to owners).",
    ),
    "MATCHING_TP_ASYMMETRIC_INCOME": (
        "income",
        "Document why TP income is not symmetric (or correct the TP register so seller+buyer income adjustments net to zero).",
    ),
    "MATCHING_TP_ASYMMETRIC_TAX": (
        "tax",
        "Document why TP taxes are not symmetric (or correct the TP register so seller+buyer tax adjustments net to zero).",
    ),
}


def _apply_integrity_adjustments(
    works: Dict[str, _TJWork],
    req: CalculationRequestV2,
    *,
    fy_start: date,
    reporting_currency: Optional[str],
) -> None:
    """Apply IntegrityAdjustmentV2 register entries (Box 7.3) prior to final ETR/safe-harbour tests."""

    adjustments: List[IntegrityAdjustmentV2] = list(getattr(req, "integrity_adjustments", None) or [])
    if not adjustments:
        return

    for adj in adjustments:
        tj_id = adj.tested_jurisdiction_id
        if tj_id not in works:
            raise ValueError(f"IntegrityAdjustmentV2 references unknown tested_jurisdiction_id '{tj_id}'.")
        w = works[tj_id]

        default_currency = adj.currency or w.input_currency or reporting_currency
        amt_conv, fx_note = _convert_amount_with_fx(
            req,
            amount=float(adj.amount),
            currency=default_currency,
            amount_scale=getattr(adj, "amount_scale", "UNITS"),
            fy_start=fy_start,
            reporting_currency=reporting_currency,
            use_spot=False,
        )

        label = adj.adjustment_id or "Integrity adjustment"
        note_bits: list[str] = []
        if adj.principle:
            note_bits.append(f"principle={adj.principle}")
        if adj.resolves_issue_code:
            note_bits.append(f"resolves={adj.resolves_issue_code}")
        if adj.evidence_ref:
            note_bits.append(f"evidence={adj.evidence_ref}")
        if fx_note:
            note_bits.append(fx_note)
        if adj.note:
            note_bits.append(str(adj.note))

        note = " | ".join([b for b in note_bits if b]) or None

        if adj.kind == "income":
            w.simplified_income += float(amt_conv)
            w.trace.append(
                TraceLine(
                    section="income",
                    step="Integrity adjustment applied (Box 7.3)",
                    amount=float(amt_conv),
                    running_total=float(w.simplified_income),
                    note=f"{label}" + (f" | {note}" if note else ""),
                )
            )
        else:
            w.simplified_taxes += float(amt_conv)
            w.trace.append(
                TraceLine(
                    section="tax",
                    step="Integrity adjustment applied (Box 7.3)",
                    amount=float(amt_conv),
                    running_total=float(w.simplified_taxes),
                    note=f"{label}" + (f" | {note}" if note else ""),
                )
            )


def _assess_integrity_box_7_3(
    works: Dict[str, _TJWork],
    req: CalculationRequestV2,
    *,
    fy_start: date,
    reporting_currency: Optional[str],
) -> None:
    """Run pragmatic integrity checks aligned to OECD Box 7.3.

    This is not a full audit engine. It focuses on deterministic checks that can be inferred from
    the structured registers (allocations, allocable tax items, TP register) and entity classification.
    """

    opts = getattr(req, "integrity_automation", None)
    if opts is None or not bool(getattr(opts, "enable_integrity_checks", True)):
        return

    tol = float(getattr(opts, "tolerance", 1e-6) or 0.0)

    # Build resolution mapping from integrity adjustments
    resolutions_by_tj: Dict[str, Set[str]] = {}
    for adj in (getattr(req, "integrity_adjustments", None) or []):
        if not getattr(adj, "resolves_issue_code", None):
            continue
        resolutions_by_tj.setdefault(adj.tested_jurisdiction_id, set()).add(str(adj.resolves_issue_code))

    issues_by_tj: Dict[str, List[IntegrityIssueV2]] = {tid: [] for tid in works.keys()}

    def _add_issue(
        *,
        tj_ids: List[str],
        severity: str,
        principle: str,
        code: str,
        message: str,
        reference_id: Optional[str] = None,
        path: Optional[str] = None,
    ) -> None:
        for tid in tj_ids:
            if tid not in issues_by_tj:
                continue
            resolvable = code in _RESOLVABLE_INTEGRITY_CODES
            hint = _INTEGRITY_RESOLVE_HINTS.get(code)
            issues_by_tj[tid].append(
                IntegrityIssueV2(
                    severity=severity,
                    principle=principle,
                    code=code,
                    message=message,
                    tested_jurisdiction_id=tid,
                    reference_id=reference_id,
                    path=path,
                    resolvable=bool(resolvable),
                    resolution_default_kind=(hint[0] if hint else None),
                    resolution_guidance=(hint[1] if hint else None),
                )
            )

    # -----------------------------
    # SINGLE_TAX: duplicate allocable tax item ids
    # -----------------------------
    seen_allocable_ids: Set[str] = set()
    for item in (req.allocable_tax_items or []):
        if item.fiscal_year_start is not None and item.fiscal_year_start != fy_start:
            continue
        if not item.item_id:
            continue
        if item.item_id in seen_allocable_ids:
            _add_issue(
                tj_ids=list(works.keys()),
                severity="error",
                principle="SINGLE_TAX",
                code="SINGLE_TAX_DUPLICATE_ALLOCABLE_TAX_ITEM_ID",
                message=f"AllocableTaxItemV2 item_id '{item.item_id}' appears more than once. Each allocable tax item should be recorded once to avoid double counting.",
                reference_id=item.item_id,
                path="$.allocable_tax_items[]",
            )
        seen_allocable_ids.add(item.item_id)

    # -----------------------------
    # TP register matching sanity
    # -----------------------------
    for tp in (req.transfer_pricing_adjustments or []):
        if tp.accrual_year_fy_start != fy_start:
            continue
        if tp.seller_tested_jurisdiction_id == tp.buyer_tested_jurisdiction_id:
            _add_issue(
                tj_ids=[tp.seller_tested_jurisdiction_id],
                severity="error",
                principle="MATCHING",
                code="MATCHING_TP_SELLER_BUYER_SAME_TJ",
                message="TransferPricingAdjustmentV2 has the same seller_tested_jurisdiction_id and buyer_tested_jurisdiction_id; counterparty symmetry cannot be assessed.",
                reference_id=tp.adjustment_id,
                path="$.transfer_pricing_adjustments[]",
            )
            continue

        # Symmetry check (soft) when no special-case flags are set and explicit buyer values are provided
        if not (tp.tp_accounted_at_cost or tp.tp_intangible_asset_related or tp.tp_loss_disallowed_deemed_tp_adjustment):
            if tp.buyer_income_adjustment is not None:
                s = float(tp.seller_income_adjustment or 0.0)
                b = float(tp.buyer_income_adjustment or 0.0)
                if abs((s + b)) > max(tol, 1e-6):
                    _add_issue(
                        tj_ids=[tp.seller_tested_jurisdiction_id, tp.buyer_tested_jurisdiction_id],
                        severity="warning",
                        principle="MATCHING",
                        code="MATCHING_TP_ASYMMETRIC_INCOME",
                        message=(
                            "Transfer pricing income adjustment is not symmetric (seller_income_adjustment + buyer_income_adjustment != 0). "
                            "If this is intended, document via integrity_adjustments (resolves_issue_code) or TP special-case flags."
                        ),
                        reference_id=tp.adjustment_id,
                        path="$.transfer_pricing_adjustments[]",
                    )
            if tp.buyer_tax_adjustment is not None:
                st = float(tp.seller_tax_adjustment or 0.0)
                bt = float(tp.buyer_tax_adjustment or 0.0)
                if abs((st + bt)) > max(tol, 1e-6) and (abs(st) > tol or abs(bt) > tol):
                    _add_issue(
                        tj_ids=[tp.seller_tested_jurisdiction_id, tp.buyer_tested_jurisdiction_id],
                        severity="warning",
                        principle="MATCHING",
                        code="MATCHING_TP_ASYMMETRIC_TAX",
                        message=(
                            "Transfer pricing tax adjustment is not symmetric (seller_tax_adjustment + buyer_tax_adjustment != 0). "
                            "If this is intended, document via integrity_adjustments (resolves_issue_code)."
                        ),
                        reference_id=tp.adjustment_id,
                        path="$.transfer_pricing_adjustments[]",
                    )

    # -----------------------------
    # Flow-through allocation integrity
    # -----------------------------
    # Entity index (only available when entity roll-up data is provided)
    entity_index: Dict[str, Tuple[str, object]] = {}
    for tj in (req.tested_jurisdictions or []):
        for e in (tj.entities or []):
            eid = getattr(e, "entity_id", None)
            if not eid:
                continue
            entity_index[str(eid)] = (tj.tested_jurisdiction_id, e)

    # Group flow-through lines by entity id (current FY only)
    lines_by_entity: Dict[str, List[FlowThroughEntityAllocationV2]] = {}
    for ln in (req.flow_through_entities or []):
        if ln.fiscal_year_start is not None and ln.fiscal_year_start != fy_start:
            continue
        lines_by_entity.setdefault(str(ln.flow_through_entity_id), []).append(ln)

    for ent_id, lines in lines_by_entity.items():
        # If the flow-through entity isn't present in entities[], we can still warn (can't check bounds).
        ent_row = entity_index.get(ent_id)
        if ent_row is None:
            # Attach warning to source TJ if provided; else all.
            src_candidates = {ln.flow_through_tested_jurisdiction_id for ln in lines if ln.flow_through_tested_jurisdiction_id}
            tj_attach = list(src_candidates) if src_candidates else list(works.keys())
            _add_issue(
                tj_ids=tj_attach,
                severity="warning",
                principle="FULL_ALLOCATION",
                code="FULL_ALLOCATION_FLOW_THROUGH_ENTITY_NOT_FOUND",
                message=(
                    f"Flow-through allocation lines reference entity_id '{ent_id}', but no matching entity row was found in tested_jurisdictions[].entities[]. "
                    "Provide entity facts (with entity_id) to enable stronger integrity checks."
                ),
                reference_id=ent_id,
                path="$.flow_through_entities[]",
            )
            continue

        src_tj_id, ent = ent_row
        if src_tj_id not in works:
            continue

        w_src = works[src_tj_id]

        # Convert entity base amounts to reporting currency using the same TJ currency multiplier.
        mult = float(getattr(w_src, "currency_multiplier_pl", 1.0))
        ent_income = float(getattr(ent, "jpbt", 0.0) or 0.0) * mult
        ent_tax = (float(getattr(ent, "current_tax_expense", 0.0) or 0.0) + float(getattr(ent, "deferred_tax_expense", 0.0) or 0.0)) * mult

        # Sum allocations for the entity (converted using line conventions)
        sum_income = 0.0
        sum_tax = 0.0

        src_ids_in_lines: Set[str] = set()

        for ln in lines:
            src_id = ln.flow_through_tested_jurisdiction_id
            tgt_id = ln.owner_tested_jurisdiction_id
            if src_id:
                src_ids_in_lines.add(str(src_id))

            default_currency = ln.currency or (works[src_id].input_currency if src_id and src_id in works else w_src.input_currency) or reporting_currency

            inc, _ = _convert_amount_with_fx(
                req,
                amount=float(getattr(ln, "income_allocated_amount", 0.0) or 0.0),
                currency=default_currency,
                amount_scale=getattr(ln, "amount_scale", "UNITS"),
                fy_start=fy_start,
                reporting_currency=reporting_currency,
                use_spot=False,
            )
            tx, _ = _convert_amount_with_fx(
                req,
                amount=float(getattr(ln, "tax_allocated_amount", 0.0) or 0.0),
                currency=default_currency,
                amount_scale=getattr(ln, "amount_scale", "UNITS"),
                fy_start=fy_start,
                reporting_currency=reporting_currency,
                use_spot=False,
            )
            sum_income += float(inc)
            sum_tax += float(tx)

            # MATCHING: income allocated but no taxes allocated
            if abs(float(inc)) > tol and abs(float(tx)) <= tol and abs(ent_tax) > tol:
                attach = []
                if src_id:
                    attach.append(str(src_id))
                if tgt_id:
                    attach.append(str(tgt_id))
                if attach:
                    _add_issue(
                        tj_ids=list({x for x in attach if x in works}),
                        severity="warning",
                        principle="MATCHING",
                        code="MATCHING_INCOME_ALLOCATED_TAX_NOT_ALLOCATED",
                        message=(
                            "Flow-through allocation moves income but does not move any taxes for the same line, while the entity has non-zero tax expense. "
                            "Under the matching principle, confirm whether corresponding taxes should be allocated or otherwise adjusted."
                        ),
                        reference_id=str(ln.line_id or ent_id),
                        path="$.flow_through_entities[]",
                    )

        # If allocation lines claim a different source TJ than where the entity is recorded, flag.
        if src_ids_in_lines and (src_tj_id not in src_ids_in_lines):
            _add_issue(
                tj_ids=list({x for x in ([src_tj_id] + list(src_ids_in_lines)) if x in works}),
                severity="error",
                principle="MATCHING",
                code="MATCHING_FLOW_THROUGH_SOURCE_TJ_MISMATCH",
                message=(
                    f"Flow-through allocation lines for entity_id '{ent_id}' use source TJ ids {sorted(list(src_ids_in_lines))}, "
                    f"but the entity is recorded under tested_jurisdiction_id '{src_tj_id}'. Ensure IDs align to avoid misallocation."
                ),
                reference_id=ent_id,
                path="$.flow_through_entities[]",
            )

        # SINGLE_EXPENSE_LOSS: allocations should not exceed entity base income (strong bound)
        if ent_income >= 0:
            if sum_income > ent_income + tol:
                _add_issue(
                    tj_ids=[src_tj_id],
                    severity="error",
                    principle="SINGLE_EXPENSE_LOSS",
                    code="SINGLE_EXPENSE_LOSS_FLOW_THROUGH_ALLOC_EXCEEDS_ENTITY_INCOME",
                    message=(
                        f"Total flow-through income allocated out for entity_id '{ent_id}' ({sum_income:.6f}) exceeds the entity JPBT ({ent_income:.6f}) in reporting currency. "
                        "This indicates possible double counting or inconsistent units/FX."
                    ),
                    reference_id=ent_id,
                    path="$.flow_through_entities[]",
                )
        else:
            if sum_income < ent_income - tol:
                _add_issue(
                    tj_ids=[src_tj_id],
                    severity="error",
                    principle="SINGLE_EXPENSE_LOSS",
                    code="SINGLE_EXPENSE_LOSS_FLOW_THROUGH_ALLOC_EXCEEDS_ENTITY_LOSS",
                    message=(
                        f"Total flow-through income allocated out for entity_id '{ent_id}' ({sum_income:.6f}) is more negative than the entity JPBT ({ent_income:.6f}) in reporting currency. "
                        "This indicates possible double counting or inconsistent units/FX."
                    ),
                    reference_id=ent_id,
                    path="$.flow_through_entities[]",
                )

        # SINGLE_TAX: allocations should not exceed entity base taxes (soft bound; taxes can be complex, but this is a useful sanity check)
        if ent_tax >= 0:
            if sum_tax > ent_tax + tol:
                _add_issue(
                    tj_ids=[src_tj_id],
                    severity="warning",
                    principle="SINGLE_TAX",
                    code="SINGLE_TAX_FLOW_THROUGH_ALLOC_EXCEEDS_ENTITY_TAX",
                    message=(
                        f"Total flow-through taxes allocated out for entity_id '{ent_id}' ({sum_tax:.6f}) exceeds the entity current+deferred tax expense ({ent_tax:.6f}) in reporting currency. "
                        "Confirm the tax basis for allocation and whether additional covered taxes are being allocated."
                    ),
                    reference_id=ent_id,
                    path="$.flow_through_entities[]",
                )

        # FULL_ALLOCATION: tax-transparent / flow-through entities should usually be fully allocated out (soft)
        etype = getattr(ent, "entity_type", None)
        if etype in {"FLOW_THROUGH_ENTITY", "TAX_TRANSPARENT_ENTITY"}:
            if abs(ent_income - sum_income) > max(tol, 1e-6) and abs(ent_income) > tol:
                _add_issue(
                    tj_ids=[src_tj_id],
                    severity="warning",
                    principle="FULL_ALLOCATION",
                    code="FULL_ALLOCATION_FLOW_THROUGH_ENTITY_NOT_FULLY_ALLOCATED",
                    message=(
                        f"Entity_id '{ent_id}' is classified as {etype} but total allocated income ({sum_income:.6f}) does not equal entity JPBT ({ent_income:.6f}) in reporting currency. "
                        "If the entity is tax transparent/flow-through, confirm that all income is allocated to owners (or document exceptions via integrity_adjustments)."
                    ),
                    reference_id=ent_id,
                    path="$.flow_through_entities[]",
                )

    # TJ-level completeness for buckets that contain only flow-through / tax-transparent entities
    for tid, w in works.items():
        t = w.tj
        ents = list(getattr(t, "entities", None) or [])
        if not ents:
            continue
        types = {getattr(e, "entity_type", None) or "STANDARD_CE" for e in ents}
        if types and types.issubset({"FLOW_THROUGH_ENTITY", "TAX_TRANSPARENT_ENTITY"}):
            post_inc = float(w.simplified_income_post_allocations if w.simplified_income_post_allocations is not None else w.simplified_income)
            post_tax = float(w.simplified_taxes_post_allocations if w.simplified_taxes_post_allocations is not None else w.simplified_taxes)
            if abs(post_inc) > tol or abs(post_tax) > tol:
                _add_issue(
                    tj_ids=[tid],
                    severity="warning",
                    principle="FULL_ALLOCATION",
                    code="FULL_ALLOCATION_BUCKET_NOT_ZERO_POST_ALLOCATIONS",
                    message=(
                        "This Tested Jurisdiction contains only flow-through/tax-transparent entities but post-allocation Simplified Income/Taxes are not near zero. "
                        "Deemed-zero (section 6.2) may not apply and integrity allocations may be incomplete."
                    ),
                    reference_id=tid,
                    path="$.tested_jurisdictions[]",
                )

    # -----------------------------
    # Apply resolutions + compute pass/fail per TJ + eligibility impact
    # -----------------------------
    for tid, w in works.items():
        issues = issues_by_tj.get(tid, [])
        # Downgrade resolvable codes when the adjustment register indicates resolution
        resolved = resolutions_by_tj.get(tid, set())
        for iss in issues:
            if iss.code in _RESOLVABLE_INTEGRITY_CODES and iss.code in resolved:
                iss.severity = "info"
                iss.message = iss.message + " (Marked as resolved via integrity_adjustments register.)"

        has_error = any(i.severity == "error" for i in issues)
        has_warn = any(i.severity == "warning" for i in issues)

        passed = (not has_error) and (not (bool(getattr(opts, "treat_warnings_as_errors", False)) and has_warn))
        w.integrity_assessment = IntegrityAssessmentV2(
            passed=bool(passed),
            issues=issues,
            notes=[
                "Automated integrity checks are pragmatic. Review warnings and document exceptions with integrity_adjustments where appropriate."
            ],
        )

        if not passed:
            # Eligibility impact
            fail_on_errors = bool(getattr(opts, "fail_on_errors", True))
            treat_warn_as_err = bool(getattr(opts, "treat_warnings_as_errors", False))
            should_fail = (has_error and fail_on_errors) or (has_warn and treat_warn_as_err)

            if should_fail and w.eligible:
                w.eligible = False
                w.ineligibility_reasons.append("Integrity rules not satisfied (Box 7.3).")
                w.trace.append(
                    TraceLine(
                        section="eligibility",
                        step="Integrity rules failed (Box 7.3)",
                        amount=0.0,
                        note="One or more integrity errors/warnings were detected. See integrity_assessment.issues.",
                    )
                )



def _apply_section_5_1_allocations(
    works: Dict[str, _TJWork],
    req: CalculationRequestV2,
    *,
    fy_start: date,
    reporting_currency: Optional[str],
    group_election_register: List[ElectionInstanceV2],
) -> List[PESimplificationStateItemV2]:
    """Apply OECD section 5.1 allocation/exclusion logic (Module 6).

    Practical implementation (deterministic and auditable):
      - Flow-through allocations: move income/taxes from flow-through TJ to owner TJ based on req.flow_through_entities lines.
      - Allocable tax items (Article 4.3.2 tagged):
          * Default: taxes under 4.3.2(a),(c),(d),(e) are excluded from all Tested Jurisdictions (removed from the source TJ).
          * Election (CROSS_BORDER_FIVE_YEAR_ELECTION_KEEP_ALLOCABLE_TAXES): do not exclude; allocate to target TJ when provided,
            otherwise keep in source.
          * Withholding on distributions: never excluded; kept in source unless election + target provided.
          * 4.3.2(b): treated as allocable; allocate to target when provided; otherwise keep in source with a warning.

      - PE simplification election (Box 5.1(3)-(4)):
          * Apply req.pe_allocation_lines to include PE Simplified Income/Loss and related taxes/foreign tax credits in
            the Main Entity Tested Jurisdiction when the PE simplification election is effective.
          * Maintain a per-PE continuation tracker (unrecouped loss + one-year tail) in response.pe_simplification_state_closing.
          * For allocable tax items under Article 4.3.2(a) linked to a PE, if the PE simplification election is effective
            for the PE context, the keep/allocate election does not apply. The item is not allocated to the PE and the
            default exclusion is applied.

    Notes:
      - All amounts are translated to the request reporting currency (when provided) using average FX (P&L convention).
      - This step runs before carryforwards so it influences Simplified ETR.
    """

    # Ensure per-TJ containers exist
    for w in works.values():
        if w.allocation_ledger is None:
            w.allocation_ledger = []
        if w.allocation_warnings is None:
            w.allocation_warnings = []
        # Snapshot pre-allocation values once
        if w.simplified_income_pre_allocations is None:
            w.simplified_income_pre_allocations = float(w.simplified_income)
        if w.simplified_taxes_pre_allocations is None:
            w.simplified_taxes_pre_allocations = float(w.simplified_taxes)

    effective_group = resolve_effective_elections(group_election_register or [], fiscal_year_start=fy_start)
    keep_allocable = bool(get_effective_election_bool(effective_group, "CROSS_BORDER_FIVE_YEAR_ELECTION_KEEP_ALLOCABLE_TAXES") or False)
    pe_group = bool(get_effective_election_bool(effective_group, "PE_SIMPLIFICATION_ELECTION_NOTE") or False)

    # PE simplification election is made on a jurisdictional basis (Main Entity TJ). In addition
    # to explicit elections, continuation state (Box 5.1(4)) can force the election.
    explicit_pe_election_tjs: Set[str] = set(works.keys()) if pe_group else {
        tj_id
        for tj_id, w in works.items()
        if bool(get_effective_election_bool(w.effective_elections, "PE_SIMPLIFICATION_ELECTION_NOTE") or False)
    }

    pe_by_id: Dict[str, PermanentEstablishmentV2] = {pe.pe_id: pe for pe in (req.permanent_establishments or [])}

    forced_pe_election_tjs: Set[str] = set()
    for st in getattr(req, "pe_simplification_state_opening", None) or []:
        loss_bal = float(getattr(st, "unrecouped_loss_balance", 0.0) or 0.0)
        tail = int(getattr(st, "tail_years_remaining", 0) or 0)
        if loss_bal <= 1e-9 and tail <= 0:
            continue
        main_tj = getattr(st, "main_entity_tested_jurisdiction_id", None)
        if main_tj is None:
            pe_id = getattr(st, "pe_id", None)
            if pe_id and pe_id in pe_by_id:
                main_tj = pe_by_id[pe_id].main_entity_tested_jurisdiction_id
        if main_tj:
            forced_pe_election_tjs.add(str(main_tj))

    pe_election_tjs: Set[str] = set(explicit_pe_election_tjs) | set(forced_pe_election_tjs)

    # If forced by continuation state, inject a synthetic effective election record (audit) and warn.
    for tj_id in sorted(forced_pe_election_tjs):
        if tj_id not in works:
            continue
        if tj_id in explicit_pe_election_tjs:
            continue
        try:
            works[tj_id].effective_elections.append(
                ElectionInstanceV2(
                    action="ELECT",
                    election_code="PE_SIMPLIFICATION_ELECTION_NOTE",
                    scope="metadata",
                    value_type="bool",
                    term_type="ANNUAL",
                    effective_fiscal_year_start=fy_start,
                    bool_value=True,
                    label="PE Simplification Election (auto)",
                    note="AUTO: required due to PE simplification loss continuation (Box 5.1(4)).",
                )
            )
        except Exception:
            # If something goes wrong, do not fail computation; continue with forced set semantics.
            pass
        works[tj_id].allocation_warnings.append(
            "PE simplification election auto-applied for this Tested Jurisdiction due to prior-year included PE loss continuation state (Box 5.1(4))."
        )

    # Flow-through entity id -> set of known flow-through TJ ids (for inference)
    ft_tj_by_entity: Dict[str, Set[str]] = {}
    for ln in (req.flow_through_entities or []):
        if ln.flow_through_entity_id:
            ft_tj_by_entity.setdefault(str(ln.flow_through_entity_id), set()).add(str(ln.flow_through_tested_jurisdiction_id or ""))

    def _warn(tj_id: Optional[str], msg: str) -> None:
        if tj_id and tj_id in works:
            works[tj_id].allocation_warnings.append(msg)

    def _add_entry_to_tjs(entry: AllocationLedgerEntryV2, tj_ids: List[str]) -> None:
        for tid in tj_ids:
            if tid in works:
                works[tid].allocation_ledger.append(entry)

    # -----------------------------
    # PE Simplification / PE allocation lines (Box 5.1(3)-(4))
    # -----------------------------
    # These lines are applied only when the PE simplification election is effective for the
    # Main Entity Tested Jurisdiction (jurisdictional basis) or forced by continuation state.
    pe_included_income_by_pe: Dict[str, float] = {}
    pe_main_tj_by_pe: Dict[str, str] = {}

    for line in getattr(req, "pe_allocation_lines", None) or []:
        if line.fiscal_year_start is not None and line.fiscal_year_start != fy_start:
            continue

        pe_id = str(getattr(line, "pe_id", "") or "").strip()
        if not pe_id:
            continue

        # Infer main / PE TJ ids if omitted
        main_tj_id = getattr(line, "main_entity_tested_jurisdiction_id", None)
        pe_tj_id = getattr(line, "pe_tested_jurisdiction_id", None)
        if (main_tj_id is None or pe_tj_id is None) and pe_id in pe_by_id:
            pe_def = pe_by_id[pe_id]
            main_tj_id = main_tj_id or pe_def.main_entity_tested_jurisdiction_id
            pe_tj_id = pe_tj_id or pe_def.pe_tested_jurisdiction_id

        if not main_tj_id:
            # No place to apply
            continue

        main_tj_id = str(main_tj_id)
        if main_tj_id not in works:
            continue

        # Apply only if election is effective for this Main Entity TJ
        if main_tj_id not in pe_election_tjs:
            # Ignore silently; validation endpoint issues a warning for non-zero rows.
            continue

        default_currency = getattr(line, "currency", None) or works[main_tj_id].input_currency or reporting_currency
        inc_income, fx_note_i = _convert_amount_with_fx(
            req,
            amount=float(getattr(line, "pe_income_included_in_main", 0.0) or 0.0),
            currency=default_currency,
            amount_scale=getattr(line, "amount_scale", "UNITS"),
            fy_start=fy_start,
            reporting_currency=reporting_currency,
            use_spot=False,
        )
        inc_tax, fx_note_t = _convert_amount_with_fx(
            req,
            amount=float(getattr(line, "main_entity_taxes_related_to_pe", 0.0) or 0.0),
            currency=default_currency,
            amount_scale=getattr(line, "amount_scale", "UNITS"),
            fy_start=fy_start,
            reporting_currency=reporting_currency,
            use_spot=False,
        )
        ftc_raw, fx_note_f = _convert_amount_with_fx(
            req,
            amount=float(getattr(line, "foreign_tax_credit_used", 0.0) or 0.0),
            currency=default_currency,
            amount_scale=getattr(line, "amount_scale", "UNITS"),
            fy_start=fy_start,
            reporting_currency=reporting_currency,
            use_spot=False,
        )

        # Apply FTC cap when nominal rate provided (Box 5.1(3) / para 153)
        ftc_used = float(ftc_raw)
        cap_note = None
        try:
            nominal = getattr(line, "main_nominal_tax_rate", None)
            if nominal is not None:
                nominal_rate = float(nominal)
                if nominal_rate < 0:
                    nominal_rate = 0.0
                # Cap uses PE income included (only positive income generates cap)
                cap = max(0.0, float(inc_income)) * nominal_rate
                if ftc_used > cap + 1e-9:
                    cap_note = f"FTC capped: raw={ftc_used} cap={cap} (nominal={nominal_rate})"
                    ftc_used = cap
        except Exception:
            pass

        # Apply to main jurisdiction
        works[main_tj_id].simplified_income += float(inc_income)
        works[main_tj_id].simplified_taxes += float(inc_tax) + float(ftc_used)

        # Track included income for continuation state
        pe_included_income_by_pe[pe_id] = float(pe_included_income_by_pe.get(pe_id, 0.0)) + float(inc_income)
        pe_main_tj_by_pe[pe_id] = main_tj_id

        label = f"PE simplification inclusion ({pe_id})"
        ref = getattr(line, "line_id", None) or pe_id

        works[main_tj_id].allocation_ledger.append(
            AllocationLedgerEntryV2(
                source_type="PE_SIMPLIFICATION",
                operation="KEEP",
                kind="income",
                amount=float(inc_income),
                source_tested_jurisdiction_id=str(pe_tj_id) if pe_tj_id else None,
                target_tested_jurisdiction_id=main_tj_id,
                reference_id=str(ref),
                label=label,
                note="Included PE Simplified Income/Loss in Main Entity TJ under PE simplification election" + (f" | {fx_note_i}" if fx_note_i else ""),
            )
        )

        works[main_tj_id].allocation_ledger.append(
            AllocationLedgerEntryV2(
                source_type="PE_SIMPLIFICATION",
                operation="KEEP",
                kind="tax",
                amount=float(inc_tax) + float(ftc_used),
                source_tested_jurisdiction_id=str(pe_tj_id) if pe_tj_id else None,
                target_tested_jurisdiction_id=main_tj_id,
                reference_id=str(ref),
                label=label,
                note=(
                    "Included Main Entity taxes related to PE income and foreign tax credit used under PE simplification election"
                    + (f" | {fx_note_t}" if fx_note_t else "")
                    + (f" | {fx_note_f}" if fx_note_f else "")
                    + (f" | {cap_note}" if cap_note else "")
                ),
            )
        )

        works[main_tj_id].trace.append(
            TraceLine(
                section="income",
                step="Section 5.1 PE simplification: included PE income/loss in main jurisdiction",
                amount=float(inc_income),
                running_total=float(works[main_tj_id].simplified_income),
                note=(
                    f"PE={pe_id}" + (f" | {fx_note_i}" if fx_note_i else "")
                ),
            )
        )
        works[main_tj_id].trace.append(
            TraceLine(
                section="tax",
                step="Section 5.1 PE simplification: included PE-related taxes/FTC in main jurisdiction",
                amount=float(inc_tax) + float(ftc_used),
                running_total=float(works[main_tj_id].simplified_taxes),
                note=(
                    f"PE={pe_id}" + (f" | {cap_note}" if cap_note else "")
                ),
            )
        )

    # -----------------------------
    # Flow-through allocations
    # -----------------------------
    for line in (req.flow_through_entities or []):
        if line.fiscal_year_start is not None and line.fiscal_year_start != fy_start:
            continue

        src_id = line.flow_through_tested_jurisdiction_id
        tgt_id = line.owner_tested_jurisdiction_id
        if not src_id or not tgt_id:
            raise ValueError("Flow-through allocation line must include flow_through_tested_jurisdiction_id and owner_tested_jurisdiction_id.")
        if src_id not in works:
            raise ValueError(f"Flow-through allocation references unknown flow_through_tested_jurisdiction_id '{src_id}'.")
        if tgt_id not in works:
            raise ValueError(f"Flow-through allocation references unknown owner_tested_jurisdiction_id '{tgt_id}'.")

        # Convert amounts (assume the line is expressed in the flow-through TJ currency unless an explicit currency is provided)
        default_currency = line.currency or works[src_id].input_currency or reporting_currency
        income_amt, fx_note_inc = _convert_amount_with_fx(
            req,
            amount=float(getattr(line, "income_allocated_amount", 0.0) or 0.0),
            currency=default_currency,
            amount_scale=getattr(line, "amount_scale", "UNITS"),
            fy_start=fy_start,
            reporting_currency=reporting_currency,
            use_spot=False,
        )
        tax_amt, fx_note_tax = _convert_amount_with_fx(
            req,
            amount=float(getattr(line, "tax_allocated_amount", 0.0) or 0.0),
            currency=default_currency,
            amount_scale=getattr(line, "amount_scale", "UNITS"),
            fy_start=fy_start,
            reporting_currency=reporting_currency,
            use_spot=False,
        )

        ref = line.line_id or line.flow_through_entity_id
        label = line.flow_through_entity_name or "Flow-through allocation"

        if income_amt != 0.0:
            works[src_id].simplified_income -= float(income_amt)
            works[tgt_id].simplified_income += float(income_amt)

            entry = AllocationLedgerEntryV2(
                source_type="FLOW_THROUGH",
                operation="ALLOCATE",
                kind="income",
                amount=float(income_amt),
                source_tested_jurisdiction_id=src_id,
                target_tested_jurisdiction_id=tgt_id,
                reference_id=str(ref) if ref is not None else None,
                label=label,
                note=(" | ".join([p for p in [line.note, fx_note_inc] if p]) or None),
            )
            _add_entry_to_tjs(entry, [src_id, tgt_id])

            works[src_id].trace.append(
                TraceLine(
                    section="income",
                    step="Section 5.1 allocation: flow-through income allocated out",
                    amount=float(-income_amt),
                    running_total=float(works[src_id].simplified_income),
                    note=f"{label} -> {tgt_id}" + (f" | {entry.note}" if entry.note else ""),
                )
            )
            works[tgt_id].trace.append(
                TraceLine(
                    section="income",
                    step="Section 5.1 allocation: flow-through income allocated in",
                    amount=float(income_amt),
                    running_total=float(works[tgt_id].simplified_income),
                    note=f"{label} <- {src_id}" + (f" | {entry.note}" if entry.note else ""),
                )
            )

        if tax_amt != 0.0:
            works[src_id].simplified_taxes -= float(tax_amt)
            works[tgt_id].simplified_taxes += float(tax_amt)

            entry = AllocationLedgerEntryV2(
                source_type="FLOW_THROUGH",
                operation="ALLOCATE",
                kind="tax",
                amount=float(tax_amt),
                source_tested_jurisdiction_id=src_id,
                target_tested_jurisdiction_id=tgt_id,
                reference_id=str(ref) if ref is not None else None,
                label=label,
                note=(" | ".join([p for p in [line.note, fx_note_tax] if p]) or None),
            )
            _add_entry_to_tjs(entry, [src_id, tgt_id])

            works[src_id].trace.append(
                TraceLine(
                    section="tax",
                    step="Section 5.1 allocation: flow-through taxes allocated out",
                    amount=float(-tax_amt),
                    running_total=float(works[src_id].simplified_taxes),
                    note=f"{label} -> {tgt_id}" + (f" | {entry.note}" if entry.note else ""),
                )
            )
            works[tgt_id].trace.append(
                TraceLine(
                    section="tax",
                    step="Section 5.1 allocation: flow-through taxes allocated in",
                    amount=float(tax_amt),
                    running_total=float(works[tgt_id].simplified_taxes),
                    note=f"{label} <- {src_id}" + (f" | {entry.note}" if entry.note else ""),
                )
            )

    # -----------------------------
    # Allocable tax items (Article 4.3.2)
    # -----------------------------
    def _infer_source_tj(item: AllocableTaxItemV2) -> Optional[str]:
        if item.source_tested_jurisdiction_id:
            return item.source_tested_jurisdiction_id
        if item.related_pe_id and item.related_pe_id in pe_by_id:
            pe = pe_by_id[item.related_pe_id]
            return pe.main_entity_tested_jurisdiction_id or pe.pe_tested_jurisdiction_id
        if item.related_flow_through_entity_id and item.related_flow_through_entity_id in ft_tj_by_entity:
            ids = {x for x in ft_tj_by_entity[item.related_flow_through_entity_id] if x}
            if len(ids) == 1:
                return list(ids)[0]
        return None

    def _infer_target_tj(item: AllocableTaxItemV2) -> Optional[str]:
        if item.target_tested_jurisdiction_id:
            return item.target_tested_jurisdiction_id
        if item.related_pe_id and item.related_pe_id in pe_by_id:
            pe = pe_by_id[item.related_pe_id]
            return pe.pe_tested_jurisdiction_id
        return None

    def _pe_simplification_in_effect_for_related_pe(item: AllocableTaxItemV2) -> bool:
        """Return True if the PE simplification election is in effect for the related PE context.

        The OECD guidance (Box 5.1(3)-(4)) restricts Article 4.3.2(a) allocations when the PE
        simplification election is in effect for the Main Entity jurisdiction.

        In practice, clients/UIs may record the PE simplification election either:
          - on the Main Entity Tested Jurisdiction, or
          - on the PE Tested Jurisdiction (because the election is conceptually tied to that PE).

        For robustness, we treat the election as "in effect" if it is effective for either the
        Main Entity TJ or the PE TJ for the referenced PE.
        """

        if not getattr(item, "related_pe_id", None):
            return False
        pe = pe_by_id.get(item.related_pe_id)
        candidates: List[str] = []
        if pe:
            if getattr(pe, "main_entity_tested_jurisdiction_id", None):
                candidates.append(str(pe.main_entity_tested_jurisdiction_id))
            if getattr(pe, "pe_tested_jurisdiction_id", None):
                candidates.append(str(pe.pe_tested_jurisdiction_id))

        # Fallback: if no PE mapping, treat source as best-effort proxy.
        if getattr(item, "source_tested_jurisdiction_id", None):
            candidates.append(str(item.source_tested_jurisdiction_id))

        return any(c and c in pe_election_tjs for c in candidates)

    for item in (req.allocable_tax_items or []):
        if item.fiscal_year_start is not None and item.fiscal_year_start != fy_start:
            continue

        src_id = _infer_source_tj(item)
        tgt_id = _infer_target_tj(item)

        if not src_id:
            raise ValueError(f"Allocable tax item '{item.label or item.item_id or 'unnamed'}' must provide source_tested_jurisdiction_id (or a resolvable related_pe_id / related_flow_through_entity_id).")
        if src_id not in works:
            raise ValueError(f"Allocable tax item '{item.label or item.item_id or 'unnamed'}' references unknown source_tested_jurisdiction_id '{src_id}'.")
        if tgt_id and tgt_id not in works:
            raise ValueError(f"Allocable tax item '{item.label or item.item_id or 'unnamed'}' references unknown target_tested_jurisdiction_id '{tgt_id}'.")

        default_currency = item.currency or works[src_id].input_currency or reporting_currency
        amt, fx_note = _convert_amount_with_fx(
            req,
            amount=float(item.amount),
            currency=default_currency,
            amount_scale=getattr(item, "amount_scale", "UNITS"),
            fy_start=fy_start,
            reporting_currency=reporting_currency,
            use_spot=False,
        )

        label = item.label or item.item_id or "Allocable tax item"
        ref = item.item_id or label

        art = str(item.globe_article)
        exclude_articles = {"4.3.2(a)", "4.3.2(c)", "4.3.2(d)", "4.3.2(e)"}

        operation: str = "KEEP"

        if art == "4.3.2(b)":
            if tgt_id:
                operation = "ALLOCATE"
            else:
                operation = "KEEP"
                _warn(src_id, f"Allocable tax item '{label}' is 4.3.2(b) but has no target_tested_jurisdiction_id; kept in source.")
        elif art in exclude_articles:
            if item.is_withholding_on_distribution:
                # Never excluded; keep in source unless election + target provided
                if keep_allocable and tgt_id:
                    operation = "ALLOCATE"
                else:
                    operation = "KEEP"
            else:
                # Special rule: when PE simplification election is in effect for the Main Entity jurisdiction,
                # Article 4.3.2(a) taxes linked to that PE cannot be allocated to the PE. The keep/allocate election
                # does not apply in this circumstance, so the default exclusion applies.
                if art == "4.3.2(a)" and _pe_simplification_in_effect_for_related_pe(item):
                    operation = "EXCLUDE"
                    if tgt_id:
                        _warn(src_id, f"Allocable tax item '{label}' (4.3.2(a)) not allocated because PE simplification election is in effect; default exclusion applies.")
                        _warn(tgt_id, f"Allocable tax item '{label}' (4.3.2(a)) not allocated because PE simplification election is in effect; default exclusion applies.")
                    if keep_allocable:
                        _warn(src_id, f"Allocable tax item '{label}' (4.3.2(a)) keep/allocate election ignored because PE simplification election is in effect for the Main Entity TJ.")
                else:
                    if keep_allocable:
                        # Election prevents exclusion; allocate when possible
                        if tgt_id:
                            operation = "ALLOCATE"
                        else:
                            operation = "KEEP"
                    else:
                        operation = "EXCLUDE"
        else:
            # Unknown/other: keep in source, but record warning
            operation = "KEEP"
            _warn(src_id, f"Allocable tax item '{label}' uses unexpected globe_article '{art}'; kept in source.")

        if operation == "KEEP":
            entry = AllocationLedgerEntryV2(
                source_type="ALLOCABLE_TAX_ITEM",
                operation="KEEP",
                kind="tax",
                amount=float(amt),
                source_tested_jurisdiction_id=src_id,
                target_tested_jurisdiction_id=tgt_id,
                reference_id=str(ref) if ref is not None else None,
                label=label,
                note=(" | ".join([p for p in [item.note, fx_note, f"article={art}"] if p]) or None),
            )
            _add_entry_to_tjs(entry, [src_id])
            works[src_id].trace.append(
                TraceLine(
                    section="tax",
                    step="Section 5.1 allocable tax item: kept in source",
                    amount=0.0,
                    running_total=float(works[src_id].simplified_taxes),
                    note=f"{label} | article={art}" + (f" | {entry.note}" if entry.note else ""),
                )
            )
            continue

        if operation == "EXCLUDE":
            works[src_id].simplified_taxes -= float(amt)
            entry = AllocationLedgerEntryV2(
                source_type="ALLOCABLE_TAX_ITEM",
                operation="EXCLUDE",
                kind="tax",
                amount=float(-abs(amt)),
                source_tested_jurisdiction_id=src_id,
                target_tested_jurisdiction_id=None,
                reference_id=str(ref) if ref is not None else None,
                label=label,
                note=(" | ".join([p for p in [item.note, fx_note, f"article={art}"] if p]) or None),
            )
            _add_entry_to_tjs(entry, [src_id])
            works[src_id].trace.append(
                TraceLine(
                    section="tax",
                    step="Section 5.1 allocable tax item: excluded from all TJs",
                    amount=float(-abs(amt)),
                    running_total=float(works[src_id].simplified_taxes),
                    note=f"{label} | article={art}" + (f" | {entry.note}" if entry.note else ""),
                )
            )
            continue

        # ALLOCATE
        if not tgt_id:
            # Defensive fallback
            works[src_id].simplified_taxes -= float(amt)
            _warn(src_id, f"Allocable tax item '{label}' could not be allocated because target_tested_jurisdiction_id is missing; excluded instead.")
            continue

        works[src_id].simplified_taxes -= float(amt)
        works[tgt_id].simplified_taxes += float(amt)

        entry = AllocationLedgerEntryV2(
            source_type="ALLOCABLE_TAX_ITEM",
            operation="ALLOCATE",
            kind="tax",
            amount=float(amt),
            source_tested_jurisdiction_id=src_id,
            target_tested_jurisdiction_id=tgt_id,
            reference_id=str(ref) if ref is not None else None,
            label=label,
            note=(" | ".join([p for p in [item.note, fx_note, f"article={art}"] if p]) or None),
        )
        _add_entry_to_tjs(entry, [src_id, tgt_id])

        works[src_id].trace.append(
            TraceLine(
                section="tax",
                step="Section 5.1 allocable tax item: allocated out",
                amount=float(-amt),
                running_total=float(works[src_id].simplified_taxes),
                note=f"{label} -> {tgt_id} | article={art}" + (f" | {entry.note}" if entry.note else ""),
            )
        )
        works[tgt_id].trace.append(
            TraceLine(
                section="tax",
                step="Section 5.1 allocable tax item: allocated in",
                amount=float(amt),
                running_total=float(works[tgt_id].simplified_taxes),
                note=f"{label} <- {src_id} | article={art}" + (f" | {entry.note}" if entry.note else ""),
            )
        )

    # Snapshot post-allocation values
    for w in works.values():
        w.simplified_income_post_allocations = float(w.simplified_income)
        w.simplified_taxes_post_allocations = float(w.simplified_taxes)

    # -----------------------------
    # PE simplification continuation state (Box 5.1(4))
    # -----------------------------
    # Track per-PE unrecouped losses included in Main Entity TJ income and a 1-year tail once recouped.
    closing_state: List[PESimplificationStateItemV2] = []
    opening_by_pe: Dict[str, PESimplificationStateItemV2] = {
        str(st.pe_id): st for st in (getattr(req, "pe_simplification_state_opening", None) or []) if getattr(st, "pe_id", None)
    }

    pe_ids: Set[str] = set(opening_by_pe.keys()) | set(pe_included_income_by_pe.keys())
    for pe_id in sorted(pe_ids):
        st = opening_by_pe.get(pe_id)
        loss = float(getattr(st, "unrecouped_loss_balance", 0.0) or 0.0) if st else 0.0
        tail = int(getattr(st, "tail_years_remaining", 0) or 0) if st else 0
        # Progress the one-year tail
        if tail > 0:
            tail = max(tail - 1, 0)

        included = float(pe_included_income_by_pe.get(pe_id, 0.0) or 0.0)
        # Negative included income represents a loss included in main; increase outstanding loss.
        if included < -1e-9:
            loss += abs(included)
            tail = 0
        # Positive included income can recoup prior losses.
        elif included > 1e-9 and loss > 1e-9:
            offset = min(loss, included)
            loss -= offset
            if loss <= 1e-9:
                loss = 0.0
                # Once fully recouped in current year, election must continue for the following FY.
                tail = 1

        # Derive main TJ for convenience / scenario builder
        main_tj = None
        if st and getattr(st, "main_entity_tested_jurisdiction_id", None):
            main_tj = getattr(st, "main_entity_tested_jurisdiction_id")
        if not main_tj and pe_id in pe_main_tj_by_pe:
            main_tj = pe_main_tj_by_pe[pe_id]
        if not main_tj and pe_id in pe_by_id and pe_by_id[pe_id].main_entity_tested_jurisdiction_id:
            main_tj = pe_by_id[pe_id].main_entity_tested_jurisdiction_id

        # Keep rows that are still relevant (or were present in opening state for audit continuity)
        if loss > 1e-9 or tail > 0 or st is not None:
            closing_state.append(
                PESimplificationStateItemV2(
                    pe_id=pe_id,
                    main_entity_tested_jurisdiction_id=str(main_tj) if main_tj else None,
                    unrecouped_loss_balance=float(max(0.0, loss)),
                    tail_years_remaining=int(max(0, tail)),
                    last_fiscal_year_start=fy_start,
                    note=(getattr(st, "note", None) if st else None),
                )
            )

    return closing_state




def _convert_amount_with_fx(
    req: CalculationRequestV2,
    *,
    amount: float,
    currency: Optional[str],
    amount_scale: Optional[AmountScale],
    fy_start: date,
    reporting_currency: Optional[str],
    use_spot: bool,
) -> tuple[float, Optional[str]]:
    """Convert a monetary amount into the reporting currency.

    Returns (converted_amount, note).
    - Applies amount_scale first
    - Applies FX translation only when reporting_currency and currency differ
    - Uses spot FX for balance-sheet items when available; otherwise falls back to avg FX.
    """

    mult = float(_scale_multiplier(amount_scale))
    amt = float(amount) * mult

    cur = (currency or "").upper().strip() or None
    rep = (reporting_currency or "").upper().strip() or None

    if not rep or not cur or cur == rep:
        return amt, None

    if use_spot:
        fx = _fx_lookup_spot(req, cur, fy_start)
        if fx is not None:
            return amt * float(fx), f"FX spot {cur}->{rep}={fx}"
        fx2 = _fx_lookup_avg(req, cur, fy_start)
        if fx2 is None:
            raise ValueError(
                f"Missing FX rate for currency '{cur}' to reporting currency '{rep}' for FY start {fy_start}. "
                "Provide request.fx_rates with avg_rate_to_reporting and (optionally) spot_rate_to_reporting."
            )
        return amt * float(fx2), f"FX spot missing; used avg {cur}->{rep}={fx2}"

    fx = _fx_lookup_avg(req, cur, fy_start)
    if fx is None:
        raise ValueError(
            f"Missing FX rate for currency '{cur}' to reporting currency '{rep}' for FY start {fy_start}. "
            "Provide request.fx_rates with avg_rate_to_reporting."
        )
    return amt * float(fx), f"FX avg {cur}->{rep}={fx}"



# ---------------------------------------------------------------------------
# After-year-end adjustments (OECD Box 4.6) (v4 phase 4.4)
# ---------------------------------------------------------------------------

_GROUP_WIDE_ELECTION_CODES: Set[str] = {
    # Box 4.6(2) timing election
    "AFTER_YEAR_END_ADJUSTMENTS_FIVE_YEAR_ELECTION_TRANSACTION_YEAR_METHOD",
    # Box 5.2(2) timing election (transfer pricing)
    "TP_FIVE_YEAR_ELECTION_TRANSACTION_YEAR_METHOD",
    # Box 5.1(2) election: do not exclude allocable cross-border taxes from all Tested Jurisdictions
    "CROSS_BORDER_FIVE_YEAR_ELECTION_KEEP_ALLOCABLE_TAXES",
}



@dataclass
class _AYEApplied:
    tj_id: str
    adjustment: AfterYearEndAdjustmentV2
    amount_reporting_currency: float
    included_in_fy_start: date
    inclusion_method: str  # 'ACCRUAL_YEAR' or 'TRANSACTION_YEAR'
    within_12_months: Optional[bool]


def _dedupe_election_register(
    elections: List[ElectionInstanceV2],
    *,
    context: str,
) -> List[ElectionInstanceV2]:
    """De-duplicate elections by (code, effective_fiscal_year_start).

    The v2 election engine rejects duplicate effective starts as ambiguous. When we combine
    group_elections with elections copied onto Tested Jurisdictions (for backwards compatibility),
    we want to treat identical rows as duplicates and hard-fail on conflicting rows.
    """

    by_key: Dict[tuple[str, date], ElectionInstanceV2] = {}
    for e in elections:
        eff = e.effective_fiscal_year_start
        if eff is None:
            # leave None as-is; the resolver will default it to fiscal_year_start when applied.
            # For de-duplication we treat None as a separate key.
            key = (e.election_code, date.min)
        else:
            key = (e.election_code, eff)
        if key not in by_key:
            by_key[key] = e
            continue

        prior = by_key[key]
        # Conflicting action or values is an error
        if getattr(prior, "action", "ELECT") != getattr(e, "action", "ELECT"):
            raise ValueError(
                f"{context}: conflicting election events for '{e.election_code}' at effective_fiscal_year_start={eff}. "
                "Found both ELECT and REVOKE (or mixed actions). Use a single consistent group election register."
            )
        # Compare value fields (revocations carry no values)
        if getattr(prior, "action", "ELECT") == "ELECT":
            if prior.value_type != e.value_type:
                raise ValueError(f"{context}: conflicting value_type for election '{e.election_code}' at {eff}.")
            if prior.bool_value != e.bool_value or prior.amount != e.amount or prior.text_value != e.text_value:
                raise ValueError(
                    f"{context}: conflicting values for election '{e.election_code}' at {eff}. "
                    "Use a single consistent group election register."
                )
    return list(by_key.values())


def _collect_group_election_register(req: CalculationRequestV2) -> List[ElectionInstanceV2]:
    """Collect group-wide election register events.

    Source priority:
      1) req.group_elections (preferred)
      2) elections recorded on individual Tested Jurisdictions for group-wide codes (backwards compatibility)
    """

    events: List[ElectionInstanceV2] = list(req.group_elections or [])

    # Backwards compatible: if users recorded group elections inside tj.elections, pull them in.
    for tj in req.tested_jurisdictions:
        for e in (tj.elections or []):
            if e.election_code in _GROUP_WIDE_ELECTION_CODES:
                events.append(e)

    # De-duplicate; conflicts are errors.
    return _dedupe_election_register(events, context="group_elections")


def _is_group_election_effective(
    register: List[ElectionInstanceV2],
    *,
    election_code: str,
    fiscal_year_start: date,
) -> bool:
    effective = resolve_effective_elections(register, fiscal_year_start=fiscal_year_start)
    return bool(get_effective_election_bool(effective, election_code) or False)




def _apply_transfer_pricing_adjustments_register(
    works: Dict[str, _TJWork],
    req: CalculationRequestV2,
    *,
    fy_start: date,
    reporting_currency: Optional[str],
    group_election_register: List[ElectionInstanceV2],
) -> None:
    """Apply explicit transfer pricing adjustment register entries (OECD section 5.2).

    This is separate from Box 4.6 after-year-end adjustments. Each register entry links a seller and buyer
    Tested Jurisdiction and can include income and tax adjustments in one coherent record.

    Timing:
      - Default (Box 5.2(1)): accrual-year method (include in accrual_year_fy_start)
      - Optional Five-Year election (Box 5.2(2)): if the adjustment accrues within 12 months after the end of the
        transaction year and the group-wide TP election is effective for the transaction year, include in the
        transaction year instead.

    Counterparty treatment:
      - If buyer_income_adjustment is omitted, it defaults to -seller_income_adjustment (symmetry).
      - buyer_tax_adjustment defaults to 0.0 when omitted.
    """

    tps = getattr(req, "transfer_pricing_adjustments", None) or []
    if not tps:
        return

    # Cache election effectiveness by transaction year
    election_cache_tp: Dict[date, bool] = {}

    for tp in tps:
        seller_id = tp.seller_tested_jurisdiction_id
        buyer_id = tp.buyer_tested_jurisdiction_id

        if seller_id not in works:
            raise ValueError(
                f"Transfer pricing adjustment '{tp.label or tp.adjustment_id or ''}': seller_tested_jurisdiction_id '{seller_id}' not found."
            )
        if buyer_id not in works:
            raise ValueError(
                f"Transfer pricing adjustment '{tp.label or tp.adjustment_id or ''}': buyer_tested_jurisdiction_id '{buyer_id}' not found."
            )

        seller_w = works[seller_id]
        buyer_w = works[buyer_id]

        # Determine within-12-months flag
        within: Optional[bool] = None
        if tp.accrued_within_12_months is not None:
            within = bool(tp.accrued_within_12_months)
        elif tp.months_after_transaction_year_end is not None:
            within = int(tp.months_after_transaction_year_end) <= 12
        else:
            within = None

        # Determine whether transaction-year method applies (Box 5.2(2))
        ty = tp.transaction_year_fy_start
        elect_applies = False
        if within is True:
            if ty not in election_cache_tp:
                election_cache_tp[ty] = _is_group_election_effective(
                    group_election_register,
                    election_code="TP_FIVE_YEAR_ELECTION_TRANSACTION_YEAR_METHOD",
                    fiscal_year_start=ty,
                )
            elect_applies = bool(election_cache_tp[ty])

        included_year = tp.transaction_year_fy_start if elect_applies else tp.accrual_year_fy_start
        if included_year != fy_start:
            continue

        # Currency / scale defaults (use seller as anchor)
        adj_currency = tp.currency or seller_w.input_currency or reporting_currency
        adj_scale = tp.amount_scale or (seller_w.amount_scale if seller_w.amount_scale is not None else "UNITS")

        label = tp.label or tp.adjustment_id or "Transfer pricing adjustment"

        base_note = (
            "Included in transaction year under Box 5.2(2) Five-Year election."
            if elect_applies
            else "Included in accrual year under Box 5.2(1) default timing."
        )
        if within is None:
            base_note += " (Within-12-months not specified; election not applied.)"

        # Special-case flags audit metadata
        specials: List[str] = []
        if getattr(tp, "tp_accounted_at_cost", False):
            specials.append("accounted-at-cost")
        if getattr(tp, "tp_intangible_asset_related", False):
            specials.append("intangible")
        if getattr(tp, "tp_loss_disallowed_deemed_tp_adjustment", False):
            specials.append("deemed-loss-adjustment")
        if specials:
            base_note += " TP flags: " + ", ".join(specials)

        # -------------------------
        # Income adjustments (P&L)
        # -------------------------
        seller_income_converted = 0.0
        seller_income_fx_note = None

        if float(tp.seller_income_adjustment or 0.0) != 0.0:
            seller_income_converted, seller_income_fx_note = _convert_amount_fx(
                req,
                amount=float(tp.seller_income_adjustment),
                currency=adj_currency,
                amount_scale=str(adj_scale) if adj_scale is not None else None,
                reporting_currency=reporting_currency,
                fy_start=fy_start,
                use_spot=False,
            )
            note = base_note + (f" FX: {seller_income_fx_note}" if seller_income_fx_note else "")
            seller_w.simplified_income += float(seller_income_converted)
            seller_w.trace.append(
                TraceLine(
                    section="income",
                    step=f"Transfer pricing register (section 5.2): {label} (seller income)",
                    amount=float(seller_income_converted),
                    note=note,
                )
            )

        # Buyer income adjustment (explicit or default symmetry)
        buyer_income_raw = tp.buyer_income_adjustment
        if buyer_income_raw is not None:
            buyer_income_converted, buyer_income_fx_note = _convert_amount_fx(
                req,
                amount=float(buyer_income_raw),
                currency=adj_currency,
                amount_scale=str(adj_scale) if adj_scale is not None else None,
                reporting_currency=reporting_currency,
                fy_start=fy_start,
                use_spot=False,
            )
            note = base_note + " (Buyer income amount provided.)"
            if buyer_income_fx_note:
                note += f" FX: {buyer_income_fx_note}"
            if float(buyer_income_converted) != 0.0:
                buyer_w.simplified_income += float(buyer_income_converted)
                buyer_w.trace.append(
                    TraceLine(
                        section="income",
                        step=f"Transfer pricing register (section 5.2): {label} (buyer income)",
                        amount=float(buyer_income_converted),
                        note=note,
                    )
                )
        else:
            # Default to negative of the seller-converted amount (symmetry) where seller income exists.
            if float(seller_income_converted) != 0.0:
                buyer_income_converted = -float(seller_income_converted)
                note = base_note + " (Buyer income defaults to -seller income.)"
                buyer_w.simplified_income += float(buyer_income_converted)
                buyer_w.trace.append(
                    TraceLine(
                        section="income",
                        step=f"Transfer pricing register (section 5.2): {label} (buyer income)",
                        amount=float(buyer_income_converted),
                        note=note,
                    )
                )

        # -----------------------
        # Tax adjustments (P&L)
        # -----------------------
        if float(tp.seller_tax_adjustment or 0.0) != 0.0:
            seller_tax_converted, seller_tax_fx_note = _convert_amount_fx(
                req,
                amount=float(tp.seller_tax_adjustment),
                currency=adj_currency,
                amount_scale=str(adj_scale) if adj_scale is not None else None,
                reporting_currency=reporting_currency,
                fy_start=fy_start,
                use_spot=False,
            )
            note = base_note + (f" FX: {seller_tax_fx_note}" if seller_tax_fx_note else "")
            seller_w.simplified_taxes += float(seller_tax_converted)
            seller_w.trace.append(
                TraceLine(
                    section="tax",
                    step=f"Transfer pricing register (section 5.2): {label} (seller tax)",
                    amount=float(seller_tax_converted),
                    note=note,
                )
            )

        buyer_tax_raw = tp.buyer_tax_adjustment
        if buyer_tax_raw is not None and float(buyer_tax_raw) != 0.0:
            buyer_tax_converted, buyer_tax_fx_note = _convert_amount_fx(
                req,
                amount=float(buyer_tax_raw),
                currency=adj_currency,
                amount_scale=str(adj_scale) if adj_scale is not None else None,
                reporting_currency=reporting_currency,
                fy_start=fy_start,
                use_spot=False,
            )
            note = base_note + " (Buyer tax amount provided.)"
            if buyer_tax_fx_note:
                note += f" FX: {buyer_tax_fx_note}"
            buyer_w.simplified_taxes += float(buyer_tax_converted)
            buyer_w.trace.append(
                TraceLine(
                    section="tax",
                    step=f"Transfer pricing register (section 5.2): {label} (buyer tax)",
                    amount=float(buyer_tax_converted),
                    note=note,
                )
            )



def _apply_after_year_end_adjustments(
    works: Dict[str, _TJWork],
    req: CalculationRequestV2,
    *,
    fy_start: date,
    reporting_currency: Optional[str],
    group_election_register: List[ElectionInstanceV2],
) -> Dict[str, List[_AYEApplied]]:
    """Apply OECD Box 4.6 after-year-end adjustments to Simplified Income/Taxes.

    This function handles:
      - Box 4.6 after-year-end adjustments (non-TP) under Box 4.6(1) default and Box 4.6(2) timing election.
      - Transfer pricing-related after-year-end adjustments (is_transfer_pricing_related=True) are handled under OECD
        section 5.2 timing rules (Box 5.2(1) default and Box 5.2(2) timing election) and apply structured counterparty
        treatment where tp_counterparty_tested_jurisdiction_id is provided.

    Returns a map of applied non-TP Box 4.6 adjustments (only those included in the current FY) for downstream
    Box 4.6(3) processing (qualified refund exclusion).
    """

    applied: Dict[str, List[_AYEApplied]] = {}
    if not req.after_year_end_adjustments:
        return applied

    # Cache election effectiveness by transaction-year start (because we may look back for revocation-year cases)
    election_cache_box46: Dict[date, bool] = {}
    election_cache_tp: Dict[date, bool] = {}

    for adj in req.after_year_end_adjustments:
        tj_id = adj.tested_jurisdiction_id
        if tj_id not in works:
            raise ValueError(
                f"After-year-end adjustment '{adj.label or adj.adjustment_id or ''}': tested_jurisdiction_id '{tj_id}' not found."
            )

        w = works[tj_id]

        # Determine within-12-months flag
        within: Optional[bool] = None
        if adj.accrued_within_12_months is not None:
            within = bool(adj.accrued_within_12_months)
        elif adj.months_after_transaction_year_end is not None:
            within = int(adj.months_after_transaction_year_end) <= 12
        else:
            within = None  # unknown

        # ------------------------------------------------------------
        # Transfer pricing-related adjustments: apply OECD section 5.2
        # ------------------------------------------------------------
        if adj.is_transfer_pricing_related:
            ty = adj.transaction_year_fy_start

            tp_elect_applies = False
            if within is True:
                if ty not in election_cache_tp:
                    election_cache_tp[ty] = _is_group_election_effective(
                        group_election_register,
                        election_code="TP_FIVE_YEAR_ELECTION_TRANSACTION_YEAR_METHOD",
                        fiscal_year_start=ty,
                    )
                tp_elect_applies = bool(election_cache_tp[ty])

            tp_included_year = adj.transaction_year_fy_start if tp_elect_applies else adj.accrual_year_fy_start

            if tp_included_year != fy_start:
                continue

            adj_currency = adj.currency or w.input_currency or reporting_currency
            adj_scale = adj.amount_scale or (w.amount_scale if w.amount_scale is not None else "UNITS")

            converted, fx_note = _convert_amount_fx(
                req,
                amount=float(adj.amount),
                currency=adj_currency,
                amount_scale=str(adj_scale) if adj_scale is not None else None,
                reporting_currency=reporting_currency,
                fy_start=fy_start,
                use_spot=False,  # P&L convention
            )

            label = adj.label or adj.adjustment_id or "Transfer pricing adjustment"
            base_note = (
                "Included in transaction year under Box 5.2(2) Five-Year election."
                if tp_elect_applies
                else "Included in accrual year under Box 5.2(1) default timing."
            )
            if within is None:
                base_note += " (Within-12-months not specified; election not applied.)"
            if fx_note:
                base_note += f" FX: {fx_note}"

            # Add audit notes for special-case flags
            specials: List[str] = []
            if getattr(adj, "tp_accounted_at_cost", False):
                specials.append("accounted-at-cost")
            if getattr(adj, "tp_intangible_asset_related", False):
                specials.append("intangible")
            if getattr(adj, "tp_loss_disallowed_deemed_tp_adjustment", False):
                specials.append("deemed-loss-adjustment")
            if specials:
                base_note += " TP flags: " + ", ".join(specials)

            if adj.kind == "income":
                # Primary side
                w.simplified_income += float(converted)
                w.trace.append(
                    TraceLine(
                        section="income",
                        step=f"Transfer pricing adjustment (Box 5.2): {label} (primary)",
                        amount=float(converted),
                        note=base_note,
                    )
                )

                # Counterparty symmetry (default on)
                if getattr(adj, "tp_apply_counterparty_income", True):
                    cp_id = getattr(adj, "tp_counterparty_tested_jurisdiction_id", None)
                    if cp_id:
                        if cp_id not in works:
                            raise ValueError(
                                f"Transfer pricing adjustment '{label}': tp_counterparty_tested_jurisdiction_id '{cp_id}' not found."
                            )
                        cp_w = works[cp_id]

                        if getattr(adj, "tp_counterparty_income_amount", None) is not None:
                            cp_amt_raw = float(getattr(adj, "tp_counterparty_income_amount"))
                            cp_converted, cp_fx_note = _convert_amount_fx(
                                req,
                                amount=cp_amt_raw,
                                currency=adj_currency,
                                amount_scale=str(adj_scale) if adj_scale is not None else None,
                                reporting_currency=reporting_currency,
                                fy_start=fy_start,
                                use_spot=False,
                            )
                            cp_note = base_note + " (Counterparty income amount provided.)"
                            if cp_fx_note and cp_fx_note != fx_note:
                                cp_note += f" FX: {cp_fx_note}"
                            cp_delta = float(cp_converted)
                        else:
                            cp_delta = -float(converted)
                            cp_note = base_note + " (Counterparty income defaults to -primary amount.)"

                        cp_w.simplified_income += float(cp_delta)
                        cp_w.trace.append(
                            TraceLine(
                                section="income",
                                step=f"Transfer pricing adjustment (Box 5.2): {label} (counterparty)",
                                amount=float(cp_delta),
                                note=cp_note,
                            )
                        )
                    else:
                        w.trace.append(
                            TraceLine(
                                section="income",
                                step=f"Transfer pricing adjustment (Box 5.2): {label} (counterparty not specified)",
                                amount=0.0,
                                note="No tp_counterparty_tested_jurisdiction_id provided; no counterparty income adjustment applied.",
                            )
                        )
            else:
                # Tax side
                w.simplified_taxes += float(converted)
                w.trace.append(
                    TraceLine(
                        section="tax",
                        step=f"Transfer pricing tax adjustment (Box 5.2): {label} (primary)",
                        amount=float(converted),
                        note=base_note,
                    )
                )

                cp_tax_raw = getattr(adj, "tp_counterparty_tax_amount", None)
                cp_id = getattr(adj, "tp_counterparty_tested_jurisdiction_id", None)
                if cp_tax_raw is not None:
                    if not cp_id:
                        raise ValueError(
                            f"Transfer pricing tax adjustment '{label}': tp_counterparty_tax_amount provided but tp_counterparty_tested_jurisdiction_id is missing."
                        )
                    if cp_id not in works:
                        raise ValueError(
                            f"Transfer pricing tax adjustment '{label}': tp_counterparty_tested_jurisdiction_id '{cp_id}' not found."
                        )
                    cp_w = works[cp_id]
                    cp_converted, cp_fx_note = _convert_amount_fx(
                        req,
                        amount=float(cp_tax_raw),
                        currency=adj_currency,
                        amount_scale=str(adj_scale) if adj_scale is not None else None,
                        reporting_currency=reporting_currency,
                        fy_start=fy_start,
                        use_spot=False,
                    )
                    cp_note = base_note + " (Counterparty tax amount provided.)"
                    if cp_fx_note and cp_fx_note != fx_note:
                        cp_note += f" FX: {cp_fx_note}"
                    cp_w.simplified_taxes += float(cp_converted)
                    cp_w.trace.append(
                        TraceLine(
                            section="tax",
                            step=f"Transfer pricing tax adjustment (Box 5.2): {label} (counterparty)",
                            amount=float(cp_converted),
                            note=cp_note,
                        )
                    )

            # TP adjustments are not part of Box 4.6(3) qualified refund processing.
            continue

        # ------------------------------------------------------------
        # Non-TP adjustments: apply OECD Box 4.6
        # ------------------------------------------------------------

        # Determine if the group-wide 12-month election applies for the transaction year
        elect_applies = False
        if within is True:
            ty = adj.transaction_year_fy_start
            if ty not in election_cache_box46:
                election_cache_box46[ty] = _is_group_election_effective(
                    group_election_register,
                    election_code="AFTER_YEAR_END_ADJUSTMENTS_FIVE_YEAR_ELECTION_TRANSACTION_YEAR_METHOD",
                    fiscal_year_start=ty,
                )
            elect_applies = bool(election_cache_box46[ty])

        inclusion_method = "TRANSACTION_YEAR" if elect_applies else "ACCRUAL_YEAR"
        included_year = adj.transaction_year_fy_start if elect_applies else adj.accrual_year_fy_start

        # Only apply the portion that belongs in the current FY
        if included_year != fy_start:
            continue

        # Determine currency / scale defaults for this adjustment
        adj_currency = adj.currency or w.input_currency or reporting_currency
        adj_scale = adj.amount_scale or (w.amount_scale if w.amount_scale is not None else "UNITS")

        converted, fx_note = _convert_amount_fx(
            req,
            amount=float(adj.amount),
            currency=adj_currency,
            amount_scale=str(adj_scale) if adj_scale is not None else None,
            reporting_currency=reporting_currency,
            fy_start=fy_start,
            use_spot=False,  # P&L convention
        )

        label = adj.label or adj.adjustment_id or "After-year-end adjustment"
        base_note = (
            "Included in transaction year under Box 4.6(2) Five-Year election."
            if elect_applies
            else "Included in accrual year under Box 4.6(1) default timing."
        )

        if within is None:
            base_note = base_note + " (Within-12-months not specified; election not applied.)"

        if fx_note:
            base_note = base_note + f" FX: {fx_note}"

        # Apply to TJ totals
        if adj.kind == "income":
            w.simplified_income += float(converted)
            w.trace.append(
                TraceLine(
                    section="income",
                    step=f"After-year-end adjustment (Box 4.6): {label}",
                    amount=float(converted),
                    note=base_note,
                )
            )
        else:
            w.simplified_taxes += float(converted)
            w.trace.append(
                TraceLine(
                    section="tax",
                    step=f"After-year-end adjustment (Box 4.6): {label}",
                    amount=float(converted),
                    note=base_note,
                )
            )

        applied.setdefault(tj_id, []).append(
            _AYEApplied(
                tj_id=tj_id,
                adjustment=adj,
                amount_reporting_currency=float(converted),
                included_in_fy_start=included_year,
                inclusion_method=inclusion_method,
                within_12_months=within,
            )
        )

    return applied


def _qualified_refund_condition_met(
    adj: AfterYearEndAdjustmentV2,
    *,
    minimum_rate: float,
) -> tuple[bool, str]:
    """Evaluate Box 4.6(3) condition (a)/(b) in a pragmatic way.

    This engine is stateless and does not automatically recompute prior-year Simplified ETR / GloBE ETR.
    Therefore:
      - If qualification_basis='SIMPLIFIED_ETR' and the prior-year Simplified Income/Taxes are provided,
        we compute the post-adjustment Simplified ETR check.
      - Otherwise, we rely on user attestation.
    """

    basis = adj.qualification_basis
    if basis == "SIMPLIFIED_ETR":
        income = float(adj.prior_year_simplified_income or 0.0)
        taxes = float(adj.prior_year_simplified_taxes or 0.0)
        dte = float(adj.prior_year_deferred_tax_effect or 0.0)
        adjusted_taxes = taxes + float(adj.amount) + dte

        if income <= 0:
            return True, "Prior (transaction) year has non-positive Simplified Income; condition treated as met."
        etr = adjusted_taxes / income if income != 0 else 0.0
        return bool(etr >= float(minimum_rate)), f"Computed prior-year Simplified ETR after adjustment = {etr:.6f}"

    # GLOBE_ETR or ATTESTATION
    if adj.attestation_prior_year_etr_not_below_minimum is True:
        return True, "Attested that prior-year ETR after adjustment is not below Minimum Rate."

    return False, "Attestation missing/false for Box 4.6(3) qualification."


def _apply_transition_year_adjustments(
    work: _TJWork,
    req: CalculationRequestV2,
    *,
    fy_start: date,
    minimum_rate: float,
) -> Optional[TransitionYearStateV2]:
    """Apply Transition Year rules (Box 4.5) to a Tested Jurisdiction.

    v4 Module 4 introduced Transition Year mechanics (stateless).
    v4 Module 4.1 upgrades this to "multi-year stateful" behaviour by:
      - returning a TransitionYearStateV2 payload in the result, and
      - allowing that payload to be supplied in subsequent-year requests as
        tested_jurisdiction.transition_year_state_opening.

    In this module we implement *statefulness* without adding server-side persistence.

    Implemented mechanics (current scope):
      - Article 9.1.2: disallowed opening DTAs (Transition Year only)
      - Article 9.1.3: structured net adjustments (Transition Year and later years)

    Currency conventions:
      - Opening DTAs/DTLs are balance-sheet items -> spot FX (fallback to avg)
      - 9.1.3 income/tax adjustments are P&L items -> avg FX
    """

    ty = getattr(work.tj, 'transition_year', None)
    st_open = getattr(work.tj, 'transition_year_state_opening', None)

    if ty is None and st_open is None:
        return None

    # Determine Transition Year start date.
    ty_start = None
    if ty is not None and getattr(ty, 'transition_year_fy_start', None) is not None:
        ty_start = ty.transition_year_fy_start
    elif st_open is not None and getattr(st_open, 'transition_year_fy_start', None) is not None:
        ty_start = st_open.transition_year_fy_start
    else:
        ty_start = fy_start
        work.trace.append(
            TraceLine(
                section='eligibility',
                step='Transition Year start date assumed',
                amount=0.0,
                note='No Transition Year FY start date was provided (neither transition_year nor transition_year_state_opening). Assuming the current fiscal year is the Transition Year for this Tested Jurisdiction.',
            )
        )

    work.transition_year_fy_start = ty_start
    work.is_transition_year = bool(fy_start == ty_start)

    # Describe the context in trace for audit.
    if fy_start < ty_start:
        status = 'pre-Transition Year'
    elif fy_start == ty_start:
        status = 'Transition Year'
    else:
        status = 'post-Transition Year'

    work.trace.append(
        TraceLine(
            section='eligibility',
            step='Transition Year context (Box 4.5)',
            amount=0.0,
            note=f'Transition Year FY start={ty_start}. Current FY start={fy_start} => {status}.',
        )
    )

    # State currency: we persist amounts in the currency that the computation is using.
    # If reporting currency is set, that is the state currency; otherwise it is the TJ input currency.
    state_currency = (work.reporting_currency or work.input_currency or None)
    if st_open is not None and getattr(st_open, 'state_currency', None) and state_currency:
        if str(st_open.state_currency).upper().strip() != str(state_currency).upper().strip():
            raise ValueError(
                f"Transition Year state currency mismatch for {work.bucket_id}: state_currency={st_open.state_currency} but current computation currency={state_currency}. "
                "Use the same reporting currency/currency basis as the year the state was generated, or regenerate the state." 
            )

    register_items: list[TransitionDeferredTaxRegisterItemV2] = []
    used_state_register = False

    # Prefer explicit TransitionYearV2 opening items when provided.
    opening_items = []
    if ty is not None and getattr(ty, 'opening_deferred_tax_items', None):
        opening_items = list(ty.opening_deferred_tax_items or [])

    if opening_items:
        # Compute the register from explicit opening items.
        for item in opening_items:
            src_cur = getattr(item, 'currency', None) or work.input_currency or work.reporting_currency
            src_scale = getattr(item, 'amount_scale', None)

            base_amt = getattr(item, 'opening_balance_at_minimum_rate', None)
            was_min_basis = base_amt is not None
            if base_amt is None:
                base_amt = float(getattr(item, 'opening_balance', 0.0) or 0.0)

            converted_bs, fx_note = _convert_amount_with_fx(
                req,
                amount=float(base_amt),
                currency=str(src_cur).upper().strip() if src_cur else None,
                amount_scale=src_scale,
                fy_start=fy_start,
                reporting_currency=work.reporting_currency,
                use_spot=True,
            )

            opening_balance_state = float(converted_bs)

            # Compute minimum-rate basis amount.
            opening_min = float(opening_balance_state)
            tax_rate_used = None
            if not was_min_basis:
                tax_rate = getattr(item, 'tax_rate', None)
                if tax_rate is None and work.tj.facts is not None and getattr(work.tj.facts, 'accounted_tax_rate', None) is not None:
                    tax_rate = float(work.tj.facts.accounted_tax_rate)
                if tax_rate is not None:
                    tax_rate_used = float(tax_rate)
                if tax_rate is not None and float(tax_rate) > 0 and float(tax_rate) > float(minimum_rate):
                    opening_min = float(opening_min) * (float(minimum_rate) / float(tax_rate))

            # Apply 9.1.2: disallowed opening DTA treated as 0.
            disallowed = bool(getattr(item, 'disallowed_under_article_9_1_2', False))
            allowed_opening_min = float(opening_min)
            if getattr(item, 'item_type', None) == 'DTA' and disallowed:
                allowed_opening_min = 0.0

            adjustment = float(opening_min) - float(allowed_opening_min)

            reg = TransitionDeferredTaxRegisterItemV2(
                item_id=getattr(item, 'item_id', None),
                label=getattr(item, 'label', None),
                item_type=getattr(item, 'item_type', None),
                category=getattr(item, 'category', 'TEMPORARY_DIFFERENCE') or 'TEMPORARY_DIFFERENCE',
                disallowed_under_article_9_1_2=disallowed,
                opening_balance_state_currency=float(opening_balance_state),
                opening_balance_minimum_rate_state_currency=float(opening_min),
                allowed_opening_balance_minimum_rate_state_currency=float(allowed_opening_min),
                disallowed_adjustment_state_currency=float(adjustment),
                tax_rate_used=tax_rate_used,
                was_provided_at_minimum_rate=bool(was_min_basis),
                fx_note=fx_note,
                source_currency=(str(src_cur).upper().strip() if src_cur else None),
                source_amount_scale=(src_scale or 'UNITS'),
                note=getattr(item, 'note', None),
            )
            register_items.append(reg)

            # Apply Transition Year tax adjustment in Transition Year only.
            if fy_start == ty_start and adjustment != 0.0:
                work.simplified_taxes += float(adjustment)
                work.trace.append(
                    TraceLine(
                        section='tax',
                        step='Transition Year: disallowed opening DTA adjustment (Art 9.1.2)',
                        amount=float(adjustment),
                        running_total=float(work.simplified_taxes),
                        note=((getattr(item, 'label', None) or getattr(item, 'item_id', None) or 'Opening deferred tax item') + ((' | ' + fx_note) if fx_note else '')),
                    )
                )

        work.trace.append(
            TraceLine(
                section='eligibility',
                step='Transition Year state generated',
                amount=0.0,
                note='Computed Transition Year deferred-tax register from transition_year.opening_deferred_tax_items.',
            )
        )

    elif st_open is not None and getattr(st_open, 'opening_deferred_tax_register', None):
        # Use the carried state register.
        register_items = list(st_open.opening_deferred_tax_register or [])
        used_state_register = True

        work.trace.append(
            TraceLine(
                section='eligibility',
                step='Transition Year state loaded',
                amount=0.0,
                note='Using transition_year_state_opening.opening_deferred_tax_register as the Transition Year deferred-tax register.',
            )
        )

        # Apply Transition Year tax adjustment in Transition Year only.
        if fy_start == ty_start:
            for reg in register_items:
                adj = float(getattr(reg, 'disallowed_adjustment_state_currency', 0.0) or 0.0)
                if adj != 0.0:
                    work.simplified_taxes += float(adj)
                    work.trace.append(
                        TraceLine(
                            section='tax',
                            step='Transition Year: disallowed opening DTA adjustment (Art 9.1.2) [state]',
                            amount=float(adj),
                            running_total=float(work.simplified_taxes),
                            note=(getattr(reg, 'label', None) or getattr(reg, 'item_id', None) or 'Opening deferred tax item (state)'),
                        )
                    )

    else:
        # Transition Year present but no opening register data supplied.
        work.trace.append(
            TraceLine(
                section='eligibility',
                step='Transition Year deferred-tax register missing',
                amount=0.0,
                note='Transition Year is configured, but no opening deferred tax items were provided and no prior Transition Year state register was supplied.',
            )
        )

    # 2) Article 9.1.3 transfers — apply from Transition Year onwards (fy_start >= ty_start).
    if ty is not None and fy_start >= ty_start and getattr(ty, 'article_9_1_3_transfers', None):
        for tr in (ty.article_9_1_3_transfers or []):
            cur = getattr(tr, 'currency', None) or work.input_currency or work.reporting_currency
            scale = getattr(tr, 'amount_scale', None)

            inc_adj, fx_note_i = _convert_amount_with_fx(
                req,
                amount=float(getattr(tr, 'income_adjustment', 0.0) or 0.0),
                currency=str(cur).upper().strip() if cur else None,
                amount_scale=scale,
                fy_start=fy_start,
                reporting_currency=work.reporting_currency,
                use_spot=False,
            )
            tax_adj, fx_note_t = _convert_amount_with_fx(
                req,
                amount=float(getattr(tr, 'tax_adjustment', 0.0) or 0.0),
                currency=str(cur).upper().strip() if cur else None,
                amount_scale=scale,
                fy_start=fy_start,
                reporting_currency=work.reporting_currency,
                use_spot=False,
            )

            if inc_adj != 0.0:
                work.simplified_income += float(inc_adj)
                work.trace.append(
                    TraceLine(
                        section='income',
                        step='Article 9.1.3 transfer adjustment',
                        amount=float(inc_adj),
                        running_total=float(work.simplified_income),
                        note=((tr.label or tr.transfer_id or 'Transfer') + ((' | ' + fx_note_i) if fx_note_i else '') + ((' | ' + tr.note) if tr.note else '')),
                    )
                )

            if tax_adj != 0.0:
                work.simplified_taxes += float(tax_adj)
                work.trace.append(
                    TraceLine(
                        section='tax',
                        step='Article 9.1.3 transfer adjustment',
                        amount=float(tax_adj),
                        running_total=float(work.simplified_taxes),
                        note=((tr.label or tr.transfer_id or 'Transfer') + ((' | ' + fx_note_t) if fx_note_t else '') + ((' | ' + tr.note) if tr.note else '')),
                    )
                )

    # Build closing state (carry forward).
    if used_state_register and st_open is not None:
        st = st_open.model_copy()
        st.transition_year_fy_start = ty_start
        st.state_currency = state_currency
        # Preserve computed_in_fiscal_year_start if already set; otherwise set to current FY
        if getattr(st, 'computed_in_fiscal_year_start', None) is None:
            st.computed_in_fiscal_year_start = fy_start
        work.transition_year_state_closing = st
        return st

    st = TransitionYearStateV2(
        transition_year_fy_start=ty_start,
        state_currency=state_currency,
        computed_in_fiscal_year_start=fy_start,
        opening_deferred_tax_register=register_items,
        note='Generated from transition_year inputs' if register_items else None,
    )
    work.transition_year_state_closing = st
    return st



# ---------------------------------------------------------------------------
# Section 6 deemed-zero automation (v4 module 7)
# ---------------------------------------------------------------------------

def _near_zero(x: float, tol: float) -> bool:
    return abs(float(x)) <= float(tol)


def _auto_deemed_zero_determination(work: _TJWork, req: CalculationRequestV2) -> tuple[bool, Optional[str], Optional[str]]:
    """Determine whether Section 6 deemed-zero should apply automatically for a Tested Jurisdiction.

    Returns: (should_apply, basis, reason)
    """
    opts = getattr(req, "deemed_zero_automation", None)
    if opts is None:
        enable = True
        tol = 1e-6
        qp_threshold = 0.9999
    else:
        enable = bool(getattr(opts, "enable_auto_deemed_zero", True))
        tol = float(getattr(opts, "zero_tolerance", 1e-6))
        qp_threshold = float(getattr(opts, "qualified_persons_threshold", 0.9999))

    if not enable:
        return False, None, None

    tj = work.tj
    ents = list(getattr(tj, "entities", None) or [])
    if not ents:
        return False, None, None

    types = [str(getattr(e, "entity_type", "STANDARD_CE") or "STANDARD_CE") for e in ents]

    # Section 6.2: Tax transparent / flow-through buckets (income & taxes allocated out under section 5.1)
    if all(t in {"FLOW_THROUGH_ENTITY", "TAX_TRANSPARENT_ENTITY"} for t in types):
        post_income = float(work.simplified_income_post_allocations if work.simplified_income_post_allocations is not None else work.simplified_income)
        post_taxes = float(work.simplified_taxes_post_allocations if work.simplified_taxes_post_allocations is not None else work.simplified_taxes)
        if _near_zero(post_income, tol) and _near_zero(post_taxes, tol):
            return (
                True,
                "SECTION_6_2_TAX_TRANSPARENT",
                "Section 6.2: all entities in this Tested Jurisdiction are tax transparent/flow-through and post-allocation income and taxes are (effectively) zero.",
            )

    # Section 6.1: Tax-Neutral UPE bucket held entirely by Qualified Persons
    if all(t == "TAX_NEUTRAL_UPE" for t in types):
        for e in ents:
            qp = getattr(e, "qualified_persons_ownership_percentage", None)
            if qp is None or float(qp) < qp_threshold:
                return False, None, None
        return (
            True,
            "SECTION_6_1_TAX_NEUTRAL_UPE",
            "Section 6.1: Tax-Neutral UPE held entirely by Qualified Persons (ownership threshold met).",
        )

    return False, None, None

def calculate_v2(req: CalculationRequestV2) -> CalculationResponseV2:
    fy_start = req.fiscal_year.start_date

    reporting_currency: Optional[str] = None
    if req.group_profile and req.group_profile.reporting_currency:
        reporting_currency = str(req.group_profile.reporting_currency).upper().strip() or None

    # ------------------------------------------------------------------
    # Article 7.3 Deemed Distribution Tax Recapture Account (v4 module 14)
    # ------------------------------------------------------------------
    ddt_opening_by_tj: Dict[str, DDTRecaptureAccountStateV2] = {
        s.tested_jurisdiction_id: s for s in (getattr(req, "ddt_recapture_account_state_opening", None) or [])
    }
    ddt_moves_by_tj: Dict[str, List[DDTRecaptureAccountMovementV2]] = {}
    for m in (getattr(req, "ddt_recapture_account_movements", None) or []):
        # Only apply movements for the fiscal year being calculated.
        if m.fiscal_year_start != fy_start:
            continue
        ddt_moves_by_tj.setdefault(m.tested_jurisdiction_id, []).append(m)

    ddt_state_closing_by_tj: Dict[str, DDTRecaptureAccountStateV2] = {}

    # -----------------------------
    # First pass: compute base numbers per Tested Jurisdiction (pre cross-border / owner addbacks)
    # -----------------------------
    works: Dict[str, _TJWork] = {}
    for tj in req.tested_jurisdictions:
        bucket_id = tj.tested_jurisdiction_id

        # Currency translation / amount scaling (v4 module 2)
        basis = tj.accounting_basis
        input_currency = (basis.currency or reporting_currency)
        if input_currency is not None:
            input_currency = str(input_currency).upper().strip() or None
        amount_scale = basis.amount_scale
        scale_mult = _scale_multiplier(amount_scale)

        # FX translation conventions (v4 module 3)
        # - P&L items use average FX
        # - balance sheet items use spot/closing FX (when available; otherwise avg is used as a fallback)
        fx_avg = 1.0
        fx_spot = 1.0
        spot_provided = True
        if reporting_currency and input_currency and input_currency != reporting_currency:
            r_avg = _fx_lookup_avg(req, input_currency, fy_start)
            if r_avg is None:
                raise ValueError(
                    f"Missing FX rate for currency '{input_currency}' to reporting currency '{reporting_currency}' for FY start {fy_start}. "
                    "Provide request.fx_rates with avg_rate_to_reporting."
                )
            fx_avg = float(r_avg)
            r_spot = _fx_lookup_spot(req, input_currency, fy_start)
            if r_spot is None:
                # No spot provided; we keep going using avg as a fallback for balance sheet items.
                fx_spot = float(fx_avg)
                spot_provided = False
            else:
                fx_spot = float(r_spot)

        currency_multiplier_pl = float(scale_mult) * float(fx_avg)
        currency_multiplier_bs = float(scale_mult) * float(fx_spot)

        # Box 7.2 entry/re-entry automation (Module 8)
        entry_eval = evaluate_entry_reentry(req, tj, current_fy_start=fy_start)

        # Determine input mode
        m = tj.composition.aggregation_method
        if m == "JURISDICTION_FACTS":
            input_mode = "jurisdiction"
        elif m == "ENTITY_ROLLUP":
            input_mode = "entity_rollup"
        else:
            # MIXED: if entities exist, roll-up; else jurisdiction facts
            input_mode = "entity_rollup" if tj.entities else "jurisdiction"

        meta, effective_elections, election_trace, conversion_trace = _build_meta_row(
            tj,
            bucket_id,
            fy_start,
            currency_multiplier_pl=currency_multiplier_pl,
            reporting_currency=reporting_currency,
            input_currency=input_currency,
            fx_rate_avg=fx_avg,
            fx_rate_spot=fx_spot,
            spot_rate_provided=spot_provided,
            amount_scale=amount_scale,
            entry_no_topup_override=entry_eval.no_topup_override,
            reentry_no_topup_override=entry_eval.reentry_override,
        )

        # ------------------------------------------------------------------
        # Module 14: auto-detect Investment Entity tested jurisdictions
        # ------------------------------------------------------------------
        inv_entity_types = {"INVESTMENT_ENTITY", "INSURANCE_INVESTMENT_ENTITY"}
        tj_type = (tj.tested_jurisdiction_type or "").strip().lower()
        is_inv_bucket = tj_type in {"investment_entity", "insurance_investment_entity"}
        has_inv_entity = any((getattr(e, "entity_type", None) in inv_entity_types) for e in (tj.entities or []))

        if is_inv_bucket or has_inv_entity:
            # Mark as an ineligible tested jurisdiction category (Box 7.1); the exception is handled via
            # meta.investment_entity_tax_transparency_election_applies (Section 6.3 / Art 7.5).
            meta.ineligible_investment_entity = True
            if is_inv_bucket:
                conversion_trace.append(
                    TraceLine(
                        section="eligibility",
                        step="Auto-detected investment entity Tested Jurisdiction",
                        amount=0.0,
                        note="tested_jurisdiction_type indicates an investment entity bucket (Box 7.1).",
                    )
                )
            else:
                conversion_trace.append(
                    TraceLine(
                        section="eligibility",
                        step="Investment entity detected inside Tested Jurisdiction",
                        amount=0.0,
                        note=(
                            "One or more entities are classified as INVESTMENT_ENTITY/INSURANCE_INVESTMENT_ENTITY. "
                            "For a determinate outcome, separate these into their own Tested Jurisdiction bucket (use /api/v2/tested-jurisdictions/build)."
                        ),
                    )
                )

        # ------------------------------------------------------------------
        # Module 14: Article 7.3 Deemed Distribution Tax Recapture Account
        # ------------------------------------------------------------------
        opening_state = ddt_opening_by_tj.get(bucket_id)
        opening_balance = 0.0
        opening_note_parts: List[str] = []
        opening_currency = None

        if opening_state is not None:
            opening_currency = opening_state.currency or input_currency or reporting_currency
            if opening_state.as_of_fiscal_year_start and opening_state.as_of_fiscal_year_start != fy_start:
                conversion_trace.append(
                    TraceLine(
                        section="eligibility",
                        step="DDT recapture account: as_of_fiscal_year_start mismatch",
                        amount=0.0,
                        note=(
                            f"Opening state provided as_of_fiscal_year_start={opening_state.as_of_fiscal_year_start} "
                            f"but request fiscal_year.start_date={fy_start}. Using the provided balance as the opening balance for this computation."
                        ),
                    )
                )

            opening_balance, fx_note = _convert_amount_with_fx(
                req,
                amount=float(opening_state.balance),
                currency=opening_currency,
                amount_scale=getattr(opening_state, "amount_scale", "UNITS"),
                fy_start=fy_start,
                reporting_currency=reporting_currency,
                use_spot=True,
            )
            if fx_note:
                opening_note_parts.append(fx_note)

        # Compute closing balance (for scenario roll-forward) using current-year movements.
        closing_balance = float(opening_balance)
        movement_notes: List[str] = []
        for mv in (ddt_moves_by_tj.get(bucket_id) or []):
            mv_currency = mv.currency or opening_currency or input_currency or reporting_currency
            mv_amt, mv_fx_note = _convert_amount_with_fx(
                req,
                amount=float(mv.amount),
                currency=mv_currency,
                amount_scale=getattr(mv, "amount_scale", "UNITS"),
                fy_start=fy_start,
                reporting_currency=reporting_currency,
                use_spot=True,
            )
            closing_balance += float(mv_amt)
            tag = (mv.movement_id or mv.reason or "movement")
            n = f"{tag}:{mv_amt:+.6f}"
            if mv_fx_note:
                n += f" ({mv_fx_note})"
            movement_notes.append(n)

        if closing_balance < -1e-6:
            raise ValueError(
                f"DDT recapture account movements would reduce the balance below zero for Tested Jurisdiction '{bucket_id}'. "
                f"opening={opening_balance}, closing={closing_balance}. Review movements and sign conventions."
            )
        if closing_balance < 0.0:
            closing_balance = 0.0

        # Eligibility gate: outstanding balance at FY start disqualifies the election for this FY.
        if opening_state is not None and float(opening_balance) > 1e-6:
            meta.ineligible_article7_3_outstanding_recapture = True
            conversion_trace.append(
                TraceLine(
                    section="eligibility",
                    step="Article 7.3 recapture account opening balance outstanding",
                    amount=0.0,
                    note=(
                        f"Opening balance={opening_balance:.6f} "
                        f"{(reporting_currency or opening_currency or '').strip() or ''}. "
                        "Safe harbour election is not available for this Tested Jurisdiction until the balance is reduced to nil." 
                        + (f" | {'; '.join(opening_note_parts)}" if opening_note_parts else "")
                    ),
                )
            )
        elif opening_state is not None:
            conversion_trace.append(
                TraceLine(
                    section="eligibility",
                    step="Article 7.3 recapture account opening balance",
                    amount=0.0,
                    note=(
                        f"Opening balance={opening_balance:.6f} "
                        f"{(reporting_currency or opening_currency or '').strip() or ''}. "
                        + (f" | {'; '.join(opening_note_parts)}" if opening_note_parts else "")
                    ),
                )
            )

        # Emit closing state for this FY if an opening state or movements exist.
        if opening_state is not None or (ddt_moves_by_tj.get(bucket_id) or []):
            out_currency = reporting_currency or opening_currency
            if not out_currency:
                mv_list = ddt_moves_by_tj.get(bucket_id) or []
                if mv_list:
                    out_currency = mv_list[0].currency or input_currency
            ddt_state_closing_by_tj[bucket_id] = DDTRecaptureAccountStateV2(
                tested_jurisdiction_id=bucket_id,
                balance=float(closing_balance),
                currency=out_currency,
                amount_scale="UNITS",
                as_of_fiscal_year_start=None,
                note=(
                    "AUTO: closing balance computed from opening + movements. "
                    + (f"Movements: {', '.join(movement_notes)}" if movement_notes else "")
                ),
            )
        dqpt = float(getattr(getattr(req, "deemed_zero_automation", None), "qualified_persons_threshold", 0.9999))
        entities = (
            _build_entities(tj, bucket_id, currency_multiplier_pl=currency_multiplier_pl, deemed_zero_qp_threshold=dqpt)
            if input_mode == "entity_rollup"
            else []
        )

        req_v1 = CalculationRequestV1(
            fiscal_year_start_date=fy_start,
            minimum_rate=req.minimum_rate,
            input_mode=input_mode,
            apply_optional_2025_start_rule=req.applicability.apply_optional_2025_start_rule,
            early_start_qdmtt_safe_harbour_applies=req.applicability.early_start_qdmtt_safe_harbour_applies,
            early_start_only_one_jurisdiction_has_taxing_rights=req.applicability.early_start_only_one_jurisdiction_has_taxing_rights,
            early_start_all_taxing_rights_jurisdictions_allow=req.applicability.early_start_all_taxing_rights_jurisdictions_allow,
            jurisdictions=[meta],
            entities=entities,
        )

        base_resp = calculate_v1(req_v1)
        base_r = base_resp.results[0]

        opening_balances, carryforward_conversion_trace = _convert_carryforwards(
            req,
            tj.carryforwards_opening,
            reporting_currency=reporting_currency,
            input_currency=input_currency,
            scale_multiplier=float(scale_mult),
            fy_start=fy_start,
        )

        trace: list[TraceLine] = list(conversion_trace) + list(carryforward_conversion_trace) + list(entry_eval.trace) + list(base_r.trace) + list(election_trace)

        works[bucket_id] = _TJWork(
            tj=tj,
            bucket_id=bucket_id,
            reporting_currency=reporting_currency,
            input_currency=input_currency,
            fx_rate_avg=float(fx_avg),
            fx_rate_spot=float(fx_spot),
            amount_scale=str(amount_scale) if amount_scale is not None else None,
            currency_multiplier_pl=float(currency_multiplier_pl),
            currency_multiplier_bs=float(currency_multiplier_bs),
            spot_rate_provided=bool(spot_provided),
            effective_elections=effective_elections,
            eligible=bool(base_r.eligible),
            ineligibility_reasons=list(base_r.ineligibility_reasons),
            election_records=list(base_r.election_records),
            trace=trace,
            simplified_income=float(base_r.simplified_income),
            simplified_taxes=float(base_r.simplified_taxes),
            opening_balances=opening_balances,
            allocation_ledger=[],
            allocation_warnings=[],
            entry_reentry_status=entry_eval.status,
        )

    # -----------------------------
    # Apply structured adjustments that can affect multiple TJs
    # -----------------------------
    group_election_register = _collect_group_election_register(req)
    effective_group_elections_current = resolve_effective_elections(group_election_register, fiscal_year_start=fy_start)

    # Attach group-wide elections to each Tested Jurisdiction for audit visibility (non-breaking).
    if effective_group_elections_current:
        for w in works.values():
            existing_codes = {e.election_code for e in (w.effective_elections or [])}
            for e in effective_group_elections_current:
                if e.election_code not in existing_codes:
                    w.effective_elections.append(e)
                    existing_codes.add(e.election_code)

                edef = ELECTIONS_BY_CODE.get(e.election_code)
                label = e.label or (edef.label if edef else e.election_code)
                w.election_records.append(
                    ElectionRecord(
                        scope=e.scope,
                        election_code=e.election_code,
                        label=label,
                        bool_value=e.bool_value,
                        amount=e.amount,
                        note=(e.note or "Group-wide election"),
                    )
                )

            w.trace.append(
                TraceLine(
                    section="eligibility",
                    step="Group-wide elections effective in this Fiscal Year",
                    amount=0.0,
                    note=", ".join([e.election_code for e in effective_group_elections_current]),
                )
            )

    # Transition Year adjustments (Box 4.5)
    for w in works.values():
        w.transition_year_state_closing = _apply_transition_year_adjustments(w, req, fy_start=fy_start, minimum_rate=req.minimum_rate)

    # Transfer pricing adjustments register (section 5.2)
    _apply_transfer_pricing_adjustments_register(
        works,
        req,
        fy_start=fy_start,
        reporting_currency=reporting_currency,
        group_election_register=group_election_register,
    )

    # After-year-end adjustments (Box 4.6)
    aye_applied = _apply_after_year_end_adjustments(
        works,
        req,
        fy_start=fy_start,
        reporting_currency=reporting_currency,
        group_election_register=group_election_register,
    )

    # Section 5.1 allocations/exclusions (Permanent Establishments, flow-through entities, allocable tax items)
    pe_simplification_state_closing = _apply_section_5_1_allocations(
        works,
        req,
        fy_start=fy_start,
        reporting_currency=reporting_currency,
        group_election_register=group_election_register,
    )

    # Investment entity owner addbacks (Articles 7.5 / 7.6)
    for w in works.values():
        _apply_owner_addbacks(w)

    # Normalise cross-border tax items (scale + optional FX translation)
    cb_items: list[CrossBorderTaxItemV2] = []
    for item in (req.cross_border_tax_items or []):
        amt = float(item.amount) * float(_scale_multiplier(getattr(item, "amount_scale", "UNITS")))
        cur = getattr(item, "currency", None)
        if reporting_currency and cur:
            cur_u = str(cur).upper().strip() or None
            if cur_u and cur_u != reporting_currency:
                r = _fx_lookup_avg(req, cur_u, fy_start)
                if r is None:
                    raise ValueError(
                        f"Missing FX rate for cross-border tax item currency '{cur_u}' to reporting currency '{reporting_currency}' for FY start {fy_start}. "
                        "Provide request.fx_rates with avg_rate_to_reporting or omit currency to indicate the amount is already in reporting currency."
                    )
                amt = amt * float(r)
        cb_items.append(item.model_copy(update={"amount": float(amt)}))

    _apply_cross_border_tax_items(works, cb_items, fy_start)

    # Integrity adjustments register + automated integrity checks (Box 7.3)
    _apply_integrity_adjustments(works, req, fy_start=fy_start, reporting_currency=reporting_currency)
    _assess_integrity_box_7_3(works, req, fy_start=fy_start, reporting_currency=reporting_currency)

    # -----------------------------
    # Final pass: carryforwards + deemed-zero + compute outcomes
    # -----------------------------
    results: list[TestedJurisdictionResultV2] = []

    # Preserve request ordering
    for tj in req.tested_jurisdictions:
        bucket_id = tj.tested_jurisdiction_id
        w = works[bucket_id]

        trace = w.trace

        # Section 6 deemed-zero (manual override + automatic determination)
        auto_apply, auto_basis, auto_reason = _auto_deemed_zero_determination(w, req)
        manual_apply = bool(getattr(tj.deemed_zero_rules, 'apply_deemed_zero', False))

        dz_apply = bool(manual_apply or auto_apply)
        dz_basis = 'MANUAL' if manual_apply else (auto_basis or None)
        dz_reason = (
            (tj.deemed_zero_rules.rationale or 'Simplified Income and Simplified Taxes treated as zero.')
            if manual_apply
            else auto_reason
        )

        if dz_apply:
            trace.append(
                TraceLine(
                    section='eligibility',
                    step='Deemed-zero rule applied' if manual_apply else 'Deemed-zero rule applied (auto)',
                    amount=0.0,
                    note=(dz_reason or 'Simplified Income and Simplified Taxes treated as zero.') + (f" | basis={dz_basis}" if dz_basis else ''),
                )
            )

            if w.eligible:
                if dz_basis == 'SECTION_6_2_TAX_TRANSPARENT':
                    sh_reason = 'PASS: deemed-zero (Section 6.2 tax transparent / flow-through).' 
                elif dz_basis == 'SECTION_6_1_TAX_NEUTRAL_UPE':
                    sh_reason = 'PASS: deemed-zero (Section 6.1 tax-neutral UPE).' 
                else:
                    sh_reason = 'PASS: deemed-zero (manual override).' 
                sh_apply = True
                if not w.eligible:
                    sh_apply = False
                    sh_reason = "NOT AVAILABLE: jurisdiction fails eligibility criteria (see reasons)."



                results.append(
                    TestedJurisdictionResultV2(
                        tested_jurisdiction_id=bucket_id,
                        jurisdiction_code=tj.jurisdiction_code,
                        label=tj.label,
                        transition_year_fy_start=w.transition_year_fy_start,
                        is_transition_year=w.is_transition_year,
                        transition_year_state_closing=w.transition_year_state_closing,
                        eligible=w.eligible,
                        ineligibility_reasons=list(w.ineligibility_reasons),
                        entry_reentry_status=w.entry_reentry_status,
                        integrity_assessment=w.integrity_assessment,
                        simplified_income=0.0,
                        simplified_taxes=0.0,
                        simplified_etr=None,
                        simplified_loss=0.0,
                        safe_harbour_applies=bool(sh_apply),
                        safe_harbour_reason=sh_reason,
                        deemed_zero_applied=True,
                        deemed_zero_basis=dz_basis,
                        deemed_zero_reason=dz_reason,
                        simplified_income_pre_allocations=w.simplified_income_pre_allocations,
                        simplified_taxes_pre_allocations=w.simplified_taxes_pre_allocations,
                        simplified_income_post_allocations=w.simplified_income_post_allocations,
                        simplified_taxes_post_allocations=w.simplified_taxes_post_allocations,
                        allocation_ledger=list(w.allocation_ledger or []),
                        allocation_warnings=list(w.allocation_warnings or []),
                        simplified_adjustment_for_negative_taxes=0.0,
                        effective_elections=w.effective_elections,
                        election_records=list(w.election_records),
                        trace=trace,
                        carryforwards_opening=w.opening_balances,
                        carryforward_movements=[],
                        carryforwards_closing=w.opening_balances,
                    )
                )
                continue

            # If not eligible, fall through with normal numbers but explain.
            trace.append(
                TraceLine(
                    section='eligibility',
                    step='Deemed-zero determined but eligibility failed',
                    amount=0.0,
                    note='Safe harbour is not available where eligibility restrictions are not met.',
                )
            )

        # Apply carryforwards to taxes (after cross-border / addbacks)
        simplified_income_base = float(w.simplified_income)
        simplified_taxes_base = float(w.simplified_taxes)

        # Start from the trace accumulated so far (but do not permanently mutate it until we decide which path to keep).
        trace_base = list(trace)

        # -------------------------------------------------------
        # Box 4.6(3) qualified refund exclusion (optional; user-flagged)
        # -------------------------------------------------------
        candidates: list[_AYEApplied] = []
        for a in (aye_applied.get(bucket_id, []) or []):
            adj = a.adjustment
            if not getattr(adj, "apply_large_refund_exclusion", False):
                continue
            if adj.kind != "tax":
                continue
            if float(a.amount_reporting_currency) >= 0:
                continue
            if getattr(adj, "attributable_to_income_change", False):
                continue
            months = getattr(adj, "months_after_transaction_year_end", None)
            if months is None or int(months) <= 12:
                continue
            # Must relate to a previous Fiscal Year
            if adj.transaction_year_fy_start >= fy_start:
                continue
            candidates.append(a)

        def _run_with_base_taxes(taxes_base: float, trace_prefix: list[TraceLine]) -> tuple[float, list[CarryforwardBalanceV2], list[CarryforwardMovementV2], list[TraceLine], Optional[float]]:
            t = list(trace_prefix)
            taxes_after, balances, moves = _apply_carryforwards(
                fy_start=fy_start,
                minimum_rate=req.minimum_rate,
                simplified_income=simplified_income_base,
                simplified_taxes=taxes_base,
                opening=w.opening_balances,
                effective_elections=w.effective_elections,
                trace=t,
            )
            etr = None
            if simplified_income_base > 0:
                etr = float(taxes_after) / float(simplified_income_base) if simplified_income_base != 0 else None
            return float(taxes_after), balances, moves, t, etr

        # Baseline (all after-year-end adjustments included per timing rules)
        taxes_after_cf, balances_after, movements, trace_trial, etr_trial = _run_with_base_taxes(simplified_taxes_base, trace_base)

        refund_addback = 0.0
        refund_lines: list[TraceLine] = []

        # Only attempt Box 4.6(3) when it could matter for passing the Simplified ETR test
        if candidates and w.eligible and simplified_income_base > 0 and etr_trial is not None and etr_trial < req.minimum_rate:
            for a in candidates:
                ok, msg = _qualified_refund_condition_met(a.adjustment, minimum_rate=req.minimum_rate)
                label = a.adjustment.label or a.adjustment.adjustment_id or "After-year-end tax adjustment"
                if ok:
                    # Excluding a net decrease means adding it back (increase Simplified Taxes)
                    refund_addback += abs(float(a.amount_reporting_currency))
                    refund_lines.append(
                        TraceLine(
                            section="tax",
                            step=f"Box 4.6(3) qualified refund exclusion applied: {label}",
                            amount=abs(float(a.amount_reporting_currency)),
                            note=msg,
                        )
                    )
                else:
                    refund_lines.append(
                        TraceLine(
                            section="tax",
                            step=f"Box 4.6(3) exclusion requested but not applied: {label}",
                            amount=0.0,
                            note=msg,
                        )
                    )

        if refund_addback > 0:
            # Re-run carryforwards with the addback applied (carryforward utilisation may change)
            taxes_after_cf, balances_after, movements, trace_trial2, _etr2 = _run_with_base_taxes(
                simplified_taxes_base + refund_addback,
                trace_base + refund_lines,
            )
            trace = trace_trial2
        else:
            trace = trace_trial

        simplified_income = simplified_income_base
        simplified_taxes = float(taxes_after_cf)

        simplified_loss = 0.0
        simplified_etr = None
        if simplified_income <= 0:
            simplified_loss = max(0.0, -simplified_income)
        else:
            simplified_etr = simplified_taxes / simplified_income if simplified_income != 0 else None

        # Loss-year negative-tax adjustment / Loss DTA method
        simplified_adjustment_for_negative_taxes = 0.0
        closing_additions: list[CarryforwardBalanceV2] = []

        loss_dta_method = bool(get_effective_election_bool(w.effective_elections, "LOSS_DTA_ADJUSTMENT_METHOD_ELECTED") or False)
        loss_dta_generated = get_effective_election_amount(w.effective_elections, "LOSS_DTA_ADJUSTMENT_GENERATED_AMOUNT")
        if loss_dta_generated is not None:
            loss_dta_generated = float(loss_dta_generated)

        if loss_dta_method and loss_dta_generated and loss_dta_generated > 0 and simplified_loss > 0:
            closing_additions.append(
                CarryforwardBalanceV2(
                    kind="LOSS_DTA_ADJUSTMENT",
                    origin_fiscal_year_start=fy_start,
                    amount=abs(loss_dta_generated),
                    remaining_amount=abs(loss_dta_generated),
                    note="Generated under Loss DTA Adjustment methodology (input amount).",
                )
            )
            trace.append(
                TraceLine(
                    section="tax",
                    step="Loss-year: Loss DTA Adjustment generated (carryforward)",
                    amount=0.0,
                    note=f"Amount created = {abs(loss_dta_generated):.2f}",
                )
            )
        else:
            if simplified_loss > 0 and simplified_taxes < 0:
                simplified_adjustment_for_negative_taxes = simplified_taxes - (simplified_loss * req.minimum_rate)
                cf_amt = abs(simplified_adjustment_for_negative_taxes)
                if cf_amt > 0:
                    closing_additions.append(
                        CarryforwardBalanceV2(
                            kind="SIMPLIFIED_NEGATIVE_TAX_ADJUSTMENT",
                            origin_fiscal_year_start=fy_start,
                            amount=cf_amt,
                            remaining_amount=cf_amt,
                            note="Computed as abs(Simplified Taxes – (Simplified Loss * Minimum Rate)).",
                        )
                    )
                    trace.append(
                        TraceLine(
                            section="tax",
                            step="Loss-year: Simplified Adjustment for Negative Taxes computed (carryforward)",
                            amount=simplified_adjustment_for_negative_taxes,
                            note="Computed as Simplified Taxes – (Simplified Loss * Minimum Rate). Stored as a positive carryforward amount.",
                        )
                    )

        # Safe harbour outcome (recomputed after adjustments)
        if simplified_income <= 0:
            safe_harbour_pass = True
            reason = "PASS: Simplified Loss (or non-positive Simplified Income)."
        else:
            safe_harbour_pass = (simplified_etr is not None) and simplified_etr >= req.minimum_rate
            reason = (
                "PASS: Simplified ETR >= Minimum Rate."
                if safe_harbour_pass
                else "FAIL: Simplified ETR < Minimum Rate and no Simplified Loss."
            )

        if not w.eligible:
            safe_harbour_pass = False
            reason = "NOT AVAILABLE: jurisdiction fails eligibility criteria (see reasons)."

        closing = [b for b in balances_after if (b.remaining_amount or 0.0) > 0] + closing_additions

        results.append(
            TestedJurisdictionResultV2(
                tested_jurisdiction_id=bucket_id,
                jurisdiction_code=tj.jurisdiction_code,
                label=tj.label,
                        transition_year_fy_start=w.transition_year_fy_start,
                        is_transition_year=w.is_transition_year,
                        transition_year_state_closing=w.transition_year_state_closing,
                eligible=w.eligible,
                ineligibility_reasons=list(w.ineligibility_reasons),
                entry_reentry_status=w.entry_reentry_status,
                integrity_assessment=w.integrity_assessment,
                simplified_income=simplified_income,
                simplified_taxes=simplified_taxes,
                simplified_etr=simplified_etr,
                simplified_loss=simplified_loss,
                safe_harbour_applies=safe_harbour_pass,
                safe_harbour_reason=reason,
                simplified_income_pre_allocations=w.simplified_income_pre_allocations,
                simplified_taxes_pre_allocations=w.simplified_taxes_pre_allocations,
                simplified_income_post_allocations=w.simplified_income_post_allocations,
                simplified_taxes_post_allocations=w.simplified_taxes_post_allocations,
                allocation_ledger=list(w.allocation_ledger or []),
                allocation_warnings=list(w.allocation_warnings or []),
                simplified_adjustment_for_negative_taxes=float(simplified_adjustment_for_negative_taxes),
                effective_elections=w.effective_elections,
                election_records=list(w.election_records),
                trace=trace,
                carryforwards_opening=w.opening_balances,
                carryforward_movements=movements,
                carryforwards_closing=closing,
            )
        )

    return CalculationResponseV2(
        ruleset_version=req.ruleset_version,
        fiscal_year=req.fiscal_year,
        minimum_rate=req.minimum_rate,
        reporting_currency=reporting_currency,
        results=results,
        pe_simplification_state_closing=list(pe_simplification_state_closing or []),
        ddt_recapture_account_state_closing=[
            ddt_state_closing_by_tj[k] for k in sorted(ddt_state_closing_by_tj.keys())
        ],
    )