from __future__ import annotations

from collections import defaultdict

from app.services.models import (
    CalculationRequest,
    CalculationResponse,
    EntityInput,
    JurisdictionInput,
    JurisdictionResult,
    TraceLine,
)
from app.services.eligibility import check_jurisdiction_eligibility


def _resolve_accounted_tax_rate(jcode: str, meta: JurisdictionInput | None, entities: list[EntityInput]) -> float | None:
    """Resolve jurisdiction-level accounted tax rate in entity roll-up mode.

    Priority:
      1) Jurisdiction meta row (if provided)
      2) Entity-level rates (only if consistent)

    If multiple distinct entity-level rates exist, we require the user to provide a jurisdiction-level override.
    """

    if meta and meta.accounted_tax_rate is not None:
        return float(meta.accounted_tax_rate)

    rates = [e.accounted_tax_rate for e in entities if e.accounted_tax_rate is not None]
    if not rates:
        return None

    # Normalise to avoid tiny rounding differences.
    uniq = sorted({round(float(r), 6) for r in rates})
    if len(uniq) == 1:
        return uniq[0]

    raise ValueError(
        f"Entity roll-up: multiple accounted_tax_rate values for jurisdiction '{jcode}' ({uniq}). "
        "Provide a single jurisdiction-level accounted_tax_rate in jurisdictions[] for that code."
    )


def _rollup_entities(req: CalculationRequest) -> tuple[list[JurisdictionInput], dict[str, int]]:
    """Aggregate EntityInput rows into JurisdictionInput rows."""

    meta_by_code: dict[str, JurisdictionInput] = {j.jurisdiction_code: j for j in req.jurisdictions}

    groups: dict[str, list[EntityInput]] = defaultdict(list)
    for e in req.entities:
        groups[e.jurisdiction_code].append(e)

    rolled: list[JurisdictionInput] = []
    counts: dict[str, int] = {code: len(ents) for code, ents in groups.items()}

    for jcode, ents in groups.items():
        meta = meta_by_code.get(jcode)

        def s(attr: str) -> float:
            return float(sum(getattr(e, attr) or 0.0 for e in ents))

        # Non-REA DTL: only exclude amounts where the entity does NOT meet an exception.
        non_rea_to_exclude = float(
            sum(
                (e.non_rea_dtl_deferred_tax_expense or 0.0)
                for e in ents
                if not bool(e.non_rea_dtl_exception_applies)
            )
        )

        j = JurisdictionInput(
            jurisdiction_code=jcode,

            # Starting points
            jpbt=s("jpbt"),

            # Basic adjustments
            excluded_dividends=s("excluded_dividends"),
            excluded_equity_gains_losses=s("excluded_equity_gains_losses"),
            illegal_payments=s("illegal_payments"),
            fines_penalties_ge_250k=s("fines_penalties_ge_250k"),

            # Industry amounts
            insurance_company_income=s("insurance_company_income"),
            fs_annual_election_not_to_exclude_insurance_income=bool(
                meta.fs_annual_election_not_to_exclude_insurance_income if meta else False
            ),
            at1_rt1_payments_receipts_adjustment=s("at1_rt1_payments_receipts_adjustment"),
            at1_rt1_corresponding_tax_in_equity=s("at1_rt1_corresponding_tax_in_equity"),

            international_shipping_income=s("international_shipping_income"),
            qualified_ancillary_international_shipping_income=s("qualified_ancillary_international_shipping_income"),
            shipping_five_year_election_not_to_exclude=bool(
                meta.shipping_five_year_election_not_to_exclude if meta else False
            ),
            taxes_on_excluded_shipping_income=s("taxes_on_excluded_shipping_income"),

            # Conditional/optional income adjustment amounts
            equity_reported_items_amount=s("equity_reported_items_amount"),
            equity_reported_items_subject_to_tax_at_or_above_minimum_rate=bool(
                meta.equity_reported_items_subject_to_tax_at_or_above_minimum_rate if meta else False
            ),
            equity_reported_items_related_taxes_accounted_in_equity_or_oci=bool(
                meta.equity_reported_items_related_taxes_accounted_in_equity_or_oci if meta else False
            ),
            equity_reported_items_related_tax_is_deferred_tax_liability=bool(
                meta.equity_reported_items_related_tax_is_deferred_tax_liability if meta else False
            ),
            equity_reported_items_related_dtl_is_recapture_exception_accrual=bool(
                meta.equity_reported_items_related_dtl_is_recapture_exception_accrual if meta else False
            ),

            mna_simplification_applied=bool(meta.mna_simplification_applied if meta else False),
            mna_goodwill_impairment_or_amortisation_addback=s("mna_goodwill_impairment_or_amortisation_addback"),
            mna_article_6_3_4_election_amount=s("mna_article_6_3_4_election_amount"),

            asymmetric_fx_gain_loss=s("asymmetric_fx_gain_loss"),
            afxgl_five_year_election_not_to_apply=bool(meta.afxgl_five_year_election_not_to_apply if meta else False),
            accrued_pension_expense_adjustment=s("accrued_pension_expense_adjustment"),
            pension_five_year_election_not_to_apply=bool(meta.pension_five_year_election_not_to_apply if meta else False),

            # Taxes (starting point)
            current_tax_expense=s("current_tax_expense"),
            deferred_tax_expense=s("deferred_tax_expense"),
            consolidated_level_deferred_tax=s("consolidated_level_deferred_tax"),

            taxes_not_covered=s("taxes_not_covered"),
            tax_refunds_and_credits_adjustment=s("tax_refunds_and_credits_adjustment"),
            taxes_on_excluded_income=s("taxes_on_excluded_income"),
            uncertain_tax_positions_adjustment=s("uncertain_tax_positions_adjustment"),
            current_tax_not_paid_within_3y=s("current_tax_not_paid_within_3y"),

            accounted_tax_rate=_resolve_accounted_tax_rate(jcode, meta, ents),
            valuation_allowance_impact=s("valuation_allowance_impact"),
            tax_rate_change_impact=s("tax_rate_change_impact"),
            deferred_tax_from_tax_credits=s("deferred_tax_from_tax_credits"),
            non_rea_dtl_deferred_tax_expense=non_rea_to_exclude,
            non_rea_dtl_exception_applies=False,

            # M&A tax-side exclusions (aggregated; flag at jurisdiction meta)
            mna_deferred_tax_accruals_to_exclude=s("mna_deferred_tax_accruals_to_exclude"),
            mna_goodwill_related_dtl_reversal_to_exclude=s("mna_goodwill_related_dtl_reversal_to_exclude"),

            # Elections (amounts)
            election_include_other_covered_taxes=s("election_include_other_covered_taxes"),
            election_include_equity_reported_taxes=s("election_include_equity_reported_taxes"),
            election_include_qrtc_mttc_credits_in_income=s("election_include_qrtc_mttc_credits_in_income"),
            election_include_qrtc_mttc_credits_in_taxes=s("election_include_qrtc_mttc_credits_in_taxes"),

            # Eligibility / integrity flags come from jurisdiction meta row (if provided), otherwise defaults.
            ineligible_stateless=bool(meta.ineligible_stateless if meta else False),
            ineligible_investment_entity=bool(meta.ineligible_investment_entity if meta else False),
            ineligible_article7_3_outstanding_recapture=bool(meta.ineligible_article7_3_outstanding_recapture if meta else False),
            stateless_exception_section_6_2_applies=bool(
                getattr(meta, "stateless_exception_section_6_2_applies", False) if meta else False
            ),
            investment_entity_tax_transparency_election_applies=bool(
                getattr(meta, "investment_entity_tax_transparency_election_applies", False) if meta else False
            ),
            no_topup_tax_in_prior_24_months=bool(meta.no_topup_tax_in_prior_24_months if meta else True),
            reentry_no_topup_tax_in_prior_24_months=(meta.reentry_no_topup_tax_in_prior_24_months if meta else None),
            integrity_rules_satisfied=bool(meta.integrity_rules_satisfied if meta else True),

            # Adjustment lines: jurisdiction-level sheets apply on top
            other_income_adjustments=list(meta.other_income_adjustments) if meta else [],
            other_tax_adjustments=list(meta.other_tax_adjustments) if meta else [],

            # Election record audit trail (if provided via Jurisdictions meta rows / ElectionAdjustments)
            election_records=list(meta.election_records) if meta else [],
        )

        # Carry through entity-level adjustment lines (if supplied via JSON)
        for e in ents:
            for adj in e.other_income_adjustments:
                j.other_income_adjustments.append(
                    adj.model_copy(update={"label": f"{e.entity_name}: {adj.label}"})
                )
            for adj in e.other_tax_adjustments:
                j.other_tax_adjustments.append(
                    adj.model_copy(update={"label": f"{e.entity_name}: {adj.label}"})
                )

        rolled.append(j)

    # Preserve stable ordering
    rolled.sort(key=lambda x: x.jurisdiction_code)
    return rolled, counts


def calculate(req: CalculationRequest) -> CalculationResponse:
    results: list[JurisdictionResult] = []

    if req.input_mode == "entity_rollup":
        jurisdictions, entity_counts = _rollup_entities(req)
    else:
        jurisdictions, entity_counts = req.jurisdictions, {}

    for j in jurisdictions:
        trace: list[TraceLine] = []

        if req.input_mode == "entity_rollup":
            n = entity_counts.get(j.jurisdiction_code)
            trace.append(
                TraceLine(
                    section="eligibility",
                    step="Input mode: entity roll-up",
                    amount=0.0,
                    note=f"Aggregated from {n} entities." if n is not None else None,
                )
            )

        # -------------------------
        # Eligibility
        # -------------------------
        elig = check_jurisdiction_eligibility(req, j)
        trace.extend(elig.trace)

        # -------------------------
        # Simplified Income
        # -------------------------
        income = j.jpbt
        trace.append(TraceLine(section="income", step="Start: JPBT", amount=j.jpbt, running_total=income))

        # Basic adjustments (OECD Box 3.2)
        if j.excluded_dividends:
            income -= j.excluded_dividends
            trace.append(
                TraceLine(
                    section="income",
                    step="Remove Excluded Dividends",
                    amount=-j.excluded_dividends,
                    running_total=income,
                )
            )
        if j.excluded_equity_gains_losses:
            income -= j.excluded_equity_gains_losses
            trace.append(
                TraceLine(
                    section="income",
                    step="Remove Excluded Equity Gains/Losses",
                    amount=-j.excluded_equity_gains_losses,
                    running_total=income,
                )
            )
        if j.illegal_payments:
            income += j.illegal_payments
            trace.append(
                TraceLine(
                    section="income",
                    step="Add-back illegal payments (bribes/kickbacks etc.)",
                    amount=+j.illegal_payments,
                    running_total=income,
                )
            )
        if j.fines_penalties_ge_250k:
            income += j.fines_penalties_ge_250k
            trace.append(
                TraceLine(
                    section="income",
                    step="Add-back fines/penalties >= 250k",
                    amount=+j.fines_penalties_ge_250k,
                    running_total=income,
                )
            )

        # -------------------------
        # Industry adjustments (OECD Box 3.3)
        # -------------------------
        # Financial services: insurance company income exclusion (Article 3.2.9)
        if j.insurance_company_income:
            if j.fs_annual_election_not_to_exclude_insurance_income:
                trace.append(
                    TraceLine(
                        section="income",
                        step="Financial services: insurance company income (election not to exclude)",
                        amount=0.0,
                        running_total=income,
                        note="Annual election not to apply Article 3.2.9 exclusion.",
                    )
                )
            else:
                income -= j.insurance_company_income
                trace.append(
                    TraceLine(
                        section="income",
                        step="Financial services: exclude insurance company income (Art 3.2.9)",
                        amount=-j.insurance_company_income,
                        running_total=income,
                    )
                )

        # Financial services: AT1/RT1 adjustments (Article 3.2.10)
        if j.at1_rt1_payments_receipts_adjustment:
            income += j.at1_rt1_payments_receipts_adjustment
            trace.append(
                TraceLine(
                    section="income",
                    step="Financial services: AT1/RT1 payments/receipts adjustment (Art 3.2.10)",
                    amount=j.at1_rt1_payments_receipts_adjustment,
                    running_total=income,
                )
            )

        # Shipping: International Shipping Income exclusion (Article 3.3) unless 5-year election applies
        shipping_total = (j.international_shipping_income or 0.0) + (j.qualified_ancillary_international_shipping_income or 0.0)
        shipping_exclusion_applies = False
        if shipping_total:
            if j.shipping_five_year_election_not_to_exclude and shipping_total > 0:
                trace.append(
                    TraceLine(
                        section="income",
                        step="Shipping: election not to apply Shipping Income Exclusion",
                        amount=0.0,
                        running_total=income,
                        note="5-year election applies because aggregate shipping income is positive.",
                    )
                )
            else:
                shipping_exclusion_applies = True
                income -= shipping_total
                note = None
                if j.shipping_five_year_election_not_to_exclude and shipping_total <= 0:
                    note = "Election not applicable because aggregate shipping income is not positive; exclusion applied."
                trace.append(
                    TraceLine(
                        section="income",
                        step="Shipping: exclude ISI + QAISI (Art 3.3)",
                        amount=-shipping_total,
                        running_total=income,
                        note=note,
                    )
                )

        # -------------------------
        # Conditional adjustments (OECD Box 3.4)
        # -------------------------
        # 3.4.1 Equity-reported items
        er = float(j.equity_reported_items_amount or 0.0)
        if er < 0:
            trace.append(
                TraceLine(
                    section="income",
                    step="Conditional: equity-reported items (expense/loss) – no adjustment required",
                    amount=0.0,
                    running_total=income,
                    note="Equity-reported item is negative; safe harbour waives the adjustment.",
                )
            )
        elif er > 0:
            waiver = (
                bool(j.equity_reported_items_subject_to_tax_at_or_above_minimum_rate)
                and bool(j.equity_reported_items_related_taxes_accounted_in_equity_or_oci)
                and (
                    (not bool(j.equity_reported_items_related_tax_is_deferred_tax_liability))
                    or bool(j.equity_reported_items_related_dtl_is_recapture_exception_accrual)
                )
            )
            if waiver:
                trace.append(
                    TraceLine(
                        section="income",
                        step="Conditional: equity-reported items (income) – adjustment waived",
                        amount=0.0,
                        running_total=income,
                        note="Waiver conditions met (taxed >= Minimum Rate and taxes accounted in equity/OCI; DTL is REA if applicable).",
                    )
                )
            else:
                income += er
                trace.append(
                    TraceLine(
                        section="income",
                        step="Conditional: include equity-reported items (income) in Simplified Income",
                        amount=+er,
                        running_total=income,
                        note="Waiver conditions not met.",
                    )
                )

        # 3.4.2 M&A simplification and Article 6.3.4 election (simplified)
        if j.mna_article_6_3_4_election_amount:
            income += j.mna_article_6_3_4_election_amount
            trace.append(
                TraceLine(
                    section="income",
                    step="Conditional/Optional: M&A Article 6.3.4 election – include GloBE-to-book Difference amount",
                    amount=j.mna_article_6_3_4_election_amount,
                    running_total=income,
                    note="Enter full-year or pro-rata (5-year) amount for the current fiscal year.",
                )
            )

        if j.mna_simplification_applied and j.mna_goodwill_impairment_or_amortisation_addback:
            income += j.mna_goodwill_impairment_or_amortisation_addback
            trace.append(
                TraceLine(
                    section="income",
                    step="Conditional: M&A simplification – add-back goodwill impairment/amortisation",
                    amount=+j.mna_goodwill_impairment_or_amortisation_addback,
                    running_total=income,
                    note="Applies where goodwill impairment/amortisation has no corresponding DTL (or DTL below Minimum Rate).",
                )
            )

        # -------------------------
        # Optional adjustments (OECD Box 3.5.2)
        # -------------------------
        if j.asymmetric_fx_gain_loss:
            if j.afxgl_five_year_election_not_to_apply:
                trace.append(
                    TraceLine(
                        section="income",
                        step="Optional exclusion: AFXGL adjustment not applied (5-year election)",
                        amount=0.0,
                        running_total=income,
                    )
                )
            else:
                income += j.asymmetric_fx_gain_loss
                trace.append(
                    TraceLine(
                        section="income",
                        step="Optional exclusion: apply AFXGL adjustment (Art 3.2.1(f))",
                        amount=j.asymmetric_fx_gain_loss,
                        running_total=income,
                    )
                )

        if j.accrued_pension_expense_adjustment:
            if j.pension_five_year_election_not_to_apply:
                trace.append(
                    TraceLine(
                        section="income",
                        step="Optional exclusion: pension adjustment not applied (5-year election)",
                        amount=0.0,
                        running_total=income,
                    )
                )
            else:
                income += j.accrued_pension_expense_adjustment
                trace.append(
                    TraceLine(
                        section="income",
                        step="Optional exclusion: apply accrued pension expense adjustment (Art 3.2.1(i))",
                        amount=j.accrued_pension_expense_adjustment,
                        running_total=income,
                    )
                )

        # Other income adjustments (fallback) – user-supplied for MVP
        for adj in j.other_income_adjustments:
            income += adj.amount
            trace.append(
                TraceLine(
                    section="income",
                    step=f"Other income adjustment: {adj.label}",
                    amount=adj.amount,
                    running_total=income,
                    note=adj.note,
                )
            )

        # Election: include QRTC/MTTC credits in Simplified Income (Box 4.4.3)
        if j.election_include_qrtc_mttc_credits_in_income:
            income += j.election_include_qrtc_mttc_credits_in_income
            trace.append(
                TraceLine(
                    section="income",
                    step="Election: include QRTC/MTTC credits in Simplified Income",
                    amount=+j.election_include_qrtc_mttc_credits_in_income,
                    running_total=income,
                )
            )

        simplified_income = income

        # -------------------------
        # Simplified Taxes
        # -------------------------
        current = float(j.current_tax_expense or 0.0)
        deferred = float(j.deferred_tax_expense or 0.0) + float(j.consolidated_level_deferred_tax or 0.0)

        trace.append(
            TraceLine(
                section="tax",
                step="Start: current tax expense",
                amount=current,
                running_total=current,
            )
        )
        trace.append(
            TraceLine(
                section="tax",
                step="Start: deferred tax expense (incl. consolidated-level attributable deferred)",
                amount=deferred,
                running_total=current + deferred,
            )
        )

        # M&A Simplification (tax-side exclusions) – remove accruals and certain reversals (if flagged)
        if j.mna_simplification_applied and j.mna_deferred_tax_accruals_to_exclude:
            deferred -= j.mna_deferred_tax_accruals_to_exclude
            trace.append(
                TraceLine(
                    section="tax",
                    step="M&A simplification: exclude deferred tax accruals attributable to M&A transaction",
                    amount=-j.mna_deferred_tax_accruals_to_exclude,
                    running_total=current + deferred,
                )
            )

        if j.mna_simplification_applied and j.mna_goodwill_related_dtl_reversal_to_exclude:
            deferred -= j.mna_goodwill_related_dtl_reversal_to_exclude
            trace.append(
                TraceLine(
                    section="tax",
                    step="M&A simplification: exclude goodwill-related DTL reversal (if any)",
                    amount=-j.mna_goodwill_related_dtl_reversal_to_exclude,
                    running_total=current + deferred,
                )
            )

        # Deferred-tax specific adjustments (OECD Box 4 / 4.2.4)
        if j.valuation_allowance_impact:
            deferred += j.valuation_allowance_impact
            trace.append(
                TraceLine(
                    section="tax",
                    step="Deferred tax adj: ignore valuation allowance / recognition adjustment",
                    amount=+j.valuation_allowance_impact,
                    running_total=current + deferred,
                )
            )

        if j.tax_rate_change_impact:
            deferred -= j.tax_rate_change_impact
            trace.append(
                TraceLine(
                    section="tax",
                    step="Deferred tax adj: exclude impact of tax rate changes",
                    amount=-j.tax_rate_change_impact,
                    running_total=current + deferred,
                )
            )

        if j.deferred_tax_from_tax_credits:
            deferred -= j.deferred_tax_from_tax_credits
            trace.append(
                TraceLine(
                    section="tax",
                    step="Deferred tax adj: exclude deferred tax from generation/use of tax credits",
                    amount=-j.deferred_tax_from_tax_credits,
                    running_total=current + deferred,
                )
            )

        if j.non_rea_dtl_deferred_tax_expense and not j.non_rea_dtl_exception_applies:
            deferred -= j.non_rea_dtl_deferred_tax_expense
            trace.append(
                TraceLine(
                    section="tax",
                    step="Deferred tax adj: exclude non-REA DTL deferred tax expense",
                    amount=-j.non_rea_dtl_deferred_tax_expense,
                    running_total=current + deferred,
                )
            )
        elif j.non_rea_dtl_deferred_tax_expense and j.non_rea_dtl_exception_applies:
            trace.append(
                TraceLine(
                    section="tax",
                    step="Deferred tax adj: non-REA DTL exception applies (kept in taxes)",
                    amount=0.0,
                    running_total=current + deferred,
                )
            )

        # Recast deferred tax expense at Minimum Rate when accounted rate > minimum (OECD Box 4 / 4.2.5)
        deferred_recast = deferred
        if j.accounted_tax_rate and j.accounted_tax_rate > 0 and j.accounted_tax_rate > req.minimum_rate:
            deferred_recast = deferred * (req.minimum_rate / j.accounted_tax_rate)
            trace.append(
                TraceLine(
                    section="tax",
                    step="Deferred tax recast to Minimum Rate",
                    amount=deferred_recast - deferred,
                    running_total=current + deferred_recast,
                    note=f"Recast factor = {req.minimum_rate}/{j.accounted_tax_rate}",
                )
            )

        tax_total = current + deferred_recast

        # Industry tax symmetry (Financial Services): include corresponding tax in equity/OCI for AT1/RT1
        if j.at1_rt1_corresponding_tax_in_equity:
            tax_total += j.at1_rt1_corresponding_tax_in_equity
            trace.append(
                TraceLine(
                    section="tax",
                    step="Financial services: include AT1/RT1 tax accounted in equity/OCI",
                    amount=j.at1_rt1_corresponding_tax_in_equity,
                    running_total=tax_total,
                )
            )

        # Policy-based & correlation adjustments (OECD Box 4)
        if j.taxes_not_covered:
            tax_total -= j.taxes_not_covered
            trace.append(
                TraceLine(
                    section="tax",
                    step="Policy-based: remove taxes not Covered Taxes",
                    amount=-j.taxes_not_covered,
                    running_total=tax_total,
                )
            )

        if j.tax_refunds_and_credits_adjustment:
            tax_total += j.tax_refunds_and_credits_adjustment
            trace.append(
                TraceLine(
                    section="tax",
                    step="Policy-based: refunds and credits adjustment",
                    amount=j.tax_refunds_and_credits_adjustment,
                    running_total=tax_total,
                )
            )

        if j.taxes_on_excluded_income:
            tax_total -= j.taxes_on_excluded_income
            trace.append(
                TraceLine(
                    section="tax",
                    step="Correlation: remove taxes on income excluded from Simplified Income",
                    amount=-j.taxes_on_excluded_income,
                    running_total=tax_total,
                )
            )

        # Shipping correlation adjustment: remove taxes on excluded shipping income ONLY when exclusion applies
        if j.taxes_on_excluded_shipping_income:
            if shipping_exclusion_applies:
                tax_total -= j.taxes_on_excluded_shipping_income
                trace.append(
                    TraceLine(
                        section="tax",
                        step="Shipping: remove taxes on excluded shipping income (Art 4.1.3(a))",
                        amount=-j.taxes_on_excluded_shipping_income,
                        running_total=tax_total,
                    )
                )
            else:
                trace.append(
                    TraceLine(
                        section="tax",
                        step="Shipping: taxes on excluded shipping income not removed",
                        amount=0.0,
                        running_total=tax_total,
                        note="Shipping Income Exclusion not applied (election or zero/negative aggregate).",
                    )
                )

        if j.uncertain_tax_positions_adjustment:
            tax_total += j.uncertain_tax_positions_adjustment
            trace.append(
                TraceLine(
                    section="tax",
                    step="Uncertain taxes: adjust accruals/reversals (net)",
                    amount=j.uncertain_tax_positions_adjustment,
                    running_total=tax_total,
                )
            )

        if j.current_tax_not_paid_within_3y:
            tax_total -= j.current_tax_not_paid_within_3y
            trace.append(
                TraceLine(
                    section="tax",
                    step="Not payable promptly: remove current tax not expected to be paid within 3 years",
                    amount=-j.current_tax_not_paid_within_3y,
                    running_total=tax_total,
                )
            )

        for adj in j.other_tax_adjustments:
            tax_total += adj.amount
            trace.append(
                TraceLine(
                    section="tax",
                    step=f"Other tax adjustment: {adj.label}",
                    amount=adj.amount,
                    running_total=tax_total,
                    note=adj.note,
                )
            )

        # Optional elections (OECD Box 4.4)
        if j.election_include_other_covered_taxes:
            tax_total += j.election_include_other_covered_taxes
            trace.append(
                TraceLine(
                    section="tax",
                    step="Election: include Covered Taxes not in income tax expense",
                    amount=+j.election_include_other_covered_taxes,
                    running_total=tax_total,
                )
            )
        if j.election_include_equity_reported_taxes:
            tax_total += j.election_include_equity_reported_taxes
            trace.append(
                TraceLine(
                    section="tax",
                    step="Election: include taxes related to equity-reported income included in Simplified Income",
                    amount=+j.election_include_equity_reported_taxes,
                    running_total=tax_total,
                )
            )
        if j.election_include_qrtc_mttc_credits_in_taxes:
            tax_total += j.election_include_qrtc_mttc_credits_in_taxes
            trace.append(
                TraceLine(
                    section="tax",
                    step="Election: include QRTC/MTTC credits in Simplified Taxes",
                    amount=+j.election_include_qrtc_mttc_credits_in_taxes,
                    running_total=tax_total,
                )
            )

        simplified_taxes = tax_total

        # -------------------------
        # Safe harbour outcome
        # -------------------------
        simplified_loss = 0.0
        simplified_etr = None

        if simplified_income <= 0:
            simplified_loss = max(0.0, -simplified_income)
            safe_harbour_pass = True
            reason = "PASS: Simplified Loss (or non-positive Simplified Income)."
        else:
            simplified_etr = simplified_taxes / simplified_income
            safe_harbour_pass = simplified_etr >= req.minimum_rate
            reason = (
                "PASS: Simplified ETR >= Minimum Rate."
                if safe_harbour_pass
                else "FAIL: Simplified ETR < Minimum Rate and no Simplified Loss."
            )

        simplified_adjustment_for_negative_taxes = 0.0
        if simplified_loss > 0 and simplified_taxes < 0:
            simplified_adjustment_for_negative_taxes = simplified_taxes - (simplified_loss * req.minimum_rate)
            trace.append(
                TraceLine(
                    section="tax",
                    step="Loss-year: simplified adjustment for negative taxes (carryforward proxy)",
                    amount=simplified_adjustment_for_negative_taxes,
                    running_total=None,
                    note="Computed as Simplified Taxes – (Simplified Loss * Minimum Rate).",
                )
            )

        # Eligibility gates the election
        if not elig.eligible:
            safe_harbour_pass = False
            reason = "NOT AVAILABLE: jurisdiction fails eligibility criteria (see reasons)."

        results.append(
            JurisdictionResult(
                jurisdiction_code=j.jurisdiction_code,
                eligible=elig.eligible,
                ineligibility_reasons=elig.reasons,
                simplified_income=simplified_income,
                simplified_taxes=simplified_taxes,
                simplified_etr=simplified_etr,
                safe_harbour_applies=safe_harbour_pass,
                safe_harbour_reason=reason,
                simplified_loss=simplified_loss,
                simplified_adjustment_for_negative_taxes=simplified_adjustment_for_negative_taxes,
                trace=trace,

                # Echo election record audit trail
                election_records=list(j.election_records),
            )
        )

    return CalculationResponse(
        fiscal_year_start_date=req.fiscal_year_start_date,
        minimum_rate=req.minimum_rate,
        results=results,
    )
