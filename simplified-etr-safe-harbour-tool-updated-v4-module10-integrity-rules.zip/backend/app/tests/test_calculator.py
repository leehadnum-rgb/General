import unittest
from datetime import date

from app.services.models import CalculationRequest, EntityInput, JurisdictionInput
from app.services.calculator import calculate


class CalculatorTests(unittest.TestCase):
    def test_pass_on_etr(self):
        req = CalculationRequest(
            fiscal_year_start_date=date(2027, 1, 1),
            minimum_rate=0.15,
            jurisdictions=[
                JurisdictionInput(
                    jurisdiction_code="GB",
                    jpbt=1000.0,
                    current_tax_expense=160.0,
                    deferred_tax_expense=0.0,
                )
            ],
        )
        resp = calculate(req)
        r = resp.results[0]
        self.assertTrue(r.eligible)
        self.assertTrue(r.safe_harbour_applies)
        self.assertAlmostEqual(r.simplified_etr, 0.16)

    def test_pass_on_loss(self):
        req = CalculationRequest(
            fiscal_year_start_date=date(2027, 1, 1),
            minimum_rate=0.15,
            jurisdictions=[
                JurisdictionInput(
                    jurisdiction_code="DE",
                    jpbt=-500.0,
                    current_tax_expense=-10.0,
                    deferred_tax_expense=0.0,
                )
            ],
        )
        resp = calculate(req)
        r = resp.results[0]
        self.assertTrue(r.safe_harbour_applies)
        self.assertIsNone(r.simplified_etr)
        self.assertEqual(r.simplified_loss, 500.0)

    def test_shipping_exclusion_and_tax_correlation(self):
        req = CalculationRequest(
            fiscal_year_start_date=date(2027, 1, 1),
            minimum_rate=0.15,
            jurisdictions=[
                JurisdictionInput(
                    jurisdiction_code="NO",
                    jpbt=1000.0,
                    international_shipping_income=200.0,
                    qualified_ancillary_international_shipping_income=0.0,
                    taxes_on_excluded_shipping_income=30.0,
                    current_tax_expense=150.0,
                    deferred_tax_expense=0.0,
                )
            ],
        )
        resp = calculate(req)
        r = resp.results[0]
        self.assertAlmostEqual(r.simplified_income, 800.0)
        self.assertAlmostEqual(r.simplified_taxes, 120.0)
        self.assertTrue(r.safe_harbour_applies)

    def test_shipping_five_year_election_includes_income(self):
        req = CalculationRequest(
            fiscal_year_start_date=date(2027, 1, 1),
            minimum_rate=0.15,
            jurisdictions=[
                JurisdictionInput(
                    jurisdiction_code="NO",
                    jpbt=1000.0,
                    international_shipping_income=200.0,
                    qualified_ancillary_international_shipping_income=0.0,
                    shipping_five_year_election_not_to_exclude=True,
                    taxes_on_excluded_shipping_income=30.0,
                    current_tax_expense=150.0,
                    deferred_tax_expense=0.0,
                )
            ],
        )
        resp = calculate(req)
        r = resp.results[0]
        self.assertAlmostEqual(r.simplified_income, 1000.0)
        self.assertAlmostEqual(r.simplified_taxes, 150.0)
        self.assertTrue(r.safe_harbour_applies)

    def test_financial_services_adjustments(self):
        # Default: insurance income is excluded (unless annual election not to exclude)
        req = CalculationRequest(
            fiscal_year_start_date=date(2027, 1, 1),
            minimum_rate=0.15,
            jurisdictions=[
                JurisdictionInput(
                    jurisdiction_code="US",
                    jpbt=1000.0,
                    insurance_company_income=100.0,
                    at1_rt1_payments_receipts_adjustment=10.0,
                    at1_rt1_corresponding_tax_in_equity=2.0,
                    current_tax_expense=148.0,
                    deferred_tax_expense=0.0,
                )
            ],
        )
        resp = calculate(req)
        r = resp.results[0]
        # Income: 1000 - 100 + 10 = 910
        self.assertAlmostEqual(r.simplified_income, 910.0)
        # Taxes: 148 + 2 = 150
        self.assertAlmostEqual(r.simplified_taxes, 150.0)
        self.assertTrue(r.safe_harbour_applies)

    def test_entity_rollup(self):
        req = CalculationRequest(
            fiscal_year_start_date=date(2027, 1, 1),
            minimum_rate=0.15,
            input_mode="entity_rollup",
            entities=[
                EntityInput(
                    entity_id="GB-1",
                    entity_name="E1",
                    jurisdiction_code="GB",
                    jpbt=600.0,
                    current_tax_expense=90.0,
                    accounted_tax_rate=0.25,
                ),
                EntityInput(
                    entity_id="GB-2",
                    entity_name="E2",
                    jurisdiction_code="GB",
                    jpbt=400.0,
                    current_tax_expense=60.0,
                    accounted_tax_rate=0.25,
                ),
            ],
        )
        resp = calculate(req)
        r = resp.results[0]
        self.assertEqual(r.jurisdiction_code, "GB")
        self.assertAlmostEqual(r.simplified_income, 1000.0)
        self.assertAlmostEqual(r.simplified_taxes, 150.0)
        self.assertTrue(r.safe_harbour_applies)



    def test_equity_reported_income_included_when_not_waived(self):
        req = CalculationRequest(
            fiscal_year_start_date=date(2027, 1, 1),
            minimum_rate=0.15,
            jurisdictions=[
                JurisdictionInput(
                    jurisdiction_code="FR",
                    jpbt=1000.0,
                    equity_reported_items_amount=100.0,
                    equity_reported_items_subject_to_tax_at_or_above_minimum_rate=False,
                    equity_reported_items_related_taxes_accounted_in_equity_or_oci=False,
                    current_tax_expense=165.0,
                    deferred_tax_expense=0.0,
                )
            ],
        )
        resp = calculate(req)
        r = resp.results[0]
        self.assertAlmostEqual(r.simplified_income, 1100.0)
        self.assertAlmostEqual(r.simplified_taxes, 165.0)
        self.assertAlmostEqual(r.simplified_etr, 0.15)
        self.assertTrue(r.safe_harbour_applies)

    def test_equity_reported_income_waived_when_conditions_met(self):
        req = CalculationRequest(
            fiscal_year_start_date=date(2027, 1, 1),
            minimum_rate=0.15,
            jurisdictions=[
                JurisdictionInput(
                    jurisdiction_code="FR",
                    jpbt=1000.0,
                    equity_reported_items_amount=100.0,
                    equity_reported_items_subject_to_tax_at_or_above_minimum_rate=True,
                    equity_reported_items_related_taxes_accounted_in_equity_or_oci=True,
                    equity_reported_items_related_tax_is_deferred_tax_liability=False,
                    current_tax_expense=150.0,
                    deferred_tax_expense=0.0,
                )
            ],
        )
        resp = calculate(req)
        r = resp.results[0]
        self.assertAlmostEqual(r.simplified_income, 1000.0)
        self.assertAlmostEqual(r.simplified_taxes, 150.0)
        self.assertAlmostEqual(r.simplified_etr, 0.15)
        self.assertTrue(r.safe_harbour_applies)

    def test_afxgl_adjustment_applies_unless_five_year_election(self):
        req = CalculationRequest(
            fiscal_year_start_date=date(2027, 1, 1),
            minimum_rate=0.15,
            jurisdictions=[
                JurisdictionInput(
                    jurisdiction_code="JP",
                    jpbt=1000.0,
                    asymmetric_fx_gain_loss=-50.0,
                    afxgl_five_year_election_not_to_apply=False,
                    current_tax_expense=150.0,
                    deferred_tax_expense=0.0,
                )
            ],
        )
        resp = calculate(req)
        r = resp.results[0]
        self.assertAlmostEqual(r.simplified_income, 950.0)

        req2 = CalculationRequest(
            fiscal_year_start_date=date(2027, 1, 1),
            minimum_rate=0.15,
            jurisdictions=[
                JurisdictionInput(
                    jurisdiction_code="JP",
                    jpbt=1000.0,
                    asymmetric_fx_gain_loss=-50.0,
                    afxgl_five_year_election_not_to_apply=True,
                    current_tax_expense=150.0,
                    deferred_tax_expense=0.0,
                )
            ],
        )
        resp2 = calculate(req2)
        r2 = resp2.results[0]
        self.assertAlmostEqual(r2.simplified_income, 1000.0)

    def test_pension_adjustment_applies_unless_five_year_election(self):
        req = CalculationRequest(
            fiscal_year_start_date=date(2027, 1, 1),
            minimum_rate=0.15,
            jurisdictions=[
                JurisdictionInput(
                    jurisdiction_code="CA",
                    jpbt=1000.0,
                    accrued_pension_expense_adjustment=25.0,
                    pension_five_year_election_not_to_apply=False,
                    current_tax_expense=150.0,
                    deferred_tax_expense=0.0,
                )
            ],
        )
        resp = calculate(req)
        r = resp.results[0]
        self.assertAlmostEqual(r.simplified_income, 1025.0)

        req2 = CalculationRequest(
            fiscal_year_start_date=date(2027, 1, 1),
            minimum_rate=0.15,
            jurisdictions=[
                JurisdictionInput(
                    jurisdiction_code="CA",
                    jpbt=1000.0,
                    accrued_pension_expense_adjustment=25.0,
                    pension_five_year_election_not_to_apply=True,
                    current_tax_expense=150.0,
                    deferred_tax_expense=0.0,
                )
            ],
        )
        resp2 = calculate(req2)
        r2 = resp2.results[0]
        self.assertAlmostEqual(r2.simplified_income, 1000.0)

    def test_mna_simplification_goodwill_addback_and_deferred_tax_exclusions(self):
        # Deferred tax expense includes: +20 (M&A accrual) and -5 (goodwill-related DTL reversal) = net +15
        # Under M&A simplification, we exclude both the +20 accrual and the -5 reversal from Simplified Taxes.
        req = CalculationRequest(
            fiscal_year_start_date=date(2027, 1, 1),
            minimum_rate=0.15,
            jurisdictions=[
                JurisdictionInput(
                    jurisdiction_code="US",
                    jpbt=1000.0,
                    mna_simplification_applied=True,
                    mna_goodwill_impairment_or_amortisation_addback=30.0,
                    current_tax_expense=155.0,
                    deferred_tax_expense=15.0,
                    mna_deferred_tax_accruals_to_exclude=20.0,
                    mna_goodwill_related_dtl_reversal_to_exclude=-5.0,
                )
            ],
        )
        resp = calculate(req)
        r = resp.results[0]
        self.assertAlmostEqual(r.simplified_income, 1030.0)
        self.assertAlmostEqual(r.simplified_taxes, 155.0)
        self.assertTrue(r.safe_harbour_applies)

if __name__ == "__main__":
    unittest.main()
