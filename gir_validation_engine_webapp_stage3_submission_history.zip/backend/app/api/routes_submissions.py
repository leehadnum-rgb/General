from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.db import models
from app.api.schemas import (
    SubmissionRead,
    SubmissionRecordRead,
    SubmissionListResponse,
    SubmissionDetailResponse,
)


router = APIRouter(prefix="/filings/{filing_id}/submissions", tags=["submissions"])


@router.get("", response_model=SubmissionListResponse)
def list_submissions(
    filing_id: str,
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    db: Session = Depends(get_db),
):
    filing = db.get(models.Filing, filing_id)
    if filing is None:
        raise HTTPException(status_code=404, detail="Filing not found")

    q = (
        db.query(models.Submission)
        .filter(models.Submission.filing_id == filing_id)
        .order_by(models.Submission.imported_at.desc())
    )
    total = q.count()
    items = q.offset(offset).limit(limit).all()
    return SubmissionListResponse(count=total, items=items)


@router.get("/{submission_id}", response_model=SubmissionDetailResponse)
def get_submission(
    filing_id: str,
    submission_id: str,
    include_records: bool = Query(default=True),
    db: Session = Depends(get_db),
):
    sub = db.get(models.Submission, submission_id)
    if sub is None or sub.filing_id != filing_id:
        raise HTTPException(status_code=404, detail="Submission not found")

    records = []
    if include_records:
        records = (
            db.query(models.SubmissionRecord)
            .filter(models.SubmissionRecord.filing_id == filing_id)
            .filter(models.SubmissionRecord.submission_id == submission_id)
            .order_by(models.SubmissionRecord.record_type.asc(), models.SubmissionRecord.filer_code.asc())
            .all()
        )
    return SubmissionDetailResponse(
        submission=sub,
        records_count=len(records),
        records=records,
    )
