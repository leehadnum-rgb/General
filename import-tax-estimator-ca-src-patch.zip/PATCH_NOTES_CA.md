# Canada (CA) patch (src-only)

This zip adds **new files only**:
- `src/ingest/connectors/ca.ts` (CBSA Customs Tariff HTML ingestor)
- `src/api/lib/ca.ts` (runtime mapping: origin ISO2 → Canadian tariff treatments, and patching measures)

You still need to *wire CA in* by editing existing files (use Codex prompt in ChatGPT response).

Env vars to add (Render):
- Cron job / ingest:
  - `CA_TARIFF_TOC_URL` (default: CBSA 2026 chapter-by-chapter page)
  - `CA_CHAPTER_CONCURRENCY` (default 4)
  - `CA_MAX_CHAPTERS` (optional, for testing)
  - `CA_GST_RATE_PCT` (default 5)
- API service:
  - `CA_COUNTRIES_TREATMENTS_URL` (default: CBSA countries page)
  - `CA_COUNTRIES_CACHE_TTL_MS` (default 6h)

