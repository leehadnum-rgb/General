import { v4 as uuidv4 } from "uuid";
import { Connector, ConnectorResult, RunContext } from "./base";
import { parseRateToAst } from "../lib/parseRateToAst";

const OPEN_END = process.env.OPEN_END_DATE ?? "9999-12-31";

const DEFAULT_TOC_URL =
  process.env.CA_TARIFF_TOC_URL ??
  "https://www.cbsa-asfc.gc.ca/trade-commerce/tariff-tarif/2026/html/tblmod-eng.html";

function timeoutMs() {
  return Number(process.env.HTTP_TIMEOUT_MS ?? "30000");
}

function chapterConcurrency(): number {
  const n = Number(process.env.CA_CHAPTER_CONCURRENCY ?? "4");
  return Number.isFinite(n) && n > 0 ? Math.floor(n) : 4;
}

function maxChapters(): number | null {
  const raw = process.env.CA_MAX_CHAPTERS;
  if (!raw) return null;
  const n = Number(raw);
  if (!Number.isFinite(n) || n <= 0) return null;
  return Math.floor(n);
}

async function fetchText(url: string): Promise<string> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs());
  try {
    const res = await fetch(url, { signal: ctrl.signal, headers: { "accept": "text/html,*/*" } });
    if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
    return await res.text();
  } finally {
    clearTimeout(t);
  }
}

function absUrl(base: string, href: string): string {
  try {
    return new URL(href, base).toString();
  } catch {
    return href;
  }
}

/**
 * Very lightweight HTML-to-text for the CBSA tariff pages.
 * We only need robust-enough line extraction for the tariff table rows.
 */
function htmlToText(html: string): string {
  return String(html ?? "")
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/(tr|p|div|li|h[1-6]|table|thead|tbody|tfoot)>/gi, "\n")
    .replace(/<\/td>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, "\"")
    .replace(/&#39;/gi, "'")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/\u00A0/g, " ")
    .replace(/\r/g, "\n");
}

function normalizeDigits(code: string): string {
  return (code ?? "").replace(/[^0-9]/g, "");
}

function looksLikeRate(tok: string): boolean {
  const t = String(tok ?? "").trim();
  if (!t) return false;
  if (/^free$/i.test(t)) return true;
  if (/%/.test(t)) return true;
  if (/[¢$]/.test(t)) return true;
  if (/cent(s)?/i.test(t)) return true;
  if (/^\d+(\.\d+)?$/.test(t)) return true;
  return false;
}

type ParsedRow = {
  codeDigits: string;          // 8 or 10 digits
  codeLen: number;
  description: string;
  unitCode: string | null;
  mfnRateText: string;
  prefLines: string[];
  sourceRef: string;
};

function splitAndTrimCsv(s: string): string[] {
  return String(s ?? "")
    .split(",")
    .map((x) => x.trim())
    .filter(Boolean)
    .map((x) => x.replace(/[^A-Z0-9]/gi, "").toUpperCase())
    .filter(Boolean);
}

function parsePreferentialLines(lines: string[]): Record<string, string> {
  const out: Record<string, string> = {};
  for (const raw of lines) {
    const t = String(raw ?? "").replace(/\u00A0/g, " ").trim();
    if (!t) continue;

    // Common pattern: "AUT, NZT, ... UKT: Free"
    // Also can appear as "CPTPT: Free"
    const colon = t.indexOf(":");
    if (colon !== -1) {
      const lhs = t.slice(0, colon).trim();
      const rhs = t.slice(colon + 1).trim();
      const codes = splitAndTrimCsv(lhs);
      if (codes.length && rhs) {
        for (const c of codes) out[c] = rhs;
        continue;
      }
    }

    // Continuation pattern: "GPT 6%" (no colon)
    const m = t.match(/^([A-Z]{2,6})\s+(.+)$/);
    if (m) {
      const code = m[1]!.trim().toUpperCase();
      const rate = m[2]!.trim();
      if (code && rate) out[code] = rate;
      continue;
    }

    // Fallback: if it's just a code list, stash as "UNKNOWN"
    const codes = splitAndTrimCsv(t);
    if (codes.length) {
      for (const c of codes) out[c] = out[c] ?? "UNKNOWN";
    }
  }
  return out;
}

function parseChapterTable(text: string, chapterUrl: string): ParsedRow[] {
  const lines = String(text ?? "")
    .split("\n")
    .map((l) =>
      l
        .replace(/\s+/g, " ")
        .replace(/%([A-Z])/g, "% $1")       // fix missing whitespace between rate and next col
        .replace(/Free([A-Z])/gi, "Free $1") // fix "FreeCCCT"
        .trim()
    )
    .filter(Boolean);

  const rows: ParsedRow[] = [];
  let current: ParsedRow | null = null;

  function flush() {
    if (!current) return;
    // discard if codeLen not 8/10 or missing MFN
    if ((current.codeLen === 8 || current.codeLen === 10) && current.mfnRateText) rows.push(current);
    current = null;
  }

  for (const l of lines) {
    // 10-digit row: "8703.24.00 21 ..."
    const m10 = l.match(/^(\d{4}\.\d{2}\.\d{2})\s+(\d{2})\s+(.+)$/);
    if (m10) {
      flush();
      const tariffItem = m10[1]!;
      const ss = m10[2]!;
      const rest = m10[3]!;
      const tokens = rest.split(" ");

      // Find unit+rate boundary
      let unitIdx = -1;
      for (let i = 0; i < tokens.length - 1; i++) {
        const tok = tokens[i]!;
        const next = tokens[i + 1]!;
        if (/^[A-Z]{2,4}$/.test(tok) && looksLikeRate(next)) {
          unitIdx = i;
          break;
        }
      }
      if (unitIdx === -1) continue;

      const desc = tokens.slice(0, unitIdx).join(" ").trim();
      const unit = tokens[unitIdx]!;
      const mfn = tokens[unitIdx + 1]!;
      const pref = tokens.slice(unitIdx + 2).join(" ").trim();

      const codeDigits = normalizeDigits(tariffItem) + String(ss);
      current = {
        codeDigits,
        codeLen: codeDigits.length,
        description: desc,
        unitCode: unit || null,
        mfnRateText: mfn,
        prefLines: pref ? [pref] : [],
        sourceRef: `${chapterUrl}#${tariffItem}-${ss}`,
      };
      continue;
    }

    // 8-digit row (no SS): "0201.10.20 Meat ... KGM 26.5% ..."
    const m8 = l.match(/^(\d{4}\.\d{2}\.\d{2})\s+(.+)$/);
    if (m8) {
      // If it was actually a 10-digit row, we'd have matched m10 already.
      // For 8-digit rows, we still need to find unit+rate boundary.
      const tariffItem = m8[1]!;
      const rest = m8[2]!;
      const tokens = rest.split(" ");

      // If the first token looks like a 2-digit SS, ignore (should have been m10).
      if (/^\d{2}$/.test(tokens[0] ?? "")) continue;

      let unitIdx = -1;
      for (let i = 0; i < tokens.length - 1; i++) {
        const tok = tokens[i]!;
        const next = tokens[i + 1]!;
        if (/^[A-Z]{2,4}$/.test(tok) && looksLikeRate(next)) {
          unitIdx = i;
          break;
        }
      }
      if (unitIdx === -1) {
        // likely a heading row without tariff rates
        continue;
      }

      // New row => flush previous
      flush();

      const desc = tokens.slice(0, unitIdx).join(" ").trim();
      const unit = tokens[unitIdx]!;
      const mfn = tokens[unitIdx + 1]!;
      const pref = tokens.slice(unitIdx + 2).join(" ").trim();

      const codeDigits = normalizeDigits(tariffItem); // 8 digits
      current = {
        codeDigits,
        codeLen: codeDigits.length,
        description: desc,
        unitCode: unit || null,
        mfnRateText: mfn,
        prefLines: pref ? [pref] : [],
        sourceRef: `${chapterUrl}#${tariffItem}`,
      };
      continue;
    }

    // Continuation lines for the preferential column (e.g., "GPT 6%").
    if (current) {
      // Heuristic: accept short lines starting with a tariff treatment code.
      if (/^[A-Z]{2,6}\b/.test(l) && l.length <= 200) {
        current.prefLines.push(l);
      }
    }
  }

  flush();
  return rows;
}

async function runWithLimit<T>(items: T[], limit: number, worker: (item: T) => Promise<void>) {
  const queue = [...items];
  const runners: Promise<void>[] = [];

  async function runOne() {
    while (queue.length) {
      const item = queue.shift()!;
      await worker(item);
    }
  }

  for (let i = 0; i < Math.max(1, limit); i++) runners.push(runOne());
  await Promise.all(runners);
}

export class CaConnector implements Connector {
  readonly sourceName = "CBSA Customs Tariff (HTML)";

  async run(ctx: RunContext): Promise<ConnectorResult> {
    const tocUrl = DEFAULT_TOC_URL;
    const tocHtml = await fetchText(tocUrl);

    // Extract chapter HTML links. Prefer explicit chapter pages.
    const re = /href="([^"]*ch\d{2}-eng\.html)"/gi;
    const urls = new Set<string>();
    let m: RegExpExecArray | null;
    while ((m = re.exec(tocHtml))) {
      const href = m[1]!;
      urls.add(absUrl(tocUrl, href));
    }

    let chapterUrls = [...urls].sort();
    const max = maxChapters();
    if (max) chapterUrls = chapterUrls.slice(0, max);

    if (chapterUrls.length === 0) {
      throw new Error(`CA connector: could not find chapter links in ${tocUrl}`);
    }

    const tariffLines: any[] = [];
    const expressions: any[] = [];
    const measures: any[] = [];

    const rows: ParsedRow[] = [];

    await runWithLimit(chapterUrls, chapterConcurrency(), async (chapterUrl) => {
      const html = await fetchText(chapterUrl);
      const txt = htmlToText(html);
      const parsed = parseChapterTable(txt, chapterUrl);
      rows.push(...parsed);
      console.log(`[ingest:CA] parsed ${parsed.length} rows from ${chapterUrl}`);
    });

    // Build canonical records
    const seen = new Set<string>(); // codeDigits (avoid duplicates)
    for (const r of rows) {
      const codeDigits = r.codeDigits;
      if (!codeDigits) continue;
      if (seen.has(codeDigits)) continue;
      seen.add(codeDigits);

      const tariffLineId = uuidv4();

      tariffLines.push({
        tariffLineId,
        jurisdictionId: "CA",
        code: codeDigits,
        codeLen: codeDigits.length,
        description: r.description || null,
        validFrom: ctx.asOfDate,
        validTo: OPEN_END,
        sourceRef: r.sourceRef ?? null,
      });

      // MFN duty
      {
        const expressionId = uuidv4();
        const measureId = uuidv4();

        const parsed = parseRateToAst(String(r.mfnRateText ?? ""), {
          defaultCurrency: "CAD",
          defaultMassField: "net_mass_kg",
        });

        if (parsed.ok) {
          expressions.push({
            expressionId,
            exprType: parsed.exprType,
            astJson: parsed.ast,
            currency: parsed.exprType === "SPECIFIC" ? "CAD" : null,
            unitCode: null,
            sourceRef: parsed.normalized,
          });

          measures.push({
            measureId,
            tariffLineId,
            expressionId,
            measureType: "CUSTOMS_DUTY",
            originScope: "MFN",
            originCode: "ALL",
            validFrom: ctx.asOfDate,
            validTo: OPEN_END,
            sourceRef: "MFN",
          });
        } else {
          expressions.push({
            expressionId,
            exprType: "CUSTOM",
            astJson: { op: "manual_required", raw: r.mfnRateText, reason: parsed.reason, message: parsed.message },
            currency: null,
            unitCode: null,
            sourceRef: null,
          });

          measures.push({
            measureId,
            tariffLineId,
            expressionId,
            measureType: "CUSTOMS_DUTY",
            originScope: "MFN",
            originCode: "ALL",
            validFrom: ctx.asOfDate,
            validTo: OPEN_END,
            sourceRef: "manual_required",
          });
        }
      }

      // Preferential tariffs (stored by tariff-treatment code in originCode).
      const prefMap = parsePreferentialLines(r.prefLines);
      for (const [treatCode, rateText] of Object.entries(prefMap)) {
        if (!treatCode || !rateText || rateText === "UNKNOWN") continue;

        const expressionId = uuidv4();
        const measureId = uuidv4();

        const parsed = parseRateToAst(String(rateText ?? ""), {
          defaultCurrency: "CAD",
          defaultMassField: "net_mass_kg",
        });

        if (parsed.ok) {
          expressions.push({
            expressionId,
            exprType: parsed.exprType,
            astJson: parsed.ast,
            currency: parsed.exprType === "SPECIFIC" ? "CAD" : null,
            unitCode: null,
            sourceRef: parsed.normalized,
          });

          measures.push({
            measureId,
            tariffLineId,
            expressionId,
            measureType: "CUSTOMS_DUTY",
            originScope: "PREFERENTIAL",
            originCode: treatCode,
            validFrom: ctx.asOfDate,
            validTo: OPEN_END,
            sourceRef: treatCode,
          });
        } else {
          expressions.push({
            expressionId,
            exprType: "CUSTOM",
            astJson: { op: "manual_required", raw: rateText, reason: parsed.reason, message: parsed.message },
            currency: null,
            unitCode: null,
            sourceRef: null,
          });

          measures.push({
            measureId,
            tariffLineId,
            expressionId,
            measureType: "CUSTOMS_DUTY",
            originScope: "PREFERENTIAL",
            originCode: treatCode,
            validFrom: ctx.asOfDate,
            validTo: OPEN_END,
            sourceRef: "manual_required",
          });
        }
      }
    }

    // GST/VAT
    const gstPct = String(process.env.CA_GST_RATE_PCT ?? "5").trim() || "5";

    const vatRules = [
      {
        vatRuleId: uuidv4(),
        jurisdictionId: "CA",
        rateType: "STANDARD",
        ratePct: gstPct,
        validFrom: ctx.asOfDate,
        validTo: OPEN_END,
        sourceRef: "CA GST (standard)",
      },
    ];

    const vatBaseFormulas = [
      {
        vatBaseFormulaId: uuidv4(),
        jurisdictionId: "CA",
        astJson: {
          op: "add",
          terms: [
            { op: "field", name: "customs_value" },
            { op: "field", name: "customs_duty_total" },
            { op: "field", name: "freight_to_border" },
            { op: "field", name: "insurance_to_border" },
          ],
        },
        validFrom: ctx.asOfDate,
        validTo: OPEN_END,
        sourceRef: "CA GST base (MVP)",
      },
    ];

    return {
      canonical: {
        tariffLines,
        expressions,
        measures,
        vatRules,
        vatBaseFormulas,
        thresholdRules: [],
      },
      manifest: {
        runId: ctx.runId,
        jurisdictionId: ctx.jurisdictionId,
        asOfDate: ctx.asOfDate,
        sourceName: this.sourceName,
        tocUrl,
        chapters: chapterUrls.length,
        rowsParsed: rows.length,
        rowsKept: tariffLines.length,
        chapterConcurrency: chapterConcurrency(),
      },
    };
  }
}
