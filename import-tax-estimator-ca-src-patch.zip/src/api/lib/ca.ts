/**
 * Canada (CA) helper: map ISO alpha-2 origin to Canadian tariff treatment codes
 * using CBSA's "List of countries and applicable tariff treatments" HTML page.
 *
 * We do NOT store country membership lists in Postgres for CA; instead we:
 *  - store preferential measures keyed by tariff-treatment code (originCode = "UST", "CPTPT", ...)
 *  - at request-time, mark measures whose treatment applies to the user's origin as matching that origin.
 *
 * This keeps the DB compact and avoids building a giant origin→membership expansion at ingest time.
 */
export type CaCountryTreatments = {
  mfn: boolean;
  gpt: boolean;
  ldct: boolean;
  other: string[]; // tariff treatment codes (e.g., ["UST","CPTPT"])
};

const DEFAULT_COUNTRIES_URL =
  process.env.CA_COUNTRIES_TREATMENTS_URL ??
  "https://www.cbsa-asfc.gc.ca/trade-commerce/tariff-tarif/2026/html/countries-pays-eng.html";

function timeoutMs() {
  return Number(process.env.HTTP_TIMEOUT_MS ?? "30000");
}

function ttlMs() {
  return Number(process.env.CA_COUNTRIES_CACHE_TTL_MS ?? String(6 * 60 * 60 * 1000)); // 6h
}

async function fetchText(url: string): Promise<string> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs());
  try {
    const res = await fetch(url, { signal: ctrl.signal, headers: { accept: "text/html,*/*" } });
    if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
    return await res.text();
  } finally {
    clearTimeout(t);
  }
}

function htmlToText(html: string): string {
  return String(html ?? "")
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/(tr|p|div|li|h[1-6]|table|thead|tbody|tfoot)>/gi, "\n")
    .replace(/<\/td>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/\u00A0/g, " ")
    .replace(/\r/g, "\n");
}

function normName(name: string): string {
  return String(name ?? "")
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "")
    .toLowerCase()
    .replace(/['’`"]/g, " ")
    .replace(/[^a-z0-9]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function parseYesNo(s: string): boolean {
  return String(s ?? "").trim().toLowerCase() === "yes";
}

function parseOther(s: string): string[] {
  return String(s ?? "")
    .split(",")
    .map((x) => x.trim())
    .filter(Boolean)
    .map((x) => x.replace(/[^A-Z0-9]/gi, "").toUpperCase())
    .filter(Boolean);
}

type Cache = { fetchedAt: number; byName: Map<string, CaCountryTreatments> };

let cache: Cache | null = null;

async function loadCountriesTable(): Promise<Map<string, CaCountryTreatments>> {
  const now = Date.now();
  if (cache && now - cache.fetchedAt < ttlMs()) return cache.byName;

  const url = DEFAULT_COUNTRIES_URL;
  const html = await fetchText(url);
  const text = htmlToText(html);

  // The CBSA page renders as a simple table, and after stripping HTML
  // the rows are typically:
  // "Australia yes no no AUT, CPTPT"
  // "United States of America yes no no UST"
  const byName = new Map<string, CaCountryTreatments>();

  for (const rawLine of text.split("\n")) {
    const line = rawLine.replace(/\s+/g, " ").trim();
    if (!line) continue;
    if (/^country name\b/i.test(line)) continue;

    const m = line.match(/^(.*)\s+(yes|no)\s+(yes|no)\s+(yes|no)\s*(.*)$/i);
    if (!m) continue;

    const country = m[1]!.trim();
    const mfn = parseYesNo(m[2]!);
    const gpt = parseYesNo(m[3]!);
    const ldct = parseYesNo(m[4]!);
    const other = parseOther(m[5] ?? "");

    byName.set(normName(country), { mfn, gpt, ldct, other });
  }

  cache = { fetchedAt: now, byName };
  return byName;
}

/**
 * Converts ISO alpha-2 to an English country name using Intl, then normalizes
 * to match the CBSA table.
 */
function iso2ToCbsaCountryName(iso2: string): string | null {
  const code = String(iso2 ?? "").trim().toUpperCase();
  if (!/^[A-Z]{2}$/.test(code)) return null;

  // Intl.DisplayNames mapping can vary ("Czechia" vs "Czech Republic", etc.)
  const display = new Intl.DisplayNames(["en"], { type: "region" });
  const baseName = display.of(code) ?? null;

  const overrides: Record<string, string> = {
    US: "United States of America",
    CZ: "Czech Republic",
    KR: "South Korea",
    KP: "North Korea",
    RU: "Russia",
    TR: "Turkey",
    SZ: "Swaziland",
    CV: "Cape Verde",
    MM: "Burma",
  };

  return overrides[code] ?? baseName;
}

/**
 * Returns the set of tariff treatment codes potentially applicable for an origin.
 *
 * Always includes "MFN" if the CBSA table says MFN=yes.
 * Includes "GPT" and "LDCT" based on the table columns.
 * Includes all codes from the "Other" column (e.g., UST, CPTPT, CEUT, UKT, etc.).
 */
export async function getCanadaTariffTreatments(originIso2: string): Promise<string[]> {
  const name = iso2ToCbsaCountryName(originIso2);
  if (!name) return ["MFN"];

  const tbl = await loadCountriesTable();
  const rec = tbl.get(normName(name));
  if (!rec) return ["MFN"];

  const codes: string[] = [];
  if (rec.mfn) codes.push("MFN");
  if (rec.gpt) codes.push("GPT");
  if (rec.ldct) codes.push("LDCT");
  for (const c of rec.other) codes.push(c);

  // stable + unique
  return [...new Set(codes.map((c) => String(c ?? "").trim().toUpperCase()).filter(Boolean))];
}

/**
 * Marks CA preferential measures as matching the user's origin if the tariff-treatment
 * code applies to that origin, per the CBSA countries table.
 */
export async function applyCanadaOriginToMeasures<T extends { measureType: string; originScope: string; originCode: string; originMemberCodes?: string[] | null }>(
  measures: T[],
  originIso2?: string
): Promise<T[]> {
  const origin = String(originIso2 ?? "").trim().toUpperCase();
  if (!origin) return measures;
  if (!/^[A-Z]{2}$/.test(origin)) return measures;

  const treatments = await getCanadaTariffTreatments(origin);

  // Only patch duty measures; fees/excise can remain as-is.
  return measures.map((m) => {
    if (m.measureType !== "CUSTOMS_DUTY") return m;
    if (m.originScope !== "PREFERENTIAL") return m;

    const treat = String(m.originCode ?? "").trim().toUpperCase();
    if (!treat) return m;
    if (!treatments.includes(treat)) return m;

    return { ...m, originMemberCodes: [origin] };
  });
}
