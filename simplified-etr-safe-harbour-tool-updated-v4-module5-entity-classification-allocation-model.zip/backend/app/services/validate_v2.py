from __future__ import annotations

from typing import Dict, List, Optional, Set, Tuple

from app.services.models_v2 import (
    CalculationRequestV2,
    ValidationIssueV2,
    ValidationResponseV2,
)


def _issue(
    issues: List[ValidationIssueV2],
    *,
    severity: str,
    code: str,
    message: str,
    path: Optional[str] = None,
    tested_jurisdiction_id: Optional[str] = None,
    entity_id: Optional[str] = None,
) -> None:
    issues.append(
        ValidationIssueV2(
            severity=severity,
            code=code,
            message=message,
            path=path,
            tested_jurisdiction_id=tested_jurisdiction_id,
            entity_id=entity_id,
        )
    )


def validate_request_v2(req: CalculationRequestV2) -> ValidationResponseV2:
    """Validate a CalculationRequestV2 for completeness and allocation readiness.

    This endpoint does not mutate the request. It returns a list of issues with severities.

    Module 5 focus:
      - Entity classification presence / consistency (Section 6 scaffolding).
      - Presence of PE / flow-through registers when such entity types exist.
      - ID reference checks for allocation-ready registers.

    Note: The allocation engine (OECD section 5.1) is introduced in a later module.
    Validation here aims to prevent users from believing an allocation outcome is being computed
    when key register data is missing.
    """

    issues: List[ValidationIssueV2] = []

    tj_ids: Set[str] = {tj.tested_jurisdiction_id for tj in req.tested_jurisdictions}
    if len(tj_ids) != len(req.tested_jurisdictions):
        _issue(
            issues,
            severity="error",
            code="DUPLICATE_TESTED_JURISDICTION_ID",
            message="tested_jurisdictions contains duplicate tested_jurisdiction_id values; IDs must be unique.",
            path="$.tested_jurisdictions",
        )

    # Build entity index
    entity_index: Dict[str, Tuple[str, object]] = {}  # entity_id -> (tj_id, entity_obj)
    missing_entity_id_count = 0
    for tj in req.tested_jurisdictions:
        for e in tj.entities or []:
            eid = getattr(e, "entity_id", None)
            if not eid:
                missing_entity_id_count += 1
                continue
            if eid in entity_index:
                _issue(
                    issues,
                    severity="warning",
                    code="DUPLICATE_ENTITY_ID",
                    message=f"Entity_id '{eid}' appears in multiple Tested Jurisdictions; allocation registers may not resolve uniquely.",
                    tested_jurisdiction_id=tj.tested_jurisdiction_id,
                    entity_id=eid,
                    path="$.tested_jurisdictions[].entities[].entity_id",
                )
            entity_index[eid] = (tj.tested_jurisdiction_id, e)

    if missing_entity_id_count:
        _issue(
            issues,
            severity="warning",
            code="MISSING_ENTITY_ID",
            message=(
                f"{missing_entity_id_count} entity rows are missing entity_id. "
                "If you want to use PE / flow-through allocation registers, provide entity_id values for referenced entities."
            ),
            path="$.tested_jurisdictions[].entities[]",
        )

    # Build PE register index
    pe_by_id: Dict[str, object] = {pe.pe_id: pe for pe in (req.permanent_establishments or []) if getattr(pe, "pe_id", None)}
    pe_by_entity: Dict[str, object] = {
        pe.pe_entity_id: pe for pe in (req.permanent_establishments or []) if getattr(pe, "pe_entity_id", None)
    }

    # Flow-through allocation lines index
    fte_lines_by_entity: Dict[str, List[object]] = {}
    for line in req.flow_through_entities or []:
        fte_lines_by_entity.setdefault(line.flow_through_entity_id, []).append(line)

        if line.flow_through_tested_jurisdiction_id and line.flow_through_tested_jurisdiction_id not in tj_ids:
            _issue(
                issues,
                severity="error",
                code="UNKNOWN_FLOW_THROUGH_TJ",
                message=f"Flow-through allocation line references unknown flow_through_tested_jurisdiction_id '{line.flow_through_tested_jurisdiction_id}'.",
                path="$.flow_through_entities[]",
            )

        if line.owner_tested_jurisdiction_id and line.owner_tested_jurisdiction_id not in tj_ids:
            _issue(
                issues,
                severity="error",
                code="UNKNOWN_OWNER_TJ",
                message=f"Flow-through allocation line references unknown owner_tested_jurisdiction_id '{line.owner_tested_jurisdiction_id}'.",
                path="$.flow_through_entities[]",
            )

    # Allocable tax items reference checks (schema already enforces article values)
    for item in req.allocable_tax_items or []:
        if item.source_tested_jurisdiction_id and item.source_tested_jurisdiction_id not in tj_ids:
            _issue(
                issues,
                severity="error",
                code="UNKNOWN_ALLOCABLE_TAX_SOURCE_TJ",
                message=f"Allocable tax item references unknown source_tested_jurisdiction_id '{item.source_tested_jurisdiction_id}'.",
                path="$.allocable_tax_items[]",
            )
        if item.target_tested_jurisdiction_id and item.target_tested_jurisdiction_id not in tj_ids:
            _issue(
                issues,
                severity="error",
                code="UNKNOWN_ALLOCABLE_TAX_TARGET_TJ",
                message=f"Allocable tax item references unknown target_tested_jurisdiction_id '{item.target_tested_jurisdiction_id}'.",
                path="$.allocable_tax_items[]",
            )

        # Guidance for non-(b) items with no target (allocation vs exclusion decision)
        if item.globe_article != "4.3.2(b)" and not item.target_tested_jurisdiction_id:
            _issue(
                issues,
                severity="warning",
                code="ALLOCABLE_TAX_NO_TARGET",
                message=(
                    f"Allocable tax item '{item.item_id or item.label or '<unnamed>'}' tagged {item.globe_article} has no target_tested_jurisdiction_id. "
                    "Later OECD section 5.1 allocation modules may require an explicit allocation/exclusion decision."
                ),
                path="$.allocable_tax_items[]",
            )

    # Entity-type specific completeness checks
    for tj in req.tested_jurisdictions:
        for e in tj.entities or []:
            et = getattr(e, "entity_type", None) or "STANDARD_CE"
            eid = getattr(e, "entity_id", None)
            # PE requires register linkage
            if et == "PERMANENT_ESTABLISHMENT":
                linked = False
                pe_id = getattr(e, "pe_id", None)
                if pe_id and pe_id in pe_by_id:
                    linked = True
                if eid and eid in pe_by_entity:
                    linked = True
                if not linked:
                    _issue(
                        issues,
                        severity="warning",
                        code="PE_MISSING_REGISTER",
                        message=(
                            f"Entity '{e.entity_name}' (entity_id={eid or 'n/a'}) is classified as PERMANENT_ESTABLISHMENT but no matching permanent_establishments register entry was found. "
                            "Provide a register row keyed by pe_id and/or pe_entity_id."
                        ),
                        tested_jurisdiction_id=tj.tested_jurisdiction_id,
                        entity_id=eid,
                        path="$.tested_jurisdictions[].entities[]",
                    )

            # Flow-through / tax-transparent requires allocation lines
            if et in {"FLOW_THROUGH_ENTITY", "TAX_TRANSPARENT_ENTITY"}:
                if not eid:
                    _issue(
                        issues,
                        severity="warning",
                        code="FLOW_THROUGH_MISSING_ENTITY_ID",
                        message=(
                            f"Entity '{e.entity_name}' is classified as {et} but has no entity_id. "
                            "Provide entity_id to link to flow_through_entities allocation lines."
                        ),
                        tested_jurisdiction_id=tj.tested_jurisdiction_id,
                        path="$.tested_jurisdictions[].entities[]",
                    )
                else:
                    if eid not in fte_lines_by_entity:
                        _issue(
                            issues,
                            severity="warning",
                            code="FLOW_THROUGH_MISSING_ALLOCATION_LINES",
                            message=(
                                f"Entity '{e.entity_name}' (entity_id={eid}) is classified as {et} but has no flow_through_entities allocation lines. "
                                "Provide at least one allocation line to support OECD section 5.1 / section 6 deemed-zero logic."
                            ),
                            tested_jurisdiction_id=tj.tested_jurisdiction_id,
                            entity_id=eid,
                            path="$.flow_through_entities",
                        )

            # Tax-neutral UPE ownership
            if et == "TAX_NEUTRAL_UPE":
                qp = getattr(e, "qualified_persons_ownership_percentage", None)
                if qp is None:
                    _issue(
                        issues,
                        severity="warning",
                        code="TAX_NEUTRAL_MISSING_OWNERSHIP",
                        message=(
                            f"Entity '{e.entity_name}' is classified as TAX_NEUTRAL_UPE but qualified_persons_ownership_percentage is missing. "
                            "Provide a 0–1 proportion to support section 6 deemed-zero determination."
                        ),
                        tested_jurisdiction_id=tj.tested_jurisdiction_id,
                        entity_id=eid,
                        path="$.tested_jurisdictions[].entities[].qualified_persons_ownership_percentage",
                    )

    # Note about current module scope
    if (req.permanent_establishments or req.flow_through_entities or req.allocable_tax_items):
        _issue(
            issues,
            severity="warning",
            code="ALLOCATION_ENGINE_NOT_YET_APPLIED",
            message=(
                "Allocation-ready registers are provided. Note: the section 5.1 allocation engine is introduced in a later module; "
                "current calculations may not yet reflect PE/flow-through allocations unless separately modelled via other adjustments."
            ),
            path="$.permanent_establishments/$.flow_through_entities/$.allocable_tax_items",
        )

    return ValidationResponseV2(issues=issues)
