from __future__ import annotations

import csv
import io
import re
from datetime import date
from typing import Dict, List, Optional

from pydantic import BaseModel, Field

from app.services.models_v2 import FlowThroughEntityAllocationV2

_NUM_RE = re.compile(r"[^0-9eE+\-\.]")

def _norm_header(h: str) -> str:
    h = (h or "").strip().lower()
    h = re.sub(r"[\s\-]+", "_", h)
    return h

_ALIASES: Dict[str, str] = {
    "fte_id": "flow_through_entity_id",
    "flow_through_id": "flow_through_entity_id",
    "flow_through_entity": "flow_through_entity_id",
    "fte_name": "flow_through_entity_name",
    "fte_tj": "flow_through_tested_jurisdiction_id",
    "flow_through_tj": "flow_through_tested_jurisdiction_id",
    "owner_tj": "owner_tested_jurisdiction_id",
    "fy_start": "fiscal_year_start",
}

def _parse_float(raw: str) -> Optional[float]:
    if raw is None:
        return None
    s = str(raw).strip()
    if s == "":
        return None
    s = _NUM_RE.sub("", s)
    if s in {"", "+", "-", "."}:
        return None
    try:
        return float(s)
    except ValueError:
        return None

def _parse_date(raw: str) -> Optional[date]:
    if raw is None:
        return None
    s = str(raw).strip()
    if s == "":
        return None
    try:
        return date.fromisoformat(s)
    except ValueError:
        return None

class FlowThroughAllocationsCsvIssue(BaseModel):
    severity: str = Field(..., description="'error' or 'warning'")
    row_number: int = Field(..., ge=1, description="1-indexed row number in the CSV (excluding header).")
    field: Optional[str] = None
    message: str

class FlowThroughAllocationsCsvParseResult(BaseModel):
    flow_through_entities: List[FlowThroughEntityAllocationV2] = Field(default_factory=list)
    issues: List[FlowThroughAllocationsCsvIssue] = Field(default_factory=list)
    detected_columns: List[str] = Field(default_factory=list)
    ignored_columns: List[str] = Field(default_factory=list)

def generate_flow_through_entities_csv_template() -> bytes:
    headers = [
        "line_id",
        "flow_through_entity_id",
        "flow_through_entity_name",
        "flow_through_tested_jurisdiction_id",
        "owner_tested_jurisdiction_id",
        "fiscal_year_start",
        "income_allocated_amount",
        "tax_allocated_amount",
        "currency",
        "amount_scale",
        "note",
    ]
    example = {
        "line_id": "FTE-001",
        "flow_through_entity_id": "FTE-ENT-1",
        "flow_through_entity_name": "Flow-through Entity 1",
        "flow_through_tested_jurisdiction_id": "NL_MAIN",
        "owner_tested_jurisdiction_id": "US_MAIN",
        "fiscal_year_start": "2027-01-01",
        "income_allocated_amount": "50000",
        "tax_allocated_amount": "0",
        "currency": "EUR",
        "amount_scale": "UNITS",
        "note": "Example only",
    }
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=headers)
    w.writeheader()
    w.writerow(example)
    return buf.getvalue().encode("utf-8")

def parse_flow_through_entities_csv(contents: bytes) -> FlowThroughAllocationsCsvParseResult:
    text = contents.decode("utf-8-sig", errors="replace")
    buf = io.StringIO(text)
    reader = csv.DictReader(buf)
    if reader.fieldnames is None:
        return FlowThroughAllocationsCsvParseResult(
            flow_through_entities=[],
            issues=[FlowThroughAllocationsCsvIssue(severity="error", row_number=1, message="CSV is missing a header row.")],
        )

    raw_headers = list(reader.fieldnames)
    norm_to_raw: Dict[str, str] = {}
    for h in raw_headers:
        nh = _ALIASES.get(_norm_header(h), _norm_header(h))
        if nh and nh not in norm_to_raw:
            norm_to_raw[nh] = h

    allowed = set(FlowThroughEntityAllocationV2.model_fields.keys())
    ignored = [raw for nh, raw in norm_to_raw.items() if nh not in allowed]
    out = FlowThroughAllocationsCsvParseResult(detected_columns=raw_headers, ignored_columns=ignored)

    rows: List[FlowThroughEntityAllocationV2] = []
    for idx, row in enumerate(reader, start=1):
        data: Dict[str, object] = {}
        issues: List[FlowThroughAllocationsCsvIssue] = []

        for nh, raw in norm_to_raw.items():
            if nh not in allowed:
                continue
            val = row.get(raw)
            if nh in {"income_allocated_amount", "tax_allocated_amount"}:
                f = _parse_float(val)
                if f is not None:
                    data[nh] = f
            elif nh == "fiscal_year_start":
                d = _parse_date(val)
                if d is not None:
                    data[nh] = d
            else:
                if val is None:
                    continue
                s = str(val).strip()
                if s == "":
                    continue
                data[nh] = s

        if not data.get("flow_through_entity_id"):
            issues.append(FlowThroughAllocationsCsvIssue(severity="error", row_number=idx, field="flow_through_entity_id", message="Missing flow_through_entity_id."))
        if not data.get("owner_tested_jurisdiction_id"):
            issues.append(FlowThroughAllocationsCsvIssue(severity="error", row_number=idx, field="owner_tested_jurisdiction_id", message="Missing owner_tested_jurisdiction_id."))
        if issues:
            out.issues.extend(issues)

        try:
            if issues and any(i.severity == "error" for i in issues):
                continue
            rows.append(FlowThroughEntityAllocationV2.model_validate(data))
        except Exception as e:
            out.issues.append(FlowThroughAllocationsCsvIssue(severity="error", row_number=idx, message=f"Row validation failed: {e}"))

    out.flow_through_entities = rows
    return out
