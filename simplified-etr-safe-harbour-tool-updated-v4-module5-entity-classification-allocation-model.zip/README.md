# Simplified ETR Safe Harbour Tool (Prototype)

This is a **working prototype** of a web-based Simplified ETR Safe Harbour calculator aligned to the OECD
*Pillar Two – Side-by-Side Package (Jan 2026)*.

It provides:
- A FastAPI backend with:
  - JSON API to calculate Simplified Income, Simplified Taxes, Simplified ETR and Safe Harbour outcome
  - Excel template download
  - Excel upload ingestion + calculation
  - Election catalogue endpoint (used by the UI and embedded in the Excel template)
  - Trace-style output (step-by-step adjustments)
- A minimal HTML UI served by the backend (for demo / internal use)

> **Important**: This prototype is designed to be extended. The OECD rules include many elections and
> fact patterns that require additional inputs and/or rule modules.

## Quick start (local)

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open:
- UI: http://127.0.0.1:8000
- API docs: http://127.0.0.1:8000/docs

## Data inputs

You can:
1) Use the web UI for manual guided entry (jurisdiction mode or entity roll-up),
2) Upload the Excel template (download from `/api/v1/template`), or
3) Call the JSON endpoint directly:
   - `POST /api/v1/calc` (v1)
   - `POST /api/v2/calc` (v2)

The Excel template supports two modes (set in `Jurisdictions!C2`):

- `jurisdiction` (default): one row per Tested Jurisdiction in the **Jurisdictions** sheet.
- `entity_rollup`: one row per Constituent Entity in the **Entities** sheet; the tool rolls up amounts by jurisdiction.
  You can still populate **Jurisdictions** with jurisdiction-level elections/eligibility flags (zeros are fine for numeric columns).

The template also supports the **applicability date / optional early-start rule** inputs in `Jurisdictions!D2:G2`.
If your fiscal year starts in the 2025/2026 window, you can enable the early-start rule and indicate which
condition(s) are satisfied.

### Elections and “net impact” adjustments

The OECD package allows a number of elections (some annual, some five-year) and also requires adjustments that, in a production tool, would often be computed from source systems.

This prototype supports elections in two ways:

1) **Mapped elections**: elections that correspond to dedicated fields in the model (e.g. shipping 5-year election, AFXGL election, annual elections in Box 4.4).
2) **Unmapped elections**: everything else can be recorded as a **net signed income/tax impact** using:
   - `ElectionAdjustments` (recommended)
   - `IncomeAdjustments` and `TaxAdjustments` (generic fallback)

The template includes an `ElectionCatalog` sheet and the API exposes the same catalogue at `/api/v1/election-catalog`.

## v2 / v4 extensions (current recommended API)

The `/api/v2/...` endpoints are the recommended integration surface for Anything.com and other clients.
They add Tested Jurisdiction IDs (multiple buckets per country), structured cross-border and investment entity
adjustments, CSV ingestion helpers, and v4 election/FX scaffolding.

### v4 Module 1: Election manager ("until revoked")

- `ElectionInstanceV2` supports `action: ELECT | REVOKE`.
- FIVE_YEAR elections are treated as **continuing until revoked** (rather than expiring after 5 years).
- Shipping five-year election supports the OECD-style **revocation timing + 4-year cooldown**.

### v4 Module 2: Accounting basis + FX scaffolding

- Request supports `group_profile.reporting_currency` and `fx_rates[]`.
- Each Tested Jurisdiction supports `accounting_basis.currency` and `accounting_basis.amount_scale`.
- Added FX CSV template + parse endpoints:
  - `GET /api/v2/templates/fx-rates.csv`
  - `POST /api/v2/fx/parse-csv`

### v4 Module 3: FX translation conventions + tighter LFAS gating

- FX convention: **P&L items use average FX**, balance sheet items use **spot/closing FX** when provided.
  - If spot is not provided, the engine falls back to average FX and records this in the trace.
- Carryforward translation enhancement: if a carryforward includes `origin_fiscal_year_start`, the engine translates
  that balance using the **origin-year average FX rate** (when provided), otherwise falls back to the current year.
- LFAS / QDMTT gating is stricter:
  - `basis_source='OTHER'` is not allowed when `lfas_requires_local_gaap=true`.
  - If any QDMTT LFAS jurisdiction uses a permitted `basis_source='CFS'`, the request must apply the same choice
    across all QDMTT LFAS jurisdictions that allow that election (group-wide consistency within the request).

In addition, every `ElectionAdjustments` row is stored as an **audit trail** record (`election_records`) in the
JSON request/response so users can document metadata/eligibility elections even if they do not change current-year
amounts in this prototype.


### v4 Module 4: Transition Year rules (Box 4.5)

- Per Tested Jurisdiction: optional `transition_year` section to capture Transition Year mechanics.
- Added structured opening deferred tax items (`opening_deferred_tax_items[]`) to support Articles 9.1.1–9.1.2.
  - Balance-sheet translation uses **spot/closing FX** (when provided).
  - Implemented: **Article 9.1.2 disallowed opening DTA** adjustment (Transition Year only) as an explicit tax-side adjustment to Simplified Taxes.
- Added structured net adjustments for Article 9.1.3 transfers (`article_9_1_3_transfers[]`) applied from Transition Year onward:
  - `income_adjustment` impacts Simplified Income
  - `tax_adjustment` impacts Simplified Taxes

> Note: this tool is stateless. The Transition Year start date must be supplied (`transition_year_fy_start`). If omitted, the engine assumes the current request fiscal year is the Transition Year and records this in the trace.

### v4 Module 4.1: Transition Year deferred tax register (client-managed state)

To enable multi-year workflows without server-side persistence, the calculator returns a Transition Year deferred-tax state payload per Tested Jurisdiction:

- `transition_year_state_closing` (in the response)

The client stores this and supplies it in later-year requests as:

- `transition_year_state_opening` (in the request)

This allows the Transition Year register (including Article 9.1.2 disallowed opening DTA adjustments) to be carried forward consistently across years.

### v4 Module 4.2: Scenario helper endpoint (advance-year)

For multi-year "planner" UI flows, the API provides:

- `POST /api/v2/scenario/advance-year`

It accepts the last request and last response and returns a ready-to-edit next-year request payload. It will:

- advance the fiscal year start date by one year,
- roll forward `carryforwards_opening` from the prior-year `carryforwards_closing`,
- roll forward `transition_year_state_opening` from the prior-year `transition_year_state_closing`,
- optionally insert year-specific FX rows for the new fiscal year (copied from prior year where possible).



### v4 Module 4.4: After-year-end adjustments (Box 4.6) + TP counterpart handling (section 5.2)

The request supports structured "after-year-end adjustments" under OECD Box 4.6:

- `after_year_end_adjustments[]` on the request (v2)

Default timing (Box 4.6(1)):
- Included in the **accrual year** (`accrual_year_fy_start`).

Optional group-wide Five-Year Election (Box 4.6(2)):
- `AFTER_YEAR_END_ADJUSTMENTS_FIVE_YEAR_ELECTION_TRANSACTION_YEAR_METHOD`
- If effective for the **transaction year** and the adjustment accrues within 12 months following year end,
  it is included in the **transaction year** (`transaction_year_fy_start`).

Box 4.6(3) qualified refund exclusion:
- Supported via `apply_large_refund_exclusion=true` and related `qualification_basis` inputs (non-TP only).

Transfer pricing-related after-year-end adjustments (OECD section 5.2):
- If an adjustment row has `is_transfer_pricing_related=true`, it is **not** processed under Box 4.6(2).
- Instead, it is processed under the **section 5.2** timing rules and can apply structured counterparty treatment using:
  - `tp_counterparty_tested_jurisdiction_id`
  - `tp_counterparty_income_amount` (optional; defaults to -amount)
  - `tp_counterparty_tax_amount` (optional)
- Optional group-wide Five-Year Election (Box 5.2(2)):
  - `TP_FIVE_YEAR_ELECTION_TRANSACTION_YEAR_METHOD`

CSV helpers:
- `GET /api/v2/templates/after-year-end-adjustments.csv`
- `POST /api/v2/after-year-end-adjustments/parse-csv`



### v4 Module 5: Entity classification + allocation-ready data model

This module adds **classification scaffolding** and **register structures** required to support the OECD operational rules
in sections 5 and 6 (allocations and deemed-zero logic). It is designed for UI workflows where users upload entity data
and then progressively supply allocation registers.

#### Entity classification fields (entity roll-up)

Each entity row (in JSON or entity CSV) can now include:

- `entity_type` (default `STANDARD_CE`)
  - `PERMANENT_ESTABLISHMENT`
  - `FLOW_THROUGH_ENTITY`
  - `TAX_TRANSPARENT_ENTITY`
  - `INVESTMENT_ENTITY`
  - `INSURANCE_INVESTMENT_ENTITY`
  - `TAX_NEUTRAL_UPE`
  - `STATELESS`
- `is_upe` (bool)
- `qualified_persons_ownership_percentage` (0–1)
- `pe_id` and `main_entity_id` (PE linkage scaffolding)

Entity CSV template updated accordingly:

- `GET /api/v2/templates/entities.csv`

#### Allocation-ready registers added to the v2 request

The v2 request now supports:

- `permanent_establishments[]` (link PE ↔ Main Entity / TJ buckets)
- `flow_through_entities[]` (flow-through allocation lines to owner TJs)
- `allocable_tax_items[]` (Article 4.3.2(a)-(e) tagging for allocable tax items)

CSV helpers:

- `GET /api/v2/templates/permanent-establishments.csv`
- `POST /api/v2/permanent-establishments/parse-csv`
- `GET /api/v2/templates/flow-through-entities.csv`
- `POST /api/v2/flow-through-entities/parse-csv`
- `GET /api/v2/templates/allocable-tax-items.csv`
- `POST /api/v2/allocable-tax-items/parse-csv`

#### Tested Jurisdiction builder + validation helper

For UI clients that start from a flat entity upload:

- `POST /api/v2/tested-jurisdictions/build`

This groups entities into Tested Jurisdiction “buckets” (e.g., `GB_MAIN`, `GB_INVEST`) and returns a
`tested_jurisdictions[]` array ready to feed into `/api/v2/calc`.

To help clients prevent missing allocation data:

- `POST /api/v2/validate`

Returns `issues[]` with severities (`error`/`warning`) covering PE/flow-through linkage completeness and basic ID checks.

> Note: this module introduces the **data model and validation** needed for later allocation engine modules. Depending on the
> configuration, current `/api/v2/calc` results may not yet automatically reflect PE/flow-through allocations unless users model them
> through other explicit adjustments.


### Industry adjustments implemented

The prototype includes dedicated fields for the Side-by-Side package industry adjustments:

- **Financial services**: insurance company income exclusion (with annual election not to exclude), and AT1/RT1 adjustments + corresponding tax in equity/OCI.
- **Shipping**: International Shipping Income + Qualified Ancillary International Shipping Income exclusion, with a 5-year election not to exclude (applies only when aggregate shipping income is positive). Taxes on excluded shipping income are removed only when the exclusion applies.


### Conditional and optional adjustments implemented

The prototype now also includes dedicated fields for several **conditional/optional** adjustments from the Side-by-Side package:

- **Equity-reported items (Box 3.4.1)**: include positive equity-reported income in Simplified Income unless the waiver conditions are met (inputs provided as boolean flags).
- **M&A simplification (Box 3.4.2)**: supports the goodwill impairment/amortisation add-back, and removal of certain deferred-tax components from Simplified Taxes via explicit inputs (simplified modelling).
- **Article 6.3.4 election (referenced in Box 3.4.2)**: include a user-provided (full-year or pro-rata) GloBE-to-book Difference amount in Simplified Income.
- **Optional exclusions (Box 3.5.2)**: AFXGL and accrued pension expense adjustments, each with a five-year election not to apply.

> These are implemented as **explicit input fields** rather than an automated computation from transaction-level data. For production, you would typically compute these amounts from source ledgers / consolidation packs.

### How the prototype maps to the OECD framework

- **Safe harbour test**: Safe harbour outcome is `PASS` if Simplified ETR ≥ Minimum Rate **or** there is a Simplified Loss.
- **Simplified Income**: JPBT adjusted by Basic/Industry/Conditional/Optional adjustments.
- **Simplified Taxes**: JITE adjusted per policy/correlation/uncertain/not-payable/deferred tax recast logic.

This prototype currently implements the core mechanics and a subset of elections as explicit inputs.
You can expand by adding additional adjustment fields or new modules in `app/services/`.

## Docker (optional)

```bash
cd backend
docker build -t simplified-etr-tool .
docker run -p 8000:8000 simplified-etr-tool
```

## Project structure

```
backend/
  app/
    api/
      routes.py
    services/
      calculator.py
      election_catalog.py
      excel_io.py
      eligibility.py
      models.py
    main.py
    tests/
      test_calculator.py

```

## Tests

```bash
cd backend
PYTHONPATH=. python -m unittest discover -s app/tests -p "test*.py" -q
```

## License

Prototype / starter code. Add your own license terms for commercial distribution.


## API versions

This repository exposes two calculation endpoints:

---

### v1

- **v1**: `POST /api/v1/calc`
  - Backwards compatible with the prototype Excel template and the original JSON schema.
  - Groups results by `jurisdiction_code` (so it cannot distinguish multiple Tested Jurisdictions in the same country).

---

### v2

- **v2**: `POST /api/v2/calc`
  - Adds `tested_jurisdiction_id` (so you can model multiple Tested Jurisdictions per country/territory).
  - Adds multi-year election semantics (Annual vs Five-Year elections) and effective start dates.
  - Validates five-year election terms do not overlap (and supports an optional "cooldown" period via the election catalog).
  - Adds carryforward mechanics for:
    - Simplified Adjustment for Negative Taxes (Box 4.3),
    - Excess Negative Tax Carry-forward (Article 4.1.5 symmetry; user input),
    - Loss DTA Adjustment method (Box 4.3(4); user input).
  - Adds a `deemed_zero` override flag for certain tax-neutral entity scenarios (user input).
  - Adds **cross-border tax item exclusion/allocation** inputs (`cross_border_tax_items[]`) to move allocable tax items
    between Tested Jurisdictions (or exclude them), per Section 5 concepts.
  - Adds structured **Investment Entity owner addbacks** (`owner_addbacks[]`) for Articles 7.5/7.6 (signed adjustments to
    Simplified Income or Simplified Taxes).
  - Adds **accounting basis / currency translation scaffolding** (v4 module 2):
    - Per Tested Jurisdiction: `accounting_basis` (currency, amount_scale, LFAS flags).
    - Per request: `group_profile.reporting_currency` and `fx_rates[]`.
    - If a Tested Jurisdiction declares a different currency from the reporting currency, the engine translates monetary
      inputs using the matching `fx_rates` average rate (P&L convention). Results are returned in the reporting currency.

The v2 election catalogue is available at:
- `GET /api/v2/election-catalog` (same as `/api/election-catalog`, but v2 clients should use the versioned route)

### v2 helper endpoints (for UI builders)

These are designed to make it easier for UI tools (including Anything.com) to build a data-entry experience.

- `GET /api/v2/entities/csv-template`
  - Downloads a CSV template with headers + an example row for entity roll-up.
- `POST /api/v2/entities/parse-csv`
  - Upload a CSV (`multipart/form-data`) and parse it into EntityFactsV2 rows.
  - Returns parsed entities + a list of row-level issues.
  - If `allow_partial=false` (default) and there are any errors, returns HTTP 400 with the parsed issue list.
- `GET /api/v2/tested-jurisdiction/template`
  - Returns a skeleton `TestedJurisdictionInputV2` object you can use to seed UI state.
  - Supports optional query params such as `aggregation_method` and `tested_jurisdiction_type`.

- `GET /api/v2/templates/fx-rates.csv`
  - Downloads a CSV template for FX rate uploads.
- `POST /api/v2/fx/parse-csv`
  - Upload a CSV (`multipart/form-data`) and parse it into `FxRateV2` rows (for UI preview/validation).

