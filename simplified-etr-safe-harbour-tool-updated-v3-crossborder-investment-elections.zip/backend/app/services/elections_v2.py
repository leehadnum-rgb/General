from __future__ import annotations

from datetime import date

from app.services.models import AdjustmentLine, ElectionRecord, JurisdictionInput, TraceLine
from app.services.models_v2 import ElectionInstanceV2, TermType
from app.services.election_catalog import ELECTIONS_BY_CODE


# Election codes that are *inputs* for v2 carryforward mechanics and must NOT be treated
# as generic tax adjustments.
_SPECIAL_NON_ADJUSTMENT_CODES: set[str] = {
    "LOSS_DTA_ADJUSTMENT_GENERATED_AMOUNT",
    "LOSS_DTA_REVERSAL_TENTATIVE_AMOUNT",
}


def _add_years(d: date, years: int) -> date:
    """Add years to a date, preserving month/day where possible."""
    try:
        return d.replace(year=d.year + years)
    except ValueError:
        # 29 Feb -> 28 Feb on non-leap year
        return d.replace(month=2, day=28, year=d.year + years)


def _infer_term_type(code: str, provided: TermType | None) -> TermType:
    if provided:
        return provided
    edef = ELECTIONS_BY_CODE.get(code)
    if edef is not None:
        return edef.term_type
    return "ANNUAL"


def _validate_election_timeline(
    elections: list[ElectionInstanceV2],
    fiscal_year_start: date,
) -> None:
    """Validate the election "register" passed in v2.

    This tool is stateless, so the client must send all relevant election history.
    We therefore validate for common multi-year issues:

    - duplicate elections for the same code/effective start;
    - overlapping FIVE_YEAR elections for the same code;
    - cooldown violations for FIVE_YEAR elections (if configured in the catalog).

    If validation fails, raise ValueError with a user-correctable message.
    """

    # Normalise instances (infer term + default effective date)
    norm: list[ElectionInstanceV2] = []
    for e in elections:
        eff = e.effective_fiscal_year_start or fiscal_year_start
        term = _infer_term_type(e.election_code, e.term_type)
        norm.append(e.model_copy(update={"effective_fiscal_year_start": eff, "term_type": term}))

    # Group by code
    by_code: dict[str, list[ElectionInstanceV2]] = {}
    for e in norm:
        by_code.setdefault(e.election_code, []).append(e)

    errors: list[str] = []

    for code, lst in by_code.items():
        # Sort by effective start
        lst_sorted = sorted(lst, key=lambda x: x.effective_fiscal_year_start or fiscal_year_start)

        # Duplicate effective starts are never valid (they are ambiguous)
        seen: set[date] = set()
        for e in lst_sorted:
            eff = e.effective_fiscal_year_start or fiscal_year_start
            if eff in seen:
                errors.append(
                    f"Election timeline error for '{code}': duplicate effective_fiscal_year_start={eff.isoformat()}."
                )
            seen.add(eff)

        term = _infer_term_type(code, None)
        if term != "FIVE_YEAR":
            continue

        edef = ELECTIONS_BY_CODE.get(code)
        cooldown = int(getattr(edef, "cooldown_years", 0) or 0)

        # Check overlap/cooldown sequentially
        for i in range(len(lst_sorted) - 1):
            cur = lst_sorted[i]
            nxt = lst_sorted[i + 1]
            cur_eff = cur.effective_fiscal_year_start or fiscal_year_start
            nxt_eff = nxt.effective_fiscal_year_start or fiscal_year_start
            cur_end = _add_years(cur_eff, 5)

            if nxt_eff < cur_end:
                errors.append(
                    f"Election timeline error for '{code}': FIVE_YEAR terms overlap "
                    f"(next starts {nxt_eff.isoformat()} before current term ends {cur_end.isoformat()})."
                )
                continue

            if cooldown > 0:
                earliest = _add_years(cur_end, cooldown)
                if nxt_eff < earliest:
                    errors.append(
                        f"Election timeline error for '{code}': cooldown violation "
                        f"(next starts {nxt_eff.isoformat()} but earliest allowed is {earliest.isoformat()})."
                    )

    if errors:
        raise ValueError("; ".join(errors))


def resolve_effective_elections(
    elections: list[ElectionInstanceV2],
    fiscal_year_start: date,
) -> list[ElectionInstanceV2]:
    """Return elections effective for the fiscal year (based on term type + effective start)."""
    # Validate multi-year election timeline (overlaps/cooldown) so we don't silently apply inconsistent elections.
    _validate_election_timeline(elections, fiscal_year_start)
    out: list[ElectionInstanceV2] = []
    for e in elections:
        eff = e.effective_fiscal_year_start or fiscal_year_start
        term = _infer_term_type(e.election_code, e.term_type)

        # Normalise instance values (copy)
        e_norm = e.model_copy(update={"effective_fiscal_year_start": eff, "term_type": term})

        if term == "ANNUAL":
            if eff == fiscal_year_start:
                out.append(e_norm)
            continue

        # FIVE_YEAR
        if term == "FIVE_YEAR":
            if fiscal_year_start >= eff and fiscal_year_start < _add_years(eff, 5):
                out.append(e_norm)
            continue

        # Fallback - should not happen
        if eff == fiscal_year_start:
            out.append(e_norm)

    # Stable ordering by group/label is handled in UI; preserve request order here.
    return out


def apply_effective_elections_to_meta(
    meta: JurisdictionInput,
    effective: list[ElectionInstanceV2],
) -> tuple[JurisdictionInput, list[TraceLine]]:
    """Apply effective elections to a v1 JurisdictionInput meta row.

    - Mapped elections update meta.<target_field>.
    - Unmapped amount elections become AdjustmentLine entries in other_income_adjustments / other_tax_adjustments.
    - All elections are recorded as ElectionRecord audit lines.
    """

    trace: list[TraceLine] = []
    for e in effective:
        edef = ELECTIONS_BY_CODE.get(e.election_code)
        label = e.label or (edef.label if edef else e.election_code)

        # Always preserve an audit record
        rec = ElectionRecord(
            scope=e.scope,
            election_code=e.election_code,
            label=label,
            bool_value=e.bool_value,
            amount=e.amount,
            note=e.note,
        )
        meta.election_records.append(rec)

        # Skip special v2 input-only codes (do not alter taxes/income)
        if e.election_code in _SPECIAL_NON_ADJUSTMENT_CODES:
            continue

        if edef and edef.target_field:
            # Mapped election -> set field on meta
            if e.value_type == "bool":
                setattr(meta, edef.target_field, bool(e.bool_value))
            elif e.value_type == "amount":
                setattr(meta, edef.target_field, float(e.amount or 0.0))
            elif e.value_type == "text":
                setattr(meta, edef.target_field, str(e.text_value or ""))
            trace.append(
                TraceLine(
                    section=e.scope if e.scope in ("income", "tax") else "eligibility",
                    step=f"Election applied: {label}",
                    amount=0.0,
                    note=f"Mapped to field '{edef.target_field}'.",
                )
            )
            continue

        # Unmapped amount elections: treat as generic adjustment lines
        if e.value_type == "amount" and e.scope in ("income", "tax"):
            adj = AdjustmentLine(
                label=f"Election: {label}",
                amount=float(e.amount or 0.0),
                category="election",
                note=e.note,
            )
            if e.scope == "income":
                meta.other_income_adjustments.append(adj)
            else:
                meta.other_tax_adjustments.append(adj)
            trace.append(
                TraceLine(
                    section=e.scope,
                    step=f"Election adjustment applied: {label}",
                    amount=float(e.amount or 0.0),
                    running_total=None,
                    note="Unmapped election treated as a net adjustment line.",
                )
            )

    return meta, trace


def get_effective_election_amount(
    effective: list[ElectionInstanceV2],
    code: str,
) -> float | None:
    for e in effective:
        if e.election_code == code and e.value_type == "amount":
            return float(e.amount or 0.0)
    return None


def get_effective_election_bool(
    effective: list[ElectionInstanceV2],
    code: str,
) -> bool | None:
    for e in effective:
        if e.election_code == code and e.value_type == "bool":
            return bool(e.bool_value)
    return None
