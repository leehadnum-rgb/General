# Simplified ETR Safe Harbour Tool (Prototype)

This is a **working prototype** of a web-based Simplified ETR Safe Harbour calculator aligned to the OECD
*Pillar Two – Side-by-Side Package (Jan 2026)*.

It provides:
- A FastAPI backend with:
  - JSON API to calculate Simplified Income, Simplified Taxes, Simplified ETR and Safe Harbour outcome
  - Excel template download
  - Excel upload ingestion + calculation
  - Election catalogue endpoint (used by the UI and embedded in the Excel template)
  - Trace-style output (step-by-step adjustments)
- A minimal HTML UI served by the backend (for demo / internal use)

> **Important**: This prototype is designed to be extended. The OECD rules include many elections and
> fact patterns that require additional inputs and/or rule modules.

## Quick start (local)

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open:
- UI: http://127.0.0.1:8000
- API docs: http://127.0.0.1:8000/docs

## Data inputs

You can:
1) Use the web UI for manual guided entry (jurisdiction mode or entity roll-up),
2) Upload the Excel template (download from `/api/v1/template`), or
3) Call the JSON endpoint directly:
   - `POST /api/v1/calc` (v1)
   - `POST /api/v2/calc` (v2)

The Excel template supports two modes (set in `Jurisdictions!C2`):

- `jurisdiction` (default): one row per Tested Jurisdiction in the **Jurisdictions** sheet.
- `entity_rollup`: one row per Constituent Entity in the **Entities** sheet; the tool rolls up amounts by jurisdiction.
  You can still populate **Jurisdictions** with jurisdiction-level elections/eligibility flags (zeros are fine for numeric columns).

The template also supports the **applicability date / optional early-start rule** inputs in `Jurisdictions!D2:G2`.
If your fiscal year starts in the 2025/2026 window, you can enable the early-start rule and indicate which
condition(s) are satisfied.

### Elections and “net impact” adjustments

The OECD package allows a number of elections (some annual, some five-year) and also requires adjustments that, in a production tool, would often be computed from source systems.

This prototype supports elections in two ways:

1) **Mapped elections**: elections that correspond to dedicated fields in the model (e.g. shipping 5-year election, AFXGL election, annual elections in Box 4.4).
2) **Unmapped elections**: everything else can be recorded as a **net signed income/tax impact** using:
   - `ElectionAdjustments` (recommended)
   - `IncomeAdjustments` and `TaxAdjustments` (generic fallback)

The template includes an `ElectionCatalog` sheet and the API exposes the same catalogue at `/api/v1/election-catalog`.

In addition, every `ElectionAdjustments` row is stored as an **audit trail** record (`election_records`) in the
JSON request/response so users can document metadata/eligibility elections even if they do not change current-year
amounts in this prototype.

### Industry adjustments implemented

The prototype includes dedicated fields for the Side-by-Side package industry adjustments:

- **Financial services**: insurance company income exclusion (with annual election not to exclude), and AT1/RT1 adjustments + corresponding tax in equity/OCI.
- **Shipping**: International Shipping Income + Qualified Ancillary International Shipping Income exclusion, with a 5-year election not to exclude (applies only when aggregate shipping income is positive). Taxes on excluded shipping income are removed only when the exclusion applies.


### Conditional and optional adjustments implemented

The prototype now also includes dedicated fields for several **conditional/optional** adjustments from the Side-by-Side package:

- **Equity-reported items (Box 3.4.1)**: include positive equity-reported income in Simplified Income unless the waiver conditions are met (inputs provided as boolean flags).
- **M&A simplification (Box 3.4.2)**: supports the goodwill impairment/amortisation add-back, and removal of certain deferred-tax components from Simplified Taxes via explicit inputs (simplified modelling).
- **Article 6.3.4 election (referenced in Box 3.4.2)**: include a user-provided (full-year or pro-rata) GloBE-to-book Difference amount in Simplified Income.
- **Optional exclusions (Box 3.5.2)**: AFXGL and accrued pension expense adjustments, each with a five-year election not to apply.

> These are implemented as **explicit input fields** rather than an automated computation from transaction-level data. For production, you would typically compute these amounts from source ledgers / consolidation packs.

### How the prototype maps to the OECD framework

- **Safe harbour test**: Safe harbour outcome is `PASS` if Simplified ETR ≥ Minimum Rate **or** there is a Simplified Loss.
- **Simplified Income**: JPBT adjusted by Basic/Industry/Conditional/Optional adjustments.
- **Simplified Taxes**: JITE adjusted per policy/correlation/uncertain/not-payable/deferred tax recast logic.

This prototype currently implements the core mechanics and a subset of elections as explicit inputs.
You can expand by adding additional adjustment fields or new modules in `app/services/`.

## Docker (optional)

```bash
cd backend
docker build -t simplified-etr-tool .
docker run -p 8000:8000 simplified-etr-tool
```

## Project structure

```
backend/
  app/
    api/
      routes.py
    services/
      calculator.py
      election_catalog.py
      excel_io.py
      eligibility.py
      models.py
    main.py
    tests/
      test_calculator.py

```

## Tests

```bash
cd backend
PYTHONPATH=. python -m unittest discover -s app/tests -p "test*.py" -q
```

## License

Prototype / starter code. Add your own license terms for commercial distribution.


## API versions

This repository exposes two calculation endpoints:

---

### v1

- **v1**: `POST /api/v1/calc`
  - Backwards compatible with the prototype Excel template and the original JSON schema.
  - Groups results by `jurisdiction_code` (so it cannot distinguish multiple Tested Jurisdictions in the same country).

---

### v2

- **v2**: `POST /api/v2/calc`
  - Adds `tested_jurisdiction_id` (so you can model multiple Tested Jurisdictions per country/territory).
  - Adds multi-year election semantics (Annual vs Five-Year elections) and effective start dates.
  - Validates five-year election terms do not overlap (and supports an optional "cooldown" period via the election catalog).
  - Adds carryforward mechanics for:
    - Simplified Adjustment for Negative Taxes (Box 4.3),
    - Excess Negative Tax Carry-forward (Article 4.1.5 symmetry; user input),
    - Loss DTA Adjustment method (Box 4.3(4); user input).
  - Adds a `deemed_zero` override flag for certain tax-neutral entity scenarios (user input).
  - Adds **cross-border tax item exclusion/allocation** inputs (`cross_border_tax_items[]`) to move allocable tax items
    between Tested Jurisdictions (or exclude them), per Section 5 concepts.
  - Adds structured **Investment Entity owner addbacks** (`owner_addbacks[]`) for Articles 7.5/7.6 (signed adjustments to
    Simplified Income or Simplified Taxes).

The v2 election catalogue is available at:
- `GET /api/v2/election-catalog` (same as `/api/election-catalog`, but v2 clients should use the versioned route)

### v2 helper endpoints (for UI builders)

These are designed to make it easier for UI tools (including Anything.com) to build a data-entry experience.

- `GET /api/v2/entities/csv-template`
  - Downloads a CSV template with headers + an example row for entity roll-up.
- `POST /api/v2/entities/parse-csv`
  - Upload a CSV (`multipart/form-data`) and parse it into EntityFactsV2 rows.
  - Returns parsed entities + a list of row-level issues.
  - If `allow_partial=false` (default) and there are any errors, returns HTTP 400 with the parsed issue list.
- `GET /api/v2/tested-jurisdiction/template`
  - Returns a skeleton `TestedJurisdictionInputV2` object you can use to seed UI state.
  - Supports optional query params such as `aggregation_method` and `tested_jurisdiction_type`.

