from __future__ import annotations

from datetime import date

from app.services.models import CalculationRequest as CalculationRequestV1
from app.services.models import JurisdictionInput as JurisdictionInputV1
from app.services.models import EntityInput as EntityInputV1
from app.services.models import TraceLine

from app.services.calculator import calculate as calculate_v1
from app.services.election_catalog import ELECTIONS_BY_CODE
from app.services.elections_v2 import (
    resolve_effective_elections,
    apply_effective_elections_to_meta,
    get_effective_election_amount,
    get_effective_election_bool,
)
from app.services.models_v2 import (
    CalculationRequestV2,
    CalculationResponseV2,
    TestedJurisdictionResultV2,
    CarryforwardBalanceV2,
    CarryforwardMovementV2,
    TestedJurisdictionInputV2,
)


def _build_meta_row(tj: TestedJurisdictionInputV2, bucket_id: str, fy_start: date) -> tuple[JurisdictionInputV1, list, list[TraceLine]]:
    """Build a v1 JurisdictionInput row used as calculation row (jurisdiction mode)
    or as 'meta' row (entity roll-up mode)."""

    if tj.facts is not None:
        data = tj.facts.model_dump()
        # v2 uses tested_jurisdiction_id as the internal key (bucket)
        data["jurisdiction_code"] = bucket_id
        meta = JurisdictionInputV1(**data)
    else:
        # For entity roll-up, a minimal meta row is still useful to carry elections and eligibility flags.
        meta = JurisdictionInputV1(jurisdiction_code=bucket_id, jpbt=0.0)

    # Eligibility flags from v2
    ei = tj.eligibility_inputs
    meta.ineligible_stateless = bool(ei.ineligible_stateless)
    meta.ineligible_investment_entity = bool(ei.ineligible_investment_entity)
    meta.ineligible_article7_3_outstanding_recapture = bool(ei.ineligible_article7_3_outstanding_recapture)
    meta.stateless_exception_section_6_2_applies = bool(ei.stateless_exception_section_6_2_applies)
    meta.investment_entity_tax_transparency_election_applies = bool(ei.investment_entity_tax_transparency_election_applies)
    meta.no_topup_tax_in_prior_24_months = bool(ei.no_topup_tax_in_prior_24_months)
    meta.reentry_no_topup_tax_in_prior_24_months = ei.reentry_no_topup_tax_in_prior_24_months
    meta.integrity_rules_satisfied = bool(ei.integrity_rules_satisfied)

    # Resolve and apply elections for this FY
    effective = resolve_effective_elections(tj.elections, fy_start)
    meta, election_trace = apply_effective_elections_to_meta(meta, effective)

    return meta, effective, election_trace


def _build_entities(tj: TestedJurisdictionInputV2, bucket_id: str) -> list[EntityInputV1]:
    ents: list[EntityInputV1] = []
    for e in tj.entities:
        data = e.model_dump()
        # Override group key
        data["jurisdiction_code"] = bucket_id
        ents.append(EntityInputV1(**data))
    return ents


def _normalise_balances(opening: list[CarryforwardBalanceV2]) -> list[CarryforwardBalanceV2]:
    # Ensure positive amounts and defaults are applied (Pydantic validator already does this).
    out: list[CarryforwardBalanceV2] = []
    for b in opening:
        out.append(b.model_copy())
    return out


def _apply_carryforwards(
    *,
    fy_start: date,
    minimum_rate: float,
    simplified_income: float,
    simplified_taxes: float,
    opening: list[CarryforwardBalanceV2],
    effective_elections: list,
    trace: list[TraceLine],
) -> tuple[float, list[CarryforwardBalanceV2], list[CarryforwardMovementV2]]:
    """Apply carryforwards to Simplified Taxes (OECD Box 4.3 and Article 4.1.5 symmetry).

    Implementation notes (pragmatic):
    - Carryforward balances are entered as POSITIVE amounts representing a reduction to Simplified Taxes.
    - Utilisation is only applied in years with positive Simplified Income and positive Simplified Taxes,
      consistent with typical utilisation mechanics for Excess Negative Tax carry-forwards.
    - Tax is not reduced below zero.
    - Loss DTA Adjustment utilisation can optionally be capped by LOSS_DTA_REVERSAL_TENTATIVE_AMOUNT.
    """

    taxes = float(simplified_taxes)
    balances = _normalise_balances(opening)
    moves: list[CarryforwardMovementV2] = []

    if simplified_income <= 0 or taxes <= 0:
        return taxes, balances, moves

    # Optional cap for Loss DTA Adjustment utilisation
    loss_dta_reversal_cap = get_effective_election_amount(effective_elections, "LOSS_DTA_REVERSAL_TENTATIVE_AMOUNT")
    if loss_dta_reversal_cap is not None:
        loss_dta_reversal_cap = max(0.0, float(loss_dta_reversal_cap))

    def use_balance(kind: str, cap_amount: float | None = None, note: str | None = None):
        nonlocal taxes, balances, moves, loss_dta_reversal_cap

        for b in balances:
            if b.kind != kind:
                continue
            if taxes <= 0:
                break
            if (b.remaining_amount or 0.0) <= 0:
                continue

            cap = taxes
            if cap_amount is not None:
                cap = min(cap, cap_amount)
            used = min(float(b.remaining_amount or 0.0), cap)

            if used <= 0:
                continue

            taxes = max(0.0, taxes - used)
            b.remaining_amount = max(0.0, float(b.remaining_amount or 0.0) - used)

            if kind == "LOSS_DTA_ADJUSTMENT" and loss_dta_reversal_cap is not None:
                loss_dta_reversal_cap = max(0.0, loss_dta_reversal_cap - used)

            moves.append(
                CarryforwardMovementV2(
                    kind=kind, used_amount=float(used), remaining_amount=float(b.remaining_amount or 0.0), note=note
                )
            )
            trace.append(
                TraceLine(
                    section="tax",
                    step=f"Carryforward utilised: {kind}",
                    amount=-float(used),
                    running_total=taxes,
                    note=note,
                )
            )

    # Order (pragmatic):
    #   1) Loss DTA Adjustment (alternative method; can be capped)
    #   2) Simplified negative tax adjustment (Box 4.3)
    #   3) Excess negative tax carry-forward (GloBE Article 4.1.5)
    if loss_dta_reversal_cap is not None and loss_dta_reversal_cap > 0:
        use_balance(
            "LOSS_DTA_ADJUSTMENT",
            cap_amount=loss_dta_reversal_cap,
            note="Capped by LOSS_DTA_REVERSAL_TENTATIVE_AMOUNT; taxes not reduced below zero.",
        )
    else:
        use_balance(
            "LOSS_DTA_ADJUSTMENT",
            cap_amount=None,
            note="No loss DTA reversal cap provided; taxes not reduced below zero.",
        )

    use_balance(
        "SIMPLIFIED_NEGATIVE_TAX_ADJUSTMENT",
        cap_amount=None,
        note="Applied as a reduction to Simplified Taxes; taxes not reduced below zero.",
    )
    use_balance(
        "EXCESS_NEGATIVE_TAX_CARRYFORWARD",
        cap_amount=None,
        note="Applied as a reduction to Simplified Taxes; taxes not reduced below zero.",
    )

    return taxes, balances, moves


def calculate_v2(req: CalculationRequestV2) -> CalculationResponseV2:
    fy_start = req.fiscal_year.start_date

    results: list[TestedJurisdictionResultV2] = []

    for tj in req.tested_jurisdictions:
        bucket_id = tj.tested_jurisdiction_id

        # Determine input mode
        m = tj.composition.aggregation_method
        if m == "JURISDICTION_FACTS":
            input_mode = "jurisdiction"
        elif m == "ENTITY_ROLLUP":
            input_mode = "entity_rollup"
        else:
            # MIXED: if entities exist, roll-up; else jurisdiction facts
            input_mode = "entity_rollup" if tj.entities else "jurisdiction"

        meta, effective_elections, election_trace = _build_meta_row(tj, bucket_id, fy_start)
        entities = _build_entities(tj, bucket_id) if input_mode == "entity_rollup" else []

        # v1 request (single bucket)
        req_v1 = CalculationRequestV1(
            fiscal_year_start_date=fy_start,
            minimum_rate=req.minimum_rate,
            input_mode=input_mode,
            apply_optional_2025_start_rule=req.applicability.apply_optional_2025_start_rule,
            early_start_qdmtt_safe_harbour_applies=req.applicability.early_start_qdmtt_safe_harbour_applies,
            early_start_only_one_jurisdiction_has_taxing_rights=req.applicability.early_start_only_one_jurisdiction_has_taxing_rights,
            early_start_all_taxing_rights_jurisdictions_allow=req.applicability.early_start_all_taxing_rights_jurisdictions_allow,
            jurisdictions=[meta],
            entities=entities,
        )

        base_resp = calculate_v1(req_v1)
        base_r = base_resp.results[0]

        trace: list[TraceLine] = list(base_r.trace) + list(election_trace)

        opening_balances = _normalise_balances(tj.carryforwards_opening)

        # Deemed-zero override (if eligible)
        if tj.deemed_zero_rules.apply_deemed_zero:
            trace.append(
                TraceLine(
                    section="eligibility",
                    step="Deemed-zero rule applied",
                    amount=0.0,
                    note=tj.deemed_zero_rules.rationale or "Simplified Income and Simplified Taxes treated as zero.",
                )
            )
            if base_r.eligible:
                results.append(
                    TestedJurisdictionResultV2(
                        tested_jurisdiction_id=bucket_id,
                        jurisdiction_code=tj.jurisdiction_code,
                        label=tj.label,
                        eligible=True,
                        ineligibility_reasons=[],
                        simplified_income=0.0,
                        simplified_taxes=0.0,
                        simplified_etr=None,
                        simplified_loss=0.0,
                        safe_harbour_applies=True,
                        safe_harbour_reason="PASS: deemed-zero rule applies.",
                        simplified_adjustment_for_negative_taxes=0.0,
                        effective_elections=effective_elections,
                        election_records=list(base_r.election_records),
                        trace=trace,
                        carryforwards_opening=opening_balances,
                        carryforward_movements=[],
                        carryforwards_closing=opening_balances,
                    )
                )
                continue
            # If not eligible, fall through with normal numbers but explain.
            trace.append(
                TraceLine(
                    section="eligibility",
                    step="Deemed-zero requested but eligibility failed",
                    amount=0.0,
                    note="Safe harbour is not available where eligibility restrictions are not met.",
                )
            )

        # Apply carryforwards to taxes
        taxes_after_cf, balances_after, movements = _apply_carryforwards(
            fy_start=fy_start,
            minimum_rate=req.minimum_rate,
            simplified_income=base_r.simplified_income,
            simplified_taxes=base_r.simplified_taxes,
            opening=opening_balances,
            effective_elections=effective_elections,
            trace=trace,
        )

        simplified_income = float(base_r.simplified_income)
        simplified_taxes = float(taxes_after_cf)

        simplified_loss = 0.0
        simplified_etr = None

        if simplified_income <= 0:
            simplified_loss = max(0.0, -simplified_income)
        else:
            simplified_etr = simplified_taxes / simplified_income if simplified_income != 0 else None

        # Negative-tax adjustment / Loss DTA method
        simplified_adjustment_for_negative_taxes = 0.0
        closing_additions: list[CarryforwardBalanceV2] = []

        loss_dta_method = bool(get_effective_election_bool(effective_elections, "LOSS_DTA_ADJUSTMENT_METHOD_ELECTED") or False)
        loss_dta_generated = get_effective_election_amount(effective_elections, "LOSS_DTA_ADJUSTMENT_GENERATED_AMOUNT")
        if loss_dta_generated is not None:
            loss_dta_generated = float(loss_dta_generated)

        if loss_dta_method and loss_dta_generated and loss_dta_generated > 0 and simplified_loss > 0:
            # Transitional alternative: create Loss DTA Adjustment carryforward (input amount).
            closing_additions.append(
                CarryforwardBalanceV2(
                    kind="LOSS_DTA_ADJUSTMENT",
                    origin_fiscal_year_start=fy_start,
                    amount=abs(loss_dta_generated),
                    remaining_amount=abs(loss_dta_generated),
                    note="Generated under Loss DTA Adjustment methodology (input amount).",
                )
            )
            trace.append(
                TraceLine(
                    section="tax",
                    step="Loss-year: Loss DTA Adjustment generated (carryforward)",
                    amount=0.0,
                    note=f"Amount created = {abs(loss_dta_generated):.2f}",
                )
            )
        else:
            if simplified_loss > 0 and simplified_taxes < 0:
                simplified_adjustment_for_negative_taxes = simplified_taxes - (simplified_loss * req.minimum_rate)
                # Create a positive carryforward balance representing reduction to future taxes
                cf_amt = abs(simplified_adjustment_for_negative_taxes)
                if cf_amt > 0:
                    closing_additions.append(
                        CarryforwardBalanceV2(
                            kind="SIMPLIFIED_NEGATIVE_TAX_ADJUSTMENT",
                            origin_fiscal_year_start=fy_start,
                            amount=cf_amt,
                            remaining_amount=cf_amt,
                            note="Computed as abs(Simplified Taxes – (Simplified Loss * Minimum Rate)).",
                        )
                    )
                    trace.append(
                        TraceLine(
                            section="tax",
                            step="Loss-year: Simplified Adjustment for Negative Taxes computed (carryforward)",
                            amount=simplified_adjustment_for_negative_taxes,
                            note="Computed as Simplified Taxes – (Simplified Loss * Minimum Rate). Stored as a positive carryforward amount.",
                        )
                    )

        # Safe harbour outcome (recomputed after carryforwards)
        if simplified_income <= 0:
            safe_harbour_pass = True
            reason = "PASS: Simplified Loss (or non-positive Simplified Income)."
        else:
            safe_harbour_pass = (simplified_etr is not None) and simplified_etr >= req.minimum_rate
            reason = (
                "PASS: Simplified ETR >= Minimum Rate."
                if safe_harbour_pass
                else "FAIL: Simplified ETR < Minimum Rate and no Simplified Loss."
            )

        if not base_r.eligible:
            safe_harbour_pass = False
            reason = "NOT AVAILABLE: jurisdiction fails eligibility criteria (see reasons)."

        # Closing balances = updated opening + any new balances created
        closing = [b for b in balances_after if (b.remaining_amount or 0.0) > 0] + closing_additions

        results.append(
            TestedJurisdictionResultV2(
                tested_jurisdiction_id=bucket_id,
                jurisdiction_code=tj.jurisdiction_code,
                label=tj.label,
                eligible=base_r.eligible,
                ineligibility_reasons=list(base_r.ineligibility_reasons),
                simplified_income=simplified_income,
                simplified_taxes=simplified_taxes,
                simplified_etr=simplified_etr,
                simplified_loss=simplified_loss,
                safe_harbour_applies=safe_harbour_pass,
                safe_harbour_reason=reason,
                simplified_adjustment_for_negative_taxes=float(simplified_adjustment_for_negative_taxes),
                effective_elections=effective_elections,
                election_records=list(base_r.election_records),
                trace=trace,
                carryforwards_opening=opening_balances,
                carryforward_movements=movements,
                carryforwards_closing=closing,
            )
        )

    return CalculationResponseV2(
        ruleset_version=req.ruleset_version,
        fiscal_year=req.fiscal_year,
        minimum_rate=req.minimum_rate,
        results=results,
    )
