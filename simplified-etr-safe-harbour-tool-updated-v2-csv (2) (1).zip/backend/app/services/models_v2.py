from __future__ import annotations

from datetime import date
from typing import List, Optional, Literal, Any

from pydantic import BaseModel, Field, model_validator

from app.services.models import (
    AdjustmentLine,
    ElectionRecord,
    TraceLine,
    JurisdictionInput as JurisdictionInputV1,
    EntityInput as EntityInputV1,
)


# ---------------------------------------------------------------------------
# v2 wrappers around v1 input models
# ---------------------------------------------------------------------------

class JurisdictionFactsV2(JurisdictionInputV1):
    """Jurisdiction facts (v2).

    This model inherits the existing v1 JurisdictionInput for maximum re-use, but makes
    jurisdiction_code optional so UI clients do not need to duplicate it. The API will override
    the internal bucket id with tested_jurisdiction_id when running calculations.
    """

    jurisdiction_code: Optional[str] = Field(
        default=None,
        description=(
            "Optional. UI may omit this; the server will fill it internally. "
            "In v2, tested_jurisdiction_id is used as the internal grouping key."
        ),
    )


class EntityFactsV2(EntityInputV1):
    """Entity facts (v2).

    In v2, entities are typically nested under a Tested Jurisdiction. The server will override
    the internal grouping key with tested_jurisdiction_id when running calculations.
    """

    jurisdiction_code: Optional[str] = Field(
        default=None,
        description=(
            "Optional. This tool groups entities by tested_jurisdiction_id (not jurisdiction_code) in v2. "
            "Use tested_jurisdiction.jurisdiction_code for the country/territory code."
        ),
    )


# ---------------------------------------------------------------------------
# Elections (v2)
# ---------------------------------------------------------------------------

Scope = Literal["income", "tax", "eligibility", "metadata"]
ValueType = Literal["bool", "amount", "text"]
TermType = Literal["ANNUAL", "FIVE_YEAR"]


class ElectionInstanceV2(BaseModel):
    """An election or adjustment selection associated with a Tested Jurisdiction."""

    election_code: str = Field(..., description="Election/adjustment code (see /api/v2/election-catalog).")
    scope: Scope = Field(..., description="Which part of the safe harbour it relates to.")
    value_type: ValueType = Field(..., description="Value type for the election.")
    # Optional term type on instance; if omitted, the server will infer from election catalog when possible.
    term_type: Optional[TermType] = Field(
        default=None,
        description="ANNUAL or FIVE_YEAR. If omitted, server will infer from the election catalog.",
    )
    effective_fiscal_year_start: Optional[date] = Field(
        default=None,
        description="Fiscal year start date when this election starts. Defaults to the request fiscal year start date.",
    )
    # Values
    bool_value: Optional[bool] = None
    amount: Optional[float] = Field(default=None, description="Signed amount (+/-) if value_type='amount'.")
    text_value: Optional[str] = None
    label: Optional[str] = None
    note: Optional[str] = None

    @model_validator(mode="after")
    def _validate_value(self) -> "ElectionInstanceV2":
        vt = self.value_type
        if vt == "bool" and self.bool_value is None:
            raise ValueError(f"Election {self.election_code}: value_type='bool' requires bool_value.")
        if vt == "amount" and self.amount is None:
            raise ValueError(f"Election {self.election_code}: value_type='amount' requires amount.")
        if vt == "text" and (self.text_value is None or str(self.text_value).strip() == ""):
            raise ValueError(f"Election {self.election_code}: value_type='text' requires text_value.")
        return self


# ---------------------------------------------------------------------------
# Carryforwards (v2)
# ---------------------------------------------------------------------------

CarryforwardKind = Literal[
    "SIMPLIFIED_NEGATIVE_TAX_ADJUSTMENT",  # Box 4.3 (paragraphs 1-3)
    "EXCESS_NEGATIVE_TAX_CARRYFORWARD",    # GloBE Article 4.1.5 carry-forward (input)
    "LOSS_DTA_ADJUSTMENT",                 # Box 4.3 (paragraph 4) alternative methodology
]


class CarryforwardBalanceV2(BaseModel):
    kind: CarryforwardKind
    origin_fiscal_year_start: Optional[date] = Field(
        default=None, description="Fiscal year start date when the balance was generated (if known)."
    )
    amount: float = Field(
        ...,
        description=(
            "Opening amount of the carryforward. Enter as a positive number. "
            "The tool applies it as a reduction to Simplified Taxes, subject to OECD limits."
        ),
    )
    remaining_amount: Optional[float] = Field(
        default=None,
        description="If omitted, defaults to amount. Must be >= 0.",
    )
    note: Optional[str] = None

    @model_validator(mode="after")
    def _normalise(self) -> "CarryforwardBalanceV2":
        # Normalise negative values to positive to avoid sign confusion.
        if self.amount < 0:
            self.amount = abs(self.amount)
        if self.remaining_amount is None:
            self.remaining_amount = float(self.amount)
        if self.remaining_amount < 0:
            self.remaining_amount = abs(self.remaining_amount)
        return self


class CarryforwardMovementV2(BaseModel):
    kind: CarryforwardKind
    used_amount: float = Field(..., ge=0.0, description="Amount utilised in the current fiscal year (>= 0).")
    remaining_amount: float = Field(..., ge=0.0, description="Remaining amount after utilisation (>= 0).")
    note: Optional[str] = None


# ---------------------------------------------------------------------------
# Tested Jurisdiction wrapper
# ---------------------------------------------------------------------------

AggregationMethod = Literal["JURISDICTION_FACTS", "ENTITY_ROLLUP", "MIXED"]


class TestedJurisdictionCompositionV2(BaseModel):
    aggregation_method: AggregationMethod = Field(
        default="JURISDICTION_FACTS",
        description="How inputs are provided for the Tested Jurisdiction.",
    )


class EligibilityInputsV2(BaseModel):
    ineligible_stateless: bool = False
    ineligible_investment_entity: bool = False
    ineligible_article7_3_outstanding_recapture: bool = False

    stateless_exception_section_6_2_applies: bool = False
    investment_entity_tax_transparency_election_applies: bool = False

    no_topup_tax_in_prior_24_months: bool = True
    reentry_no_topup_tax_in_prior_24_months: Optional[bool] = None

    integrity_rules_satisfied: bool = True


class DeemedZeroRulesV2(BaseModel):
    apply_deemed_zero: bool = Field(
        default=False,
        description=(
            "If True, treat Simplified Income and Simplified Taxes as zero for the Tested Jurisdiction "
            "(deemed-zero rule). This is intended for certain Tax-Neutral Entity scenarios."
        ),
    )
    rationale: Optional[str] = None


class TestedJurisdictionInputV2(BaseModel):
    tested_jurisdiction_id: str = Field(..., description="Unique identifier for this Tested Jurisdiction.")
    jurisdiction_code: Optional[str] = Field(
        default=None, description="Country/territory code (e.g. 'GB', 'DE'). Multiple Tested Jurisdictions may share a code."
    )
    label: Optional[str] = Field(default=None, description="Optional display label.")
    tested_jurisdiction_type: Optional[str] = Field(
        default=None,
        description="Optional classification (e.g., 'standard', 'stateless', 'investment_entity'). Informational.",
    )

    composition: TestedJurisdictionCompositionV2 = Field(default_factory=TestedJurisdictionCompositionV2)

    # Inputs (either provide facts or entities depending on composition method)
    facts: Optional[JurisdictionFactsV2] = None
    entities: List[EntityFactsV2] = Field(default_factory=list)

    # Elections and carryforwards
    elections: List[ElectionInstanceV2] = Field(default_factory=list)
    carryforwards_opening: List[CarryforwardBalanceV2] = Field(default_factory=list)

    # Eligibility & deemed-zero
    eligibility_inputs: EligibilityInputsV2 = Field(default_factory=EligibilityInputsV2)
    deemed_zero_rules: DeemedZeroRulesV2 = Field(default_factory=DeemedZeroRulesV2)

    @model_validator(mode="after")
    def _validate_composition(self) -> "TestedJurisdictionInputV2":
        m = self.composition.aggregation_method
        if m == "JURISDICTION_FACTS":
            if self.facts is None:
                raise ValueError(f"{self.tested_jurisdiction_id}: aggregation_method='JURISDICTION_FACTS' requires facts.")
        elif m == "ENTITY_ROLLUP":
            if not self.entities:
                raise ValueError(f"{self.tested_jurisdiction_id}: aggregation_method='ENTITY_ROLLUP' requires entities[].")
        elif m == "MIXED":
            if self.facts is None and not self.entities:
                raise ValueError(f"{self.tested_jurisdiction_id}: aggregation_method='MIXED' requires facts and/or entities[].")
        return self


# ---------------------------------------------------------------------------
# Request / Response (v2)
# ---------------------------------------------------------------------------

class ApplicabilityOptionsV2(BaseModel):
    apply_optional_2025_start_rule: bool = False
    early_start_qdmtt_safe_harbour_applies: bool = False
    early_start_only_one_jurisdiction_has_taxing_rights: bool = False
    early_start_all_taxing_rights_jurisdictions_allow: bool = False


class FiscalYearV2(BaseModel):
    start_date: date
    end_date: Optional[date] = None


class CalculationRequestV2(BaseModel):
    schema_version: Literal["2.0"] = "2.0"
    ruleset_version: str = Field(default="OECD_SBS_2026_01", description="OECD Side-by-Side Package (Jan 2026).")

    fiscal_year: FiscalYearV2
    minimum_rate: float = Field(default=0.15, ge=0.0, le=1.0)

    applicability: ApplicabilityOptionsV2 = Field(default_factory=ApplicabilityOptionsV2)

    tested_jurisdictions: List[TestedJurisdictionInputV2] = Field(default_factory=list)

    @model_validator(mode="after")
    def _validate(self) -> "CalculationRequestV2":
        if not self.tested_jurisdictions:
            raise ValueError("tested_jurisdictions[] must contain at least one Tested Jurisdiction.")
        return self


class TestedJurisdictionResultV2(BaseModel):
    tested_jurisdiction_id: str
    jurisdiction_code: Optional[str] = None
    label: Optional[str] = None

    eligible: bool
    ineligibility_reasons: List[str] = Field(default_factory=list)

    simplified_income: float
    simplified_taxes: float
    simplified_etr: Optional[float] = None
    simplified_loss: float = 0.0

    safe_harbour_applies: bool
    safe_harbour_reason: str

    # Negative tax adjustment proxy (for transparency)
    simplified_adjustment_for_negative_taxes: float = 0.0

    # Elections and trace
    effective_elections: List[ElectionInstanceV2] = Field(default_factory=list)
    election_records: List[ElectionRecord] = Field(default_factory=list)
    trace: List[TraceLine] = Field(default_factory=list)

    # Carryforwards
    carryforwards_opening: List[CarryforwardBalanceV2] = Field(default_factory=list)
    carryforward_movements: List[CarryforwardMovementV2] = Field(default_factory=list)
    carryforwards_closing: List[CarryforwardBalanceV2] = Field(default_factory=list)


class CalculationResponseV2(BaseModel):
    schema_version: Literal["2.0"] = "2.0"
    ruleset_version: str

    fiscal_year: FiscalYearV2
    minimum_rate: float

    results: List[TestedJurisdictionResultV2]
