import unittest
from datetime import date

from app.services.models_v2 import CalculationRequestV2, FiscalYearV2, TestedJurisdictionInputV2, TestedJurisdictionCompositionV2, JurisdictionFactsV2, CarryforwardBalanceV2
from app.services.calculator_v2 import calculate_v2


class CalculatorV2Tests(unittest.TestCase):
    def test_two_tested_jurisdictions_same_country(self):
        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            tested_jurisdictions=[
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="GB_MAIN",
                    jurisdiction_code="GB",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    facts=JurisdictionFactsV2(jpbt=100.0, current_tax_expense=20.0),
                ),
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="GB_INVEST",
                    jurisdiction_code="GB",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    facts=JurisdictionFactsV2(jpbt=100.0, current_tax_expense=10.0),
                ),
            ],
        )
        resp = calculate_v2(req)
        self.assertEqual(len(resp.results), 2)
        ids = {r.tested_jurisdiction_id for r in resp.results}
        self.assertEqual(ids, {"GB_MAIN", "GB_INVEST"})

    def test_carryforward_reduces_taxes(self):
        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            tested_jurisdictions=[
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="DE_MAIN",
                    jurisdiction_code="DE",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    facts=JurisdictionFactsV2(jpbt=100.0, current_tax_expense=20.0),
                    carryforwards_opening=[
                        CarryforwardBalanceV2(kind="SIMPLIFIED_NEGATIVE_TAX_ADJUSTMENT", amount=10.0)
                    ],
                )
            ],
        )
        resp = calculate_v2(req)
        r = resp.results[0]
        self.assertAlmostEqual(r.simplified_taxes, 10.0)
        self.assertFalse(r.safe_harbour_applies)

    def test_loss_year_generates_negative_tax_adjustment(self):
        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            tested_jurisdictions=[
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="FR_MAIN",
                    jurisdiction_code="FR",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    facts=JurisdictionFactsV2(jpbt=-100.0, current_tax_expense=-5.0),
                )
            ],
        )
        resp = calculate_v2(req)
        r = resp.results[0]
        self.assertTrue(r.safe_harbour_applies)
        self.assertAlmostEqual(r.simplified_loss, 100.0)
        self.assertAlmostEqual(r.simplified_adjustment_for_negative_taxes, -20.0)
        kinds = [b.kind for b in r.carryforwards_closing]
        self.assertIn("SIMPLIFIED_NEGATIVE_TAX_ADJUSTMENT", kinds)
        bal = [b for b in r.carryforwards_closing if b.kind == "SIMPLIFIED_NEGATIVE_TAX_ADJUSTMENT"][0]
        self.assertAlmostEqual(bal.amount, 20.0)


if __name__ == "__main__":
    unittest.main()
