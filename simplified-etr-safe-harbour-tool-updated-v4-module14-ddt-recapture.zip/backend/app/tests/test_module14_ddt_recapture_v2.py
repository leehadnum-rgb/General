from __future__ import annotations

import unittest
from datetime import date

from app.services.calculator_v2 import calculate_v2
from app.services.scenario_v2 import advance_year_scenario
from app.services.models_v2 import (
    CalculationRequestV2,
    FiscalYearV2,
    TestedJurisdictionInputV2,
    TestedJurisdictionCompositionV2,
    EligibilityInputsV2,
    DDTRecaptureAccountStateV2,
    DDTRecaptureAccountMovementV2,
    ScenarioAdvanceYearRequestV2,
    ScenarioAdvanceYearOptionsV2,
    ElectionInstanceV2,
    EntityFactsV2,
    JurisdictionFactsV2,
)


class Module14DDTRecaptureTests(unittest.TestCase):
    def _tj_facts(self, tj_id: str, code: str, jpbt: float, tax: float, *, entities=None, elections=None) -> TestedJurisdictionInputV2:
        return TestedJurisdictionInputV2(
            tested_jurisdiction_id=tj_id,
            jurisdiction_code=code,
            composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
            facts=JurisdictionFactsV2(jpbt=jpbt, current_tax_expense=tax),
            eligibility_inputs=EligibilityInputsV2(),
            entities=entities or [],
            elections=elections or [],
        )

    def test_ddt_recapture_opening_balance_disqualifies(self):
        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            tested_jurisdictions=[self._tj_facts("GB", "GB", jpbt=1000.0, tax=150.0)],
            ddt_recapture_account_state_opening=[
                DDTRecaptureAccountStateV2(
                    tested_jurisdiction_id="GB",
                    balance=1.0,
                    currency=None,
                    amount_scale="UNITS",
                    as_of_fiscal_year_start=date(2027, 1, 1),
                )
            ],
            ddt_recapture_account_movements=[
                DDTRecaptureAccountMovementV2(
                    movement_id="DDT-1",
                    tested_jurisdiction_id="GB",
                    fiscal_year_start=date(2027, 1, 1),
                    amount=-1.0,
                    reason="REDUCTION",
                    currency=None,
                    amount_scale="UNITS",
                )
            ],
        )

        resp = calculate_v2(req)
        r = resp.results[0]

        self.assertFalse(r.eligible)
        self.assertTrue(any("Recapture" in s or "Article 7.3" in s for s in r.ineligibility_reasons))

        # Closing state is still produced for scenario roll-forward.
        by_tj = {s.tested_jurisdiction_id: s for s in resp.ddt_recapture_account_state_closing}
        self.assertIn("GB", by_tj)
        self.assertAlmostEqual(by_tj["GB"].balance, 0.0, places=6)

    def test_scenario_advance_year_rolls_ddt_state(self):
        last_req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            tested_jurisdictions=[self._tj_facts("GB", "GB", jpbt=1000.0, tax=150.0)],
            ddt_recapture_account_state_opening=[
                DDTRecaptureAccountStateV2(
                    tested_jurisdiction_id="GB",
                    balance=10.0,
                    currency=None,
                    amount_scale="UNITS",
                    as_of_fiscal_year_start=date(2027, 1, 1),
                )
            ],
            ddt_recapture_account_movements=[
                DDTRecaptureAccountMovementV2(
                    movement_id="DDT-1",
                    tested_jurisdiction_id="GB",
                    fiscal_year_start=date(2027, 1, 1),
                    amount=-4.0,
                    reason="REDUCTION",
                    currency=None,
                    amount_scale="UNITS",
                )
            ],
        )
        last_resp = calculate_v2(last_req)

        adv = advance_year_scenario(
            ScenarioAdvanceYearRequestV2(
                last_request=last_req,
                last_response=last_resp,
                options=ScenarioAdvanceYearOptionsV2(
                    carry_forward_ddt_recapture_account_state=True,
                    clear_ddt_recapture_account_movements=True,
                ),
            )
        )

        next_req = adv.next_request
        self.assertEqual(next_req.fiscal_year.start_date, date(2028, 1, 1))
        self.assertEqual(len(next_req.ddt_recapture_account_state_opening), 1)
        self.assertAlmostEqual(next_req.ddt_recapture_account_state_opening[0].balance, 6.0, places=6)
        self.assertEqual(next_req.ddt_recapture_account_state_opening[0].as_of_fiscal_year_start, date(2028, 1, 1))
        self.assertEqual(next_req.ddt_recapture_account_movements, [])


class Module14InvestmentEntityEligibilityTests(unittest.TestCase):
    def _tj_with_entity(self, tj_id: str, code: str, *, entity_type: str, elections=None) -> TestedJurisdictionInputV2:
        return TestedJurisdictionInputV2(
            tested_jurisdiction_id=tj_id,
            jurisdiction_code=code,
            composition=TestedJurisdictionCompositionV2(aggregation_method="ENTITY_ROLLUP"),
            entities=[
                EntityFactsV2(
                    entity_id="E1",
                    entity_name="InvCo",
                    jurisdiction_code=code,
                    jpbt=1000.0,
                    current_tax_expense=150.0,
                    entity_type=entity_type,
                )
            ],
            eligibility_inputs=EligibilityInputsV2(),
            elections=elections or [],
        )

    def test_investment_entity_auto_ineligible_without_transparency_election(self):
        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            tested_jurisdictions=[self._tj_with_entity("IE_TJ", "IE", entity_type="INVESTMENT_ENTITY")],
        )
        resp = calculate_v2(req)
        r = resp.results[0]
        self.assertFalse(r.eligible)
        self.assertTrue(any("investment" in s.lower() for s in r.ineligibility_reasons))

    def test_investment_entity_transparency_election_allows(self):
        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            tested_jurisdictions=[
                self._tj_with_entity(
                    "IE_TJ",
                    "IE",
                    entity_type="INVESTMENT_ENTITY",
                    elections=[
                        ElectionInstanceV2(
                            election_code="INVESTMENT_ENTITY_TAX_TRANSPARENCY_ELECTION_ART_7_5",
                            scope="eligibility",
                            value_type="bool",
                            bool_value=True,
                            effective_fiscal_year_start=date(2027, 1, 1),
                        )
                    ],
                )
            ],
        )
        resp = calculate_v2(req)
        r = resp.results[0]
        self.assertTrue(r.eligible)
