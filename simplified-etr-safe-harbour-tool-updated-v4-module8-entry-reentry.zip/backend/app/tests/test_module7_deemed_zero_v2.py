import unittest
from datetime import date

from app.services.models_v2 import (
    CalculationRequestV2,
    FiscalYearV2,
    TestedJurisdictionInputV2,
    TestedJurisdictionCompositionV2,
    EntityFactsV2,
    FlowThroughEntityAllocationV2,
)
from app.services.calculator_v2 import calculate_v2


class Module7DeemedZeroTests(unittest.TestCase):
    def test_section_6_2_tax_transparent_bucket_deemed_zero(self):
        fy = date(2027, 1, 1)

        owner_tj = TestedJurisdictionInputV2(
            tested_jurisdiction_id="OWNER_TJ",
            jurisdiction_code="GB",
            composition=TestedJurisdictionCompositionV2(aggregation_method="ENTITY_ROLLUP"),
            entities=[
                EntityFactsV2(
                    entity_id="E_OWNER",
                    entity_name="Owner Co",
                    jurisdiction_code="GB",
                    jpbt=1000.0,
                    current_tax_expense=150.0,
                    entity_type="STANDARD_CE",
                )
            ],
        )

        fte_tj = TestedJurisdictionInputV2(
            tested_jurisdiction_id="FTE_TJ",
            jurisdiction_code="LU",
            composition=TestedJurisdictionCompositionV2(aggregation_method="ENTITY_ROLLUP"),
            entities=[
                EntityFactsV2(
                    entity_id="E_FTE",
                    entity_name="Flow-through",
                    jurisdiction_code="LU",
                    jpbt=200.0,
                    current_tax_expense=0.0,
                    entity_type="TAX_TRANSPARENT_ENTITY",
                )
            ],
        )

        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=fy),
            tested_jurisdictions=[owner_tj, fte_tj],
            flow_through_entities=[
                FlowThroughEntityAllocationV2(
                    flow_through_entity_id="E_FTE",
                    flow_through_tested_jurisdiction_id="FTE_TJ",
                    owner_tested_jurisdiction_id="OWNER_TJ",
                    fiscal_year_start=fy,
                    income_allocated_amount=200.0,
                    tax_allocated_amount=0.0,
                )
            ],
        )

        resp = calculate_v2(req)
        by_id = {r.tested_jurisdiction_id: r for r in resp.results}

        # Flow-through bucket should be deemed zero automatically (Section 6.2)
        r_fte = by_id["FTE_TJ"]
        self.assertTrue(r_fte.deemed_zero_applied)
        self.assertEqual(r_fte.deemed_zero_basis, "SECTION_6_2_TAX_TRANSPARENT")
        self.assertTrue(r_fte.safe_harbour_applies)
        self.assertEqual(r_fte.simplified_income, 0.0)
        self.assertEqual(r_fte.simplified_taxes, 0.0)

        # Owner bucket should pick up the allocated income (not deemed zero)
        r_owner = by_id["OWNER_TJ"]
        self.assertFalse(r_owner.deemed_zero_applied)
        self.assertGreater(r_owner.simplified_income, 1000.0)

    def test_section_6_1_tax_neutral_upe_bucket_deemed_zero(self):
        fy = date(2027, 1, 1)

        tn_tj = TestedJurisdictionInputV2(
            tested_jurisdiction_id="TN_TJ",
            jurisdiction_code="XX",
            composition=TestedJurisdictionCompositionV2(aggregation_method="ENTITY_ROLLUP"),
            entities=[
                EntityFactsV2(
                    entity_id="E_TN",
                    entity_name="Tax Neutral UPE",
                    jurisdiction_code="XX",
                    jpbt=500.0,
                    current_tax_expense=0.0,
                    entity_type="TAX_NEUTRAL_UPE",
                    qualified_persons_ownership_percentage=1.0,
                    is_upe=True,
                )
            ],
        )

        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=fy),
            tested_jurisdictions=[tn_tj],
        )

        resp = calculate_v2(req)
        r = resp.results[0]
        self.assertTrue(r.deemed_zero_applied)
        self.assertEqual(r.deemed_zero_basis, "SECTION_6_1_TAX_NEUTRAL_UPE")
        self.assertTrue(r.safe_harbour_applies)
        self.assertEqual(r.simplified_income, 0.0)
        self.assertEqual(r.simplified_taxes, 0.0)

    def test_tax_neutral_upe_not_qualified_does_not_auto_deem(self):
        fy = date(2027, 1, 1)

        tn_tj = TestedJurisdictionInputV2(
            tested_jurisdiction_id="TN_TJ_BAD",
            jurisdiction_code="XX",
            composition=TestedJurisdictionCompositionV2(aggregation_method="ENTITY_ROLLUP"),
            entities=[
                EntityFactsV2(
                    entity_id="E_TN_BAD",
                    entity_name="Tax Neutral UPE",
                    jurisdiction_code="XX",
                    jpbt=500.0,
                    current_tax_expense=0.0,
                    entity_type="TAX_NEUTRAL_UPE",
                    qualified_persons_ownership_percentage=0.5,
                    is_upe=True,
                )
            ],
        )

        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=fy),
            tested_jurisdictions=[tn_tj],
        )

        resp = calculate_v2(req)
        r = resp.results[0]
        self.assertFalse(r.deemed_zero_applied)
        # In most cases ETR will be below minimum rate here, so safe harbour should not apply.
        self.assertFalse(r.safe_harbour_applies)


if __name__ == "__main__":
    unittest.main()
