from __future__ import annotations

import re
from datetime import datetime
from hashlib import sha1
from typing import Iterable, List, Optional, Set, Tuple

import requests
import xml.etree.ElementTree as ET

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import Session

from app.api.schemas import (
    ImportGirXmlRequest,
    ImportGirXmlResponse,
    ImportGirXmlStats,
    ImportGirXmlWarning,
    ImportGirXmlValidateRequest,
    ImportGirXmlValidateResponse,
    ValidationRunCreate,
    ValidationRunRead,
)
from app.db import models
from app.db.session import get_db
from app.services.utils import try_parse_date, try_parse_decimal

# Reuse the existing validation run implementation for consistent persistence + outputs.
from app.api.routes_validation import create_validation_run as _create_validation_run


router = APIRouter(prefix="/filings/{filing_id}/imports", tags=["imports"])


def _local(tag: str) -> str:
    """Return localname for XML tags with namespaces."""
    if "}" in tag:
        return tag.split("}", 1)[1]
    return tag


def _child(parent: ET.Element, name: str) -> Optional[ET.Element]:
    for ch in list(parent):
        if isinstance(ch.tag, str) and _local(ch.tag) == name:
            return ch
    return None


def _child_text(parent: ET.Element, name: str) -> Optional[str]:
    ch = _child(parent, name)
    if ch is None:
        return None
    t = (ch.text or "").strip()
    return t or None


def _find_text(root: ET.Element, parts: List[str]) -> Optional[str]:
    cur = root
    for p in parts:
        nxt = _child(cur, p)
        if nxt is None:
            return None
        cur = nxt
    t = (cur.text or "").strip()
    return t or None


def _safe_code(seed: Optional[str], prefix: str, max_len: int = 64) -> str:
    base = (seed or "").strip()
    cleaned = re.sub(r"[^A-Za-z0-9]+", "", base).upper()
    if not cleaned:
        return f"{prefix}01"
    if len(cleaned) <= max_len:
        return cleaned
    h = sha1(base.encode("utf-8")).hexdigest()[:12].upper()
    return (prefix + h)[:max_len]


def _chunked(it: List[dict], n: int) -> Iterable[List[dict]]:
    for i in range(0, len(it), n):
        yield it[i : i + n]


def _ensure_filing(db: Session, filing_id: str) -> models.Filing:
    filing = db.get(models.Filing, filing_id)
    if filing is None:
        raise HTTPException(status_code=404, detail="Filing not found")
    return filing


@router.post("/gir-xml", response_model=ImportGirXmlResponse)
def import_gir_xml(filing_id: str, payload: ImportGirXmlRequest, db: Session = Depends(get_db)):
    """Import a GIR XML file into registers + datapoints.

    This is a pragmatic bridge endpoint intended for customer-facing web tools
    (Anything.com, etc.). The API accepts a file URL, downloads it server-side,
    parses XML, and loads:
      - Filer register (single filer from FilingCE)
      - Jurisdiction register (from JurisdictionSection, plus RecJurCode fallbacks)
      - Constituent Entity register (from GeneralSection/CorporateStructure/CE)
      - Datapoints (flattened leaf nodes)
    """

    filing = _ensure_filing(db, filing_id)

    import_id = f"IMP-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}-{sha1(f'{filing_id}'.encode('utf-8')).hexdigest()[:8].upper()}"
    warnings: List[ImportGirXmlWarning] = []

    url = (payload.file_url or "").strip()
    if not url.lower().startswith(("https://", "http://")):
        raise HTTPException(status_code=400, detail="file_url must start with http:// or https://")

    # Optional replacement (recommended for web UX: re-upload replaces prior state).
    if payload.replace_existing:
        db.query(models.DataPoint).filter(models.DataPoint.filing_id == filing_id).delete(synchronize_session=False)
        db.query(models.Filer).filter(models.Filer.filing_id == filing_id).delete(synchronize_session=False)
        db.query(models.Jurisdiction).filter(models.Jurisdiction.filing_id == filing_id).delete(synchronize_session=False)
        db.query(models.ConstituentEntity).filter(models.ConstituentEntity.filing_id == filing_id).delete(synchronize_session=False)
        db.commit()

    # Download XML
    try:
        resp = requests.get(url, timeout=60)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Could not download file_url: {e}")

    if resp.status_code >= 400:
        raise HTTPException(status_code=400, detail=f"Could not download file_url: HTTP {resp.status_code}")

    content = resp.content or b""
    max_bytes = 50 * 1024 * 1024
    if len(content) > max_bytes:
        raise HTTPException(status_code=413, detail=f"File too large ({len(content)} bytes). Max {max_bytes} bytes")

    # Parse XML
    try:
        root = ET.fromstring(content)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid XML: {e}")

    # Extract FilingCE details for a single 'primary filer'
    filing_ce_name = _find_text(root, ["GLOBEBody", "FilingInfo", "FilingCE", "Name"])
    filing_ce_tin = _find_text(root, ["GLOBEBody", "FilingInfo", "FilingCE", "TIN"])
    filing_ce_role = _find_text(root, ["GLOBEBody", "FilingInfo", "FilingCE", "Role"])

    # Derive a stable filer_code
    filer_code = _safe_code(filing_ce_tin or filing_ce_name or filing.tenant_id, prefix="FE")

    now = datetime.utcnow()

    # Upsert filer register (single entry)
    filer_row = {
        "filing_id": filing_id,
        "filer_code": filer_code,
        "legal_name": filing_ce_name,
        "role": "FILING_CE",
        "jurisdiction_code": None,
        "tin": filing_ce_tin,
        "filing_ce_role": filing_ce_role,
        "updated_at": now,
        "created_at": now,
    }
    stmt = insert(models.Filer).values([filer_row])
    update_cols = {c.name: getattr(stmt.excluded, c.name) for c in models.Filer.__table__.columns if c.name not in ("id", "created_at")}
    stmt = stmt.on_conflict_do_update(constraint="uq_filer_filing_code", set_=update_cols)
    db.execute(stmt)
    db.commit()

    # Collect jurisdictions from JurisdictionSection and RecJurCode fallbacks.
    jurisdiction_rows: List[dict] = []
    jurisdiction_codes: Set[str] = set()

    gbody = _child(root, "GLOBEBody")
    if gbody is not None:
        for ch in list(gbody):
            if not isinstance(ch.tag, str):
                continue
            if _local(ch.tag) != "JurisdictionSection":
                continue
            jc = (_child_text(ch, "Jurisdiction") or "").strip().upper()
            if len(jc) != 2:
                continue
            jurisdiction_codes.add(jc)
            local_cur = _child_text(ch, "LocalCurrency")
            jurisdiction_rows.append({
                "filing_id": filing_id,
                "jurisdiction_code": jc,
                "local_currency": local_cur,
                "responsible_filer_code": filer_code,
                "computation_mode": None,
                "qdmt_applicable": None,
                "status": None,
                "notes": None,
                "updated_at": now,
                "created_at": now,
            })

    # Parse Constituent Entities from CorporateStructure/CE
    entity_rows: List[dict] = []
    entity_by_key: dict = {}

    def _entity_code_for(name: Optional[str], res: Optional[str], tin: Optional[str]) -> str:
        seed = f"{(res or '').strip().upper()}|{(tin or '').strip()}|{(name or '').strip()}"
        h = sha1(seed.encode("utf-8")).hexdigest()[:12].upper()
        return f"E{h}"

    if gbody is not None:
        general = _child(gbody, "GeneralSection")
        if general is not None:
            corp = _child(general, "CorporateStructure")
            if corp is not None:
                for ce in list(corp):
                    if not isinstance(ce.tag, str) or _local(ce.tag) != "CE":
                        continue
                    id_node = _child(ce, "ID")
                    name = _child_text(id_node, "Name") if id_node is not None else None
                    res = _child_text(id_node, "ResCountryCode") if id_node is not None else None
                    tin = _child_text(id_node, "TIN") if id_node is not None else None
                    id_rules = _child_text(id_node, "Rules") if id_node is not None else None
                    globe_status = _child_text(id_node, "GlobeStatus") if id_node is not None else None

                    entity_code = _entity_code_for(name, res, tin)
                    entity_by_key[id(ce)] = entity_code
                    jcode = (res or "").strip().upper() if res else None
                    if jcode and len(jcode) != 2:
                        jcode = None

                    entity_rows.append({
                        "filing_id": filing_id,
                        "entity_code": entity_code,
                        "legal_name": name,
                        "jurisdiction_code": jcode,
                        "tin": tin,
                        "included_in_gir": True,
                        "filed_by_filer_code": filer_code,
                        "id_rules": id_rules,
                        "globe_status": globe_status,
                        "parent_entity_code": None,
                        "ownership_type": None,
                        "ownership_percentage": None,
                        "owner_tin_override": None,
                        "updated_at": now,
                        "created_at": now,
                    })

                    if jcode:
                        jurisdiction_codes.add(jcode)

    # Import datapoints (flattened leaf nodes)
    recjur_codes: Set[str] = set()
    datapoint_rows: List[dict] = []

    def walk(node: ET.Element, path_parts: List[str], juris_code: Optional[str], entity_code: Optional[str]):
        tag = _local(node.tag) if isinstance(node.tag, str) else ""
        new_parts = path_parts + ([tag] if tag else [])

        # Children elements only
        children = [c for c in list(node) if isinstance(c.tag, str)]

        # Special scoping: entering JurisdictionSection (direct child of GLOBEBody)
        if tag == "GLOBEBody":
            for ch in children:
                ch_tag = _local(ch.tag)
                if ch_tag == "JurisdictionSection":
                    jc = (_child_text(ch, "Jurisdiction") or "").strip().upper()
                    jc = jc if len(jc) == 2 and jc.isalpha() else None
                    walk(ch, new_parts, juris_code=jc, entity_code=None)
                else:
                    walk(ch, new_parts, juris_code=None, entity_code=None)
            return

        # Special scoping: entering CorporateStructure/CE
        if tag == "CorporateStructure":
            for ch in children:
                ch_tag = _local(ch.tag)
                if ch_tag == "CE":
                    ecode = entity_by_key.get(id(ch))
                    if not ecode:
                        # Fallback if CE list parsing missed it
                        id_node = _child(ch, "ID")
                        name = _child_text(id_node, "Name") if id_node is not None else None
                        res = _child_text(id_node, "ResCountryCode") if id_node is not None else None
                        tin = _child_text(id_node, "TIN") if id_node is not None else None
                        ecode = _entity_code_for(name, res, tin)
                        entity_by_key[id(ch)] = ecode
                    walk(ch, new_parts, juris_code=None, entity_code=ecode)
                else:
                    walk(ch, new_parts, juris_code=None, entity_code=None)
            return

        if not children:
            text = (node.text or "").strip()
            if not text:
                return

            xml_path = "/" + "/".join([p for p in new_parts if p])

            context_key: Optional[str] = None
            if tag == "RecJurCode":
                code = text.strip().upper()
                if len(code) == 2 and code.isalpha():
                    recjur_codes.add(code)
                    if "/GeneralSection/RecJurCode" in xml_path:
                        context_key = f"GEN_RECJUR:{code}"
                    elif "/Summary/RecJurCode" in xml_path:
                        context_key = f"SUM_RECJUR:{code}"
                    elif "/JurisdictionSection/RecJurCode" in xml_path:
                        context_key = f"JUR_RECJUR:{(juris_code or code)}"
                    else:
                        context_key = f"RECJUR:{code}"

            dec = try_parse_decimal(text)
            dt = try_parse_date(text)

            datapoint_rows.append({
                "filing_id": filing_id,
                "filer_code": filer_code,
                "jurisdiction_code": juris_code,
                "entity_code": entity_code,
                "context_key": context_key,
                "xml_path": xml_path,
                "value_raw": text,
                "value_numeric": dec,
                "value_date": dt,
                "currency": None,
                "source": "import",
                "source_system": payload.source_system or "gir_xml_import",
                "notes": None,
                "updated_at": now,
                "created_at": now,
            })
            return

        for ch in children:
            walk(ch, new_parts, juris_code=juris_code, entity_code=entity_code)


    # Start traversal from root
    walk(root, [], juris_code=None, entity_code=None)

    # Fallback jurisdictions from RecJurCode values
    for code in sorted(recjur_codes):
        if code and len(code) == 2 and code.isalpha():
            jurisdiction_codes.add(code)

    # Upsert jurisdictions
    if jurisdiction_codes and not jurisdiction_rows:
        # If we have codes but no JurisdictionSection blocks, create minimal register rows.
        for jc in sorted(jurisdiction_codes):
            jurisdiction_rows.append({
                "filing_id": filing_id,
                "jurisdiction_code": jc,
                "local_currency": None,
                "responsible_filer_code": filer_code,
                "computation_mode": None,
                "qdmt_applicable": None,
                "status": None,
                "notes": "Derived from RecJurCode values",
                "updated_at": now,
                "created_at": now,
            })

    if jurisdiction_rows:
        stmt = insert(models.Jurisdiction).values(jurisdiction_rows)
        update_cols = {c.name: getattr(stmt.excluded, c.name) for c in models.Jurisdiction.__table__.columns if c.name not in ("id", "created_at")}
        stmt = stmt.on_conflict_do_update(constraint="uq_juris_filing_code", set_=update_cols)
        db.execute(stmt)
        db.commit()

    # Upsert entities
    if entity_rows:
        stmt = insert(models.ConstituentEntity).values(entity_rows)
        update_cols = {c.name: getattr(stmt.excluded, c.name) for c in models.ConstituentEntity.__table__.columns if c.name not in ("id", "created_at")}
        stmt = stmt.on_conflict_do_update(constraint="uq_entity_filing_code", set_=update_cols)
        db.execute(stmt)
        db.commit()

    # Upsert datapoints (chunked)
    if datapoint_rows:
        for chunk in _chunked(datapoint_rows, 5000):
            stmt = insert(models.DataPoint).values(chunk)
            update_cols = {c.name: getattr(stmt.excluded, c.name) for c in models.DataPoint.__table__.columns if c.name not in ("id", "created_at")}
            stmt = stmt.on_conflict_do_update(constraint="uq_datapoint_key", set_=update_cols)
            db.execute(stmt)
        db.commit()

    # Basic sanity warning: filing currency mismatch vs XML if present
    xml_currency = _find_text(root, ["GLOBEBody", "FilingInfo", "AccountingInfo", "Currency"])
    if xml_currency and filing.reporting_currency and xml_currency.strip().upper() != filing.reporting_currency.strip().upper():
        warnings.append(ImportGirXmlWarning(
            code="CURRENCY_MISMATCH",
            message=f"XML currency={xml_currency.strip().upper()} differs from filing.reporting_currency={filing.reporting_currency.strip().upper()}",
        ))

    # Update filing timestamp
    filing.updated_at = now
    db.add(filing)
    db.commit()

    stats = ImportGirXmlStats(
        filers_total=1,
        jurisdictions_total=len(jurisdiction_codes),
        entities_total=len(entity_rows),
        datapoints_total=len(datapoint_rows),
    )

    return ImportGirXmlResponse(
        import_id=import_id,
        filing_id=filing_id,
        status="completed",
        stats=stats,
        warnings=warnings,
    )


@router.post("/gir-xml:validate", response_model=ImportGirXmlValidateResponse)
def import_gir_xml_and_validate(
    filing_id: str,
    payload: ImportGirXmlValidateRequest,
    db: Session = Depends(get_db),
):
    """One-click import + validate endpoint.

    This is designed specifically for customer-facing self-serve flows (Anything.com, etc.)
    where the UI wants to:
      1) upload XML
      2) import it into the engine
      3) run validations

    ...all in a single API call.
    """

    # First import
    import_payload = ImportGirXmlRequest(
        file_url=payload.file_url,
        source_system=payload.source_system,
        replace_existing=payload.replace_existing,
        strict_xsd=payload.strict_xsd,
    )
    import_result = import_gir_xml(filing_id, import_payload, db)

    # Then validate (reuse existing implementation for consistent persistence)
    try:
        run_dict = _create_validation_run(
            filing_id,
            ValidationRunCreate(notes=payload.notes),
            db,
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Validation failed: {e}")

    return ImportGirXmlValidateResponse(
        import_result=import_result,
        validation_run=ValidationRunRead(**run_dict),
    )
