from fastapi import APIRouter, Depends, HTTPException
from app.core.settings import settings
from app.services.config_loader import list_config_versions, load_config_meta
from app.services.reconciliation_sets import load_reconciliation_sets, default_reconciliation_sets

router = APIRouter(prefix="/config", tags=["config"])

@router.get("/versions")
def get_versions():
    return {"versions": list_config_versions(settings.config_root)}

@router.get("/versions/{config_version_id}")
def get_version_meta(config_version_id: str):
    try:
        meta = load_config_meta(settings.config_root, config_version_id)
        return meta
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Config version not found")


@router.get("/versions/{config_version_id}/reconciliation-sets")
def get_reconciliation_sets(config_version_id: str):
    """List reconciliation set definitions for a config version.

    These sets drive the Sprint 2.2 expected-datapoints matrix.
    """
    try:
        sets = load_reconciliation_sets(settings.config_root, config_version_id)
        if not sets:
            sets = default_reconciliation_sets()
        return {
            "config_version_id": config_version_id,
            "count": len(sets),
            "sets": [
                {
                    "set_id": s.set_id,
                    "description": s.description,
                    "section": s.section,
                    "scope": s.scope,
                    "xpaths": s.xpaths,
                    "xpath_includes": s.xpath_includes,
                    "xpath_excludes": s.xpath_excludes,
                    "required_only": s.required_only,
                    "exclude_repeatable": s.exclude_repeatable,
                    "computation_mode_in": s.computation_mode_in,
                    "qdmt_applicable": s.qdmt_applicable,
                    "pack_family": s.pack_family,
                    "pack_variant": s.pack_variant,
                    "pack_tags": s.pack_tags,
                    "treat_included_as_required": s.treat_included_as_required,
                }
                for s in sets
            ],
        }
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Config version not found")
