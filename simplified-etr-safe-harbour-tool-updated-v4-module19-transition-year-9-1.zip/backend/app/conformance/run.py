from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict

from app.services.calculator_v2 import calculate_v2
from app.services.models_v2 import CalculationRequestV2


CASES_DIR = Path(__file__).parent / "cases"


def _load_cases() -> list[dict[str, Any]]:
    cases = []
    for p in sorted(CASES_DIR.glob("*.json")):
        with p.open("r", encoding="utf-8") as f:
            cases.append(json.load(f))
    return cases


def _get_result_by_tj(resp: Any, tj_id: str) -> Any:
    for r in resp.results:
        if r.tested_jurisdiction_id == tj_id:
            return r
    return None


def _assert_field(case_id: str, tj_id: str, field: str, expected: Any, actual: Any) -> tuple[bool, str]:
    if field == "entry_reentry_mode":
        # nested field
        mode = actual.entry_reentry_status.mode if actual and actual.entry_reentry_status else None
        ok = (mode == expected)
        return ok, f"{field}: expected {expected!r}, got {mode!r}"
    val = getattr(actual, field, None) if actual else None
    ok = (val == expected)
    return ok, f"{field}: expected {expected!r}, got {val!r}"


def run_cases(selected: set[str] | None = None) -> int:
    cases = _load_cases()
    failed = 0
    ran = 0
    for case in cases:
        cid = case.get("case_id") or "unknown"
        if selected and cid not in selected:
            continue
        ran += 1
        req_dict = case["request"]
        req = CalculationRequestV2.model_validate(req_dict)
        resp = calculate_v2(req)

        assertions: Dict[str, Dict[str, Any]] = case.get("assertions", {})
        case_failed = False
        for tj_id, asserts in assertions.items():
            r = _get_result_by_tj(resp, tj_id)
            if r is None:
                print(f"[FAIL] {cid}: missing result for tested_jurisdiction_id={tj_id}")
                case_failed = True
                continue
            for field, expected in asserts.items():
                ok, msg = _assert_field(cid, tj_id, field, expected, r)
                if not ok:
                    print(f"[FAIL] {cid} / {tj_id}: {msg}")
                    case_failed = True
        if not case_failed:
            print(f"[PASS] {cid}")
        else:
            failed += 1

    print(f"\nRan {ran} case(s). Failed {failed}.")
    return 1 if failed else 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run Simplified ETR Safe Harbour conformance cases.")
    parser.add_argument("--case", action="append", dest="cases", help="Case ID to run (can specify multiple).")
    args = parser.parse_args(argv)
    selected = set(args.cases) if args.cases else None
    return run_cases(selected)


if __name__ == "__main__":
    raise SystemExit(main())
