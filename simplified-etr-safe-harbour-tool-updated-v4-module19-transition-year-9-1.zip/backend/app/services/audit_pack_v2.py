from __future__ import annotations

import io
import json
import zipfile
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from openpyxl import Workbook
from openpyxl.utils import get_column_letter

# PDF is optional (to keep deployment lightweight). If reportlab is not installed,
# the audit pack will include a human-readable summary.txt instead.
try:
    from reportlab.lib.pagesizes import A4  # type: ignore
    from reportlab.pdfgen import canvas  # type: ignore
    _HAS_REPORTLAB = True
except Exception:  # pragma: no cover
    A4 = None
    canvas = None
    _HAS_REPORTLAB = False

from app.services.models_v2 import (
    AuditPackRequestV2,
    AuditPackOptionsV2,
    CalculationRequestV2,
    CalculationResponseV2,
)


def _now_utc_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _safe_filename(s: str) -> str:
    out = []
    for ch in s:
        if ch.isalnum() or ch in ("-", "_", ".", " "):
            out.append(ch)
        else:
            out.append("_")
    return "".join(out).strip().replace(" ", "_")


def _json_dumps(obj: Any, *, pretty: bool = True) -> str:
    def _default(o: Any):
        if hasattr(o, "model_dump"):
            return o.model_dump()
        if hasattr(o, "isoformat"):
            return o.isoformat()
        return str(o)

    if pretty:
        return json.dumps(obj, indent=2, ensure_ascii=False, default=_default)
    return json.dumps(obj, ensure_ascii=False, default=_default)


def _autosize(ws) -> None:
    for col in ws.columns:
        try:
            col_letter = get_column_letter(col[0].column)
        except Exception:
            continue
        max_len = 0
        for cell in col:
            if cell.value is None:
                continue
            max_len = max(max_len, len(str(cell.value)))
        ws.column_dimensions[col_letter].width = min(70, max(12, max_len + 2))


def _flatten_value(v: Any) -> Any:
    if v is None:
        return None
    if isinstance(v, (str, int, float, bool)):
        return v
    if hasattr(v, "isoformat"):
        return v.isoformat()
    if hasattr(v, "model_dump"):
        v = v.model_dump()
    if isinstance(v, (dict, list)):
        return _json_dumps(v, pretty=False)
    return str(v)


def _write_table(ws, headers: List[str], rows: List[Dict[str, Any]]) -> None:
    ws.append(headers)
    for r in rows:
        ws.append([_flatten_value(r.get(h)) for h in headers])
    _autosize(ws)


def _sheet_from_models(wb: Workbook, title: str, items: List[Any]) -> None:
    ws = wb.create_sheet(title)
    if not items:
        ws["A1"] = "(none)"
        _autosize(ws)
        return
    dicts: List[Dict[str, Any]] = []
    keys: set[str] = set()
    for it in items:
        if hasattr(it, "model_dump"):
            d = it.model_dump()
        elif isinstance(it, dict):
            d = dict(it)
        else:
            d = {"value": str(it)}
        dicts.append(d)
        keys.update(d.keys())
    headers = sorted(keys)
    _write_table(ws, headers, dicts)


def _build_audit_workbook(req: CalculationRequestV2, resp: CalculationResponseV2, opts: AuditPackOptionsV2) -> bytes:
    wb = Workbook()
    wb.remove(wb.active)

    ws = wb.create_sheet("Summary")
    ws["A1"] = "Simplified ETR Safe Harbour - Audit Pack"
    ws["A3"] = "Generated (UTC)"
    ws["B3"] = _now_utc_iso()
    ws["A4"] = "Schema version"
    ws["B4"] = getattr(req, "schema_version", None) or ""
    ws["A5"] = "Ruleset version"
    ws["B5"] = getattr(req, "ruleset_version", None) or ""
    ws["A6"] = "Fiscal year start"
    ws["B6"] = getattr(req.fiscal_year, "start_date", None).isoformat() if req.fiscal_year else ""
    ws["A7"] = "Minimum rate"
    ws["B7"] = req.minimum_rate
    ws["A8"] = "Reporting currency"
    ws["B8"] = (req.group_profile.reporting_currency if req.group_profile else "") or ""

    ws["A10"] = "Tested Jurisdiction Results"
    headers = [
        "tested_jurisdiction_id",
        "jurisdiction_code",
        "eligible",
        "safe_harbour_applies",
        "simplified_income",
        "simplified_taxes",
        "simplified_etr",
        "minimum_rate",
        "deemed_zero_applied",
        "deemed_zero_basis",
        "entry_reentry_mode",
        "ineligibility_reasons",
    ]
    ws.append(headers)
    for r in resp.results:
        inelig = "; ".join(r.ineligibility_reasons) if getattr(r, "ineligibility_reasons", None) else ""
        mode = r.entry_reentry_status.mode if getattr(r, "entry_reentry_status", None) else ""
        ws.append([
            r.tested_jurisdiction_id,
            r.jurisdiction_code,
            r.eligible,
            r.safe_harbour_applies,
            r.simplified_income,
            r.simplified_taxes,
            r.simplified_etr,
            r.minimum_rate,
            getattr(r, "deemed_zero_applied", False),
            getattr(r, "deemed_zero_basis", None),
            mode,
            inelig,
        ])
    _autosize(ws)

    alloc_rows: List[Dict[str, Any]] = []
    for r in resp.results:
        for le in getattr(r, "allocation_ledger", []) or []:
            d = le.model_dump()
            d["tested_jurisdiction_id"] = r.tested_jurisdiction_id
            alloc_rows.append(d)
    _sheet_from_models(wb, "Allocations", alloc_rows)

    integrity_rows: List[Dict[str, Any]] = []
    for r in resp.results:
        ia = getattr(r, "integrity_assessment", None)
        if not ia:
            continue
        for issue in ia.issues:
            d = issue.model_dump()
            d["tested_jurisdiction_id"] = r.tested_jurisdiction_id
            integrity_rows.append(d)
    _sheet_from_models(wb, "Integrity", integrity_rows)

    elect_rows: List[Dict[str, Any]] = []
    for r in resp.results:
        for e in getattr(r, "effective_elections", []) or []:
            d = e.model_dump()
            d["tested_jurisdiction_id"] = r.tested_jurisdiction_id
            elect_rows.append(d)
    _sheet_from_models(wb, "Elections", elect_rows)

    if opts.include_trace:
        trace_rows: List[Dict[str, Any]] = []
        max_rows = opts.max_trace_rows_per_tj
        for r in resp.results:
            t = getattr(r, "trace", []) or []
            if max_rows is not None:
                t = t[:max_rows]
            for tl in t:
                d = tl.model_dump() if hasattr(tl, "model_dump") else {"step": getattr(tl, "step", ""), "amount": getattr(tl, "amount", None), "note": getattr(tl, "note", None)}
                d["tested_jurisdiction_id"] = r.tested_jurisdiction_id
                trace_rows.append(d)
        _sheet_from_models(wb, "Trace", trace_rows)

    if opts.include_registers:
        _sheet_from_models(wb, "AYE_Adjustments", req.after_year_end_adjustments or [])
        _sheet_from_models(wb, "TP_Register", req.transfer_pricing_adjustments or [])
        _sheet_from_models(wb, "FlowThrough_Alloc", req.flow_through_entities or [])
        _sheet_from_models(wb, "AllocableTaxItems", req.allocable_tax_items or [])
        _sheet_from_models(wb, "PE_AllocationLines", getattr(req, "pe_allocation_lines", []) or [])
        _sheet_from_models(wb, "Permanent_Ests", getattr(req, "permanent_establishments", []) or [])
        _sheet_from_models(wb, "DDT_Open", getattr(req, "ddt_recapture_account_state_opening", []) or [])
        _sheet_from_models(wb, "DDT_Move", getattr(req, "ddt_recapture_account_movements", []) or [])
        _sheet_from_models(wb, "PriorYearStatus", getattr(req, "prior_years_status", []) or [])
        _sheet_from_models(wb, "Integrity_Adjust", getattr(req, "integrity_adjustments", []) or [])

        # Transition Year registers (Box 4.5)
        ty_open_rows: List[Dict[str, Any]] = []
        ty_state_open_rows: List[Dict[str, Any]] = []
        for tj in req.tested_jurisdictions:
            ty = getattr(tj, "transition_year", None)
            if ty is not None:
                for it in getattr(ty, "opening_deferred_tax_items", []) or []:
                    d = it.model_dump() if hasattr(it, "model_dump") else dict(it)
                    d["tested_jurisdiction_id"] = tj.tested_jurisdiction_id
                    ty_open_rows.append(d)
            st_open = getattr(tj, "transition_year_state_opening", None)
            if st_open is not None:
                for reg in getattr(st_open, "opening_deferred_tax_register", []) or []:
                    d = reg.model_dump() if hasattr(reg, "model_dump") else dict(reg)
                    d["tested_jurisdiction_id"] = tj.tested_jurisdiction_id
                    d["transition_year_fy_start"] = getattr(st_open, "transition_year_fy_start", None)
                    d["state_currency"] = getattr(st_open, "state_currency", None)
                    ty_state_open_rows.append(d)

        ty_state_close_rows: List[Dict[str, Any]] = []
        for r in resp.results:
            st = getattr(r, "transition_year_state_closing", None)
            if st is None:
                continue
            for reg in getattr(st, "opening_deferred_tax_register", []) or []:
                d = reg.model_dump() if hasattr(reg, "model_dump") else dict(reg)
                d["tested_jurisdiction_id"] = r.tested_jurisdiction_id
                d["transition_year_fy_start"] = getattr(st, "transition_year_fy_start", None)
                d["state_currency"] = getattr(st, "state_currency", None)
                ty_state_close_rows.append(d)

        _sheet_from_models(wb, "TY_OpeningDT", ty_open_rows)
        _sheet_from_models(wb, "TY_StateOpenDT", ty_state_open_rows)
        _sheet_from_models(wb, "TY_StateCloseDT", ty_state_close_rows)

    bio = io.BytesIO()
    wb.save(bio)
    return bio.getvalue()


def _build_summary_text(req: CalculationRequestV2, resp: CalculationResponseV2) -> str:
    fy = req.fiscal_year.start_date.isoformat() if req.fiscal_year else ""
    rc = (req.group_profile.reporting_currency if req.group_profile else "") or ""
    lines = []
    lines.append("Simplified ETR Safe Harbour – Audit Summary")
    lines.append(f"Generated (UTC): {_now_utc_iso()}")
    lines.append(f"Fiscal year start: {fy}")
    lines.append(f"Minimum rate: {req.minimum_rate}")
    lines.append(f"Reporting currency: {rc}")
    lines.append(f"Ruleset: {getattr(req, 'ruleset_version', '')}")
    lines.append("")
    lines.append("Tested Jurisdiction Results:")
    for r in resp.results:
        lines.append(
            f"- {r.tested_jurisdiction_id} ({r.jurisdiction_code}): eligible={r.eligible} "
            f"safe_harbour={r.safe_harbour_applies} income={r.simplified_income:.2f} "
            f"taxes={r.simplified_taxes:.2f} etr={r.simplified_etr:.4f}"
        )
    return "\n".join(lines) + "\n"


def _build_pdf_summary(req: CalculationRequestV2, resp: CalculationResponseV2) -> bytes:
    # Only called when reportlab is available
    assert _HAS_REPORTLAB and canvas is not None and A4 is not None
    bio = io.BytesIO()
    c = canvas.Canvas(bio, pagesize=A4)
    width, height = A4

    y = height - 50
    c.setFont("Helvetica-Bold", 14)
    c.drawString(50, y, "Simplified ETR Safe Harbour – Audit Summary")
    y -= 25
    c.setFont("Helvetica", 10)
    c.drawString(50, y, f"Generated (UTC): {_now_utc_iso()}")
    y -= 14
    fy = req.fiscal_year.start_date.isoformat() if req.fiscal_year else ""
    c.drawString(50, y, f"Fiscal year start: {fy}    Minimum rate: {req.minimum_rate}")
    y -= 14
    rc = (req.group_profile.reporting_currency if req.group_profile else "") or ""
    c.drawString(50, y, f"Reporting currency: {rc}    Ruleset: {getattr(req, 'ruleset_version', '')}")
    y -= 22

    c.setFont("Helvetica-Bold", 9)
    cols = [50, 150, 235, 315, 390, 470]
    c.drawString(cols[0], y, "TJ ID")
    c.drawString(cols[1], y, "Eligible")
    c.drawString(cols[2], y, "SH applies")
    c.drawString(cols[3], y, "Income")
    c.drawString(cols[4], y, "Taxes")
    c.drawString(cols[5], y, "ETR")
    y -= 12
    c.setFont("Helvetica", 9)

    for r in resp.results:
        if y < 80:
            c.showPage()
            y = height - 60
            c.setFont("Helvetica-Bold", 9)
            c.drawString(cols[0], y, "TJ ID")
            c.drawString(cols[1], y, "Eligible")
            c.drawString(cols[2], y, "SH applies")
            c.drawString(cols[3], y, "Income")
            c.drawString(cols[4], y, "Taxes")
            c.drawString(cols[5], y, "ETR")
            y -= 12
            c.setFont("Helvetica", 9)

        c.drawString(cols[0], y, str(r.tested_jurisdiction_id))
        c.drawString(cols[1], y, "Y" if r.eligible else "N")
        c.drawString(cols[2], y, "Y" if r.safe_harbour_applies else "N")
        c.drawRightString(cols[3] + 60, y, f"{r.simplified_income:,.2f}")
        c.drawRightString(cols[4] + 60, y, f"{r.simplified_taxes:,.2f}")
        c.drawRightString(cols[5] + 40, y, f"{r.simplified_etr:.4f}")
        y -= 12

    c.showPage()
    c.save()
    return bio.getvalue()


def build_audit_pack_zip(payload: AuditPackRequestV2) -> Tuple[bytes, str]:
    req = payload.request
    resp = payload.response
    opts = payload.options or AuditPackOptionsV2()

    if resp is None:
        raise ValueError("Audit pack export requires both request and response (response missing).")

    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    prefix = _safe_filename(opts.filename_prefix or "audit_pack")
    filename = f"{prefix}_{ts}.zip"

    manifest = {
        "generated_utc": _now_utc_iso(),
        "schema_version": getattr(req, "schema_version", None),
        "ruleset_version": getattr(req, "ruleset_version", None),
        "fiscal_year_start": req.fiscal_year.start_date.isoformat() if req.fiscal_year else None,
        "minimum_rate": req.minimum_rate,
        "tested_jurisdiction_count": len(req.tested_jurisdictions or []),
        "result_count": len(resp.results or []),
        "notes": [
            "This audit pack includes request/response JSON plus derived Excel and summary files.",
            "Excel sheets are a reconciliation aid; request.json and response.json are the authoritative record.",
            "If reportlab is installed, the pack contains summary.pdf; otherwise it contains summary.txt.",
        ],
    }

    out = io.BytesIO()
    with zipfile.ZipFile(out, mode="w", compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr("manifest.json", _json_dumps(manifest, pretty=True))

        if opts.include_json:
            z.writestr("request.json", _json_dumps(req, pretty=True))
            z.writestr("response.json", _json_dumps(resp, pretty=True))

        if opts.include_excel:
            xlsx = _build_audit_workbook(req, resp, opts)
            z.writestr("audit_pack.xlsx", xlsx)

        if opts.include_pdf and _HAS_REPORTLAB:
            z.writestr("summary.pdf", _build_pdf_summary(req, resp))
        else:
            z.writestr("summary.txt", _build_summary_text(req, resp))

    return out.getvalue(), filename
