from __future__ import annotations

import os
import time
from dataclasses import dataclass
from typing import Dict, Optional, Tuple

from fastapi import FastAPI, Request
from starlette.responses import JSONResponse, Response

from app.services.auth_v2 import get_auth_config, get_tenant_id_from_request
from app.services.usage_store_v2 import (
    record_audit_event,
    increment_daily_usage,
    enforce_daily_quota_or_raise,
    is_usage_controls_enabled,
    QuotaExceededError,
)


@dataclass
class RateLimitDecision:
    allowed: bool
    retry_after_seconds: int
    limit: int
    window_seconds: int


class FixedWindowRateLimiter:
    """Simple fixed-window per-tenant request counter.

    Notes:
    - in-memory only (per instance). This is a pragmatic control for Render.
    - For true distributed limits, you'd use Redis; we intentionally avoid that dependency.
    """

    def __init__(self, window_seconds: int = 60):
        self.window_seconds = window_seconds
        # key -> (window_start_epoch, count)
        self._state: Dict[str, Tuple[int, int]] = {}

    def check(self, key: str, limit: int) -> RateLimitDecision:
        if limit <= 0:
            return RateLimitDecision(allowed=True, retry_after_seconds=0, limit=limit, window_seconds=self.window_seconds)

        now = int(time.time())
        window_start = (now // self.window_seconds) * self.window_seconds
        cur = self._state.get(key)
        if cur is None or cur[0] != window_start:
            self._state[key] = (window_start, 1)
            return RateLimitDecision(allowed=True, retry_after_seconds=0, limit=limit, window_seconds=self.window_seconds)

        count = cur[1] + 1
        self._state[key] = (window_start, count)
        if count <= limit:
            return RateLimitDecision(allowed=True, retry_after_seconds=0, limit=limit, window_seconds=self.window_seconds)

        retry_after = (window_start + self.window_seconds) - now
        retry_after = max(1, retry_after)
        return RateLimitDecision(allowed=False, retry_after_seconds=retry_after, limit=limit, window_seconds=self.window_seconds)


def _int_env(name: str, default: int, *, min_v: int = 0, max_v: int = 10_000_000) -> int:
    v = (os.getenv(name) or "").strip()
    if not v:
        return default
    try:
        n = int(v)
        return max(min_v, min(max_v, n))
    except ValueError:
        return default


def _max_request_bytes() -> int:
    return _int_env("MAX_REQUEST_BYTES", 2_000_000, min_v=10_000, max_v=200_000_000)


def _max_upload_bytes() -> int:
    return _int_env("MAX_UPLOAD_BYTES", 15_000_000, min_v=100_000, max_v=1_000_000_000)


def _rate_limit_rpm_default() -> int:
    return _int_env("RATE_LIMIT_RPM_DEFAULT", 600, min_v=0, max_v=200_000)


def _rate_limit_rpm_calc() -> int:
    return _int_env("RATE_LIMIT_RPM_CALC", 120, min_v=0, max_v=50_000)


def _rate_limit_rpm_export() -> int:
    return _int_env("RATE_LIMIT_RPM_EXPORT", 120, min_v=0, max_v=50_000)


def _rate_limit_rpm_upload() -> int:
    return _int_env("RATE_LIMIT_RPM_UPLOAD", 120, min_v=0, max_v=50_000)


def _body_limit_for_request(request: Request) -> int:
    # File uploads can be larger than normal JSON.
    path = request.url.path
    if path.endswith("/parse-csv") or "parse-csv" in path or path.endswith("/calc-from-excel") or "calc-from-excel" in path:
        return _max_upload_bytes()
    if "/export/" in path:
        return _max_request_bytes()  # export payload is JSON request+response; keep bounded
    return _max_request_bytes()


def _rpm_limit_for_request(request: Request) -> int:
    path = request.url.path
    if path.endswith("/v2/calc") or path.endswith("/v1/calc"):
        return _rate_limit_rpm_calc()
    if "/export/" in path:
        return _rate_limit_rpm_export()
    if path.endswith("/parse-csv") or "parse-csv" in path or "calc-from-excel" in path:
        return _rate_limit_rpm_upload()
    return _rate_limit_rpm_default()


def _resolve_tenant_id(request: Request) -> str:
    # Prefer tenant already set by auth middleware.
    tenant = getattr(request.state, "tenant_id", None)
    if tenant:
        return str(tenant)

    # Fallback: infer from auth config directly so middleware order doesn't matter.
    cfg = get_auth_config()
    if not cfg.enabled:
        return "public"

    # Try header name first, then bearer.
    key = request.headers.get(cfg.header_name)
    if not key:
        auth = request.headers.get("Authorization") or ""
        if auth.lower().startswith("bearer "):
            key = auth.split(" ", 1)[1].strip()
    if not key:
        return "public"
    return cfg.key_to_tenant.get(key.strip(), "public")


def _client_ip(request: Request) -> Optional[str]:
    # Render/most reverse proxies set X-Forwarded-For.
    xff = request.headers.get("X-Forwarded-For")
    if xff:
        return xff.split(",")[0].strip()
    return request.client.host if request.client else None


def _json_error(status: int, detail: str, *, error_code: str, retry_after: Optional[int] = None, extra: Optional[dict] = None) -> JSONResponse:
    payload = {"detail": detail, "error_code": error_code}
    if retry_after is not None:
        payload["retry_after_seconds"] = int(retry_after)
    if extra:
        payload.update(extra)
    headers = {}
    if retry_after is not None:
        headers["Retry-After"] = str(int(retry_after))
    return JSONResponse(status_code=status, content=payload, headers=headers)


def add_usage_controls_middleware(app: FastAPI) -> None:
    """Install Module 18 usage controls middleware.

    Controls included:
      - rate limiting (in-memory per tenant)
      - request/upload size caps (Content-Length, and best-effort fallback)
      - daily quotas for calc/export/upload bytes (sqlite)
      - audit logging (sqlite)
    """

    limiter = FixedWindowRateLimiter(window_seconds=_int_env("RATE_LIMIT_WINDOW_SECONDS", 60, min_v=10, max_v=600))

    @app.middleware("http")
    async def _usage_controls(request: Request, call_next):
        start = time.time()

        # Always allow CORS preflight
        if request.method.upper() == "OPTIONS":
            return await call_next(request)

        path = request.url.path
        if not path.startswith("/api"):
            return await call_next(request)

        # If usage controls are disabled, we still want a tiny audit trail in server logs only.
        enabled = is_usage_controls_enabled()

        tenant_id = _resolve_tenant_id(request)

        # ------------------------
        # Request size caps
        # ------------------------
        body_limit = _body_limit_for_request(request)
        content_length = request.headers.get("content-length")
        if content_length:
            try:
                n = int(content_length)
                if n > body_limit:
                    if enabled:
                        record_audit_event(
                            tenant_id=tenant_id,
                            method=request.method,
                            path=path,
                            status_code=413,
                            duration_ms=0,
                            request_bytes=n,
                            response_bytes=0,
                            client_ip=_client_ip(request),
                            user_agent=request.headers.get("user-agent"),
                            error_code="REQUEST_TOO_LARGE",
                        )
                    return _json_error(
                        413,
                        f"Request body too large. Max={body_limit} bytes for this endpoint.",
                        error_code="REQUEST_TOO_LARGE",
                        extra={"max_bytes": body_limit},
                    )
            except ValueError:
                pass

        # Best-effort fallback when Content-Length is missing: read and cap.
        # This is safe for small bodies; for large streaming uploads, most clients do send Content-Length.
        if enabled and request.method.upper() in {"POST", "PUT", "PATCH"} and not content_length:
            try:
                body = await request.body()
                if len(body) > body_limit:
                    record_audit_event(
                        tenant_id=tenant_id,
                        method=request.method,
                        path=path,
                        status_code=413,
                        duration_ms=0,
                        request_bytes=len(body),
                        response_bytes=0,
                        client_ip=_client_ip(request),
                        user_agent=request.headers.get("user-agent"),
                        error_code="REQUEST_TOO_LARGE",
                    )
                    return _json_error(
                        413,
                        f"Request body too large. Max={body_limit} bytes for this endpoint.",
                        error_code="REQUEST_TOO_LARGE",
                        extra={"max_bytes": body_limit},
                    )
            except Exception:
                # If reading fails, let downstream handle.
                pass

        # ------------------------
        # Rate limit
        # ------------------------
        rpm = _rpm_limit_for_request(request)
        key = f"{tenant_id}:{path}:{request.method.upper()}"
        dec = limiter.check(key, rpm)
        if enabled and not dec.allowed:
            record_audit_event(
                tenant_id=tenant_id,
                method=request.method,
                path=path,
                status_code=429,
                duration_ms=0,
                request_bytes=int(content_length or 0),
                response_bytes=0,
                client_ip=_client_ip(request),
                user_agent=request.headers.get("user-agent"),
                error_code="RATE_LIMIT_EXCEEDED",
            )
            return _json_error(
                429,
                f"Rate limit exceeded. Limit={dec.limit} requests per {dec.window_seconds} seconds for this endpoint.",
                error_code="RATE_LIMIT_EXCEEDED",
                retry_after=dec.retry_after_seconds,
                extra={"limit": dec.limit, "window_seconds": dec.window_seconds},
            )

        # ------------------------
        # Daily quotas (calc/export/upload bytes)
        # ------------------------
        if enabled and tenant_id != "public":
            try:
                if path.endswith("/v2/calc") and request.method.upper() == "POST":
                    enforce_daily_quota_or_raise(tenant_id, event="calc", increment=1)
                if "/export/" in path and request.method.upper() == "POST":
                    enforce_daily_quota_or_raise(tenant_id, event="export", increment=1)
                # Upload bytes quota: use content-length when present
                if (path.endswith("/parse-csv") or "calc-from-excel" in path) and request.method.upper() == "POST":
                    bytes_in = int(content_length or 0)
                    if bytes_in > 0:
                        enforce_daily_quota_or_raise(tenant_id, event="upload_bytes", bytes_in=bytes_in)
            except QuotaExceededError as qe:
                record_audit_event(
                    tenant_id=tenant_id,
                    method=request.method,
                    path=path,
                    status_code=429,
                    duration_ms=0,
                    request_bytes=int(content_length or 0),
                    response_bytes=0,
                    client_ip=_client_ip(request),
                    user_agent=request.headers.get("user-agent"),
                    error_code=qe.error_code,
                )
                return _json_error(429, str(qe), error_code=qe.error_code)

        # ------------------------
        # Proceed
        # ------------------------
        response: Response
        error_code: Optional[str] = None
        try:
            response = await call_next(request)
        except Exception as e:
            # Still record audit trail for uncaught errors
            if enabled:
                duration_ms = int((time.time() - start) * 1000)
                record_audit_event(
                    tenant_id=tenant_id,
                    method=request.method,
                    path=path,
                    status_code=500,
                    duration_ms=duration_ms,
                    request_bytes=int(content_length or 0),
                    response_bytes=0,
                    client_ip=_client_ip(request),
                    user_agent=request.headers.get("user-agent"),
                    error_code="UNHANDLED_EXCEPTION",
                )
            raise

        # ------------------------
        # Post: update usage counters and audit log
        # ------------------------
        duration_ms = int((time.time() - start) * 1000)
        resp_len = int(response.headers.get("content-length") or 0)
        req_len = int(content_length or 0)

        if enabled and tenant_id != "public":
            # Always count API requests
            inc_kwargs = {"request_count": 1}

            if path.endswith("/v2/calc") and request.method.upper() == "POST":
                inc_kwargs["calc_count"] = 1
            if "/export/" in path and request.method.upper() == "POST":
                inc_kwargs["export_count"] = 1
            if (path.endswith("/parse-csv") or "calc-from-excel" in path) and request.method.upper() == "POST":
                inc_kwargs["upload_bytes"] = max(0, req_len)

            try:
                increment_daily_usage(tenant_id, **inc_kwargs)
            except Exception:
                pass

        if enabled:
            record_audit_event(
                tenant_id=tenant_id,
                method=request.method,
                path=path,
                status_code=int(response.status_code),
                duration_ms=duration_ms,
                request_bytes=req_len,
                response_bytes=resp_len,
                client_ip=_client_ip(request),
                user_agent=request.headers.get("user-agent"),
                error_code=error_code,
            )

        # Helpful headers for debugging/quota awareness
        response.headers.setdefault("X-RateLimit-Limit", str(rpm))
        response.headers.setdefault("X-Max-Request-Bytes", str(body_limit))

        return response
