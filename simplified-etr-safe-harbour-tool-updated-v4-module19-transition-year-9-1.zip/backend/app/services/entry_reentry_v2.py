from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Dict, List, Optional, Tuple

from app.services.models import TraceLine
from app.services.models_v2 import (
    CalculationRequestV2,
    EntryReentryStatusV2,
    PriorYearStatusV2,
    TestedJurisdictionInputV2,
)


def _days_in_month(year: int, month: int) -> int:
    # month: 1-12
    if month in {1, 3, 5, 7, 8, 10, 12}:
        return 31
    if month in {4, 6, 9, 11}:
        return 30
    # February
    leap = (year % 4 == 0 and (year % 100 != 0 or year % 400 == 0))
    return 29 if leap else 28


def add_months(d: date, months: int) -> date:
    """Add months to a date, clamping day to last day of resulting month."""

    y = d.year
    m = d.month
    total = (y * 12 + (m - 1)) + int(months)
    new_y = total // 12
    new_m = total % 12 + 1
    new_day = min(d.day, _days_in_month(new_y, new_m))
    return date(new_y, new_m, new_day)


def _expected_fiscal_year_starts(anchor_fy_start: date, lookback_months: int) -> Tuple[date, List[date]]:
    """Return (window_start, expected_fy_starts) stepping back in 12-month increments.

    This matches the OECD phrasing "each fiscal year beginning within 24 months" for typical 12-month fiscal years.
    """

    window_start = add_months(anchor_fy_start, -int(lookback_months))
    expected: List[date] = []
    cur = add_months(anchor_fy_start, -12)
    while cur >= window_start:
        expected.append(cur)
        cur = add_months(cur, -12)
    return window_start, expected


def _is_tainting_topup(row: PriorYearStatusV2, *, ignore_additional: bool) -> Tuple[bool, Optional[str]]:
    """Return (taints, note)."""

    if row.topup_tax_status != "TOPUP_TAX":
        return False, None

    if ignore_additional and bool(getattr(row, "additional_current_topup_tax_for_prior_year", False)):
        return False, "Top-up tax flagged as Additional Current Top-up Tax for a prior year; ignored for Box 7.2." 

    # Transitional CbCR SH and QDMTT SH are not treated as Specified Safe Harbours for 7.2 purposes.
    if row.regime in {"TRANSITIONAL_CBCR_SAFE_HARBOUR", "QDMTT_SAFE_HARBOUR"}:
        return False, f"Top-up tax under regime '{row.regime}' is not treated as tainting for Box 7.2 re-entry purposes."

    # FULL_GLOBE and SPECIFIED_SAFE_HARBOUR are tainting. OTHER is treated conservatively as tainting.
    if row.regime in {"FULL_GLOBE", "SPECIFIED_SAFE_HARBOUR", "SIMPLIFIED_ETR_SAFE_HARBOUR", "OTHER"}:
        return True, None

    # Default conservative
    return True, f"Regime '{row.regime}' treated conservatively as tainting."


@dataclass
class EntryReentryEvaluation:
    status: Optional[EntryReentryStatusV2]
    no_topup_override: Optional[bool]
    reentry_override: Optional[bool]
    trace: List[TraceLine]


def evaluate_entry_reentry(req: CalculationRequestV2, tj: TestedJurisdictionInputV2, *, current_fy_start: date) -> EntryReentryEvaluation:
    """Evaluate Box 7.2 entry / re-entry criteria for a Tested Jurisdiction.

    Returns:
      - status: EntryReentryStatusV2 (or None if not computed)
      - overrides: (no_topup_override, reentry_override) to be applied to v1 eligibility flags
      - trace: trace lines for audit

    Policy:
      - If no prior_years_status rows are provided for the TJ, no override is applied.
      - If require_complete_lookback_coverage is True and required years are missing, the criteria fails unless
        the user provided the legacy EligibilityInputsV2 attestation boolean for that criterion.
      - Re-entry criteria uses the anchor year defined as the first fiscal year beginning after the first fiscal
        year for which the Simplified ETR SH election is not made following a prior election sequence.
    """

    opt = getattr(req, "entry_reentry_automation", None)
    if opt is None or not bool(getattr(opt, "enable_auto_entry_reentry", True)):
        return EntryReentryEvaluation(status=None, no_topup_override=None, reentry_override=None, trace=[])

    tj_id = tj.tested_jurisdiction_id
    rows_all = [r for r in (req.prior_years_status or []) if r.tested_jurisdiction_id == tj_id]
    if not rows_all:
        # Nothing to compute; keep legacy booleans.
        return EntryReentryEvaluation(status=None, no_topup_override=None, reentry_override=None, trace=[])

    rows_all.sort(key=lambda r: r.fiscal_year_start)

    lookback_months = int(getattr(opt, "lookback_months", 24) or 24)
    require_complete = bool(getattr(opt, "require_complete_lookback_coverage", True))
    ignore_additional = bool(getattr(opt, "ignore_additional_current_topup_tax_for_prior_year", True))

    # Determine election history from the prior-year register: regime == SIMPLIFIED_ETR_SAFE_HARBOUR
    elected_years = [r.fiscal_year_start for r in rows_all if r.regime == "SIMPLIFIED_ETR_SAFE_HARBOUR" and r.fiscal_year_start < current_fy_start]

    trace: List[TraceLine] = []

    def evaluate_window(anchor: date, *, criterion: str, fallback_attestation: Optional[bool]) -> Tuple[bool, EntryReentryStatusV2]:
        window_start, expected_starts = _expected_fiscal_year_starts(anchor, lookback_months)
        window_end = anchor

        in_window = [r for r in rows_all if (window_start <= r.fiscal_year_start < window_end)]
        by_start: Dict[date, PriorYearStatusV2] = {r.fiscal_year_start: r for r in in_window}

        missing = [d for d in expected_starts if d not in by_start]
        tainting: List[date] = []
        notes: List[str] = []

        # Check tainting years
        for r in in_window:
            taints, note = _is_tainting_topup(r, ignore_additional=ignore_additional)
            if note:
                notes.append(f"FY {r.fiscal_year_start}: {note}")
            if taints:
                tainting.append(r.fiscal_year_start)

        ok = (len(tainting) == 0)
        used_fallback = False

        if require_complete and missing:
            if fallback_attestation is True:
                used_fallback = True
                notes.append(
                    f"Lookback coverage missing for {len(missing)} expected fiscal year(s); used EligibilityInputsV2 attestation as fallback for {criterion}."
                )
            else:
                ok = False
                notes.append(
                    f"Lookback coverage missing for {len(missing)} expected fiscal year(s) and no fallback attestation was provided."
                )

        status = EntryReentryStatusV2(
            mode="FIRST_ELECTION",
            anchor_fiscal_year_start=anchor,
            lookback_window_start=window_start,
            lookback_window_end=window_end,
            lookback_months=lookback_months,
            required_prior_fiscal_year_starts=list(expected_starts),
            missing_prior_fiscal_year_starts=list(missing),
            tainting_fiscal_year_starts=list(tainting),
            used_fallback_attestation=used_fallback,
            notes=notes,
        )
        return ok, status

    # Determine mode
    if not elected_years:
        mode = "FIRST_ELECTION"
        anchor = current_fy_start

        fallback = bool(getattr(tj.eligibility_inputs, "no_topup_tax_in_prior_24_months", False))
        ok, st = evaluate_window(anchor, criterion="entry", fallback_attestation=fallback)
        st.mode = mode
        st.entry_criteria_satisfied = bool(ok)
        st.reentry_criteria_satisfied = None

        trace.append(
            TraceLine(
                section="eligibility",
                step="Entry criteria (Box 7.2) computed from prior_years_status",
                amount=0.0,
                note=(
                    f"Mode={mode}. Anchor FY start={anchor}. Lookback months={lookback_months}. "
                    + ("PASS" if ok else "FAIL")
                ),
            )
        )

        # Override legacy v1 boolean field used by eligibility engine.
        return EntryReentryEvaluation(status=st, no_topup_override=bool(ok), reentry_override=None, trace=trace)

    # There was a prior election.
    prev_year_start = add_months(current_fy_start, -12)
    prev = next((r for r in rows_all if r.fiscal_year_start == prev_year_start), None)
    if prev is not None and prev.regime == "SIMPLIFIED_ETR_SAFE_HARBOUR":
        mode = "CONTINUATION"
        st = EntryReentryStatusV2(
            mode=mode,
            anchor_fiscal_year_start=current_fy_start,
            lookback_window_start=add_months(current_fy_start, -lookback_months),
            lookback_window_end=current_fy_start,
            lookback_months=lookback_months,
            required_prior_fiscal_year_starts=[],
            missing_prior_fiscal_year_starts=[],
            tainting_fiscal_year_starts=[],
            entry_criteria_satisfied=True,
            reentry_criteria_satisfied=None,
            used_fallback_attestation=False,
            notes=["Prior fiscal year indicates Simplified ETR Safe Harbour election was made; treated as continuation (re-entry criteria not applied)."],
        )
        trace.append(
            TraceLine(
                section="eligibility",
                step="Entry/re-entry criteria (Box 7.2)",
                amount=0.0,
                note=f"Mode={mode}. Prior FY {prev_year_start} shows election made; no re-entry test applied.",
            )
        )
        # For continuation we keep eligibility entry booleans as True (do not re-check).
        return EntryReentryEvaluation(status=st, no_topup_override=True, reentry_override=None, trace=trace)

    # Re-entry scenario
    mode = "REENTRY"
    last_election_year = max(elected_years)

    # Lapse year = first year after the last election year where election not made (if recorded)
    later_rows = [r for r in rows_all if (r.fiscal_year_start > last_election_year and r.fiscal_year_start < current_fy_start)]
    lapse_row = next((r for r in later_rows if r.regime != "SIMPLIFIED_ETR_SAFE_HARBOUR"), None)

    assumed = False
    if lapse_row is None:
        assumed = True
        lapse_year_start = add_months(last_election_year, 12)
    else:
        lapse_year_start = lapse_row.fiscal_year_start

    anchor = add_months(lapse_year_start, 12)

    fallback_reentry = getattr(tj.eligibility_inputs, "reentry_no_topup_tax_in_prior_24_months", None)
    # If not explicitly provided, we do not assume.

    ok, st = evaluate_window(anchor, criterion="re-entry", fallback_attestation=(fallback_reentry is True))
    st.mode = mode
    st.entry_criteria_satisfied = True  # not used in re-entry path
    st.reentry_criteria_satisfied = bool(ok)

    if assumed:
        st.notes.append(
            "Lapse year not found in prior_years_status; assumed lapse year = last election year + 12 months. Provide a row for the first non-election year to avoid assumptions."
        )

    trace.append(
        TraceLine(
            section="eligibility",
            step="Re-entry criteria (Box 7.2) computed from prior_years_status",
            amount=0.0,
            note=(
                f"Mode={mode}. Last election FY start={last_election_year}. "
                f"Lapse FY start={lapse_year_start}{' (assumed)' if assumed else ''}. "
                f"Anchor FY start={anchor}. Lookback months={lookback_months}. "
                + ("PASS" if ok else "FAIL")
            ),
        )
    )

    # For v1 eligibility:
    # - treat entry criteria as satisfied (we're evaluating re-entry),
    # - set reentry boolean to drive eligibility result.
    return EntryReentryEvaluation(status=st, no_topup_override=True, reentry_override=bool(ok), trace=trace)
