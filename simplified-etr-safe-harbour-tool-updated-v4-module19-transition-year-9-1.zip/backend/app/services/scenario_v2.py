from __future__ import annotations

from datetime import date
from typing import Dict, List, Optional, Set

from app.services.models_v2 import (
    CalculationRequestV2,
    CalculationResponseV2,
    ScenarioAdvanceYearRequestV2,
    ScenarioAdvanceYearResponseV2,
    FxRateV2,
    PriorYearStatusV2,
)


def _add_year(d: date, years: int = 1) -> date:
    """Add calendar years to a date, handling Feb 29."""

    try:
        return d.replace(year=d.year + years)
    except ValueError:
        # Handle leap-day -> Feb 28
        if d.month == 2 and d.day == 29:
            return d.replace(month=2, day=28, year=d.year + years)
        raise


def _required_fx_currencies(req: CalculationRequestV2) -> Set[str]:
    """Return currencies that require FX translation (excluding reporting currency)."""

    reporting = (req.group_profile.reporting_currency if req.group_profile else None)
    if not reporting:
        return set()
    reporting = str(reporting).upper().strip()

    currencies: Set[str] = set()

    for tj in req.tested_jurisdictions:
        cur = tj.accounting_basis.currency
        if cur:
            cur = str(cur).upper().strip()
            if cur and cur != reporting:
                currencies.add(cur)

    for cb in req.cross_border_tax_items or []:
        if cb.currency:
            cur = str(cb.currency).upper().strip()
            if cur and cur != reporting:
                currencies.add(cur)

    # After-year-end adjustments may specify a currency distinct from the TJ accounting currency.
    for adj in req.after_year_end_adjustments or []:
        if getattr(adj, "currency", None):
            cur = str(adj.currency).upper().strip()
            if cur and cur != reporting:
                currencies.add(cur)

    # Transfer pricing adjustments register may also carry explicit currency codes.
    for tp in getattr(req, "transfer_pricing_adjustments", None) or []:
        if getattr(tp, "currency", None):
            cur = str(tp.currency).upper().strip()
            if cur and cur != reporting:
                currencies.add(cur)

    

    # Allocable tax items (module 5 scaffolding)
    for item in getattr(req, "allocable_tax_items", None) or []:
        if getattr(item, "currency", None):
            cur = str(item.currency).upper().strip()
            if cur and cur != reporting:
                currencies.add(cur)

    # Flow-through allocation lines may also carry explicit currency codes.
    for line in getattr(req, "flow_through_entities", None) or []:
        if getattr(line, "currency", None):
            cur = str(line.currency).upper().strip()
            if cur and cur != reporting:
                currencies.add(cur)

    # PE allocation / PE simplification lines (v4 module 11)
    for line in getattr(req, "pe_allocation_lines", None) or []:
        if getattr(line, "currency", None):
            cur = str(line.currency).upper().strip()
            if cur and cur != reporting:
                currencies.add(cur)

    # Article 7.3 DDT recapture account state / movements (v4 module 14)
    for s in getattr(req, "ddt_recapture_account_state_opening", None) or []:
        if getattr(s, "currency", None):
            cur = str(s.currency).upper().strip()
            if cur and cur != reporting:
                currencies.add(cur)
    for m in getattr(req, "ddt_recapture_account_movements", None) or []:
        if getattr(m, "currency", None):
            cur = str(m.currency).upper().strip()
            if cur and cur != reporting:
                currencies.add(cur)

    return currencies


def _find_fx_rate(
    fx_rates: List[FxRateV2],
    currency: str,
    fiscal_year_start: Optional[date],
) -> Optional[FxRateV2]:
    """Find FX rate row for a currency for a specific fiscal year, falling back to default (fy_start None)."""

    currency = str(currency).upper().strip()
    # Exact year match first
    for r in fx_rates:
        if str(r.currency).upper().strip() == currency and r.fiscal_year_start == fiscal_year_start:
            return r
    # Default row (fy_start None)
    for r in fx_rates:
        if str(r.currency).upper().strip() == currency and r.fiscal_year_start is None:
            return r
    return None


def advance_year_scenario(payload: ScenarioAdvanceYearRequestV2) -> ScenarioAdvanceYearResponseV2:
    """Build a next-fiscal-year CalculationRequestV2 from the last request + last response.

    This is a convenience endpoint for UI clients to run multi-year planning workflows.
    The server does not persist state; the client stores the returned next_request and
    can supply it again as the next year's last_request.
    """

    last_req = payload.last_request
    last_resp = payload.last_response
    opt = payload.options

    # Determine next fiscal year start
    next_start = opt.advance_to_fiscal_year_start or _add_year(last_req.fiscal_year.start_date, 1)
    next_end = None
    if last_req.fiscal_year.end_date:
        try:
            next_end = _add_year(last_req.fiscal_year.end_date, 1)
        except Exception:
            # Fallback: keep None if weird end_date
            next_end = None

    warnings: List[str] = []

    # Map results by Tested Jurisdiction ID for roll-forward items
    resp_by_id: Dict[str, any] = {r.tested_jurisdiction_id: r for r in (last_resp.results or [])}

    # Base next request as a deep copy
    next_req: CalculationRequestV2 = last_req.model_copy(deep=True)
    next_req.fiscal_year.start_date = next_start
    next_req.fiscal_year.end_date = next_end

    # Roll-forward per Tested Jurisdiction
    for tj in next_req.tested_jurisdictions:
        r = resp_by_id.get(tj.tested_jurisdiction_id)
        if r is None:
            warnings.append(
                f"No prior-year result found for Tested Jurisdiction '{tj.tested_jurisdiction_id}'. Carryforwards/state not rolled forward."
            )
        else:
            if opt.carry_forward_transition_year_state:
                tj.transition_year_state_opening = r.transition_year_state_closing
            if opt.carry_forward_carryforwards:
                tj.carryforwards_opening = list(r.carryforwards_closing or [])

        # Clear year-specific Transition Year inputs unless user wants to keep them.
        if opt.clear_transition_year_inputs and tj.transition_year is not None:
            tj.transition_year.opening_deferred_tax_items = []
            tj.transition_year.article_9_1_3_transfers = []

    # Roll-forward request-level PE simplification continuation state (v4 module 11)
    if getattr(opt, "carry_forward_pe_simplification_state", True):
        next_req.pe_simplification_state_opening = list(getattr(last_resp, "pe_simplification_state_closing", None) or [])
        if next_req.pe_simplification_state_opening:
            warnings.append(
                "Carried forward pe_simplification_state_opening from prior-year response (PE simplification election continuation state)."
            )
    else:
        if getattr(next_req, "pe_simplification_state_opening", None):
            next_req.pe_simplification_state_opening = []

    # Roll-forward Article 7.3 DDT recapture account state (v4 module 14)
    if getattr(opt, "carry_forward_ddt_recapture_account_state", True):
        next_req.ddt_recapture_account_state_opening = list(
            getattr(last_resp, "ddt_recapture_account_state_closing", None) or []
        )
        for s in next_req.ddt_recapture_account_state_opening or []:
            try:
                s.as_of_fiscal_year_start = next_start
            except Exception:
                # Best effort; keep as-is
                pass
        if next_req.ddt_recapture_account_state_opening:
            warnings.append(
                "Carried forward ddt_recapture_account_state_opening from prior-year response (Article 7.3 Deemed Distribution Tax Recapture Account state)."
            )
    else:
        if getattr(next_req, "ddt_recapture_account_state_opening", None):
            next_req.ddt_recapture_account_state_opening = []

    # Clear year-specific DDT recapture movements unless user wants to keep them.
    if getattr(opt, "clear_ddt_recapture_account_movements", True):
        if getattr(next_req, "ddt_recapture_account_movements", None):
            next_req.ddt_recapture_account_movements = []
            warnings.append(
                "Cleared ddt_recapture_account_movements for next Fiscal Year; provide new Article 7.3 movement lines if applicable."
            )

    
    # Clear year-specific after-year-end adjustments (Box 4.6) unless user wants to keep them.
    if getattr(opt, "clear_after_year_end_adjustments", True):
        if getattr(next_req, "after_year_end_adjustments", None):
            next_req.after_year_end_adjustments = []
            warnings.append("Cleared after_year_end_adjustments for next Fiscal Year; provide new Box 4.6 inputs if applicable.")

    # Clear year-specific transfer pricing adjustments (section 5.2 register) unless user wants to keep them.
    if getattr(opt, "clear_transfer_pricing_adjustments", True):
        if getattr(next_req, "transfer_pricing_adjustments", None):
            next_req.transfer_pricing_adjustments = []
            warnings.append("Cleared transfer_pricing_adjustments for next Fiscal Year; provide new section 5.2 TP register inputs if applicable.")

    # Clear year-specific PE allocation / PE simplification lines (v4 module 11)
    if getattr(opt, "clear_pe_allocation_lines", True):
        if getattr(next_req, "pe_allocation_lines", None):
            next_req.pe_allocation_lines = []
            warnings.append("Cleared pe_allocation_lines for next Fiscal Year; provide new PE allocation/PE simplification inputs if applicable.")




    # Clear year-specific allocable tax item register unless user wants to keep it.
    if getattr(opt, "clear_allocable_tax_items", True):
        if getattr(next_req, "allocable_tax_items", None):
            next_req.allocable_tax_items = []
            warnings.append("Cleared allocable_tax_items for next Fiscal Year; provide new OECD 4.3.2/5.1 register inputs if applicable.")

    # Clear year-specific flow-through allocation lines unless user wants to keep them.
    if getattr(opt, "clear_flow_through_entities", True):
        if getattr(next_req, "flow_through_entities", None):
            next_req.flow_through_entities = []
            warnings.append("Cleared flow_through_entities allocation lines for next Fiscal Year; provide new OECD section 5.1 allocation lines if applicable.")

    # ------------------------------------------------------------------
    # Prior-year status auto-builder (Box 7.2) (v4 module 9)
    # ------------------------------------------------------------------
    # This enables multi-year planner workflows to build the prior_years_status register automatically.
    # We derive rows from the last_response safe_harbour_applies flag:
    #   - If SH applies, record regime='SIMPLIFIED_ETR_SAFE_HARBOUR' and topup_tax_status='NONE'.
    #   - If SH does not apply, either skip (default) or record regime='FULL_GLOBE' with topup_tax_status='UNKNOWN'.
    if getattr(opt, "append_prior_year_status", True):
        fy_just_calculated = last_req.fiscal_year.start_date
        existing_keys: Set[tuple[str, date]] = {
            (row.tested_jurisdiction_id, row.fiscal_year_start) for row in (next_req.prior_years_status or [])
        }

        for r in (last_resp.results or []):
            tj_id = r.tested_jurisdiction_id
            key = (tj_id, fy_just_calculated)
            if key in existing_keys:
                warnings.append(
                    f"Prior-year status row already exists for Tested Jurisdiction '{tj_id}' FY {fy_just_calculated}; not appending."
                )
                continue

            sh_applies = bool(getattr(r, "safe_harbour_applies", False))

            if sh_applies:
                next_req.prior_years_status.append(
                    PriorYearStatusV2(
                        tested_jurisdiction_id=tj_id,
                        fiscal_year_start=fy_just_calculated,
                        regime="SIMPLIFIED_ETR_SAFE_HARBOUR",
                        topup_tax_status="NONE",
                        additional_current_topup_tax_for_prior_year=False,
                        specified_safe_harbour_name=None,
                        note=(
                            "AUTO: derived from prior-year /api/v2/calc result; treated as Simplified ETR Safe Harbour election made "
                            "(Box 7.2 history builder)."
                        ),
                    )
                )
                existing_keys.add(key)
                continue

            if getattr(opt, "append_prior_year_status_include_non_safe_harbour_years", False):
                next_req.prior_years_status.append(
                    PriorYearStatusV2(
                        tested_jurisdiction_id=tj_id,
                        fiscal_year_start=fy_just_calculated,
                        regime="FULL_GLOBE",
                        topup_tax_status="UNKNOWN",
                        additional_current_topup_tax_for_prior_year=False,
                        specified_safe_harbour_name=None,
                        note=(
                            "AUTO: safe_harbour_applies=false in prior-year calc; recorded as FULL_GLOBE with top-up tax UNKNOWN. "
                            "Review/update for Box 7.2."
                        ),
                    )
                )
                existing_keys.add(key)
                warnings.append(
                    f"Recorded prior-year status for '{tj_id}' FY {fy_just_calculated} as FULL_GLOBE/UNKNOWN (safe harbour did not apply). "
                    "Review before relying on Box 7.2."
                )
            else:
                warnings.append(
                    f"Skipped prior-year status row for '{tj_id}' FY {fy_just_calculated} because safe_harbour_applies=false. "
                    "Provide a PriorYearStatus row if needed for Box 7.2."
                )

    # FX placeholders / year-specific FX rows
    if opt.include_fx_placeholders:
        reporting = next_req.group_profile.reporting_currency if next_req.group_profile else None
        if reporting:
            required = _required_fx_currencies(next_req)

            # Ensure year-specific FX rows exist for next_start
            for cur in sorted(required):
                existing_next = _find_fx_rate(next_req.fx_rates, cur, next_start)
                if existing_next and existing_next.fiscal_year_start == next_start:
                    continue

                # Copy from last-year if available
                source = _find_fx_rate(last_req.fx_rates, cur, last_req.fiscal_year.start_date)
                if source is None:
                    # fall back to default
                    source = _find_fx_rate(last_req.fx_rates, cur, None)

                if source is not None:
                    next_req.fx_rates.append(
                        FxRateV2(
                            currency=cur,
                            avg_rate_to_reporting=source.avg_rate_to_reporting,
                            spot_rate_to_reporting=source.spot_rate_to_reporting,
                            fiscal_year_start=next_start,
                            note=(
                                f"AUTO: copied from FY {source.fiscal_year_start or 'default'}; review/update for planning."
                            ),
                        )
                    )
                    warnings.append(
                        f"FX rate for {cur} FY {next_start} auto-copied from prior rate; review/update before calculating."
                    )
                else:
                    next_req.fx_rates.append(
                        FxRateV2(
                            currency=cur,
                            avg_rate_to_reporting=1.0,
                            spot_rate_to_reporting=None,
                            fiscal_year_start=next_start,
                            note="AUTO: placeholder 1.0 (missing FX rate). Update before calculating.",
                        )
                    )
                    warnings.append(
                        f"Missing FX rate for {cur} FY {next_start}. Placeholder 1.0 inserted; update before calculating."
                    )

    # Re-validate the next request (ensures no duplicate FX rows, etc.)
    next_req = CalculationRequestV2.model_validate(next_req.model_dump())

    return ScenarioAdvanceYearResponseV2(next_request=next_req, warnings=warnings)
