import os
from datetime import date

import pytest

from app.services.calculator_v2 import calculate_v2
from app.services.models_v2 import (
    CalculationRequestV2,
    FiscalYearV2,
    TestedJurisdictionInputV2,
    TestedJurisdictionCompositionV2,
    JurisdictionFactsV2,
    StoredScenarioCreateRequestV2,
    StoredScenarioRunCreateRequestV2,
)
from app.services.storage_v2 import create_scenario, list_scenarios, create_run, get_scenario


def _minimal_request() -> CalculationRequestV2:
    tj = TestedJurisdictionInputV2(
        tested_jurisdiction_id="GB_MAIN",
        jurisdiction_code="GB",
        composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
        facts=JurisdictionFactsV2(
            jurisdiction_code="GB",
            jpbt=100.0,
            current_tax_expense=20.0,
            deferred_tax_expense=0.0,
        ),
    )
    return CalculationRequestV2(
        fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1), end_date=date(2027, 12, 31)),
        minimum_rate=0.15,
        tested_jurisdictions=[tj],
    )


def test_storage_tenant_isolation(tmp_path, monkeypatch):
    monkeypatch.setenv("DATA_DIR", str(tmp_path))
    # Ensure db is in tmp
    if "STORAGE_DB_PATH" in os.environ:
        monkeypatch.delenv("STORAGE_DB_PATH", raising=False)

    s1 = create_scenario("tenantA", StoredScenarioCreateRequestV2(label="A"))
    s2 = create_scenario("tenantB", StoredScenarioCreateRequestV2(label="B"))

    la = list_scenarios("tenantA")
    lb = list_scenarios("tenantB")

    assert {s.scenario_id for s in la.scenarios} == {s1.scenario_id}
    assert {s.scenario_id for s in lb.scenarios} == {s2.scenario_id}

    # TenantB cannot see TenantA scenario
    with pytest.raises(ValueError):
        get_scenario("tenantB", s1.scenario_id)


def test_storage_runs_roundtrip(tmp_path, monkeypatch):
    monkeypatch.setenv("DATA_DIR", str(tmp_path))
    if "STORAGE_DB_PATH" in os.environ:
        monkeypatch.delenv("STORAGE_DB_PATH", raising=False)

    scenario = create_scenario("tenantA", StoredScenarioCreateRequestV2(label="Run test"))
    req = _minimal_request()
    resp = calculate_v2(req)

    run = create_run(
        "tenantA",
        scenario.scenario_id,
        StoredScenarioRunCreateRequestV2(request=req, response=resp, note="first"),
    )

    assert run.scenario_id == scenario.scenario_id
    assert run.request.fiscal_year.start_date == req.fiscal_year.start_date
    assert len(run.response.results) == 1
