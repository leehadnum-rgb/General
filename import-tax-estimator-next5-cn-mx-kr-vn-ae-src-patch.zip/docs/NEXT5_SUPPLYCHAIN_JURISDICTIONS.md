# Next 5 jurisdictions for supply chains: CN, MX, KR, VN, AE

This patch adds **display + live tariff connector stubs** for:

- **CN** (China)
- **MX** (Mexico) – best-effort live scrape via **SIAVI**
- **KR** (South Korea)
- **VN** (Vietnam)
- **AE** (United Arab Emirates)

These are added as **new supported jurisdictions** for the supply-chain MVP so they can be used as nodes/destinations.

## What this patch does

1) Adds new API live connector modules:
- `src/api/lib/cn.ts`
- `src/api/lib/mx.ts`
- `src/api/lib/kr.ts`
- `src/api/lib/vn.ts`
- `src/api/lib/ae.ts`

2) Extends the supported jurisdiction registry:
- `src/api/lib/jurisdictions.ts`
- `src/api/lib/jurisdictionCatalog.ts`

## Important scope notes

- **MX** attempts to fetch duty (ad-valorem) from SIAVI HTML. If SIAVI is slow/unavailable or the HTML changes, the connector falls back to an env-configured default (or 0 with a warning).
- **CN/KR/VN** are placeholders for duty (flat env default or 0 with warning). VAT is computed from a configurable default rate.
- **AE** applies a configurable flat duty (default 5%) and VAT (default 5%), with warnings for likely excise categories.

This is intentionally an MVP to unblock multi-leg supply chain planning while you progressively add deeper upstream parsing.

---

## Render environment variables (recommended)

### Mexico (MX)
- `MX_SIAVI_TARIFF_URL_TEMPLATE` (default already in code)
  - Default: `https://siavi.economia.gob.mx/siavi5r/aranceles.php?fraccion={code}`
- `MX_HTTP_TIMEOUT_MS` (SIAVI can be slow)
  - Suggested: `60000` or `90000`
- `MX_CACHE_TTL_MS`
  - Suggested: `86400000` (24h)
- `MX_IVA_RATE_PCT`
  - Default: `16`
- Optional (MVP shortcut): `MX_PREFERENTIAL_ZERO_DUTY_ORIGINS`
  - Example: `US,CA`
  - Applies a 0% preferential duty measure if `originCountry` matches.
  - **Warning:** This ignores real rules-of-origin.
- Optional fallback: `MX_MFN_DUTY_RATE_PCT_DEFAULT`
  - Example: `10`

### China (CN)
- `CN_VAT_RATE_PCT` (default 13)
- Optional: `CN_MFN_DUTY_RATE_PCT_DEFAULT`

### South Korea (KR)
- `KR_VAT_RATE_PCT` (default 10)
- Optional: `KR_MFN_DUTY_RATE_PCT_DEFAULT`

### Vietnam (VN)
- `VN_VAT_RATE_PCT` (default 10)
- Optional: `VN_MFN_DUTY_RATE_PCT_DEFAULT`

### United Arab Emirates (AE)
- `AE_VAT_RATE_PCT` (default 5)
- `AE_DUTY_DEFAULT_RATE_PCT` (default 5)

---

## Wiring into /v1/requirements and /v1/estimate

Your app already has patterns for **LIVE** jurisdictions (e.g., GB/EU/HK/SG).

You must add **CN/MX/KR/VN/AE** to those same live branches, otherwise the routes will try the database and return `no_data_for_jurisdiction`.

### 1) requirements route

In `src/api/routes/requirements.ts`:

Add imports:

```ts
import { fetchCnLiveTariff } from "../lib/cn";
import { fetchMxLiveTariff } from "../lib/mx";
import { fetchKrLiveTariff } from "../lib/kr";
import { fetchVnLiveTariff } from "../lib/vn";
import { fetchAeLiveTariff } from "../lib/ae";
```

Then add live blocks (place them near your GB/EU live blocks, before the DB lookup):

```ts
if (requestedJurisdictionId === "CN") {
  const live = await fetchCnLiveTariff(code);
  // Return using the same LIVE response pattern you use for GB/EU/HK/SG.
}

if (requestedJurisdictionId === "MX") {
  const live = await fetchMxLiveTariff(code);
}

if (requestedJurisdictionId === "KR") {
  const live = await fetchKrLiveTariff(code);
}

if (requestedJurisdictionId === "VN") {
  const live = await fetchVnLiveTariff(code);
}

if (requestedJurisdictionId === "AE") {
  const live = await fetchAeLiveTariff(code);
}
```

**Implementation tip:** copy/paste your existing GB live branch and just swap the function call + jurisdiction metadata.

### 2) estimate route

In `src/api/routes/estimate.ts`:

Add imports:

```ts
import { fetchCnLiveTariff } from "../lib/cn";
import { fetchMxLiveTariff } from "../lib/mx";
import { fetchKrLiveTariff } from "../lib/kr";
import { fetchVnLiveTariff } from "../lib/vn";
import { fetchAeLiveTariff } from "../lib/ae";
```

Then add live estimate blocks (same structure you use for GB/EU):

- Fetch live tariff
- Validate currency
- Map measures into `calculateEstimate(...)`
- Provide `vatRule` and `vatBase`

---

## Anything UI impact

Once wired:
- `/v1/jurisdictions` will include CN/MX/KR/VN/AE
- Anything can offer them in destination dropdowns
- Supply-chain requirements/estimate endpoints will work for these nodes

