# Codex prompt: add CN/MX/KR/VN/AE (supply-chain destinations)

Paste the following into ChatGPT Codex (or your repo-updater) after unzipping this patch into the repo root.

---

**PROMPT START**

You are updating a TypeScript Fastify API for an import-tax + supply-chain MVP.

Goal: add 5 new jurisdictions **CN, MX, KR, VN, AE** end-to-end so:
- They appear in `/v1/jurisdictions`
- `/v1/requirements` works for them
- `/v1/estimate` works for them
- `/v1/supplychain/*` works automatically (it uses `/v1/requirements` + `/v1/estimate`)

This patch already added/updated:
- `src/api/lib/cn.ts`, `mx.ts`, `kr.ts`, `vn.ts`, `ae.ts`
- `src/api/lib/jurisdictions.ts` (adds them to SUPPORTED_JURISDICTIONS)
- `src/api/lib/jurisdictionCatalog.ts`

Now wire them into the existing API routes.

## A) Wire into `/v1/requirements`

Open `src/api/routes/requirements.ts`.

1) Add imports near other live connectors:
```ts
import { fetchCnLiveTariff } from "../lib/cn";
import { fetchMxLiveTariff } from "../lib/mx";
import { fetchKrLiveTariff } from "../lib/kr";
import { fetchVnLiveTariff } from "../lib/vn";
import { fetchAeLiveTariff } from "../lib/ae";
```

2) Find where live jurisdictions are handled (GB/EU/HK/SG/etc). Add five new live branches **before any DB lookup**.

For each of CN/MX/KR/VN/AE:
- call the corresponding `fetch*LiveTariff(code)` function
- build a LIVE requirements response in the same response schema you already use for GB/EU/HK/SG

Key requirements behavior (match existing patterns):
- Always include required input fields: `originCountry` (string, required) and `customsValue` (money, required)
- Use the same `collectAstFields()` logic over each supported duty AST to add required quantity fields (netMassKg, etc)
- If a duty expression is unsupported/manual, add it to `unsupported` and DO NOT include its required fields
- If `live.vatBaseAst` contains `freight_to_border` or `insurance_to_border`, add `freightToBorder` / `insuranceToBorder` to **recommended** inputs

Return the same envelope as other live jurisdictions:
- `dataVersionId: "LIVE"`
- `jurisdiction: { id, currency, vatLabel, vatRatePct }`
- `tariffLine: { code, description }`
- `inputs: { required: [...], recommended: [...] }`
- `unsupported: [...]`

## B) Wire into `/v1/estimate`

Open `src/api/routes/estimate.ts`.

1) Add imports:
```ts
import { fetchCnLiveTariff } from "../lib/cn";
import { fetchMxLiveTariff } from "../lib/mx";
import { fetchKrLiveTariff } from "../lib/kr";
import { fetchVnLiveTariff } from "../lib/vn";
import { fetchAeLiveTariff } from "../lib/ae";
```

2) Find where live jurisdictions are handled (GB/EU/HK/SG/etc). Add five new live branches **before DB lookup**.

For each of CN/MX/KR/VN/AE:
- call the `fetch*LiveTariff(code)`
- enforce currency guardrails: customsValue (and freight/insurance if provided) must match `live.currency` or return 400 `currency_mismatch`
- filter out unsupported/manual expressions the same way you do for GB/EU
- map `live.measures` into the `calculateEstimate(...)` input shape
- set `vatRule = { ratePct: live.vatRatePct, label: live.vatLabel }`
- set `vatBase = { ast: live.vatBaseAst }`
- respond with `dataVersionId: "LIVE"`, include `unsupported`, and `tariffLine.description`

## C) Sanity checks

- `npm run build` must pass.
- `/v1/jurisdictions` should now list CN, MX, KR, VN, AE.
- `/v1/requirements` and `/v1/estimate` should work for each of those jurisdictionIds.

Commit all changes.

**PROMPT END**

---
