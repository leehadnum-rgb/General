import { Expr } from "../../core/ast";

export type KrLiveMeasure = {
  measureId: string;
  measureType: "CUSTOMS_DUTY";
  originScope: "MFN" | "PREFERENTIAL" | "ALL";
  originCode: string;
  excludedOriginCodes?: string[] | null;
  expression: { expressionId: string; exprType: "AST" | "CUSTOM"; ast: Expr; sourceRef?: string | null; raw?: any };
};

export type KrLiveTariff = {
  code: string;
  description: string;
  currency: string;
  vatLabel: string;
  vatRatePct: number;
  vatBaseAst: Expr;
  measures: KrLiveMeasure[];
  unsupported: any[];
  sourceRef: string;
};

const VAT_BASE_AST: Expr = {
  op: "add",
  terms: [
    { op: "field", name: "customs_value" },
    { op: "field", name: "customs_duty_total" },
    { op: "field", name: "fees_total" },
    { op: "field", name: "freight_to_border" },
    { op: "field", name: "insurance_to_border" },
  ],
};

function normalizeCode(code: string): string {
  return String(code ?? "").replace(/[^0-9]/g, "");
}

function normalizeKrCode(codeInput: string): string {
  const d = normalizeCode(codeInput);
  if (!d) return "";
  // Korea often uses 10-digit HS codes; pad shorter codes.
  if (d.length > 0 && d.length < 10) return d.padEnd(10, "0");
  return d;
}

function krVatRatePct(): number {
  const raw = process.env.KR_VAT_RATE_PCT ?? process.env.KR_IMPORT_VAT_RATE_PCT;
  const n = raw != null && raw !== "" ? Number(raw) : 10;
  return Number.isFinite(n) ? n : 10;
}

function krDefaultDutyRatePct(): number | null {
  const raw = process.env.KR_MFN_DUTY_RATE_PCT_DEFAULT ?? process.env.KR_DUTY_DEFAULT_RATE_PCT;
  if (raw == null || raw === "") return null;
  const n = Number(raw);
  return Number.isFinite(n) ? n : null;
}

/**
 * South Korea / KR (MVP)
 *
 * Upstream duty integration (UniPass tariff rate table) is not yet implemented in this MVP.
 * Provide a flat duty rate via KR_MFN_DUTY_RATE_PCT_DEFAULT if you want non-zero duty.
 */
export async function fetchKrLiveTariff(codeInput: string): Promise<KrLiveTariff> {
  const currency = "KRW";
  const code = normalizeKrCode(codeInput);

  const unsupported: any[] = [];

  const dutyPct = krDefaultDutyRatePct();
  const effectiveDutyPct = dutyPct ?? 0;

  if (dutyPct == null) {
    unsupported.push({
      kind: "duty_placeholder",
      reason: "kr_upstream_not_integrated",
      message:
        "Korea duty rates are not integrated yet (UniPass tariff lookup pending). Assuming 0% duty (MVP placeholder). Configure KR_MFN_DUTY_RATE_PCT_DEFAULT to apply a flat ad-valorem duty rate.",
      sourceRef: "KR_RULES",
    });
  } else {
    unsupported.push({
      kind: "duty_flat_default",
      reason: "using_env_default",
      message: `Using KR_MFN_DUTY_RATE_PCT_DEFAULT=${dutyPct}% as a flat duty rate (MVP). Real duty varies by HS code and may include preferences.`,
      sourceRef: "KR_RULES",
    });
  }

  const measures: KrLiveMeasure[] = [
    {
      measureId: `kr:${code || "unknown"}:duty:mfn:${effectiveDutyPct}`,
      measureType: "CUSTOMS_DUTY",
      originScope: "MFN",
      originCode: "ALL",
      excludedOriginCodes: null,
      expression: {
        expressionId: `kr:${code || "unknown"}:expr:mfn:${effectiveDutyPct}`,
        exprType: "AST",
        ast: { op: "ad_valorem", rate_pct: effectiveDutyPct, base: "customs_value" },
        sourceRef: "KR_RULES",
        raw: `${effectiveDutyPct}%`,
      },
    },
  ];

  return {
    code: code || "",
    description: code ? `South Korea import (HS ${code})` : "South Korea import",
    currency,
    vatLabel: "VAT",
    vatRatePct: krVatRatePct(),
    vatBaseAst: VAT_BASE_AST,
    measures,
    unsupported,
    sourceRef: "KR_RULES",
  };
}
