import { Expr } from "../../core/ast";

export type AeLiveMeasure = {
  measureId: string;
  measureType: "CUSTOMS_DUTY";
  originScope: "MFN" | "PREFERENTIAL" | "ALL";
  originCode: string;
  excludedOriginCodes?: string[] | null;
  expression: { expressionId: string; exprType: "AST" | "CUSTOM"; ast: Expr; sourceRef?: string | null; raw?: any };
};

export type AeLiveTariff = {
  code: string;
  description: string;
  currency: string;
  vatLabel: string;
  vatRatePct: number;
  vatBaseAst: Expr;
  measures: AeLiveMeasure[];
  unsupported: any[];
  sourceRef: string;
};

const VAT_BASE_AST: Expr = {
  op: "add",
  terms: [
    { op: "field", name: "customs_value" },
    { op: "field", name: "customs_duty_total" },
    { op: "field", name: "fees_total" },
    { op: "field", name: "freight_to_border" },
    { op: "field", name: "insurance_to_border" },
  ],
};

function normalizeCode(code: string): string {
  return String(code ?? "").replace(/[^0-9]/g, "");
}

function vatRatePct(): number {
  const raw = process.env.AE_VAT_RATE_PCT ?? process.env.AE_VAT_PCT;
  const n = raw != null && raw !== "" ? Number(raw) : 5;
  return Number.isFinite(n) ? n : 5;
}

function defaultDutyPct(): number {
  const raw = process.env.AE_DUTY_DEFAULT_RATE_PCT ?? process.env.AE_DUTY_RATE_PCT;
  const n = raw != null && raw !== "" ? Number(raw) : 5;
  return Number.isFinite(n) ? n : 5;
}

function classifyPotentialExcise(codeDigits: string): { category: string; message: string } | null {
  // UAE can apply excise on certain goods (e.g., tobacco, energy drinks, carbonated drinks).
  // This MVP does not compute excise. We surface warnings for likely HS chapters.
  if (!codeDigits) return null;
  if (codeDigits.startsWith("24")) {
    return { category: "TOBACCO", message: "UAE excise and/or higher charges may apply to tobacco products (HS Chapter 24)." };
  }
  if (codeDigits.startsWith("22")) {
    return { category: "ALCOHOL_OR_BEVERAGES", message: "UAE excise/customs variations may apply to alcoholic beverages and some drinks (HS Chapter 22)." };
  }
  return null;
}

/**
 * UAE / AE (MVP)
 * - Duty: GCC Common Customs Tariff is often 5% for many goods (varies by HS).
 * - VAT: standard 5%.
 *
 * This implementation is intentionally conservative: it applies a configurable flat duty rate.
 * You can override the duty and VAT rates via env vars.
 */
export async function fetchAeLiveTariff(codeInput: string): Promise<AeLiveTariff> {
  const currency = "AED";
  const code = normalizeCode(codeInput);

  const unsupported: any[] = [];
  const excise = classifyPotentialExcise(code);
  if (excise) {
    unsupported.push({
      kind: "excise_unimplemented",
      category: excise.category,
      reason: "excise_not_implemented",
      message: excise.message,
      sourceRef: "AE_RULES",
    });
  }

  const dutyPct = defaultDutyPct();

  const measures: AeLiveMeasure[] = [
    {
      measureId: `ae:${code || "unknown"}:duty:mfn:${dutyPct}`,
      measureType: "CUSTOMS_DUTY",
      originScope: "MFN",
      originCode: "ALL",
      excludedOriginCodes: null,
      expression: {
        expressionId: `ae:${code || "unknown"}:expr:mfn:${dutyPct}`,
        exprType: "AST",
        ast: { op: "ad_valorem", rate_pct: dutyPct, base: "customs_value" },
        sourceRef: "AE_RULES",
        raw: `${dutyPct}%`,
      },
    },
  ];

  return {
    code: code || "",
    description: code ? `United Arab Emirates import (HS ${code})` : "United Arab Emirates import",
    currency,
    vatLabel: "VAT",
    vatRatePct: vatRatePct(),
    vatBaseAst: VAT_BASE_AST,
    measures,
    unsupported,
    sourceRef: "AE_RULES",
  };
}
