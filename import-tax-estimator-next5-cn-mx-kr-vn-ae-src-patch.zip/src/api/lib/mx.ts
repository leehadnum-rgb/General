import { Expr } from "../../core/ast";
import { parseRateToAst } from "../../ingest/lib/parseRateToAst";

export type MxLiveMeasure = {
  measureId: string;
  measureType: "CUSTOMS_DUTY";
  originScope: "MFN" | "PREFERENTIAL" | "ALL";
  originCode: string;
  excludedOriginCodes?: string[] | null;
  expression: { expressionId: string; exprType: "AST" | "CUSTOM"; ast: Expr; sourceRef?: string | null; raw?: any };
};

export type MxLiveTariff = {
  code: string;
  description: string;
  currency: string;
  vatLabel: string;
  vatRatePct: number;
  vatBaseAst: Expr;
  measures: MxLiveMeasure[];
  unsupported: any[];
  sourceRef: string;
};

const IVA_BASE_AST: Expr = {
  op: "add",
  terms: [
    { op: "field", name: "customs_value" },
    { op: "field", name: "customs_duty_total" },
    { op: "field", name: "fees_total" },
    { op: "field", name: "freight_to_border" },
    { op: "field", name: "insurance_to_border" },
  ],
};

function normalizeCode(code: string): string {
  return String(code ?? "").replace(/[^0-9]/g, "");
}

function normalizeMxFraction(codeInput: string): string {
  const d = normalizeCode(codeInput);
  if (!d) return "";
  // SIAVI examples commonly use 8-digit fracción arancelaria (without NICO).
  // If 10 digits are provided, we take the first 8 as best-effort.
  if (d.length >= 8) return d.slice(0, 8);
  return d.padEnd(8, "0");
}

function ivaRatePct(): number {
  const raw = process.env.MX_IVA_RATE_PCT ?? process.env.MX_VAT_RATE_PCT;
  const n = raw != null && raw !== "" ? Number(raw) : 16;
  return Number.isFinite(n) ? n : 16;
}

function defaultDutyRatePct(): number | null {
  const raw = process.env.MX_MFN_DUTY_RATE_PCT_DEFAULT ?? process.env.MX_DUTY_DEFAULT_RATE_PCT;
  if (raw == null || raw === "") return null;
  const n = Number(raw);
  return Number.isFinite(n) ? n : null;
}

function prefZeroDutyOrigins(): string[] {
  const raw = process.env.MX_PREFERENTIAL_ZERO_DUTY_ORIGINS ?? "";
  return raw
    .split(",")
    .map((s) => s.trim().toUpperCase())
    .filter((s) => /^[A-Z]{2}$/.test(s));
}

async function fetchText(url: string, timeoutMs: number): Promise<string> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      headers: {
        "user-agent": process.env.HTTP_USER_AGENT ?? "import-tax-estimator/1.0 (+https://render.com)",
        accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
    return await res.text();
  } finally {
    clearTimeout(t);
  }
}

function findPercentNear(labelRe: RegExp, html: string): number | null {
  const m = html.match(labelRe);
  if (!m || m.index == null) return null;
  const start = Math.max(0, m.index);
  const slice = html.slice(start, start + 1200);
  const pct = slice.match(/(\d+(?:\.\d+)?)\s*%/);
  if (!pct) return null;
  const n = Number(pct[1]);
  return Number.isFinite(n) ? n : null;
}

function extractDutyRatePctFromSiaviHtml(html: string): number | null {
  // SIAVI pages can be large and inconsistent. We do best-effort extraction.
  // Prefer matching near common Spanish labels.
  const candidates: Array<[RegExp, string]> = [
    [/\bArancel\b/i, "Arancel"],
    [/\bIGI\b/i, "IGI"],
    [/Ad[- ]?valorem/i, "Ad valorem"],
    [/\bTIGIE\b/i, "TIGIE"],
  ];

  for (const [re] of candidates) {
    const n = findPercentNear(re, html);
    if (n != null) return n;
  }

  // Fallback: first percent on the page.
  const pct = html.match(/(\d+(?:\.\d+)?)\s*%/);
  if (!pct) return null;
  const n = Number(pct[1]);
  return Number.isFinite(n) ? n : null;
}

function extractDescription(html: string): string | null {
  // Best-effort: look for "Descripción" label.
  const m = html.match(/Descripci[oó]n\s*:?\s*<[^>]*>\s*([^<]{3,200})</i);
  if (m && m[1]) return m[1].replace(/\s+/g, " ").trim();
  const m2 = html.match(/Descripci[oó]n\s*:?\s*([^<\n]{3,200})/i);
  if (m2 && m2[1]) return m2[1].replace(/\s+/g, " ").trim();
  return null;
}

type CacheEntry = { expiresAt: number; value: { dutyPct: number | null; description?: string | null; sourceRef: string } };
const cache = new Map<string, CacheEntry>();

async function lookupMxDutyPct(code8: string): Promise<{ dutyPct: number | null; description?: string | null; sourceRef: string }> {
  const template =
    process.env.MX_SIAVI_TARIFF_URL_TEMPLATE ??
    process.env.MX_TARIFF_URL_TEMPLATE ??
    "https://siavi.economia.gob.mx/siavi5r/aranceles.php?fraccion={code}";

  const url = template.replace("{code}", encodeURIComponent(code8));
  const timeoutMs = Number(process.env.MX_HTTP_TIMEOUT_MS ?? process.env.HTTP_TIMEOUT_MS ?? "60000");
  const ttlMs = Number(process.env.MX_CACHE_TTL_MS ?? "86400000");

  const key = `MX:${code8}`;
  const hit = cache.get(key);
  if (hit && hit.expiresAt > Date.now()) return hit.value;

  const html = await fetchText(url, timeoutMs);
  const dutyPct = extractDutyRatePctFromSiaviHtml(html);
  const desc = extractDescription(html);

  const value = { dutyPct, description: desc, sourceRef: url };
  cache.set(key, { expiresAt: Date.now() + ttlMs, value });
  return value;
}

/**
 * Mexico / MX (MVP)
 * - Duty: best-effort live scrape from SIAVI (fracción arancelaria).
 * - IVA: configurable (default 16%).
 *
 * Preferences:
 * - Optionally, you can set MX_PREFERENTIAL_ZERO_DUTY_ORIGINS=US,CA to apply 0% duty
 *   when the originCountry matches exactly. (Real-world eligibility depends on rules of origin.)
 */
export async function fetchMxLiveTariff(codeInput: string): Promise<MxLiveTariff> {
  const currency = "MXN";
  const code = normalizeMxFraction(codeInput);

  const unsupported: any[] = [];
  let dutyPct: number | null = null;
  let description: string | null = null;
  let sourceRef = "MX_RULES";

  if (code) {
    try {
      const live = await lookupMxDutyPct(code);
      dutyPct = live.dutyPct;
      description = live.description ?? null;
      sourceRef = live.sourceRef;
    } catch (e: any) {
      unsupported.push({
        kind: "mx_siavi_fetch_failed",
        reason: "upstream_unavailable",
        message: `Failed to fetch Mexico SIAVI tariff page for ${code}: ${String(e?.message ?? e)}`,
        sourceRef: "MX_SIAVI",
      });
    }
  }

  if (dutyPct == null) {
    const fallback = defaultDutyRatePct();
    if (fallback == null) {
      unsupported.push({
        kind: "duty_placeholder",
        reason: "no_parsed_duty_rate",
        message:
          "Mexico duty rate could not be parsed from SIAVI and no MX_MFN_DUTY_RATE_PCT_DEFAULT is configured. Assuming 0% duty (MVP placeholder).",
        sourceRef,
      });
      dutyPct = 0;
    } else {
      unsupported.push({
        kind: "duty_fallback",
        reason: "using_env_default",
        message: `Mexico duty rate could not be parsed from SIAVI; using MX_MFN_DUTY_RATE_PCT_DEFAULT=${fallback}% instead.`,
        sourceRef,
      });
      dutyPct = fallback;
    }
  }

  const measures: MxLiveMeasure[] = [];

  // MFN duty
  {
    const rawDuty = `${dutyPct}%`;
    const parsed = parseRateToAst(rawDuty, {
      defaultCurrency: currency,
      defaultMassField: "net_mass_kg",
      defaultCountField: "quantity",
      defaultVolumeField: "volume_litre",
    });

    if (!parsed.ok) {
      measures.push({
        measureId: `mx:${code || "unknown"}:duty:mfn`,
        measureType: "CUSTOMS_DUTY",
        originScope: "MFN",
        originCode: "ALL",
        excludedOriginCodes: null,
        expression: {
          expressionId: `mx:${code || "unknown"}:expr:mfn`,
          exprType: "CUSTOM",
          ast: { op: "manual_required", raw: rawDuty, reason: parsed.reason, message: parsed.message } as any,
          sourceRef,
          raw: rawDuty,
        },
      });
      unsupported.push({
        kind: "manual_or_unsupported_expression",
        measureId: `mx:${code || "unknown"}:duty:mfn`,
        raw: rawDuty,
        detail: parsed,
        sourceRef,
      });
    } else {
      measures.push({
        measureId: `mx:${code || "unknown"}:duty:mfn`,
        measureType: "CUSTOMS_DUTY",
        originScope: "MFN",
        originCode: "ALL",
        excludedOriginCodes: null,
        expression: {
          expressionId: `mx:${code || "unknown"}:expr:mfn`,
          exprType: "AST",
          ast: parsed.ast,
          sourceRef,
          raw: rawDuty,
        },
      });
    }
  }

  // Optional: 0% preferential measure for specific origins (MVP shortcut)
  for (const o of prefZeroDutyOrigins()) {
    measures.push({
      measureId: `mx:${code || "unknown"}:duty:pref0:${o}`,
      measureType: "CUSTOMS_DUTY",
      originScope: "PREFERENTIAL",
      originCode: o,
      excludedOriginCodes: null,
      expression: {
        expressionId: `mx:${code || "unknown"}:expr:pref0:${o}`,
        exprType: "AST",
        ast: { op: "ad_valorem", rate_pct: 0, base: "customs_value" },
        sourceRef: "MX_RULES",
        raw: "0%",
      },
    });
    unsupported.push({
      kind: "preference_assumption",
      reason: "rules_of_origin_not_modelled",
      message: `Applied 0% preferential duty for origin ${o} because MX_PREFERENTIAL_ZERO_DUTY_ORIGINS includes it. Real-world eligibility depends on rules of origin.` ,
      sourceRef: "MX_RULES",
    });
  }

  return {
    code: code || "",
    description: description || (code ? `Mexico import (HS ${code})` : "Mexico import"),
    currency,
    vatLabel: "IVA",
    vatRatePct: ivaRatePct(),
    vatBaseAst: IVA_BASE_AST,
    measures,
    unsupported,
    sourceRef,
  };
}
