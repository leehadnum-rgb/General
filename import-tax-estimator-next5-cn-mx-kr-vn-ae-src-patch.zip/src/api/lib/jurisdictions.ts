/**
 * Central registry of supported jurisdictions.
 *
 * Modes (current app):
 * - INGESTED: US/NZ/CH/NO/CA/AU/JP (and others) are ingested into Postgres by the cron job.
 * - LIVE: GB and EU member states (and some newer jurisdictions) are looked up / resolved live.
 * - ALIAS: LI is treated as an alias of CH (customs territory CHLI).
 */

export const EU_JURISDICTIONS = [
  "AT",
  "BE",
  "BG",
  "CY",
  "CZ",
  "DE",
  "DK",
  "EE",
  "ES",
  "FI",
  "FR",
  "GR",
  "HR",
  "HU",
  "IE",
  "IT",
  "LT",
  "LU",
  "LV",
  "MT",
  "NL",
  "PL",
  "PT",
  "RO",
  "SE",
  "SI",
  "SK",
] as const;

export const SUPPORTED_JURISDICTIONS = [
  // Americas
  "US",
  "CA",
  "MX",

  // Europe
  "GB",
  "CH",
  "LI",
  "NO",
  "IS",
  ...EU_JURISDICTIONS,

  // Asia-Pacific
  "CN",
  "NZ",
  "AU",
  "JP",
  "KR",
  "SG",
  "HK",
  "VN",

  // Middle East
  "AE",
] as const;

export type SupportedJurisdictionId = (typeof SUPPORTED_JURISDICTIONS)[number];

export function isEuJurisdiction(jurisdictionId: string): jurisdictionId is (typeof EU_JURISDICTIONS)[number] {
  return (EU_JURISDICTIONS as readonly string[]).includes(String(jurisdictionId ?? "").toUpperCase());
}
