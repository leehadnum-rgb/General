import { SUPPORTED_JURISDICTIONS, isEuJurisdiction } from "./jurisdictions";
import { jurisdictionToCustomsTerritoryId } from "./customsTerritories";

export type JurisdictionMode = "LIVE" | "INGESTED" | "ALIAS";

export type JurisdictionInfo = {
  jurisdictionId: string;
  name: string;
  currency: string;
  vatLabel: string;
  mode: JurisdictionMode;
  customsTerritoryId: string;
};

// NOTE: This is display metadata for UI (Anything graph builder).
// The calculation engine remains the source of truth; the UI should still call
// /v1/requirements and /v1/estimate for actual currency/rules.

const NAME_MAP: Record<string, string> = {
  // Americas
  US: "United States",
  CA: "Canada",
  MX: "Mexico",

  // Europe
  GB: "United Kingdom",
  CH: "Switzerland",
  LI: "Liechtenstein",
  NO: "Norway",
  IS: "Iceland",

  // Asia-Pacific
  CN: "China",
  NZ: "New Zealand",
  AU: "Australia",
  JP: "Japan",
  KR: "South Korea",
  SG: "Singapore",
  HK: "Hong Kong",
  VN: "Vietnam",

  // Middle East
  AE: "United Arab Emirates",

  // EU member states
  AT: "Austria",
  BE: "Belgium",
  BG: "Bulgaria",
  CY: "Cyprus",
  CZ: "Czechia",
  DE: "Germany",
  DK: "Denmark",
  EE: "Estonia",
  ES: "Spain",
  FI: "Finland",
  FR: "France",
  GR: "Greece",
  HR: "Croatia",
  HU: "Hungary",
  IE: "Ireland",
  IT: "Italy",
  LT: "Lithuania",
  LU: "Luxembourg",
  LV: "Latvia",
  MT: "Malta",
  NL: "Netherlands",
  PL: "Poland",
  PT: "Portugal",
  RO: "Romania",
  SE: "Sweden",
  SI: "Slovenia",
  SK: "Slovakia",
};

const CURRENCY_MAP: Record<string, string> = {
  // Americas
  US: "USD",
  CA: "CAD",
  MX: "MXN",

  // Europe
  GB: "GBP",
  CH: "CHF",
  LI: "CHF",
  NO: "NOK",
  IS: "ISK",

  // Asia-Pacific
  CN: "CNY",
  NZ: "NZD",
  AU: "AUD",
  JP: "JPY",
  KR: "KRW",
  SG: "SGD",
  HK: "HKD",
  VN: "VND",

  // Middle East
  AE: "AED",
};

function vatLabelFor(j: string): string {
  if (isEuJurisdiction(j)) return "VAT";
  if (j === "GB") return "VAT";
  if (j === "NZ" || j === "SG" || j === "AU" || j === "CA") return "GST";
  if (j === "JP") return "Consumption Tax";
  if (j === "MX") return "IVA";
  if (j === "US" || j === "HK") return "Tax";
  // Default
  return "VAT";
}

function modeFor(j: string): JurisdictionMode {
  if (
    j === "GB" ||
    j === "HK" ||
    j === "SG" ||
    j === "MX" ||
    j === "CN" ||
    j === "KR" ||
    j === "VN" ||
    j === "AE" ||
    isEuJurisdiction(j)
  ) {
    return "LIVE";
  }
  if (j === "LI") return "ALIAS";
  // Everything else currently in this tool is ingested.
  return "INGESTED";
}

export function listJurisdictions(): JurisdictionInfo[] {
  const ids = (SUPPORTED_JURISDICTIONS ?? []).map((x) => String(x).toUpperCase());
  const uniq = Array.from(new Set(ids)).sort();

  return uniq.map((id) => {
    const name = NAME_MAP[id] ?? id;
    const currency = isEuJurisdiction(id) ? "EUR" : (CURRENCY_MAP[id] ?? id);
    const vatLabel = vatLabelFor(id);
    const mode = modeFor(id);
    const customsTerritoryId = jurisdictionToCustomsTerritoryId(id);

    return { jurisdictionId: id, name, currency, vatLabel, mode, customsTerritoryId };
  });
}
