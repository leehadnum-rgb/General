import { Expr } from "../../core/ast";

export type CnLiveMeasure = {
  measureId: string;
  measureType: "CUSTOMS_DUTY";
  originScope: "MFN" | "PREFERENTIAL" | "ALL";
  originCode: string;
  excludedOriginCodes?: string[] | null;
  expression: { expressionId: string; exprType: "AST" | "CUSTOM"; ast: Expr; sourceRef?: string | null; raw?: any };
};

export type CnLiveTariff = {
  code: string;
  description: string;
  currency: string;
  vatLabel: string;
  vatRatePct: number;
  vatBaseAst: Expr;
  measures: CnLiveMeasure[];
  unsupported: any[];
  sourceRef: string;
};

const VAT_BASE_AST: Expr = {
  op: "add",
  terms: [
    { op: "field", name: "customs_value" },
    { op: "field", name: "customs_duty_total" },
    { op: "field", name: "fees_total" },
    { op: "field", name: "freight_to_border" },
    { op: "field", name: "insurance_to_border" },
  ],
};

function normalizeCode(code: string): string {
  return String(code ?? "").replace(/[^0-9]/g, "");
}

function normalizeCnCode(codeInput: string): string {
  const d = normalizeCode(codeInput);
  if (!d) return "";
  // China commonly uses 10-digit commodity codes; pad shorter codes with trailing zeros.
  if (d.length > 0 && d.length < 10) return d.padEnd(10, "0");
  return d;
}

function cnVatRatePct(): number {
  // Import VAT in China varies by goods category. This MVP uses a configurable default.
  const raw = process.env.CN_VAT_RATE_PCT ?? process.env.CN_IMPORT_VAT_RATE_PCT;
  const n = raw != null && raw !== "" ? Number(raw) : 13;
  return Number.isFinite(n) ? n : 13;
}

function cnDefaultDutyRatePct(): number | null {
  const raw = process.env.CN_MFN_DUTY_RATE_PCT_DEFAULT ?? process.env.CN_DUTY_DEFAULT_RATE_PCT;
  if (raw == null || raw === "") return null;
  const n = Number(raw);
  return Number.isFinite(n) ? n : null;
}

/**
 * China / CN (MVP)
 *
 * This connector is intentionally conservative:
 * - It does NOT yet integrate China's upstream tariff API (which requires robust scraping / anti-bot handling).
 * - It returns a configurable ad-valorem MFN duty rate if CN_MFN_DUTY_RATE_PCT_DEFAULT is provided.
 * - Otherwise it assumes 0% duty and flags a strong warning in `unsupported`.
 */
export async function fetchCnLiveTariff(codeInput: string): Promise<CnLiveTariff> {
  const currency = "CNY";
  const code = normalizeCnCode(codeInput);

  const unsupported: any[] = [];

  const dutyPct = cnDefaultDutyRatePct();
  const effectiveDutyPct = dutyPct ?? 0;

  if (dutyPct == null) {
    unsupported.push({
      kind: "duty_placeholder",
      reason: "cn_upstream_not_integrated",
      message:
        "China duty rates are not integrated yet (CN upstream tariff lookup pending). Assuming 0% duty (MVP placeholder). Configure CN_MFN_DUTY_RATE_PCT_DEFAULT to apply a flat ad-valorem duty rate.",
      sourceRef: "CN_RULES",
    });
  } else {
    unsupported.push({
      kind: "duty_flat_default",
      reason: "using_env_default",
      message: `Using CN_MFN_DUTY_RATE_PCT_DEFAULT=${dutyPct}% as a flat duty rate (MVP). Real duty varies by HS code and may have preferences/remedies.`,
      sourceRef: "CN_RULES",
    });
  }

  const measures: CnLiveMeasure[] = [
    {
      measureId: `cn:${code || "unknown"}:duty:mfn:${effectiveDutyPct}`,
      measureType: "CUSTOMS_DUTY",
      originScope: "MFN",
      originCode: "ALL",
      excludedOriginCodes: null,
      expression: {
        expressionId: `cn:${code || "unknown"}:expr:mfn:${effectiveDutyPct}`,
        exprType: "AST",
        ast: { op: "ad_valorem", rate_pct: effectiveDutyPct, base: "customs_value" },
        sourceRef: "CN_RULES",
        raw: `${effectiveDutyPct}%`,
      },
    },
  ];

  return {
    code: code || "",
    description: code ? `China import (HS ${code})` : "China import",
    currency,
    vatLabel: "VAT",
    vatRatePct: cnVatRatePct(),
    vatBaseAst: VAT_BASE_AST,
    measures,
    unsupported,
    sourceRef: "CN_RULES",
  };
}
