import { Expr } from "../../core/ast";

export type VnLiveMeasure = {
  measureId: string;
  measureType: "CUSTOMS_DUTY";
  originScope: "MFN" | "PREFERENTIAL" | "ALL";
  originCode: string;
  excludedOriginCodes?: string[] | null;
  expression: { expressionId: string; exprType: "AST" | "CUSTOM"; ast: Expr; sourceRef?: string | null; raw?: any };
};

export type VnLiveTariff = {
  code: string;
  description: string;
  currency: string;
  vatLabel: string;
  vatRatePct: number;
  vatBaseAst: Expr;
  measures: VnLiveMeasure[];
  unsupported: any[];
  sourceRef: string;
};

const VAT_BASE_AST: Expr = {
  op: "add",
  terms: [
    { op: "field", name: "customs_value" },
    { op: "field", name: "customs_duty_total" },
    { op: "field", name: "fees_total" },
    { op: "field", name: "freight_to_border" },
    { op: "field", name: "insurance_to_border" },
  ],
};

function normalizeCode(code: string): string {
  return String(code ?? "").replace(/[^0-9]/g, "");
}

function normalizeVnCode(codeInput: string): string {
  const d = normalizeCode(codeInput);
  if (!d) return "";
  // Vietnam commonly uses 8-digit tariff lines; pad shorter codes with zeros.
  if (d.length > 0 && d.length < 8) return d.padEnd(8, "0");
  return d;
}

function vnVatRatePct(): number {
  // Vietnam VAT depends on goods category (0/5/10). MVP uses a configurable default.
  const raw = process.env.VN_VAT_RATE_PCT ?? process.env.VN_IMPORT_VAT_RATE_PCT;
  const n = raw != null && raw !== "" ? Number(raw) : 10;
  return Number.isFinite(n) ? n : 10;
}

function vnDefaultDutyRatePct(): number | null {
  const raw = process.env.VN_MFN_DUTY_RATE_PCT_DEFAULT ?? process.env.VN_DUTY_DEFAULT_RATE_PCT;
  if (raw == null || raw === "") return null;
  const n = Number(raw);
  return Number.isFinite(n) ? n : null;
}

/**
 * Vietnam / VN (MVP)
 *
 * Upstream duty integration (Vietnam Customs tariff lookup) is not yet implemented.
 * Provide a flat duty rate via VN_MFN_DUTY_RATE_PCT_DEFAULT if you want non-zero duty.
 */
export async function fetchVnLiveTariff(codeInput: string): Promise<VnLiveTariff> {
  const currency = "VND";
  const code = normalizeVnCode(codeInput);

  const unsupported: any[] = [];

  const dutyPct = vnDefaultDutyRatePct();
  const effectiveDutyPct = dutyPct ?? 0;

  if (dutyPct == null) {
    unsupported.push({
      kind: "duty_placeholder",
      reason: "vn_upstream_not_integrated",
      message:
        "Vietnam duty rates are not integrated yet (VN Customs tariff lookup pending). Assuming 0% duty (MVP placeholder). Configure VN_MFN_DUTY_RATE_PCT_DEFAULT to apply a flat ad-valorem duty rate.",
      sourceRef: "VN_RULES",
    });
  } else {
    unsupported.push({
      kind: "duty_flat_default",
      reason: "using_env_default",
      message: `Using VN_MFN_DUTY_RATE_PCT_DEFAULT=${dutyPct}% as a flat duty rate (MVP). Real duty varies by HS code and may have special/preferential rates.`,
      sourceRef: "VN_RULES",
    });
  }

  const measures: VnLiveMeasure[] = [
    {
      measureId: `vn:${code || "unknown"}:duty:mfn:${effectiveDutyPct}`,
      measureType: "CUSTOMS_DUTY",
      originScope: "MFN",
      originCode: "ALL",
      excludedOriginCodes: null,
      expression: {
        expressionId: `vn:${code || "unknown"}:expr:mfn:${effectiveDutyPct}`,
        exprType: "AST",
        ast: { op: "ad_valorem", rate_pct: effectiveDutyPct, base: "customs_value" },
        sourceRef: "VN_RULES",
        raw: `${effectiveDutyPct}%`,
      },
    },
  ];

  return {
    code: code || "",
    description: code ? `Vietnam import (HS ${code})` : "Vietnam import",
    currency,
    vatLabel: "VAT",
    vatRatePct: vnVatRatePct(),
    vatBaseAst: VAT_BASE_AST,
    measures,
    unsupported,
    sourceRef: "VN_RULES",
  };
}
