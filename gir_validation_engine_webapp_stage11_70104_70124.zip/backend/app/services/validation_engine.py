from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha1
import re
from typing import Dict, List, Optional, Set, Tuple, Iterable
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP

from sqlalchemy.orm import Session

from app.db import models
from app.services.config_models import GIRConfig, Element, ErrorCode
from app.services.utils import try_parse_decimal, try_parse_date


@dataclass(frozen=True)
class Issue:
    severity: str  # BLOCKING/WARNING/INFO
    rule_id: str
    message: str
    how_to_fix: Optional[str] = None
    error_number: Optional[int] = None
    section: Optional[str] = None
    xml_path: Optional[str] = None
    filer_code: Optional[str] = None
    jurisdiction_code: Optional[str] = None
    entity_code: Optional[str] = None
    context_key: Optional[str] = None


def _rid(prefix: str, key: str) -> str:
    h = sha1(key.encode("utf-8")).hexdigest()[:10].upper()
    return f"{prefix}-{h}"


def _ancestors(xpath: str) -> List[str]:
    """Return all ancestor xpaths (excluding the xpath itself).

    Example: /a/b/c -> [/a/b, /a]
    """
    out: List[str] = []
    cur = xpath
    while "/" in cur:
        cur = cur.rsplit("/", 1)[0]
        if cur:
            out.append(cur)
        else:
            break
    return out



# -----------------------------
# Choice container overrides
# -----------------------------
#
# The extracted Excel config does not model XSD <choice> groups. In the OECD GIR
# schema, certain sibling containers (e.g., UPE/ExcludedUPE vs UPE/OtherUPE) are
# mutually exclusive. Without special handling, both branches appear 'required'
# and the engine produces false missing-required errors.
#
# Sprint 1.3: treat known choice-branches as optional 'gates'. Required leaf
# elements under these containers are only enforced when the branch is active
# (i.e., any datapoint exists beneath it).
CHOICE_CONTAINER_MIN_OCCURS_OVERRIDES: Dict[str, int] = {
    "/GLOBE_OECD/GLOBEBody/GeneralSection/CorporateStructure/UPE/ExcludedUPE": 0,
    "/GLOBE_OECD/GLOBEBody/GeneralSection/CorporateStructure/UPE/OtherUPE": 0,
}

def _build_container_index(config: GIRConfig) -> Dict[str, int]:
    """Map container xpath -> min_occurs.

    Includes:
    - container elements (complex types) from elements.json
    - section root containers from section_cardinality.json
    """
    containers: Dict[str, int] = {}
    for e in config.elements:
        if e.is_container and e.xpath:
            containers[e.xpath] = int(e.min_occurs or 0)
    for s in config.section_cardinality:
        if s.container_xpath:
            containers[s.container_xpath] = int(s.min_occurs or 0)
    # Apply choice overrides (see CHOICE_CONTAINER_MIN_OCCURS_OVERRIDES).
    for xp, mo in CHOICE_CONTAINER_MIN_OCCURS_OVERRIDES.items():
        containers[xp] = int(mo)

    return containers


def _deepest_optional_gate(leaf_xpath: str, containers_min_occurs: Dict[str, int]) -> Optional[str]:
    """Find the deepest optional container (minOccurs=0) in the leaf's ancestor chain.

    This is the container we use to gate requiredness to reduce false positives for
    optional blocks.
    """
    for anc in _ancestors(leaf_xpath):
        mo = containers_min_occurs.get(anc)
        if mo is None:
            continue
        if mo == 0:
            return anc
    return None


# -----------------------------
# Error code mapping helpers
# -----------------------------

def _error_by_number(config: GIRConfig) -> Dict[int, ErrorCode]:
    out: Dict[int, ErrorCode] = {}
    for ec in config.error_codes:
        if ec.number is None:
            continue
        out[int(ec.number)] = ec
    return out


def _oecd_fix_text(error_map: Dict[int, ErrorCode], number: int) -> Optional[str]:
    ec = error_map.get(number)
    if ec and ec.validation_description:
        return ec.validation_description
    return None



# -----------------------------
# Calculation helpers (Stage 4: 60025–60028)
# -----------------------------

_CALC_Q4 = Decimal("0.0001")
_CALC_MARGIN = Decimal("0.01")  # 1% relative margin


def _round4(x: Decimal) -> Decimal:
    """Round to 4 decimal places (OECD guidance for calc validations)."""
    return x.quantize(_CALC_Q4, rounding=ROUND_HALF_UP)


def _as_decimal(val: Optional[object]) -> Optional[Decimal]:
    if val is None:
        return None
    if isinstance(val, Decimal):
        return val
    try:
        return Decimal(str(val))
    except Exception:
        return None


def _dp_decimal(dp: models.DataPoint) -> Optional[Decimal]:
    """Best-effort decimal value from a datapoint."""
    if dp.value_numeric is not None:
        return _as_decimal(dp.value_numeric)
    v = (dp.value_raw or "").strip()
    if not v:
        return None
    return try_parse_decimal(v)


def _calc_equal(expected: Decimal, actual: Decimal) -> bool:
    """Return True if actual is within OECD tolerance rules.

    We apply:
      1) rounding to 4dp
      2) allow 1% relative margin (when expected != 0)
      3) when expected == 0, allow tiny absolute tolerance (4dp)
    """
    exp4 = _round4(expected)
    act4 = _round4(actual)
    if exp4 == act4:
        return True
    diff = abs(act4 - exp4)
    if exp4 == 0:
        return diff <= _CALC_Q4
    return diff <= abs(exp4) * _CALC_MARGIN


# -----------------------------
# Record type mapping helpers (DocSpec)
# -----------------------------
#
# Several OECD severe record errors refer to the DocTypeIndic of specific "record types"
# (FilingInfo, GeneralSection, Summary, JurisdictionSection, UTPRAttribution). Early
# versions of this engine used substring matching on xml_path, which can be brittle
# (eForm wrappers, variant roots, etc.). These helpers map record types explicitly
# using config-derived container xpaths and DocSpec/DocTypeIndic xpaths.

@dataclass(frozen=True)
class RecordTypeSpec:
    record_type: str
    section: str
    container_xpaths_lc: Set[str]
    doctypeindic_xpaths_lc: Set[str]


def _norm_xpath(xp: Optional[str]) -> str:
    """Normalize xpaths for robust matching across wrapper variants.

    The config extracted from the Excel/XSD toolkit sometimes includes an eForm wrapper
    segment like:
      /GLOBE_OECD/GLOBEBody/eForm/Payload/GLOBE_OECD/GLOBEBody/...

    while XML imports may produce:
      /GLOBE_OECD/GLOBEBody/...

    We collapse the wrapper segment when present.
    """
    if not xp:
        return ""
    x = xp.strip()
    x = x.replace(
        "/GLOBE_OECD/GLOBEBody/eForm/Payload/GLOBE_OECD/GLOBEBody",
        "/GLOBE_OECD/GLOBEBody",
    )
    x = x.replace(
        "/eForm/Payload/GLOBE_OECD/GLOBEBody",
        "/GLOBE_OECD/GLOBEBody",
    )
    x = re.sub(r"/{2,}", "/", x)
    return x


def _parse_bool(v: Optional[str]) -> Optional[bool]:
    """Parse common boolean lexical forms used in XML attributes.

    Returns:
      - True / False when parsing succeeds
      - None when value is missing or unrecognized
    """
    if v is None:
        return None
    s = str(v).strip().lower()
    if s == "":
        return None
    if s in {"1", "true", "t", "yes", "y"}:
        return True
    if s in {"0", "false", "f", "no", "n"}:
        return False
    return None



def _build_record_type_specs(config: GIRConfig) -> Dict[str, RecordTypeSpec]:
    """Build explicit record-type specifications from config.

    Returns a dict with keys:
      - FilingInfo
      - GeneralSection
      - Summary
      - JurisdictionSection
      - UTPRAttribution
    """
    containers_by_section: Dict[str, str] = {}
    for s in config.section_cardinality:
        if s.section and s.container_xpath:
            containers_by_section[s.section] = _norm_xpath(s.container_xpath).lower()

    doctype_by_section: Dict[str, Set[str]] = {}
    for e in config.elements:
        if not e.xpath:
            continue
        if (e.element_name or "").strip().lower() != "doctypeindic":
            continue
        sec = (e.section or "").strip()
        doctype_by_section.setdefault(sec, set()).add(_norm_xpath(e.xpath).lower())

    def _mk(record_type: str, section: str) -> RecordTypeSpec:
        cx = containers_by_section.get(section, "")
        dx = doctype_by_section.get(section, set())
        return RecordTypeSpec(
            record_type=record_type,
            section=section,
            container_xpaths_lc={cx} if cx else set(),
            doctypeindic_xpaths_lc=set(dx),
        )

    return {
        "FilingInfo": _mk("FilingInfo", "FilingInfo"),
        "GeneralSection": _mk("GeneralSection", "General"),
        "Summary": _mk("Summary", "Summary"),
        "JurisdictionSection": _mk("JurisdictionSection", "Jurisdiction"),
        "UTPRAttribution": _mk("UTPRAttribution", "UTPRAttribution"),
    }


def _filer_matches(dp_filer: Optional[str], filer: Optional[str]) -> bool:
    """Treat missing dp.filer_code as 'global' (matches any filer)."""
    if not filer:
        return True
    if not (dp_filer or "").strip():
        return True
    return dp_filer == filer


def _dp_xpath_lc(dp: models.DataPoint) -> str:
    return _norm_xpath(dp.xml_path).lower() if dp.xml_path else ""


def _record_present(dps: List[models.DataPoint], spec: RecordTypeSpec, filer: Optional[str]) -> bool:
    """Return True if any datapoint exists under the record container for the filer."""
    if not spec.container_xpaths_lc:
        return False
    for dp in dps:
        if not _filer_matches(dp.filer_code, filer):
            continue
        xp = _dp_xpath_lc(dp)
        for cx in spec.container_xpaths_lc:
            if cx and xp.startswith(cx):
                return True
    return False


def _record_doctype_dps(dps: List[models.DataPoint], spec: RecordTypeSpec, filer: Optional[str]) -> List[models.DataPoint]:
    """Return datapoints that correspond to DocSpec/DocTypeIndic for the record type."""
    if not spec.doctypeindic_xpaths_lc:
        return []
    out: List[models.DataPoint] = []
    for dp in dps:
        if not _filer_matches(dp.filer_code, filer):
            continue
        xp = _dp_xpath_lc(dp)
        if xp in spec.doctypeindic_xpaths_lc:
            out.append(dp)
    return out


# -----------------------------
# Scoping helpers
# -----------------------------

ScopeKind = str  # "filing" | "filer" | "jurisdiction" | "entity"


def _infer_scope(e: Element) -> ScopeKind:
    """Best-effort scope inference based on section and xpath.

    Sprint 1.2 goal: improve scoping so requiredness is not just "present somewhere".

    Principles:
    - Jurisdiction section is jurisdiction-scoped.
    - CE/ConstituentEntity/CEComputation blocks are entity-scoped.
    - FilingInfo is filer-scoped.
    - General/Summary/UTPRAttribution default to filer-scoped (but filing-level values
      satisfy all filers).
    """
    sec = (e.section or "").strip().lower()
    xp = (e.xpath or "").lower()

    if sec == "jurisdiction" or "jurisdictionsection" in xp:
        return "jurisdiction"

    # Entity-level constructs
    if any(tok in xp for tok in ["/cecomputation/", "/constituententity", "/corporatestructure/ce/", "nonmaterial"]):
        return "entity"

    if sec == "filinginfo" or "filingce" in xp:
        return "filer"

    if sec in {"general", "summary", "utprattribution"}:
        return "filer"

    return "filing"


def _build_presence_indexes(non_empty_dps: List[models.DataPoint]) -> dict:
    """Build sets for fast presence checks across scopes."""
    present_paths_global: Set[str] = set()
    present_by_filer: Set[Tuple[str, str]] = set()
    present_by_juris: Set[Tuple[str, str]] = set()
    present_by_entity: Set[Tuple[str, str]] = set()

    present_by_filer_juris: Set[Tuple[str, str, str]] = set()
    present_by_filer_entity: Set[Tuple[str, str, str]] = set()

    # Track "no-filer" subsets for jurisdiction/entity so filer-scoped checks can accept shared values.
    present_juris_no_filer: Set[Tuple[str, str]] = set()
    present_entity_no_filer: Set[Tuple[str, str]] = set()

    for dp in non_empty_dps:
        present_paths_global.add(dp.xml_path)

        if dp.filer_code:
            present_by_filer.add((dp.filer_code, dp.xml_path))

        if dp.jurisdiction_code:
            present_by_juris.add((dp.jurisdiction_code, dp.xml_path))
            if not dp.filer_code:
                present_juris_no_filer.add((dp.jurisdiction_code, dp.xml_path))

        if dp.entity_code:
            present_by_entity.add((dp.entity_code, dp.xml_path))
            if not dp.filer_code:
                present_entity_no_filer.add((dp.entity_code, dp.xml_path))

        if dp.filer_code and dp.jurisdiction_code:
            present_by_filer_juris.add((dp.filer_code, dp.jurisdiction_code, dp.xml_path))

        if dp.filer_code and dp.entity_code:
            present_by_filer_entity.add((dp.filer_code, dp.entity_code, dp.xml_path))

    return {
        "present_paths_global": present_paths_global,
        "present_by_filer": present_by_filer,
        "present_by_juris": present_by_juris,
        "present_by_entity": present_by_entity,
        "present_by_filer_juris": present_by_filer_juris,
        "present_by_filer_entity": present_by_filer_entity,
        "present_juris_no_filer": present_juris_no_filer,
        "present_entity_no_filer": present_entity_no_filer,
    }


def _build_activation_indexes(non_empty_dps: List[models.DataPoint], optional_containers: Set[str]) -> dict:
    """Build activation sets for optional blocks across scopes.

    A block is "active" for a scope if any non-empty datapoint exists under that container.
    """
    active_optional_global: Set[str] = set()
    active_optional_by_filer: Dict[str, Set[str]] = {}
    active_optional_by_juris: Dict[str, Set[str]] = {}
    active_optional_by_entity: Dict[str, Set[str]] = {}
    active_optional_by_filer_juris: Dict[Tuple[str, str], Set[str]] = {}
    active_optional_by_filer_entity: Dict[Tuple[str, str], Set[str]] = {}

    for dp in non_empty_dps:
        for anc in _ancestors(dp.xml_path):
            if anc not in optional_containers:
                continue
            active_optional_global.add(anc)
            if dp.filer_code:
                active_optional_by_filer.setdefault(dp.filer_code, set()).add(anc)
            if dp.jurisdiction_code:
                active_optional_by_juris.setdefault(dp.jurisdiction_code, set()).add(anc)
            if dp.entity_code:
                active_optional_by_entity.setdefault(dp.entity_code, set()).add(anc)
            if dp.filer_code and dp.jurisdiction_code:
                active_optional_by_filer_juris.setdefault((dp.filer_code, dp.jurisdiction_code), set()).add(anc)
            if dp.filer_code and dp.entity_code:
                active_optional_by_filer_entity.setdefault((dp.filer_code, dp.entity_code), set()).add(anc)

    return {
        "active_optional_global": active_optional_global,
        "active_optional_by_filer": active_optional_by_filer,
        "active_optional_by_juris": active_optional_by_juris,
        "active_optional_by_entity": active_optional_by_entity,
        "active_optional_by_filer_juris": active_optional_by_filer_juris,
        "active_optional_by_filer_entity": active_optional_by_filer_entity,
    }


def _is_gate_active(
    gate: Optional[str],
    *,
    filer: Optional[str],
    juris: Optional[str],
    entity: Optional[str],
    activation: dict,
    force_active: bool = False,
) -> bool:
    if gate is None:
        return True
    if force_active:
        return True

    if gate in activation["active_optional_global"]:
        return True

    if filer and gate in activation["active_optional_by_filer"].get(filer, set()):
        return True

    if juris and gate in activation["active_optional_by_juris"].get(juris, set()):
        return True

    if entity and gate in activation["active_optional_by_entity"].get(entity, set()):
        return True

    if filer and juris and gate in activation["active_optional_by_filer_juris"].get((filer, juris), set()):
        return True

    if filer and entity and gate in activation["active_optional_by_filer_entity"].get((filer, entity), set()):
        return True

    return False



# -----------------------------
# Register-driven datapoint bridge (Sprint 1.3)
# -----------------------------

DEFAULT_ID_RULES = "GIR201"
DEFAULT_GLOBE_STATUS = "GIR301"
DEFAULT_OWNERSHIP_TYPE = "GIR801"

def _dp_key(dp: models.DataPoint) -> Tuple[Optional[str], Optional[str], Optional[str], Optional[str], str]:
    return (dp.filer_code, dp.jurisdiction_code, dp.entity_code, dp.context_key, dp.xml_path)

def _make_virtual_dp(
    *,
    filing_id: str,
    xml_path: str,
    value_raw: str,
    filer_code: Optional[str] = None,
    jurisdiction_code: Optional[str] = None,
    entity_code: Optional[str] = None,
    context_key: Optional[str] = None,
    source_system: str = "register_bridge",
    notes: Optional[str] = None,
) -> models.DataPoint:
    now = datetime.utcnow()
    dp = models.DataPoint(
        filing_id=filing_id,
        filer_code=filer_code,
        jurisdiction_code=jurisdiction_code,
        entity_code=entity_code,
        context_key=context_key,
        xml_path=xml_path,
        value_raw=value_raw,
        source="derived",
        source_system=source_system,
        notes=notes,
        updated_at=now,
        created_at=now,
    )
    dp.value_numeric = try_parse_decimal(value_raw)
    dp.value_date = try_parse_date(value_raw)
    return dp

def _find_xpath(
    config: GIRConfig,
    *,
    section: Optional[str] = None,
    endswith: Optional[str] = None,
    contains: Optional[str] = None,
) -> Optional[str]:
    for e in config.elements:
        if section and (e.section or "") != section:
            continue
        xp = (e.xpath or "").strip()
        if not xp:
            continue
        if endswith and not xp.endswith(endswith):
            continue
        if contains and contains not in xp:
            continue
        return xp
    return None

def _gen_docrefid(prefix: str, filing_id: str, scope_key: str) -> str:
    r"""Generate a schema-friendly DocRefId.

    OECD severe record error **60011** expects a high-level format:
      [CountryCode][ReportingYear][UniqueID]

    For this web tool we generate a deterministic value that:
      - stays within the XSD 200 char max
      - matches the expected high-level pattern
      - is stable for a given (prefix, filing_id, scope_key)

    The `prefix` parameter is overloaded:
      - If prefix matches /^[A-Z]{2}\\d{4}$/ then we treat it as CCYYYY
      - Otherwise we fall back to CC=XX and YYYY=1900

    Callers that *know* the CCYYYY should pass it via prefix.
    """
    key = f"{prefix}|{filing_id}|{scope_key}"
    h = sha1(key.encode("utf-8")).hexdigest()[:20].upper()

    cc = "XX"
    yyyy = "1900"
    if re.match(r"^[A-Z]{2}\d{4}$", (prefix or "")):
        cc = prefix[:2]
        yyyy = prefix[2:6]

    docref = f"{cc}{yyyy}{h}"
    return docref[:200]

def _map_filing_ce_role(filer: models.Filer) -> Optional[str]:
    # Prefer explicit GIR code if provided.
    if (filer.filing_ce_role or "").strip():
        return filer.filing_ce_role.strip()
    r = (filer.role or "").strip().upper()
    if r == "UPE":
        return "GIR401"
    if "DESIGNATED" in r:
        return "GIR402"
    if "LOCAL" in r:
        return "GIR403"
    if r in {"POPE", "CE", "CONSTITUENT"}:
        return "GIR404"
    if r:
        return "GIR405"
    return None

def _register_hint_for_xpath(xpath: str) -> Optional[str]:
    xp = xpath or ""
    # Filing register
    if xp.endswith("/FilingCE/Name"):
        return "Populate legal_name in the Filing Entity Register."
    if xp.endswith("/FilingCE/TIN"):
        return "Populate tin in the Filing Entity Register (or use NOTIN if applicable)."
    if xp.endswith("/FilingCE/Role"):
        return "Populate filing_ce_role (preferred) or role in the Filing Entity Register."
    if xp.endswith("/FilingInfo/Period/Start"):
        return "Populate period_start on the Filing record (or submit a datapoint for Period/Start)."
    if xp.endswith("/FilingInfo/Period/End"):
        return "Populate period_end on the Filing record (or submit a datapoint for Period/End)."
    if xp.endswith("/FilingInfo/AccountingInfo/Currency"):
        return "Populate reporting_currency on the Filing record (or submit a datapoint for AccountingInfo/Currency)."
    if xp.endswith("/DocSpec/DocTypeIndic") or xp.endswith("/DocSpec/DocRefId"):
        return "DocSpec values are auto-generated by the engine unless you override them via datapoints."

    # Constituent entity register
    if "/CorporateStructure/CE/ID/Name" in xp:
        return "Populate legal_name in the Constituent Entity Register for this entity."
    if "/CorporateStructure/CE/ID/ResCountryCode" in xp:
        return "Populate jurisdiction_code in the Constituent Entity Register for this entity."
    if "/CorporateStructure/CE/ID/TIN" in xp:
        return "Populate tin in the Constituent Entity Register for this entity (or use NOTIN if applicable)."
    if "/CorporateStructure/CE/ID/Rules" in xp:
        return "Populate id_rules in the Constituent Entity Register for this entity."
    if "/CorporateStructure/CE/ID/GlobeStatus" in xp:
        return "Populate globe_status in the Constituent Entity Register for this entity."
    if "/CorporateStructure/CE/Ownership/OwnershipType" in xp:
        return "Populate ownership_type (GIR801..GIR806) in the Constituent Entity Register for this entity."
    if "/CorporateStructure/CE/Ownership/OwnershipPercentage" in xp:
        return "Populate ownership_percentage in the Constituent Entity Register for this entity."
    if "/CorporateStructure/CE/Ownership/TIN" in xp:
        return "Provide owner_tin_override, or set parent_entity_code (with a TIN present on the parent), so the engine can derive the ownership holder TIN."

    # Jurisdiction register
    if xp.endswith("/JurisdictionSection/Jurisdiction"):
        return "Ensure this jurisdiction is present in the Jurisdiction Register."
    if xp.endswith("/JurisdictionSection/LocalCurrency"):
        return "Populate local_currency in the Jurisdiction Register (if required for your facts)."
    if xp.endswith("/JurisdictionSection/RecJurCode"):
        return "Populate the receiving jurisdiction(s). By default the engine uses the responsible filer's jurisdiction_code."

    return None

def derive_virtual_datapoints_from_registers(
    *,
    db: Session,
    filing: models.Filing,
    config: GIRConfig,
    filers: List[models.Filer],
    jurisdictions: List[models.Jurisdiction],
    entities: List[models.ConstituentEntity],
    existing_datapoints: List[models.DataPoint],
    suppress_if_exists: bool = True,
) -> List[models.DataPoint]:
    """Create non-persisted datapoints from registers (and filing header fields).

    These derived datapoints are used for validation scope/presence checks, so the
    engine can be 'register driven' rather than requiring users to manually
    populate datapoints for obvious header / identity fields.

    The rule is: *never override an explicit datapoint* (same key).
    """
    # Keys already explicitly provided by the user (persisted datapoints).
    # By default we suppress derived datapoints that would collide with these keys.
    occupied_keys: Set[Tuple[Optional[str], Optional[str], Optional[str], Optional[str], str]] = (
        {_dp_key(dp) for dp in existing_datapoints} if suppress_if_exists else set()
    )

    # Avoid duplicates in the derived output itself.
    seen_keys: Set[Tuple[Optional[str], Optional[str], Optional[str], Optional[str], str]] = set()

    out: List[models.DataPoint] = []

    def add(
        *,
        xml_path: Optional[str],
        value: Optional[str],
        filer_code: Optional[str] = None,
        jurisdiction_code: Optional[str] = None,
        entity_code: Optional[str] = None,
        context_key: Optional[str] = None,
        origin: Optional[str] = None,
    ):
        if not xml_path:
            return
        v = (value or "").strip()
        if v == "":
            return
        dp = _make_virtual_dp(
            filing_id=filing.id,
            xml_path=xml_path,
            value_raw=v,
            filer_code=filer_code,
            jurisdiction_code=jurisdiction_code,
            entity_code=entity_code,
            context_key=context_key,
            notes=origin,
        )
        k = _dp_key(dp)
        if k in occupied_keys:
            return
        if k in seen_keys:
            return
        seen_keys.add(k)
        out.append(dp)

    # --- XPaths (config driven) ---
    xp_filingce_name = _find_xpath(config, section="FilingInfo", endswith="/FilingCE/Name")
    xp_filingce_tin = _find_xpath(config, section="FilingInfo", endswith="/FilingCE/TIN")
    xp_filingce_role = _find_xpath(config, section="FilingInfo", endswith="/FilingCE/Role")

    xp_filing_period_start = _find_xpath(config, section="FilingInfo", endswith="/FilingInfo/Period/Start")
    xp_filing_period_end = _find_xpath(config, section="FilingInfo", endswith="/FilingInfo/Period/End")
    xp_filing_currency = _find_xpath(config, section="FilingInfo", endswith="/FilingInfo/AccountingInfo/Currency")

    xp_filing_doc_type = _find_xpath(config, section="FilingInfo", endswith="/DocSpec/DocTypeIndic")
    xp_filing_doc_ref = _find_xpath(config, section="FilingInfo", endswith="/DocSpec/DocRefId")

    xp_summary_recjur = _find_xpath(config, section="Summary", endswith="/Summary/RecJurCode")
    xp_summary_doc_type = _find_xpath(config, section="Summary", endswith="/Summary/DocSpec/DocTypeIndic")
    xp_summary_doc_ref = _find_xpath(config, section="Summary", endswith="/Summary/DocSpec/DocRefId")

    xp_general_recjur = _find_xpath(config, section="General", endswith="/GeneralSection/RecJurCode")

    xp_juris = _find_xpath(config, section="Jurisdiction", endswith="/JurisdictionSection/Jurisdiction")
    xp_juris_recjur = _find_xpath(config, section="Jurisdiction", endswith="/JurisdictionSection/RecJurCode")
    xp_juris_local_cur = _find_xpath(config, section="Jurisdiction", endswith="/JurisdictionSection/LocalCurrency")
    xp_juris_doc_type = _find_xpath(config, section="Jurisdiction", endswith="/JurisdictionSection/DocSpec/DocTypeIndic")
    xp_juris_doc_ref = _find_xpath(config, section="Jurisdiction", endswith="/JurisdictionSection/DocSpec/DocRefId")

    # CorporateStructure (UPE branch - OtherUPE)
    xp_upe_name = _find_xpath(config, section="General", contains="/CorporateStructure/UPE/OtherUPE/ID/Name")
    xp_upe_res = _find_xpath(config, section="General", contains="/CorporateStructure/UPE/OtherUPE/ID/ResCountryCode")
    xp_upe_tin = _find_xpath(config, section="General", contains="/CorporateStructure/UPE/OtherUPE/ID/TIN")
    xp_upe_rules = _find_xpath(config, section="General", contains="/CorporateStructure/UPE/OtherUPE/ID/Rules")
    xp_upe_status = _find_xpath(config, section="General", contains="/CorporateStructure/UPE/OtherUPE/ID/GlobeStatus")

    # CorporateStructure (CE)
    xp_ce_name = _find_xpath(config, section="General", contains="/CorporateStructure/CE/ID/Name")
    xp_ce_res = _find_xpath(config, section="General", contains="/CorporateStructure/CE/ID/ResCountryCode")
    xp_ce_tin = _find_xpath(config, section="General", contains="/CorporateStructure/CE/ID/TIN")
    xp_ce_rules = _find_xpath(config, section="General", contains="/CorporateStructure/CE/ID/Rules")
    xp_ce_status = _find_xpath(config, section="General", contains="/CorporateStructure/CE/ID/GlobeStatus")

    xp_own_type = _find_xpath(config, section="General", contains="/CorporateStructure/CE/Ownership/OwnershipType")
    xp_own_tin = _find_xpath(config, section="General", contains="/CorporateStructure/CE/Ownership/TIN")
    xp_own_pct = _find_xpath(config, section="General", contains="/CorporateStructure/CE/Ownership/OwnershipPercentage")

    # --- Filing header datapoints (global; satisfy all filers) ---
    add(xml_path=xp_filing_period_start, value=filing.period_start.isoformat() if filing.period_start else None, origin="filing.period_start")
    add(xml_path=xp_filing_period_end, value=filing.period_end.isoformat() if filing.period_end else None, origin="filing.period_end")
    add(xml_path=xp_filing_currency, value=filing.reporting_currency, origin="filing.reporting_currency")

    # --- Best-effort CCYYYY prefix for DocRefId generation ---
    # Prefer the UPE jurisdiction, then any filer jurisdiction, then infer from TIN.
    def _best_effort_ccyyyy() -> str:
        # 1) UPE filer jurisdiction
        upe = next((f for f in filers if (f.role or "").strip().upper() == "UPE" and (f.jurisdiction_code or "").strip()), None)
        if upe and (upe.jurisdiction_code or "").strip():
            cc = upe.jurisdiction_code.strip().upper()[:2]
        else:
            # 2) any filer jurisdiction
            any_f = next((f for f in filers if (f.jurisdiction_code or "").strip()), None)
            if any_f and (any_f.jurisdiction_code or "").strip():
                cc = any_f.jurisdiction_code.strip().upper()[:2]
            else:
                # 3) infer from TIN prefix (e.g. "US-...")
                tin = (filers[0].tin or "").strip() if filers else ""
                cc = (tin[:2].upper() if len(tin) >= 2 and tin[:2].isalpha() else "XX")

        year = (filing.period_end.year if filing.period_end else datetime.utcnow().year)
        return f"{cc}{year:04d}"

    ccyyyy = _best_effort_ccyyyy()

    # --- FilingInfo per filer ---
    for f in filers:
        fc = (f.filer_code or "").strip()
        if not fc:
            continue
        add(xml_path=xp_filingce_name, value=f.legal_name, filer_code=fc, origin="filer.legal_name")
        add(xml_path=xp_filingce_tin, value=f.tin, filer_code=fc, origin="filer.tin")
        add(xml_path=xp_filingce_role, value=_map_filing_ce_role(f), filer_code=fc, origin="filer.filing_ce_role_or_role_map")

        # DocSpec (auto-generated) for FilingInfo
        # Default to OECD1 (new record) for self-serve validation.
        add(xml_path=xp_filing_doc_type, value="OECD1", filer_code=fc, origin="auto_generated:filinginfo.docspec.doctype")
        add(xml_path=xp_filing_doc_ref, value=_gen_docrefid(ccyyyy, filing.id, f"FILINFO:{fc}"), filer_code=fc, origin="auto_generated:filinginfo.docspec.docrefid")

    # --- Summary (global) ---
    add(xml_path=xp_summary_doc_type, value="OECD1", origin="auto_generated:summary.docspec.doctype")
    add(xml_path=xp_summary_doc_ref, value=_gen_docrefid(ccyyyy, filing.id, "SUMMARY:GLOBAL"), origin="auto_generated:summary.docspec.docrefid")

    # --- Receiving jurisdiction codes (global, repeatable) ---
    juris_codes = sorted({(j.jurisdiction_code or "").strip().upper() for j in jurisdictions if (j.jurisdiction_code or "").strip()})
    for code in juris_codes:
        add(xml_path=xp_general_recjur, value=code, context_key=f"GEN_RECJUR:{code}", origin="jurisdiction_register.jurisdiction_code")
        add(xml_path=xp_summary_recjur, value=code, context_key=f"SUM_RECJUR:{code}", origin="jurisdiction_register.jurisdiction_code")

    # --- JurisdictionSection (per jurisdiction) ---
    filers_by_code: Dict[str, models.Filer] = {f.filer_code: f for f in filers if f.filer_code}
    for j in jurisdictions:
        jc = (j.jurisdiction_code or "").strip().upper()
        if not jc:
            continue
        responsible = (j.responsible_filer_code or "").strip() or None
        responsible_filer = filers_by_code.get(responsible) if responsible else None
        rec = (responsible_filer.jurisdiction_code or "").strip().upper() if responsible_filer else None
        add(xml_path=xp_juris, value=jc, jurisdiction_code=jc, filer_code=responsible, origin="jurisdiction_register.jurisdiction_code")
        add(xml_path=xp_juris_recjur, value=rec or jc, jurisdiction_code=jc, filer_code=responsible, origin="jurisdiction_register.responsible_filer_or_jurisdiction")
        add(xml_path=xp_juris_local_cur, value=j.local_currency, jurisdiction_code=jc, filer_code=responsible, origin="jurisdiction_register.local_currency")
        add(xml_path=xp_juris_doc_type, value="OECD1", jurisdiction_code=jc, filer_code=responsible, origin="auto_generated:jurisdiction.docspec.doctype")
        add(xml_path=xp_juris_doc_ref, value=_gen_docrefid(ccyyyy, filing.id, f"JUR:{jc}:{responsible or 'GLOBAL'}"), jurisdiction_code=jc, filer_code=responsible, origin="auto_generated:jurisdiction.docspec.docrefid")

    # --- CorporateStructure: UPE ---
    upe_filers = [f for f in filers if (f.role or "").strip().upper() == "UPE"]
    for upe in upe_filers:
        u_code = (upe.filer_code or "").strip() or "UPE"
        ctx = f"UPE:{u_code}"
        add(xml_path=xp_upe_name, value=upe.legal_name, context_key=ctx, origin="filer_register(role=UPE).legal_name")
        add(xml_path=xp_upe_res, value=upe.jurisdiction_code, context_key=ctx, origin="filer_register(role=UPE).jurisdiction_code")
        add(xml_path=xp_upe_tin, value=upe.tin, context_key=ctx, origin="filer_register(role=UPE).tin")
        add(xml_path=xp_upe_rules, value=(upe.id_rules or DEFAULT_ID_RULES), context_key=ctx, origin="filer_register(role=UPE).id_rules_or_default")
        add(xml_path=xp_upe_status, value=(upe.globe_status or DEFAULT_GLOBE_STATUS), context_key=ctx, origin="filer_register(role=UPE).globe_status_or_default")

    # --- CorporateStructure: Constituent entities (included) ---
    entities_by_code: Dict[str, models.ConstituentEntity] = {e.entity_code: e for e in entities if e.entity_code}
    upe_tin = (upe_filers[0].tin or "").strip() if upe_filers else None

    def owner_tin(ent: models.ConstituentEntity) -> Tuple[Optional[str], str]:
        """Return (owner_tin_value, origin_string)."""
        if (ent.owner_tin_override or "").strip():
            return ent.owner_tin_override.strip(), "entity_register.owner_tin_override"
        p = (ent.parent_entity_code or "").strip()
        if p and p in entities_by_code and (entities_by_code[p].tin or "").strip():
            return entities_by_code[p].tin.strip(), f"entity_register.parent_entity_code({p}).tin"
        fb = (ent.filed_by_filer_code or "").strip()
        if fb and fb in filers_by_code and (filers_by_code[fb].tin or "").strip():
            return filers_by_code[fb].tin.strip(), f"filer_register({fb}).tin"
        if upe_tin and upe_tin.strip():
            return upe_tin.strip(), "filer_register(role=UPE).tin"
        return None, "unresolved"

    for ent in entities:
        if not ent.included_in_gir:
            continue
        ec = (ent.entity_code or "").strip()
        if not ec:
            continue
        ctx = f"CE:{ec}"
        fc = (ent.filed_by_filer_code or "").strip() or None
        add(xml_path=xp_ce_name, value=ent.legal_name, entity_code=ec, filer_code=fc, context_key=ctx, origin="entity_register.legal_name")
        add(xml_path=xp_ce_res, value=ent.jurisdiction_code, entity_code=ec, filer_code=fc, context_key=ctx, origin="entity_register.jurisdiction_code")
        add(xml_path=xp_ce_tin, value=ent.tin, entity_code=ec, filer_code=fc, context_key=ctx, origin="entity_register.tin")
        add(xml_path=xp_ce_rules, value=(ent.id_rules or DEFAULT_ID_RULES), entity_code=ec, filer_code=fc, context_key=ctx, origin="entity_register.id_rules_or_default")
        add(xml_path=xp_ce_status, value=(ent.globe_status or DEFAULT_GLOBE_STATUS), entity_code=ec, filer_code=fc, context_key=ctx, origin="entity_register.globe_status_or_default")

        add(xml_path=xp_own_type, value=(ent.ownership_type or DEFAULT_OWNERSHIP_TYPE), entity_code=ec, filer_code=fc, context_key=ctx, origin="entity_register.ownership_type_or_default")
        own_tin_val, own_tin_origin = owner_tin(ent)
        add(xml_path=xp_own_tin, value=own_tin_val, entity_code=ec, filer_code=fc, context_key=ctx, origin=own_tin_origin)
        add(
            xml_path=xp_own_pct,
            value=str(ent.ownership_percentage) if ent.ownership_percentage is not None else None,
            entity_code=ec,
            filer_code=fc,
            context_key=ctx,
            origin="entity_register.ownership_percentage",
        )

    return out

def run_validations(
    db: Session,
    filing_id: str,
    config: GIRConfig,
    *,
    attribute_requiredness_mode: str = "auto",
) -> List[Issue]:
    # Load filing + registers + datapoints.
    filing = db.get(models.Filing, filing_id)
    if filing is None:
        # Should be prevented by the API layer, but keep validation_engine robust.
        return [Issue(
            severity="BLOCKING",
            rule_id=_rid("SYS", f"missing_filing|{filing_id}"),
            section="General",
            message="Filing not found.",
            how_to_fix="Create the filing first, then retry validation.",
        )]

    dps: List[models.DataPoint] = (
        db.query(models.DataPoint)
        .filter(models.DataPoint.filing_id == filing_id)
        .all()
    )

    filers: List[models.Filer] = (
        db.query(models.Filer).filter(models.Filer.filing_id == filing_id).all()
    )
    juris_rows: List[models.Jurisdiction] = (
        db.query(models.Jurisdiction).filter(models.Jurisdiction.filing_id == filing_id).all()
    )
    entity_rows: List[models.ConstituentEntity] = (
        db.query(models.ConstituentEntity).filter(models.ConstituentEntity.filing_id == filing_id).all()
    )

    # Sprint 1.3: derive datapoints from registers so validations can be register-driven.
    virtual_dps = derive_virtual_datapoints_from_registers(
        db=db,
        filing=filing,
        config=config,
        filers=filers,
        jurisdictions=juris_rows,
        entities=entity_rows,
        existing_datapoints=dps,
    )
    all_dps: List[models.DataPoint] = list(dps) + list(virtual_dps)
    # "Submission view" datapoints: excludes engine-derived helper datapoints.
    # Many OECD severe record errors are defined against the submitted XML.
    submission_dps: List[models.DataPoint] = [dp for dp in all_dps if (dp.source or "").lower() != "derived"]

    # Build element lookup for type / allowed values checks.
    elements_by_path: Dict[str, Element] = {e.xpath: e for e in config.elements if e.xpath}

    non_empty_dps: List[models.DataPoint] = [dp for dp in all_dps if (dp.value_raw or "").strip() != ""]
    presence = _build_presence_indexes(non_empty_dps)

    issues: List[Issue] = []

    # -----------------------------
    # 0) Precompute config-driven helper indexes
    # -----------------------------
    containers_min_occurs = _build_container_index(config)
    optional_containers: Set[str] = {xp for xp, mo in containers_min_occurs.items() if mo == 0}
    activation = _build_activation_indexes(non_empty_dps, optional_containers)

    error_map = _error_by_number(config)

    # -----------------------------
    # Stage 3: Submission history context ("previously received")
    # -----------------------------
    #
    # Certain OECD severe record errors (e.g., 60002 / 60008 / 60009 / 60014) depend on
    # what has been previously received. The web tool stores an immutable Submission
    # summary per import (see models.Submission / models.SubmissionRecord).
    submissions: List[models.Submission] = []
    current_submission: Optional[models.Submission] = None
    prev_submissions: List[models.Submission] = []
    prev_records: List[models.SubmissionRecord] = []

    # Indexes used by cross-submission validations
    prev_docrefs_by_filer: Dict[Optional[str], Set[str]] = {}
    corr_successor: Dict[str, str] = {}  # CorrDocRefId -> DocRefId (latest successor in history)
    sub_time: Dict[str, datetime] = {}

    try:
        submissions = (
            db.query(models.Submission)
            .filter(models.Submission.filing_id == filing_id)
            .order_by(models.Submission.imported_at.asc())
            .all()
        )
        if submissions:
            current_submission = submissions[-1]
            prev_submissions = submissions[:-1]
            sub_time = {s.id: (s.imported_at or datetime.min) for s in submissions}

        if prev_submissions:
            prev_ids = [s.id for s in prev_submissions]
            prev_records = (
                db.query(models.SubmissionRecord)
                .filter(models.SubmissionRecord.filing_id == filing_id)
                .filter(models.SubmissionRecord.submission_id.in_(prev_ids))
                .all()
            )

        for r in prev_records:
            if not r.doc_ref_id:
                continue
            fk = r.filer_code  # None means GLOBAL
            prev_docrefs_by_filer.setdefault(fk, set()).add((r.doc_ref_id or "").strip())

        # Build successor links for correction chains in *history* (order matters).
        recs_sorted = sorted(
            [r for r in prev_records if (r.corr_doc_ref_id or '').strip() and (r.doc_ref_id or '').strip()],
            key=lambda rr: sub_time.get(rr.submission_id, datetime.min),
        )
        for r in recs_sorted:
            corr = (r.corr_doc_ref_id or '').strip()
            new = (r.doc_ref_id or '').strip()
            if corr and new:
                corr_successor[corr] = new

    except Exception:
        # Non-fatal: if history tables are not available, cross-submission checks are skipped.
        submissions = []
        current_submission = None
        prev_submissions = []
        prev_records = []
        prev_docrefs_by_filer = {}
        corr_successor = {}
        sub_time = {}

    def _latest_instance(docref: str) -> str:
        """Follow CorrDocRefId -> DocRefId links to find the latest instance in history."""
        cur = (docref or '').strip()
        seen: Set[str] = set()
        while cur and cur in corr_successor and cur not in seen:
            seen.add(cur)
            cur = (corr_successor.get(cur) or '').strip()
        return cur


    # Expected filers (prefer register; fallback to datapoints)
    expected_filers: List[str] = sorted({f.filer_code for f in filers if (f.filer_code or "").strip()})
    if not expected_filers:
        expected_filers = sorted({dp.filer_code for dp in all_dps if dp.filer_code})

    # Expected jurisdictions (prefer register; fallback to datapoints)
    responsible_by_juris: Dict[str, Optional[str]] = {
        j.jurisdiction_code: (j.responsible_filer_code or None)
        for j in juris_rows
    }
    expected_jurisdictions: List[str] = sorted({j.jurisdiction_code for j in juris_rows})
    if not expected_jurisdictions:
        expected_jurisdictions = sorted({dp.jurisdiction_code for dp in all_dps if dp.jurisdiction_code})

    # Expected entities (prefer register; fallback to datapoints)
    filed_by_entity: Dict[str, Optional[str]] = {
        e.entity_code: (e.filed_by_filer_code or None)
        for e in entity_rows
        if e.entity_code
    }
    expected_entities: List[str] = sorted({e.entity_code for e in entity_rows if e.included_in_gir and e.entity_code})
    if not expected_entities:
        expected_entities = sorted({dp.entity_code for dp in all_dps if dp.entity_code})

    # Jurisdiction section root container (optional overall, but can be expected per jurisdiction)
    juris_section_container = next(
        (s.container_xpath for s in config.section_cardinality if s.section == "Jurisdiction"),
        None,
    )

    # Helpful inference: if jurisdiction_code is not set on the datapoint but the
    # value of RecJurCode/Jurisdiction looks like an ISO-2 code, treat it as
    # belonging to that jurisdiction for scoping checks.
    # (We add these to presence indexes in a minimal way.)
    for dp in non_empty_dps:
        if dp.jurisdiction_code:
            continue
        if not dp.xml_path:
            continue
        if not (dp.xml_path.endswith("/RecJurCode") or dp.xml_path.endswith("/Jurisdiction")):
            continue
        code = (dp.value_raw or "").strip().upper()
        if len(code) == 2 and code.isalpha():
            presence["present_by_juris"].add((code, dp.xml_path))
            if dp.filer_code:
                presence["present_by_filer_juris"].add((dp.filer_code, code, dp.xml_path))
            else:
                presence["present_juris_no_filer"].add((code, dp.xml_path))

    # -----------------------------
    # 1) Generated validations (Sprint 1.2)
    # -----------------------------

    # 1a) Required leaf element presence (scope-aware)
    #
    # Stage 4.5: Attribute-path requiredness
    #
    # The importer can emit attribute datapoints with xml_path like:
    #   /.../TIN/@issuedBy
    # Some configs (when generated from the OECD XSD rather than the Excel toolkit)
    # may include attributes as required nodes.
    #
    # To avoid breaking XLSX/CSV submissions (which typically cannot supply XML
    # attributes), we allow this behaviour to be controlled via a mode:
    #   - off  : never enforce attribute requiredness
    #   - auto : enforce only when the latest submission source_type is "xml"
    #   - on   : always enforce
    arm = (attribute_requiredness_mode or "auto").strip().lower()
    if arm not in {"off", "auto", "on"}:
        arm = "auto"
    config_has_attributes = any("/@" in (el.xpath or "") for el in (config.elements or []))
    enforce_attribute_requiredness = False
    if config_has_attributes:
        if arm == "on":
            enforce_attribute_requiredness = True
        elif arm == "auto":
            enforce_attribute_requiredness = bool(
                current_submission
                and (current_submission.source_type or "").strip().lower() == "xml"
            )

    def _is_required_leaf(el: Element) -> bool:
        if el.is_container:
            return False
        if not el.required:
            return False
        xp = (el.xpath or "").strip()
        is_attr = "/@" in xp
        if is_attr:
            return enforce_attribute_requiredness
        return (el.min_occurs or 0) >= 1

    required_elements = [e for e in (config.elements or []) if _is_required_leaf(e)]

    def _present_for_filer(filer: str, xpath: str) -> bool:
        return (
            xpath in presence["present_paths_global"]
            or (filer, xpath) in presence["present_by_filer"]
        )

    def _present_for_juris(juris: str, xpath: str, filer: Optional[str]) -> bool:
        if filer:
            # Prefer scoped datapoints for the responsible filer; allow "no-filer" shared datapoints.
            return (
                (filer, juris, xpath) in presence["present_by_filer_juris"]
                or (juris, xpath) in presence["present_juris_no_filer"]
            )
        # If no responsible filer is defined, accept any filer scoped to that jurisdiction.
        return (juris, xpath) in presence["present_by_juris"]

    def _present_for_entity(entity: str, xpath: str, filer: Optional[str]) -> bool:
        if filer:
            return (
                (filer, entity, xpath) in presence["present_by_filer_entity"]
                or (entity, xpath) in presence["present_entity_no_filer"]
            )
        return (entity, xpath) in presence["present_by_entity"]

    for e in required_elements:
        scope = _infer_scope(e)
        gate = _deepest_optional_gate(e.xpath, containers_min_occurs)

        if scope == "jurisdiction" and expected_jurisdictions:
            for juris in expected_jurisdictions:
                responsible = responsible_by_juris.get(juris)
                filer_for_scope = responsible

                # Special case: treat JurisdictionSection root as active if the jurisdiction is expected.
                force_active = bool(juris_section_container and gate == juris_section_container)

                if not _is_gate_active(
                    gate,
                    filer=filer_for_scope,
                    juris=juris,
                    entity=None,
                    activation=activation,
                    force_active=force_active,
                ):
                    continue

                if not _present_for_juris(juris, e.xpath, filer_for_scope):
                    kind = "attribute" if "/@" in (e.xpath or "") else "element"
                    issues.append(Issue(
                        severity="BLOCKING",
                        rule_id=_rid("REQJ", f"{e.xpath}|{juris}|{filer_for_scope or ''}"),
                        section=e.section,
                        xml_path=e.xpath,
                        filer_code=filer_for_scope,
                        jurisdiction_code=juris,
                        message=(
                            f"Missing required {kind} for jurisdiction {juris}"
                            + (f" (responsible filer {filer_for_scope})" if filer_for_scope else "")
                            + f": {e.tax_label} ({e.xpath})"
                        ),
                        how_to_fix=_register_hint_for_xpath(e.xpath) or "Provide a value for this required field for the jurisdiction.",
                    ))
            continue

        if scope == "entity" and expected_entities:
            for entity in expected_entities:
                filer_for_scope = filed_by_entity.get(entity)

                if not _is_gate_active(
                    gate,
                    filer=filer_for_scope,
                    juris=None,
                    entity=entity,
                    activation=activation,
                ):
                    continue

                if not _present_for_entity(entity, e.xpath, filer_for_scope):
                    kind = "attribute" if "/@" in (e.xpath or "") else "element"
                    issues.append(Issue(
                        severity="BLOCKING",
                        rule_id=_rid("REQE", f"{e.xpath}|{entity}|{filer_for_scope or ''}"),
                        section=e.section,
                        xml_path=e.xpath,
                        filer_code=filer_for_scope,
                        entity_code=entity,
                        message=(
                            f"Missing required {kind} for entity {entity}"
                            + (f" (filed by {filer_for_scope})" if filer_for_scope else "")
                            + f": {e.tax_label} ({e.xpath})"
                        ),
                        how_to_fix=_register_hint_for_xpath(e.xpath) or "Provide a value for this required field for the entity.",
                    ))
            continue

        if scope == "filer" and expected_filers:
            for filer in expected_filers:
                if not _is_gate_active(
                    gate,
                    filer=filer,
                    juris=None,
                    entity=None,
                    activation=activation,
                ):
                    continue

                if not _present_for_filer(filer, e.xpath):
                    kind = "attribute" if "/@" in (e.xpath or "") else "element"
                    issues.append(Issue(
                        severity="BLOCKING",
                        rule_id=_rid("REQF", f"{e.xpath}|{filer}"),
                        section=e.section,
                        xml_path=e.xpath,
                        filer_code=filer,
                        message=f"Missing required {kind} for filer {filer}: {e.tax_label} ({e.xpath})",
                        how_to_fix=_register_hint_for_xpath(e.xpath) or "Provide a value for this required field for the filing entity.",
                    ))
            continue

        # Filing-level presence (gated by optional containers)
        if not _is_gate_active(
            gate,
            filer=None,
            juris=None,
            entity=None,
            activation=activation,
        ):
            continue

        if e.xpath not in presence["present_paths_global"]:
            kind = "attribute" if "/@" in (e.xpath or "") else "element"
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("REQ", e.xpath),
                section=e.section,
                xml_path=e.xpath,
                message=f"Missing required {kind}: {e.tax_label} ({e.xpath})",
                how_to_fix=_register_hint_for_xpath(e.xpath) or "Provide a value for this required field.",
            ))

    # 1b) Allowed values (enums / code lists)
    for dp in all_dps:
        e = elements_by_path.get(dp.xml_path)
        if e is None:
            continue  # unknown path
        allowed = list(e.allowed_values or [])
        if not allowed:
            continue
        v = (dp.value_raw or "").strip()
        if v == "":
            continue
        if v not in allowed:
            preview = ", ".join(allowed[:20])
            more = "" if len(allowed) <= 20 else f" (+{len(allowed)-20} more)"
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("ENUM", f"{dp.xml_path}|{v}|{dp.filer_code}|{dp.jurisdiction_code}|{dp.entity_code}|{dp.context_key}"),
                section=e.section,
                xml_path=dp.xml_path,
                filer_code=dp.filer_code,
                jurisdiction_code=dp.jurisdiction_code,
                entity_code=dp.entity_code,
                context_key=dp.context_key,
                message=f"Invalid value '{v}' for {e.tax_label}. Allowed: {preview}{more}",
                how_to_fix="Select/submit a value from the allowed code list.",
            ))

    # 1c) Basic datatype sanity (best-effort)
    for dp in all_dps:
        e = elements_by_path.get(dp.xml_path)
        if e is None or not e.xsd_type:
            continue
        v = (dp.value_raw or "").strip()
        if v == "":
            continue
        t = e.xsd_type.lower()
        if "date" in t and dp.value_date is None:
            issues.append(Issue(
                severity="WARNING",
                rule_id=_rid("TYPE", f"date|{dp.xml_path}|{v}|{dp.filer_code}|{dp.jurisdiction_code}|{dp.entity_code}|{dp.context_key}"),
                section=e.section,
                xml_path=dp.xml_path,
                filer_code=dp.filer_code,
                jurisdiction_code=dp.jurisdiction_code,
                entity_code=dp.entity_code,
                context_key=dp.context_key,
                message=f"Value '{v}' does not look like a valid date for {e.tax_label}.",
                how_to_fix="Provide the date in ISO format (YYYY-MM-DD) or as required by your data source.",
            ))
        if any(x in t for x in ["decimal", "integer", "nonnegativeinteger", "positiveinteger"]) and dp.value_numeric is None:
            issues.append(Issue(
                severity="WARNING",
                rule_id=_rid("TYPE", f"num|{dp.xml_path}|{v}|{dp.filer_code}|{dp.jurisdiction_code}|{dp.entity_code}|{dp.context_key}"),
                section=e.section,
                xml_path=dp.xml_path,
                filer_code=dp.filer_code,
                jurisdiction_code=dp.jurisdiction_code,
                entity_code=dp.entity_code,
                context_key=dp.context_key,
                message=f"Value '{v}' does not look like a valid number for {e.tax_label}.",
                how_to_fix="Provide a numeric value (e.g., 123.45).",
            ))

    # -----------------------------
    # 2) Bespoke validations (expanded / scoped)
    # -----------------------------

    filer_codes = {f.filer_code for f in filers}

    # 2a) Exactly one UPE filer (best-effort; assumes role='UPE')
    upe_filers = [f for f in filers if (f.role or "").strip().upper() == "UPE"]
    if len(upe_filers) != 1:
        issues.append(Issue(
            severity="BLOCKING",
            rule_id=_rid("BIZ", "upe_count"),
            section="General",
            message=f"Expected exactly 1 UPE filer in Filing Entity Register, found {len(upe_filers)}.",
            how_to_fix="Ensure one (and only one) filer has role 'UPE'.",
        ))

    # 2b) Included entities must map to an existing filer when multiple filers exist
    multi_filer = len(filers) > 1
    for ent in entity_rows:
        if not ent.included_in_gir:
            continue
        fb = (ent.filed_by_filer_code or "").strip()
        if fb == "":
            if multi_filer:
                issues.append(Issue(
                    severity="BLOCKING",
                    rule_id=_rid("BIZ", f"missing_filed_by|{ent.entity_code}"),
                    section="General",
                    entity_code=ent.entity_code,
                    message=f"Included entity '{ent.entity_code}' is missing filed_by_filer_code in a multi-filer filing.",
                    how_to_fix="Populate filed_by_filer_code for this entity to assign it to a filing entity (UPE/POPE/designated).",
                ))
            continue
        if fb not in filer_codes:
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("BIZ", f"invalid_filed_by|{ent.entity_code}|{fb}"),
                section="General",
                entity_code=ent.entity_code,
                message=f"Included entity '{ent.entity_code}' references unknown filer '{fb}'.",
                how_to_fix="Fix filed_by_filer_code to match a filer_code in the Filing Entity Register.",
            ))

    # 2c) DocRefId uniqueness and CorrDocRefId referential integrity (scoped per filer)
    #      This avoids false positives when one Filing contains multiple filer submissions.
    docref_paths = [p for p in {dp.xml_path for dp in submission_dps} if p and p.lower().endswith("docrefid") and not p.lower().endswith("corrdocrefid")]
    corr_paths = [p for p in {dp.xml_path for dp in submission_dps} if p and p.lower().endswith("corrdocrefid")]

    # Group datapoints by filer_code (None is its own group)
    def _filer_group(dp: models.DataPoint) -> Optional[str]:
        return dp.filer_code

    dps_by_filer: Dict[Optional[str], List[models.DataPoint]] = {}
    for dp in submission_dps:
        dps_by_filer.setdefault(_filer_group(dp), []).append(dp)

    from collections import Counter

    for filer, rows in dps_by_filer.items():
        # Collect DocRefId
        docref_values: List[str] = []
        for dp in rows:
            if dp.xml_path not in docref_paths:
                continue
            v = (dp.value_raw or "").strip()
            if v:
                docref_values.append(v)

        docref_counter = Counter(docref_values)
        duplicates = [v for v, c in docref_counter.items() if c > 1]
        if duplicates:
            preview = ", ".join(duplicates[:10])
            more = "" if len(duplicates) <= 10 else f" (+{len(duplicates)-10} more)"
            num = 60007 if 60007 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("DOC", f"dup_docrefid|{filer or 'GLOBAL'}"),
                section="FilingInfo",
                filer_code=filer,
                error_number=num,
                message=(
                    f"Duplicate DocRefId values detected for filer {filer or 'GLOBAL'}: {preview}{more}."
                ),
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure every DocRefId is unique within the submission.",
            ))

        docref_set = set(docref_counter.keys())

        # Collect CorrDocRefId
        corr_values: List[str] = []
        for dp in rows:
            if dp.xml_path not in corr_paths:
                continue
            v = (dp.value_raw or "").strip()
            if v:
                corr_values.append(v)

        # 60006: same docref corrected/deleted twice in same message
        corr_counter = Counter(corr_values)
        corr_dups = [v for v, c in corr_counter.items() if c > 1]
        if corr_dups:
            preview = ", ".join(corr_dups[:10])
            more = "" if len(corr_dups) <= 10 else f" (+{len(corr_dups)-10} more)"
            num = 60006 if 60006 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("DOC", f"dup_corrdocrefid|{filer or 'GLOBAL'}"),
                section="FilingInfo",
                filer_code=filer,
                error_number=num,
                message=f"The same CorrDocRefId is used more than once for filer {filer or 'GLOBAL'}: {preview}{more}.",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure each DocRefId is corrected/deleted at most once per submission.",
            ))

        # 60008: CorrDocRefId refers to an unknown record (cross-submission aware)
        history_known: Set[str] = set()
        if prev_docrefs_by_filer:
            if filer is None:
                for s in prev_docrefs_by_filer.values():
                    history_known |= set(s)
            else:
                history_known |= set(prev_docrefs_by_filer.get(filer, set()))
                history_known |= set(prev_docrefs_by_filer.get(None, set()))

        known_docrefs = set(docref_set) | history_known

        missing_corr_refs = sorted({v for v in corr_values if v not in known_docrefs})
        if missing_corr_refs:
            preview = ", ".join(missing_corr_refs[:10])
            more = "" if len(missing_corr_refs) <= 10 else f" (+{len(missing_corr_refs)-10} more)"
            num = 60008 if 60008 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("DOC", f"missing_corr_ref|{filer or 'GLOBAL'}"),
                section="FilingInfo",
                filer_code=filer,
                error_number=num,
                message=(
                    f"CorrDocRefId values not found among previously received DocRefId values for filer {filer or 'GLOBAL'}: "
                    f"{preview}{more}."
                ),
                how_to_fix=_oecd_fix_text(error_map, num) if num else "CorrDocRefId must reference an existing DocRefId from a previously received submission.",
            ))

        # 60009: CorrDocRefId does not relate to the latest instance (cross-submission)
        not_latest: List[Tuple[str, str]] = []
        for v in sorted({v for v in corr_values if v in history_known}):
            latest = _latest_instance(v)
            if latest and latest != v:
                not_latest.append((v, latest))

        if not_latest:
            preview = ", ".join([f"{a}->{b}" for (a, b) in not_latest[:8]])
            suffix = "..." if len(not_latest) > 8 else ""
            num = 60009 if 60009 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("DOC", f"corr_not_latest|{filer or 'GLOBAL'}"),
                section="FilingInfo",
                filer_code=filer,
                error_number=num,
                message=(
                    f"CorrDocRefId does not refer to the latest instance for filer {filer or 'GLOBAL'}: "
                    f"{preview}{suffix}."
                ),
                how_to_fix=_oecd_fix_text(error_map, num) if num else "When correcting/deleting a record, CorrDocRefId must refer to the latest previously received DocRefId in that correction chain.",
            ))

    # 2d) DocTypeIndic <-> CorrDocRefId consistency (scoped to the same DocSpec container)
    correction_types = {"OECD2", "OECD3", "OECD12", "OECD13"}

    # Build fast lookup by full key (filer/juris/entity/context + xml_path)
    key_to_dp: Dict[Tuple[Optional[str], Optional[str], Optional[str], Optional[str], str], models.DataPoint] = {}
    for dp in all_dps:
        key_to_dp[(dp.filer_code, dp.jurisdiction_code, dp.entity_code, dp.context_key, dp.xml_path)] = dp

    # CorrDocRefId present but DocTypeIndic is OECD0/OECD1 (OECD 60012)
    for dp in all_dps:
        if not dp.xml_path.lower().endswith("corrdocrefid"):
            continue
        corr_val = (dp.value_raw or "").strip()
        if not corr_val:
            continue
        base = dp.xml_path.rsplit("/", 1)[0]
        doc_type_path = base + "/DocTypeIndic"
        doc_type_dp = key_to_dp.get((dp.filer_code, dp.jurisdiction_code, dp.entity_code, dp.context_key, doc_type_path))
        if doc_type_dp is None:
            continue
        dt = (doc_type_dp.value_raw or "").strip()
        if dt in {"OECD0", "OECD1"}:
            num = 60012 if 60012 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("DOC", f"corr_present_non_correction|{dp.filer_code}|{dp.jurisdiction_code}|{dp.entity_code}|{dp.context_key}|{dp.xml_path}"),
                section="FilingInfo",
                filer_code=dp.filer_code,
                jurisdiction_code=dp.jurisdiction_code,
                entity_code=dp.entity_code,
                context_key=dp.context_key,
                xml_path=dp.xml_path,
                error_number=num,
                message=f"CorrDocRefId must be omitted when DocTypeIndic is '{dt}'.",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Remove CorrDocRefId or set DocTypeIndic to a correction/deletion code.",
            ))

    # DocTypeIndic indicates correction but CorrDocRefId missing
    for dp in all_dps:
        if not dp.xml_path.lower().endswith("doctypeindic"):
            continue
        dt = (dp.value_raw or "").strip()
        if dt not in correction_types:
            continue

        base = dp.xml_path.rsplit("/", 1)[0]
        corr_path = base + "/CorrDocRefId"
        corr_dp = key_to_dp.get((dp.filer_code, dp.jurisdiction_code, dp.entity_code, dp.context_key, corr_path))
        corr_val = (corr_dp.value_raw or "").strip() if corr_dp else ""
        if not corr_val:
            num = 60015 if 60015 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("DOC", f"missing_corrdocrefid|{dp.filer_code}|{dp.jurisdiction_code}|{dp.entity_code}|{dp.context_key}|{corr_path}|{dt}"),
                section="FilingInfo",
                filer_code=dp.filer_code,
                jurisdiction_code=dp.jurisdiction_code,
                entity_code=dp.entity_code,
                context_key=dp.context_key,
                xml_path=corr_path,
                error_number=num,
                message=f"DocTypeIndic='{dt}' indicates a correction/deletion but CorrDocRefId is missing.",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Provide CorrDocRefId referencing the prior DocRefId.",
            ))

    # -----------------------------
    # 2e) OECD 600xx severe record errors (single-file, best-effort)
    # -----------------------------

    # Helper: string value
    def _v(dp: models.DataPoint) -> str:
        return (dp.value_raw or "").strip()

    # 60001: MessageRefId format
    msgref_dps = [dp for dp in submission_dps if (dp.xml_path or "").endswith("/MessageRefId")]
    # Accept a high-level pattern: CCYYYYCCUnique (<= 200 chars)
    msgref_re = re.compile(r"^[A-Z]{2}\d{4}[A-Z]{2}[A-Za-z0-9][A-Za-z0-9\-_.:]{0,193}$")
    for dp in msgref_dps:
        val = _v(dp)
        if not val:
            continue
        if len(val) > 200 or not msgref_re.match(val):
            num = 60001 if 60001 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("OECD", f"60001|{dp.xml_path}|{val}"),
                section="GLOBEHeader",
                xml_path=dp.xml_path,
                filer_code=dp.filer_code,
                error_number=num,
                message=f"MessageRefId '{val}' does not match the expected format (CCYYYYCCUniqueID).",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure MessageRefId follows the OECD structure and is <= 200 characters.",
            ))

    # 60002: MessageRefId has already been used in a previously received submission
    current_msgref: Optional[str] = None
    msgref_xpath: Optional[str] = None
    if current_submission and (current_submission.message_ref_id or '').strip():
        current_msgref = (current_submission.message_ref_id or '').strip()
    else:
        for dp in msgref_dps:
            val = _v(dp)
            if val:
                current_msgref = val
                msgref_xpath = dp.xml_path
                break

    if current_msgref and prev_submissions:
        prev_hits = [s for s in prev_submissions if (s.message_ref_id or '').strip() == current_msgref]
        if prev_hits:
            num = 60002 if 60002 in error_map else None
            # Show up to 3 dates for context
            dates = []
            for s in sorted(prev_hits, key=lambda x: x.imported_at or datetime.min, reverse=True):
                if s.imported_at:
                    dates.append(s.imported_at.date().isoformat())
                if len(dates) >= 3:
                    break
            preview = ", ".join(dates)
            more = "" if len(prev_hits) <= 3 else f" (+{len(prev_hits)-3} more)"
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("OECD", f"60002|{current_msgref}"),
                section="GLOBEHeader",
                xml_path=msgref_xpath or "/GLOBE_OECD/GLOBEHeader/MessageRefId",
                error_number=num,
                message=f"MessageRefId '{current_msgref}' has already been used in a previously received submission: {preview}{more}.",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Use a new, unique MessageRefId for each GIR submission.",
            ))

    # Extract header reporting period end date / year (best-effort)
    header_period_end = None
    # Prefer explicit EndDate within GLOBEHeader/ReportingPeriod
    for dp in submission_dps:
        p = (dp.xml_path or "").lower()
        if "globeheader" not in p or "reportingperiod" not in p:
            continue
        if not (p.endswith("enddate") or p.endswith("/enddate") or p.endswith("/end")):
            continue
        if dp.value_date:
            header_period_end = dp.value_date
            break
    # Fallback: any date under GLOBEHeader/ReportingPeriod
    if header_period_end is None:
        for dp in submission_dps:
            p = (dp.xml_path or "").lower()
            if "globeheader" not in p or "reportingperiod" not in p:
                continue
            if dp.value_date:
                header_period_end = dp.value_date
                break

    # 60003: ReportingPeriod year <= current year
    if header_period_end is not None:
        current_year = datetime.utcnow().year
        if header_period_end.year > current_year:
            num = 60003 if 60003 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("OECD", f"60003|{header_period_end.isoformat()}"),
                section="GLOBEHeader",
                error_number=num,
                message=f"ReportingPeriod year {header_period_end.year} is later than the current year {current_year}.",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Set ReportingPeriod to the correct year (<= current year).",
            ))

    # 60004: mixture of new (OECD1) and corrections (OECD2/OECD3) in a message
    doc_types = {(_v(dp)) for dp in all_dps if (dp.xml_path or "").lower().endswith("doctypeindic") and _v(dp)}
    has_new = "OECD1" in doc_types
    has_corr = any(dt in {"OECD2", "OECD3", "OECD12", "OECD13"} for dt in doc_types)
    if has_new and has_corr:
        num = 60004 if 60004 in error_map else None
        issues.append(Issue(
            severity="BLOCKING",
            rule_id=_rid("OECD", f"60004|{sorted(doc_types)}"),
            section="FilingInfo",
            error_number=num,
            message="This message contains a mix of new records (OECD1) and correction/deletion records (OECD2/OECD3).",
            how_to_fix=_oecd_fix_text(error_map, num) if num else "Do not mix new records and corrections in the same message; submit separate messages.",
        ))

    # 60011: DocRefId format (CCYYYYUniqueID)
    docref_re = re.compile(r"^[A-Z]{2}\d{4}[A-Za-z0-9][A-Za-z0-9\-_.:]{0,193}$")
    for dp in all_dps:
        p = (dp.xml_path or "").lower()
        if not p.endswith("docrefid") or p.endswith("corrdocrefid"):
            continue
        val = _v(dp)
        if not val:
            continue
        if len(val) > 200 or not docref_re.match(val):
            num = 60011 if 60011 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("OECD", f"60011|{dp.xml_path}|{val}|{dp.filer_code}|{dp.jurisdiction_code}|{dp.entity_code}|{dp.context_key}"),
                section=dp.xml_path.split("/")[3] if dp.xml_path.startswith("/") and len(dp.xml_path.split("/")) > 3 else "FilingInfo",
                xml_path=dp.xml_path,
                filer_code=dp.filer_code,
                jurisdiction_code=dp.jurisdiction_code,
                entity_code=dp.entity_code,
                context_key=dp.context_key,
                error_number=num,
                message=f"DocRefId '{val}' does not match the expected format (CCYYYYUniqueID).",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure DocRefId begins with a 2-letter country code and 4-digit year.",
            ))

    # 60013: OECD0 (Resend) is only allowed for FilingInfo
    for dp in all_dps:
        p = (dp.xml_path or "").lower()
        if not p.endswith("doctypeindic"):
            continue
        if _v(dp) != "OECD0":
            continue
        if "/filinginfo/" in p:
            continue
        num = 60013 if 60013 in error_map else None
        issues.append(Issue(
            severity="BLOCKING",
            rule_id=_rid("OECD", f"60013|{dp.xml_path}|{dp.filer_code}|{dp.jurisdiction_code}|{dp.entity_code}|{dp.context_key}"),
            section="General",
            xml_path=dp.xml_path,
            filer_code=dp.filer_code,
            jurisdiction_code=dp.jurisdiction_code,
            entity_code=dp.entity_code,
            context_key=dp.context_key,
            error_number=num,
            message="DocTypeIndic 'OECD0' (Resend) may only be used for FilingInfo.",
            how_to_fix=_oecd_fix_text(error_map, num) if num else "Use OECD0 only for FilingInfo; use OECD1/2/3 as appropriate for other records.",
        ))

    # 60016 / 60017: FilingInfo <-> GeneralSection relationship (record-type mapped)
    # These rules reference the DocSpec/DocTypeIndic of the FilingInfo and GeneralSection records.
    record_specs = _build_record_type_specs(config)
    filing_spec = record_specs.get("FilingInfo")
    general_spec = record_specs.get("GeneralSection")

    filing_docref_xp = _find_xpath(config, section="FilingInfo", endswith="/DocSpec/DocRefId")
    filing_docref_xp_lc = _norm_xpath(filing_docref_xp).lower() if filing_docref_xp else ""

    filing_doctype_dps: List[models.DataPoint] = []
    if filing_spec and filing_spec.doctypeindic_xpaths_lc:
        # filer=None here means "include all filers"; we will group by filer_code below.
        filing_doctype_dps = _record_doctype_dps(submission_dps, filing_spec, filer=None)

    filing_dt_by_filer: Dict[str, Set[str]] = {}
    for dp in filing_doctype_dps:
        fk = (dp.filer_code or "").strip() or "GLOBAL"
        filing_dt_by_filer.setdefault(fk, set()).add(_v(dp))

    def _general_present_for(filer_code: Optional[str]) -> bool:
        if not general_spec:
            return False
        return _record_present(submission_dps, general_spec, filer=filer_code)

    def _general_doctypes_for(filer_code: Optional[str]) -> Set[str]:
        if not general_spec:
            return set()
        return {(_v(dp)) for dp in _record_doctype_dps(submission_dps, general_spec, filer=filer_code) if _v(dp)}

    for fk, dts in filing_dt_by_filer.items():
        filer_code = None if fk == "GLOBAL" else fk

        # 60014: If FilingInfo is resent with OECD0, its DocRefId must match the latest previously received FilingInfo DocRefId.
        if "OECD0" in dts:
            current_docref = None
            current_docref_xpath = None
            if filing_docref_xp_lc:
                for dp in submission_dps:
                    if not _filer_matches(dp.filer_code, filer_code):
                        continue
                    if _dp_xpath_lc(dp) != filing_docref_xp_lc:
                        continue
                    v = _v(dp)
                    if v:
                        current_docref = v
                        current_docref_xpath = dp.xml_path
                        break

            latest_prev_docref = None
            if prev_records:
                candidates = []
                for r in prev_records:
                    if (r.record_type or "") != "FilingInfo":
                        continue
                    if filer_code and (r.filer_code not in (None, filer_code)):
                        continue
                    if (r.doc_ref_id or "").strip():
                        candidates.append(r)
                if candidates:
                    latest_rec = max(candidates, key=lambda rr: sub_time.get(rr.submission_id, datetime.min))
                    latest_prev_docref = (latest_rec.doc_ref_id or "").strip()

            if current_docref:
                if (not latest_prev_docref) or (current_docref != latest_prev_docref):
                    num = 60014 if 60014 in error_map else None
                    expected_txt = latest_prev_docref or "<none found>"
                    issues.append(Issue(
                        severity="BLOCKING",
                        rule_id=_rid("OECD", f"60014|{fk}|{current_docref}|{expected_txt}"),
                        section="FilingInfo",
                        xml_path=current_docref_xpath or filing_docref_xp or "/GLOBE_OECD/GLOBEBody/FilingInfo/DocSpec/DocRefId",
                        filer_code=filer_code,
                        error_number=num,
                        message=(
                            "FilingInfo DocTypeIndic is 'OECD0' (Resend) but the FilingInfo DocRefId "
                            f"'{current_docref}' does not match the latest previously received FilingInfo DocRefId '{expected_txt}'."
                        ),
                        how_to_fix=_oecd_fix_text(error_map, num) if num else "Use the same FilingInfo DocRefId as the latest previously received FilingInfo record when submitting a resend (OECD0).",
                    ))


        # 60017: if FilingInfo DocTypeIndic is OECD1 (new filing), GeneralSection must be provided.
        if "OECD1" in dts and not _general_present_for(filer_code):
            num = 60017 if 60017 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("OECD", f"60017|{fk}"),
                section="General",
                filer_code=filer_code,
                error_number=num,
                message="FilingInfo DocTypeIndic is OECD1 (new filing) but GeneralSection is missing.",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Provide GeneralSection when submitting a new GIR (OECD1).",
            ))

        # 60016: if FilingInfo DocTypeIndic is OECD0 (resend), GeneralSection DocTypeIndic must not be OECD1 (new).
        if "OECD0" in dts:
            gen_dts = _general_doctypes_for(filer_code)
            if "OECD1" in gen_dts:
                num = 60016 if 60016 in error_map else None
                issues.append(Issue(
                    severity="BLOCKING",
                    rule_id=_rid("OECD", f"60016|{fk}"),
                    section="General",
                    filer_code=filer_code,
                    error_number=num,
                    message="FilingInfo DocTypeIndic is OECD0 (resend) but GeneralSection DocTypeIndic is OECD1 (new).",
                    how_to_fix=_oecd_fix_text(error_map, num) if num else "Do not include a new GeneralSection (OECD1) when resending FilingInfo (OECD0).",
                ))

    # 60018: at least one RecJurCode must match ReceivingCountry (best-effort)
    receiving_country = None
    for dp in submission_dps:
        p = (dp.xml_path or "").lower()
        if p.endswith("/receivingcountry") or p.endswith("receivingcountry"):
            rc = _v(dp).upper()
            if len(rc) >= 2 and rc[:2].isalpha():
                receiving_country = rc[:2]
                break
    if receiving_country:
        recjur = {(_v(dp).upper()[:2]) for dp in submission_dps if (dp.xml_path or "").endswith("/RecJurCode") and len(_v(dp)) >= 2}
        if receiving_country not in recjur:
            num = 60018 if 60018 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("OECD", f"60018|{receiving_country}|{sorted(recjur)}"),
                section="GLOBEHeader",
                error_number=num,
                message=f"No RecJurCode matches ReceivingCountry '{receiving_country}'.",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure at least one RecJurCode equals ReceivingCountry.",
            ))

    # 60019: Local lodgement roles must not be exchanged (informational in this web tool)
    filing_ce_role = None
    filing_ce_tin = None
    for dp in all_dps:
        p = (dp.xml_path or "").lower()
        if "/filinginfo/" in p and p.endswith("/filingce/role"):
            filing_ce_role = _v(dp)
        if "/filinginfo/" in p and p.endswith("/filingce/tin"):
            filing_ce_tin = _v(dp)
    if filing_ce_role in {"GIR403", "GIR404", "GIR405"}:
        num = 60019 if 60019 in error_map else None
        issues.append(Issue(
            severity="WARNING",
            rule_id=_rid("OECD", f"60019|{filing_ce_role}"),
            section="FilingInfo",
            error_number=num,
            message=f"Filing CE role '{filing_ce_role}' indicates a local lodgement GIR that should not be exchanged.",
            how_to_fix=_oecd_fix_text(error_map, num) if num else "If this is a local lodgement, do not exchange the GIR; file locally as required.",
        ))

    # 60020: FilingInfo period start must not be later than period end
    if filing.period_start and filing.period_end and filing.period_start > filing.period_end:
        num = 60020 if 60020 in error_map else None
        xp_start = _find_xpath(config, section="FilingInfo", endswith="/FilingInfo/Period/Start") or "/GLOBE_OECD/GLOBEBody/FilingInfo/Period/Start"
        xp_end = _find_xpath(config, section="FilingInfo", endswith="/FilingInfo/Period/End") or "/GLOBE_OECD/GLOBEBody/FilingInfo/Period/End"
        issues.append(Issue(
            severity="BLOCKING",
            rule_id=_rid("OECD", f"60020|{filing.period_start.isoformat()}|{filing.period_end.isoformat()}"),
            section="FilingInfo",
            xml_path=xp_start,
            error_number=num,
            message=f"Period start date {filing.period_start.isoformat()} is later than period end date {filing.period_end.isoformat()}.",
            how_to_fix=_oecd_fix_text(error_map, num) if num else f"Ensure Period/Start <= Period/End (currently {xp_start} > {xp_end}).",
        ))

    # 60021: FilingInfo Period/End must not be later than header ReportingPeriod
    if filing.period_end and header_period_end and filing.period_end > header_period_end:
        num = 60021 if 60021 in error_map else None
        xp_end = _find_xpath(config, section="FilingInfo", endswith="/FilingInfo/Period/End") or "/GLOBE_OECD/GLOBEBody/FilingInfo/Period/End"
        issues.append(Issue(
            severity="BLOCKING",
            rule_id=_rid("OECD", f"60021|{filing.period_end.isoformat()}|{header_period_end.isoformat()}"),
            section="FilingInfo",
            xml_path=xp_end,
            error_number=num,
            message=f"FilingInfo Period/End {filing.period_end.isoformat()} is later than header ReportingPeriod {header_period_end.isoformat()}.",
            how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure FilingInfo Period/End is within the header ReportingPeriod.",
        ))

    # 60022: If Filing CE role is GIR401, FilingCE TIN should match a UPE TIN
    if filing_ce_role == "GIR401" and filing_ce_tin:
        upe_tins = {(_v(dp)) for dp in all_dps if "/corporatestructure/upe/" in (dp.xml_path or "").lower() and (dp.xml_path or "").lower().endswith("/tin") and _v(dp)}
        if upe_tins and filing_ce_tin not in upe_tins:
            num = 60022 if 60022 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("OECD", f"60022|{filing_ce_tin}|{sorted(upe_tins)}"),
                section="FilingInfo",
                error_number=num,
                message="When Filing CE role is GIR401, FilingCE TIN should match a TIN provided in the UPE ID.",
                how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure the FilingCE/TIN equals one of the UPE/ID/TIN values.",
            ))

    # 60023: FilingCE ResCountryCode must match TransmittingCountry (best-effort)
    transmitting_country = None
    for dp in submission_dps:
        p = (dp.xml_path or "").lower()
        if p.endswith("/transmittingcountry") or p.endswith("transmittingcountry"):
            tc = _v(dp).upper()
            if len(tc) >= 2 and tc[:2].isalpha():
                transmitting_country = tc[:2]
                break
    filing_ce_res = None
    # Prefer explicit element if present in the submission
    for dp in submission_dps:
        p = (dp.xml_path or "").lower()
        if "/filinginfo/" in p and p.endswith("/filingce/rescountrycode"):
            fc = _v(dp).upper()
            if len(fc) >= 2 and fc[:2].isalpha():
                filing_ce_res = fc[:2]
                break
    # Fallback to filer register jurisdiction_code
    if filing_ce_res is None and filers:
        f0 = next((f for f in filers if (f.jurisdiction_code or "").strip()), None)
        if f0 and (f0.jurisdiction_code or "").strip():
            filing_ce_res = f0.jurisdiction_code.strip().upper()[:2]
    if transmitting_country and filing_ce_res and transmitting_country != filing_ce_res:
        num = 60023 if 60023 in error_map else None
        issues.append(Issue(
            severity="BLOCKING",
            rule_id=_rid("OECD", f"60023|{filing_ce_res}|{transmitting_country}"),
            section="FilingInfo",
            error_number=num,
            message=f"FilingCE ResCountryCode '{filing_ce_res}' does not match TransmittingCountry '{transmitting_country}'.",
            how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure FilingCE ResCountryCode matches the TransmittingCountry in the header.",
        ))

    # 60010: FilingInfo deletion requires deletion of related records (single-file only, record-type mapped)
    deletion_types = {"OECD3", "OECD13"}

    record_specs = _build_record_type_specs(config)
    filing_spec = record_specs.get("FilingInfo")
    related_specs: List[RecordTypeSpec] = [
        record_specs.get("GeneralSection"),
        record_specs.get("Summary"),
        record_specs.get("JurisdictionSection"),
        record_specs.get("UTPRAttribution"),
    ]
    related_specs = [s for s in related_specs if s is not None]

    filing_doctype_dps: List[models.DataPoint] = []
    if filing_spec and filing_spec.doctypeindic_xpaths_lc:
        filing_doctype_dps = _record_doctype_dps(submission_dps, filing_spec, filer=None)

    filing_dt_by_filer: Dict[str, Set[str]] = {}
    for dp in filing_doctype_dps:
        fk = (dp.filer_code or "").strip() or "GLOBAL"
        filing_dt_by_filer.setdefault(fk, set()).add(_v(dp))

    for fk, dts in filing_dt_by_filer.items():
        if not any(dt in deletion_types for dt in dts):
            continue
        filer_code = None if fk == "GLOBAL" else fk

        violations: List[Tuple[str, str]] = []
        for spec in related_specs:
            for dp in _record_doctype_dps(submission_dps, spec, filer=filer_code):
                dt = _v(dp)
                if dt and dt not in deletion_types:
                    violations.append((spec.record_type, dt))

        if violations:
            # Collapse to a compact summary for the message.
            uniq = sorted({f"{rt}:{dt}" for (rt, dt) in violations})
            preview = ", ".join(uniq[:8])
            suffix = "..." if len(uniq) > 8 else ""
            num = 60010 if 60010 in error_map else None
            issues.append(Issue(
                severity="BLOCKING",
                rule_id=_rid("OECD", f"60010|{fk}|{preview}"),
                section="FilingInfo",
                filer_code=filer_code,
                error_number=num,
                message=(
                    "FilingInfo is marked for deletion, but one or more related records are not deleted "
                    + f"in this message: {preview}{suffix}"
                ),
                how_to_fix=_oecd_fix_text(error_map, num) if num else "If deleting FilingInfo, also delete all related GeneralSection/Summary/JurisdictionSection/UTPRAttribution records.",
            ))



    # -----------------------------
    # Stage 4: additional OECD severe record errors
    #   - 60005 (record type mismatch for correction/deletion)
    #   - 60024 (Summary conditional requiredness)
    #   - 60025–60028 (calculation checks with 4dp rounding + 1% margin)
    # -----------------------------

    # 60005: When DocTypeIndic is OECD2 or OECD3, the record must concern the same sub section
    #        as the CorrDocRefId (cross-submission aware via SubmissionRecord history).
    try:
        current_records: List[models.SubmissionRecord] = []
        if current_submission is not None:
            current_records = (
                db.query(models.SubmissionRecord)
                .filter(models.SubmissionRecord.filing_id == filing_id)
                .filter(models.SubmissionRecord.submission_id == current_submission.id)
                .all()
            )

        # Build a "latest record" lookup by DocRefId across history + current.
        # (We already enforce CorrDocRefId -> latest via 60009; but 60005 uses section identity.)
        docref_to_latest: Dict[str, models.SubmissionRecord] = {}
        for r in (prev_records + current_records):
            docref = (r.doc_ref_id or "").strip()
            if not docref:
                continue
            rt = sub_time.get(r.submission_id, datetime.min)
            if docref not in docref_to_latest:
                docref_to_latest[docref] = r
                continue
            existing = docref_to_latest[docref]
            et = sub_time.get(existing.submission_id, datetime.min)
            if rt > et:
                docref_to_latest[docref] = r

        def _rt_to_section(rt: str) -> str:
            if rt == "GeneralSection":
                return "General"
            if rt == "JurisdictionSection":
                return "Jurisdiction"
            return rt

        corr_xpath_by_rt: Dict[str, str] = {}
        for rt in ["FilingInfo", "GeneralSection", "Summary", "JurisdictionSection", "UTPRAttribution"]:
            sec = _rt_to_section(rt)
            xp = _find_xpath(config, section=sec, endswith="/DocSpec/CorrDocRefId")
            if xp:
                corr_xpath_by_rt[rt] = xp

        correction_types_60005 = {"OECD2", "OECD3"}
        for r in current_records:
            dt = (r.doc_type_indic or "").strip()
            if dt not in correction_types_60005:
                continue
            corr = (r.corr_doc_ref_id or "").strip()
            if not corr:
                continue

            target = docref_to_latest.get(corr)
            if not target:
                continue

            if (target.record_type or "") != (r.record_type or ""):
                num = 60005 if 60005 in error_map else None
                rt_cur = r.record_type or "Unknown"
                rt_prev = target.record_type or "Unknown"
                issues.append(Issue(
                    severity="BLOCKING",
                    rule_id=_rid("OECD", f"60005|{rt_cur}|{rt_prev}|{r.doc_ref_id}|{corr}|{r.filer_code}"),
                    section=rt_cur,
                    xml_path=corr_xpath_by_rt.get(rt_cur),
                    filer_code=r.filer_code,
                    error_number=num,
                    message=(
                        f"DocTypeIndic '{dt}' indicates a correction/deletion for record type '{rt_cur}', "
                        f"but CorrDocRefId '{corr}' refers to a previously received record of type '{rt_prev}'."
                    ),
                    how_to_fix=_oecd_fix_text(error_map, num) if num else "Ensure CorrDocRefId references a record in the same subsection (FilingInfo/GeneralSection/Summary/JurisdictionSection/UTPRAttribution).",
                ))
    except Exception:
        # Non-fatal: if submission history isn't available, this check is skipped.
        pass


    # 60024: If Summary contains any of SafeHarbour, ETRRange, SBIE, QDMTTut, GLoBETut,
    #        then JurWithTaxingRights/JurisdictionName must be provided.
    try:
        record_specs2 = record_specs if 'record_specs' in locals() else _build_record_type_specs(config)
        summary_spec = record_specs2.get("Summary") if record_specs2 else None

        trigger_names = ["SafeHarbour", "ETRRange", "SBIE", "QDMTTut", "GLoBETut"]
        trigger_roots_lc: Dict[str, str] = {}
        for nm in trigger_names:
            for e in config.elements:
                if (e.section or "").strip() != "Summary":
                    continue
                if (e.element_name or "").strip() != nm:
                    continue
                if not e.xpath:
                    continue
                trigger_roots_lc[nm] = _norm_xpath(e.xpath).lower()
                break

        req_xpath = None
        for e in config.elements:
            if (e.section or "").strip() != "Summary":
                continue
            if (e.element_name or "").strip() != "JurisdictionName":
                continue
            xp = (e.xpath or "")
            if "JurWithTaxingRights" not in xp:
                continue
            req_xpath = e.xpath
            break
        req_xpath_lc = _norm_xpath(req_xpath).lower() if req_xpath else ""

        if summary_spec and summary_spec.container_xpaths_lc and trigger_roots_lc and req_xpath_lc:
            # Determine which filers have a Summary record (or treat as GLOBAL)
            summary_filers: Set[Optional[str]] = set()
            for dp in submission_dps:
                xp = _dp_xpath_lc(dp)
                if any(cx and xp.startswith(cx) for cx in summary_spec.container_xpaths_lc):
                    summary_filers.add(dp.filer_code or None)

            if not summary_filers:
                summary_filers = {None}

            for filer_code in summary_filers:
                found_triggers: Set[str] = set()
                for dp in submission_dps:
                    if not _filer_matches(dp.filer_code, filer_code):
                        continue
                    if (dp.value_raw or "").strip() == "":
                        continue
                    xp = _dp_xpath_lc(dp)
                    # Trigger if any datapoint exists under the trigger root.
                    for nm, root in trigger_roots_lc.items():
                        if root and xp.startswith(root):
                            found_triggers.add(nm)

                if not found_triggers:
                    continue

                has_req = any(
                    _filer_matches(dp.filer_code, filer_code)
                    and _dp_xpath_lc(dp) == req_xpath_lc
                    and (dp.value_raw or "").strip() != ""
                    for dp in submission_dps
                )

                if not has_req:
                    num = 60024 if 60024 in error_map else None
                    trig_preview = ", ".join(sorted(found_triggers))
                    issues.append(Issue(
                        severity="BLOCKING",
                        rule_id=_rid("OECD", f"60024|{filer_code or 'GLOBAL'}|{trig_preview}"),
                        section="Summary",
                        xml_path=req_xpath,
                        filer_code=filer_code,
                        error_number=num,
                        message=(
                            f"Summary contains {trig_preview}, so JurWithTaxingRights/JurisdictionName must be provided, "
                            "but none was found."
                        ),
                        how_to_fix=_oecd_fix_text(error_map, num) if num else "Provide Summary/JurWithTaxingRights/JurisdictionName when any SafeHarbour/ETRRange/SBIE/QDMTTut/GLoBETut elements are present.",
                    ))
    except Exception:
        pass


    # 60025–60028: calculation validations
    # Note: These validations only run when the target element exists in the submission.
    try:
        def _pick_xpath(*, section: str, element_name: str, must_contain: Optional[str] = None, must_end: Optional[str] = None, must_not_contain: Optional[str] = None) -> Optional[str]:
            sec = (section or "").strip()
            en = (element_name or "").strip().lower()
            for e in config.elements:
                if sec and (e.section or "").strip() != sec:
                    continue
                if (e.element_name or "").strip().lower() != en:
                    continue
                xp = (e.xpath or "").strip()
                if not xp:
                    continue
                xp_n = _norm_xpath(xp)
                xp_lc = xp_n.lower()
                if must_contain and must_contain.lower() not in xp_lc:
                    continue
                if must_end and not xp_lc.endswith(must_end.lower()):
                    continue
                if must_not_contain and must_not_contain.lower() in xp_lc:
                    continue
                return xp_n
            return None

        def _first_dec(dps: List[models.DataPoint]) -> Decimal:
            """Return first parseable decimal from a list, else 0."""
            for ddp in dps:
                v = _dp_decimal(ddp)
                if v is not None:
                    return v
            return Decimal("0")

        # --- 60025 ---
        xp_etr = _pick_xpath(section="Jurisdiction", element_name="ETRRate", must_contain="/overallcomputation/", must_end="/etrrate", must_not_contain="/additionaltopuptax/")
        xp_adj = _pick_xpath(section="Jurisdiction", element_name="AdjustedCoveredTax", must_contain="/overallcomputation/", must_end="/adjustedcoveredtax", must_not_contain="/additionaltopuptax/")
        xp_net = _pick_xpath(section="Jurisdiction", element_name="NetGlobeIncome", must_contain="/overallcomputation/", must_end="/netglobeincome", must_not_contain="/additionaltopuptax/")

        if xp_etr and xp_net:
            xp_etr_lc = _norm_xpath(xp_etr).lower()
            xp_adj_lc = _norm_xpath(xp_adj).lower() if xp_adj else ""
            xp_net_lc = _norm_xpath(xp_net).lower()

            # Group by filer + jurisdiction (+ context_key) because the values are jurisdiction-scoped.
            groups: Dict[Tuple[Optional[str], Optional[str], Optional[str]], Dict[str, models.DataPoint]] = {}
            for dp in submission_dps:
                if not dp.jurisdiction_code:
                    continue
                xp = _dp_xpath_lc(dp)
                if xp not in {xp_etr_lc, xp_adj_lc, xp_net_lc}:
                    continue
                gk = (dp.filer_code or None, dp.jurisdiction_code, dp.context_key or None)
                d = groups.setdefault(gk, {})
                if xp == xp_etr_lc and "etr" not in d:
                    d["etr"] = dp
                elif xp == xp_adj_lc and "adj" not in d:
                    d["adj"] = dp
                elif xp == xp_net_lc and "net" not in d:
                    d["net"] = dp

            for (filer_code, juris, ctx), d in groups.items():
                dp_etr = d.get("etr")
                dp_net = d.get("net")
                if dp_etr is None or dp_net is None:
                    continue

                etr_val = _dp_decimal(dp_etr)
                net_val = _dp_decimal(dp_net)
                if etr_val is None or net_val is None:
                    continue
                if net_val <= 0:
                    continue  # rule does not apply

                adj_val = Decimal("0")
                if d.get("adj") is not None:
                    v = _dp_decimal(d["adj"])
                    if v is not None:
                        adj_val = v

                expected = (adj_val / net_val) if net_val != 0 else Decimal("0")
                if not _calc_equal(expected, etr_val):
                    num = 60025 if 60025 in error_map else None
                    issues.append(Issue(
                        severity="BLOCKING",
                        rule_id=_rid("OECD", f"60025|{filer_code}|{juris}|{ctx}|{etr_val}|{adj_val}|{net_val}"),
                        section="Jurisdiction",
                        xml_path=xp_etr,
                        filer_code=filer_code,
                        jurisdiction_code=juris,
                        context_key=ctx,
                        error_number=num,
                        message=(
                            f"ETRRate={etr_val} but expected approximately {_round4(expected)} (AdjustedCoveredTax={adj_val} / NetGlobeIncome={net_val})."
                        ),
                        how_to_fix=_oecd_fix_text(error_map, num) if num else "Recalculate ETRRate as AdjustedCoveredTax/Total divided by NetGlobeIncome/Total (4dp, allow 1% margin).",
                    ))

        # --- 60026 ---
        xp_topup = _pick_xpath(section="Jurisdiction", element_name="TopUpTax", must_contain="/overallcomputation/", must_end="/topuptax", must_not_contain="/additionaltopuptax/")
        xp_tup_pct = _pick_xpath(section="Jurisdiction", element_name="TopUpTaxPercentage", must_contain="/overallcomputation/", must_end="/topuptaxpercentage", must_not_contain="/additionaltopuptax/")
        xp_excess = _pick_xpath(section="Jurisdiction", element_name="ExcessProfits", must_contain="/overallcomputation/", must_end="/excessprofits", must_not_contain="/additionaltopuptax/")
        xp_add_non = _pick_xpath(section="Jurisdiction", element_name="AdditionalTopUpTax", must_contain="/overallcomputation/additionaltopuptax/nonart4.1.5/", must_end="/additionaltopuptax")
        xp_add_art = _pick_xpath(section="Jurisdiction", element_name="AdditionalTopUpTax", must_contain="/overallcomputation/additionaltopuptax/art4.1.5/", must_end="/additionaltopuptax")
        xp_qdmt_amt = _pick_xpath(section="Jurisdiction", element_name="Amount", must_contain="/overallcomputation/qdmt", must_end="/amount")

        if xp_topup:
            x_topup_lc = _norm_xpath(xp_topup).lower()
            x_pct_lc = _norm_xpath(xp_tup_pct).lower() if xp_tup_pct else ""
            x_exc_lc = _norm_xpath(xp_excess).lower() if xp_excess else ""
            x_non_lc = _norm_xpath(xp_add_non).lower() if xp_add_non else ""
            x_art_lc = _norm_xpath(xp_add_art).lower() if xp_add_art else ""
            x_qdmt_lc = _norm_xpath(xp_qdmt_amt).lower() if xp_qdmt_amt else ""

            groups2: Dict[Tuple[Optional[str], Optional[str], Optional[str]], Dict[str, List[models.DataPoint]]] = {}
            for dp in submission_dps:
                if not dp.jurisdiction_code:
                    continue
                xp = _dp_xpath_lc(dp)
                if xp not in {x_topup_lc, x_pct_lc, x_exc_lc, x_non_lc, x_art_lc, x_qdmt_lc}:
                    continue
                gk = (dp.filer_code or None, dp.jurisdiction_code, dp.context_key or None)
                d = groups2.setdefault(gk, {})
                if xp == x_topup_lc:
                    d.setdefault("topup", []).append(dp)
                elif xp == x_pct_lc:
                    d.setdefault("pct", []).append(dp)
                elif xp == x_exc_lc:
                    d.setdefault("excess", []).append(dp)
                elif xp == x_non_lc:
                    d.setdefault("non", []).append(dp)
                elif xp == x_art_lc:
                    d.setdefault("art", []).append(dp)
                elif xp == x_qdmt_lc:
                    d.setdefault("qdmt", []).append(dp)


            for (filer_code, juris, ctx), d in groups2.items():
                if "topup" not in d:
                    continue
                topup_val = _first_dec(d.get("topup", []))
                pct_val = _first_dec(d.get("pct", []))
                excess_val = _first_dec(d.get("excess", []))
                non_val = _first_dec(d.get("non", []))
                art_val = _first_dec(d.get("art", []))
                qdmt_val = _first_dec(d.get("qdmt", []))

                expected = (pct_val * excess_val) + (non_val + art_val) - qdmt_val
                if not _calc_equal(expected, topup_val):
                    num = 60026 if 60026 in error_map else None
                    issues.append(Issue(
                        severity="BLOCKING",
                        rule_id=_rid("OECD", f"60026|{filer_code}|{juris}|{ctx}|{topup_val}|{pct_val}|{excess_val}|{non_val}|{art_val}|{qdmt_val}"),
                        section="Jurisdiction",
                        xml_path=xp_topup,
                        filer_code=filer_code,
                        jurisdiction_code=juris,
                        context_key=ctx,
                        error_number=num,
                        message=(
                            f"TopUpTax={topup_val} but expected approximately {_round4(expected)} "
                            f"(TopUpTaxPercentage={pct_val} * ExcessProfits={excess_val} + AdditionalTopUpTax={non_val + art_val} - QDMTT/Amount={qdmt_val})."
                        ),
                        how_to_fix=_oecd_fix_text(error_map, num) if num else "Recalculate TopUpTax per OECD formula (4dp, allow 1% margin).",
                    ))

        # --- 60027 ---
        xp_iir_topup = _pick_xpath(section="Jurisdiction", element_name="TopUpTax", must_contain="/iir/parententity/", must_end="/topuptax")
        xp_iir_share = _pick_xpath(section="Jurisdiction", element_name="TopUpTaxShare", must_contain="/iir/parententity/", must_end="/topuptaxshare")
        xp_iir_off = _pick_xpath(section="Jurisdiction", element_name="IIROffSet", must_contain="/iir/parententity/", must_end="/iiroffset")

        if xp_iir_topup:
            x_it_lc = _norm_xpath(xp_iir_topup).lower()
            x_is_lc = _norm_xpath(xp_iir_share).lower() if xp_iir_share else ""
            x_io_lc = _norm_xpath(xp_iir_off).lower() if xp_iir_off else ""

            groups3: Dict[Tuple[Optional[str], Optional[str], Optional[str]], Dict[str, List[models.DataPoint]]] = {}
            for dp in submission_dps:
                if not dp.jurisdiction_code:
                    continue
                xp = _dp_xpath_lc(dp)
                if xp not in {x_it_lc, x_is_lc, x_io_lc}:
                    continue
                gk = (dp.filer_code or None, dp.jurisdiction_code, dp.context_key or None)
                d = groups3.setdefault(gk, {})
                if xp == x_it_lc:
                    d.setdefault("topup", []).append(dp)
                elif xp == x_is_lc:
                    d.setdefault("share", []).append(dp)
                elif xp == x_io_lc:
                    d.setdefault("off", []).append(dp)

            for (filer_code, juris, ctx), d in groups3.items():
                if "topup" not in d:
                    continue
                topup_val = _first_dec(d.get("topup", []))
                share_val = _first_dec(d.get("share", []))
                off_val = _first_dec(d.get("off", []))

                expected = share_val - off_val
                if not _calc_equal(expected, topup_val):
                    num = 60027 if 60027 in error_map else None
                    issues.append(Issue(
                        severity="BLOCKING",
                        rule_id=_rid("OECD", f"60027|{filer_code}|{juris}|{ctx}|{topup_val}|{share_val}|{off_val}"),
                        section="Jurisdiction",
                        xml_path=xp_iir_topup,
                        filer_code=filer_code,
                        jurisdiction_code=juris,
                        context_key=ctx,
                        error_number=num,
                        message=(
                            f"IIR/ParentEntity/TopUpTax={topup_val} but expected approximately {_round4(expected)} "
                            f"(TopUpTaxShare={share_val} - IIROffSet={off_val})."
                        ),
                        how_to_fix=_oecd_fix_text(error_map, num) if num else "Recalculate IIR/ParentEntity/TopUpTax as TopUpTaxShare minus IIROffSet (4dp, allow 1% margin).",
                    ))

        # --- 60028 ---
        xp_af_total = _pick_xpath(section="Jurisdiction", element_name="Total", must_contain="/cecomputation/adjustedfanil/", must_end="/total")
        xp_af_fanil = _pick_xpath(section="Jurisdiction", element_name="FANIL", must_contain="/cecomputation/adjustedfanil/", must_end="/fanil")
        xp_af_add = _pick_xpath(section="Jurisdiction", element_name="Additions", must_contain="/cecomputation/adjustedfanil/adjustment/mainentitypeandfte/", must_end="/additions")
        xp_af_red = _pick_xpath(section="Jurisdiction", element_name="Reductions", must_contain="/cecomputation/adjustedfanil/adjustment/mainentitypeandfte/", must_end="/reductions")

        if xp_af_total and xp_af_fanil:
            x_tot_lc = _norm_xpath(xp_af_total).lower()
            x_fan_lc = _norm_xpath(xp_af_fanil).lower()
            x_add_lc = _norm_xpath(xp_af_add).lower() if xp_af_add else ""
            x_red_lc = _norm_xpath(xp_af_red).lower() if xp_af_red else ""

            # CEComputation is repeatable and also contains nested repeatable containers
            # (e.g., multiple MainEntityPEandFTE entries). The XML importer preserves these by
            # appending repeat-instance markers to context_key (base|MainEntityPEandFTE:2).
            # For 60028 we need to sum Additions/Reductions at the CEComputation row level, so
            # we group by the *base* context_key segment (before the first '|').
            def _ctx_base(v: Optional[str]) -> Optional[str]:
                if not v:
                    return None
                return str(v).split("|", 1)[0]

            groups4: Dict[Tuple[Optional[str], Optional[str], Optional[str], Optional[str]], Dict[str, List[models.DataPoint]]] = {}
            for dp in submission_dps:
                xp = _dp_xpath_lc(dp)
                if xp not in {x_tot_lc, x_fan_lc, x_add_lc, x_red_lc}:
                    continue
                gk = (dp.filer_code or None, dp.jurisdiction_code or None, dp.entity_code or None, _ctx_base(dp.context_key))
                d = groups4.setdefault(gk, {})
                if xp == x_tot_lc:
                    d.setdefault("total", []).append(dp)
                elif xp == x_fan_lc:
                    d.setdefault("fanil", []).append(dp)
                elif xp == x_add_lc:
                    d.setdefault("add", []).append(dp)
                elif xp == x_red_lc:
                    d.setdefault("red", []).append(dp)

            for (filer_code, juris, ent, ctx), d in groups4.items():
                if "total" not in d or "fanil" not in d:
                    continue
                total_val = _first_dec(d.get("total", []))
                fanil_val = _first_dec(d.get("fanil", []))
                add_sum = sum([_first_dec([dp]) for dp in d.get("add", [])], Decimal("0"))
                red_sum = sum([_first_dec([dp]) for dp in d.get("red", [])], Decimal("0"))

                expected = fanil_val + add_sum - red_sum
                if not _calc_equal(expected, total_val):
                    num = 60028 if 60028 in error_map else None
                    issues.append(Issue(
                        severity="BLOCKING",
                        rule_id=_rid("OECD", f"60028|{filer_code}|{juris}|{ent}|{ctx}|{total_val}|{fanil_val}|{add_sum}|{red_sum}"),
                        section="Jurisdiction",
                        xml_path=xp_af_total,
                        filer_code=filer_code,
                        jurisdiction_code=juris,
                        entity_code=ent,
                        context_key=ctx,
                        error_number=num,
                        message=(
                            f"AdjustedFANIL/Total={total_val} but expected approximately {_round4(expected)} "
                            f"(FANIL={fanil_val} + Additions={add_sum} - Reductions={red_sum})."
                        ),
                        how_to_fix=_oecd_fix_text(error_map, num) if num else "Recalculate AdjustedFANIL/Total per OECD formula (4dp, allow 1% margin).",
                    ))

    except Exception:
        # Calculations are best-effort; do not fail the overall run if inputs are missing/invalid.
        pass

    # -----------------------------
    # Stage 4.7: Attribute-driven OECD record errors (TIN) — 70001–70007
    # -----------------------------
    #
    # The OECD Status Message guidance defines several record errors that are specifically
    # driven by XML attributes on the TIN type (issuedBy / unknown / TypeOfTIN).
    # See Status Message User Guide Part 4 (70001–70007).
    #
    # We only run these checks when the latest submission is XML (or when attribute mode is forced on),
    # to avoid false positives for XLSX/CSV uploads which generally cannot represent XML attributes.
    try:
        tin_rules_enabled = False
        if arm != "off":
            if arm == "on":
                tin_rules_enabled = True
            elif arm == "auto":
                tin_rules_enabled = bool(
                    current_submission
                    and (current_submission.source_type or "").strip().lower() == "xml"
                )

        if tin_rules_enabled:
            filer_juris: Dict[str, str] = {
                (f.filer_code or "").strip(): (f.jurisdiction_code or "").strip()
                for f in filers
                if (f.filer_code or "").strip()
            }
            entity_juris: Dict[str, str] = {
                (e.entity_code or "").strip(): (e.jurisdiction_code or "").strip()
                for e in entity_rows
                if (e.entity_code or "").strip()
            }

            # 70006 exception needs CE/ID/GloBEStatus for the same entity (GIR316 / GIR318).
            ce_globe_status_xpath = _find_xpath(
                config,
                section="General",
                endswith="/CorporateStructure/CE/ID/GloBEStatus",
            ) or _find_xpath(config, endswith="/CorporateStructure/CE/ID/GloBEStatus")
            ce_globe_status_xpath_lc = _norm_xpath(ce_globe_status_xpath).lower() if ce_globe_status_xpath else ""

            globe_status_by_entity: Dict[str, str] = {}
            if ce_globe_status_xpath_lc:
                for dp in submission_dps:
                    ec = (dp.entity_code or "").strip()
                    if not ec:
                        continue
                    if _dp_xpath_lc(dp) != ce_globe_status_xpath_lc:
                        continue
                    v = (dp.value_raw or "").strip()
                    if v:
                        globe_status_by_entity[ec] = v

            # Group all TIN datapoints by their base element path + scope keys.
            # Base path example: /.../ID/TIN
            # Attribute path examples: /.../ID/TIN/@TypeOfTIN, /.../ID/TIN/@issuedBy, /.../ID/TIN/@unknown
            def _base_tin_path(xp: Optional[str]) -> Optional[str]:
                if not xp:
                    return None
                nx = _norm_xpath(xp)
                if "/@" in nx:
                    base = nx.split("/@", 1)[0]
                else:
                    base = nx
                return base if base.lower().endswith("/tin") else None

            groups: Dict[
                Tuple[Optional[str], Optional[str], Optional[str], Optional[str], str],
                Dict[str, Optional[str]],
            ] = {}

            for dp in submission_dps:
                base = _base_tin_path(dp.xml_path)
                if not base:
                    continue

                key = (dp.filer_code or None, dp.jurisdiction_code or None, dp.entity_code or None, dp.context_key or None, base)
                g = groups.get(key)
                if g is None:
                    g = {
                        "base": base,
                        "tin": None,
                        "typeoftin": None,
                        "issuedby": None,
                        "unknown": None,
                        "filer_code": dp.filer_code,
                        "jurisdiction_code": dp.jurisdiction_code,
                        "entity_code": dp.entity_code,
                        "context_key": dp.context_key,
                    }
                    groups[key] = g

                nx = _norm_xpath(dp.xml_path or "")
                val = (dp.value_raw or "").strip()

                if nx == base:
                    if val:
                        g["tin"] = val
                    continue

                # Attribute
                if "/@" not in nx:
                    continue
                attr = nx.split("/@", 1)[1].strip()
                if not attr:
                    continue
                attr_lc = attr.lower()

                if val == "":
                    # treat empty attribute as absent for these rules
                    continue

                if attr_lc == "typeoftin":
                    g["typeoftin"] = val
                elif attr_lc == "issuedby":
                    g["issuedby"] = val
                elif attr_lc == "unknown":
                    g["unknown"] = val

            # Common helpers
            def _issue(
                *,
                number: int,
                base: str,
                xml_path: str,
                message: str,
                filer_code: Optional[str],
                jurisdiction_code: Optional[str],
                entity_code: Optional[str],
                context_key: Optional[str],
            ) -> None:
                num = number if number in error_map else None
                issues.append(Issue(
                    severity="BLOCKING",
                    rule_id=_rid("OECD", f"{number}|{xml_path}|{filer_code}|{jurisdiction_code}|{entity_code}|{context_key}|{message}"),
                    section="General",
                    xml_path=xml_path,
                    filer_code=filer_code,
                    jurisdiction_code=jurisdiction_code,
                    entity_code=entity_code,
                    context_key=context_key,
                    error_number=num,
                    message=message,
                    how_to_fix=_oecd_fix_text(error_map, num) if num else None,
                ))

            # -----------------------------
            # Stage 4.8: OECD 70025 (OwnershipType GIR805/GIR806 => NOTIN + TypeOfTIN GIR3004)
            # -----------------------------
            # The OECD catalogue includes an attribute-driven rule outside the core TIN block.
            # When OwnershipType indicates an ownership type that requires NOTIN (GIR805/GIR806),
            # the associated ownership TIN must use the NOTIN convention (TypeOfTIN=GIR3004 and value NOTIN).
            #
            # We scope within the same (filer, jurisdiction, entity, context_key) so repeated OwnershipChange
            # list entries (IDX scopes) are validated independently.
            try:
                own_type_xps = [
                    _find_xpath(config, endswith="/CorporateStructure/CE/Ownership/OwnershipType"),
                    _find_xpath(config, endswith="/CorporateStructure/CE/OwnershipChange/PreOwnership/OwnershipType"),
                ]
                own_type_xps_lc = {
                    _norm_xpath(xp).lower() for xp in own_type_xps if (xp or "").strip()
                }

                # Build a lookup of datapoints by scope key + normalized xpath.
                scope_idx: Dict[
                    Tuple[Optional[str], Optional[str], Optional[str], Optional[str]],
                    Dict[str, List[models.DataPoint]],
                ] = {}
                for dp in submission_dps:
                    sk = (dp.filer_code or None, dp.jurisdiction_code or None, dp.entity_code or None, dp.context_key or None)
                    scope_idx.setdefault(sk, {}).setdefault(_dp_xpath_lc(dp), []).append(dp)

                def _first_val(dps: List[models.DataPoint]) -> str:
                    if not dps:
                        return ""
                    return (dps[0].value_raw or "").strip()

                for dp in submission_dps:
                    xp_lc = _dp_xpath_lc(dp)
                    if own_type_xps_lc and xp_lc not in own_type_xps_lc:
                        continue
                    own_val = (dp.value_raw or "").strip()
                    if own_val not in {"GIR805", "GIR806"}:
                        continue

                    parent = _norm_xpath(dp.xml_path or "")
                    if not parent:
                        continue
                    parent = parent.rsplit("/", 1)[0]
                    tin_base = f"{parent}/TIN"
                    tin_base_lc = tin_base.lower()
                    tin_type_lc = f"{tin_base}/@typeoftin".lower()

                    sk = (dp.filer_code or None, dp.jurisdiction_code or None, dp.entity_code or None, dp.context_key or None)
                    m = scope_idx.get(sk, {})
                    tin_val = _first_val(m.get(tin_base_lc, []))
                    typ_val = _first_val(m.get(tin_type_lc, []))

                    ok = (tin_val.upper() == "NOTIN") and (typ_val == "GIR3004")
                    if not ok:
                        _issue(
                            number=70025,
                            base=tin_base,
                            xml_path=_norm_xpath(dp.xml_path or "") or dp.xml_path or tin_base,
                            message=(
                                f"OwnershipType is '{own_val}', so the associated ownership TIN must be 'NOTIN' "
                                "with TypeOfTIN='GIR3004'. "
                                f"Observed TIN='{tin_val or '∅'}', TypeOfTIN='{typ_val or '∅'}'."
                            ),
                            filer_code=dp.filer_code,
                            jurisdiction_code=dp.jurisdiction_code,
                            entity_code=dp.entity_code,
                            context_key=dp.context_key,
                        )
            except Exception:
                pass

            # 70006 target path list (normalized, no namespaces)
            t70006_suffixes = [
                "/GLOBE_OECD/GLOBEBody/GeneralSection/CorporateStructure/UPE/ExcludedUPE/ID/TIN",
                "/GLOBE_OECD/GLOBEBody/GeneralSection/CorporateStructure/UPE/OtherUPE/ID/TIN",
                "/GLOBE_OECD/GLOBEBody/GeneralSection/CorporateStructure/CE/ID/TIN",
                "/GLOBE_OECD/GLOBEBody/GeneralSection/CorporateStructure/CE/QIIR/Exception/TIN",
                "/GLOBE_OECD/GLOBEBody/JurisdictionSection/GLoBETax/ETR/ETRStatus/ETRComputation/CEComputation/Elections/AggregatedReporting/TaxConsolGroupTIN",
            ]
            t70006_suffixes_lc = [s.lower() for s in t70006_suffixes]

            # 70007 regex (designated reference for TypeOfTIN GIR3003)
            # Format: P2JJYYYYMMDDCCCXXX
            # - P2 constant
            # - JJ ISO country code (2 letters)
            # - YYYYMMDD date
            # - CCC 3-letter group ref
            # - XXX 3-digit unique number
            t70007_re = re.compile(r"^P2[A-Z]{2}\d{8}[A-Z]{3}\d{3}$")

            for g in groups.values():
                base = (g.get("base") or "").strip()
                tin_val = (g.get("tin") or "").strip()
                typ = (g.get("typeoftin") or "").strip()
                issued = (g.get("issuedby") or "").strip()
                unk = _parse_bool(g.get("unknown"))
                unk_true = (unk is True)

                fc = g.get("filer_code")
                jc = g.get("jurisdiction_code")
                ec = g.get("entity_code")
                ck = g.get("context_key")

                # 70005: Attributes issuedBy and TypeOfTIN must always be present,
                # except issuedBy is not required when TypeOfTIN is GIR3003 or GIR3004.
                if not typ:
                    _issue(
                        number=70005,
                        base=base,
                        xml_path=f"{base}/@TypeOfTIN",
                        message="TIN is missing required attribute TypeOfTIN.",
                        filer_code=fc,
                        jurisdiction_code=jc,
                        entity_code=ec,
                        context_key=ck,
                    )
                    # Without TypeOfTIN we cannot apply dependent rules reliably.
                    continue

                if (typ not in {"GIR3003", "GIR3004"}) and (not issued):
                    _issue(
                        number=70005,
                        base=base,
                        xml_path=f"{base}/@issuedBy",
                        message=f"TIN is missing required attribute issuedBy for TypeOfTIN='{typ}'.",
                        filer_code=fc,
                        jurisdiction_code=jc,
                        entity_code=ec,
                        context_key=ck,
                    )

                # 70001/70002/70003: NOTIN / GIR3004 / Unknown / issuedBy consistency
                if typ == "GIR3004":
                    ok = (tin_val.upper() == "NOTIN") and unk_true and (not issued)
                    if not ok:
                        _issue(
                            number=70001,
                            base=base,
                            xml_path=f"{base}/@TypeOfTIN",
                            message=(
                                "TypeOfTIN is GIR3004, so TIN must be 'NOTIN', unknown must be TRUE, "
                                "and issuedBy must NOT be provided."
                            ),
                            filer_code=fc,
                            jurisdiction_code=jc,
                            entity_code=ec,
                            context_key=ck,
                        )
                elif tin_val.upper() == "NOTIN":
                    ok = (typ == "GIR3004") and unk_true and (not issued)
                    if not ok:
                        _issue(
                            number=70002,
                            base=base,
                            xml_path=base,
                            message=(
                                "TIN value is 'NOTIN', so TypeOfTIN must be GIR3004, unknown must be TRUE, "
                                "and issuedBy must NOT be provided."
                            ),
                            filer_code=fc,
                            jurisdiction_code=jc,
                            entity_code=ec,
                            context_key=ck,
                        )
                elif unk_true:
                    ok = (tin_val.upper() == "NOTIN") and (typ == "GIR3004") and (not issued)
                    if not ok:
                        _issue(
                            number=70003,
                            base=base,
                            xml_path=f"{base}/@unknown",
                            message=(
                                "TIN is flagged unknown=TRUE, so TIN must be 'NOTIN', TypeOfTIN must be GIR3004, "
                                "and issuedBy must NOT be provided."
                            ),
                            filer_code=fc,
                            jurisdiction_code=jc,
                            entity_code=ec,
                            context_key=ck,
                        )


                # 70004: Where issuedBy is the local jurisdiction, validate TIN format for that jurisdiction.
                #
                # OECD notes this should only be applied by the issuing jurisdiction unless a TIN validation tool is available.
                # To avoid false positives, this validator ONLY applies 70004 when you configure BOTH:
                #   - LOCAL_JURISDICTION_CODE=<JJ>   (2-letter ISO code)
                #   - TIN_VALIDATION_REGEX_MAP_JSON='{"JJ":"<regex>", "AA":"<regex>", ...}'
                #
                # Example:
                #   LOCAL_JURISDICTION_CODE=GB
                #   TIN_VALIDATION_REGEX_MAP_JSON={"GB":"^[A-Z0-9]{1,20}$"}
                #
                # If not configured, 70004 is skipped.
                try:
                    import os as _os
                    import json as _json
                    _local = (_os.getenv("LOCAL_JURISDICTION_CODE") or "").strip().upper()
                    _rx_map_raw = (_os.getenv("TIN_VALIDATION_REGEX_MAP_JSON") or "").strip()
                    _rx_map = {}
                    if _local and _rx_map_raw:
                        try:
                            _rx_map = _json.loads(_rx_map_raw)
                        except Exception:
                            _rx_map = {}
                    if _local and _rx_map and issued and issued.strip().upper() == _local:
                        # Skip cases already handled by NOTIN/unknown logic
                        if typ not in {"GIR3004"} and (not unk_true) and tin_val:
                            pat = (_rx_map.get(_local) or "").strip()
                            if pat:
                                try:
                                    _re = re.compile(pat)
                                    if not _re.match(tin_val.strip()):
                                        _issue(
                                            number=70004,
                                            base=base,
                                            xml_path=f"{base}/@issuedBy",
                                            message=(
                                                f"TIN issuedBy='{_local}' does not match the configured local-jurisdiction "
                                                "TIN validation pattern."
                                            ),
                                            filer_code=fc,
                                            jurisdiction_code=jc,
                                            entity_code=ec,
                                            context_key=ck,
                                        )
                                except Exception:
                                    # Bad regex => skip validation
                                    pass
                except Exception:
                    pass

                # 70006: Certain key TINs must not use TypeOfTIN GIR3004 and must not be Unknown
                base_lc = _norm_xpath(base).lower()
                if any(base_lc.endswith(suf) for suf in t70006_suffixes_lc):
                    # Exception for CE/ID/TIN when GloBEStatus is GIR316 or GIR318
                    skip = False
                    if base_lc.endswith("/generalsection/corporatestructure/ce/id/tin"):
                        st = globe_status_by_entity.get((ec or "").strip(), "")
                        if st in {"GIR316", "GIR318"}:
                            skip = True
                    if not skip and (typ == "GIR3004" or unk_true):
                        _issue(
                            number=70006,
                            base=base,
                            xml_path=f"{base}/@TypeOfTIN",
                            message="This TIN must not use TypeOfTIN GIR3004 and must not be flagged unknown.",
                            filer_code=fc,
                            jurisdiction_code=jc,
                            entity_code=ec,
                            context_key=ck,
                        )

                # 70007: If TypeOfTIN is GIR3003, validate designated reference format
                if typ == "GIR3003" and tin_val:
                    tin_up = tin_val.strip().upper()
                    if not t70007_re.match(tin_up):
                        _issue(
                            number=70007,
                            base=base,
                            xml_path=base,
                            message=(
                                "TypeOfTIN is GIR3003, so TIN must follow the designated reference format "
                                "P2JJYYYYMMDDCCCXXX (e.g., P2GB20250101ABC001)."
                            ),
                            filer_code=fc,
                            jurisdiction_code=jc,
                            entity_code=ec,
                            context_key=ck,
                        )
                    else:
                        # Extra check: JJ should match entity/filer jurisdiction when we can infer it.
                        jj = tin_up[2:4]
                        expected = ""
                        if ec and (ec or "").strip() in entity_juris:
                            expected = (entity_juris.get((ec or "").strip()) or "").strip().upper()
                        elif fc and (fc or "").strip() in filer_juris:
                            expected = (filer_juris.get((fc or "").strip()) or "").strip().upper()
                        elif jc:
                            expected = (jc or "").strip().upper()
                        if expected and jj and expected != jj:
                            _issue(
                                number=70007,
                                base=base,
                                xml_path=base,
                                message=(
                                    f"TypeOfTIN is GIR3003 and TIN reference begins with JJ='{jj}', but the "
                                    f"inferred jurisdiction is '{expected}'. JJ should match the jurisdiction of location."
                                ),
                                filer_code=fc,
                                jurisdiction_code=jc,
                                entity_code=ec,
                                context_key=ck,
                            )
                        # Validate date chunk is a real date (YYYYMMDD)
                        try:
                            _ = datetime.strptime(tin_up[4:12], "%Y%m%d")
                        except Exception:
                            _issue(
                                number=70007,
                                base=base,
                                xml_path=base,
                                message=(
                                    f"TypeOfTIN is GIR3003, but the YYYYMMDD segment '{tin_up[4:12]}' is not a valid date."
                                ),
                                filer_code=fc,
                                jurisdiction_code=jc,
                                entity_code=ec,
                                context_key=ck,
                            )
    except Exception:
        # Non-fatal: attribute-driven rules are best-effort.
        pass


    # -----------------------------
    # Stage 7: OECD CorporateStructure / Ownership / UTPR record errors — 70008–70035
    # -----------------------------
    #
    # These are additional OECD “Other record errors” that are not pure XSD constraints.
    # They primarily relate to:
    #   - CorporateStructure (UPE/CE status consistency, ownership rules)
    #   - OwnershipChange date window checks
    #   - QIIR / POPE-IPE exception flags
    #   - UTPRAttribution RecJurCode validation
    try:
        # Helper for consistent OECD issue emission.
        def _oecd_issue(
            *,
            number: int,
            severity: str,
            xml_path: Optional[str],
            message: str,
            filer_code: Optional[str] = None,
            jurisdiction_code: Optional[str] = None,
            entity_code: Optional[str] = None,
            context_key: Optional[str] = None,
        ) -> None:
            num = number if number in error_map else None
            issues.append(Issue(
                severity=severity,
                rule_id=_rid(
                    "OECD",
                    f"{number}|{xml_path}|{filer_code}|{jurisdiction_code}|{entity_code}|{context_key}|{message}",
                ),
                section="General",
                xml_path=xml_path,
                filer_code=filer_code,
                jurisdiction_code=jurisdiction_code,
                entity_code=entity_code,
                context_key=context_key,
                error_number=num,
                message=message,
                how_to_fix=_oecd_fix_text(error_map, num) if num else None,
            ))

        def _truthy(v: str) -> bool:
            vv = (v or "").strip().lower()
            return vv in {"1", "true", "t", "yes", "y"}

        # --- Locate xpaths used by these rules ---
        xp_utpr_rec = _find_xpath(config, endswith="/UTPRAttribution/RecJurCode")
        xp_jwtr_name = _find_xpath(config, endswith="/JurisdictionSection/JurWithTaxingRights/JurisdictionName")

        xp_upe_other_res = _find_xpath(config, endswith="/CorporateStructure/UPE/OtherUPE/ID/ResCountryCode")
        xp_upe_excl_res = _find_xpath(config, endswith="/CorporateStructure/UPE/ExcludedUPE/ID/ResCountryCode")
        xp_upe_other_rules = _find_xpath(config, endswith="/CorporateStructure/UPE/OtherUPE/ID/Rules")
        xp_upe_excl_rules = _find_xpath(config, endswith="/CorporateStructure/UPE/ExcludedUPE/ID/Rules")
        xp_upe_other_globe = _find_xpath(config, endswith="/CorporateStructure/UPE/OtherUPE/ID/GloBEStatus")
        xp_upe_excl_globe = _find_xpath(config, endswith="/CorporateStructure/UPE/ExcludedUPE/ID/GloBEStatus")
        xp_upe_other_tin = _find_xpath(config, endswith="/CorporateStructure/UPE/OtherUPE/ID/TIN")
        xp_upe_excl_tin = _find_xpath(config, endswith="/CorporateStructure/UPE/ExcludedUPE/ID/TIN")

        xp_ce_globe = _find_xpath(config, endswith="/CorporateStructure/CE/ID/GloBEStatus")
        xp_ce_res = _find_xpath(config, endswith="/CorporateStructure/CE/ID/ResCountryCode")
        xp_ce_rules = _find_xpath(config, endswith="/CorporateStructure/CE/ID/Rules")
        xp_ce_id_tin = _find_xpath(config, endswith="/CorporateStructure/CE/ID/TIN")

        xp_own_pct = _find_xpath(config, endswith="/CorporateStructure/CE/Ownership/OwnershipPercentage")
        xp_own_tin = _find_xpath(config, endswith="/CorporateStructure/CE/Ownership/TIN")
        xp_own_type = _find_xpath(config, endswith="/CorporateStructure/CE/Ownership/OwnershipType")

        xp_ownchg_date = _find_xpath(config, endswith="/CorporateStructure/CE/OwnershipChange/ChangeDate")
        xp_pre_globe = _find_xpath(config, endswith="/CorporateStructure/CE/OwnershipChange/PreGlobeStatus")
        xp_pre_own_tin = _find_xpath(config, endswith="/CorporateStructure/CE/OwnershipChange/PreOwnership/TIN")

        xp_qiir_pope_ipe = _find_xpath(config, endswith="/CorporateStructure/CE/QIIR/POPE-IPE")
        xp_qiir_exc_tin = _find_xpath(config, endswith="/CorporateStructure/CE/QIIR/Exception/TIN")
        xp_qiir_art213 = _find_xpath(config, endswith="/CorporateStructure/CE/QIIR/Exception/ExceptionRule/Art2.1.3")
        xp_qiir_art215 = _find_xpath(config, endswith="/CorporateStructure/CE/QIIR/Exception/ExceptionRule/Art2.1.5")

        # Normalize to lowercase for fast comparisons.
        xp_utpr_rec_lc = _norm_xpath(xp_utpr_rec).lower() if xp_utpr_rec else ""
        xp_jwtr_name_lc = _norm_xpath(xp_jwtr_name).lower() if xp_jwtr_name else ""

        xp_upe_other_res_lc = _norm_xpath(xp_upe_other_res).lower() if xp_upe_other_res else ""
        xp_upe_excl_res_lc = _norm_xpath(xp_upe_excl_res).lower() if xp_upe_excl_res else ""
        xp_upe_other_rules_lc = _norm_xpath(xp_upe_other_rules).lower() if xp_upe_other_rules else ""
        xp_upe_excl_rules_lc = _norm_xpath(xp_upe_excl_rules).lower() if xp_upe_excl_rules else ""
        xp_upe_other_globe_lc = _norm_xpath(xp_upe_other_globe).lower() if xp_upe_other_globe else ""
        xp_upe_excl_globe_lc = _norm_xpath(xp_upe_excl_globe).lower() if xp_upe_excl_globe else ""
        xp_upe_other_tin_lc = _norm_xpath(xp_upe_other_tin).lower() if xp_upe_other_tin else ""
        xp_upe_excl_tin_lc = _norm_xpath(xp_upe_excl_tin).lower() if xp_upe_excl_tin else ""

        xp_ce_globe_lc = _norm_xpath(xp_ce_globe).lower() if xp_ce_globe else ""
        xp_ce_res_lc = _norm_xpath(xp_ce_res).lower() if xp_ce_res else ""
        xp_ce_rules_lc = _norm_xpath(xp_ce_rules).lower() if xp_ce_rules else ""
        xp_ce_id_tin_lc = _norm_xpath(xp_ce_id_tin).lower() if xp_ce_id_tin else ""

        xp_own_pct_lc = _norm_xpath(xp_own_pct).lower() if xp_own_pct else ""
        xp_own_tin_lc = _norm_xpath(xp_own_tin).lower() if xp_own_tin else ""
        xp_own_type_lc = _norm_xpath(xp_own_type).lower() if xp_own_type else ""

        xp_ownchg_date_lc = _norm_xpath(xp_ownchg_date).lower() if xp_ownchg_date else ""
        xp_pre_globe_lc = _norm_xpath(xp_pre_globe).lower() if xp_pre_globe else ""
        xp_pre_own_tin_lc = _norm_xpath(xp_pre_own_tin).lower() if xp_pre_own_tin else ""

        xp_qiir_pope_ipe_lc = _norm_xpath(xp_qiir_pope_ipe).lower() if xp_qiir_pope_ipe else ""
        xp_qiir_exc_tin_lc = _norm_xpath(xp_qiir_exc_tin).lower() if xp_qiir_exc_tin else ""
        xp_qiir_art213_lc = _norm_xpath(xp_qiir_art213).lower() if xp_qiir_art213 else ""
        xp_qiir_art215_lc = _norm_xpath(xp_qiir_art215).lower() if xp_qiir_art215 else ""

        # -----------------------------
        # 70008: UTPRAttribution/RecJurCode allowed values (UPE jurisdiction or JurWithTaxingRights)
        # -----------------------------
        # Build UPE jurisdiction set and JWTR index by jurisdiction section.
        upe_juris: Set[str] = set()
        if xp_upe_other_res_lc or xp_upe_excl_res_lc:
            for dp in submission_dps:
                xp = _dp_xpath_lc(dp)
                if xp in {xp_upe_other_res_lc, xp_upe_excl_res_lc}:
                    v = (dp.value_raw or "").strip().upper()
                    if v:
                        upe_juris.add(v)

        jwtr_by_juris: Dict[Optional[str], Set[str]] = {}
        if xp_jwtr_name_lc:
            for dp in submission_dps:
                if _dp_xpath_lc(dp) != xp_jwtr_name_lc:
                    continue
                v = (dp.value_raw or "").strip().upper()
                if not v:
                    continue
                jwtr_by_juris.setdefault(dp.jurisdiction_code or None, set()).add(v)

        if xp_utpr_rec_lc:
            all_jwtr = set().union(*jwtr_by_juris.values()) if jwtr_by_juris else set()
            for dp in submission_dps:
                if _dp_xpath_lc(dp) != xp_utpr_rec_lc:
                    continue
                rec = (dp.value_raw or "").strip().upper()
                if not rec:
                    continue
                allowed = set(upe_juris)
                if dp.jurisdiction_code is not None and dp.jurisdiction_code in jwtr_by_juris:
                    allowed |= jwtr_by_juris.get(dp.jurisdiction_code, set())
                else:
                    allowed |= all_jwtr
                if allowed and rec not in allowed:
                    _oecd_issue(
                        number=70008,
                        severity="BLOCKING",
                        xml_path=dp.xml_path,
                        filer_code=dp.filer_code,
                        jurisdiction_code=dp.jurisdiction_code,
                        entity_code=dp.entity_code,
                        context_key=dp.context_key,
                        message=(
                            f"RecJurCode '{rec}' is not permitted. It must be the UPE jurisdiction "
                            f"({', '.join(sorted(upe_juris)) or '∅'}) or one of the JurWithTaxingRights jurisdictions "
                            "for the relevant JurisdictionSection."
                        ),
                    )

        # -----------------------------
        # Build CorporateStructure indexes for CE + UPE
        # -----------------------------
        ce_statuses: Dict[str, Set[str]] = {}
        if xp_ce_globe_lc:
            for dp in submission_dps:
                if _dp_xpath_lc(dp) != xp_ce_globe_lc:
                    continue
                ec = (dp.entity_code or "").strip()
                if not ec:
                    continue
                v = (dp.value_raw or "").strip()
                if v:
                    ce_statuses.setdefault(ec, set()).add(v)

        # UPE status + identifiers
        upe_statuses: Set[str] = set()
        if xp_upe_other_globe_lc or xp_upe_excl_globe_lc:
            for dp in submission_dps:
                if _dp_xpath_lc(dp) in {xp_upe_other_globe_lc, xp_upe_excl_globe_lc}:
                    v = (dp.value_raw or "").strip()
                    if v:
                        upe_statuses.add(v)

        # Entity TIN lookup (CE/ID/TIN)
        ce_tin_by_entity: Dict[str, str] = {}
        tin_to_entities: Dict[str, Set[str]] = {}
        if xp_ce_id_tin_lc:
            for dp in submission_dps:
                if _dp_xpath_lc(dp) != xp_ce_id_tin_lc:
                    continue
                ec = (dp.entity_code or "").strip()
                if not ec:
                    continue
                v = (dp.value_raw or "").strip()
                if not v:
                    continue
                # prefer first seen
                if ec not in ce_tin_by_entity:
                    ce_tin_by_entity[ec] = v
                tin_to_entities.setdefault(v, set()).add(ec)

        ce_tins: Set[str] = set(tin_to_entities.keys())

        # UPE TIN set (OtherUPE/ID/TIN or ExcludedUPE/ID/TIN)
        upe_tins: Set[str] = set()
        if xp_upe_other_tin_lc or xp_upe_excl_tin_lc:
            for dp in submission_dps:
                if _dp_xpath_lc(dp) in {xp_upe_other_tin_lc, xp_upe_excl_tin_lc}:
                    v = (dp.value_raw or "").strip()
                    if v:
                        upe_tins.add(v)

        # -----------------------------
        # 70009: Invalid UPE GloBEStatus values
        # -----------------------------
        invalid_upe = {"GIR305", "GIR307", "GIR308", "GIR309", "GIR312", "GIR313", "GIR314", "GIR315", "GIR317", "GIR318"}
        if (xp_upe_other_globe_lc or xp_upe_excl_globe_lc) and invalid_upe:
            for dp in submission_dps:
                if _dp_xpath_lc(dp) not in {xp_upe_other_globe_lc, xp_upe_excl_globe_lc}:
                    continue
                v = (dp.value_raw or "").strip()
                if v in invalid_upe:
                    _oecd_issue(
                        number=70009,
                        severity="BLOCKING",
                        xml_path=dp.xml_path,
                        filer_code=dp.filer_code,
                        jurisdiction_code=dp.jurisdiction_code,
                        message=f"UPE GloBEStatus '{v}' is not permitted for the UPE.",
                    )

        # -----------------------------
        # 70010: Only one ResCountryCode allowed for UPE/OtherUPE
        # -----------------------------
        if xp_upe_other_res_lc:
            # Count occurrences across the submission (choice group means there should be at most one).
            seen: List[models.DataPoint] = [dp for dp in submission_dps if _dp_xpath_lc(dp) == xp_upe_other_res_lc]
            if len(seen) > 1:
                vals = sorted({(dp.value_raw or "").strip().upper() for dp in seen if (dp.value_raw or "").strip()})
                _oecd_issue(
                    number=70010,
                    severity="BLOCKING",
                    xml_path=xp_upe_other_res,
                    message=f"More than one ResCountryCode was provided for UPE/OtherUPE: {', '.join(vals) or '∅'}.",
                )

        # -----------------------------
        # 70011: Only one ResCountryCode allowed per CE
        # -----------------------------
        if xp_ce_res_lc:
            by_ent: Dict[str, List[models.DataPoint]] = {}
            for dp in submission_dps:
                if _dp_xpath_lc(dp) != xp_ce_res_lc:
                    continue
                ec = (dp.entity_code or "").strip()
                if not ec:
                    continue
                by_ent.setdefault(ec, []).append(dp)
            for ec, arr in by_ent.items():
                if len(arr) > 1:
                    vals = sorted({(dp.value_raw or "").strip().upper() for dp in arr if (dp.value_raw or "").strip()})
                    _oecd_issue(
                        number=70011,
                        severity="BLOCKING",
                        xml_path=xp_ce_res,
                        entity_code=ec,
                        message=f"More than one ResCountryCode was provided for CE '{ec}': {', '.join(vals) or '∅'}.",
                    )

        # -----------------------------
        # 70012: Entities in same ResCountryCode must share the same Rules (ignoring GIR204)
        # -----------------------------
        # Collect rules per entity-like record.
        rules_by_key: Dict[str, Set[str]] = {}
        res_by_key: Dict[str, str] = {}

        # UPE (OtherUPE / ExcludedUPE)
        def _collect_single(prefix: str, xp_res_lc: str, xp_rules_lc: str) -> None:
            if not xp_res_lc:
                return
            # ResCountryCode
            for dp in submission_dps:
                if _dp_xpath_lc(dp) == xp_res_lc:
                    v = (dp.value_raw or "").strip().upper()
                    if v:
                        res_by_key[prefix] = v
                        break
            if not xp_rules_lc:
                return
            for dp in submission_dps:
                if _dp_xpath_lc(dp) != xp_rules_lc:
                    continue
                v = (dp.value_raw or "").strip()
                if v:
                    rules_by_key.setdefault(prefix, set()).add(v)

        _collect_single("UPE_OTHER", xp_upe_other_res_lc, xp_upe_other_rules_lc)
        _collect_single("UPE_EXCL", xp_upe_excl_res_lc, xp_upe_excl_rules_lc)

        # CEs
        if xp_ce_res_lc:
            for dp in submission_dps:
                if _dp_xpath_lc(dp) != xp_ce_res_lc:
                    continue
                ec = (dp.entity_code or "").strip()
                if not ec:
                    continue
                v = (dp.value_raw or "").strip().upper()
                if v:
                    res_by_key.setdefault(ec, v)
        if xp_ce_rules_lc:
            for dp in submission_dps:
                if _dp_xpath_lc(dp) != xp_ce_rules_lc:
                    continue
                ec = (dp.entity_code or "").strip()
                if not ec:
                    continue
                v = (dp.value_raw or "").strip()
                if v:
                    rules_by_key.setdefault(ec, set()).add(v)

        # Compare within each ResCountryCode.
        by_res: Dict[str, List[str]] = {}
        for key, res in res_by_key.items():
            if not res:
                continue
            by_res.setdefault(res, []).append(key)

        for res, keys in by_res.items():
            # Determine the canonical rule-set, ignoring GIR204.
            norm_sets: Dict[str, Set[str]] = {}
            for k in keys:
                s = set(rules_by_key.get(k, set()))
                s.discard("GIR204")
                norm_sets[k] = s
            unique = {frozenset(v) for v in norm_sets.values()}
            if len(unique) <= 1:
                continue
            # Emit issues for all keys in the jurisdiction (so users can reconcile).
            pretty = {k: ",".join(sorted(v)) or "∅" for k, v in norm_sets.items()}
            msg = " ; ".join([f"{k}=[{pretty[k]}]" for k in sorted(pretty.keys())])
            _oecd_issue(
                number=70012,
                severity="BLOCKING",
                xml_path=xp_ce_rules or xp_upe_other_rules or xp_upe_excl_rules,
                jurisdiction_code=res,
                message=(
                    f"Entities with ResCountryCode '{res}' have inconsistent Rules (ignoring GIR204): {msg}."
                ),
            )

        # -----------------------------
        # 70013–70021: CE GloBEStatus consistency rules
        # -----------------------------
        any_gir307 = any("GIR307" in s for s in ce_statuses.values())
        any_gir306 = any("GIR306" in s for s in ce_statuses.values())

        for ec, st in ce_statuses.items():
            # 70013: GIR313 and GIR314 cannot both be present
            if "GIR313" in st and "GIR314" in st:
                _oecd_issue(
                    number=70013,
                    severity="BLOCKING",
                    xml_path=xp_ce_globe,
                    entity_code=ec,
                    message="CE has both GloBEStatus GIR313 and GIR314; they must not be reported together.",
                )
            # 70014: GIR307 and GIR308 cannot both be present
            if "GIR307" in st and "GIR308" in st:
                _oecd_issue(
                    number=70014,
                    severity="BLOCKING",
                    xml_path=xp_ce_globe,
                    entity_code=ec,
                    message="CE has both GloBEStatus GIR307 and GIR308; they must not be reported together.",
                )

            # 70016/70017: GIR307/308 should also include GIR309
            if "GIR307" in st and "GIR309" not in st:
                _oecd_issue(
                    number=70016,
                    severity="WARNING",
                    xml_path=xp_ce_globe,
                    entity_code=ec,
                    message="CE has GloBEStatus GIR307 but is missing GIR309, which should also be reported.",
                )
            if "GIR308" in st and "GIR309" not in st:
                _oecd_issue(
                    number=70017,
                    severity="WARNING",
                    xml_path=xp_ce_globe,
                    entity_code=ec,
                    message="CE has GloBEStatus GIR308 but is missing GIR309, which should also be reported.",
                )

            # 70018: GIR305 and GIR306 cannot both be present
            if "GIR305" in st and "GIR306" in st:
                _oecd_issue(
                    number=70018,
                    severity="BLOCKING",
                    xml_path=xp_ce_globe,
                    entity_code=ec,
                    message="CE has both GloBEStatus GIR305 and GIR306; they must not be reported together.",
                )

            # 70020: GIR316/GIR318 should be the only GloBEStatus value
            if ("GIR316" in st or "GIR318" in st) and len(st) > 1:
                _oecd_issue(
                    number=70020,
                    severity="WARNING",
                    xml_path=xp_ce_globe,
                    entity_code=ec,
                    message=(
                        "CE has GloBEStatus GIR316/GIR318 but also other GloBEStatus values; GIR316 or GIR318 should be the only value."
                    ),
                )

        # 70015: GIR308 requires another CE with GIR307
        if not any_gir307:
            for ec, st in ce_statuses.items():
                if "GIR308" in st:
                    _oecd_issue(
                        number=70015,
                        severity="BLOCKING",
                        xml_path=xp_ce_globe,
                        entity_code=ec,
                        message=(
                            "A CE is reported with GloBEStatus GIR308, but no other CE in CorporateStructure has GloBEStatus GIR307."
                        ),
                    )

        # 70019: GIR305 requires another CE with GIR306
        if not any_gir306:
            for ec, st in ce_statuses.items():
                if "GIR305" in st:
                    _oecd_issue(
                        number=70019,
                        severity="BLOCKING",
                        xml_path=xp_ce_globe,
                        entity_code=ec,
                        message=(
                            "A CE is reported with GloBEStatus GIR305 (PE), but no other CE in CorporateStructure has GloBEStatus GIR306 (main entity)."
                        ),
                    )

        # 70021: GIR316/GIR318 requires a completed OwnershipChange (ID/TIN must match PreOwnership/TIN)
        if xp_pre_own_tin_lc and xp_ce_id_tin_lc:
            pre_tins_by_ent: Dict[str, Set[str]] = {}
            for dp in submission_dps:
                if _dp_xpath_lc(dp) != xp_pre_own_tin_lc:
                    continue
                ec = (dp.entity_code or "").strip()
                if not ec:
                    continue
                v = (dp.value_raw or "").strip()
                if v:
                    pre_tins_by_ent.setdefault(ec, set()).add(v)

            for ec, st in ce_statuses.items():
                if "GIR316" not in st and "GIR318" not in st:
                    continue
                id_tin = ce_tin_by_entity.get(ec)
                if not id_tin:
                    continue
                if id_tin not in pre_tins_by_ent.get(ec, set()):
                    _oecd_issue(
                        number=70021,
                        severity="BLOCKING",
                        xml_path=xp_ce_globe,
                        entity_code=ec,
                        message=(
                            f"CE has GloBEStatus GIR316/GIR318, but no OwnershipChange is completed where PreOwnership/TIN matches CE/ID/TIN ('{id_tin}')."
                        ),
                    )

        # -----------------------------
        # 70022–70024: OwnershipChange date window + PreOwnership gating
        # -----------------------------
        if xp_ownchg_date_lc:
            for dp in submission_dps:
                if _dp_xpath_lc(dp) != xp_ownchg_date_lc:
                    continue
                dt = dp.value_date or try_parse_date((dp.value_raw or "").strip())
                if not dt:
                    continue
                if filing.period_start and dt < filing.period_start:
                    _oecd_issue(
                        number=70022,
                        severity="BLOCKING",
                        xml_path=dp.xml_path,
                        filer_code=dp.filer_code,
                        jurisdiction_code=dp.jurisdiction_code,
                        entity_code=dp.entity_code,
                        context_key=dp.context_key,
                        message=(
                            f"OwnershipChange/ChangeDate {dt.isoformat()} is before FilingInfo Period Start {filing.period_start.isoformat()}."
                        ),
                    )
                if filing.period_end and dt > filing.period_end:
                    _oecd_issue(
                        number=70023,
                        severity="BLOCKING",
                        xml_path=dp.xml_path,
                        filer_code=dp.filer_code,
                        jurisdiction_code=dp.jurisdiction_code,
                        entity_code=dp.entity_code,
                        context_key=dp.context_key,
                        message=(
                            f"OwnershipChange/ChangeDate {dt.isoformat()} is after FilingInfo Period End {filing.period_end.isoformat()}."
                        ),
                    )

        # 70024: When PreGlobeStatus=GIR719, PreOwnership must not be completed.
        if xp_pre_globe_lc:
            # Build quick lookup of any PreOwnership leaf presence by (entity, context_key)
            preown_present: Set[Tuple[str, Optional[str]]] = set()
            for dp in submission_dps:
                xp = _norm_xpath(dp.xml_path or "").lower()
                if "/ownershipchange/preownership/" in xp:
                    ec = (dp.entity_code or "").strip()
                    if ec:
                        preown_present.add((ec, dp.context_key or None))

            for dp in submission_dps:
                if _dp_xpath_lc(dp) != xp_pre_globe_lc:
                    continue
                ec = (dp.entity_code or "").strip()
                if not ec:
                    continue
                v = (dp.value_raw or "").strip()
                if v != "GIR719":
                    continue
                if (ec, dp.context_key or None) in preown_present:
                    _oecd_issue(
                        number=70024,
                        severity="BLOCKING",
                        xml_path=dp.xml_path,
                        filer_code=dp.filer_code,
                        jurisdiction_code=dp.jurisdiction_code,
                        entity_code=ec,
                        context_key=dp.context_key,
                        message="PreGlobeStatus is GIR719, so PreOwnership must not be completed for this OwnershipChange.",
                    )

        # -----------------------------
        # 70026–70031: Ownership element rules
        # -----------------------------
        # Build ownership datapoint index by (entity_code, context_key)
        own_idx: Dict[Tuple[str, Optional[str]], Dict[str, List[models.DataPoint]]] = {}
        if xp_own_type_lc or xp_own_pct_lc or xp_own_tin_lc:
            for dp in submission_dps:
                ec = (dp.entity_code or "").strip()
                if not ec:
                    continue
                xp = _dp_xpath_lc(dp)
                if xp not in {xp_own_type_lc, xp_own_pct_lc, xp_own_tin_lc}:
                    continue
                k = (ec, dp.context_key or None)
                own_idx.setdefault(k, {}).setdefault(xp, []).append(dp)

        def _first_str(arr: List[models.DataPoint]) -> str:
            if not arr:
                return ""
            return (arr[0].value_raw or "").strip()

        def _first_dec(arr: List[models.DataPoint]) -> Optional[Decimal]:
            if not arr:
                return None
            return _dp_decimal(arr[0])

        # 70026: PE (GIR305) OwnershipPercentage must equal 100%
        for ec, st in ce_statuses.items():
            if "GIR305" not in st:
                continue
            for (e2, ck), m in own_idx.items():
                if e2 != ec:
                    continue
                pct = _first_dec(m.get(xp_own_pct_lc, []))
                if pct is None:
                    continue
                if pct != Decimal("100"):
                    _oecd_issue(
                        number=70026,
                        severity="BLOCKING",
                        xml_path=xp_own_pct,
                        entity_code=ec,
                        context_key=ck,
                        message=f"CE has GloBEStatus GIR305 (PE) but OwnershipPercentage is {pct} (must be 100).",
                    )

        # 70027: Non-Group Member (GIR318) should have 0% + NOTIN + OwnershipType GIR806
        for ec, st in ce_statuses.items():
            if "GIR318" not in st:
                continue
            for (e2, ck), m in own_idx.items():
                if e2 != ec:
                    continue
                pct = _first_dec(m.get(xp_own_pct_lc, []))
                ot = _first_str(m.get(xp_own_type_lc, []))
                tin = _first_str(m.get(xp_own_tin_lc, []))
                problems: List[str] = []
                if pct is not None and pct != Decimal("0"):
                    problems.append(f"OwnershipPercentage={pct} (expected 0)")
                if tin and tin.upper() != "NOTIN":
                    problems.append(f"Ownership/TIN='{tin}' (expected NOTIN)")
                if ot and ot != "GIR806":
                    problems.append(f"OwnershipType='{ot}' (expected GIR806)")
                if problems:
                    _oecd_issue(
                        number=70027,
                        severity="WARNING",
                        xml_path=xp_own_type or xp_own_pct or xp_own_tin,
                        entity_code=ec,
                        context_key=ck,
                        message=(
                            "CE has GloBEStatus GIR318; ownership should reflect Non-Group Member conventions. "
                            + "; ".join(problems)
                        ),
                    )

        # 70028: Unless GIR318, OwnershipPercentage must not be 0%
        for (ec, ck), m in own_idx.items():
            st = ce_statuses.get(ec, set())
            if "GIR318" in st:
                continue
            pct = _first_dec(m.get(xp_own_pct_lc, []))
            if pct is None:
                continue
            if pct == Decimal("0"):
                _oecd_issue(
                    number=70028,
                    severity="BLOCKING",
                    xml_path=xp_own_pct,
                    entity_code=ec,
                    context_key=ck,
                    message="OwnershipPercentage is 0% but CE is not reported as GloBEStatus GIR318 (Non-Group Member).",
                )

        # 70029/70030: OwnershipType-based owner TIN references
        for (ec, ck), m in own_idx.items():
            ot = _first_str(m.get(xp_own_type_lc, []))
            tin = _first_str(m.get(xp_own_tin_lc, []))
            if not ot or not tin:
                continue
            if ot == "GIR801" and upe_tins:
                if tin not in upe_tins:
                    _oecd_issue(
                        number=70029,
                        severity="BLOCKING",
                        xml_path=xp_own_tin,
                        entity_code=ec,
                        context_key=ck,
                        message=(
                            f"OwnershipType is GIR801 (UPE), but Ownership/TIN '{tin}' does not match any UPE TIN ({', '.join(sorted(upe_tins))})."
                        ),
                    )
            if ot in {"GIR802", "GIR803", "GIR804"} and ce_tins:
                if tin not in ce_tins:
                    _oecd_issue(
                        number=70030,
                        severity="BLOCKING",
                        xml_path=xp_own_tin,
                        entity_code=ec,
                        context_key=ck,
                        message=(
                            f"OwnershipType is {ot}, but Ownership/TIN '{tin}' does not match any CE/ID/TIN in CorporateStructure."
                        ),
                    )

        # 70031: PE owner TIN must be held by a main entity (GIR306) (CE or UPE/OtherUPE)
        main_tins: Set[str] = set()
        for ec, st in ce_statuses.items():
            if "GIR306" in st:
                t = ce_tin_by_entity.get(ec)
                if t:
                    main_tins.add(t)
        if "GIR306" in upe_statuses:
            # Use UPE TIN(s) if UPE is a main entity.
            main_tins |= set(upe_tins)

        if main_tins:
            for pe, st in ce_statuses.items():
                if "GIR305" not in st:
                    continue
                # Any ownership record must reference a main entity TIN.
                ok = False
                for (ec, ck), m in own_idx.items():
                    if ec != pe:
                        continue
                    tin = _first_str(m.get(xp_own_tin_lc, []))
                    if tin and tin in main_tins:
                        ok = True
                        break
                if not ok:
                    _oecd_issue(
                        number=70031,
                        severity="BLOCKING",
                        xml_path=xp_own_tin,
                        entity_code=pe,
                        message=(
                            f"CE has GloBEStatus GIR305 (PE) but Ownership/TIN does not match any main entity (GIR306) TIN ({', '.join(sorted(main_tins))})."
                        ),
                    )

        # -----------------------------
        # 70032–70035: QIIR / exception rules
        # -----------------------------
        # 70032: If QIIR is provided, CE/ID/Rules must include GIR201 or GIR202.
        if xp_qiir_pope_ipe_lc and xp_ce_rules_lc:
            qiir_entities: Set[str] = set()
            for dp in submission_dps:
                if "/corporatestructure/ce/qiir" not in (_norm_xpath(dp.xml_path or "").lower()):
                    continue
                ec = (dp.entity_code or "").strip()
                if ec:
                    qiir_entities.add(ec)

            for ec in qiir_entities:
                rules = set(rules_by_key.get(ec, set()))
                if not ({"GIR201", "GIR202"} & rules):
                    _oecd_issue(
                        number=70032,
                        severity="BLOCKING",
                        xml_path=xp_ce_rules,
                        entity_code=ec,
                        message=(
                            "QIIR is provided for this CE, but CE/ID/Rules does not include GIR201 or GIR202."
                        ),
                    )

        # 70033: QIIR/Exception/TIN must match another CE/ID/TIN.
        if xp_qiir_exc_tin_lc and tin_to_entities:
            for dp in submission_dps:
                if _dp_xpath_lc(dp) != xp_qiir_exc_tin_lc:
                    continue
                ec = (dp.entity_code or "").strip()
                v = (dp.value_raw or "").strip()
                if not v:
                    continue
                owners = tin_to_entities.get(v, set())
                if not owners or (ec and owners == {ec}):
                    _oecd_issue(
                        number=70033,
                        severity="BLOCKING",
                        xml_path=dp.xml_path,
                        entity_code=ec or None,
                        context_key=dp.context_key,
                        message=(
                            f"QIIR/Exception/TIN '{v}' does not match the TIN of any other CE in CorporateStructure."
                        ),
                    )

        # 70034/70035: POPE-IPE + exception implies Art2.1.3 / Art2.1.5 must be TRUE.
        if xp_qiir_pope_ipe_lc and (xp_qiir_art213_lc or xp_qiir_art215_lc):
            # Index QIIR values per entity
            pope_ipe_by_ent: Dict[str, str] = {}
            exc_present: Set[Tuple[str, Optional[str]]] = set()
            art213_by_key: Dict[Tuple[str, Optional[str]], str] = {}
            art215_by_key: Dict[Tuple[str, Optional[str]], str] = {}

            for dp in submission_dps:
                ec = (dp.entity_code or "").strip()
                if not ec:
                    continue
                xp = _dp_xpath_lc(dp)
                ck = dp.context_key or None
                if xp == xp_qiir_pope_ipe_lc:
                    v = (dp.value_raw or "").strip()
                    if v:
                        pope_ipe_by_ent[ec] = v
                # Exception container presence: any dp under /QIIR/Exception
                if "/corporatestructure/ce/qiir/exception" in (_norm_xpath(dp.xml_path or "").lower()):
                    exc_present.add((ec, ck))
                if xp_qiir_art213_lc and xp == xp_qiir_art213_lc:
                    art213_by_key[(ec, ck)] = (dp.value_raw or "").strip()
                if xp_qiir_art215_lc and xp == xp_qiir_art215_lc:
                    art215_by_key[(ec, ck)] = (dp.value_raw or "").strip()

            for (ec, ck) in exc_present:
                pi = pope_ipe_by_ent.get(ec)
                if not pi:
                    continue
                if pi == "GIR902":
                    v = art213_by_key.get((ec, ck), "")
                    if not _truthy(v):
                        _oecd_issue(
                            number=70034,
                            severity="BLOCKING",
                            xml_path=xp_qiir_art213,
                            entity_code=ec,
                            context_key=ck,
                            message=(
                                "QIIR exception applies and POPE-IPE is GIR902 (IPE), but Art2.1.3 is not TRUE."
                            ),
                        )
                if pi == "GIR901":
                    v = art215_by_key.get((ec, ck), "")
                    if not _truthy(v):
                        _oecd_issue(
                            number=70035,
                            severity="BLOCKING",
                            xml_path=xp_qiir_art215,
                            entity_code=ec,
                            context_key=ck,
                            message=(
                                "QIIR exception applies and POPE-IPE is GIR901 (POPE), but Art2.1.5 is not TRUE."
                            ),
                        )
    except Exception:
        # Non-fatal: OECD record error checks are best-effort.
        pass

    # -----------------------------
    # Stage 8: OECD Summary / SafeHarbour record errors — 70036–70053
    # -----------------------------
    #
    # These OECD “Other record errors” primarily relate to:
    #   - Summary repetition when multiple subgroups exist (70036)
    #   - Summary subgroup ↔ JurisdictionSection ETR subgroup alignment (70037)
    #   - Safe harbour date gates and cross-section dependencies (70038–70053)
    #
    # Implementation notes:
    #   - Summary records are identified using the first context segment that scopes the Summary
    #     instance (DOCREF:Summary:* or IDX:Summary:*). This allows us to join JurisdictionName,
    #     SafeHarbour and other Summary fields within the same Summary record instance.
    #   - JurisdictionSection records are keyed by dp.jurisdiction_code (set by the XML importer).
    try:
        def _oecd_issue(
            *,
            number: int,
            severity: str,
            xml_path: Optional[str],
            message: str,
            filer_code: Optional[str] = None,
            jurisdiction_code: Optional[str] = None,
            entity_code: Optional[str] = None,
            context_key: Optional[str] = None,
        ) -> None:
            num = number if number in error_map else None
            issues.append(Issue(
                severity=severity,
                rule_id=_rid(
                    "OECD",
                    f"{number}|{xml_path}|{filer_code}|{jurisdiction_code}|{entity_code}|{context_key}|{message}",
                ),
                section="Summary",
                xml_path=xml_path,
                filer_code=filer_code,
                jurisdiction_code=jurisdiction_code,
                entity_code=entity_code,
                context_key=context_key,
                error_number=num,
                message=message,
                how_to_fix=_oecd_fix_text(error_map, num) if num else None,
            ))

        def _scope_key(ctx: Optional[str], tag: str) -> str:
            '''Return a stable scope key for a repeatable record block.

            We keep context segments up to and including the first segment that scopes the
            record tag (DOCREF:{tag}:* or IDX:{tag}:*). This prevents child repeat indexes
            (e.g., IDX:Subgroup:1) from fragmenting the record identity.
            '''
            if not ctx:
                return ""
            parts = str(ctx).split("|")
            for i, p in enumerate(parts):
                if p.startswith(f"DOCREF:{tag}:") or p.startswith(f"IDX:{tag}:"):
                    return "|".join(parts[: i + 1])
            return parts[0]

        def _date_only(d) -> Optional[object]:
            if d is None:
                return None
            try:
                # date has no .date(); datetime does.
                return d.date() if hasattr(d, "date") else d
            except Exception:
                return None

        # --- Locate xpaths ---
        xp_sum_juris = _find_xpath(config, endswith="/Summary/Jurisdiction/JurisdictionName")
        xp_sum_sub_tin = _find_xpath(config, endswith="/Summary/Jurisdiction/Subgroup/TIN")
        xp_sum_safe = _find_xpath(config, endswith="/Summary/SafeHarbour")
        xp_sum_jwtr = _find_xpath(config, endswith="/Summary/JurWithTaxingRights/JurisdictionName")

        xp_sum_etr_range = _find_xpath(config, endswith="/Summary/ETRRange")
        xp_sum_sbie = _find_xpath(config, endswith="/Summary/SBIE")
        xp_sum_qdmt = _find_xpath(config, endswith="/Summary/QDMTTut")
        xp_sum_globetut = _find_xpath(config, endswith="/Summary/GLoBETut")

        xp_cfs = _find_xpath(config, endswith="/FilingInfo/AccountingInfo/CFSofUPE")

        xp_upe_other_res = _find_xpath(config, endswith="/CorporateStructure/UPE/OtherUPE/ID/ResCountryCode")
        xp_upe_excl_res = _find_xpath(config, endswith="/CorporateStructure/UPE/ExcludedUPE/ID/ResCountryCode")

        xp_js_sub_tin = _find_xpath(config, endswith="/JurisdictionSection/GLoBETax/ETR/SubGroup/TIN")
        xp_js_sub_type = _find_xpath(config, endswith="/JurisdictionSection/GLoBETax/ETR/SubGroup/TypeofSubGroup")

        xp_js_etr_status = _find_xpath(config, endswith="/JurisdictionSection/GLoBETax/ETR/ETRStatus")
        xp_js_etr_exc = _find_xpath(config, endswith="/JurisdictionSection/GLoBETax/ETR/ETRStatus/ETRException")
        xp_js_etr_comp = _find_xpath(config, endswith="/JurisdictionSection/GLoBETax/ETR/ETRStatus/ETRComputation")

        xp_js_cbcr = _find_xpath(config, endswith="/ETRStatus/ETRException/TransitionalCbCRSafeHarbour")
        xp_js_cbcr_rev = _find_xpath(config, endswith="/ETRStatus/ETRException/TransitionalCbCRSafeHarbour/Revenue")
        xp_js_cbcr_it = _find_xpath(config, endswith="/ETRStatus/ETRException/TransitionalCbCRSafeHarbour/IncomeTax")
        xp_js_cbcr_profit = _find_xpath(config, endswith="/ETRStatus/ETRException/TransitionalCbCRSafeHarbour/Profit")

        xp_js_utpr = _find_xpath(config, endswith="/ETRStatus/ETRException/UTPRSafeHarbour")
        xp_js_utpr_cit = _find_xpath(config, endswith="/ETRStatus/ETRException/UTPRSafeHarbour/CITRate")

        xp_js_nmce = _find_xpath(config, endswith="/ETRStatus/ETRComputation/Non - MaterialCE")
        xp_js_nmce_agg = _find_xpath(config, endswith="/ETRStatus/ETRComputation/Non - MaterialCE/RFY/AggregateSimplified")

        xp_js_subst = _find_xpath(config, endswith="/ETRStatus/ETRComputation/OverallComputation/SubstanceExclusion")

        # Normalize to lowercase for comparisons
        xp_sum_juris_lc = _norm_xpath(xp_sum_juris).lower() if xp_sum_juris else ""
        xp_sum_sub_tin_lc = _norm_xpath(xp_sum_sub_tin).lower() if xp_sum_sub_tin else ""
        xp_sum_safe_lc = _norm_xpath(xp_sum_safe).lower() if xp_sum_safe else ""
        xp_sum_jwtr_lc = _norm_xpath(xp_sum_jwtr).lower() if xp_sum_jwtr else ""

        xp_sum_etr_range_lc = _norm_xpath(xp_sum_etr_range).lower() if xp_sum_etr_range else ""
        xp_sum_sbie_lc = _norm_xpath(xp_sum_sbie).lower() if xp_sum_sbie else ""
        xp_sum_qdmt_lc = _norm_xpath(xp_sum_qdmt).lower() if xp_sum_qdmt else ""
        xp_sum_globetut_lc = _norm_xpath(xp_sum_globetut).lower() if xp_sum_globetut else ""

        xp_cfs_lc = _norm_xpath(xp_cfs).lower() if xp_cfs else ""

        xp_upe_other_res_lc = _norm_xpath(xp_upe_other_res).lower() if xp_upe_other_res else ""
        xp_upe_excl_res_lc = _norm_xpath(xp_upe_excl_res).lower() if xp_upe_excl_res else ""

        xp_js_sub_tin_lc = _norm_xpath(xp_js_sub_tin).lower() if xp_js_sub_tin else ""
        xp_js_sub_type_lc = _norm_xpath(xp_js_sub_type).lower() if xp_js_sub_type else ""

        xp_js_etr_exc_lc = _norm_xpath(xp_js_etr_exc).lower() if xp_js_etr_exc else ""
        xp_js_etr_comp_lc = _norm_xpath(xp_js_etr_comp).lower() if xp_js_etr_comp else ""
        xp_js_cbcr_lc = _norm_xpath(xp_js_cbcr).lower() if xp_js_cbcr else ""
        xp_js_cbcr_rev_lc = _norm_xpath(xp_js_cbcr_rev).lower() if xp_js_cbcr_rev else ""
        xp_js_cbcr_it_lc = _norm_xpath(xp_js_cbcr_it).lower() if xp_js_cbcr_it else ""
        xp_js_cbcr_profit_lc = _norm_xpath(xp_js_cbcr_profit).lower() if xp_js_cbcr_profit else ""
        xp_js_utpr_lc = _norm_xpath(xp_js_utpr).lower() if xp_js_utpr else ""
        xp_js_utpr_cit_lc = _norm_xpath(xp_js_utpr_cit).lower() if xp_js_utpr_cit else ""
        xp_js_nmce_lc = _norm_xpath(xp_js_nmce).lower() if xp_js_nmce else ""
        xp_js_nmce_agg_lc = _norm_xpath(xp_js_nmce_agg).lower() if xp_js_nmce_agg else ""
        xp_js_subst_lc = _norm_xpath(xp_js_subst).lower() if xp_js_subst else ""

        # --- Build UPE jurisdiction set (for 70040) ---
        upe_juris: Set[str] = set()
        if xp_upe_other_res_lc or xp_upe_excl_res_lc:
            for dp in submission_dps:
                xp = _dp_xpath_lc(dp)
                if xp in {xp_upe_other_res_lc, xp_upe_excl_res_lc}:
                    v = (dp.value_raw or "").strip().upper()
                    if v:
                        upe_juris.add(v)

        # --- FilingInfo CFSofUPE (for 70041) ---
        cfs_val: Optional[str] = None
        if xp_cfs_lc:
            for dp in submission_dps:
                if _dp_xpath_lc(dp) == xp_cfs_lc:
                    vv = (dp.value_raw or "").strip()
                    if vv:
                        cfs_val = vv
                        break

        # --- Summary record index ---
        # Map summary_scope -> jurisdiction code (Summary/Jurisdiction/JurisdictionName)
        sum_jur_by_scope: Dict[str, str] = {}
        # Map summary_scope -> subgroup TIN set (Summary/Jurisdiction/Subgroup/TIN)
        sum_subs_by_scope: Dict[str, Set[str]] = {}
        # Map summary_scope -> safe harbour value set (Summary/SafeHarbour can repeat)
        sum_safe_by_scope: Dict[str, Set[str]] = {}
        # Map summary_scope -> jwtr presence
        sum_jwtr_present: Set[str] = set()
        # Map summary_scope -> presence of summary outputs
        sum_presence: Dict[str, Dict[str, bool]] = {}

        def _mark(scope: str, key: str) -> None:
            sum_presence.setdefault(scope, {})[key] = True

        for dp in submission_dps:
            xp = _dp_xpath_lc(dp)
            scope = _scope_key(dp.context_key, "Summary")

            if xp_sum_juris_lc and xp == xp_sum_juris_lc:
                jur = (dp.value_raw or "").strip().upper()
                if jur:
                    sum_jur_by_scope[scope] = jur

            if xp_sum_sub_tin_lc and xp == xp_sum_sub_tin_lc:
                tin = (dp.value_raw or "").strip()
                if tin:
                    sum_subs_by_scope.setdefault(scope, set()).add(tin)

            if xp_sum_safe_lc and xp == xp_sum_safe_lc:
                sh = (dp.value_raw or "").strip()
                if sh:
                    sum_safe_by_scope.setdefault(scope, set()).add(sh)

            if xp_sum_jwtr_lc and xp == xp_sum_jwtr_lc:
                vv = (dp.value_raw or "").strip().upper()
                if vv:
                    sum_jwtr_present.add(scope)

            if xp_sum_etr_range_lc and xp == xp_sum_etr_range_lc:
                if (dp.value_raw or "").strip() != "":
                    _mark(scope, "ETRRange")

            if xp_sum_sbie_lc and xp.startswith(xp_sum_sbie_lc):
                if (dp.value_raw or "").strip() != "":
                    _mark(scope, "SBIE")

            if xp_sum_qdmt_lc and xp == xp_sum_qdmt_lc:
                if (dp.value_raw or "").strip() != "":
                    _mark(scope, "QDMTTut")

            if xp_sum_globetut_lc and xp == xp_sum_globetut_lc:
                if (dp.value_raw or "").strip() != "":
                    _mark(scope, "GLoBETut")

        # Helper: jurisdictions with JurisdictionSection present (from importer scoping)
        js_juris_present: Set[str] = {dp.jurisdiction_code for dp in submission_dps if (dp.jurisdiction_code or "").strip()}
        js_juris_present = {j.strip().upper() for j in js_juris_present if j}

        # Index JurisdictionSection subgroup TINs by jurisdiction
        js_sub_tins: Dict[str, Set[str]] = {}
        if xp_js_sub_tin_lc:
            for dp in submission_dps:
                if not (dp.jurisdiction_code or "").strip():
                    continue
                if _dp_xpath_lc(dp) != xp_js_sub_tin_lc:
                    continue
                j = dp.jurisdiction_code.strip().upper()
                v = (dp.value_raw or "").strip()
                if v:
                    js_sub_tins.setdefault(j, set()).add(v)

        # Index JurisdictionSection subgroup types by jurisdiction
        js_sub_types: Dict[str, Set[str]] = {}
        if xp_js_sub_type_lc:
            for dp in submission_dps:
                if not (dp.jurisdiction_code or "").strip():
                    continue
                if _dp_xpath_lc(dp) != xp_js_sub_type_lc:
                    continue
                j = dp.jurisdiction_code.strip().upper()
                v = (dp.value_raw or "").strip()
                if v:
                    js_sub_types.setdefault(j, set()).add(v)

        # Index key JurisdictionSection containers by jurisdiction
        js_has_exc: Set[str] = set()
        js_has_comp: Set[str] = set()
        js_has_cbcr: Set[str] = set()
        js_has_utpr: Set[str] = set()
        js_has_nmce: Set[str] = set()
        js_has_subst: Set[str] = set()
        js_cbcr_rev: Set[str] = set()
        js_cbcr_it: Set[str] = set()
        js_cbcr_profit: Dict[str, Optional[Decimal]] = {}
        js_nmce_agg: Set[str] = set()

        for dp in submission_dps:
            j = (dp.jurisdiction_code or "").strip().upper()
            if not j:
                continue
            xp = _dp_xpath_lc(dp)

            if xp_js_etr_exc_lc and xp.startswith(xp_js_etr_exc_lc):
                js_has_exc.add(j)
            if xp_js_etr_comp_lc and xp.startswith(xp_js_etr_comp_lc):
                js_has_comp.add(j)
            if xp_js_cbcr_lc and xp.startswith(xp_js_cbcr_lc):
                js_has_cbcr.add(j)
            if xp_js_utpr_lc and xp.startswith(xp_js_utpr_lc):
                js_has_utpr.add(j)
            if xp_js_nmce_lc and xp.startswith(xp_js_nmce_lc):
                js_has_nmce.add(j)
            if xp_js_subst_lc and xp.startswith(xp_js_subst_lc):
                js_has_subst.add(j)

            if xp_js_cbcr_rev_lc and xp == xp_js_cbcr_rev_lc and (dp.value_raw or "").strip() != "":
                js_cbcr_rev.add(j)
            if xp_js_cbcr_it_lc and xp == xp_js_cbcr_it_lc and (dp.value_raw or "").strip() != "":
                js_cbcr_it.add(j)
            if xp_js_cbcr_profit_lc and xp == xp_js_cbcr_profit_lc and (dp.value_raw or "").strip() != "":
                js_cbcr_profit[j] = _dp_decimal(dp)
            if xp_js_nmce_agg_lc and xp == xp_js_nmce_agg_lc and (dp.value_raw or "").strip() != "":
                js_nmce_agg.add(j)

        # -----------------------------
        # 70036: Summary repetition when multiple subgroups exist
        # -----------------------------
        # Group summary scopes by jurisdiction.
        scopes_by_jur: Dict[str, List[str]] = {}
        for sc, jur in sum_jur_by_scope.items():
            if jur:
                scopes_by_jur.setdefault(jur, []).append(sc)

        for jur, scopes in scopes_by_jur.items():
            union_subs: Set[str] = set()
            for sc in scopes:
                union_subs |= set(sum_subs_by_scope.get(sc, set()))
            if len(union_subs) <= 1:
                continue

            if len(scopes) != len(union_subs):
                _oecd_issue(
                    number=70036,
                    severity="BLOCKING",
                    xml_path=xp_sum_sub_tin or xp_sum_juris,
                    jurisdiction_code=jur,
                    message=(
                        f"Summary reports {len(union_subs)} subgroup(s) for jurisdiction '{jur}' ({', '.join(sorted(union_subs))}), "
                        f"but there are {len(scopes)} Summary record(s) for that jurisdiction. OECD requires the Summary record to be repeated "
                        "so the number of Summary records matches the number of subgroup computations."
                    ),
                )

            # Each repeated Summary record should list the same subgroup set.
            for sc in scopes:
                subs = set(sum_subs_by_scope.get(sc, set()))
                if subs != union_subs:
                    _oecd_issue(
                        number=70036,
                        severity="BLOCKING",
                        xml_path=xp_sum_sub_tin or xp_sum_juris,
                        jurisdiction_code=jur,
                        context_key=sc,
                        message=(
                            f"Summary record '{sc or '∅'}' for jurisdiction '{jur}' reports subgroup(s) {', '.join(sorted(subs)) or '∅'}, "
                            f"but the jurisdiction has subgroup set {', '.join(sorted(union_subs))}. When multiple subgroups exist, each repeated "
                            "Summary record should carry the full subgroup list."
                        ),
                    )

        # -----------------------------
        # 70037: Summary subgroup ↔ JurisdictionSection ETR/SubGroup/TIN alignment
        # -----------------------------
        # OECD text says this 'should' be completed, so we emit WARNING.
        for sc, subs in sum_subs_by_scope.items():
            if not subs:
                continue
            jur = sum_jur_by_scope.get(sc, "")
            if not jur or jur not in js_juris_present:
                continue

            present = js_sub_tins.get(jur, set())
            for tin in sorted(subs):
                if tin not in present:
                    _oecd_issue(
                        number=70037,
                        severity="WARNING",
                        xml_path=xp_js_sub_tin or xp_sum_sub_tin,
                        jurisdiction_code=jur,
                        context_key=sc,
                        message=(
                            f"Summary indicates subgroup TIN '{tin}' for jurisdiction '{jur}', but no matching "
                            "JurisdictionSection/GLoBETax/ETR/SubGroup/TIN was found for that jurisdiction."
                        ),
                    )

        # -----------------------------
        # Reporting period end date (for 70038/70039)
        # -----------------------------
        end_dt = _date_only(getattr(filing, "period_end", None))
        cutoff_cbcr = datetime(2028, 6, 30).date()
        cutoff_utpr = datetime(2026, 12, 31).date()

        # -----------------------------
        # Iterate Summary scopes for SafeHarbour-driven checks
        # -----------------------------
        for sc, sh_set in sum_safe_by_scope.items():
            if not sh_set:
                continue
            jur = sum_jur_by_scope.get(sc, "")

            for sh in sorted(sh_set):
                # 70038: Transitional CbCR safe harbour after 30/06/2028
                if end_dt and end_dt > cutoff_cbcr and sh in {"GIR1203", "GIR1204", "GIR1205"}:
                    _oecd_issue(
                        number=70038,
                        severity="BLOCKING",
                        xml_path=xp_sum_safe,
                        jurisdiction_code=jur or None,
                        context_key=sc,
                        message=(
                            f"SafeHarbour '{sh}' was selected but the filing period end date ({end_dt}) is after 2028-06-30."
                        ),
                    )

                # 70039: Transitional UTPR safe harbour after 31/12/2026
                if end_dt and end_dt > cutoff_utpr and sh == "GIR1206":
                    _oecd_issue(
                        number=70039,
                        severity="BLOCKING",
                        xml_path=xp_sum_safe,
                        jurisdiction_code=jur or None,
                        context_key=sc,
                        message=(
                            f"SafeHarbour GIR1206 was selected but the filing period end date ({end_dt}) is after 2026-12-31."
                        ),
                    )

                # 70040: GIR1206 only permitted in the UPE jurisdiction
                if sh == "GIR1206" and jur and upe_juris and jur not in upe_juris:
                    _oecd_issue(
                        number=70040,
                        severity="BLOCKING",
                        xml_path=xp_sum_safe,
                        jurisdiction_code=jur,
                        context_key=sc,
                        message=(
                            f"SafeHarbour GIR1206 is only permitted in the UPE jurisdiction ({', '.join(sorted(upe_juris))}). "
                            f"Summary record is for jurisdiction '{jur}'."
                        ),
                    )

                # 70041: NMCE simplified safe harbours require eligible CFSofUPE
                if cfs_val in {"GIR502", "GIR504"} and sh in {"GIR1207", "GIR1208", "GIR1209"}:
                    _oecd_issue(
                        number=70041,
                        severity="BLOCKING",
                        xml_path=xp_sum_safe,
                        jurisdiction_code=jur or None,
                        context_key=sc,
                        message=(
                            f"SafeHarbour '{sh}' was selected, but FilingInfo/AccountingInfo/CFSofUPE is '{cfs_val}'. "
                            "OECD guidance restricts NMCE simplified calculations for this CFSofUPE value."
                        ),
                    )

        # -----------------------------
        # 70042 / 70043: Summary completion when jurisdictions have taxing rights
        # -----------------------------
        for sc in sum_jwtr_present:
            jur = sum_jur_by_scope.get(sc, "")
            sh_set = set(sum_safe_by_scope.get(sc, set()))

            # 70042: JWTR completed and SafeHarbour not completed or only GIR1206
            if (not sh_set) or (sh_set == {"GIR1206"}):
                missing = []
                if not sum_presence.get(sc, {}).get("ETRRange"):
                    missing.append("ETRRange")
                if not sum_presence.get(sc, {}).get("SBIE"):
                    missing.append("SBIE")
                if not sum_presence.get(sc, {}).get("QDMTTut"):
                    missing.append("QDMTTut")
                if not sum_presence.get(sc, {}).get("GLoBETut"):
                    missing.append("GLoBETut")
                if missing:
                    _oecd_issue(
                        number=70042,
                        severity="BLOCKING",
                        xml_path=xp_sum_etr_range or xp_sum_sbie or xp_sum_qdmt or xp_sum_globetut,
                        jurisdiction_code=jur or None,
                        context_key=sc,
                        message=(
                            f"JurWithTaxingRights is completed for this Summary record, but required Summary outputs are missing: "
                            f"{', '.join(missing)} (when no SafeHarbour is applied or only GIR1206 is applied)."
                        ),
                    )

            # 70043: JWTR completed and SafeHarbour includes GIR1202
            if "GIR1202" in sh_set:
                missing = []
                if not sum_presence.get(sc, {}).get("ETRRange"):
                    missing.append("ETRRange")
                if not sum_presence.get(sc, {}).get("SBIE"):
                    missing.append("SBIE")
                if not sum_presence.get(sc, {}).get("QDMTTut"):
                    missing.append("QDMTTut")
                if missing:
                    _oecd_issue(
                        number=70043,
                        severity="BLOCKING",
                        xml_path=xp_sum_etr_range or xp_sum_sbie or xp_sum_qdmt,
                        jurisdiction_code=jur or None,
                        context_key=sc,
                        message=(
                            f"JurWithTaxingRights is completed and SafeHarbour GIR1202 is applied, but required Summary outputs are missing: "
                            f"{', '.join(missing)} (GLoBETut is not required under GIR1202)."
                        ),
                    )

        # -----------------------------
        # 70044: If ETRStatus is completed, it must contain ETRException or ETRComputation
        # -----------------------------
        # In the XSD, ETRStatus is mandatory. We implement this as:
        #   for each JurisdictionSection (jurisdiction_code), at least one datapoint must exist
        #   under either .../ETRStatus/ETRException or .../ETRStatus/ETRComputation.
        for j in sorted(js_juris_present):
            if j not in js_has_exc and j not in js_has_comp:
                _oecd_issue(
                    number=70044,
                    severity="BLOCKING",
                    xml_path=xp_js_etr_status,
                    jurisdiction_code=j,
                    message=(
                        f"JurisdictionSection '{j}' has no ETRException or ETRComputation under ETRStatus. "
                        "OECD requires Part 2 (ETRException) or Part 3 (ETRComputation) to be completed."
                    ),
                )

        # -----------------------------
        # 70045–70053: SafeHarbour ↔ JurisdictionSection dependency rules
        # -----------------------------
        # We evaluate per Summary record scope, matching the Summary jurisdiction to JurisdictionSection/Jurisdiction.
        for sc, sh_set in sum_safe_by_scope.items():
            if not sh_set:
                continue
            jur = sum_jur_by_scope.get(sc, "")
            if not jur or jur not in js_juris_present:
                continue

            # 70045: GIR1203/1204/1205 => TransitionalCbCRSafeHarbour must be completed
            if sh_set.intersection({"GIR1203", "GIR1204", "GIR1205"}):
                if jur not in js_has_cbcr:
                    _oecd_issue(
                        number=70045,
                        severity="BLOCKING",
                        xml_path=xp_js_cbcr,
                        jurisdiction_code=jur,
                        context_key=sc,
                        message=(
                            f"Summary SafeHarbour includes a Transitional CbCR option ({', '.join(sorted(sh_set.intersection({'GIR1203','GIR1204','GIR1205'})))}), "
                            "but JurisdictionSection does not include ETRException/TransitionalCbCRSafeHarbour for this jurisdiction."
                        ),
                    )

            # 70047: GIR1203 => Revenue must be completed
            if "GIR1203" in sh_set and jur not in js_cbcr_rev:
                _oecd_issue(
                    number=70047,
                    severity="BLOCKING",
                    xml_path=xp_js_cbcr_rev,
                    jurisdiction_code=jur,
                    context_key=sc,
                    message=(
                        "SafeHarbour GIR1203 (De minimis CbCR) selected in Summary; TransitionalCbCRSafeHarbour/Revenue must be completed."
                    ),
                )

            # 70048: GIR1204 => IncomeTax must be completed
            if "GIR1204" in sh_set and jur not in js_cbcr_it:
                _oecd_issue(
                    number=70048,
                    severity="BLOCKING",
                    xml_path=xp_js_cbcr_it,
                    jurisdiction_code=jur,
                    context_key=sc,
                    message=(
                        "SafeHarbour GIR1204 (Simplified ETR Test) selected in Summary; TransitionalCbCRSafeHarbour/IncomeTax must be completed."
                    ),
                )

            # 70049: GIR1206 => UTPRSafeHarbour must be completed (CITRate required)
            if "GIR1206" in sh_set and jur not in js_has_utpr:
                _oecd_issue(
                    number=70049,
                    severity="BLOCKING",
                    xml_path=xp_js_utpr_cit or xp_js_utpr,
                    jurisdiction_code=jur,
                    context_key=sc,
                    message=(
                        "SafeHarbour GIR1206 (UTPR Safe Harbour) selected in Summary; ETRException/UTPRSafeHarbour (incl. CITRate) must be completed."
                    ),
                )

            # 70050: GIR1207/1208/1209 => Non-MaterialCE must be completed
            if sh_set.intersection({"GIR1207", "GIR1208", "GIR1209"}) and jur not in js_has_nmce:
                _oecd_issue(
                    number=70050,
                    severity="BLOCKING",
                    xml_path=xp_js_nmce,
                    jurisdiction_code=jur,
                    context_key=sc,
                    message=(
                        f"SafeHarbour includes NMCE simplified option(s) ({', '.join(sorted(sh_set.intersection({'GIR1207','GIR1208','GIR1209'})))}); "
                        "ETRComputation/Non - MaterialCE must be completed."
                    ),
                )

            # 70051: GIR1208 => AggregateSimplified must be completed
            if "GIR1208" in sh_set and jur not in js_nmce_agg:
                _oecd_issue(
                    number=70051,
                    severity="BLOCKING",
                    xml_path=xp_js_nmce_agg,
                    jurisdiction_code=jur,
                    context_key=sc,
                    message=(
                        "SafeHarbour GIR1208 selected in Summary; Non - MaterialCE/RFY/AggregateSimplified must be completed."
                    ),
                )

            # 70052: GIR1209 => SubstanceExclusion must be completed
            if "GIR1209" in sh_set and jur not in js_has_subst:
                _oecd_issue(
                    number=70052,
                    severity="BLOCKING",
                    xml_path=xp_js_subst,
                    jurisdiction_code=jur,
                    context_key=sc,
                    message=(
                        "SafeHarbour GIR1209 selected in Summary; OverallComputation/SubstanceExclusion must be completed."
                    ),
                )

            # 70053: GIR1205 => SubstanceExclusion required unless Profit <= 0
            if "GIR1205" in sh_set:
                profit = js_cbcr_profit.get(jur)
                require_subst = True
                if profit is not None:
                    try:
                        require_subst = profit > Decimal("0")
                    except Exception:
                        require_subst = True
                if require_subst and jur not in js_has_subst:
                    _oecd_issue(
                        number=70053,
                        severity="BLOCKING",
                        xml_path=xp_js_subst,
                        jurisdiction_code=jur,
                        context_key=sc,
                        message=(
                            "SafeHarbour GIR1205 selected in Summary and Profit is positive (or could not be evaluated); "
                            "OverallComputation/SubstanceExclusion must be completed (unless Profit is 0 or negative)."
                        ),
                    )

        # -----------------------------
        # 70046: If TransitionalCbCRSafeHarbour completed, SubGroup must be completed and TypeofSubGroup ∈ {GIR1607,GIR1608}
        # -----------------------------
        allowed_types = {"GIR1607", "GIR1608"}
        for j in sorted(js_has_cbcr):
            # SubGroup must exist
            if not js_sub_tins.get(j):
                _oecd_issue(
                    number=70046,
                    severity="BLOCKING",
                    xml_path=xp_js_sub_tin or xp_js_sub_type,
                    jurisdiction_code=j,
                    message=(
                        "TransitionalCbCRSafeHarbour is completed, but no ETR/SubGroup elements were provided for the jurisdiction."
                    ),
                )
                continue

            # TypeofSubGroup must be GIR1607 or GIR1608
            types = js_sub_types.get(j, set())
            if not types:
                _oecd_issue(
                    number=70046,
                    severity="BLOCKING",
                    xml_path=xp_js_sub_type,
                    jurisdiction_code=j,
                    message=(
                        "TransitionalCbCRSafeHarbour is completed, but ETR/SubGroup/TypeofSubGroup is missing; it must be GIR1607 or GIR1608."
                    ),
                )
            else:
                bad = sorted([t for t in types if t not in allowed_types])
                if bad:
                    _oecd_issue(
                        number=70046,
                        severity="BLOCKING",
                        xml_path=xp_js_sub_type,
                        jurisdiction_code=j,
                        message=(
                            f"ETR/SubGroup/TypeofSubGroup contains invalid value(s) for a TransitionalCbCRSafeHarbour filing: {', '.join(bad)}. "
                            "Allowed values are GIR1607 or GIR1608."
                        ),
                    )

    except Exception:
        # Non-fatal: OECD summary/safe harbour checks are best-effort.
        pass


    # -----------------------------
    # Stage 9: OECD ETR / Elections / Adjustments / Post‑filing cross‑record errors — 70054–70079
    # -----------------------------
    #
    # Focus: the 7005x/7006x/7007x range with cross-record dependencies inside JurisdictionSection,
    # including election gating, adjustment uniqueness/conditional completion, post‑filing arithmetic
    # checks, DeemedDistTax recapture logic and Deferred Tax adjustment formulas.
    try:
        def _oecd_issue(
            *,
            number: int,
            severity: str,
            xml_path: Optional[str],
            message: str,
            filer_code: Optional[str] = None,
            jurisdiction_code: Optional[str] = None,
            entity_code: Optional[str] = None,
            context_key: Optional[str] = None,
        ) -> None:
            num = number if number in error_map else None
            issues.append(Issue(
                severity=severity,
                rule_id=_rid(
                    "OECD",
                    f"{number}|{xml_path}|{filer_code}|{jurisdiction_code}|{entity_code}|{context_key}|{message}",
                ),
                section="Jurisdiction",
                xml_path=xml_path,
                filer_code=filer_code,
                jurisdiction_code=jurisdiction_code,
                entity_code=entity_code,
                context_key=context_key,
                error_number=num,
                message=message,
                how_to_fix=_oecd_fix_text(error_map, num) if num else None,
            ))

        def _scope_key(ctx: Optional[str], tag: str) -> str:
            """Return a stable scope key for a repeatable record block."""
            if not ctx:
                return ""
            parts = str(ctx).split("|")
            for i, p in enumerate(parts):
                if p.startswith(f"DOCREF:{tag}:") or p.startswith(f"IDX:{tag}:"):
                    return "|".join(parts[: i + 1])
            return parts[0]

        def _ctx_root(ctx: Optional[str]) -> str:
            return (str(ctx).split("|", 1)[0]) if ctx else ""

        def _parse_year_int(v: Optional[str]) -> Optional[int]:
            if v is None:
                return None
            s = str(v).strip()
            if not s:
                return None
            try:
                return int(s)
            except Exception:
                # Sometimes a date-like value sneaks in; take leading 4 digits.
                m = re.match(r"^\s*(\d{4})", s)
                if m:
                    try:
                        return int(m.group(1))
                    except Exception:
                        return None
            return None

        # Filing period years (used by 70066/70068/70070/70071/70075)
        ps = getattr(filing, "period_start", None)
        pe = getattr(filing, "period_end", None)
        ps_year = ps.year if ps else None
        pe_year = pe.year if pe else None

        # --- Build a fast lookup for exact-xpath sibling access ---
        dp_by_exact: Dict[Tuple[Optional[str], Optional[str], Optional[str], Optional[str], str], models.DataPoint] = {}
        for dp in submission_dps:
            xp = _dp_xpath_lc(dp)
            dp_by_exact[(dp.filer_code or None, dp.jurisdiction_code or None, dp.entity_code or None, dp.context_key or None, xp)] = dp

        # --- Collect relevant xpaths ---
        # 70054/70056 (RevocationYear gating) – enumerate from config so we don't miss any elections.
        rev_etr_xps_lc: Set[str] = set()
        rev_ce_xps_lc: Set[str] = set()
        for e in config.elements:
            xp = (e.xpath or "").strip()
            if not xp or not xp.endswith("/RevocationYear"):
                continue
            xpn = _norm_xpath(xp).lower()
            if "/jurisdictionsection/" not in xpn:
                continue
            if "/etr/election/" in xpn:
                rev_etr_xps_lc.add(xpn)
            if "/cecomputation/elections/" in xpn:
                rev_ce_xps_lc.add(xpn)

        # 70055 (Art3.2.1.c OutstandingBalance)
        xp_321c_status = _find_xpath(config, endswith="/ETR/Election/Art3.2.1.c/Status")
        xp_321c_qib = _find_xpath(config, endswith="/ETR/Election/Art3.2.1.c/QualOwnerIntentBalance")
        xp_321c_add = _find_xpath(config, endswith="/ETR/Election/Art3.2.1.c/Additions")
        xp_321c_red = _find_xpath(config, endswith="/ETR/Election/Art3.2.1.c/Reductions")
        xp_321c_out = _find_xpath(config, endswith="/ETR/Election/Art3.2.1.c/OutstandingBalance")

        x_321c_status_lc = _norm_xpath(xp_321c_status).lower() if xp_321c_status else ""
        x_321c_qib_lc = _norm_xpath(xp_321c_qib).lower() if xp_321c_qib else ""
        x_321c_add_lc = _norm_xpath(xp_321c_add).lower() if xp_321c_add else ""
        x_321c_red_lc = _norm_xpath(xp_321c_red).lower() if xp_321c_red else ""
        x_321c_out_lc = _norm_xpath(xp_321c_out).lower() if xp_321c_out else ""

        # 70057/70058 (CEComputation election checks)
        xp_ce_tin = _find_xpath(config, endswith="/ETRStatus/ETRComputation/CEComputation/TIN")
        xp_agg_tax_tin = _find_xpath(config, endswith="/CEComputation/Elections/AggregatedReporting/TaxConsolGroupTIN")
        xp_agg_ent_tin = _find_xpath(config, endswith="/CEComputation/Elections/AggregatedReporting/EntityTIN")
        xp_inv_ent_tin = _find_xpath(config, endswith="/CEComputation/Elections/Art7.6/InvestmentEntityTIN")

        x_ce_tin_lc = _norm_xpath(xp_ce_tin).lower() if xp_ce_tin else ""
        x_agg_tax_lc = _norm_xpath(xp_agg_tax_tin).lower() if xp_agg_tax_tin else ""
        x_agg_ent_lc = _norm_xpath(xp_agg_ent_tin).lower() if xp_agg_ent_tin else ""
        x_inv_ent_lc = _norm_xpath(xp_inv_ent_tin).lower() if xp_inv_ent_tin else ""

        # 70059–70063 (AdjustmentItem checks + Art4.6.1 gate)
        xp_art461 = _find_xpath(config, endswith="/ETR/Election/Art4.6.1")
        xp_ng_adj_item = _find_xpath(config, endswith="/OverallComputation/NetGlobeIncome/Adjustments/AdjustmentItem")
        xp_ng_intship = _find_xpath(config, endswith="/OverallComputation/NetGlobeIncome/IntShippingIncome")
        xp_act_adj_item = _find_xpath(config, endswith="/OverallComputation/AdjustedCoveredTax/Adjustments/AdjustmentItem")
        xp_act_adj_amt = _find_xpath(config, endswith="/OverallComputation/AdjustedCoveredTax/Adjustments/Amount")
        xp_act_total = _find_xpath(config, endswith="/OverallComputation/AdjustedCoveredTax/Total")

        x_art461_lc = _norm_xpath(xp_art461).lower() if xp_art461 else ""
        x_ng_adj_item_lc = _norm_xpath(xp_ng_adj_item).lower() if xp_ng_adj_item else ""
        x_ng_intship_lc = _norm_xpath(xp_ng_intship).lower() if xp_ng_intship else ""
        x_act_adj_item_lc = _norm_xpath(xp_act_adj_item).lower() if xp_act_adj_item else ""
        x_act_adj_amt_lc = _norm_xpath(xp_act_adj_amt).lower() if xp_act_adj_amt else ""
        x_act_total_lc = _norm_xpath(xp_act_total).lower() if xp_act_total else ""

        # 70064–70069 (PostFilingAdjust)
        xp_pfa_dta_total = _find_xpath(config, endswith="/PostFilingAdjust/DeferTaxAsset/Total")
        xp_pfa_dta_amt = _find_xpath(config, endswith="/PostFilingAdjust/DeferTaxAsset/AmountAttributed/Amount")
        xp_pfa_dta_year = _find_xpath(config, endswith="/PostFilingAdjust/DeferTaxAsset/AmountAttributed/Year")
        xp_pfa_ctr_total = _find_xpath(config, endswith="/PostFilingAdjust/CoveredTaxRefund/Total")
        xp_pfa_ctr_amt = _find_xpath(config, endswith="/PostFilingAdjust/CoveredTaxRefund/AmountAttributed/Amount")
        xp_pfa_ctr_year = _find_xpath(config, endswith="/PostFilingAdjust/CoveredTaxRefund/AmountAttributed/Year")

        x_pfa_dta_total_lc = _norm_xpath(xp_pfa_dta_total).lower() if xp_pfa_dta_total else ""
        x_pfa_dta_amt_lc = _norm_xpath(xp_pfa_dta_amt).lower() if xp_pfa_dta_amt else ""
        x_pfa_dta_year_lc = _norm_xpath(xp_pfa_dta_year).lower() if xp_pfa_dta_year else ""
        x_pfa_ctr_total_lc = _norm_xpath(xp_pfa_ctr_total).lower() if xp_pfa_ctr_total else ""
        x_pfa_ctr_amt_lc = _norm_xpath(xp_pfa_ctr_amt).lower() if xp_pfa_ctr_amt else ""
        x_pfa_ctr_year_lc = _norm_xpath(xp_pfa_ctr_year).lower() if xp_pfa_ctr_year else ""

        # 70070–70075 (DeemedDistTax/Recapture)
        xp_ddt_year = _find_xpath(config, endswith="/DeemedDistTax/Election/Recapture/Year")
        xp_ddt_start = _find_xpath(config, endswith="/DeemedDistTax/Election/Recapture/StartAmount")
        xp_ddt_y0 = _find_xpath(config, endswith="/DeemedDistTax/Election/Recapture/DDTYear - 0")
        xp_ddt_y1 = _find_xpath(config, endswith="/DeemedDistTax/Election/Recapture/DDTYear - 1")
        xp_ddt_y2 = _find_xpath(config, endswith="/DeemedDistTax/Election/Recapture/DDTYear - 2")
        xp_ddt_y3 = _find_xpath(config, endswith="/DeemedDistTax/Election/Recapture/DDTYear - 3")
        xp_ddt_total = _find_xpath(config, endswith="/DeemedDistTax/Election/Recapture/TotalDDT")
        xp_ddt_end = _find_xpath(config, endswith="/DeemedDistTax/Election/Recapture/EndAmount")

        x_ddt_year_lc = _norm_xpath(xp_ddt_year).lower() if xp_ddt_year else ""
        x_ddt_start_lc = _norm_xpath(xp_ddt_start).lower() if xp_ddt_start else ""
        x_ddt_y0_lc = _norm_xpath(xp_ddt_y0).lower() if xp_ddt_y0 else ""
        x_ddt_y1_lc = _norm_xpath(xp_ddt_y1).lower() if xp_ddt_y1 else ""
        x_ddt_y2_lc = _norm_xpath(xp_ddt_y2).lower() if xp_ddt_y2 else ""
        x_ddt_y3_lc = _norm_xpath(xp_ddt_y3).lower() if xp_ddt_y3 else ""
        x_ddt_total_lc = _norm_xpath(xp_ddt_total).lower() if xp_ddt_total else ""
        x_ddt_end_lc = _norm_xpath(xp_ddt_end).lower() if xp_ddt_end else ""

        # 70076 (TransBlendCFC totals)
        xp_tbc_total = _find_xpath(config, endswith="/TransBlendCFC/Total")
        xp_tbc_agg = _find_xpath(config, endswith="/TransBlendCFC/CFCJur/Allocation/AggAllocTax")
        x_tbc_total_lc = _norm_xpath(xp_tbc_total).lower() if xp_tbc_total else ""
        x_tbc_agg_lc = _norm_xpath(xp_tbc_agg).lower() if xp_tbc_agg else ""

        # 70077–70079 (DeferTaxAdjustAmt formulas)
        xp_dta_total = _find_xpath(config, endswith="/DeferTaxAdjustAmt/Total")
        xp_dta_prerecast = _find_xpath(config, endswith="/DeferTaxAdjustAmt/PreRecast")
        xp_dta_lower = _find_xpath(config, endswith="/DeferTaxAdjustAmt/Recast/Lower")
        xp_dta_higher = _find_xpath(config, endswith="/DeferTaxAdjustAmt/Recast/Higher")
        xp_dta_def = _find_xpath(config, endswith="/DeferTaxAdjustAmt/DefTaxAmt")
        xp_dta_diff = _find_xpath(config, endswith="/DeferTaxAdjustAmt/DiffCarryValue")
        xp_dta_globe = _find_xpath(config, endswith="/DeferTaxAdjustAmt/GLoBEValue")
        xp_dta_bef = _find_xpath(config, endswith="/DeferTaxAdjustAmt/BefRecastAdjust")
        xp_dta_total_adj = _find_xpath(config, endswith="/DeferTaxAdjustAmt/TotalAdjust")

        x_dta_total_lc = _norm_xpath(xp_dta_total).lower() if xp_dta_total else ""
        x_dta_prerecast_lc = _norm_xpath(xp_dta_prerecast).lower() if xp_dta_prerecast else ""
        x_dta_lower_lc = _norm_xpath(xp_dta_lower).lower() if xp_dta_lower else ""
        x_dta_higher_lc = _norm_xpath(xp_dta_higher).lower() if xp_dta_higher else ""
        x_dta_def_lc = _norm_xpath(xp_dta_def).lower() if xp_dta_def else ""
        x_dta_diff_lc = _norm_xpath(xp_dta_diff).lower() if xp_dta_diff else ""
        x_dta_globe_lc = _norm_xpath(xp_dta_globe).lower() if xp_dta_globe else ""
        x_dta_bef_lc = _norm_xpath(xp_dta_bef).lower() if xp_dta_bef else ""
        x_dta_total_adj_lc = _norm_xpath(xp_dta_total_adj).lower() if xp_dta_total_adj else ""

        # -----------------------------
        # 70054: RevocationYear only when Status is FALSE (ETR/Election/*)
        # 70056: RevocationYear only when Status is FALSE (CEComputation/Elections/*)
        # -----------------------------
        for dp in submission_dps:
            xp = _dp_xpath_lc(dp)
            v = (dp.value_raw or "").strip()
            if not v:
                continue
            if xp in rev_etr_xps_lc:
                st_xp = xp.rsplit("/", 1)[0] + "/status"
                st_dp = dp_by_exact.get((dp.filer_code or None, dp.jurisdiction_code or None, dp.entity_code or None, dp.context_key or None, st_xp))
                st = _parse_bool(st_dp.value_raw if st_dp else None)
                if st is True:
                    _oecd_issue(
                        number=70054,
                        severity="BLOCKING",
                        xml_path=_norm_xpath(dp.xml_path) if dp.xml_path else None,
                        filer_code=dp.filer_code or None,
                        jurisdiction_code=dp.jurisdiction_code or None,
                        context_key=dp.context_key or None,
                        message="RevocationYear is provided even though the election Status is TRUE. RevocationYear may only be provided when Status is FALSE.",
                    )
            if xp in rev_ce_xps_lc:
                st_xp = xp.rsplit("/", 1)[0] + "/status"
                st_dp = dp_by_exact.get((dp.filer_code or None, dp.jurisdiction_code or None, dp.entity_code or None, dp.context_key or None, st_xp))
                st = _parse_bool(st_dp.value_raw if st_dp else None)
                if st is True:
                    _oecd_issue(
                        number=70056,
                        severity="BLOCKING",
                        xml_path=_norm_xpath(dp.xml_path) if dp.xml_path else None,
                        filer_code=dp.filer_code or None,
                        jurisdiction_code=dp.jurisdiction_code or None,
                        entity_code=dp.entity_code or None,
                        context_key=dp.context_key or None,
                        message="RevocationYear is provided even though the CEComputation election Status is TRUE. RevocationYear may only be provided when Status is FALSE.",
                    )

        # -----------------------------
        # 70055: OutstandingBalance = QualOwnerIntentBalance + Additions - Reductions (Art3.2.1.c)
        # -----------------------------
        if x_321c_out_lc:
            for dp_out in submission_dps:
                if _dp_xpath_lc(dp_out) != x_321c_out_lc:
                    continue
                out_val = _dp_decimal(dp_out)
                if out_val is None:
                    continue

                st = None
                if x_321c_status_lc:
                    st_dp = dp_by_exact.get((dp_out.filer_code or None, dp_out.jurisdiction_code or None, dp_out.entity_code or None, dp_out.context_key or None, x_321c_status_lc))
                    st = _parse_bool(st_dp.value_raw if st_dp else None)
                if st is False:
                    continue  # election not active; skip best-effort calc check

                qib = Decimal("0")
                add = Decimal("0")
                red = Decimal("0")
                if x_321c_qib_lc:
                    dp_q = dp_by_exact.get((dp_out.filer_code or None, dp_out.jurisdiction_code or None, dp_out.entity_code or None, dp_out.context_key or None, x_321c_qib_lc))
                    vq = _dp_decimal(dp_q) if dp_q else None
                    if vq is not None:
                        qib = vq
                if x_321c_add_lc:
                    dp_a = dp_by_exact.get((dp_out.filer_code or None, dp_out.jurisdiction_code or None, dp_out.entity_code or None, dp_out.context_key or None, x_321c_add_lc))
                    va = _dp_decimal(dp_a) if dp_a else None
                    if va is not None:
                        add = va
                if x_321c_red_lc:
                    dp_r = dp_by_exact.get((dp_out.filer_code or None, dp_out.jurisdiction_code or None, dp_out.entity_code or None, dp_out.context_key or None, x_321c_red_lc))
                    vr = _dp_decimal(dp_r) if dp_r else None
                    if vr is not None:
                        red = vr

                expected = qib + add - red
                if not _calc_equal(expected, out_val):
                    _oecd_issue(
                        number=70055,
                        severity="WARNING",
                        xml_path=xp_321c_out,
                        filer_code=dp_out.filer_code or None,
                        jurisdiction_code=dp_out.jurisdiction_code or None,
                        context_key=dp_out.context_key or None,
                        message=(
                            f"OutstandingBalance={out_val} but expected approximately {_round4(expected)} "
                            f"(QualOwnerIntentBalance={qib} + Additions={add} - Reductions={red})."
                        ),
                    )

        # -----------------------------
        # 70057/70058: CEComputation-level election cross checks
        # -----------------------------
        ce_rows: Dict[str, dict] = {}
        if x_ce_tin_lc or x_agg_tax_lc or x_agg_ent_lc or x_inv_ent_lc:
            for dp in submission_dps:
                xp = _dp_xpath_lc(dp)
                if xp not in {x_ce_tin_lc, x_agg_tax_lc, x_agg_ent_lc, x_inv_ent_lc}:
                    continue
                root = _ctx_root(dp.context_key)
                r = ce_rows.setdefault(root, {
                    "filer": dp.filer_code or None,
                    "jur": dp.jurisdiction_code or None,
                    "ent": dp.entity_code or None,
                    "ctx": root or (dp.context_key or None),
                    "ce_tin": None,
                    "tax_tin": None,
                    "entity_tin": None,
                    "inv_tin": None,
                })
                val = (dp.value_raw or "").strip()
                if xp == x_ce_tin_lc:
                    r["ce_tin"] = val
                elif xp == x_agg_tax_lc:
                    r["tax_tin"] = val
                elif xp == x_agg_ent_lc:
                    r["entity_tin"] = val
                elif xp == x_inv_ent_lc:
                    r["inv_tin"] = val

            for r in ce_rows.values():
                ce_tin = (r.get("ce_tin") or "").strip()
                tax_tin = (r.get("tax_tin") or "").strip()
                ent_tin = (r.get("entity_tin") or "").strip()
                inv_tin = (r.get("inv_tin") or "").strip()

                # 70057: If AggregatedReporting is completed (TaxConsolGroupTIN or EntityTIN present),
                # CEComputation/TIN should match TaxConsolGroupTIN.
                if (tax_tin or ent_tin) and tax_tin and ce_tin and (tax_tin != ce_tin):
                    _oecd_issue(
                        number=70057,
                        severity="WARNING",
                        xml_path=xp_ce_tin,
                        filer_code=r.get("filer"),
                        jurisdiction_code=r.get("jur"),
                        entity_code=r.get("ent"),
                        context_key=r.get("ctx"),
                        message=(
                            f"AggregatedReporting is completed, but CEComputation/TIN '{ce_tin}' does not match TaxConsolGroupTIN '{tax_tin}'."
                        ),
                    )

                # 70058: InvestmentEntityTIN must not match CEComputation TIN
                if inv_tin and ce_tin and (inv_tin == ce_tin):
                    _oecd_issue(
                        number=70058,
                        severity="BLOCKING",
                        xml_path=xp_inv_ent_tin,
                        filer_code=r.get("filer"),
                        jurisdiction_code=r.get("jur"),
                        entity_code=r.get("ent"),
                        context_key=r.get("ctx"),
                        message="InvestmentEntityTIN must not match the CEComputation/TIN, but both are identical.",
                    )

        # -----------------------------
        # 70059–70063: AdjustmentItem uniqueness + conditional completion (OverallComputation)
        # -----------------------------
        codes_ng: Dict[Tuple[Optional[str], Optional[str], str], List[str]] = {}
        codes_act: Dict[Tuple[Optional[str], Optional[str], str], List[str]] = {}
        has_intship: Set[Tuple[Optional[str], Optional[str], str]] = set()
        has_gir2025: Set[Tuple[Optional[str], Optional[str], str]] = set()
        has_gir2720: Set[Tuple[Optional[str], Optional[str], str]] = set()
        elect_461: Dict[Tuple[Optional[str], Optional[str], str], bool] = {}
        act_total_by_etr: Dict[Tuple[Optional[str], Optional[str], str], Decimal] = {}

        # For 70061: join AdjustedCoveredTax adjustment rows (code+amount) by full context_key
        act_adj_rows: Dict[Tuple[Tuple[Optional[str], Optional[str], str], Optional[str]], dict] = {}

        for dp in submission_dps:
            if not dp.jurisdiction_code:
                continue
            xp = _dp_xpath_lc(dp)
            etr = (dp.filer_code or None, dp.jurisdiction_code or None, _scope_key(dp.context_key, "ETR"))

            if x_ng_intship_lc and xp.startswith(x_ng_intship_lc):
                has_intship.add(etr)

            if x_ng_adj_item_lc and xp == x_ng_adj_item_lc:
                code = (dp.value_raw or "").strip()
                if code:
                    codes_ng.setdefault(etr, []).append(code)
                    if code == "GIR2025":
                        has_gir2025.add(etr)

            if x_art461_lc and xp == x_art461_lc:
                st = _parse_bool(dp.value_raw)
                if st is not None:
                    elect_461[etr] = bool(st)

            if x_act_adj_item_lc and xp == x_act_adj_item_lc:
                code = (dp.value_raw or "").strip()
                if code:
                    codes_act.setdefault(etr, []).append(code)
                    if code == "GIR2720":
                        has_gir2720.add(etr)
                    rk = (etr, dp.context_key or None)
                    act_adj_rows.setdefault(rk, {})["code"] = code

            if x_act_adj_amt_lc and xp == x_act_adj_amt_lc:
                amt = _dp_decimal(dp)
                rk = (etr, dp.context_key or None)
                if amt is not None:
                    act_adj_rows.setdefault(rk, {})["amount"] = amt

            if x_act_total_lc and xp == x_act_total_lc:
                tv = _dp_decimal(dp)
                if tv is not None:
                    act_total_by_etr[etr] = tv

        # 70059: unique codes per ETR for NetGlobeIncome adjustments
        for etr, codes in codes_ng.items():
            counts: Dict[str, int] = {}
            for c in codes:
                counts[c] = counts.get(c, 0) + 1
            dups = sorted([c for c, n in counts.items() if n > 1])
            if dups:
                _oecd_issue(
                    number=70059,
                    severity="BLOCKING",
                    xml_path=xp_ng_adj_item,
                    filer_code=etr[0],
                    jurisdiction_code=etr[1],
                    context_key=etr[2],
                    message=(
                        "Each AdjustmentItem code in OverallComputation/NetGlobeIncome/Adjustments can only be used once per ETR. "
                        f"Duplicate code(s) found: {', '.join(dups)}."
                    ),
                )

        # 70060: GIR2025 -> IntShippingIncome must be completed
        for etr in sorted(has_gir2025):
            if etr not in has_intship:
                _oecd_issue(
                    number=70060,
                    severity="BLOCKING",
                    xml_path=xp_ng_intship,
                    filer_code=etr[0],
                    jurisdiction_code=etr[1],
                    context_key=etr[2],
                    message="NetGlobeIncome/Adjustments contains GIR2025, so NetGlobeIncome/IntShippingIncome must be completed for this ETR.",
                )

        # 70063: unique codes per ETR for AdjustedCoveredTax adjustments
        for etr, codes in codes_act.items():
            counts: Dict[str, int] = {}
            for c in codes:
                counts[c] = counts.get(c, 0) + 1
            dups = sorted([c for c, n in counts.items() if n > 1])
            if dups:
                _oecd_issue(
                    number=70063,
                    severity="BLOCKING",
                    xml_path=xp_act_adj_item,
                    filer_code=etr[0],
                    jurisdiction_code=etr[1],
                    context_key=etr[2],
                    message=(
                        "Each AdjustmentItem code in OverallComputation/AdjustedCoveredTax/Adjustments can only be used once per ETR. "
                        f"Duplicate code(s) found: {', '.join(dups)}."
                    ),
                )

        # 70061: Art4.6.1 TRUE -> must contain GIR2711 and amount negative
        for etr, st in elect_461.items():
            if not st:
                continue
            # Find any GIR2711 row(s)
            gir2711_rows = []
            for (etr2, ctx), row in act_adj_rows.items():
                if etr2 != etr:
                    continue
                if (row.get("code") or "").strip() == "GIR2711":
                    gir2711_rows.append((ctx, row.get("amount")))
            if not gir2711_rows:
                _oecd_issue(
                    number=70061,
                    severity="BLOCKING",
                    xml_path=xp_act_adj_item,
                    filer_code=etr[0],
                    jurisdiction_code=etr[1],
                    context_key=etr[2],
                    message="Art4.6.1 election is TRUE, so AdjustedCoveredTax/Adjustments must include AdjustmentItem GIR2711 with a negative Amount, but no GIR2711 AdjustmentItem was found.",
                )
                continue

            bad = []
            for ctx, amt in gir2711_rows:
                if amt is None or amt >= 0:
                    bad.append((ctx, amt))
            if bad:
                preview = "; ".join([f"{c or '∅'}: {a}" for c, a in bad[:5]])
                _oecd_issue(
                    number=70061,
                    severity="BLOCKING",
                    xml_path=xp_act_adj_amt,
                    filer_code=etr[0],
                    jurisdiction_code=etr[1],
                    context_key=etr[2],
                    message=(
                        "Art4.6.1 election is TRUE, so AdjustmentItem GIR2711 must have a negative Amount. "
                        f"Non-negative or missing Amount found for GIR2711: {preview}"
                    ),
                )

        # 70062: if any AdjustedCoveredTax AdjustmentItem is GIR2720 then AdjustedCoveredTax Total cannot be negative
        for etr in has_gir2720:
            tot = act_total_by_etr.get(etr)
            if tot is None:
                continue
            if tot < 0:
                _oecd_issue(
                    number=70062,
                    severity="BLOCKING",
                    xml_path=xp_act_total,
                    filer_code=etr[0],
                    jurisdiction_code=etr[1],
                    context_key=etr[2],
                    message=(
                        f"AdjustedCoveredTax/Adjustments includes GIR2720, so AdjustedCoveredTax/Total cannot be negative, but Total={tot}."
                    ),
                )

        # -----------------------------
        # 70064–70069: PostFilingAdjust totals and year constraints
        # -----------------------------
        pfa_dta_total: Dict[Tuple[Optional[str], Optional[str], str], Decimal] = {}
        pfa_dta_amounts: Dict[Tuple[Optional[str], Optional[str], str], List[Decimal]] = {}
        pfa_dta_years: Dict[Tuple[Optional[str], Optional[str], str], List[int]] = {}

        pfa_ctr_total: Dict[Tuple[Optional[str], Optional[str], str], Decimal] = {}
        pfa_ctr_amounts: Dict[Tuple[Optional[str], Optional[str], str], List[Decimal]] = {}
        pfa_ctr_years: Dict[Tuple[Optional[str], Optional[str], str], List[int]] = {}

        if any([x_pfa_dta_total_lc, x_pfa_dta_amt_lc, x_pfa_dta_year_lc, x_pfa_ctr_total_lc, x_pfa_ctr_amt_lc, x_pfa_ctr_year_lc]):
            for dp in submission_dps:
                if not dp.jurisdiction_code:
                    continue
                xp = _dp_xpath_lc(dp)
                etr = (dp.filer_code or None, dp.jurisdiction_code or None, _scope_key(dp.context_key, "ETR"))

                if x_pfa_dta_total_lc and xp == x_pfa_dta_total_lc:
                    dv = _dp_decimal(dp)
                    if dv is not None:
                        pfa_dta_total[etr] = dv
                if x_pfa_dta_amt_lc and xp == x_pfa_dta_amt_lc:
                    dv = _dp_decimal(dp)
                    if dv is not None:
                        pfa_dta_amounts.setdefault(etr, []).append(dv)
                if x_pfa_dta_year_lc and xp == x_pfa_dta_year_lc:
                    y = _parse_year_int(dp.value_raw)
                    if y is not None:
                        pfa_dta_years.setdefault(etr, []).append(y)

                if x_pfa_ctr_total_lc and xp == x_pfa_ctr_total_lc:
                    dv = _dp_decimal(dp)
                    if dv is not None:
                        pfa_ctr_total[etr] = dv
                if x_pfa_ctr_amt_lc and xp == x_pfa_ctr_amt_lc:
                    dv = _dp_decimal(dp)
                    if dv is not None:
                        pfa_ctr_amounts.setdefault(etr, []).append(dv)
                if x_pfa_ctr_year_lc and xp == x_pfa_ctr_year_lc:
                    y = _parse_year_int(dp.value_raw)
                    if y is not None:
                        pfa_ctr_years.setdefault(etr, []).append(y)

            # 70064 / 70065 (totals)
            for etr, tot in pfa_dta_total.items():
                amts = pfa_dta_amounts.get(etr, [])
                if not amts:
                    continue
                expected = sum(amts, Decimal("0"))
                if not _calc_equal(expected, tot):
                    _oecd_issue(
                        number=70064,
                        severity="WARNING",
                        xml_path=xp_pfa_dta_total,
                        filer_code=etr[0],
                        jurisdiction_code=etr[1],
                        context_key=etr[2],
                        message=f"PostFilingAdjust/DeferTaxAsset/Total={tot} but expected approximately {_round4(expected)} (sum of AmountAttributed/Amount).",
                    )

            for etr, tot in pfa_ctr_total.items():
                amts = pfa_ctr_amounts.get(etr, [])
                if not amts:
                    continue
                expected = sum(amts, Decimal("0"))
                if not _calc_equal(expected, tot):
                    _oecd_issue(
                        number=70065,
                        severity="WARNING",
                        xml_path=xp_pfa_ctr_total,
                        filer_code=etr[0],
                        jurisdiction_code=etr[1],
                        context_key=etr[2],
                        message=f"PostFilingAdjust/CoveredTaxRefund/Total={tot} but expected approximately {_round4(expected)} (sum of AmountAttributed/Amount).",
                    )

            # 70066 / 70068 (years <= Period Start year)
            if ps_year is not None:
                for etr, ys in pfa_dta_years.items():
                    bad = sorted([y for y in ys if y > ps_year])
                    if bad:
                        _oecd_issue(
                            number=70066,
                            severity="WARNING",
                            xml_path=xp_pfa_dta_year,
                            filer_code=etr[0],
                            jurisdiction_code=etr[1],
                            context_key=etr[2],
                            message=f"DeferTaxAsset/AmountAttributed/Year contains year(s) after Period Start year ({ps_year}): {', '.join(map(str, bad))}.",
                        )
                for etr, ys in pfa_ctr_years.items():
                    bad = sorted([y for y in ys if y > ps_year])
                    if bad:
                        _oecd_issue(
                            number=70068,
                            severity="WARNING",
                            xml_path=xp_pfa_ctr_year,
                            filer_code=etr[0],
                            jurisdiction_code=etr[1],
                            context_key=etr[2],
                            message=f"CoveredTaxRefund/AmountAttributed/Year contains year(s) after Period Start year ({ps_year}): {', '.join(map(str, bad))}.",
                        )

            # 70067 / 70069 (duplicate years within the same ETR)
            for etr, ys in pfa_dta_years.items():
                counts: Dict[int, int] = {}
                for y in ys:
                    counts[y] = counts.get(y, 0) + 1
                dups = sorted([y for y, n in counts.items() if n > 1])
                if dups:
                    _oecd_issue(
                        number=70067,
                        severity="BLOCKING",
                        xml_path=xp_pfa_dta_year,
                        filer_code=etr[0],
                        jurisdiction_code=etr[1],
                        context_key=etr[2],
                        message=f"DeferTaxAsset/AmountAttributed includes duplicate Year value(s): {', '.join(map(str, dups))}. Years must be unique when more than one AmountAttributed is provided.",
                    )

            for etr, ys in pfa_ctr_years.items():
                counts: Dict[int, int] = {}
                for y in ys:
                    counts[y] = counts.get(y, 0) + 1
                dups = sorted([y for y, n in counts.items() if n > 1])
                if dups:
                    _oecd_issue(
                        number=70069,
                        severity="BLOCKING",
                        xml_path=xp_pfa_ctr_year,
                        filer_code=etr[0],
                        jurisdiction_code=etr[1],
                        context_key=etr[2],
                        message=f"CoveredTaxRefund/AmountAttributed includes duplicate Year value(s): {', '.join(map(str, dups))}. Years must be unique when more than one AmountAttributed is provided.",
                    )

        # -----------------------------
        # 70070–70075: DeemedDistTax/Recapture year window + arithmetic checks
        # -----------------------------
        ddt_year_by_etr: Dict[Tuple[Optional[str], Optional[str], str], int] = {}
        ddt_vals: Dict[Tuple[Optional[str], Optional[str], str], dict] = {}

        if x_ddt_year_lc:
            for dp in submission_dps:
                if not dp.jurisdiction_code:
                    continue
                xp = _dp_xpath_lc(dp)
                etr = (dp.filer_code or None, dp.jurisdiction_code or None, _scope_key(dp.context_key, "ETR"))
                d = ddt_vals.setdefault(etr, {})
                if xp == x_ddt_year_lc:
                    y = _parse_year_int(dp.value_raw)
                    if y is not None:
                        ddt_year_by_etr[etr] = y
                elif xp == x_ddt_start_lc:
                    v = _dp_decimal(dp)
                    if v is not None:
                        d["start"] = v
                elif xp == x_ddt_total_lc:
                    v = _dp_decimal(dp)
                    if v is not None:
                        d["total"] = v
                elif xp == x_ddt_end_lc:
                    v = _dp_decimal(dp)
                    if v is not None:
                        d["end"] = v
                elif xp in {x_ddt_y0_lc, x_ddt_y1_lc, x_ddt_y2_lc, x_ddt_y3_lc}:
                    v = _dp_decimal(dp)
                    if v is not None:
                        d.setdefault("years", {})[xp] = v

            for etr, year in ddt_year_by_etr.items():
                # 70070: Year cannot be after Period End year
                if pe_year is not None and year > pe_year:
                    _oecd_issue(
                        number=70070,
                        severity="BLOCKING",
                        xml_path=xp_ddt_year,
                        filer_code=etr[0],
                        jurisdiction_code=etr[1],
                        context_key=etr[2],
                        message=f"DeemedDistTax Recapture Year={year} is after the Period End year ({pe_year}).",
                    )

                # 70071: Year must be within current RFY and previous 3 years (>= pe_year-3)
                if pe_year is not None and year <= (pe_year - 4):
                    _oecd_issue(
                        number=70071,
                        severity="BLOCKING",
                        xml_path=xp_ddt_year,
                        filer_code=etr[0],
                        jurisdiction_code=etr[1],
                        context_key=etr[2],
                        message=f"DeemedDistTax Recapture Year={year} is 4 years or more before the Period End year ({pe_year}). Allowed range is {pe_year-3}–{pe_year}.",
                    )

                d = ddt_vals.get(etr, {})
                # 70074: TotalDDT = sum(DDTYear - 0..3)
                years_map = d.get("years", {}) or {}
                if "total" in d and years_map:
                    ysum = sum([years_map.get(x_ddt_y0_lc, Decimal('0')),
                                years_map.get(x_ddt_y1_lc, Decimal('0')),
                                years_map.get(x_ddt_y2_lc, Decimal('0')),
                                years_map.get(x_ddt_y3_lc, Decimal('0'))], Decimal("0"))
                    if not _calc_equal(ysum, d["total"]):
                        _oecd_issue(
                            number=70074,
                            severity="WARNING",
                            xml_path=xp_ddt_total,
                            filer_code=etr[0],
                            jurisdiction_code=etr[1],
                            context_key=etr[2],
                            message=f"TotalDDT={d['total']} but expected approximately {_round4(ysum)} (DDTYear-0..3 sum).",
                        )

                # 70072: EndAmount = StartAmount - TotalDDT
                if "end" in d and "start" in d and "total" in d:
                    expected_end = d["start"] - d["total"]
                    if not _calc_equal(expected_end, d["end"]):
                        _oecd_issue(
                            number=70072,
                            severity="WARNING",
                            xml_path=xp_ddt_end,
                            filer_code=etr[0],
                            jurisdiction_code=etr[1],
                            context_key=etr[2],
                            message=f"EndAmount={d['end']} but expected approximately {_round4(expected_end)} (StartAmount={d['start']} - TotalDDT={d['total']}).",
                        )

                # 70073: EndAmount must not be negative
                if "end" in d and d["end"] < 0:
                    _oecd_issue(
                        number=70073,
                        severity="BLOCKING",
                        xml_path=xp_ddt_end,
                        filer_code=etr[0],
                        jurisdiction_code=etr[1],
                        context_key=etr[2],
                        message=f"EndAmount is negative ({d['end']}). EndAmount must not be negative.",
                    )

                # 70075: If Year equals Period End year, DDTYear - 0..3 should be present and 0
                if pe_year is not None and year == pe_year:
                    missing_or_nonzero = []
                    for lab, x in [("DDTYear-0", x_ddt_y0_lc), ("DDTYear-1", x_ddt_y1_lc), ("DDTYear-2", x_ddt_y2_lc), ("DDTYear-3", x_ddt_y3_lc)]:
                        vv = years_map.get(x)
                        if vv is None:
                            missing_or_nonzero.append(f"{lab}=<missing>")
                        else:
                            try:
                                if vv != 0:
                                    missing_or_nonzero.append(f"{lab}={vv}")
                            except Exception:
                                missing_or_nonzero.append(f"{lab}={vv}")
                    if missing_or_nonzero:
                        _oecd_issue(
                            number=70075,
                            severity="WARNING",
                            xml_path=xp_ddt_y0 or xp_ddt_year,
                            filer_code=etr[0],
                            jurisdiction_code=etr[1],
                            context_key=etr[2],
                            message=(
                                f"Recapture Year equals Period End year ({pe_year}); OECD guidance expects DDTYear-0..3 to be completed with 0. "
                                f"Found: {', '.join(missing_or_nonzero)}."
                            ),
                        )

        # -----------------------------
        # 70076: TransBlendCFC Total = sum(AggAllocTax)
        # -----------------------------
        if x_tbc_total_lc:
            tbc_total: Dict[Tuple[Optional[str], Optional[str], str], Decimal] = {}
            tbc_amts: Dict[Tuple[Optional[str], Optional[str], str], List[Decimal]] = {}
            for dp in submission_dps:
                if not dp.jurisdiction_code:
                    continue
                xp = _dp_xpath_lc(dp)
                etr = (dp.filer_code or None, dp.jurisdiction_code or None, _scope_key(dp.context_key, "ETR"))
                if x_tbc_total_lc and xp == x_tbc_total_lc:
                    v = _dp_decimal(dp)
                    if v is not None:
                        tbc_total[etr] = v
                if x_tbc_agg_lc and xp == x_tbc_agg_lc:
                    v = _dp_decimal(dp)
                    if v is not None:
                        tbc_amts.setdefault(etr, []).append(v)
            for etr, tot in tbc_total.items():
                amts = tbc_amts.get(etr, [])
                if not amts:
                    continue
                expected = sum(amts, Decimal("0"))
                if not _calc_equal(expected, tot):
                    _oecd_issue(
                        number=70076,
                        severity="WARNING",
                        xml_path=xp_tbc_total,
                        filer_code=etr[0],
                        jurisdiction_code=etr[1],
                        context_key=etr[2],
                        message=f"TransBlendCFC/Total={tot} but expected approximately {_round4(expected)} (sum of AggAllocTax).",
                    )

        # -----------------------------
        # 70077–70079: DeferTaxAdjustAmt formulas (OverallComputation/AdjustedCoveredTax)
        # -----------------------------
        if x_dta_total_lc:
            dta_vals: Dict[Tuple[Optional[str], Optional[str], str], dict] = {}
            for dp in submission_dps:
                if not dp.jurisdiction_code:
                    continue
                xp = _dp_xpath_lc(dp)
                etr = (dp.filer_code or None, dp.jurisdiction_code or None, _scope_key(dp.context_key, "ETR"))
                if xp not in {x_dta_total_lc, x_dta_prerecast_lc, x_dta_lower_lc, x_dta_higher_lc, x_dta_def_lc, x_dta_diff_lc, x_dta_globe_lc, x_dta_bef_lc, x_dta_total_adj_lc}:
                    continue
                d = dta_vals.setdefault(etr, {})
                v = _dp_decimal(dp)
                if v is None:
                    continue
                if xp == x_dta_total_lc:
                    d["total"] = v
                elif xp == x_dta_prerecast_lc:
                    d["prerecast"] = v
                elif xp == x_dta_lower_lc:
                    d["lower"] = v
                elif xp == x_dta_higher_lc:
                    d["higher"] = v
                elif xp == x_dta_def_lc:
                    d["deftax"] = v
                elif xp == x_dta_diff_lc:
                    d["diffcarry"] = v
                elif xp == x_dta_globe_lc:
                    d["globeval"] = v
                elif xp == x_dta_bef_lc:
                    d["befrecast"] = v
                elif xp == x_dta_total_adj_lc:
                    d["totaladjust"] = v

            for etr, d in dta_vals.items():
                # 70078: BefRecastAdjust = DefTaxAmt - DiffCarryValue + GLoBEValue
                if {"befrecast", "deftax", "diffcarry", "globeval"} <= set(d.keys()):
                    expected = d["deftax"] - d["diffcarry"] + d["globeval"]
                    if not _calc_equal(expected, d["befrecast"]):
                        _oecd_issue(
                            number=70078,
                            severity="WARNING",
                            xml_path=xp_dta_bef,
                            filer_code=etr[0],
                            jurisdiction_code=etr[1],
                            context_key=etr[2],
                            message=f"BefRecastAdjust={d['befrecast']} but expected approximately {_round4(expected)} (DefTaxAmt - DiffCarryValue + GLoBEValue).",
                        )

                # 70079: PreRecast = BefRecastAdjust + TotalAdjust
                if {"prerecast", "befrecast", "totaladjust"} <= set(d.keys()):
                    expected = d["befrecast"] + d["totaladjust"]
                    if not _calc_equal(expected, d["prerecast"]):
                        _oecd_issue(
                            number=70079,
                            severity="WARNING",
                            xml_path=xp_dta_prerecast,
                            filer_code=etr[0],
                            jurisdiction_code=etr[1],
                            context_key=etr[2],
                            message=f"PreRecast={d['prerecast']} but expected approximately {_round4(expected)} (BefRecastAdjust + TotalAdjust).",
                        )

                # 70077: Total = PreRecast + Lower - Higher (missing lower/higher treated as 0)
                if "total" in d and "prerecast" in d:
                    lower = d.get("lower", Decimal("0"))
                    higher = d.get("higher", Decimal("0"))
                    expected = d["prerecast"] + lower - higher
                    if not _calc_equal(expected, d["total"]):
                        _oecd_issue(
                            number=70077,
                            severity="WARNING",
                            xml_path=xp_dta_total,
                            filer_code=etr[0],
                            jurisdiction_code=etr[1],
                            context_key=etr[2],
                            message=f"DeferTaxAdjustAmt/Total={d['total']} but expected approximately {_round4(expected)} (PreRecast + Lower - Higher; missing treated as 0).",
                        )

    except Exception:
        # Non-fatal: Stage 9 OECD cross-record validations are best-effort.
        pass


    # -----------------------------
    # Stage 10: OECD cross-record validations — Deferred tax transition, Excess negative tax expense,
    #           Additional Top-up Tax, LTCE (IIR) and UTPR attribution — 70080–70103
    # -----------------------------
    #
    # Focus: the next set of OECD Status Message validation rules after 70079:
    #   - 70080: DeferTaxAdjustAmt adjustment item uniqueness
    #   - 70081–70082: Transition/DeferredTaxAssets arithmetic and mutual exclusivity
    #   - 70083: ExcessNegTaxExpense remaining balance arithmetic
    #   - 70084–70085: link AdjustedCoveredTax adjustments (GIR2719 / GIR2720) to ExcessNegTaxExpense
    #   - 70086–70087: ExcessProfits and SubstanceExclusion arithmetic
    #   - 70088–70092: AdditionalTopUpTax (Art4.1.5) gating + arithmetic
    #   - 70093–70096: AdditionalTopUpTax (NONArt4.1.5) Year constraints + arithmetic
    #   - 70097–70099: LTCE IIR and UTPR attribution cross‑section arithmetic
    #   - 70100–70103: UTPR attribution requiredness + percentage gating
    try:
        def _oecd_issue(
            *,
            number: int,
            severity: str,
            xml_path: Optional[str],
            message: str,
            filer_code: Optional[str] = None,
            jurisdiction_code: Optional[str] = None,
            entity_code: Optional[str] = None,
            context_key: Optional[str] = None,
        ) -> None:
            num = number if number in error_map else None
            issues.append(Issue(
                severity=severity,
                rule_id=_rid(
                    "OECD",
                    f"{number}|{xml_path}|{filer_code}|{jurisdiction_code}|{entity_code}|{context_key}|{message}",
                ),
                section="Jurisdiction",
                xml_path=xml_path,
                filer_code=filer_code,
                jurisdiction_code=jurisdiction_code,
                entity_code=entity_code,
                context_key=context_key,
                error_number=num,
                message=message,
                how_to_fix=_oecd_fix_text(error_map, num) if num else None,
            ))

        def _scope_key(ctx: Optional[str], tag: str) -> str:
            """Return a stable scope key for a repeatable record block."""
            if not ctx:
                return ""
            parts = str(ctx).split("|")
            for i, p in enumerate(parts):
                if p.startswith(f"DOCREF:{tag}:") or p.startswith(f"IDX:{tag}:"):
                    return "|".join(parts[: i + 1])
            return parts[0]

        def _parse_year_int(v: Optional[str]) -> Optional[int]:
            if v is None:
                return None
            s = str(v).strip()
            if not s:
                return None
            try:
                return int(s)
            except Exception:
                m = re.match(r"^\s*(\d{4})", s)
                if m:
                    try:
                        return int(m.group(1))
                    except Exception:
                        return None
            return None

        def _parse_percent(v: Optional[str]) -> Optional[Decimal]:
            """Parse percent-like values: '0', '0.0', '0%', '12.5%' -> Decimal."""
            if v is None:
                return None
            s = str(v).strip()
            if not s:
                return None
            if s.endswith("%"):
                s = s[:-1].strip()
            return try_parse_decimal(s)

        # Filing period end year (used by 70093–70095)
        pe = getattr(filing, "period_end", None)
        pe_year = pe.year if pe else None

        # Fast lookup for sibling access (same filer/juris/entity/context/xpath)
        dp_by_exact: Dict[Tuple[Optional[str], Optional[str], Optional[str], Optional[str], str], models.DataPoint] = {}
        for dp in submission_dps:
            xp = _dp_xpath_lc(dp)
            dp_by_exact[(dp.filer_code or None, dp.jurisdiction_code or None, dp.entity_code or None, dp.context_key or None, xp)] = dp

        # --- XPaths ---
        # 70080: DeferTaxAdjustAmt adjustments
        xp_dta_adj_item = _find_xpath(config, endswith="/DeferTaxAdjustAmt/Adjustments/AdjustmentItem")
        x_dta_adj_item_lc = _norm_xpath(xp_dta_adj_item).lower() if xp_dta_adj_item else ""

        # 70081–70082: Transition/DeferredTaxAssets
        xp_tr_total = _find_xpath(config, endswith="/DeferTaxAdjustAmt/Transition/DeferredTaxAssets/Total")
        xp_tr_start = _find_xpath(config, endswith="/DeferTaxAdjustAmt/Transition/DeferredTaxAssets/DeferredTaxAssetStart")
        xp_tr_recast = _find_xpath(config, endswith="/DeferTaxAdjustAmt/Transition/DeferredTaxAssets/DeferredTaxAssetRecast")
        xp_tr_excl = _find_xpath(config, endswith="/DeferTaxAdjustAmt/Transition/DeferredTaxAssets/DeferredTaxAssetExcluded")
        x_tr_total_lc = _norm_xpath(xp_tr_total).lower() if xp_tr_total else ""
        x_tr_start_lc = _norm_xpath(xp_tr_start).lower() if xp_tr_start else ""
        x_tr_recast_lc = _norm_xpath(xp_tr_recast).lower() if xp_tr_recast else ""
        x_tr_excl_lc = _norm_xpath(xp_tr_excl).lower() if xp_tr_excl else ""
        tr_container_lc = ""
        if x_tr_total_lc:
            tr_container_lc = x_tr_total_lc.rsplit("/", 1)[0]

        # 70083: ExcessNegTaxExpense arithmetic
        xp_exn_prior = _find_xpath(config, endswith="/ExcessNegTaxExpense/PriorYearBalance")
        xp_exn_gen = _find_xpath(config, endswith="/ExcessNegTaxExpense/GeneratedInRFY")
        xp_exn_util = _find_xpath(config, endswith="/ExcessNegTaxExpense/UtilizedInRFY")
        xp_exn_rem = _find_xpath(config, endswith="/ExcessNegTaxExpense/Remaining")
        x_exn_prior_lc = _norm_xpath(xp_exn_prior).lower() if xp_exn_prior else ""
        x_exn_gen_lc = _norm_xpath(xp_exn_gen).lower() if xp_exn_gen else ""
        x_exn_util_lc = _norm_xpath(xp_exn_util).lower() if xp_exn_util else ""
        x_exn_rem_lc = _norm_xpath(xp_exn_rem).lower() if xp_exn_rem else ""

        # 70084–70085: link AdjustedCoveredTax adjustments to ExcessNegTaxExpense
        xp_act_adj_item = _find_xpath(config, endswith="/OverallComputation/AdjustedCoveredTax/Adjustments/AdjustmentItem")
        xp_act_adj_amt = _find_xpath(config, endswith="/OverallComputation/AdjustedCoveredTax/Adjustments/Amount")
        x_act_adj_item_lc = _norm_xpath(xp_act_adj_item).lower() if xp_act_adj_item else ""
        x_act_adj_amt_lc = _norm_xpath(xp_act_adj_amt).lower() if xp_act_adj_amt else ""

        # 70086–70087: ExcessProfits + SubstanceExclusion arithmetic
        xp_ng_total = _find_xpath(config, endswith="/OverallComputation/NetGlobeIncome/Total")
        xp_se_total = _find_xpath(config, endswith="/OverallComputation/SubstanceExclusion/Total")
        xp_excess_profits = _find_xpath(config, endswith="/OverallComputation/ExcessProfits")
        x_ng_total_lc = _norm_xpath(xp_ng_total).lower() if xp_ng_total else ""
        x_se_total_lc = _norm_xpath(xp_se_total).lower() if xp_se_total else ""
        x_excess_profits_lc = _norm_xpath(xp_excess_profits).lower() if xp_excess_profits else ""

        xp_se_payroll_cost = _find_xpath(config, endswith="/OverallComputation/SubstanceExclusion/PayrollCost")
        xp_se_payroll_mu = _find_xpath(config, endswith="/OverallComputation/SubstanceExclusion/PayrollMarkUp")
        xp_se_tav = _find_xpath(config, endswith="/OverallComputation/SubstanceExclusion/TangibleAssetValue")
        xp_se_tav_mu = _find_xpath(config, endswith="/OverallComputation/SubstanceExclusion/TangibleAssetMarkup")
        x_se_payroll_cost_lc = _norm_xpath(xp_se_payroll_cost).lower() if xp_se_payroll_cost else ""
        x_se_payroll_mu_lc = _norm_xpath(xp_se_payroll_mu).lower() if xp_se_payroll_mu else ""
        x_se_tav_lc = _norm_xpath(xp_se_tav).lower() if xp_se_tav else ""
        x_se_tav_mu_lc = _norm_xpath(xp_se_tav_mu).lower() if xp_se_tav_mu else ""

        # 70088–70092: AdditionalTopUpTax Art4.1.5
        xp_art415 = _find_xpath(config, endswith="/OverallComputation/AdditionalTopUpTax/Art4.1.5")
        xp_art_adjct = _find_xpath(config, endswith="/AdditionalTopUpTax/Art4.1.5/AdjustedCoveredTax")
        xp_art_gl = _find_xpath(config, endswith="/AdditionalTopUpTax/Art4.1.5/GlobeLoss")
        xp_art_exp = _find_xpath(config, endswith="/AdditionalTopUpTax/Art4.1.5/ExpectedAdjustedCoveredTax")
        xp_art_add = _find_xpath(config, endswith="/AdditionalTopUpTax/Art4.1.5/AdditionalTopUpTax")
        x_art415_lc = _norm_xpath(xp_art415).lower() if xp_art415 else ""
        art415_container_lc = x_art415_lc
        x_art_adjct_lc = _norm_xpath(xp_art_adjct).lower() if xp_art_adjct else ""
        x_art_gl_lc = _norm_xpath(xp_art_gl).lower() if xp_art_gl else ""
        x_art_exp_lc = _norm_xpath(xp_art_exp).lower() if xp_art_exp else ""
        x_art_add_lc = _norm_xpath(xp_art_add).lower() if xp_art_add else ""

        # 70093–70096: AdditionalTopUpTax NONArt4.1.5
        xp_non_year = _find_xpath(config, endswith="/AdditionalTopUpTax/NONArt4.1.5/Year")
        xp_non_articles = _find_xpath(config, endswith="/AdditionalTopUpTax/NONArt4.1.5/Articles")
        xp_non_add = _find_xpath(config, endswith="/AdditionalTopUpTax/NONArt4.1.5/AdditionalTopUpTax")
        xp_non_prev_tut = _find_xpath(config, endswith="/AdditionalTopUpTax/NONArt4.1.5/Previous/TopUpTax")
        xp_non_recalc_tut = _find_xpath(config, endswith="/AdditionalTopUpTax/NONArt4.1.5/Recalculated/TopUpTax")
        x_non_year_lc = _norm_xpath(xp_non_year).lower() if xp_non_year else ""
        x_non_articles_lc = _norm_xpath(xp_non_articles).lower() if xp_non_articles else ""
        x_non_add_lc = _norm_xpath(xp_non_add).lower() if xp_non_add else ""
        x_non_prev_tut_lc = _norm_xpath(xp_non_prev_tut).lower() if xp_non_prev_tut else ""
        x_non_recalc_tut_lc = _norm_xpath(xp_non_recalc_tut).lower() if xp_non_recalc_tut else ""

        # 70097–70098: LTCE IIR ParentEntity arithmetic
        xp_ltce_net = _find_xpath(config, endswith="/LowTaxJurisdiction/LTCE/IIR/NetGlobeIncome")
        xp_ltce_topuptax = _find_xpath(config, endswith="/LowTaxJurisdiction/LTCE/IIR/TopUpTax")
        xp_ltce_other = _find_xpath(config, endswith="/LowTaxJurisdiction/LTCE/IIR/ParentEntity/OtherOwnershipAllocation")
        xp_ltce_ratio = _find_xpath(config, endswith="/LowTaxJurisdiction/LTCE/IIR/ParentEntity/InclusionRatio")
        xp_ltce_share = _find_xpath(config, endswith="/LowTaxJurisdiction/LTCE/IIR/ParentEntity/TopUpTaxShare")
        x_ltce_net_lc = _norm_xpath(xp_ltce_net).lower() if xp_ltce_net else ""
        x_ltce_topuptax_lc = _norm_xpath(xp_ltce_topuptax).lower() if xp_ltce_topuptax else ""
        x_ltce_other_lc = _norm_xpath(xp_ltce_other).lower() if xp_ltce_other else ""
        x_ltce_ratio_lc = _norm_xpath(xp_ltce_ratio).lower() if xp_ltce_ratio else ""
        x_ltce_share_lc = _norm_xpath(xp_ltce_share).lower() if xp_ltce_share else ""

        # 70099–70103: UTPR Attribution
        xp_utpr_total = _find_xpath(config, endswith="/LowTaxJurisdiction/UTPR/UTPRCalculation/TotalUTPRTopUpTax")
        x_utpr_total_lc = _norm_xpath(xp_utpr_total).lower() if xp_utpr_total else ""

        xp_utpr_attr = _find_xpath(config, endswith="/UTPRAttribution/Attribution/UTPRTopUpTaxAttributed")
        xp_utpr_carry = _find_xpath(config, endswith="/UTPRAttribution/Attribution/UTPRTopUpTaxCarryForward")
        xp_utpr_emp = _find_xpath(config, endswith="/UTPRAttribution/Attribution/Employees")
        xp_utpr_tav = _find_xpath(config, endswith="/UTPRAttribution/Attribution/TangibleAssetValue")
        xp_utpr_pct = _find_xpath(config, endswith="/UTPRAttribution/Attribution/UTPRPercentage")
        x_utpr_attr_lc = _norm_xpath(xp_utpr_attr).lower() if xp_utpr_attr else ""
        x_utpr_carry_lc = _norm_xpath(xp_utpr_carry).lower() if xp_utpr_carry else ""
        x_utpr_emp_lc = _norm_xpath(xp_utpr_emp).lower() if xp_utpr_emp else ""
        x_utpr_tav_lc = _norm_xpath(xp_utpr_tav).lower() if xp_utpr_tav else ""
        x_utpr_pct_lc = _norm_xpath(xp_utpr_pct).lower() if xp_utpr_pct else ""

        # Detect whether UTPRAttribution is "completed" (any datapoint under container)
        utpr_container_lc = "/globe_oecd/globebody/utprattribution"
        has_any_utpr_attr = any((_dp_xpath_lc(dp).startswith(utpr_container_lc) and (dp.value_raw or "").strip() != "") for dp in submission_dps)

        # -----------------------------
        # 70080: DeferTaxAdjustAmt/Adjustments/AdjustmentItem must be unique per ETR scope
        # -----------------------------
        if x_dta_adj_item_lc:
            seen: Dict[Tuple[Optional[str], Optional[str], str], Dict[str, int]] = {}
            for dp in submission_dps:
                if not dp.jurisdiction_code:
                    continue
                xp = _dp_xpath_lc(dp)
                if xp != x_dta_adj_item_lc:
                    continue
                code = (dp.value_raw or "").strip()
                if not code:
                    continue
                etr = (dp.filer_code or None, dp.jurisdiction_code or None, _scope_key(dp.context_key, "ETR"))
                m = seen.setdefault(etr, {})
                m[code] = m.get(code, 0) + 1

            for etr, m in seen.items():
                dups = sorted([c for c, n in m.items() if n > 1])
                if dups:
                    _oecd_issue(
                        number=70080,
                        severity="BLOCKING",
                        xml_path=xp_dta_adj_item,
                        filer_code=etr[0],
                        jurisdiction_code=etr[1],
                        context_key=etr[2],
                        message=(
                            "DeferTaxAdjustAmt/Adjustments contains duplicate AdjustmentItem value(s): "
                            f"{', '.join(dups)}. Each AdjustmentItem can only be used once per ETRComputation."
                        ),
                    )

        # -----------------------------
        # 70081–70082: Transition/DeferredTaxAssets
        # -----------------------------
        if tr_container_lc:
            tr_vals: Dict[Tuple[Optional[str], Optional[str], str], dict] = {}
            tr_present: Set[Tuple[Optional[str], Optional[str], str]] = set()

            for dp in submission_dps:
                if not dp.jurisdiction_code:
                    continue
                xp = _dp_xpath_lc(dp)
                etr = (dp.filer_code or None, dp.jurisdiction_code or None, _scope_key(dp.context_key, "ETR"))
                if xp.startswith(tr_container_lc):
                    # Any datapoint under the container implies DeferredTaxAssets element is provided.
                    if (dp.value_raw or "").strip() != "":
                        tr_present.add(etr)

                if xp not in {x_tr_total_lc, x_tr_start_lc, x_tr_recast_lc, x_tr_excl_lc}:
                    continue
                v = _dp_decimal(dp)
                if v is None:
                    continue
                d = tr_vals.setdefault(etr, {})
                if xp == x_tr_total_lc:
                    d["total"] = v
                elif xp == x_tr_start_lc:
                    d["start"] = v
                elif xp == x_tr_recast_lc:
                    d["recast"] = v
                elif xp == x_tr_excl_lc:
                    d["excluded"] = v

            # 70082: mutual exclusivity (one of Start/Recast must be 0) when DeferredTaxAssets provided
            for etr in tr_present:
                d = tr_vals.get(etr, {})
                if "start" in d and "recast" in d:
                    if d["start"] != 0 and d["recast"] != 0:
                        _oecd_issue(
                            number=70082,
                            severity="BLOCKING",
                            xml_path=xp_tr_start,
                            filer_code=etr[0],
                            jurisdiction_code=etr[1],
                            context_key=etr[2],
                            message=(
                                "DeferredTaxAssets is provided, but both DeferredTaxAssetStart and DeferredTaxAssetRecast are non-zero. "
                                "One of these values must be reported as 0."
                            ),
                        )

            # 70081: Total formula (either Start-Excluded OR Recast-Excluded)
            for etr, d in tr_vals.items():
                if "total" not in d or "excluded" not in d:
                    continue
                candidates: List[Decimal] = []
                if "start" in d:
                    candidates.append(d["start"] - d["excluded"])
                if "recast" in d:
                    candidates.append(d["recast"] - d["excluded"])
                if not candidates:
                    continue
                if not any(_calc_equal(exp, d["total"]) for exp in candidates):
                    exp_txt = " or ".join([str(_round4(c)) for c in candidates])
                    _oecd_issue(
                        number=70081,
                        severity="WARNING",
                        xml_path=xp_tr_total,
                        filer_code=etr[0],
                        jurisdiction_code=etr[1],
                        context_key=etr[2],
                        message=f"Transition/DeferredTaxAssets/Total={d['total']} but expected approximately {exp_txt} (Start-Excluded or Recast-Excluded).",
                    )

        # -----------------------------
        # 70083: ExcessNegTaxExpense Remaining = Prior + Generated - Utilized
        # -----------------------------
        if x_exn_rem_lc:
            exn: Dict[Tuple[Optional[str], Optional[str], str], dict] = {}
            for dp in submission_dps:
                if not dp.jurisdiction_code:
                    continue
                xp = _dp_xpath_lc(dp)
                if xp not in {x_exn_prior_lc, x_exn_gen_lc, x_exn_util_lc, x_exn_rem_lc}:
                    continue
                v = _dp_decimal(dp)
                if v is None:
                    continue
                etr = (dp.filer_code or None, dp.jurisdiction_code or None, _scope_key(dp.context_key, "ETR"))
                d = exn.setdefault(etr, {})
                if xp == x_exn_prior_lc:
                    d["prior"] = v
                elif xp == x_exn_gen_lc:
                    d["gen"] = v
                elif xp == x_exn_util_lc:
                    d["util"] = v
                elif xp == x_exn_rem_lc:
                    d["rem"] = v

            for etr, d in exn.items():
                if {"prior", "gen", "util", "rem"} <= set(d.keys()):
                    expected = d["prior"] + d["gen"] - d["util"]
                    if not _calc_equal(expected, d["rem"]):
                        _oecd_issue(
                            number=70083,
                            severity="WARNING",
                            xml_path=xp_exn_rem,
                            filer_code=etr[0],
                            jurisdiction_code=etr[1],
                            context_key=etr[2],
                            message=f"ExcessNegTaxExpense/Remaining={d['rem']} but expected approximately {_round4(expected)} (PriorYearBalance + GeneratedInRFY - UtilizedInRFY).",
                        )

        # -----------------------------
        # 70084–70085: AdjustedCoveredTax adjustments GIR2719/GIR2720 must match Generated/Utilized
        # -----------------------------
        if x_act_adj_item_lc and x_act_adj_amt_lc and x_exn_gen_lc and x_exn_util_lc:
            # Map Generated/Utilized per ETR scope
            gu: Dict[Tuple[Optional[str], Optional[str], str], dict] = {}
            for dp in submission_dps:
                if not dp.jurisdiction_code:
                    continue
                xp = _dp_xpath_lc(dp)
                if xp not in {x_exn_gen_lc, x_exn_util_lc}:
                    continue
                v = _dp_decimal(dp)
                if v is None:
                    continue
                etr = (dp.filer_code or None, dp.jurisdiction_code or None, _scope_key(dp.context_key, "ETR"))
                d = gu.setdefault(etr, {})
                if xp == x_exn_gen_lc:
                    d["gen"] = v
                else:
                    d["util"] = v

            for dp in submission_dps:
                if not dp.jurisdiction_code:
                    continue
                xp = _dp_xpath_lc(dp)
                if xp != x_act_adj_item_lc:
                    continue
                code = (dp.value_raw or "").strip()
                if code not in {"GIR2719", "GIR2720"}:
                    continue
                etr = (dp.filer_code or None, dp.jurisdiction_code or None, _scope_key(dp.context_key, "ETR"))
                d = gu.get(etr, {})
                target = d.get("gen") if code == "GIR2719" else d.get("util")
                if target is None:
                    continue

                sib = dp_by_exact.get((dp.filer_code or None, dp.jurisdiction_code or None, dp.entity_code or None, dp.context_key or None, x_act_adj_amt_lc))
                if not sib:
                    continue
                amt = _dp_decimal(sib)
                if amt is None:
                    continue

                if not _calc_equal(target, amt):
                    _oecd_issue(
                        number=70084 if code == "GIR2719" else 70085,
                        severity="WARNING",
                        xml_path=xp_act_adj_amt,
                        filer_code=etr[0],
                        jurisdiction_code=etr[1],
                        context_key=dp.context_key,
                        message=(
                            f"AdjustedCoveredTax/Adjustments Amount={amt} for AdjustmentItem {code} but expected approximately {_round4(target)} "
                            f"(must match ExcessNegTaxExpense/{'GeneratedInRFY' if code=='GIR2719' else 'UtilizedInRFY'})."
                        ),
                    )

        # -----------------------------
        # 70086: ExcessProfits = max(NetGlobeIncome/Total - SubstanceExclusion/Total, 0)
        # 70087: SubstanceExclusion/Total = PayrollCost * PayrollMarkUp + TangibleAssetValue * TangibleAssetMarkup
        # -----------------------------
        if x_ng_total_lc:
            oc: Dict[Tuple[Optional[str], Optional[str], str], dict] = {}
            for dp in submission_dps:
                if not dp.jurisdiction_code:
                    continue
                xp = _dp_xpath_lc(dp)
                if xp not in {
                    x_ng_total_lc,
                    x_se_total_lc,
                    x_excess_profits_lc,
                    x_se_payroll_cost_lc,
                    x_se_payroll_mu_lc,
                    x_se_tav_lc,
                    x_se_tav_mu_lc,
                }:
                    continue
                v = _dp_decimal(dp)
                if v is None:
                    continue
                etr = (dp.filer_code or None, dp.jurisdiction_code or None, _scope_key(dp.context_key, "ETR"))
                d = oc.setdefault(etr, {})
                if xp == x_ng_total_lc:
                    d["ng"] = v
                elif xp == x_se_total_lc:
                    d["se_total"] = v
                elif xp == x_excess_profits_lc:
                    d["excess"] = v
                elif xp == x_se_payroll_cost_lc:
                    d["pc"] = v
                elif xp == x_se_payroll_mu_lc:
                    d["pmu"] = v
                elif xp == x_se_tav_lc:
                    d["tav"] = v
                elif xp == x_se_tav_mu_lc:
                    d["tmu"] = v

            # 70087
            for etr, d in oc.items():
                if {"se_total", "pc", "pmu", "tav", "tmu"} <= set(d.keys()):
                    expected = (d["pc"] * d["pmu"]) + (d["tav"] * d["tmu"])
                    if not _calc_equal(expected, d["se_total"]):
                        _oecd_issue(
                            number=70087,
                            severity="WARNING",
                            xml_path=xp_se_total,
                            filer_code=etr[0],
                            jurisdiction_code=etr[1],
                            context_key=etr[2],
                            message=f"SubstanceExclusion/Total={d['se_total']} but expected approximately {_round4(expected)} (PayrollCost*PayrollMarkUp + TangibleAssetValue*TangibleAssetMarkup).",
                        )

            # 70086
            for etr, d in oc.items():
                if "excess" not in d or "ng" not in d:
                    continue
                se_total = d.get("se_total", Decimal("0"))
                expected = d["ng"] - se_total
                if expected < 0:
                    expected = Decimal("0")
                if not _calc_equal(expected, d["excess"]):
                    _oecd_issue(
                        number=70086,
                        severity="WARNING",
                        xml_path=xp_excess_profits,
                        filer_code=etr[0],
                        jurisdiction_code=etr[1],
                        context_key=etr[2],
                        message=f"ExcessProfits={d['excess']} but expected approximately {_round4(expected)} (max(NetGlobeIncome/Total - SubstanceExclusion/Total, 0); missing SubstanceExclusion treated as 0).",
                    )

        # -----------------------------
        # 70088–70092: AdditionalTopUpTax/Art4.1.5
        # -----------------------------
        if x_ng_total_lc and art415_container_lc:
            art: Dict[Tuple[Optional[str], Optional[str], str], dict] = {}
            art_present: Set[Tuple[Optional[str], Optional[str], str]] = set()

            for dp in submission_dps:
                if not dp.jurisdiction_code:
                    continue
                xp = _dp_xpath_lc(dp)
                etr = (dp.filer_code or None, dp.jurisdiction_code or None, _scope_key(dp.context_key, "ETR"))

                if art415_container_lc and xp.startswith(art415_container_lc) and (dp.value_raw or "").strip() != "":
                    art_present.add(etr)

                if xp not in {x_ng_total_lc, x_art_adjct_lc, x_art_gl_lc, x_art_exp_lc, x_art_add_lc}:
                    continue
                v = _dp_decimal(dp)
                if v is None:
                    continue
                d = art.setdefault(etr, {})
                if xp == x_ng_total_lc:
                    d["ng"] = v
                elif xp == x_art_adjct_lc:
                    d["adjct"] = v
                elif xp == x_art_gl_lc:
                    d["gl"] = v
                elif xp == x_art_exp_lc:
                    d["exp"] = v
                elif xp == x_art_add_lc:
                    d["add"] = v

            # 70088: If NetGlobeIncome/Total is negative, Art4.1.5 must be completed
            for etr, d in art.items():
                ng = d.get("ng")
                if ng is None:
                    continue
                if ng < 0 and etr not in art_present:
                    _oecd_issue(
                        number=70088,
                        severity="BLOCKING",
                        xml_path=xp_art415,
                        filer_code=etr[0],
                        jurisdiction_code=etr[1],
                        context_key=etr[2],
                        message=(
                            "NetGlobeIncome/Total is negative, so AdditionalTopUpTax/Art4.1.5 must be completed, but no Art4.1.5 values were provided."
                        ),
                    )

            # 70089: AdjustedCoveredTax should be negative
            for etr, d in art.items():
                if "adjct" in d and d["adjct"] >= 0:
                    _oecd_issue(
                        number=70089,
                        severity="WARNING",
                        xml_path=xp_art_adjct,
                        filer_code=etr[0],
                        jurisdiction_code=etr[1],
                        context_key=etr[2],
                        message=f"Art4.1.5/AdjustedCoveredTax should be negative, but value is {d['adjct']}.",
                    )

            # 70090: GlobeLoss == NetGlobeIncome/Total
            for etr, d in art.items():
                if "gl" in d and "ng" in d:
                    if not _calc_equal(d["ng"], d["gl"]):
                        _oecd_issue(
                            number=70090,
                            severity="WARNING",
                            xml_path=xp_art_gl,
                            filer_code=etr[0],
                            jurisdiction_code=etr[1],
                            context_key=etr[2],
                            message=f"Art4.1.5/GlobeLoss={d['gl']} but expected approximately {_round4(d['ng'])} (must match NetGlobeIncome/Total).",
                        )

            # 70091: ExpectedAdjustedCoveredTax = GlobeLoss * 15%
            for etr, d in art.items():
                if {"gl", "exp"} <= set(d.keys()):
                    expected = d["gl"] * Decimal("0.15")
                    if not _calc_equal(expected, d["exp"]):
                        _oecd_issue(
                            number=70091,
                            severity="WARNING",
                            xml_path=xp_art_exp,
                            filer_code=etr[0],
                            jurisdiction_code=etr[1],
                            context_key=etr[2],
                            message=f"ExpectedAdjustedCoveredTax={d['exp']} but expected approximately {_round4(expected)} (GlobeLoss * 15%).",
                        )

            # 70092: AdditionalTopUpTax = max(ExpectedAdjustedCoveredTax - AdjustedCoveredTax, 0)
            for etr, d in art.items():
                if {"add", "exp", "adjct"} <= set(d.keys()):
                    expected = d["exp"] - d["adjct"]
                    if expected < 0:
                        expected = Decimal("0")
                    if not _calc_equal(expected, d["add"]):
                        _oecd_issue(
                            number=70092,
                            severity="WARNING",
                            xml_path=xp_art_add,
                            filer_code=etr[0],
                            jurisdiction_code=etr[1],
                            context_key=etr[2],
                            message=f"Art4.1.5/AdditionalTopUpTax={d['add']} but expected approximately {_round4(expected)} (max(ExpectedAdjustedCoveredTax - AdjustedCoveredTax, 0)).",
                        )

        # -----------------------------
        # 70093–70096: AdditionalTopUpTax/NONArt4.1.5
        # -----------------------------
        if x_non_year_lc and pe_year is not None:
            nonart: Dict[Tuple[Optional[str], Optional[str], str], dict] = {}
            for dp in submission_dps:
                if not dp.jurisdiction_code:
                    continue
                xp = _dp_xpath_lc(dp)
                if xp not in {x_non_year_lc, x_non_articles_lc, x_non_add_lc, x_non_prev_tut_lc, x_non_recalc_tut_lc}:
                    continue
                etr_scope = _scope_key(dp.context_key, "ETR")
                # Keep NONArt blocks separate when repeated by year
                row_scope = _scope_key(dp.context_key, "NONArt4.1.5")
                if not row_scope or row_scope == etr_scope:
                    row_scope = dp.context_key or etr_scope
                key = (dp.filer_code or None, dp.jurisdiction_code or None, row_scope)
                d = nonart.setdefault(key, {"etr_scope": etr_scope})

                if xp == x_non_year_lc:
                    d["year"] = _parse_year_int(dp.value_raw)
                elif xp == x_non_articles_lc:
                    # Articles can repeat
                    d.setdefault("articles", set()).add((dp.value_raw or "").strip())
                elif xp == x_non_add_lc:
                    v = _dp_decimal(dp)
                    if v is not None:
                        d["add"] = v
                elif xp == x_non_prev_tut_lc:
                    v = _dp_decimal(dp)
                    if v is not None:
                        d["prev"] = v
                elif xp == x_non_recalc_tut_lc:
                    v = _dp_decimal(dp)
                    if v is not None:
                        d["recalc"] = v

            for key, d in nonart.items():
                filer_code, juris, row_scope = key
                year = d.get("year")
                if year is None:
                    continue

                # 70093: Year <= Period End Year
                if year > pe_year:
                    _oecd_issue(
                        number=70093,
                        severity="BLOCKING",
                        xml_path=xp_non_year,
                        filer_code=filer_code,
                        jurisdiction_code=juris,
                        context_key=row_scope,
                        message=f"NONArt4.1.5/Year={year} must not be greater than the Period End year ({pe_year}).",
                    )

                arts = {a for a in (d.get("articles") or set()) if a}
                # 70094: GIR2605 -> Year <= PeriodEndYear - 4
                if "GIR2605" in arts and year > (pe_year - 4):
                    _oecd_issue(
                        number=70094,
                        severity="WARNING",
                        xml_path=xp_non_year,
                        filer_code=filer_code,
                        jurisdiction_code=juris,
                        context_key=row_scope,
                        message=f"Articles includes GIR2605, so Year should be at least 4 years before Period End year ({pe_year}); got {year}.",
                    )

                # 70095: GIR2602 -> Year == PeriodEndYear - 5
                if "GIR2602" in arts and year != (pe_year - 5):
                    _oecd_issue(
                        number=70095,
                        severity="WARNING",
                        xml_path=xp_non_year,
                        filer_code=filer_code,
                        jurisdiction_code=juris,
                        context_key=row_scope,
                        message=f"Articles includes GIR2602, so Year should be the fifth fiscal year preceding Period End year ({pe_year}); expected {pe_year - 5} but got {year}.",
                    )

                # 70096: AdditionalTopUpTax = Recalculated/TopUpTax - Previous/TopUpTax
                if {"add", "recalc", "prev"} <= set(d.keys()):
                    expected = d["recalc"] - d["prev"]
                    if not _calc_equal(expected, d["add"]):
                        _oecd_issue(
                            number=70096,
                            severity="WARNING",
                            xml_path=xp_non_add,
                            filer_code=filer_code,
                            jurisdiction_code=juris,
                            context_key=row_scope,
                            message=f"NONArt4.1.5/AdditionalTopUpTax={d['add']} but expected approximately {_round4(expected)} (Recalculated/TopUpTax - Previous/TopUpTax).",
                        )

        # -----------------------------
        # 70097–70098: LTCE IIR ParentEntity calculations
        # -----------------------------
        if x_ltce_net_lc and x_ltce_ratio_lc:
            ltce_vals: Dict[Tuple[Optional[str], Optional[str], str], dict] = {}
            parent_vals: Dict[Tuple[Optional[str], Optional[str], str], dict] = {}

            for dp in submission_dps:
                if not dp.jurisdiction_code:
                    continue
                xp = _dp_xpath_lc(dp)

                if xp in {x_ltce_net_lc, x_ltce_topuptax_lc}:
                    v = _dp_decimal(dp)
                    if v is None:
                        continue
                    scope = _scope_key(dp.context_key, "LTCE")
                    key = (dp.filer_code or None, dp.jurisdiction_code or None, scope)
                    d = ltce_vals.setdefault(key, {})
                    if xp == x_ltce_net_lc:
                        d["net"] = v
                    else:
                        d["topup"] = v

                if xp in {x_ltce_other_lc, x_ltce_ratio_lc, x_ltce_share_lc}:
                    v = _dp_decimal(dp)
                    if v is None:
                        continue
                    parent_scope = _scope_key(dp.context_key, "ParentEntity")
                    if not parent_scope:
                        parent_scope = dp.context_key or ""
                    key = (dp.filer_code or None, dp.jurisdiction_code or None, parent_scope)
                    d = parent_vals.setdefault(key, {"ltce_scope": _scope_key(dp.context_key, "LTCE")})
                    if xp == x_ltce_other_lc:
                        d["other"] = v
                    elif xp == x_ltce_ratio_lc:
                        d["ratio"] = v
                    else:
                        d["share"] = v

            # 70097: InclusionRatio = (Net - Other) / Net
            for pkey, d in parent_vals.items():
                filer_code, juris, parent_scope = pkey
                ltce_scope = d.get("ltce_scope") or ""
                net = ltce_vals.get((filer_code, juris, ltce_scope), {}).get("net")
                if net is None or net == 0:
                    continue
                other = d.get("other", Decimal("0"))
                if "ratio" in d:
                    expected = (net - other) / net
                    if not _calc_equal(expected, d["ratio"]):
                        _oecd_issue(
                            number=70097,
                            severity="WARNING",
                            xml_path=xp_ltce_ratio,
                            filer_code=filer_code,
                            jurisdiction_code=juris,
                            context_key=parent_scope,
                            message=f"LTCE/IIR/ParentEntity/InclusionRatio={d['ratio']} but expected approximately {_round4(expected)} ((NetGlobeIncome - OtherOwnershipAllocation) / NetGlobeIncome).",
                        )

            # 70098: TopUpTaxShare = TopUpTax * InclusionRatio
            for pkey, d in parent_vals.items():
                filer_code, juris, parent_scope = pkey
                ltce_scope = d.get("ltce_scope") or ""
                topup = ltce_vals.get((filer_code, juris, ltce_scope), {}).get("topup")
                if topup is None:
                    continue
                if "ratio" in d and "share" in d:
                    expected = topup * d["ratio"]
                    if not _calc_equal(expected, d["share"]):
                        _oecd_issue(
                            number=70098,
                            severity="WARNING",
                            xml_path=xp_ltce_share,
                            filer_code=filer_code,
                            jurisdiction_code=juris,
                            context_key=parent_scope,
                            message=f"LTCE/IIR/ParentEntity/TopUpTaxShare={d['share']} but expected approximately {_round4(expected)} (TopUpTax * InclusionRatio).",
                        )

        # -----------------------------
        # 70099: Sum(UTPRTopUpTaxAttributed) == Sum(TotalUTPRTopUpTax) across jurisdictions
        # 70100: If any UTPRCalculation TotalUTPRTopUpTax > 0, UTPRAttribution must be completed
        # -----------------------------
        if x_utpr_total_lc and x_utpr_attr_lc:
            sum_total_by_filer: Dict[Optional[str], Decimal] = {}
            sum_attr_by_filer: Dict[Optional[str], Decimal] = {}

            any_utpr_positive = False

            for dp in submission_dps:
                xp = _dp_xpath_lc(dp)
                if xp == x_utpr_total_lc:
                    v = _dp_decimal(dp)
                    if v is None:
                        continue
                    fk = dp.filer_code or None
                    sum_total_by_filer[fk] = sum_total_by_filer.get(fk, Decimal("0")) + v
                    if v > 0:
                        any_utpr_positive = True

                if xp == x_utpr_attr_lc:
                    v = _dp_decimal(dp)
                    if v is None:
                        continue
                    fk = dp.filer_code or None
                    sum_attr_by_filer[fk] = sum_attr_by_filer.get(fk, Decimal("0")) + v

            # 70099 checks per filer key
            for fk, tot in sum_total_by_filer.items():
                attr = sum_attr_by_filer.get(fk, Decimal("0"))
                if not _calc_equal(tot, attr):
                    _oecd_issue(
                        number=70099,
                        severity="WARNING",
                        xml_path=xp_utpr_attr,
                        filer_code=fk,
                        message=f"Sum(UTPRTopUpTaxAttributed)={attr} but expected approximately {_round4(tot)} (sum of JurisdictionSection UTPRCalculation/TotalUTPRTopUpTax across all jurisdictions).",
                    )

            # 70100
            if any_utpr_positive and not has_any_utpr_attr:
                _oecd_issue(
                    number=70100,
                    severity="BLOCKING",
                    xml_path="/GLOBE_OECD/GLOBEBody/UTPRAttribution",
                    message="A UTPR Top-up Tax has been reported (TotalUTPRTopUpTax > 0) but UTPRAttribution is not completed. Please complete the UTPRAttribution element.",
                )

        # -----------------------------
        # 70101–70103: UTPR attribution requiredness + percentage gating
        # -----------------------------
        if x_utpr_carry_lc and x_utpr_pct_lc:
            rows: Dict[Tuple[Optional[str], str], dict] = {}
            for dp in submission_dps:
                xp = _dp_xpath_lc(dp)
                if xp not in {x_utpr_carry_lc, x_utpr_emp_lc, x_utpr_tav_lc, x_utpr_pct_lc}:
                    continue
                # Group per attribution record
                row_scope = _scope_key(dp.context_key, "Attribution")
                if not row_scope:
                    row_scope = dp.context_key or ""
                key = (dp.filer_code or None, row_scope)
                d = rows.setdefault(key, {"juris": dp.jurisdiction_code})
                if xp == x_utpr_carry_lc:
                    v = _dp_decimal(dp)
                    if v is not None:
                        d["carry"] = v
                elif xp == x_utpr_emp_lc:
                    d["emp_present"] = (dp.value_raw or "").strip() != ""
                elif xp == x_utpr_tav_lc:
                    d["tav_present"] = (dp.value_raw or "").strip() != ""
                elif xp == x_utpr_pct_lc:
                    v = _parse_percent(dp.value_raw)
                    if v is not None:
                        d["pct"] = v

            # 70101 / 70102
            for (fk, row_scope), d in rows.items():
                carry = d.get("carry")
                if carry is None:
                    continue
                juris = d.get("juris")
                if carry != 0:
                    if not d.get("emp_present"):
                        _oecd_issue(
                            number=70101,
                            severity="BLOCKING",
                            xml_path=xp_utpr_emp,
                            filer_code=fk,
                            jurisdiction_code=juris,
                            context_key=row_scope,
                            message="Employees must be completed unless UTPRTopUpTaxCarryForward is 0.",
                        )
                    if not d.get("tav_present"):
                        _oecd_issue(
                            number=70102,
                            severity="BLOCKING",
                            xml_path=xp_utpr_tav,
                            filer_code=fk,
                            jurisdiction_code=juris,
                            context_key=row_scope,
                            message="TangibleAssetValue must be completed unless UTPRTopUpTaxCarryForward is 0.",
                        )

            # 70103
            # Rule A: if carryForward > 0, pct must be 0
            for (fk, row_scope), d in rows.items():
                carry = d.get("carry")
                pct = d.get("pct")
                if carry is None or pct is None:
                    continue
                juris = d.get("juris")
                if carry > 0 and pct != 0:
                    _oecd_issue(
                        number=70103,
                        severity="BLOCKING",
                        xml_path=xp_utpr_pct,
                        filer_code=fk,
                        jurisdiction_code=juris,
                        context_key=row_scope,
                        message=f"UTPRPercentage must be 0% when UTPRTopUpTaxCarryForward > 0; got {pct}%.",
                    )

            # Rule B (best-effort): if carryForward == 0, pct can only be 0% when all UTPR jurisdictions have 0%
            # We implement: within each filer, mixing {0, >0} percentages among carry==0 rows is invalid.
            by_filer: Dict[Optional[str], List[Tuple[str, dict]]] = {}
            for (fk, row_scope), d in rows.items():
                by_filer.setdefault(fk, []).append((row_scope, d))

            for fk, items in by_filer.items():
                zero_rows: List[Tuple[str, dict]] = []
                nonzero_exists = False
                for row_scope, d in items:
                    carry = d.get("carry")
                    pct = d.get("pct")
                    if carry is None or pct is None:
                        continue
                    if carry == 0:
                        if pct == 0:
                            zero_rows.append((row_scope, d))
                        else:
                            nonzero_exists = True
                if nonzero_exists and zero_rows:
                    for row_scope, d in zero_rows:
                        _oecd_issue(
                            number=70103,
                            severity="WARNING",
                            xml_path=xp_utpr_pct,
                            filer_code=fk,
                            jurisdiction_code=d.get("juris"),
                            context_key=row_scope,
                            message="UTPRPercentage is 0% while other UTPR jurisdictions report non‑zero UTPRPercentage in the Reporting Fiscal Year (with carry forward = 0).",
                        )

    except Exception:
        # Non-fatal: Stage 10 OECD cross-record validations are best-effort.
        pass

    # -----------------------------
    # Stage 11: OECD other record errors — remaining 70104–70124
    # -----------------------------
    #
    # Focus: UTPR carry-forward arithmetic, UPE Adjustments / owner identification gates,
    # CEComputation-level adjustment uniqueness + arithmetic, and CrossAllocation sign rules.
    try:
        def _oecd_issue(
            *,
            number: int,
            severity: str,
            xml_path: Optional[str],
            message: str,
            filer_code: Optional[str] = None,
            jurisdiction_code: Optional[str] = None,
            entity_code: Optional[str] = None,
            context_key: Optional[str] = None,
        ) -> None:
            num = number if number in error_map else None
            issues.append(Issue(
                severity=severity,
                rule_id=_rid(
                    "OECD",
                    f"{number}|{xml_path}|{filer_code}|{jurisdiction_code}|{entity_code}|{context_key}|{message}",
                ),
                section="Jurisdiction",
                xml_path=xml_path,
                filer_code=filer_code,
                jurisdiction_code=jurisdiction_code,
                entity_code=entity_code,
                context_key=context_key,
                error_number=num,
                message=message,
                how_to_fix=_oecd_fix_text(error_map, num) if num else None,
            ))

        def _ctx_root(ctx: Optional[str]) -> str:
            return (str(ctx).split("|", 1)[0]) if ctx else ""

        def _scope_key(ctx: Optional[str], tag: str) -> str:
            """Return a stable scope key for a repeatable record block."""
            if not ctx:
                return ""
            parts = str(ctx).split("|")
            for i, p in enumerate(parts):
                if p.startswith(f"DOCREF:{tag}:") or p.startswith(f"IDX:{tag}:"):
                    return "|".join(parts[: i + 1])
            return parts[0]

        def _amount_parent_scope(ctx: Optional[str]) -> str:
            """Group repeating leaf Amount values by stripping the trailing IDX/DOCREF Amount token."""
            if not ctx:
                return ""
            parts = str(ctx).split("|")
            if parts and (parts[-1].startswith("IDX:Amount:") or parts[-1].startswith("DOCREF:Amount:")):
                return "|".join(parts[:-1])
            return str(ctx)

        # --- XPaths (best-effort; may be absent depending on config version) ---
        # 70104/70105: UTPR carry-forward arithmetic
        xp_utpr_carry_fwd = _find_xpath(config, endswith="/UTPRAttribution/Attribution/UTPRTopUpTaxCarryForward")
        xp_utpr_attr = _find_xpath(config, endswith="/UTPRAttribution/Attribution/UTPRTopUpTaxAttributed")
        xp_utpr_addcash = _find_xpath(config, endswith="/UTPRAttribution/Attribution/AddCashTaxExpense")
        xp_utpr_carried = _find_xpath(config, endswith="/UTPRAttribution/Attribution/UTPRTopUpTaxCarriedForward")

        x_utpr_carry_fwd_lc = _norm_xpath(xp_utpr_carry_fwd).lower() if xp_utpr_carry_fwd else ""
        x_utpr_attr_lc = _norm_xpath(xp_utpr_attr).lower() if xp_utpr_attr else ""
        x_utpr_addcash_lc = _norm_xpath(xp_utpr_addcash).lower() if xp_utpr_addcash else ""
        x_utpr_carried_lc = _norm_xpath(xp_utpr_carried).lower() if xp_utpr_carried else ""

        if x_utpr_carried_lc:
            rows: Dict[Tuple[Optional[str], str], dict] = {}
            relevant = {x_utpr_carry_fwd_lc, x_utpr_attr_lc, x_utpr_addcash_lc, x_utpr_carried_lc}
            for dp in submission_dps:
                xp = _dp_xpath_lc(dp)
                if xp not in relevant:
                    continue
                row_scope = _scope_key(dp.context_key, "Attribution") or (dp.context_key or "")
                key = (dp.filer_code or None, row_scope)
                d = rows.setdefault(key, {"juris": dp.jurisdiction_code})
                v = _dp_decimal(dp)
                if v is None:
                    continue
                if xp == x_utpr_carry_fwd_lc:
                    d["carry_fwd"] = v
                elif xp == x_utpr_attr_lc:
                    d["attr"] = v
                elif xp == x_utpr_addcash_lc:
                    d["addcash"] = v
                elif xp == x_utpr_carried_lc:
                    d["carried"] = v

            for (fk, row_scope), d in rows.items():
                carried = d.get("carried")
                if carried is None:
                    continue

                juris = d.get("juris")

                # 70104: CarriedForward must not be negative
                if carried < 0:
                    _oecd_issue(
                        number=70104,
                        severity="BLOCKING",
                        xml_path=xp_utpr_carried,
                        filer_code=fk,
                        jurisdiction_code=juris,
                        context_key=row_scope,
                        message="UTPRTopUpTaxCarriedForward cannot be negative.",
                    )

                # 70105: CarriedForward = CarryForward + Attributed - AddCashTaxExpense
                carry_fwd = d.get("carry_fwd")
                attr = d.get("attr")
                if carry_fwd is None or attr is None:
                    continue
                addcash = d.get("addcash", Decimal("0"))
                expected = carry_fwd + attr - addcash
                if not _calc_equal(expected, carried):
                    _oecd_issue(
                        number=70105,
                        severity="WARNING",
                        xml_path=xp_utpr_carried,
                        filer_code=fk,
                        jurisdiction_code=juris,
                        context_key=row_scope,
                        message=(
                            f"UTPRTopUpTaxCarriedForward={carried} but expected approximately {_round4(expected)} "
                            f"(UTPRTopUpTaxCarryForward={carry_fwd} + UTPRTopUpTaxAttributed={attr} - AddCashTaxExpense={addcash})."
                        ),
                    )

        # 70106–70113: CEComputation owner identification / cross-border gates
        xp_ce_tin = _find_xpath(config, endswith="/ETRStatus/ETRComputation/CEComputation/TIN")
        x_ce_tin_lc = _norm_xpath(xp_ce_tin).lower() if xp_ce_tin else ""

        xp_other_tin = _find_xpath(config, endswith="/CrossBorderAdjustments/OtherTIN", contains="/CEComputation/AdjustedFANIL/")
        if not xp_other_tin:
            xp_other_tin = _find_xpath(config, endswith="/CrossBorderAdjustments/OtherTIN")
        x_other_tin_lc = _norm_xpath(xp_other_tin).lower() if xp_other_tin else ""

        xp_upe_exception = _find_xpath(config, endswith="/UPEAdjustments/Reductions/Exception", contains="/CEComputation/AdjustedFANIL/")
        x_upe_exception_lc = _norm_xpath(xp_upe_exception).lower() if xp_upe_exception else ""

        xp_upe_basis = _find_xpath(config, endswith="/UPEAdjustments/Basis", contains="/CEComputation/AdjustedFANIL/")
        x_upe_basis_lc = _norm_xpath(xp_upe_basis).lower() if xp_upe_basis else ""

        xp_taxrate_ent = _find_xpath(config, endswith="/IdentificationOfOwners/EntityOwner/TaxRate", contains="/UPEAdjustments/IdentificationOfOwners/")
        xp_taxrate_ind = _find_xpath(config, endswith="/IdentificationOfOwners/IndOwners/TaxRate", contains="/UPEAdjustments/IdentificationOfOwners/")
        xp_res_ind = _find_xpath(config, endswith="/IdentificationOfOwners/IndOwners/ResCountryCode", contains="/UPEAdjustments/IdentificationOfOwners/")
        xp_extype = _find_xpath(config, endswith="/IdentificationOfOwners/EntityOwner/ExTypeOfEntity", contains="/UPEAdjustments/IdentificationOfOwners/")

        x_taxrate_ent_lc = _norm_xpath(xp_taxrate_ent).lower() if xp_taxrate_ent else ""
        x_taxrate_ind_lc = _norm_xpath(xp_taxrate_ind).lower() if xp_taxrate_ind else ""
        x_res_ind_lc = _norm_xpath(xp_res_ind).lower() if xp_res_ind else ""
        x_extype_lc = _norm_xpath(xp_extype).lower() if xp_extype else ""

        # CEComputation NetGlobeIncome adjustments (70114–70117)
        xp_ce_ng_adj_item = _find_xpath(config, endswith="/CEComputation/NetGlobeIncome/Adjustments/AdjustmentItem")
        xp_ce_ng_adj_amt = _find_xpath(config, endswith="/CEComputation/NetGlobeIncome/Adjustments/Amount")
        xp_ce_ng_intship = _find_xpath(config, endswith="/CEComputation/NetGlobeIncome/IntShippingIncome")
        x_ce_ng_adj_item_lc = _norm_xpath(xp_ce_ng_adj_item).lower() if xp_ce_ng_adj_item else ""
        x_ce_ng_adj_amt_lc = _norm_xpath(xp_ce_ng_adj_amt).lower() if xp_ce_ng_adj_amt else ""
        x_ce_ng_intship_lc = _norm_xpath(xp_ce_ng_intship).lower() if xp_ce_ng_intship else ""

        xp_art76_status = _find_xpath(config, endswith="/CEComputation/Elections/Art7.6/Status")
        x_art76_any_lc = "/cecomputation/elections/art7.6/"

        # CEComputation AdjustedCoveredTax adjustments (70118–70122)
        xp_ce_act_adj_item = _find_xpath(config, endswith="/CEComputation/AdjustedCoveredTax/Adjustments/AdjustmentItem")
        xp_ce_act_adj_amt = _find_xpath(config, endswith="/CEComputation/AdjustedCoveredTax/Adjustments/Amount")
        x_ce_act_adj_item_lc = _norm_xpath(xp_ce_act_adj_item).lower() if xp_ce_act_adj_item else ""
        x_ce_act_adj_amt_lc = _norm_xpath(xp_ce_act_adj_amt).lower() if xp_ce_act_adj_amt else ""

        # CEComputation DeferTaxAdjustAmt arithmetic (70120–70122)
        xp_ce_dta_total = _find_xpath(config, contains="/CEComputation/AdjustedCoveredTax/DeferTaxAdjustAmt/", endswith="/Total")
        xp_ce_dta_def = _find_xpath(config, contains="/CEComputation/AdjustedCoveredTax/DeferTaxAdjustAmt/", endswith="/DeferTaxExpense")
        xp_ce_dta_adj_amt = _find_xpath(config, contains="/CEComputation/AdjustedCoveredTax/DeferTaxAdjustAmt/", endswith="/Adjustment/Amount")
        xp_ce_dta_adj_item = _find_xpath(config, contains="/CEComputation/AdjustedCoveredTax/DeferTaxAdjustAmt/", endswith="/Adjustment/AdjustmentItem")
        xp_ce_dta_high = _find_xpath(config, contains="/CEComputation/AdjustedCoveredTax/DeferTaxAdjustAmt/", endswith="/Recast/Higher")
        xp_ce_dta_low = _find_xpath(config, contains="/CEComputation/AdjustedCoveredTax/DeferTaxAdjustAmt/", endswith="/Recast/Lower")

        x_ce_dta_total_lc = _norm_xpath(xp_ce_dta_total).lower() if xp_ce_dta_total else ""
        x_ce_dta_def_lc = _norm_xpath(xp_ce_dta_def).lower() if xp_ce_dta_def else ""
        x_ce_dta_adj_amt_lc = _norm_xpath(xp_ce_dta_adj_amt).lower() if xp_ce_dta_adj_amt else ""
        x_ce_dta_adj_item_lc = _norm_xpath(xp_ce_dta_adj_item).lower() if xp_ce_dta_adj_item else ""
        x_ce_dta_high_lc = _norm_xpath(xp_ce_dta_high).lower() if xp_ce_dta_high else ""
        x_ce_dta_low_lc = _norm_xpath(xp_ce_dta_low).lower() if xp_ce_dta_low else ""

        # AdjustedIncomeTax CrossAllocation sign constraints (70123–70124)
        xp_ca_add = _find_xpath(config, contains="/CEComputation/AdjustedIncomeTax/CrossAllocation", endswith="/Additions")
        xp_ca_red = _find_xpath(config, contains="/CEComputation/AdjustedIncomeTax/CrossAllocation", endswith="/Reductions")
        x_ca_add_lc = _norm_xpath(xp_ca_add).lower() if xp_ca_add else ""
        x_ca_red_lc = _norm_xpath(xp_ca_red).lower() if xp_ca_red else ""

        # --- Collect per-CEComputation row facts ---
        ce_rows: Dict[str, dict] = {}
        def _ce_row(dp: models.DataPoint) -> dict:
            root = _ctx_root(dp.context_key)
            r = ce_rows.setdefault(root, {
                "filer": dp.filer_code or None,
                "jur": dp.jurisdiction_code or None,
                "ent": dp.entity_code or None,
                "ctx": root or (dp.context_key or None),
                "ce_tin": None,
                "other_tins": [],
                "exception": None,
                "crossborder_present": False,
                "upe_basis": None,
                "upe_any": False,
                "taxrate_ent": False,
                "taxrate_ind": False,
                "res_ind": False,
                "ind_any": False,
                "extypes": [],
                "ng_adj_codes": [],
                "ng_intship": False,
                "art76_any": False,
                "ng_amt_groups": {},
                "act_adj_codes": [],
                "act_amt_groups": {},
                "dta_adj_codes": [],
                "dta_amt_groups": {},
                "dta_total": None,
                "dta_def": None,
                "dta_high": Decimal("0"),
                "dta_low": Decimal("0"),
                "dta_adj_amts": [],
            })
            return r

        for dp in submission_dps:
            xp = _dp_xpath_lc(dp)
            # Limit to jurisdiction/entity scoped datapoints where possible
            if "/cecomputation/" not in xp and xp not in {x_utpr_carry_fwd_lc, x_utpr_attr_lc, x_utpr_addcash_lc, x_utpr_carried_lc}:
                continue

            if "/cecomputation/" in xp:
                r = _ce_row(dp)

                # 70106/70107 cross-border
                if x_ce_tin_lc and xp == x_ce_tin_lc:
                    r["ce_tin"] = (dp.value_raw or "").strip()
                if x_other_tin_lc and xp == x_other_tin_lc:
                    r["other_tins"].append((dp.context_key or "", (dp.value_raw or "").strip()))
                if x_upe_exception_lc and xp == x_upe_exception_lc:
                    r["exception"] = _parse_bool(dp.value_raw)
                if "/crossborderadjustments/" in xp and "/adjustedfanil/" in xp:
                    # Any datapoint inside CrossBorderAdjustments counts as presence
                    r["crossborder_present"] = True

                # UPE adjustments owner identification
                if "/upeadjustments/" in xp and "/adjustedfanil/adjustment/" in xp:
                    r["upe_any"] = True
                if x_upe_basis_lc and xp == x_upe_basis_lc:
                    r["upe_basis"] = (dp.value_raw or "").strip().upper()
                if x_taxrate_ent_lc and xp == x_taxrate_ent_lc and (dp.value_raw or "").strip() != "":
                    r["taxrate_ent"] = True
                if x_taxrate_ind_lc and xp == x_taxrate_ind_lc and (dp.value_raw or "").strip() != "":
                    r["taxrate_ind"] = True
                    r["ind_any"] = True
                if x_res_ind_lc and xp == x_res_ind_lc and (dp.value_raw or "").strip() != "":
                    r["res_ind"] = True
                    r["ind_any"] = True
                if "/identificationofowners/indowners/" in xp and "/upeadjustments/" in xp and (dp.value_raw or "").strip() != "":
                    r["ind_any"] = True
                if x_extype_lc and xp == x_extype_lc:
                    val = (dp.value_raw or "").strip().upper()
                    if val:
                        r["extypes"].append(val)

                # NetGlobeIncome adjustments codes
                if x_ce_ng_adj_item_lc and xp == x_ce_ng_adj_item_lc:
                    code = (dp.value_raw or "").strip().upper()
                    if code:
                        r["ng_adj_codes"].append(code)
                if x_ce_ng_intship_lc and xp == x_ce_ng_intship_lc and (dp.value_raw or "").strip() != "":
                    r["ng_intship"] = True
                if x_art76_any_lc in xp:
                    r["art76_any"] = True

                # 70114: NetGlobeIncome Adjustments Amount sign rule (two values)
                if x_ce_ng_adj_amt_lc and xp == x_ce_ng_adj_amt_lc:
                    v = _dp_decimal(dp)
                    if v is not None:
                        p = _amount_parent_scope(dp.context_key)
                        r["ng_amt_groups"].setdefault(p, []).append(v)

                # AdjustedCoveredTax adjustments (70118/70119)
                if x_ce_act_adj_item_lc and xp == x_ce_act_adj_item_lc:
                    code = (dp.value_raw or "").strip().upper()
                    if code:
                        r["act_adj_codes"].append(code)
                if x_ce_act_adj_amt_lc and xp == x_ce_act_adj_amt_lc:
                    v = _dp_decimal(dp)
                    if v is not None:
                        p = _amount_parent_scope(dp.context_key)
                        r["act_amt_groups"].setdefault(p, []).append(v)

                # DeferTaxAdjustAmt (70120–70122)
                if x_ce_dta_adj_item_lc and xp == x_ce_dta_adj_item_lc:
                    code = (dp.value_raw or "").strip().upper()
                    if code:
                        r["dta_adj_codes"].append(code)
                if x_ce_dta_adj_amt_lc and xp == x_ce_dta_adj_amt_lc:
                    v = _dp_decimal(dp)
                    if v is not None:
                        r["dta_adj_amts"].append(v)
                        p = _amount_parent_scope(dp.context_key)
                        r["dta_amt_groups"].setdefault(p, []).append(v)
                if x_ce_dta_total_lc and xp == x_ce_dta_total_lc:
                    r["dta_total"] = _dp_decimal(dp)
                if x_ce_dta_def_lc and xp == x_ce_dta_def_lc:
                    r["dta_def"] = _dp_decimal(dp)
                if x_ce_dta_high_lc and xp == x_ce_dta_high_lc:
                    v = _dp_decimal(dp)
                    if v is not None:
                        r["dta_high"] = v
                if x_ce_dta_low_lc and xp == x_ce_dta_low_lc:
                    v = _dp_decimal(dp)
                    if v is not None:
                        r["dta_low"] = v

                # CrossAllocation sign rules
                if x_ca_add_lc and xp == x_ca_add_lc:
                    v = _dp_decimal(dp)
                    if v is not None and v < 0:
                        _oecd_issue(
                            number=70123,
                            severity="BLOCKING",
                            xml_path=xp_ca_add,
                            filer_code=r.get("filer"),
                            jurisdiction_code=r.get("jur"),
                            entity_code=r.get("ent"),
                            context_key=r.get("ctx"),
                            message="AdjustedIncomeTax/CrossAllocation/Additions must not have a negative value.",
                        )
                if x_ca_red_lc and xp == x_ca_red_lc:
                    v = _dp_decimal(dp)
                    if v is not None and v > 0:
                        _oecd_issue(
                            number=70124,
                            severity="BLOCKING",
                            xml_path=xp_ca_red,
                            filer_code=r.get("filer"),
                            jurisdiction_code=r.get("jur"),
                            entity_code=r.get("ent"),
                            context_key=r.get("ctx"),
                            message="AdjustedIncomeTax/CrossAllocation/Reductions must not have a positive value.",
                        )

        # --- Apply CEComputation-level rules ---
        for r in ce_rows.values():
            filer = r.get("filer")
            jur = r.get("jur")
            ent = r.get("ent")
            ctx = r.get("ctx")

            # 70106: OtherTIN must not equal CEComputation/TIN
            ce_tin = (r.get("ce_tin") or "").strip()
            if ce_tin:
                for (ot_ctx, ot) in r.get("other_tins", []):
                    if ot and ot == ce_tin:
                        _oecd_issue(
                            number=70106,
                            severity="BLOCKING",
                            xml_path=xp_other_tin,
                            filer_code=filer,
                            jurisdiction_code=jur,
                            entity_code=ent,
                            context_key=_ctx_root(ot_ctx) or ctx,
                            message="OtherTIN must not match the CEComputation/TIN, but both are identical.",
                        )

            # 70107: If Exception is TRUE then CrossBorderAdjustments must not be provided
            if r.get("exception") is True and r.get("crossborder_present"):
                _oecd_issue(
                    number=70107,
                    severity="BLOCKING",
                    xml_path=_norm_xpath(xp_other_tin).rsplit("/", 1)[0] if xp_other_tin else "/GLOBE_OECD/GLOBEBody/JurisdictionSection/GLoBETax/ETR/ETRStatus/ETRComputation/CEComputation/AdjustedFANIL/Total/Adjustment/CrossBorderAdjustments",
                    filer_code=filer,
                    jurisdiction_code=jur,
                    entity_code=ent,
                    context_key=ctx,
                    message="CrossBorderAdjustments must not be provided when UPEAdjustments/Reductions/Exception is TRUE.",
                )

            basis = (r.get("upe_basis") or "").strip().upper()

            # 70108: Basis GIR1901/1902/1905/1906 -> TaxRate required (EntityOwner or IndOwners)
            if basis in {"GIR1901", "GIR1902", "GIR1905", "GIR1906"}:
                if not (r.get("taxrate_ent") or r.get("taxrate_ind")):
                    _oecd_issue(
                        number=70108,
                        severity="BLOCKING",
                        xml_path=xp_taxrate_ent or xp_taxrate_ind,
                        filer_code=filer,
                        jurisdiction_code=jur,
                        entity_code=ent,
                        context_key=ctx,
                        message="When Basis is GIR1901, GIR1902, GIR1905 or GIR1906, TaxRate must be completed under EntityOwner or IndOwners.",
                    )

            # 70109: Basis GIR1907 -> IndOwners/ResCountryCode required (choice must be IndOwners)
            if basis == "GIR1907":
                if not r.get("res_ind"):
                    _oecd_issue(
                        number=70109,
                        severity="BLOCKING",
                        xml_path=xp_res_ind,
                        filer_code=filer,
                        jurisdiction_code=jur,
                        entity_code=ent,
                        context_key=ctx,
                        message="When Basis is GIR1907, IndOwners/ResCountryCode must be completed (i.e. IdentificationOfOwners choice must be IndOwners).",
                    )

            # 70110: Basis GIR1903 or GIR1908 -> IndOwners element must be completed
            if basis in {"GIR1903", "GIR1908"}:
                if not r.get("ind_any"):
                    _oecd_issue(
                        number=70110,
                        severity="BLOCKING",
                        xml_path=xp_res_ind or xp_taxrate_ind,
                        filer_code=filer,
                        jurisdiction_code=jur,
                        entity_code=ent,
                        context_key=ctx,
                        message="When Basis is GIR1903 or GIR1908, the IndOwners element must be completed.",
                    )

            # 70111: Basis GIR1904 or GIR1909 -> EntityOwner/ExTypeOfEntity must be completed
            if basis in {"GIR1904", "GIR1909"}:
                if not r.get("extypes"):
                    _oecd_issue(
                        number=70111,
                        severity="BLOCKING",
                        xml_path=xp_extype,
                        filer_code=filer,
                        jurisdiction_code=jur,
                        entity_code=ent,
                        context_key=ctx,
                        message="When Basis is GIR1904 or GIR1909, EntityOwner/ExTypeOfEntity must be completed (i.e. IdentificationOfOwners choice must be EntityOwner).",
                    )

            # 70112: Basis GIR1904 -> ExTypeOfEntity must not contain GIR2805
            if basis == "GIR1904" and "GIR2805" in set(r.get("extypes") or []):
                _oecd_issue(
                    number=70112,
                    severity="BLOCKING",
                    xml_path=xp_extype,
                    filer_code=filer,
                    jurisdiction_code=jur,
                    entity_code=ent,
                    context_key=ctx,
                    message="When Basis is GIR1904, ExTypeOfEntity must not contain the value GIR2805.",
                )

            # 70113: Basis GIR1909 -> ExTypeOfEntity must not contain GIR2804
            if basis == "GIR1909" and "GIR2804" in set(r.get("extypes") or []):
                _oecd_issue(
                    number=70113,
                    severity="BLOCKING",
                    xml_path=xp_extype,
                    filer_code=filer,
                    jurisdiction_code=jur,
                    entity_code=ent,
                    context_key=ctx,
                    message="When Basis is GIR1909, ExTypeOfEntity must not contain the value GIR2804.",
                )

            # 70114: if two values are provided for NetGlobeIncome/Adjustments/Amount, one must be negative and the other positive
            for scope, vals in (r.get("ng_amt_groups") or {}).items():
                if len(vals) == 2:
                    a, b = vals[0], vals[1]
                    if not ((a < 0 and b > 0) or (a > 0 and b < 0)):
                        _oecd_issue(
                            number=70114,
                            severity="BLOCKING",
                            xml_path=xp_ce_ng_adj_amt,
                            filer_code=filer,
                            jurisdiction_code=jur,
                            entity_code=ent,
                            context_key=scope or ctx,
                            message="If two values are provided for NetGlobeIncome/Adjustments/Amount, one value must be negative and the other value positive.",
                        )

            # 70115: GIR2022/GIR2023 selected -> UPEAdjustments must be completed
            if set(r.get("ng_adj_codes") or []) & {"GIR2022", "GIR2023"}:
                if not r.get("upe_any"):
                    _oecd_issue(
                        number=70115,
                        severity="BLOCKING",
                        xml_path=xp_upe_basis,
                        filer_code=filer,
                        jurisdiction_code=jur,
                        entity_code=ent,
                        context_key=ctx,
                        message="NetGlobeIncome/Adjustments contains GIR2022 and/or GIR2023, so AdjustedFANIL/Adjustment/UPEAdjustments must be completed.",
                    )

            # 70116: GIR2025 selected -> IntShippingIncome must be completed
            if "GIR2025" in set(r.get("ng_adj_codes") or []):
                if not r.get("ng_intship"):
                    _oecd_issue(
                        number=70116,
                        severity="BLOCKING",
                        xml_path=xp_ce_ng_intship,
                        filer_code=filer,
                        jurisdiction_code=jur,
                        entity_code=ent,
                        context_key=ctx,
                        message="NetGlobeIncome/Adjustments contains GIR2025, so NetGlobeIncome/IntShippingIncome must be completed for this CEComputation.",
                    )

            # 70117: GIR2024 selected -> Elections/Art7.6 must be completed
            if "GIR2024" in set(r.get("ng_adj_codes") or []):
                if not r.get("art76_any"):
                    _oecd_issue(
                        number=70117,
                        severity="BLOCKING",
                        xml_path=xp_art76_status or "/GLOBE_OECD/GLOBEBody/JurisdictionSection/GLOBETax/ETR/ETRStatus/ETRComputation/CEComputation/Elections/Art7.6",
                        filer_code=filer,
                        jurisdiction_code=jur,
                        entity_code=ent,
                        context_key=ctx,
                        message="NetGlobeIncome/Adjustments contains GIR2024, so the CEComputation Elections/Art7.6 element must be completed.",
                    )

            # 70118: if two values are provided for AdjustedCoveredTax/Adjustments/Amount, one must be negative and the other positive
            for scope, vals in (r.get("act_amt_groups") or {}).items():
                if len(vals) == 2:
                    a, b = vals[0], vals[1]
                    if not ((a < 0 and b > 0) or (a > 0 and b < 0)):
                        _oecd_issue(
                            number=70118,
                            severity="BLOCKING",
                            xml_path=xp_ce_act_adj_amt,
                            filer_code=filer,
                            jurisdiction_code=jur,
                            entity_code=ent,
                            context_key=scope or ctx,
                            message="If two values are provided for AdjustedCoveredTax/Adjustments/Amount, one value must be negative and the other value positive.",
                        )

            # 70119: uniqueness of AdjustedCoveredTax adjustment item codes within a CEComputation
            if r.get("act_adj_codes"):
                counts: Dict[str, int] = {}
                for c in r["act_adj_codes"]:
                    counts[c] = counts.get(c, 0) + 1
                dups = sorted([c for c, n in counts.items() if n > 1])
                if dups:
                    _oecd_issue(
                        number=70119,
                        severity="BLOCKING",
                        xml_path=xp_ce_act_adj_item,
                        filer_code=filer,
                        jurisdiction_code=jur,
                        entity_code=ent,
                        context_key=ctx,
                        message=f"Each code for CEComputation/AdjustedCoveredTax/Adjustments/AdjustmentItem cannot be used more than once. Duplicate code(s): {', '.join(dups)}.",
                    )

            # 70120: DeferTaxAdjustAmt/Total arithmetic (DeferTaxExpense + Sum Adjustments/Amount + Recast/Higher + Recast/Lower)
            if r.get("dta_total") is not None:
                total = r.get("dta_total")
                if total is not None:
                    defexp = r.get("dta_def") or Decimal("0")
                    higher = r.get("dta_high") or Decimal("0")
                    lower = r.get("dta_low") or Decimal("0")
                    expected = defexp + sum(r.get("dta_adj_amts") or [], Decimal("0")) + higher + lower
                    if not _calc_equal(expected, total):
                        _oecd_issue(
                            number=70120,
                            severity="WARNING",
                            xml_path=xp_ce_dta_total,
                            filer_code=filer,
                            jurisdiction_code=jur,
                            entity_code=ent,
                            context_key=ctx,
                            message=(
                                f"DeferTaxAdjustAmt/Total={total} but expected approximately {_round4(expected)} "
                                f"(DeferTaxExpense={defexp} + sum(Adjustment/Amount) + Recast/Higher={higher} + Recast/Lower={lower}; missing treated as 0)."
                            ),
                        )

            # 70121: uniqueness of DeferTaxAdjustAmt/Adjustment/AdjustmentItem codes within a CEComputation
            if r.get("dta_adj_codes"):
                counts: Dict[str, int] = {}
                for c in r["dta_adj_codes"]:
                    counts[c] = counts.get(c, 0) + 1
                dups = sorted([c for c, n in counts.items() if n > 1])
                if dups:
                    _oecd_issue(
                        number=70121,
                        severity="BLOCKING",
                        xml_path=xp_ce_dta_adj_item,
                        filer_code=filer,
                        jurisdiction_code=jur,
                        entity_code=ent,
                        context_key=ctx,
                        message=f"Each code for CEComputation/AdjustedCoveredTax/DeferTaxAdjustAmt/Adjustment/AdjustmentItem cannot be used more than once. Duplicate code(s): {', '.join(dups)}.",
                    )

            # 70122: if two values are provided for DeferTaxAdjustAmt/Adjustment/Amount, one must be negative and the other positive
            for scope, vals in (r.get("dta_amt_groups") or {}).items():
                if len(vals) == 2:
                    a, b = vals[0], vals[1]
                    if not ((a < 0 and b > 0) or (a > 0 and b < 0)):
                        _oecd_issue(
                            number=70122,
                            severity="BLOCKING",
                            xml_path=xp_ce_dta_adj_amt,
                            filer_code=filer,
                            jurisdiction_code=jur,
                            entity_code=ent,
                            context_key=scope or ctx,
                            message="If two values are provided for DeferTaxAdjustAmt/Adjustment/Amount, one value must be negative and the other value positive.",
                        )

    except Exception:
        # Non-fatal: Stage 11 OECD validations are best-effort.
        pass


    return issues
