from datetime import date

import pytest

from app.services.models_v2 import AfterYearEndAdjustmentV2, TPMigrateFromAYERequestV2, TPMigrateFromAYEOptionsV2
from app.services.tp_migration_v2 import migrate_tp_from_aye


def test_tp_migration_combines_income_and_tax_into_single_register_entry():
    payload = TPMigrateFromAYERequestV2(
        after_year_end_adjustments=[
            AfterYearEndAdjustmentV2(
                adjustment_id="TP-1",
                label="TP true-up",
                tested_jurisdiction_id="TJ_SELLER",
                kind="income",
                amount=100.0,
                transaction_year_fy_start=date(2027, 1, 1),
                accrual_year_fy_start=date(2028, 1, 1),
                months_after_transaction_year_end=6,
                is_transfer_pricing_related=True,
                tp_counterparty_tested_jurisdiction_id="TJ_BUYER",
            ),
            AfterYearEndAdjustmentV2(
                adjustment_id="TP-1",
                label="TP true-up",
                tested_jurisdiction_id="TJ_SELLER",
                kind="tax",
                amount=10.0,
                transaction_year_fy_start=date(2027, 1, 1),
                accrual_year_fy_start=date(2028, 1, 1),
                months_after_transaction_year_end=6,
                is_transfer_pricing_related=True,
                tp_counterparty_tested_jurisdiction_id="TJ_BUYER",
            ),
        ],
        tested_jurisdiction_ids=["TJ_SELLER", "TJ_BUYER"],
        options=TPMigrateFromAYEOptionsV2(allow_partial=True, combine_income_and_tax=True),
    )

    resp = migrate_tp_from_aye(payload)

    assert resp.issues == []
    assert len(resp.transfer_pricing_adjustments) == 1
    assert len(resp.remaining_after_year_end_adjustments) == 0

    tp = resp.transfer_pricing_adjustments[0]
    assert tp.seller_tested_jurisdiction_id == "TJ_SELLER"
    assert tp.buyer_tested_jurisdiction_id == "TJ_BUYER"
    assert tp.seller_income_adjustment == pytest.approx(100.0)
    assert tp.seller_tax_adjustment == pytest.approx(10.0)
    # Pure symmetry -> buyer_income_adjustment can be omitted (None)
    assert tp.buyer_income_adjustment is None


def test_tp_migration_special_case_forces_explicit_buyer_income():
    payload = TPMigrateFromAYERequestV2(
        after_year_end_adjustments=[
            AfterYearEndAdjustmentV2(
                adjustment_id="TP-2",
                label="TP intangible",
                tested_jurisdiction_id="TJ_SELLER",
                kind="income",
                amount=50.0,
                transaction_year_fy_start=date(2027, 1, 1),
                accrual_year_fy_start=date(2028, 1, 1),
                months_after_transaction_year_end=6,
                is_transfer_pricing_related=True,
                tp_counterparty_tested_jurisdiction_id="TJ_BUYER",
                tp_intangible_asset_related=True,
            )
        ],
        tested_jurisdiction_ids=["TJ_SELLER", "TJ_BUYER"],
        options=TPMigrateFromAYEOptionsV2(allow_partial=True, combine_income_and_tax=True),
    )

    resp = migrate_tp_from_aye(payload)
    assert resp.issues == []
    assert len(resp.transfer_pricing_adjustments) == 1
    tp = resp.transfer_pricing_adjustments[0]
    # Special-case flag -> buyer income must be explicit
    assert tp.buyer_income_adjustment == pytest.approx(-50.0)


def test_tp_migration_missing_counterparty_produces_error_and_keeps_row():
    payload = TPMigrateFromAYERequestV2(
        after_year_end_adjustments=[
            AfterYearEndAdjustmentV2(
                adjustment_id="TP-3",
                label="TP missing buyer",
                tested_jurisdiction_id="TJ_SELLER",
                kind="income",
                amount=10.0,
                transaction_year_fy_start=date(2027, 1, 1),
                accrual_year_fy_start=date(2028, 1, 1),
                months_after_transaction_year_end=6,
                is_transfer_pricing_related=True,
            )
        ],
        options=TPMigrateFromAYEOptionsV2(allow_partial=True, combine_income_and_tax=True),
    )

    resp = migrate_tp_from_aye(payload)
    assert any(i.severity == "error" for i in resp.issues)
    assert len(resp.transfer_pricing_adjustments) == 0
    # By default, unmigrated TP rows remain in remaining_after_year_end_adjustments
    assert len(resp.remaining_after_year_end_adjustments) == 1
