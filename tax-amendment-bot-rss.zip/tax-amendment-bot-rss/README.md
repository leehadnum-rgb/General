# Tax Amendment Writer (Anything + Render + Exa + OpenAI)

This repo runs a scheduled job (Render Cron) that:

1. Pulls the next pending **alert** from your Anything app (`/api/internal/next-alert`)
2. Uses OpenAI + Exa to:
   - detect whether it's a **tax legislation amendment**
   - find the **amending instrument** and the **base/original law**
   - draft a Markdown article focused on **what changed**, with **citations to the laws**
3. Pushes the draft (or published post) back into Anything (`/api/internal/upsert-post`)
4. Marks the alert as processed (`/api/internal/mark-alert`)

You trigger alerts separately (e.g., Zapier), **or** you can enable RSS polling in this job.

### RSS option (skip Zapier)

If you set:

- `BLOOMBERG_RSS_FEED_URL`
- `BLOOMBERG_WEBHOOK_SECRET`

…the cron job will poll the RSS/Atom feed each run and ingest items into Anything using the same webhook route.

## 1) Configure environment variables

Copy `.env.example` to `.env` and fill in values.

Required:
- `ANYTHING_BASE_URL`
- `ANYTHING_INTERNAL_TOKEN`
- `OPENAI_API_KEY`
- `EXA_API_KEY`

Optional (RSS polling):
- `BLOOMBERG_RSS_FEED_URL`
- `BLOOMBERG_WEBHOOK_SECRET`
- `MAX_RSS_ITEMS_PER_RUN`

## 2) Run locally

```bash
npm install
cp .env.example .env
# edit .env
npm run job
```

## 3) Deploy to Render

Render will read `render.yaml` and create a Cron Job.

Set secrets in Render Dashboard:
- ANYTHING_BASE_URL
- ANYTHING_INTERNAL_TOKEN
- OPENAI_API_KEY
- EXA_API_KEY
Optionally:
- BLOOMBERG_RSS_FEED_URL
- BLOOMBERG_WEBHOOK_SECRET

## 4) Anything endpoints required

Your Anything app must implement these routes:

- `POST /api/webhooks/bloomberg` (Zapier or RSS polling posts alerts here)
- `GET /api/internal/next-alert` (returns one claimed alert or null/204)
- `POST /api/internal/mark-alert` (update status)
- `POST /api/internal/upsert-post` (create/update the post)

All `/api/internal/*` routes should require:
`Authorization: Bearer ${ANYTHING_INTERNAL_TOKEN}`

The webhook route should require:
`x-webhook-secret: ${BLOOMBERG_WEBHOOK_SECRET}`

See the main assistant message for the exact expected request/response shapes.
