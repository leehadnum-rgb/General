import { Expr } from "../../core/ast";

export type SgLiveMeasure = {
  measureId: string;
  measureType: "CUSTOMS_DUTY";
  originScope: "MFN" | "PREFERENTIAL" | "ALL";
  originCode: string;
  excludedOriginCodes?: string[] | null;
  expression: { expressionId: string; exprType: "AST" | "CUSTOM"; ast: Expr; sourceRef?: string | null; raw?: any };
};

export type SgLiveTariff = {
  code: string;
  description: string;
  currency: string;
  vatLabel: string;
  vatRatePct: number;
  vatBaseAst: Expr;
  measures: SgLiveMeasure[];
  unsupported: any[];
  sourceRef: string;
};

const GST_BASE_AST: Expr = {
  op: "add",
  terms: [
    { op: "field", name: "customs_value" },
    { op: "field", name: "customs_duty_total" },
    { op: "field", name: "fees_total" },
    { op: "field", name: "freight_to_border" },
    { op: "field", name: "insurance_to_border" },
  ],
};

function normalizeCode(code: string): string {
  return (code ?? "").replace(/[^0-9]/g, "");
}

function gstRatePct(): number {
  const raw = process.env.SG_GST_RATE_PCT ?? process.env.SG_VAT_RATE_PCT;
  const n = raw != null && raw !== "" ? Number(raw) : 9;
  return Number.isFinite(n) ? n : 9;
}

function classifyPotentialDutiable(codeDigits: string): { category: string; message: string } | null {
  // Singapore levies customs/excise duties mainly on a limited set of dutiable goods
  // (e.g., alcohol, tobacco, motor vehicles, petroleum). This MVP does not compute
  // those duties yet; we warn for likely HS chapters.
  if (!codeDigits) return null;
  if (codeDigits.startsWith("22")) {
    return { category: "ALCOHOL", message: "Singapore excise/customs duty may apply to alcoholic beverages (HS Chapter 22)." };
  }
  if (codeDigits.startsWith("24")) {
    return { category: "TOBACCO", message: "Singapore excise/customs duty may apply to tobacco products (HS Chapter 24)." };
  }
  if (codeDigits.startsWith("27")) {
    return { category: "PETROLEUM", message: "Singapore excise/customs duty may apply to petroleum / mineral fuels (HS Chapter 27)." };
  }
  if (codeDigits.startsWith("87")) {
    return { category: "MOTOR_VEHICLE", message: "Singapore taxes/fees may apply to motor vehicles (HS Chapter 87)." };
  }
  return null;
}

export async function fetchSgLiveTariff(codeInput: string): Promise<SgLiveTariff> {
  const currency = "SGD";
  const code = normalizeCode(codeInput);

  const unsupported: any[] = [];
  const maybe = classifyPotentialDutiable(code);
  if (maybe) {
    unsupported.push({
      kind: "dutiable_commodity_unimplemented",
      category: maybe.category,
      reason: "duty_not_implemented",
      message: maybe.message,
    });
  }

  // Customs duty: for most goods Singapore duty is 0. Represent as a 0% MFN duty measure.
  const measures: SgLiveMeasure[] = [
    {
      measureId: `sg:${code || "unknown"}:duty:mfn0`,
      measureType: "CUSTOMS_DUTY",
      originScope: "MFN",
      originCode: "ALL",
      excludedOriginCodes: null,
      expression: {
        expressionId: `sg:${code || "unknown"}:expr:mfn0`,
        exprType: "AST",
        ast: { op: "const_money", amount: "0", currency },
        sourceRef: "SG_RULES",
        raw: "0",
      },
    },
  ];

  return {
    code: code || "",
    description: code ? `Singapore import (HS ${code})` : "Singapore import",
    currency,
    vatLabel: "GST",
    vatRatePct: gstRatePct(),
    vatBaseAst: GST_BASE_AST,
    measures,
    unsupported,
    sourceRef: "SG_RULES",
  };
}
