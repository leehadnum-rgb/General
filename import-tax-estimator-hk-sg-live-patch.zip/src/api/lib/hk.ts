import { Expr } from "../../core/ast";

export type HkLiveMeasure = {
  measureId: string;
  measureType: "CUSTOMS_DUTY";
  originScope: "MFN" | "PREFERENTIAL" | "ALL";
  originCode: string;
  excludedOriginCodes?: string[] | null;
  expression: { expressionId: string; exprType: "AST" | "CUSTOM"; ast: Expr; sourceRef?: string | null; raw?: any };
};

export type HkLiveTariff = {
  code: string;
  description: string;
  currency: string;
  vatLabel: string;
  vatRatePct: number;
  vatBaseAst: Expr;
  measures: HkLiveMeasure[];
  unsupported: any[];
  sourceRef: string;
};

const VAT_BASE_AST: Expr = {
  op: "add",
  terms: [
    { op: "field", name: "customs_value" },
    { op: "field", name: "customs_duty_total" },
    { op: "field", name: "fees_total" },
    { op: "field", name: "freight_to_border" },
    { op: "field", name: "insurance_to_border" },
  ],
};

function normalizeCode(code: string): string {
  return (code ?? "").replace(/[^0-9]/g, "");
}

function classifyPotentialDutiable(codeDigits: string): { category: string; message: string } | null {
  // Hong Kong is generally a free port; excise applies to certain dutiable commodities.
  // This MVP does NOT compute excise. We surface a warning for likely chapters.
  if (!codeDigits) return null;
  if (codeDigits.startsWith("22")) {
    return { category: "ALCOHOL", message: "Hong Kong excise may apply to alcoholic beverages (HS Chapter 22)." };
  }
  if (codeDigits.startsWith("24")) {
    return { category: "TOBACCO", message: "Hong Kong excise may apply to tobacco products (HS Chapter 24)." };
  }
  if (codeDigits.startsWith("27")) {
    return { category: "HYDROCARBON_OIL", message: "Hong Kong excise may apply to hydrocarbon oil / fuels (HS Chapter 27)." };
  }
  if (codeDigits.startsWith("290511")) {
    return { category: "METHYL_ALCOHOL", message: "Hong Kong excise may apply to methyl alcohol (methanol)." };
  }
  return null;
}

export async function fetchHkLiveTariff(codeInput: string): Promise<HkLiveTariff> {
  const currency = "HKD";
  const code = normalizeCode(codeInput);

  const unsupported: any[] = [];
  const maybe = classifyPotentialDutiable(code);
  if (maybe) {
    unsupported.push({
      kind: "dutiable_commodity_unimplemented",
      category: maybe.category,
      reason: "excise_not_implemented",
      message: maybe.message,
    });
  }

  // Customs duty: HK is generally duty-free. Represent as a 0% MFN duty measure.
  const measures: HkLiveMeasure[] = [
    {
      measureId: `hk:${code || "unknown"}:duty:mfn0`,
      measureType: "CUSTOMS_DUTY",
      originScope: "MFN",
      originCode: "ALL",
      excludedOriginCodes: null,
      expression: {
        expressionId: `hk:${code || "unknown"}:expr:mfn0`,
        exprType: "AST",
        ast: { op: "const_money", amount: "0", currency },
        sourceRef: "HK_RULES",
        raw: "0",
      },
    },
  ];

  return {
    code: code || "",
    description: code ? `Hong Kong import (HS ${code})` : "Hong Kong import",
    currency,
    vatLabel: "Tax",
    vatRatePct: 0,
    vatBaseAst: VAT_BASE_AST,
    measures,
    unsupported,
    sourceRef: "HK_RULES",
  };
}
