# HK + SG Jurisdictions (Live, rules-only)

This patch adds `src/api/lib/hk.ts` and `src/api/lib/sg.ts`.

You still need to wire them into:
- `src/api/lib/jurisdictions.ts` (add HK and SG)
- `src/api/routes/requirements.ts` (route HK/SG before DB branch)
- `src/api/routes/estimate.ts` (route HK/SG before DB branch)

Env:
- `SG_GST_RATE_PCT` (default 9)
