from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field


# -----------------------------
# Filing / registers / datapoints
# -----------------------------

class FilingCreate(BaseModel):
    tenant_id: str = Field(..., description="Tenant identifier (e.g., 'demo' for local dev)")
    config_version_id: str
    period_start: date
    period_end: date
    reporting_currency: str

class FilingRead(BaseModel):
    id: str
    tenant_id: str
    config_version_id: str
    period_start: date
    period_end: date
    reporting_currency: str
    status: str
    created_at: datetime
    updated_at: datetime


# -----------------------------
# Import bridge (GIR XML upload)
# -----------------------------


class ImportGirXmlRequest(BaseModel):
    file_url: str = Field(..., description="Publicly accessible URL of the GIR XML file")
    source_system: Optional[str] = Field(default="anything_upload", description="Free-text provenance tag")
    replace_existing: bool = Field(
        default=True,
        description="If true, existing registers/datapoints for the filing are deleted before importing",
    )
    strict_xsd: bool = Field(
        default=False,
        description="Reserved for future: validate the XML against the GIR XSD before importing",
    )


class ImportGirXmlWarning(BaseModel):
    code: str
    message: str


class ImportGirXmlStats(BaseModel):
    filers_total: int = 0
    jurisdictions_total: int = 0
    entities_total: int = 0
    datapoints_total: int = 0


class ImportGirXmlResponse(BaseModel):
    import_id: str
    filing_id: str
    status: str
    stats: ImportGirXmlStats
    warnings: List[ImportGirXmlWarning] = []


class ImportGirXmlValidateRequest(ImportGirXmlRequest):
    """Request for the one-click import + validate endpoint."""

    notes: Optional[str] = Field(default=None, description="Optional notes stored on the validation run")


class ImportGirXmlValidateResponse(BaseModel):
    """Response for the one-click import + validate endpoint."""

    import_result: ImportGirXmlResponse
    validation_run: ValidationRunRead



# -----------------------------
# Import bridge (GIR Toolkit Excel / CSV uploads)
# -----------------------------

class ImportGirToolkitXlsxRequest(BaseModel):
    file_url: str = Field(..., description="Publicly accessible URL of the GIR Toolkit .xlsx file")
    source_system: Optional[str] = Field(default="gir_toolkit_xlsx", description="Free-text provenance tag")
    replace_existing: bool = Field(
        default=True,
        description="If true, existing registers/datapoints for the filing are deleted before importing",
    )
    preferred_sheet: Optional[str] = Field(
        default=None,
        description="Optional override for the sheet to import (default tries GIR_Export_FlatFile then Engine_Normalised_Output).",
    )


class ImportGirToolkitXlsxResponse(BaseModel):
    import_id: str
    filing_id: str
    status: str
    sheet_used: Optional[str] = None
    stats: ImportGirXmlStats
    warnings: List[ImportGirXmlWarning] = []


class ImportGirToolkitXlsxValidateRequest(ImportGirToolkitXlsxRequest):
    notes: Optional[str] = Field(default=None, description="Optional notes stored on the validation run")


class ImportGirToolkitXlsxValidateResponse(BaseModel):
    import_result: ImportGirToolkitXlsxResponse
    validation_run: ValidationRunRead

class FilerUpsert(BaseModel):
    filer_code: str
    legal_name: Optional[str] = None
    role: Optional[str] = None
    jurisdiction_code: Optional[str] = Field(default=None, min_length=2, max_length=2)
    tin: Optional[str] = None
    filing_ce_role: Optional[str] = Field(default=None, description="GIR filing CE role code (e.g., GIR401)")
    id_rules: Optional[str] = Field(default=None, description="ID/Rules code list value (e.g., GIR205)")
    globe_status: Optional[str] = Field(default=None, description="Globe status code list value (e.g., GIR301)")
    reporting_currency: Optional[str] = Field(default=None, min_length=3, max_length=3)
    scope: Optional[str] = None
    owner: Optional[str] = None
    status: Optional[str] = None

class ConstituentEntityUpsert(BaseModel):
    entity_code: str
    legal_name: Optional[str] = None
    jurisdiction_code: Optional[str] = Field(default=None, min_length=2, max_length=2)
    tin: Optional[str] = None
    included_in_gir: bool = True
    filed_by_filer_code: Optional[str] = None

    # Corporate structure (register-driven) fields
    id_rules: Optional[str] = Field(default=None, description="ID/Rules code list value (e.g., GIR205)")
    globe_status: Optional[str] = Field(default=None, description="Globe status code list value (e.g., GIR301)")
    parent_entity_code: Optional[str] = Field(default=None, description="Immediate parent entity code (for corporate structure ownership)")
    ownership_type: Optional[str] = Field(default=None, description="Ownership type code (GIR801..GIR806)")
    ownership_percentage: Optional[Decimal] = Field(default=None, description="Ownership percentage (0-100)")
    owner_tin_override: Optional[str] = Field(default=None, description="Override the ownership holder TIN if it cannot be derived")

class JurisdictionUpsert(BaseModel):
    jurisdiction_code: str = Field(..., min_length=2, max_length=2)
    local_currency: Optional[str] = Field(default=None, min_length=3, max_length=3)
    responsible_filer_code: Optional[str] = None
    computation_mode: Optional[str] = None
    qdmt_applicable: Optional[bool] = None
    status: Optional[str] = None
    notes: Optional[str] = None

class DataPointUpsert(BaseModel):
    filer_code: Optional[str] = None
    jurisdiction_code: Optional[str] = Field(default=None, min_length=2, max_length=2)
    entity_code: Optional[str] = None
    context_key: Optional[str] = None
    xml_path: str
    value_raw: str
    currency: Optional[str] = Field(default=None, min_length=3, max_length=3)
    source: str = "import"
    source_system: Optional[str] = None
    notes: Optional[str] = None


class DataPointRead(BaseModel):
    """A datapoint returned by the API.

    Sprint 1.3.1 adds `is_virtual` so callers can distinguish values that are
    stored in the database from values that are *derived on the fly* from
    registers (Filing Entity Register, Jurisdiction Register, Constituent Entity
    Register) and filing header fields.
    """

    id: str
    filer_code: Optional[str] = None
    jurisdiction_code: Optional[str] = None
    entity_code: Optional[str] = None
    context_key: Optional[str] = None

    xml_path: str
    value_raw: str
    value_numeric: Optional[Decimal] = None
    value_date: Optional[date] = None
    currency: Optional[str] = None

    source: str
    source_system: Optional[str] = None
    notes: Optional[str] = None
    updated_at: datetime

    is_virtual: bool = False


class EffectiveDataPointQueryResult(BaseModel):
    generated_at: datetime
    count: int
    persisted_count: int
    virtual_count: int
    items: List[DataPointRead]


class DataPointKey(BaseModel):
    """Canonical datapoint key used across the app.

    This matches the unique constraint used for datapoint upserts:
      (filing_id, filer_code, jurisdiction_code, entity_code, context_key, xml_path)
    """

    filer_code: Optional[str] = None
    jurisdiction_code: Optional[str] = None
    entity_code: Optional[str] = None
    context_key: Optional[str] = None
    xml_path: str


class EffectiveDataPointDiffItem(BaseModel):
    """Side-by-side view of persisted vs derived datapoints for a given key."""

    key: DataPointKey
    resolution: str = Field(..., description="How the effective value was chosen")
    differs: bool = Field(..., description="True if persisted and virtual both exist and differ")
    explain: str = Field(..., description="Human-friendly explanation for UI tooltips")

    effective: DataPointRead
    persisted: Optional[DataPointRead] = None
    virtual: Optional[DataPointRead] = None

    diff_fields: List[str] = Field(default_factory=list, description="Fields that differ (e.g. value_raw, currency)")


class EffectiveDataPointDiffResult(BaseModel):
    generated_at: datetime
    count: int
    keys_with_both: int
    overrides_count: int
    differences_count: int
    items: List[EffectiveDataPointDiffItem]


class EffectiveDataPointDiffSummaryBucket(BaseModel):
    """Aggregated counts for a dimension (e.g., section / filer / jurisdiction)."""

    key: str
    total_keys: int
    keys_with_both: int
    differences: int
    persisted_only: int
    virtual_only: int


class EffectiveDataPointDiffPathBucket(BaseModel):
    """Aggregated counts for a specific XML path."""

    xml_path: str
    total_keys: int
    keys_with_both: int
    differences: int


class EffectiveDataPointDiffSummaryResult(BaseModel):
    """Compact breakdown of persisted vs derived datapoint differences.

    Intended for dashboards and fast diagnostics (top mismatches by section,
    filer, jurisdiction, entity).
    """

    generated_at: datetime

    count_keys: int
    keys_with_both: int
    differences_count: int
    persisted_only_count: int
    virtual_only_count: int

    by_section: List[EffectiveDataPointDiffSummaryBucket] = []
    by_filer: List[EffectiveDataPointDiffSummaryBucket] = []
    by_jurisdiction: List[EffectiveDataPointDiffSummaryBucket] = []
    by_entity: List[EffectiveDataPointDiffSummaryBucket] = []

    top_diff_paths: List[EffectiveDataPointDiffPathBucket] = []

class BulkUpsertResult(BaseModel):
    inserted: int
    updated: int
    total: int

class ValidationRunCreate(BaseModel):
    # placeholder for Sprint 1+: allow selecting rule sets, toggles, etc.
    notes: Optional[str] = None

class ValidationRunRead(BaseModel):
    id: str
    filing_id: str
    config_version_id: str
    status: str
    started_at: datetime
    completed_at: Optional[datetime] = None
    message: Optional[str] = None

    total_issues: int = 0
    blocking_issues: int = 0
    warning_issues: int = 0
    info_issues: int = 0



# -----------------------------
# OECD error code catalogue
# -----------------------------

class OecdErrorCodeRead(BaseModel):
    """Metadata for an OECD GIR validation error code.

    Values are loaded from config/<version>/error_codes.json (generated from the OECD guidance workbook).
    """

    section: str
    number: int
    path_target: Optional[str] = None
    path_reference: Optional[str] = None
    element_name: Optional[str] = None
    validation_rule: Optional[str] = None
    validation_description: Optional[str] = None


class OecdErrorCodesResponse(BaseModel):
    config_version_id: str
    count: int
    sections: Dict[str, int] = Field(default_factory=dict)
    codes: List[OecdErrorCodeRead]


class ValidationIssueRead(BaseModel):
    id: str
    validation_run_id: str
    severity: str
    rule_id: str
    error_number: Optional[int] = None
    section: Optional[str] = None
    xml_path: Optional[str] = None
    message: str
    how_to_fix: Optional[str] = None
    oecd: Optional[OecdErrorCodeRead] = None

    filer_code: Optional[str] = None
    jurisdiction_code: Optional[str] = None
    entity_code: Optional[str] = None
    context_key: Optional[str] = None
    created_at: datetime

class ValidationIssueQueryResult(BaseModel):
    count: int
    items: List[ValidationIssueRead]


# -----------------------------
# Sprint 2.1 — Reconciliation
# -----------------------------


class ReconciliationGroupCounts(BaseModel):
    """Aggregated validation issue counts for a dimension key."""

    key: str
    blocking: int = 0
    warning: int = 0
    info: int = 0
    total: int = 0


class JurisdictionCoverageBucket(BaseModel):
    """Engine-agnostic coverage diagnostics per jurisdiction.

    This is meant to help UI dashboards answer: "Do we have any CE outputs for
    the entities we expect in this jurisdiction?".
    """

    jurisdiction_code: str
    responsible_filer_code: Optional[str] = None

    expected_included_entities: int = 0
    entities_with_outputs: int = 0
    missing_entity_outputs: int = 0

    jurisdiction_output_rows: int = 0
    entity_output_rows: int = 0


class ReconciliationSummaryResult(BaseModel):
    generated_at: datetime
    filing_id: str
    validation_run_id: str

    severity_counts: dict

    by_section: List[ReconciliationGroupCounts] = []
    by_filer: List[ReconciliationGroupCounts] = []
    by_jurisdiction: List[ReconciliationGroupCounts] = []
    by_entity: List[ReconciliationGroupCounts] = []

    missing_required_total: int = 0
    top_missing_required_paths: List[ReconciliationGroupCounts] = []

    jurisdiction_coverage: List[JurisdictionCoverageBucket] = []


class MissingDatapointItem(BaseModel):
    severity: str
    error_number: Optional[int] = None
    rule_id: str
    section: Optional[str] = None
    xml_path: str

    scope: str = Field(..., description="filing|filer|jurisdiction|entity")
    tax_label: Optional[str] = None
    allowed_values: List[str] = []

    filer_code: Optional[str] = None
    jurisdiction_code: Optional[str] = None
    entity_code: Optional[str] = None
    context_key: Optional[str] = None

    message: str
    how_to_fix: Optional[str] = None
    oecd: Optional[OecdErrorCodeRead] = None


class MissingDatapointResult(BaseModel):
    generated_at: datetime
    filing_id: str
    validation_run_id: str
    count: int
    items: List[MissingDatapointItem]


class RegisterCoverageIssue(BaseModel):
    severity: str = Field(..., description="BLOCKING/WARNING/INFO")
    area: str = Field(..., description="filers|entities|jurisdictions")
    code: str
    message: str
    filer_code: Optional[str] = None
    jurisdiction_code: Optional[str] = None
    entity_code: Optional[str] = None


class RegisterCoverageResult(BaseModel):
    generated_at: datetime
    filing_id: str
    filers: dict
    entities: dict
    jurisdictions: dict
    issues: List[RegisterCoverageIssue] = []


# -----------------------------
# Sprint 2.2 — Expected datapoints reconciliation
# -----------------------------


class ExpectedDatapointItem(BaseModel):
    set_id: str
    section: Optional[str] = None
    scope: str = Field(..., description="filing|filer|jurisdiction|entity")

    filer_code: Optional[str] = None
    jurisdiction_code: Optional[str] = None
    entity_code: Optional[str] = None
    context_key: Optional[str] = None

    xml_path: str
    tax_label: Optional[str] = None
    required: bool = False
    repeatable: bool = False

    is_present: bool = False
    present_id: Optional[str] = None
    present_is_virtual: Optional[bool] = None
    present_source: Optional[str] = None
    present_source_system: Optional[str] = None
    present_value_raw: Optional[str] = None
    present_currency: Optional[str] = None


class ExpectedDatapointResult(BaseModel):
    generated_at: datetime
    filing_id: str
    set_id: str
    set_description: Optional[str] = None
    count: int
    items: List[ExpectedDatapointItem]


class JurisdictionEntityCompletenessEntity(BaseModel):
    entity_code: str
    legal_name: Optional[str] = None
    filer_code: Optional[str] = None
    required_count: int
    present_count: int
    missing_count: int
    missing_xml_paths: List[str] = []


class JurisdictionEntityCompletenessRow(BaseModel):
    jurisdiction_code: str
    expected_entities: int
    entities_complete: int
    entities_partial: int
    entities_missing: int
    missing_datapoints_total: int
    required_datapoints_per_entity: int
    completion_ratio_entities: Optional[float] = None
    entities: Optional[List[JurisdictionEntityCompletenessEntity]] = None


class JurisdictionEntityCompletenessResult(BaseModel):
    generated_at: datetime
    filing_id: str
    set_id: str
    set_description: Optional[str] = None
    required_datapoints_per_entity: int
    jurisdictions: List[JurisdictionEntityCompletenessRow]


# -----------------------------
# Sprint 2.4 — Multi-pack completeness dashboards
# -----------------------------


class PackSetMeta(BaseModel):
    """Metadata for a reconciliation set used as a "pack" in dashboards."""

    set_id: str
    description: Optional[str] = None
    section: Optional[str] = None
    scope: str = Field(..., description="filing|filer|jurisdiction|entity")

    pack_family: Optional[str] = None
    pack_variant: Optional[str] = None
    pack_tags: List[str] = []
    treat_included_as_required: bool = False

    computation_mode_in: Optional[List[str]] = None
    qdmt_applicable: Optional[bool] = None


class MissingExpectedSample(BaseModel):
    xml_path: str
    tax_label: Optional[str] = None


class PackCompletenessStats(BaseModel):
    """Checklist-style completeness for a pack at its natural scope."""

    set_id: str
    active: bool = True

    required_count: int = 0
    present_count: int = 0
    missing_count: int = 0
    completion_ratio: Optional[float] = None

    missing_samples: List[MissingExpectedSample] = []


class EntityPackCompletenessStats(BaseModel):
    """Entity-scoped pack completeness summarized per jurisdiction."""

    set_id: str
    active: bool = True

    expected_entities: int = 0
    entities_complete: int = 0
    entities_partial: int = 0
    entities_missing: int = 0
    missing_datapoints_total: int = 0
    required_datapoints_per_entity: int = 0
    completion_ratio_entities: Optional[float] = None


class JurisdictionPackDashboardRow(BaseModel):
    jurisdiction_code: str
    responsible_filer_code: Optional[str] = None
    computation_mode: Optional[str] = None
    computation_mode_norm: Optional[str] = None
    qdmt_applicable: Optional[bool] = None

    packs: List[PackCompletenessStats] = []
    entity_packs: List[EntityPackCompletenessStats] = []

    # Convenience totals for dashboards (across active packs)
    packs_active_count: int = 0
    packs_required_total: int = 0
    packs_present_total: int = 0
    packs_missing_total: int = 0
    packs_completion_ratio: Optional[float] = None

    entity_packs_active_count: int = 0
    entity_packs_expected_entities_total: int = 0
    entity_packs_entities_complete_total: int = 0
    entity_packs_entities_missing_total: int = 0


class FilerPackDashboardRow(BaseModel):
    filer_code: str
    role: Optional[str] = None
    jurisdiction_code: Optional[str] = None
    packs: List[PackCompletenessStats] = []

    packs_active_count: int = 0
    packs_required_total: int = 0
    packs_present_total: int = 0
    packs_missing_total: int = 0
    packs_completion_ratio: Optional[float] = None


class PackCompletenessDashboardResult(BaseModel):
    generated_at: datetime
    filing_id: str
    config_version_id: str

    set_count: int
    sets: List[PackSetMeta] = []

    jurisdictions: List[JurisdictionPackDashboardRow] = []
    filers: List[FilerPackDashboardRow] = []
