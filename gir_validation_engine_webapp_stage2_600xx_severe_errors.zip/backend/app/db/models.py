import uuid
from datetime import datetime, date
from sqlalchemy import (
    Column, String, Date, DateTime, Boolean, Text, Numeric,
    UniqueConstraint, Index
)
from app.db.base import Base

def _uuid() -> str:
    return str(uuid.uuid4())

class Tenant(Base):
    __tablename__ = "tenant"
    id = Column(String(64), primary_key=True)  # allow string tenant ids like 'demo'
    name = Column(String(255), nullable=True)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)

class Filing(Base):
    __tablename__ = "filing"
    id = Column(String(36), primary_key=True, default=_uuid)
    tenant_id = Column(String(64), nullable=False, index=True)
    config_version_id = Column(String(128), nullable=False)
    period_start = Column(Date, nullable=False)
    period_end = Column(Date, nullable=False)
    reporting_currency = Column(String(3), nullable=False)
    status = Column(String(32), nullable=False, default="draft")
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow)

    __table_args__ = (
        Index("ix_filing_tenant_status", "tenant_id", "status"),
    )

class Filer(Base):
    __tablename__ = "filer"
    id = Column(String(36), primary_key=True, default=_uuid)
    filing_id = Column(String(36), nullable=False, index=True)
    filer_code = Column(String(64), nullable=False)
    legal_name = Column(String(255), nullable=True)
    role = Column(String(64), nullable=True)  # UPE/POPE/DESIGNATED/...
    jurisdiction_code = Column(String(2), nullable=True)
    tin = Column(String(64), nullable=True)
    filing_ce_role = Column(String(16), nullable=True)  # GIR401/GIR402/...
    id_rules = Column(String(16), nullable=True)  # e.g., GIR205
    globe_status = Column(String(16), nullable=True)  # e.g., GIR301
    reporting_currency = Column(String(3), nullable=True)
    scope = Column(String(255), nullable=True)
    owner = Column(String(255), nullable=True)
    status = Column(String(32), nullable=True)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow)

    __table_args__ = (
        UniqueConstraint("filing_id", "filer_code", name="uq_filer_filing_code"),
    )

class ConstituentEntity(Base):
    __tablename__ = "constituent_entity"
    id = Column(String(36), primary_key=True, default=_uuid)
    filing_id = Column(String(36), nullable=False, index=True)
    entity_code = Column(String(64), nullable=False)
    legal_name = Column(String(255), nullable=True)
    jurisdiction_code = Column(String(2), nullable=True)
    tin = Column(String(64), nullable=True)
    included_in_gir = Column(Boolean, nullable=False, default=True)
    filed_by_filer_code = Column(String(64), nullable=True)

    # Sprint 1.3+ (register-driven) corporate structure fields
    id_rules = Column(String(16), nullable=True)  # e.g., GIR205
    globe_status = Column(String(16), nullable=True)  # e.g., GIR301
    parent_entity_code = Column(String(64), nullable=True)
    ownership_type = Column(String(16), nullable=True)  # GIR801..GIR806
    ownership_percentage = Column(Numeric(38, 10), nullable=True)
    owner_tin_override = Column(String(64), nullable=True)

    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow)

    __table_args__ = (
        UniqueConstraint("filing_id", "entity_code", name="uq_entity_filing_code"),
    )

class Jurisdiction(Base):
    __tablename__ = "jurisdiction"
    id = Column(String(36), primary_key=True, default=_uuid)
    filing_id = Column(String(36), nullable=False, index=True)
    jurisdiction_code = Column(String(2), nullable=False)
    local_currency = Column(String(3), nullable=True)
    responsible_filer_code = Column(String(64), nullable=True)
    computation_mode = Column(String(128), nullable=True)
    qdmt_applicable = Column(Boolean, nullable=True)
    status = Column(String(32), nullable=True)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow)

    __table_args__ = (
        UniqueConstraint("filing_id", "jurisdiction_code", name="uq_juris_filing_code"),
    )

class DataPoint(Base):
    __tablename__ = "datapoint"
    id = Column(String(36), primary_key=True, default=_uuid)
    filing_id = Column(String(36), nullable=False, index=True)

    filer_code = Column(String(64), nullable=True, index=True)
    jurisdiction_code = Column(String(2), nullable=True, index=True)
    entity_code = Column(String(64), nullable=True, index=True)
    context_key = Column(String(128), nullable=True, index=True)

    xml_path = Column(String(1024), nullable=False, index=True)
    value_raw = Column(Text, nullable=False)
    value_numeric = Column(Numeric(38, 10), nullable=True)
    value_date = Column(Date, nullable=True)
    currency = Column(String(3), nullable=True)

    source = Column(String(32), nullable=False, default="import")  # manual/import/derived
    source_system = Column(String(255), nullable=True)
    notes = Column(Text, nullable=True)

    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow)

    __table_args__ = (
        UniqueConstraint(
            "filing_id", "filer_code", "jurisdiction_code", "entity_code", "context_key", "xml_path",
            name="uq_datapoint_key"
        ),
        Index("ix_datapoint_filing_path", "filing_id", "xml_path"),
    )

class ValidationRun(Base):
    __tablename__ = "validation_run"
    id = Column(String(36), primary_key=True, default=_uuid)
    filing_id = Column(String(36), nullable=False, index=True)
    config_version_id = Column(String(128), nullable=False)
    status = Column(String(32), nullable=False, default="queued")  # queued/running/completed/failed
    started_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)
    message = Column(Text, nullable=True)


class ValidationIssue(Base):
    __tablename__ = "validation_issue"
    id = Column(String(36), primary_key=True, default=_uuid)
    validation_run_id = Column(String(36), nullable=False, index=True)

    severity = Column(String(16), nullable=False)  # BLOCKING/WARNING/INFO
    rule_id = Column(String(64), nullable=False)
    error_number = Column(Numeric(10, 0), nullable=True)

    section = Column(String(64), nullable=True)
    xml_path = Column(String(1024), nullable=True)

    message = Column(Text, nullable=False)
    how_to_fix = Column(Text, nullable=True)

    filer_code = Column(String(64), nullable=True, index=True)
    jurisdiction_code = Column(String(2), nullable=True, index=True)
    entity_code = Column(String(64), nullable=True, index=True)
    context_key = Column(String(128), nullable=True)

    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)

    __table_args__ = (
        Index("ix_validation_issue_run_sev", "validation_run_id", "severity"),
    )
