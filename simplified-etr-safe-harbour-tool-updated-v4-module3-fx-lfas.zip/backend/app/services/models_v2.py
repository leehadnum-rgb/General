from __future__ import annotations

from datetime import date
from typing import List, Optional, Literal, Any

from pydantic import BaseModel, Field, model_validator

from app.services.models import (
    AdjustmentLine,
    ElectionRecord,
    TraceLine,
    JurisdictionInput as JurisdictionInputV1,
    EntityInput as EntityInputV1,
)


# ---------------------------------------------------------------------------
# Accounting basis / currency translation scaffolding (v4 module 2)
# ---------------------------------------------------------------------------

AmountScale = Literal["UNITS", "THOUSANDS", "MILLIONS"]
AccountingBasisSource = Literal["CFS", "LOCAL_GAAP", "OTHER"]


class AccountingBasisV2(BaseModel):
    """Accounting basis / currency metadata.

    This tool is a *calculator* and cannot determine accounting standards or currency translation
    independently. The OECD guidance requires that currency translation rules apply, and that
    certain jurisdictions subject to QDMTT LFAS rules may require local accounting standards.

    v4 module 2 introduces lightweight scaffolding to:
      - record the accounting basis assumptions,
      - normalise monetary inputs to a reporting currency when FX rates are provided, and
      - raise errors for obvious LFAS conflicts.
    """

    basis_source: AccountingBasisSource = Field(
        default="CFS",
        description=(
            "Source of accounting basis used for the figures supplied (e.g., CFS or local GAAP). "
            "This is used for validation and audit trail only."
        ),
    )

    standard: Optional[str] = Field(
        default=None,
        description="Optional label for the accounting standard used (e.g., IFRS, US GAAP, UK GAAP, local GAAP).",
    )

    currency: Optional[str] = Field(
        default=None,
        description=(
            "Currency code for monetary inputs provided for this Tested Jurisdiction (e.g., 'EUR', 'USD'). "
            "If omitted, and a request.group_profile.reporting_currency is provided, the tool assumes amounts "
            "are already in that reporting currency."
        ),
    )

    amount_scale: AmountScale = Field(
        default="UNITS",
        description="Scale applied to monetary inputs: UNITS (as entered), THOUSANDS (x1,000), or MILLIONS (x1,000,000).",
    )

    # LFAS / QDMTT scaffolding
    lfas_qdmtt_applies: bool = Field(
        default=False,
        description=(
            "If True, the Tested Jurisdiction is subject to a QDMTT LFAS requirement (jurisdiction requires local financial accounting standards)."
        ),
    )
    lfas_requires_local_gaap: bool = Field(
        default=False,
        description=(
            "If True, the user asserts that the jurisdiction requires using local GAAP for QDMTT LFAS purposes. "
            "If basis_source='CFS' and the jurisdiction does not allow CFS GAAP, the tool will raise an error."
        ),
    )
    jurisdiction_allows_cfs_gaap_for_qdmtt: Optional[bool] = Field(
        default=None,
        description=(
            "If True, the jurisdiction allows using the CFS accounting standard for QDMTT even if LFAS would otherwise apply. "
            "If omitted, treated as False for validation when lfas_requires_local_gaap=True."
        ),
    )

    note: Optional[str] = None

    @model_validator(mode="after")
    def _validate_lfas(self) -> "AccountingBasisV2":
        """Tighter LFAS / QDMTT gating rules (v4 module 3).

        Practical implementation:
        - If the user asserts local GAAP is required (lfas_requires_local_gaap=True), then:
            * basis_source must be either LOCAL_GAAP, or CFS where the jurisdiction explicitly allows it.
            * basis_source='OTHER' is not accepted (too ambiguous for a determinate tool).
        - If basis_source='CFS' under a local GAAP requirement, jurisdiction_allows_cfs_gaap_for_qdmtt must be True.
        """

        if self.lfas_requires_local_gaap:
            if self.basis_source == "OTHER":
                raise ValueError(
                    "LFAS validation: lfas_requires_local_gaap=true but basis_source='OTHER'. Use basis_source='LOCAL_GAAP' (or 'CFS' if explicitly allowed)."
                )

            if self.basis_source == "CFS" and not bool(self.jurisdiction_allows_cfs_gaap_for_qdmtt):
                raise ValueError(
                    "LFAS validation: lfas_requires_local_gaap=true but basis_source='CFS' and jurisdiction_allows_cfs_gaap_for_qdmtt is not true."
                )
        return self


class GroupProfileV2(BaseModel):
    reporting_currency: Optional[str] = Field(
        default=None,
        description="Group reporting currency used for results (e.g., 'EUR'). If provided, FX rates may be used to translate inputs.",
    )
    default_accounting_standard: Optional[str] = Field(
        default=None,
        description="Optional label for group default accounting standard (e.g., IFRS).",
    )
    fx_translation_convention: Optional[str] = Field(
        default="PL_AVG_BS_SPOT",
        description=(
            "Currency translation convention used when FX rates are supplied. "
            "This tool applies average FX rates to P&L-type items (income/taxes) and spot FX rates to balance sheet items "
            "(when/if such items are introduced, e.g., Transition Year opening DTAs/DTLs)."
        ),
    )
    note: Optional[str] = None


class FxRateV2(BaseModel):
    """FX rate to translate from a local currency into the reporting currency."""

    currency: str = Field(..., description="Local currency code (e.g., 'USD').")
    avg_rate_to_reporting: float = Field(..., gt=0.0, description="Average FX rate to reporting currency for P&L items.")
    spot_rate_to_reporting: Optional[float] = Field(
        default=None,
        gt=0.0,
        description=(
            "Optional spot / closing FX rate to reporting currency. "
            "Used for balance sheet translation conventions (v4 module 3 and later modules)."
        ),
    )
    fiscal_year_start: Optional[date] = Field(
        default=None,
        description="Optional fiscal year start date that this FX rate applies to. If omitted, used as a default rate for that currency.",
    )
    note: Optional[str] = None


# ---------------------------------------------------------------------------
# v2 wrappers around v1 input models
# ---------------------------------------------------------------------------

class JurisdictionFactsV2(JurisdictionInputV1):
    """Jurisdiction facts (v2).

    This model inherits the existing v1 JurisdictionInput for maximum re-use, but makes
    jurisdiction_code optional so UI clients do not need to duplicate it. The API will override
    the internal bucket id with tested_jurisdiction_id when running calculations.
    """

    jurisdiction_code: Optional[str] = Field(
        default=None,
        description=(
            "Optional. UI may omit this; the server will fill it internally. "
            "In v2, tested_jurisdiction_id is used as the internal grouping key."
        ),
    )


class EntityFactsV2(EntityInputV1):
    """Entity facts (v2).

    In v2, entities are typically nested under a Tested Jurisdiction. The server will override
    the internal grouping key with tested_jurisdiction_id when running calculations.
    """

    jurisdiction_code: Optional[str] = Field(
        default=None,
        description=(
            "Optional. This tool groups entities by tested_jurisdiction_id (not jurisdiction_code) in v2. "
            "Use tested_jurisdiction.jurisdiction_code for the country/territory code."
        ),
    )


# ---------------------------------------------------------------------------
# Elections (v2)
# ---------------------------------------------------------------------------

Scope = Literal["income", "tax", "eligibility", "metadata"]
ValueType = Literal["bool", "amount", "text"]
TermType = Literal["ANNUAL", "FIVE_YEAR"]
ElectionAction = Literal["ELECT", "REVOKE"]


class ElectionInstanceV2(BaseModel):
    """An election or adjustment selection associated with a Tested Jurisdiction."""

    action: ElectionAction = Field(
        default="ELECT",
        description=(
            "Election register event type. 'ELECT' records that the election is made; 'REVOKE' records that it is revoked "
            "(used for FIVE_YEAR elections which continue until revoked in the OECD guidance)."
        ),
    )

    election_code: str = Field(..., description="Election/adjustment code (see /api/v2/election-catalog).")
    scope: Scope = Field(..., description="Which part of the safe harbour it relates to.")
    value_type: ValueType = Field(..., description="Value type for the election.")
    # Optional term type on instance; if omitted, the server will infer from election catalog when possible.
    term_type: Optional[TermType] = Field(
        default=None,
        description="ANNUAL or FIVE_YEAR. If omitted, server will infer from the election catalog.",
    )
    effective_fiscal_year_start: Optional[date] = Field(
        default=None,
        description="Fiscal year start date when this election starts. Defaults to the request fiscal year start date.",
    )
    # Values
    bool_value: Optional[bool] = None
    amount: Optional[float] = Field(default=None, description="Signed amount (+/-) if value_type='amount'.")
    text_value: Optional[str] = None
    label: Optional[str] = None
    note: Optional[str] = None

    @model_validator(mode="after")
    def _validate_value(self) -> "ElectionInstanceV2":
        # Revocation events act as a timeline marker. They do not carry a value.
        if self.action == "REVOKE":
            return self
        vt = self.value_type
        if vt == "bool" and self.bool_value is None:
            raise ValueError(f"Election {self.election_code}: value_type='bool' requires bool_value.")
        if vt == "amount" and self.amount is None:
            raise ValueError(f"Election {self.election_code}: value_type='amount' requires amount.")
        if vt == "text" and (self.text_value is None or str(self.text_value).strip() == ""):
            raise ValueError(f"Election {self.election_code}: value_type='text' requires text_value.")
        return self


# ---------------------------------------------------------------------------
# Carryforwards (v2)
# ---------------------------------------------------------------------------

CarryforwardKind = Literal[
    "SIMPLIFIED_NEGATIVE_TAX_ADJUSTMENT",  # Box 4.3 (paragraphs 1-3)
    "EXCESS_NEGATIVE_TAX_CARRYFORWARD",    # GloBE Article 4.1.5 carry-forward (input)
    "LOSS_DTA_ADJUSTMENT",                 # Box 4.3 (paragraph 4) alternative methodology
]


class CarryforwardBalanceV2(BaseModel):
    kind: CarryforwardKind
    origin_fiscal_year_start: Optional[date] = Field(
        default=None, description="Fiscal year start date when the balance was generated (if known)."
    )
    amount: float = Field(
        ...,
        description=(
            "Opening amount of the carryforward. Enter as a positive number. "
            "The tool applies it as a reduction to Simplified Taxes, subject to OECD limits."
        ),
    )
    remaining_amount: Optional[float] = Field(
        default=None,
        description="If omitted, defaults to amount. Must be >= 0.",
    )
    note: Optional[str] = None

    @model_validator(mode="after")
    def _normalise(self) -> "CarryforwardBalanceV2":
        # Normalise negative values to positive to avoid sign confusion.
        if self.amount < 0:
            self.amount = abs(self.amount)
        if self.remaining_amount is None:
            self.remaining_amount = float(self.amount)
        if self.remaining_amount < 0:
            self.remaining_amount = abs(self.remaining_amount)
        return self


class CarryforwardMovementV2(BaseModel):
    kind: CarryforwardKind
    used_amount: float = Field(..., ge=0.0, description="Amount utilised in the current fiscal year (>= 0).")
    remaining_amount: float = Field(..., ge=0.0, description="Remaining amount after utilisation (>= 0).")
    note: Optional[str] = None


# ---------------------------------------------------------------------------
# Cross-border adjustments (v2)
# ---------------------------------------------------------------------------

CrossBorderTaxTreatment = Literal[
    "ALLOCATE",          # subtract from source and add to target
    "EXCLUDE_FROM_ALL",  # subtract from source and add to no Tested Jurisdiction
    "KEEP_IN_SOURCE",    # do not adjust (i.e., keep where recorded)
]


class CrossBorderTaxItemV2(BaseModel):
    """Cross-border allocable tax item.

    This is a *structured* way to handle the OECD cross-border tax exclusion/allocation concept.
    The user provides the tax amount and where it is recorded (source) and optionally where it
    should be allocated (target).

    The engine applies the adjustment after the base v1 Simplified Taxes computation, and before
    carryforwards, so it affects Simplified ETR.
    """

    item_id: Optional[str] = None
    label: Optional[str] = None
    category: Optional[str] = Field(
        default=None,
        description="Optional category label (e.g., withholding, CFC, PE, hybrid, other).",
    )

    amount: float = Field(..., ge=0.0, description="Tax amount (positive).")

    currency: Optional[str] = Field(
        default=None,
        description=(
            "Optional currency code for the amount (e.g., 'USD'). If request.group_profile.reporting_currency is provided "
            "and currency differs, the engine will translate this amount using request.fx_rates. "
            "If omitted, the tool assumes the amount is already in the reporting currency (when provided)."
        ),
    )

    amount_scale: AmountScale = Field(
        default="UNITS",
        description="Scale applied to the amount: UNITS/THOUSANDS/MILLIONS. Applied before FX translation.",
    )

    source_tested_jurisdiction_id: Optional[str] = Field(
        default=None,
        description="Tested Jurisdiction where the tax is currently recorded (for safe harbour purposes).",
    )
    target_tested_jurisdiction_id: Optional[str] = Field(
        default=None,
        description="Tested Jurisdiction to which the tax should be allocated (if applicable).",
    )

    treatment: Optional[CrossBorderTaxTreatment] = Field(
        default=None,
        description=(
            "How to treat the tax item. If omitted, the engine infers a default based on whether a target is provided "
            "and whether the cross-border 'keep allocable taxes' election is in effect for the source jurisdiction."
        ),
    )

    requires_pe_simplification_election: bool = Field(
        default=False,
        description=(
            "If True, the engine requires the PE simplification election to be effective for the relevant Tested Jurisdiction(s). "
            "Use this when the allocation relies on the PE simplification election."  
        ),
    )

    note: Optional[str] = None

    @model_validator(mode="after")
    def _validate(self) -> "CrossBorderTaxItemV2":
        if self.treatment == "ALLOCATE" and not self.target_tested_jurisdiction_id:
            raise ValueError("CrossBorderTaxItemV2: treatment='ALLOCATE' requires target_tested_jurisdiction_id.")
        return self


# ---------------------------------------------------------------------------
# Investment entity owner addbacks (v2)
# ---------------------------------------------------------------------------

OwnerAddbackKind = Literal["tax", "income"]
InvestmentEntityArticle = Literal["7.5", "7.6"]


class InvestmentEntityOwnerAddbackV2(BaseModel):
    """Structured owner addback line for Investment Entity rules (Articles 7.5 and 7.6).

    The OECD investment entity rules can require adding certain owner-level taxes (and in some cases
    related income) back into the Tested Jurisdiction's Simplified Taxes/Simplified Income.

    This tool models the addback as a signed amount applied to Simplified Taxes or Simplified Income.
    """

    addback_id: Optional[str] = None
    label: str = Field(..., description="Short label for the addback.")
    article: InvestmentEntityArticle = Field(..., description="OECD rule reference: '7.5' or '7.6'.")
    kind: OwnerAddbackKind = Field(..., description="Whether this addback adjusts Simplified Taxes or Simplified Income.")
    amount: float = Field(..., description="Signed amount (+/-) to apply.")

    owner_name: Optional[str] = None
    owner_jurisdiction_code: Optional[str] = None
    note: Optional[str] = None


# ---------------------------------------------------------------------------
# Tested Jurisdiction wrapper
# ---------------------------------------------------------------------------

AggregationMethod = Literal["JURISDICTION_FACTS", "ENTITY_ROLLUP", "MIXED"]


class TestedJurisdictionCompositionV2(BaseModel):
    aggregation_method: AggregationMethod = Field(
        default="JURISDICTION_FACTS",
        description="How inputs are provided for the Tested Jurisdiction.",
    )


class EligibilityInputsV2(BaseModel):
    ineligible_stateless: bool = False
    ineligible_investment_entity: bool = False
    ineligible_article7_3_outstanding_recapture: bool = False

    stateless_exception_section_6_2_applies: bool = False
    investment_entity_tax_transparency_election_applies: bool = False

    no_topup_tax_in_prior_24_months: bool = True
    reentry_no_topup_tax_in_prior_24_months: Optional[bool] = None

    integrity_rules_satisfied: bool = True


class DeemedZeroRulesV2(BaseModel):
    apply_deemed_zero: bool = Field(
        default=False,
        description=(
            "If True, treat Simplified Income and Simplified Taxes as zero for the Tested Jurisdiction "
            "(deemed-zero rule). This is intended for certain Tax-Neutral Entity scenarios."
        ),
    )
    rationale: Optional[str] = None


class TestedJurisdictionInputV2(BaseModel):
    tested_jurisdiction_id: str = Field(..., description="Unique identifier for this Tested Jurisdiction.")
    jurisdiction_code: Optional[str] = Field(
        default=None, description="Country/territory code (e.g. 'GB', 'DE'). Multiple Tested Jurisdictions may share a code."
    )
    label: Optional[str] = Field(default=None, description="Optional display label.")
    tested_jurisdiction_type: Optional[str] = Field(
        default=None,
        description="Optional classification (e.g., 'standard', 'stateless', 'investment_entity'). Informational.",
    )

    accounting_basis: AccountingBasisV2 = Field(
        default_factory=AccountingBasisV2,
        description=(
            "Accounting basis and currency metadata. If request.group_profile.reporting_currency is provided "
            "and accounting_basis.currency differs, inputs will be translated using request.fx_rates." 
        ),
    )

    composition: TestedJurisdictionCompositionV2 = Field(default_factory=TestedJurisdictionCompositionV2)

    # Inputs (either provide facts or entities depending on composition method)
    facts: Optional[JurisdictionFactsV2] = None
    entities: List[EntityFactsV2] = Field(default_factory=list)

    # Elections and carryforwards
    elections: List[ElectionInstanceV2] = Field(default_factory=list)
    owner_addbacks: List[InvestmentEntityOwnerAddbackV2] = Field(
        default_factory=list,
        description="Structured owner addbacks (Articles 7.5/7.6) applied to this Tested Jurisdiction.",
    )
    carryforwards_opening: List[CarryforwardBalanceV2] = Field(default_factory=list)

    # Eligibility & deemed-zero
    eligibility_inputs: EligibilityInputsV2 = Field(default_factory=EligibilityInputsV2)
    deemed_zero_rules: DeemedZeroRulesV2 = Field(default_factory=DeemedZeroRulesV2)

    @model_validator(mode="after")
    def _validate_composition(self) -> "TestedJurisdictionInputV2":
        m = self.composition.aggregation_method
        if m == "JURISDICTION_FACTS":
            if self.facts is None:
                raise ValueError(f"{self.tested_jurisdiction_id}: aggregation_method='JURISDICTION_FACTS' requires facts.")
        elif m == "ENTITY_ROLLUP":
            if not self.entities:
                raise ValueError(f"{self.tested_jurisdiction_id}: aggregation_method='ENTITY_ROLLUP' requires entities[].")
        elif m == "MIXED":
            if self.facts is None and not self.entities:
                raise ValueError(f"{self.tested_jurisdiction_id}: aggregation_method='MIXED' requires facts and/or entities[].")
        return self


# ---------------------------------------------------------------------------
# Request / Response (v2)
# ---------------------------------------------------------------------------

class ApplicabilityOptionsV2(BaseModel):
    apply_optional_2025_start_rule: bool = False
    early_start_qdmtt_safe_harbour_applies: bool = False
    early_start_only_one_jurisdiction_has_taxing_rights: bool = False
    early_start_all_taxing_rights_jurisdictions_allow: bool = False


class FiscalYearV2(BaseModel):
    start_date: date
    end_date: Optional[date] = None


class CalculationRequestV2(BaseModel):
    schema_version: Literal["2.0", "2.1"] = "2.0"
    ruleset_version: str = Field(default="OECD_SBS_2026_01", description="OECD Side-by-Side Package (Jan 2026).")

    fiscal_year: FiscalYearV2
    minimum_rate: float = Field(default=0.15, ge=0.0, le=1.0)

    group_profile: Optional[GroupProfileV2] = Field(
        default=None,
        description="Optional group profile metadata (reporting currency and accounting standard).",
    )
    fx_rates: List[FxRateV2] = Field(
        default_factory=list,
        description=(
            "Optional FX rates used to translate Tested Jurisdiction inputs into the reporting currency. "
            "If group_profile.reporting_currency is provided and a Tested Jurisdiction declares a different currency, "
            "a matching FX rate must be provided."
        ),
    )

    applicability: ApplicabilityOptionsV2 = Field(default_factory=ApplicabilityOptionsV2)

    cross_border_tax_items: List[CrossBorderTaxItemV2] = Field(
        default_factory=list,
        description="Optional cross-border tax items that require exclusion/allocation between Tested Jurisdictions.",
    )

    tested_jurisdictions: List[TestedJurisdictionInputV2] = Field(default_factory=list)

    @model_validator(mode="after")
    def _validate(self) -> "CalculationRequestV2":
        if not self.tested_jurisdictions:
            raise ValueError("tested_jurisdictions[] must contain at least one Tested Jurisdiction.")

        # Normalise reporting currency to uppercase (if provided)
        if self.group_profile and self.group_profile.reporting_currency:
            self.group_profile.reporting_currency = str(self.group_profile.reporting_currency).upper().strip() or None

        # Normalise FX currencies and validate duplicates
        seen_fx: set[tuple[str, Optional[date]]] = set()
        for r in (self.fx_rates or []):
            r.currency = str(r.currency).upper().strip()
            key = (r.currency, r.fiscal_year_start)
            if key in seen_fx:
                raise ValueError(f"Duplicate FX rate entry for currency '{r.currency}' and fiscal_year_start={r.fiscal_year_start}.")
            seen_fx.add(key)

        # LFAS / QDMTT group-wide gating (v4 module 3)
        # OECD requires that if an MNE uses a permitted CFS GAAP election in one QDMTT LFAS jurisdiction,
        # it should apply consistently across all QDMTT LFAS jurisdictions that provide the same election.
        lfas_allow_election: list[TestedJurisdictionInputV2] = []
        for tj in self.tested_jurisdictions:
            b = tj.accounting_basis
            if bool(b.lfas_qdmtt_applies) and bool(b.lfas_requires_local_gaap) and bool(b.jurisdiction_allows_cfs_gaap_for_qdmtt):
                lfas_allow_election.append(tj)

        cfs_used = any(tj.accounting_basis.basis_source == "CFS" for tj in lfas_allow_election)
        if cfs_used:
            # If CFS basis is used in any LFAS jurisdiction where an election is available, require all such jurisdictions to use it.
            offenders = [tj.tested_jurisdiction_id for tj in lfas_allow_election if tj.accounting_basis.basis_source != "CFS"]
            if offenders:
                raise ValueError(
                    "LFAS consistency: basis_source='CFS' is used in at least one QDMTT LFAS jurisdiction where an election is available. "
                    "OECD consistency requires applying the election to all such jurisdictions. "
                    f"Set basis_source='CFS' for: {', '.join(offenders)} (or use LOCAL_GAAP for all)."
                )

        return self


class TestedJurisdictionResultV2(BaseModel):
    tested_jurisdiction_id: str
    jurisdiction_code: Optional[str] = None
    label: Optional[str] = None

    eligible: bool
    ineligibility_reasons: List[str] = Field(default_factory=list)

    simplified_income: float
    simplified_taxes: float
    simplified_etr: Optional[float] = None
    simplified_loss: float = 0.0

    safe_harbour_applies: bool
    safe_harbour_reason: str

    # Negative tax adjustment proxy (for transparency)
    simplified_adjustment_for_negative_taxes: float = 0.0

    # Elections and trace
    effective_elections: List[ElectionInstanceV2] = Field(default_factory=list)
    election_records: List[ElectionRecord] = Field(default_factory=list)
    trace: List[TraceLine] = Field(default_factory=list)

    # Carryforwards
    carryforwards_opening: List[CarryforwardBalanceV2] = Field(default_factory=list)
    carryforward_movements: List[CarryforwardMovementV2] = Field(default_factory=list)
    carryforwards_closing: List[CarryforwardBalanceV2] = Field(default_factory=list)


class CalculationResponseV2(BaseModel):
    schema_version: Literal["2.0", "2.1"] = "2.0"
    ruleset_version: str

    fiscal_year: FiscalYearV2
    minimum_rate: float

    reporting_currency: Optional[str] = Field(
        default=None,
        description="Echo of group_profile.reporting_currency if provided; results are expressed in this currency when FX translation is applied.",
    )

    results: List[TestedJurisdictionResultV2]
