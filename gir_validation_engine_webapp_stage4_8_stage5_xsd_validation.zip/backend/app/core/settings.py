from __future__ import annotations

from typing import Optional

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings.

    Notes:
    - Render provides Postgres URLs like: postgresql://... (or postgres://...)
      whereas SQLAlchemy with psycopg expects: postgresql+psycopg://...
      We normalize automatically.
    - For local Docker, CONFIG_ROOT defaults to /app/config.
    """

    model_config = SettingsConfigDict(env_file=None, extra="ignore")

    database_url: str = Field(..., alias="DATABASE_URL")
    config_root: str = Field("/app/config", alias="CONFIG_ROOT")

    # Optional API key (if set, enforced via X-API-Key header).
    api_key: Optional[str] = Field(default=None, alias="GIR_API_KEY")

    # CORS allowlist for browser-based front ends (Anything.com, etc.).
    # Use "*" for MVP; for production provide a comma-separated list.
    cors_allow_origins: str = Field(default="*", alias="CORS_ALLOW_ORIGINS")

    # Attribute-path requiredness (Stage 4.5)
    #
    # The XML importer can emit attribute datapoints with xml_path like:
    #   /.../TIN/@issuedBy
    # Some OECD/XSD-derived configs may also include attributes as required leaf nodes.
    #
    # Modes:
    #   - off  : never enforce requiredness for attribute xpaths
    #   - auto : enforce only when the latest Submission source_type is "xml"
    #   - on   : always enforce (even for xlsx/csv submissions)
    attribute_requiredness_mode: str = Field(
        default="auto",
        alias="ATTRIBUTE_REQUIREDNESS_MODE",
        description="Controls whether requiredness checks include attribute xpaths (/@...). Values: off|auto|on",
    )

    # GIR XSD validation (Stage 5 / OECD 50007)
    #
    # When enabled, the importer validates uploaded GIR XML files against the OECD GIR XML Schema (XSD bundle).
    # This is the most comprehensive way to catch schema-level issues (including required attributes such as currCode)
    # and maps failures to OECD file error code 50007 in the validation results.
    #
    # Modes:
    #   - off : do not run XSD validation unless the request explicitly sets strict_xsd=true
    #   - on  : always run XSD validation for XML imports
    xsd_validation_mode: str = Field(
        default="off",
        alias="XSD_VALIDATION_MODE",
        description="Controls default XSD validation on XML import. Values: off|on",
    )

    # Path to the OECD GIR XSD bundle (ZIP) or extracted directory.
    # Recommended repo path: oecd_schemas/oecd_gir_xml_schema.zip
    gir_xsd_zip_path: str = Field(
        default="oecd_schemas/oecd_gir_xml_schema.zip",
        alias="GIR_XSD_ZIP_PATH",
        description="Path to the OECD GIR XSD ZIP bundle used for schema validation",
    )
    gir_xsd_dir: Optional[str] = Field(
        default=None,
        alias="GIR_XSD_DIR",
        description="Optional path to an extracted folder of .xsd files (overrides GIR_XSD_ZIP_PATH)",
    )
    gir_xsd_main: Optional[str] = Field(
        default=None,
        alias="GIR_XSD_MAIN",
        description="Optional main XSD filename/path within the bundle (if auto-detection fails)",
    )

    @field_validator("attribute_requiredness_mode", mode="before")
    @classmethod
    def normalize_attribute_requiredness_mode(cls, v):
        if not isinstance(v, str):
            return "auto"
        vv = v.strip().lower()
        if vv not in {"off", "auto", "on"}:
            return "auto"
        return vv

    @field_validator("xsd_validation_mode", mode="before")
    @classmethod
    def normalize_xsd_validation_mode(cls, v):
        if not isinstance(v, str):
            return "off"
        vv = v.strip().lower()
        if vv not in {"off", "on"}:
            return "off"
        return vv

    @field_validator("database_url", mode="before")
    @classmethod
    def normalize_database_url(cls, v):
        if not isinstance(v, str):
            return v
        if v.startswith("postgresql://"):
            return v.replace("postgresql://", "postgresql+psycopg://", 1)
        if v.startswith("postgres://"):
            return v.replace("postgres://", "postgresql+psycopg://", 1)
        return v


settings = Settings()
