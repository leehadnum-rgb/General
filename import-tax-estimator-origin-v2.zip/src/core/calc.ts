import Decimal from "decimal.js";
import { Expr, Money, Value } from "./ast";
import { evalExpr } from "./evaluator";

export type Measure = {
  measureId: string;
  measureType: "CUSTOMS_DUTY" | "EXCISE" | "FEE";
  /**
   * MFN: default duty for most origins (a.k.a. “third country duty” in some systems)
   * PREFERENTIAL: an alternative rate for a specific origin country/group
   * ALL: always applies regardless of origin (e.g., certain fees)
   */
  originScope: "MFN" | "PREFERENTIAL" | "ALL";
  /**
   * Typically:
   * - "ALL" for MFN measures that apply to all origins
   * - ISO alpha-2 country code for country-specific preferential measures (e.g., "JP")
   * - A 4-digit geographical area group id in some tariff systems (best-effort in this MVP)
   */
  originCode: string;
  /** Optional list of excluded origin codes (ISO alpha-2), if known. */
  excludedOriginCodes?: string[] | null;
  expression: { expressionId: string; ast: Expr };
};

export type VatRule = { ratePct: number; label: string } | null;
export type VatBaseFormula = { ast: Expr } | null;

export type CalcInput = {
  jurisdictionId: string;
  currency: string;
  code: string;
  asOfDate: string;

  /** ISO alpha-2 country of origin, e.g., "CN" */
  originCountry?: string;

  customsValue: Money;
  freightToBorder?: Money;
  insuranceToBorder?: Money;

  quantity?: { amount: string; unit: string };
  netMassKg?: string;
  grossMassKg?: string;
  volumeLitre?: string;
};

export type CalcOutput = {
  missingInputs: string[];
  assumptions: { code: string; message: string }[];
  warnings: { code: string; message: string }[];
  charges: any[];
  totalTax: Money | null;
  trace: any;
};

function normalizeOrigin(origin?: string | null): string | null {
  const s = (origin ?? "").trim().toUpperCase();
  return s.length ? s : null;
}

function isExcludedByOrigin(m: Measure, origin: string): boolean {
  const list = m.excludedOriginCodes ?? [];
  return list.map((x) => String(x ?? "").trim().toUpperCase()).includes(origin);
}

function matchesExactOrigin(m: Measure, origin: string): boolean {
  if (isExcludedByOrigin(m, origin)) return false;
  return String(m.originCode ?? "").trim().toUpperCase() === origin;
}

type SelectionForType = {
  measureType: Measure["measureType"];
  origin: string | null;
  /** Measures that always apply regardless of origin (additive). */
  always: Measure[];
  /** Candidate measures for this origin (typically choose ONE for duty). */
  candidates: Measure[];
  applied: "PREFERENTIAL" | "MFN" | "ALL" | "NONE";
};

function selectCandidatesForOrigin(all: Measure[], origin: string | null) {
  const byType = new Map<Measure["measureType"], Measure[]>();
  for (const m of all) {
    const arr = byType.get(m.measureType) ?? [];
    arr.push(m);
    byType.set(m.measureType, arr);
  }

  const selectionMeta: Array<{
    measureType: Measure["measureType"];
    applied: "PREFERENTIAL" | "MFN" | "ALL" | "NONE";
    origin: string | null;
  }> = [];

  const selectionByType = new Map<Measure["measureType"], SelectionForType>();

  for (const [measureType, measures] of byType.entries()) {
    const always = measures.filter((m) => m.originScope === "ALL");
    const pref = measures.filter((m) => m.originScope === "PREFERENTIAL");
    const mfn = measures.filter((m) => m.originScope === "MFN");

    let candidates: Measure[] = [];
    let applied: "PREFERENTIAL" | "MFN" | "ALL" | "NONE" = "NONE";

    if (origin) {
      const prefMatches = pref.filter((m) => matchesExactOrigin(m, origin));
      if (prefMatches.length) {
        candidates = prefMatches;
        applied = "PREFERENTIAL";
      } else if (mfn.length) {
        candidates = mfn;
        applied = "MFN";
      } else if (always.length) {
        applied = "ALL";
      }
    } else {
      if (mfn.length) {
        candidates = mfn;
        applied = "MFN";
      } else if (always.length) {
        applied = "ALL";
      }
    }

    // stable ordering
    candidates = [...candidates];
    selectionByType.set(measureType, { measureType, origin, always: [...always], candidates, applied });
    selectionMeta.push({ measureType, applied, origin });
  }

  return { selectionByType, selectionMeta };
}

export function calculateEstimate(
  input: CalcInput,
  measures: Measure[],
  vatRule: VatRule,
  vatBase: VatBaseFormula
): CalcOutput {
  const missing = new Set<string>();
  const assumptions: { code: string; message: string }[] = [];
  const warnings: { code: string; message: string }[] = [
    {
      code: "SCOPE_LIMIT",
      message: "Trade remedy duties / special programs may not be included unless encoded in measures.",
    },
  ];

  const origin = normalizeOrigin(input.originCountry);

  const fields: Record<string, Value | undefined> = {
    customs_value: { kind: "money", money: input.customsValue },
    freight_to_border: input.freightToBorder
      ? { kind: "money", money: input.freightToBorder }
      : { kind: "money", money: { amount: "0", currency: input.currency } },
    insurance_to_border: input.insuranceToBorder
      ? { kind: "money", money: input.insuranceToBorder }
      : { kind: "money", money: { amount: "0", currency: input.currency } },

    quantity: input.quantity ? { kind: "number", value: input.quantity.amount } : undefined,
    net_mass_kg: input.netMassKg ? { kind: "number", value: input.netMassKg } : undefined,
    gross_mass_kg: input.grossMassKg ? { kind: "number", value: input.grossMassKg } : undefined,
    volume_litre: input.volumeLitre ? { kind: "number", value: input.volumeLitre } : undefined,
  };

  const steps: any[] = [];

  const { selectionByType, selectionMeta } = selectCandidatesForOrigin(measures, origin);
  const dutySel = selectionMeta.find((x) => x.measureType === "CUSTOMS_DUTY") ?? {
    measureType: "CUSTOMS_DUTY" as const,
    applied: "NONE" as const,
    origin,
  };

  if (!origin) {
    assumptions.push({ code: "ORIGIN", message: "No country of origin provided; MFN rates applied." });
  } else if (dutySel.applied === "PREFERENTIAL") {
    assumptions.push({ code: "ORIGIN", message: `Origin ${origin} provided; preferential duty applied where available.` });
  } else {
    assumptions.push({ code: "ORIGIN", message: `Origin ${origin} provided; MFN (non-preferential) duty applied.` });

    // If we have preferential measures that are likely country groups (e.g., "1034") we cannot map in this MVP.
    const hasGroupPreferential = measures.some(
      (m) => m.measureType === "CUSTOMS_DUTY" && m.originScope === "PREFERENTIAL" && /^[0-9]{4}$/.test(String(m.originCode ?? ""))
    );
    if (hasGroupPreferential) {
      warnings.push({
        code: "PREF_GROUP_UNSUPPORTED",
        message:
          "Preferential duties exist for origin country groups in the underlying tariff data. This MVP only matches preferences that specify the origin country directly (ISO alpha-2), so you may be eligible for a lower duty.",
      });
    }
  }

  // 1) Duty measures (origin-aware)
  let dutyTotal = new Decimal(0);
  const dutyComponents: any[] = [];

  const dutyGroup = selectionByType.get("CUSTOMS_DUTY");
  const dutyAlways = dutyGroup?.always ?? [];
  const dutyCandidates = dutyGroup?.candidates ?? [];

  // 1a) Always-applicable duty components (rare; mostly fees in other systems)
  for (const m of dutyAlways) {
    const res = evalExpr(m.expression.ast, { fields });
    steps.push({
      kind: "EVALUATE_MEASURE",
      measureId: m.measureId,
      expressionId: m.expression.expressionId,
      ok: res.ok,
      meta: res.meta,
      exprTrace: res.trace,
      originScope: m.originScope,
      originCode: m.originCode,
      selectionRole: "ALWAYS",
    });

    if (!res.ok) {
      res.meta.missingFields.forEach((f) => missing.add(f));
      continue;
    }
    if (res.value.kind !== "money") {
      missing.add(`unsupported_expression:${m.expression.expressionId}`);
      continue;
    }
    const amt = new Decimal(res.value.money.amount);
    dutyTotal = dutyTotal.add(amt);
    dutyComponents.push({
      measureId: m.measureId,
      expressionId: m.expression.expressionId,
      originScope: m.originScope,
      originCode: m.originCode,
      amount: res.value.money,
      selectionRole: "ALWAYS",
    });
  }

  // 1b) Choose ONE duty candidate (MFN or preferential) with the lowest computed amount.
  // This prevents double-counting when multiple preferential candidates match the origin.
  let bestCandidate: {
    measure: Measure;
    amount: Money;
    amtDec: Decimal;
  } | null = null;
  const candidateFailures: Array<{ missingFields: string[]; exprId: string }> = [];

  for (const m of dutyCandidates) {
    const res = evalExpr(m.expression.ast, { fields });
    steps.push({
      kind: "EVALUATE_MEASURE",
      measureId: m.measureId,
      expressionId: m.expression.expressionId,
      ok: res.ok,
      meta: res.meta,
      exprTrace: res.trace,
      originScope: m.originScope,
      originCode: m.originCode,
      selectionRole: "CANDIDATE",
    });

    if (!res.ok) {
      candidateFailures.push({ missingFields: [...res.meta.missingFields], exprId: m.expression.expressionId });
      continue;
    }
    if (res.value.kind !== "money") {
      candidateFailures.push({ missingFields: [`unsupported_expression:${m.expression.expressionId}`], exprId: m.expression.expressionId });
      continue;
    }

    const amtDec = new Decimal(res.value.money.amount);
    if (!bestCandidate || amtDec.lessThan(bestCandidate.amtDec)) {
      bestCandidate = { measure: m, amount: res.value.money, amtDec };
    }
  }

  if (bestCandidate) {
    dutyTotal = dutyTotal.add(bestCandidate.amtDec);
    dutyComponents.push({
      measureId: bestCandidate.measure.measureId,
      expressionId: bestCandidate.measure.expression.expressionId,
      originScope: bestCandidate.measure.originScope,
      originCode: bestCandidate.measure.originCode,
      amount: bestCandidate.amount,
      selectionRole: "CHOSEN",
    });
  } else if (dutyCandidates.length) {
    // Only require fields if *no* candidate could be evaluated.
    for (const f of candidateFailures.flatMap((x) => x.missingFields)) missing.add(f);
  }

  fields["customs_duty_total"] = { kind: "money", money: { amount: dutyTotal.toFixed(), currency: input.currency } };
  fields["fees_total"] = { kind: "money", money: { amount: "0", currency: input.currency } }; // MVP

  const charges: any[] = [
    {
      type: "CUSTOMS_DUTY",
      label: "Customs duty",
      amount: { amount: dutyTotal.toFixed(), currency: input.currency },
      components: dutyComponents,
      originApplied: { originCountry: origin, mode: dutySel.applied },
    },
  ];

  // 2) VAT/GST (if configured)
  let vatAmount = new Decimal(0);
  let vatBaseMoney: Money | null = null;

  if (vatRule && vatBase) {
    assumptions.push({ code: "VAT_RATE", message: "Standard VAT/GST rate applied." });

    const vatBaseRes = evalExpr(vatBase.ast, { fields });
    steps.push({
      kind: "EVALUATE_VAT_BASE",
      ok: vatBaseRes.ok,
      meta: vatBaseRes.meta,
      exprTrace: vatBaseRes.trace,
    });

    if (!vatBaseRes.ok) {
      vatBaseRes.meta.missingFields.forEach((f) => missing.add(f));
    } else if (vatBaseRes.value.kind === "money") {
      vatBaseMoney = vatBaseRes.value.money;
      vatAmount = new Decimal(vatBaseMoney.amount).mul(new Decimal(vatRule.ratePct)).div(100);
    } else {
      missing.add("vat_base_not_money");
    }

    charges.push({
      type: "VAT",
      label: vatRule.label,
      ratePct: vatRule.ratePct,
      base: vatBaseMoney,
      amount: { amount: vatAmount.toFixed(), currency: input.currency },
    });
  }

  const totalTax = missing.size === 0 ? dutyTotal.add(vatAmount) : null;

  return {
    missingInputs: [...missing],
    assumptions,
    warnings,
    charges,
    totalTax: totalTax ? { amount: totalTax.toFixed(), currency: input.currency } : null,
    trace: {
      meta: {
        jurisdictionId: input.jurisdictionId,
        asOfDate: input.asOfDate,
        originCountry: origin,
      },
      selection: selectionMeta,
      steps,
    },
  };
}
