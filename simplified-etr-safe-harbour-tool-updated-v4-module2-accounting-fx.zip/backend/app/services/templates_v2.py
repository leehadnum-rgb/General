from __future__ import annotations

from datetime import date
from typing import Optional

from app.services.models_v2 import (
    TestedJurisdictionInputV2,
    TestedJurisdictionCompositionV2,
    JurisdictionFactsV2,
    EntityFactsV2,
    AccountingBasisV2,
)


def generate_tested_jurisdiction_template(
    *,
    tested_jurisdiction_id: str,
    jurisdiction_code: Optional[str] = None,
    tested_jurisdiction_type: Optional[str] = None,
    aggregation_method: str = "JURISDICTION_FACTS",
    label: Optional[str] = None,
    fiscal_year_start: Optional[date] = None,
    include_placeholder_entity: bool = True,
) -> TestedJurisdictionInputV2:
    """Generate a skeleton Tested Jurisdiction input object.

    This is designed for UI builders (e.g., Anything.com) to create a correctly-shaped JSON
    object aligned with the API schema.

    Notes:
    - v2 uses tested_jurisdiction_id as the internal grouping key (bucket id).
    - For JURISDICTION_FACTS, facts.jpbt is required by the schema, so we set it to 0.0.
    - For ENTITY_ROLLUP, at least one entity is required by the schema; we include a placeholder
      entity unless include_placeholder_entity=False.
    """

    agg = aggregation_method
    comp = TestedJurisdictionCompositionV2(aggregation_method=agg)

    if label is None:
        if jurisdiction_code:
            label = f"{jurisdiction_code} – {tested_jurisdiction_id}"
        else:
            label = tested_jurisdiction_id

    if agg == "JURISDICTION_FACTS":
        facts = JurisdictionFactsV2(
            jurisdiction_code=jurisdiction_code,
            jpbt=0.0,
            current_tax_expense=0.0,
            deferred_tax_expense=0.0,
        )
        return TestedJurisdictionInputV2(
            tested_jurisdiction_id=tested_jurisdiction_id,
            jurisdiction_code=jurisdiction_code,
            label=label,
            tested_jurisdiction_type=tested_jurisdiction_type,
            accounting_basis=AccountingBasisV2(
                currency=None,
                amount_scale="UNITS",
            ),
            composition=comp,
            facts=facts,
            entities=[],
        )

    if agg == "ENTITY_ROLLUP":
        entities = []
        if include_placeholder_entity:
            entities = [
                EntityFactsV2(
                    entity_id=f"{tested_jurisdiction_id}-E1",
                    entity_name="Entity 1",
                    jurisdiction_code=jurisdiction_code,
                    jpbt=0.0,
                    current_tax_expense=0.0,
                    deferred_tax_expense=0.0,
                )
            ]
        return TestedJurisdictionInputV2(
            tested_jurisdiction_id=tested_jurisdiction_id,
            jurisdiction_code=jurisdiction_code,
            label=label,
            tested_jurisdiction_type=tested_jurisdiction_type,
            accounting_basis=AccountingBasisV2(
                currency=None,
                amount_scale="UNITS",
            ),
            composition=comp,
            facts=None,
            entities=entities,
        )

    # MIXED: include both facts and (optionally) a placeholder entity
    facts = JurisdictionFactsV2(
        jurisdiction_code=jurisdiction_code,
        jpbt=0.0,
        current_tax_expense=0.0,
        deferred_tax_expense=0.0,
    )
    entities = []
    if include_placeholder_entity:
        entities = [
            EntityFactsV2(
                entity_id=f"{tested_jurisdiction_id}-E1",
                entity_name="Entity 1",
                jurisdiction_code=jurisdiction_code,
                jpbt=0.0,
                current_tax_expense=0.0,
                deferred_tax_expense=0.0,
            )
        ]

    return TestedJurisdictionInputV2(
        tested_jurisdiction_id=tested_jurisdiction_id,
        jurisdiction_code=jurisdiction_code,
        label=label,
        tested_jurisdiction_type=tested_jurisdiction_type,
        accounting_basis=AccountingBasisV2(
            currency=None,
            amount_scale="UNITS",
        ),
        composition=comp,
        facts=facts,
        entities=entities,
    )
