from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Dict

from app.services.models import CalculationRequest as CalculationRequestV1
from app.services.models import JurisdictionInput as JurisdictionInputV1
from app.services.models import EntityInput as EntityInputV1
from app.services.models import TraceLine

from app.services.calculator import calculate as calculate_v1
from app.services.election_catalog import ELECTIONS_BY_CODE
from app.services.elections_v2 import (
    resolve_effective_elections,
    apply_effective_elections_to_meta,
    get_effective_election_amount,
    get_effective_election_bool,
)
from app.services.models_v2 import (
    CalculationRequestV2,
    CalculationResponseV2,
    TestedJurisdictionResultV2,
    CarryforwardBalanceV2,
    CarryforwardMovementV2,
    TestedJurisdictionInputV2,
    CrossBorderTaxItemV2,
)


@dataclass
class _TJWork:
    tj: TestedJurisdictionInputV2
    bucket_id: str
    effective_elections: list
    eligible: bool
    ineligibility_reasons: list[str]
    election_records: list
    trace: list[TraceLine]
    simplified_income: float
    simplified_taxes: float
    opening_balances: list[CarryforwardBalanceV2]


def _build_meta_row(tj: TestedJurisdictionInputV2, bucket_id: str, fy_start: date) -> tuple[JurisdictionInputV1, list, list[TraceLine]]:
    """Build a v1 JurisdictionInput row used as calculation row (jurisdiction mode)
    or as 'meta' row (entity roll-up mode)."""

    if tj.facts is not None:
        data = tj.facts.model_dump()
        # v2 uses tested_jurisdiction_id as the internal key (bucket)
        data["jurisdiction_code"] = bucket_id
        meta = JurisdictionInputV1(**data)
    else:
        # For entity roll-up, a minimal meta row is still useful to carry elections and eligibility flags.
        meta = JurisdictionInputV1(jurisdiction_code=bucket_id, jpbt=0.0)

    # Eligibility flags from v2
    ei = tj.eligibility_inputs
    meta.ineligible_stateless = bool(ei.ineligible_stateless)
    meta.ineligible_investment_entity = bool(ei.ineligible_investment_entity)
    meta.ineligible_article7_3_outstanding_recapture = bool(ei.ineligible_article7_3_outstanding_recapture)
    meta.stateless_exception_section_6_2_applies = bool(ei.stateless_exception_section_6_2_applies)
    meta.investment_entity_tax_transparency_election_applies = bool(ei.investment_entity_tax_transparency_election_applies)
    meta.no_topup_tax_in_prior_24_months = bool(ei.no_topup_tax_in_prior_24_months)
    meta.reentry_no_topup_tax_in_prior_24_months = ei.reentry_no_topup_tax_in_prior_24_months
    meta.integrity_rules_satisfied = bool(ei.integrity_rules_satisfied)

    # Resolve and apply elections for this FY
    effective = resolve_effective_elections(tj.elections, fy_start)
    meta, election_trace = apply_effective_elections_to_meta(meta, effective)

    return meta, effective, election_trace


def _build_entities(tj: TestedJurisdictionInputV2, bucket_id: str) -> list[EntityInputV1]:
    ents: list[EntityInputV1] = []
    for e in tj.entities:
        data = e.model_dump()
        # Override group key
        data["jurisdiction_code"] = bucket_id
        ents.append(EntityInputV1(**data))
    return ents


def _normalise_balances(opening: list[CarryforwardBalanceV2]) -> list[CarryforwardBalanceV2]:
    # Ensure positive amounts and defaults are applied (Pydantic validator already does this).
    out: list[CarryforwardBalanceV2] = []
    for b in opening:
        out.append(b.model_copy())
    return out


def _apply_carryforwards(
    *,
    fy_start: date,
    minimum_rate: float,
    simplified_income: float,
    simplified_taxes: float,
    opening: list[CarryforwardBalanceV2],
    effective_elections: list,
    trace: list[TraceLine],
) -> tuple[float, list[CarryforwardBalanceV2], list[CarryforwardMovementV2]]:
    """Apply carryforwards to Simplified Taxes (OECD Box 4.3 and Article 4.1.5 symmetry).

    Implementation notes (pragmatic):
    - Carryforward balances are entered as POSITIVE amounts representing a reduction to Simplified Taxes.
    - Utilisation is only applied in years with positive Simplified Income and positive Simplified Taxes,
      consistent with typical utilisation mechanics for Excess Negative Tax carry-forwards.
    - Tax is not reduced below zero.
    - Loss DTA Adjustment utilisation can optionally be capped by LOSS_DTA_REVERSAL_TENTATIVE_AMOUNT.
    """

    taxes = float(simplified_taxes)
    balances = _normalise_balances(opening)
    moves: list[CarryforwardMovementV2] = []

    if simplified_income <= 0 or taxes <= 0:
        return taxes, balances, moves

    # Optional cap for Loss DTA Adjustment utilisation
    loss_dta_reversal_cap = get_effective_election_amount(effective_elections, "LOSS_DTA_REVERSAL_TENTATIVE_AMOUNT")
    if loss_dta_reversal_cap is not None:
        loss_dta_reversal_cap = max(0.0, float(loss_dta_reversal_cap))

    def use_balance(kind: str, cap_amount: float | None = None, note: str | None = None):
        nonlocal taxes, balances, moves, loss_dta_reversal_cap

        for b in balances:
            if b.kind != kind:
                continue
            if taxes <= 0:
                break
            if (b.remaining_amount or 0.0) <= 0:
                continue

            cap = taxes
            if cap_amount is not None:
                cap = min(cap, cap_amount)
            used = min(float(b.remaining_amount or 0.0), cap)

            if used <= 0:
                continue

            taxes = max(0.0, taxes - used)
            b.remaining_amount = max(0.0, float(b.remaining_amount or 0.0) - used)

            if kind == "LOSS_DTA_ADJUSTMENT" and loss_dta_reversal_cap is not None:
                loss_dta_reversal_cap = max(0.0, loss_dta_reversal_cap - used)

            moves.append(
                CarryforwardMovementV2(
                    kind=kind, used_amount=float(used), remaining_amount=float(b.remaining_amount or 0.0), note=note
                )
            )
            trace.append(
                TraceLine(
                    section="tax",
                    step=f"Carryforward utilised: {kind}",
                    amount=-float(used),
                    running_total=taxes,
                    note=note,
                )
            )

    # Order (pragmatic):
    #   1) Loss DTA Adjustment (alternative method; can be capped)
    #   2) Simplified negative tax adjustment (Box 4.3)
    #   3) Excess negative tax carry-forward (GloBE Article 4.1.5)
    if loss_dta_reversal_cap is not None and loss_dta_reversal_cap > 0:
        use_balance(
            "LOSS_DTA_ADJUSTMENT",
            cap_amount=loss_dta_reversal_cap,
            note="Capped by LOSS_DTA_REVERSAL_TENTATIVE_AMOUNT; taxes not reduced below zero.",
        )
    else:
        use_balance(
            "LOSS_DTA_ADJUSTMENT",
            cap_amount=None,
            note="No loss DTA reversal cap provided; taxes not reduced below zero.",
        )

    use_balance(
        "SIMPLIFIED_NEGATIVE_TAX_ADJUSTMENT",
        cap_amount=None,
        note="Applied as a reduction to Simplified Taxes; taxes not reduced below zero.",
    )
    use_balance(
        "EXCESS_NEGATIVE_TAX_CARRYFORWARD",
        cap_amount=None,
        note="Applied as a reduction to Simplified Taxes; taxes not reduced below zero.",
    )

    return taxes, balances, moves
def _apply_owner_addbacks(work: _TJWork) -> None:
    """Apply structured owner addbacks (Articles 7.5/7.6).

    These are treated as signed adjustments to Simplified Income or Simplified Taxes.
    """

    for a in (work.tj.owner_addbacks or []):
        if a.kind == "income":
            work.simplified_income += float(a.amount)
            work.trace.append(
                TraceLine(
                    section="income",
                    step=f"Investment entity owner addback (Art {a.article})",
                    amount=float(a.amount),
                    running_total=float(work.simplified_income),
                    note=a.label + (f" | {a.note}" if a.note else ""),
                )
            )
        else:
            work.simplified_taxes += float(a.amount)
            work.trace.append(
                TraceLine(
                    section="tax",
                    step=f"Investment entity owner addback (Art {a.article})",
                    amount=float(a.amount),
                    running_total=float(work.simplified_taxes),
                    note=a.label + (f" | {a.note}" if a.note else ""),
                )
            )


def _apply_cross_border_tax_items(
    works: Dict[str, _TJWork],
    items: list[CrossBorderTaxItemV2],
    fy_start: date,
) -> None:
    """Apply cross-border tax item exclusion/allocation adjustments.

    The adjustments are applied after base Simplified Taxes have been computed, but before
    carryforwards, so they affect Simplified ETR.
    """

    if not items:
        return

    # Helper: check deemed-zero conflicts
    deemed_zero_ids = {k for k, w in works.items() if w.tj.deemed_zero_rules.apply_deemed_zero}

    for item in items:
        src = item.source_tested_jurisdiction_id
        tgt = item.target_tested_jurisdiction_id

        # Validate IDs
        if src and src not in works:
            raise ValueError(f"Cross-border tax item '{item.label or item.item_id or ''}': source_tested_jurisdiction_id '{src}' not found.")
        if tgt and tgt not in works:
            raise ValueError(f"Cross-border tax item '{item.label or item.item_id or ''}': target_tested_jurisdiction_id '{tgt}' not found.")

        if src in deemed_zero_ids or tgt in deemed_zero_ids:
            raise ValueError(
                "Cross-border tax items cannot reference a Tested Jurisdiction where deemed-zero is applied. "
                f"(item={item.label or item.item_id or 'unnamed'}, source={src}, target={tgt})"
            )

        amount = float(item.amount)

        # Infer default treatment if not provided
        treatment = item.treatment
        if not treatment:
            if tgt:
                treatment = "ALLOCATE"
            else:
                keep = False
                if src:
                    keep = bool(get_effective_election_bool(works[src].effective_elections, "CROSS_BORDER_FIVE_YEAR_ELECTION_KEEP_ALLOCABLE_TAXES") or False)
                treatment = "KEEP_IN_SOURCE" if keep else "EXCLUDE_FROM_ALL"

        # PE election enforcement (if requested)
        if getattr(item, "requires_pe_simplification_election", False):
            pe_ok = False
            if src and bool(get_effective_election_bool(works[src].effective_elections, "PE_SIMPLIFICATION_ELECTION_NOTE") or False):
                pe_ok = True
            if tgt and bool(get_effective_election_bool(works[tgt].effective_elections, "PE_SIMPLIFICATION_ELECTION_NOTE") or False):
                pe_ok = True
            if not pe_ok:
                raise ValueError(
                    "Cross-border tax item requires PE simplification election, but PE_SIMPLIFICATION_ELECTION_NOTE is not effective "
                    f"for source/target Tested Jurisdiction(s). (item={item.label or item.item_id or 'unnamed'})"
                )

        label = item.label or item.item_id or "Cross-border tax item"
        note = item.note

        if treatment == "KEEP_IN_SOURCE":
            if src:
                works[src].trace.append(
                    TraceLine(
                        section="tax",
                        step="Cross-border tax item kept in source",
                        amount=0.0,
                        running_total=float(works[src].simplified_taxes),
                        note=f"{label}" + (f" | {note}" if note else ""),
                    )
                )
            continue

        if treatment == "EXCLUDE_FROM_ALL":
            if not src:
                # nothing to exclude if no source provided
                continue
            w = works[src]
            w.simplified_taxes -= amount
            w.trace.append(
                TraceLine(
                    section="tax",
                    step="Cross-border tax excluded (allocable tax removed)",
                    amount=-amount,
                    running_total=float(w.simplified_taxes),
                    note=f"{label}" + (f" | {note}" if note else ""),
                )
            )
            continue

        if treatment == "ALLOCATE":
            if tgt is None:
                raise ValueError(f"Cross-border tax item '{label}': treatment='ALLOCATE' requires target_tested_jurisdiction_id.")

            if src:
                ws = works[src]
                ws.simplified_taxes -= amount
                ws.trace.append(
                    TraceLine(
                        section="tax",
                        step="Cross-border tax allocated out of source",
                        amount=-amount,
                        running_total=float(ws.simplified_taxes),
                        note=f"{label} -> {tgt}" + (f" | {note}" if note else ""),
                    )
                )

            wt = works[tgt]
            wt.simplified_taxes += amount
            wt.trace.append(
                TraceLine(
                    section="tax",
                    step="Cross-border tax allocated into target",
                    amount=amount,
                    running_total=float(wt.simplified_taxes),
                    note=f"{label} (from {src or 'external'})" + (f" | {note}" if note else ""),
                )
            )
            continue

        raise ValueError(f"Cross-border tax item '{label}': unknown treatment '{treatment}'.")


def calculate_v2(req: CalculationRequestV2) -> CalculationResponseV2:
    fy_start = req.fiscal_year.start_date

    # -----------------------------
    # First pass: compute base numbers per Tested Jurisdiction (pre cross-border / owner addbacks)
    # -----------------------------
    works: Dict[str, _TJWork] = {}
    for tj in req.tested_jurisdictions:
        bucket_id = tj.tested_jurisdiction_id

        # Determine input mode
        m = tj.composition.aggregation_method
        if m == "JURISDICTION_FACTS":
            input_mode = "jurisdiction"
        elif m == "ENTITY_ROLLUP":
            input_mode = "entity_rollup"
        else:
            # MIXED: if entities exist, roll-up; else jurisdiction facts
            input_mode = "entity_rollup" if tj.entities else "jurisdiction"

        meta, effective_elections, election_trace = _build_meta_row(tj, bucket_id, fy_start)
        entities = _build_entities(tj, bucket_id) if input_mode == "entity_rollup" else []

        req_v1 = CalculationRequestV1(
            fiscal_year_start_date=fy_start,
            minimum_rate=req.minimum_rate,
            input_mode=input_mode,
            apply_optional_2025_start_rule=req.applicability.apply_optional_2025_start_rule,
            early_start_qdmtt_safe_harbour_applies=req.applicability.early_start_qdmtt_safe_harbour_applies,
            early_start_only_one_jurisdiction_has_taxing_rights=req.applicability.early_start_only_one_jurisdiction_has_taxing_rights,
            early_start_all_taxing_rights_jurisdictions_allow=req.applicability.early_start_all_taxing_rights_jurisdictions_allow,
            jurisdictions=[meta],
            entities=entities,
        )

        base_resp = calculate_v1(req_v1)
        base_r = base_resp.results[0]

        trace: list[TraceLine] = list(base_r.trace) + list(election_trace)
        opening_balances = _normalise_balances(tj.carryforwards_opening)

        works[bucket_id] = _TJWork(
            tj=tj,
            bucket_id=bucket_id,
            effective_elections=effective_elections,
            eligible=bool(base_r.eligible),
            ineligibility_reasons=list(base_r.ineligibility_reasons),
            election_records=list(base_r.election_records),
            trace=trace,
            simplified_income=float(base_r.simplified_income),
            simplified_taxes=float(base_r.simplified_taxes),
            opening_balances=opening_balances,
        )

    # -----------------------------
    # Apply structured adjustments that can affect multiple TJs
    # -----------------------------
    for w in works.values():
        _apply_owner_addbacks(w)

    _apply_cross_border_tax_items(works, list(req.cross_border_tax_items or []), fy_start)

    # -----------------------------
    # Final pass: carryforwards + deemed-zero + compute outcomes
    # -----------------------------
    results: list[TestedJurisdictionResultV2] = []

    # Preserve request ordering
    for tj in req.tested_jurisdictions:
        bucket_id = tj.tested_jurisdiction_id
        w = works[bucket_id]

        trace = w.trace

        # Deemed-zero override (only if eligible)
        if tj.deemed_zero_rules.apply_deemed_zero:
            trace.append(
                TraceLine(
                    section="eligibility",
                    step="Deemed-zero rule applied",
                    amount=0.0,
                    note=tj.deemed_zero_rules.rationale or "Simplified Income and Simplified Taxes treated as zero.",
                )
            )
            if w.eligible:
                results.append(
                    TestedJurisdictionResultV2(
                        tested_jurisdiction_id=bucket_id,
                        jurisdiction_code=tj.jurisdiction_code,
                        label=tj.label,
                        eligible=True,
                        ineligibility_reasons=[],
                        simplified_income=0.0,
                        simplified_taxes=0.0,
                        simplified_etr=None,
                        simplified_loss=0.0,
                        safe_harbour_applies=True,
                        safe_harbour_reason="PASS: deemed-zero rule applies.",
                        simplified_adjustment_for_negative_taxes=0.0,
                        effective_elections=w.effective_elections,
                        election_records=list(w.election_records),
                        trace=trace,
                        carryforwards_opening=w.opening_balances,
                        carryforward_movements=[],
                        carryforwards_closing=w.opening_balances,
                    )
                )
                continue
            # If not eligible, fall through with normal numbers but explain.
            trace.append(
                TraceLine(
                    section="eligibility",
                    step="Deemed-zero requested but eligibility failed",
                    amount=0.0,
                    note="Safe harbour is not available where eligibility restrictions are not met.",
                )
            )

        # Apply carryforwards to taxes (after cross-border / addbacks)
        taxes_after_cf, balances_after, movements = _apply_carryforwards(
            fy_start=fy_start,
            minimum_rate=req.minimum_rate,
            simplified_income=w.simplified_income,
            simplified_taxes=w.simplified_taxes,
            opening=w.opening_balances,
            effective_elections=w.effective_elections,
            trace=trace,
        )

        simplified_income = float(w.simplified_income)
        simplified_taxes = float(taxes_after_cf)

        simplified_loss = 0.0
        simplified_etr = None
        if simplified_income <= 0:
            simplified_loss = max(0.0, -simplified_income)
        else:
            simplified_etr = simplified_taxes / simplified_income if simplified_income != 0 else None

        # Loss-year negative-tax adjustment / Loss DTA method
        simplified_adjustment_for_negative_taxes = 0.0
        closing_additions: list[CarryforwardBalanceV2] = []

        loss_dta_method = bool(get_effective_election_bool(w.effective_elections, "LOSS_DTA_ADJUSTMENT_METHOD_ELECTED") or False)
        loss_dta_generated = get_effective_election_amount(w.effective_elections, "LOSS_DTA_ADJUSTMENT_GENERATED_AMOUNT")
        if loss_dta_generated is not None:
            loss_dta_generated = float(loss_dta_generated)

        if loss_dta_method and loss_dta_generated and loss_dta_generated > 0 and simplified_loss > 0:
            closing_additions.append(
                CarryforwardBalanceV2(
                    kind="LOSS_DTA_ADJUSTMENT",
                    origin_fiscal_year_start=fy_start,
                    amount=abs(loss_dta_generated),
                    remaining_amount=abs(loss_dta_generated),
                    note="Generated under Loss DTA Adjustment methodology (input amount).",
                )
            )
            trace.append(
                TraceLine(
                    section="tax",
                    step="Loss-year: Loss DTA Adjustment generated (carryforward)",
                    amount=0.0,
                    note=f"Amount created = {abs(loss_dta_generated):.2f}",
                )
            )
        else:
            if simplified_loss > 0 and simplified_taxes < 0:
                simplified_adjustment_for_negative_taxes = simplified_taxes - (simplified_loss * req.minimum_rate)
                cf_amt = abs(simplified_adjustment_for_negative_taxes)
                if cf_amt > 0:
                    closing_additions.append(
                        CarryforwardBalanceV2(
                            kind="SIMPLIFIED_NEGATIVE_TAX_ADJUSTMENT",
                            origin_fiscal_year_start=fy_start,
                            amount=cf_amt,
                            remaining_amount=cf_amt,
                            note="Computed as abs(Simplified Taxes – (Simplified Loss * Minimum Rate)).",
                        )
                    )
                    trace.append(
                        TraceLine(
                            section="tax",
                            step="Loss-year: Simplified Adjustment for Negative Taxes computed (carryforward)",
                            amount=simplified_adjustment_for_negative_taxes,
                            note="Computed as Simplified Taxes – (Simplified Loss * Minimum Rate). Stored as a positive carryforward amount.",
                        )
                    )

        # Safe harbour outcome (recomputed after adjustments)
        if simplified_income <= 0:
            safe_harbour_pass = True
            reason = "PASS: Simplified Loss (or non-positive Simplified Income)."
        else:
            safe_harbour_pass = (simplified_etr is not None) and simplified_etr >= req.minimum_rate
            reason = (
                "PASS: Simplified ETR >= Minimum Rate."
                if safe_harbour_pass
                else "FAIL: Simplified ETR < Minimum Rate and no Simplified Loss."
            )

        if not w.eligible:
            safe_harbour_pass = False
            reason = "NOT AVAILABLE: jurisdiction fails eligibility criteria (see reasons)."

        closing = [b for b in balances_after if (b.remaining_amount or 0.0) > 0] + closing_additions

        results.append(
            TestedJurisdictionResultV2(
                tested_jurisdiction_id=bucket_id,
                jurisdiction_code=tj.jurisdiction_code,
                label=tj.label,
                eligible=w.eligible,
                ineligibility_reasons=list(w.ineligibility_reasons),
                simplified_income=simplified_income,
                simplified_taxes=simplified_taxes,
                simplified_etr=simplified_etr,
                simplified_loss=simplified_loss,
                safe_harbour_applies=safe_harbour_pass,
                safe_harbour_reason=reason,
                simplified_adjustment_for_negative_taxes=float(simplified_adjustment_for_negative_taxes),
                effective_elections=w.effective_elections,
                election_records=list(w.election_records),
                trace=trace,
                carryforwards_opening=w.opening_balances,
                carryforward_movements=movements,
                carryforwards_closing=closing,
            )
        )

    return CalculationResponseV2(
        ruleset_version=req.ruleset_version,
        fiscal_year=req.fiscal_year,
        minimum_rate=req.minimum_rate,
        results=results,
    )
