
from __future__ import annotations

import csv
import io
import re
from typing import Dict, List, Optional

from pydantic import BaseModel, Field

from app.services.models_v2 import IntegrityAdjustmentV2

_NUM_RE = re.compile(r"[^0-9eE+\-\.]")

def _norm_header(h: str) -> str:
    h = (h or "").strip().lower()
    h = re.sub(r"[\s\-]+", "_", h)
    return h

_ALIASES: Dict[str, str] = {
    "tj_id": "tested_jurisdiction_id",
    "tested_jurisdiction": "tested_jurisdiction_id",
    "id": "adjustment_id",
    "integrity_adjustment_id": "adjustment_id",
    "issue_code": "resolves_issue_code",
    "resolves": "resolves_issue_code",
    "ref": "evidence_ref",
    "evidence": "evidence_ref",
}

def _parse_float(raw: Optional[str]) -> Optional[float]:
    if raw is None:
        return None
    s = str(raw).strip()
    if s == "":
        return None
    s2 = _NUM_RE.sub("", s)
    if s2 in {"", "+", "-"}:
        return None
    try:
        return float(s2)
    except ValueError:
        return None

class IntegrityAdjustmentsCsvIssue(BaseModel):
    severity: str = Field(..., description="'error' or 'warning'")
    row_number: int = Field(..., ge=1, description="1-indexed row number in the CSV (excluding header).")
    field: Optional[str] = None
    message: str

class IntegrityAdjustmentsCsvParseResult(BaseModel):
    integrity_adjustments: List[IntegrityAdjustmentV2] = Field(default_factory=list)
    issues: List[IntegrityAdjustmentsCsvIssue] = Field(default_factory=list)
    detected_columns: List[str] = Field(default_factory=list)
    ignored_columns: List[str] = Field(default_factory=list)

def generate_integrity_adjustments_csv_template() -> bytes:
    headers = [
        "tested_jurisdiction_id",
        "adjustment_id",
        "principle",
        "kind",
        "amount",
        "currency",
        "amount_scale",
        "resolves_issue_code",
        "evidence_ref",
        "note",
    ]

    example = {
        "tested_jurisdiction_id": "US_MAIN",
        "adjustment_id": "INT-1",
        "principle": "MATCHING",
        "kind": "tax",
        "amount": "100000",
        "currency": "USD",
        "amount_scale": "UNITS",
        "resolves_issue_code": "MATCHING_INCOME_ALLOCATED_TAX_NOT_ALLOCATED",
        "evidence_ref": "WP-7.3-001",
        "note": "Example only: add back tax to align with matching principle.",
    }

    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=headers)
    w.writeheader()
    w.writerow(example)
    return buf.getvalue().encode("utf-8")

def parse_integrity_adjustments_csv(contents: bytes) -> IntegrityAdjustmentsCsvParseResult:
    text = contents.decode("utf-8-sig", errors="replace")
    buf = io.StringIO(text)
    reader = csv.DictReader(buf)
    if reader.fieldnames is None:
        return IntegrityAdjustmentsCsvParseResult(
            integrity_adjustments=[],
            issues=[IntegrityAdjustmentsCsvIssue(severity="error", row_number=1, message="CSV is missing a header row.")],
        )

    raw_headers = list(reader.fieldnames)
    norm_to_raw: Dict[str, str] = {}
    for h in raw_headers:
        nh0 = _norm_header(h)
        nh = _ALIASES.get(nh0, nh0)
        if nh and nh not in norm_to_raw:
            norm_to_raw[nh] = h

    allowed = set(IntegrityAdjustmentV2.model_fields.keys())
    ignored = [raw for nh, raw in norm_to_raw.items() if nh not in allowed]

    out = IntegrityAdjustmentsCsvParseResult(detected_columns=raw_headers, ignored_columns=ignored)

    for i, row in enumerate(reader, start=1):
        data: Dict[str, object] = {}

        def raw(field: str) -> Optional[str]:
            rkey = norm_to_raw.get(field)
            return row.get(rkey) if rkey else None

        tj_id = (raw("tested_jurisdiction_id") or "").strip()
        if not tj_id:
            out.issues.append(IntegrityAdjustmentsCsvIssue(severity="error", row_number=i, field="tested_jurisdiction_id", message="Missing tested_jurisdiction_id."))
            continue

        kind = (raw("kind") or "").strip()
        if kind not in {"income", "tax"}:
            out.issues.append(IntegrityAdjustmentsCsvIssue(severity="error", row_number=i, field="kind", message="Invalid kind (expected 'income' or 'tax')."))
            continue

        amt = _parse_float(raw("amount"))
        if amt is None:
            out.issues.append(IntegrityAdjustmentsCsvIssue(severity="error", row_number=i, field="amount", message="Invalid or missing amount (expected number)."))
            continue

        data["tested_jurisdiction_id"] = tj_id
        data["kind"] = kind
        data["amount"] = float(amt)

        for fld in ["adjustment_id", "principle", "currency", "amount_scale", "resolves_issue_code", "evidence_ref", "note"]:
            v = raw(fld)
            if v is None:
                continue
            v2 = str(v).strip()
            if v2 == "":
                continue
            data[fld] = v2

        try:
            out.integrity_adjustments.append(IntegrityAdjustmentV2(**data))
        except Exception as e:
            out.issues.append(IntegrityAdjustmentsCsvIssue(severity="error", row_number=i, message=str(e)))

    return out
