from __future__ import annotations

from fastapi import APIRouter, File, UploadFile, HTTPException, Query
from fastapi.responses import FileResponse, StreamingResponse

from app.services.csv_io import generate_entities_csv_template, parse_entities_csv, EntitiesCsvParseResult
from app.services.fx_io import generate_fx_rates_csv_template, parse_fx_rates_csv, FxRatesCsvParseResult
from app.services.after_year_end_io import generate_after_year_end_adjustments_csv_template, parse_after_year_end_adjustments_csv, AfterYearEndCsvParseResult
from app.services.transfer_pricing_io import generate_transfer_pricing_adjustments_csv_template, parse_transfer_pricing_adjustments_csv, TransferPricingCsvParseResult
from app.services.pe_io import generate_permanent_establishments_csv_template, parse_permanent_establishments_csv, PermanentEstablishmentsCsvParseResult
from app.services.flow_through_io import generate_flow_through_entities_csv_template, parse_flow_through_entities_csv, FlowThroughAllocationsCsvParseResult
from app.services.allocable_tax_io import generate_allocable_tax_items_csv_template, parse_allocable_tax_items_csv, AllocableTaxItemsCsvParseResult
from app.services.integrity_adjustments_io import generate_integrity_adjustments_csv_template, parse_integrity_adjustments_csv, IntegrityAdjustmentsCsvParseResult
from app.services.integrity_resolve_v2 import get_resolution_catalog, build_integrity_resolve_template
from app.services.prior_year_status_io import generate_prior_year_status_csv_template, parse_prior_year_status_csv, PriorYearStatusCsvParseResult
from app.services.tp_migration_v2 import migrate_tp_from_aye
from app.services.templates_v2 import generate_tested_jurisdiction_template

from app.services.models import CalculationRequest, CalculationResponse
from app.services.models_v2 import (
    CalculationRequestV2,
    CalculationResponseV2,
    TestedJurisdictionInputV2,
    ScenarioAdvanceYearRequestV2,
    ScenarioAdvanceYearResponseV2,
    TPMigrateFromAYERequestV2,
    TPMigrateFromAYEResponseV2,
    ValidationResponseV2,
    TestedJurisdictionsBuildRequestV2,
    TestedJurisdictionsBuildResponseV2,
    AllocationPreviewResponseV2,
    AllocationPreviewItemV2,

    IntegrityResolutionCatalogItemV2,
    IntegrityResolveTemplateRequestV2,
    IntegrityResolveTemplateResponseV2,

)
from app.services.excel_io import build_template_xlsx, parse_template_xlsx
from app.services.calculator import calculate
from app.services.calculator_v2 import calculate_v2
from app.services.scenario_v2 import advance_year_scenario
from app.services.builder_v2 import build_tested_jurisdictions_from_entities
from app.services.validate_v2 import validate_request_v2
from app.services.election_catalog import as_public_dict

router = APIRouter()


@router.get("/v1/template")
def download_template():
    """Download the Excel input template."""
    path = build_template_xlsx()
    return FileResponse(
        path,
        filename="simplified_etr_safe_harbour_template.xlsx",
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


@router.post("/v1/calc", response_model=CalculationResponse)
def calc_json(req: CalculationRequest):
    """Calculate from JSON input."""
    try:
        return calculate(req)
    except ValueError as e:
        # User-correctable validation / modelling errors
        raise HTTPException(status_code=400, detail=str(e)) from e


@router.post("/v1/calc-from-excel")
async def calc_from_excel(file: UploadFile = File(...)):
    """Upload Excel template and calculate."""
    try:
        contents = await file.read()
        req = parse_template_xlsx(contents)
        resp = calculate(req)
        return resp.model_dump()
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


@router.get("/v1/election-catalog")
def election_catalog():
    """Return a lightweight catalogue of elections/adjustments.

    Used by the prototype web UI and also mirrors the Excel ElectionCatalog sheet.
    """

    return as_public_dict()


@router.get("/v2/election-catalog")
def election_catalog_v2():
    # Same catalogue, but v2 clients may rely on 'term_type' to drive multi-year UX.
    return as_public_dict()


@router.post("/v2/calc", response_model=CalculationResponseV2)
def calculate_api_v2(req: CalculationRequestV2):
    try:
        return calculate_v2(req)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))




@router.post("/v2/preview/allocations", response_model=AllocationPreviewResponseV2)
def preview_allocations_v2(req: CalculationRequestV2):
    """Preview Section 5.1 allocation effects (Module 6).

    This runs the v2 calculator and returns only the pre/post allocation snapshots and the allocation ledger,
    so UIs can show users how amounts move before they commit to a full multi-year workflow.
    """
    try:
        resp = calculate_v2(req)
        items = []
        for r in resp.results:
            # These fields are populated by the Module 6 allocation engine.
            items.append(
                AllocationPreviewItemV2(
                    tested_jurisdiction_id=r.tested_jurisdiction_id,
                    jurisdiction_code=r.jurisdiction_code,
                    label=r.label,
                    simplified_income_pre_allocations=float(r.simplified_income_pre_allocations or 0.0),
                    simplified_taxes_pre_allocations=float(r.simplified_taxes_pre_allocations or 0.0),
                    simplified_income_post_allocations=float(r.simplified_income_post_allocations or float(r.simplified_income or 0.0)),
                    simplified_taxes_post_allocations=float(r.simplified_taxes_post_allocations or float(r.simplified_taxes or 0.0)),
                    allocation_ledger=list(r.allocation_ledger or []),
                    allocation_warnings=list(r.allocation_warnings or []),
                )
            )
        return AllocationPreviewResponseV2(
            fiscal_year=req.fiscal_year,
            reporting_currency=resp.reporting_currency,
            items=items,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/v2/entities/csv-template")
def entities_csv_template_v2():
    """Download a CSV template for entity roll-up uploads (v2)."""

    content = generate_entities_csv_template()
    return StreamingResponse(
        iter([content]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=entity_rollup_template.csv"},
    )


@router.get("/v2/templates/fx-rates.csv")
def fx_rates_csv_template_v2():
    """Download a CSV template for FX rates uploads (v2).

    This supports v4 module 2 (currency translation scaffolding).
    """

    content = generate_fx_rates_csv_template()
    return StreamingResponse(
        iter([content]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=fx_rates_template.csv"},
    )



@router.get("/v2/templates/prior-year-status.csv")
def prior_year_status_csv_template_v2():
    """Download a CSV template for prior-year status register rows (Box 7.2) (v2)."""

    content = generate_prior_year_status_csv_template()
    return StreamingResponse(
        iter([content]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=prior_year_status.csv"},
    )


@router.post("/v2/prior-year-status/parse-csv", response_model=PriorYearStatusCsvParseResult)
async def prior_year_status_parse_csv_v2(
    file: UploadFile = File(...),
    allow_partial: bool = Query(
        default=False,
        description=(
            "If false (default), any row-level errors will return HTTP 400. "
            "If true, returns parsed prior-year status rows along with issues (some rows may be dropped)."
        ),
    ),
):
    """Upload a CSV of prior-year status rows (Box 7.2) and parse into structured register entries."""

    try:
        contents = await file.read()
        parsed = parse_prior_year_status_csv(contents)
        has_errors = any(i.severity == "error" for i in parsed.issues)
        if has_errors and not allow_partial:
            raise HTTPException(status_code=400, detail=parsed.model_dump())
        return parsed
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


# ---------------------------------------------------------------------------
# Integrity 'Resolve helper' (v4 Module 10.1)
# ---------------------------------------------------------------------------


@router.get("/v2/integrity/resolution-catalog", response_model=list[IntegrityResolutionCatalogItemV2])
def integrity_resolution_catalog_v2():
    """Return the list of integrity issue codes that support a 'Resolve' action.

    UIs can use this to decide when to show a one-click button and what default
    adjustment kind/principle to propose.
    """

    return get_resolution_catalog()


@router.post("/v2/integrity/resolve-template", response_model=IntegrityResolveTemplateResponseV2)
def integrity_resolve_template_v2(payload: IntegrityResolveTemplateRequestV2):
    """Build a draft IntegrityAdjustmentV2 for a given integrity issue.

    Intended for UIs to create a documentation/audit-trail entry quickly.
    """

    try:
        return build_integrity_resolve_template(payload)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e





@router.get("/v2/templates/integrity-adjustments.csv")
def integrity_adjustments_csv_template_v2():
    """Download a CSV template for integrity adjustments (OECD Box 7.3) (v2)."""

    content = generate_integrity_adjustments_csv_template()
    return StreamingResponse(
        iter([content]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=integrity_adjustments.csv"},
    )


@router.post("/v2/integrity-adjustments/parse-csv", response_model=IntegrityAdjustmentsCsvParseResult)
async def integrity_adjustments_parse_csv_v2(
    file: UploadFile = File(...),
    allow_partial: bool = Query(
        default=False,
        description=(
            "If false (default), any row-level errors will return HTTP 400. "
            "If true, returns parsed integrity adjustments along with issues (some rows may be dropped)."
        ),
    ),
):
    """Upload a CSV of integrity adjustments (Box 7.3) and parse into structured rows."""

    try:
        contents = await file.read()
        parsed = parse_integrity_adjustments_csv(contents)
        has_errors = any(i.severity == "error" for i in parsed.issues)
        if has_errors and not allow_partial:
            raise HTTPException(status_code=400, detail=parsed.model_dump())
        return parsed
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


@router.get("/v2/templates/after-year-end-adjustments.csv")
def after_year_end_adjustments_csv_template_v2():
    """Download a CSV template for after-year-end adjustments (OECD Box 4.6) (v2)."""

    content = generate_after_year_end_adjustments_csv_template()
    return StreamingResponse(
        iter([content]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=after_year_end_adjustments.csv"},
    )


@router.post("/v2/after-year-end-adjustments/parse-csv", response_model=AfterYearEndCsvParseResult)
async def after_year_end_adjustments_parse_csv_v2(
    file: UploadFile = File(...),
    allow_partial: bool = Query(
        default=False,
        description=(
            "If false (default), any row-level errors will return HTTP 400. "
            "If true, returns parsed adjustments along with issues (some rows may be dropped)."
        ),
    ),
):
    """Upload a CSV of after-year-end adjustments (Box 4.6) and parse into structured rows."""

    try:
        contents = await file.read()
        parsed = parse_after_year_end_adjustments_csv(contents)
        has_errors = any(i.severity == "error" for i in parsed.issues)
        if has_errors and not allow_partial:
            raise HTTPException(status_code=400, detail=parsed.model_dump())
        return parsed
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e




@router.get("/v2/templates/transfer-pricing-adjustments.csv")
def transfer_pricing_adjustments_csv_template_v2():
    """Download a CSV template for transfer pricing adjustment register entries (OECD section 5.2) (v2)."""

    content = generate_transfer_pricing_adjustments_csv_template()
    return StreamingResponse(
        iter([content]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=transfer_pricing_adjustments.csv"},
    )


@router.post("/v2/transfer-pricing-adjustments/parse-csv", response_model=TransferPricingCsvParseResult)
async def transfer_pricing_adjustments_parse_csv_v2(
    file: UploadFile = File(...),
    allow_partial: bool = Query(
        default=False,
        description=(
            "If false (default), any row-level errors will return HTTP 400. "
            "If true, returns parsed adjustments along with issues (some rows may be dropped)."
        ),
    ),
):
    """Upload a CSV of transfer pricing adjustments (section 5.2 register) and parse into structured rows."""

    try:
        contents = await file.read()
        parsed = parse_transfer_pricing_adjustments_csv(contents)
        has_errors = any(i.severity == "error" for i in parsed.issues)
        if has_errors and not allow_partial:
            raise HTTPException(status_code=400, detail=parsed.model_dump())
        return parsed
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e




@router.get("/v2/templates/permanent-establishments.csv")
def permanent_establishments_csv_template_v2():
    """Download a CSV template for Permanent Establishment linkage register (v2)."""

    content = generate_permanent_establishments_csv_template()
    return StreamingResponse(
        iter([content]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=permanent_establishments.csv"},
    )


@router.post("/v2/permanent-establishments/parse-csv", response_model=PermanentEstablishmentsCsvParseResult)
async def permanent_establishments_parse_csv_v2(
    file: UploadFile = File(...),
    allow_partial: bool = Query(
        default=False,
        description=(
            "If false (default), any row-level errors will return HTTP 400. "
            "If true, returns parsed rows along with issues (some rows may be dropped)."
        ),
    ),
):
    """Upload a CSV of Permanent Establishment linkage rows and parse into PermanentEstablishmentV2 objects."""

    try:
        contents = await file.read()
        parsed = parse_permanent_establishments_csv(contents)
        has_errors = any(i.severity == "error" for i in parsed.issues)
        if has_errors and not allow_partial:
            raise HTTPException(status_code=400, detail=parsed.model_dump())
        return parsed
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


@router.get("/v2/templates/flow-through-entities.csv")
def flow_through_entities_csv_template_v2():
    """Download a CSV template for flow-through / tax-transparent entity allocation lines (v2)."""

    content = generate_flow_through_entities_csv_template()
    return StreamingResponse(
        iter([content]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=flow_through_entities.csv"},
    )


@router.post("/v2/flow-through-entities/parse-csv", response_model=FlowThroughAllocationsCsvParseResult)
async def flow_through_entities_parse_csv_v2(
    file: UploadFile = File(...),
    allow_partial: bool = Query(
        default=False,
        description=(
            "If false (default), any row-level errors will return HTTP 400. "
            "If true, returns parsed rows along with issues (some rows may be dropped)."
        ),
    ),
):
    """Upload a CSV of flow-through allocation lines and parse into FlowThroughEntityAllocationV2 objects."""

    try:
        contents = await file.read()
        parsed = parse_flow_through_entities_csv(contents)
        has_errors = any(i.severity == "error" for i in parsed.issues)
        if has_errors and not allow_partial:
            raise HTTPException(status_code=400, detail=parsed.model_dump())
        return parsed
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


@router.get("/v2/templates/allocable-tax-items.csv")
def allocable_tax_items_csv_template_v2():
    """Download a CSV template for allocable tax items (Article 4.3.2 references) (v2)."""

    content = generate_allocable_tax_items_csv_template()
    return StreamingResponse(
        iter([content]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=allocable_tax_items.csv"},
    )


@router.post("/v2/allocable-tax-items/parse-csv", response_model=AllocableTaxItemsCsvParseResult)
async def allocable_tax_items_parse_csv_v2(
    file: UploadFile = File(...),
    allow_partial: bool = Query(
        default=False,
        description=(
            "If false (default), any row-level errors will return HTTP 400. "
            "If true, returns parsed rows along with issues (some rows may be dropped)."
        ),
    ),
):
    """Upload a CSV of allocable tax items and parse into AllocableTaxItemV2 objects."""

    try:
        contents = await file.read()
        parsed = parse_allocable_tax_items_csv(contents)
        has_errors = any(i.severity == "error" for i in parsed.issues)
        if has_errors and not allow_partial:
            raise HTTPException(status_code=400, detail=parsed.model_dump())
        return parsed
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e

@router.post("/v2/transfer-pricing-adjustments/migrate-from-aye", response_model=TPMigrateFromAYEResponseV2)
def migrate_tp_from_aye_v2(payload: TPMigrateFromAYERequestV2):
    """Convert TP-tagged Box 4.6 after-year-end rows into TP register entries.

    This endpoint supports a one-click migration UX in UI builders (e.g., Anything.com):
      - Users may have entered TP adjustments historically using after_year_end_adjustments[] rows
        with is_transfer_pricing_related=true.
      - The tool now models TP adjustments using a dedicated transfer_pricing_adjustments[] register.

    The endpoint returns:
      - transfer_pricing_adjustments: existing + migrated register entries
      - remaining_after_year_end_adjustments: non-TP AYE rows (and optionally unmigrated TP rows)
      - issues: row-level migration warnings/errors

    If payload.options.allow_partial is false and any errors occur, the endpoint returns HTTP 400
    with the response payload in the error detail.
    """

    try:
        resp = migrate_tp_from_aye(payload)
        has_errors = any(i.severity == "error" for i in resp.issues)
        if has_errors and not payload.options.allow_partial:
            raise HTTPException(status_code=400, detail=resp.model_dump())
        return resp
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
@router.post("/v2/fx/parse-csv", response_model=FxRatesCsvParseResult)
async def fx_rates_parse_csv_v2(
    file: UploadFile = File(...),
    allow_partial: bool = Query(
        default=False,
        description=(
            "If false (default), any row-level errors will return HTTP 400. "
            "If true, returns parsed fx rates along with issues (some rows may be dropped)."
        ),
    ),
):
    """Upload a CSV of FX rates and parse into FxRateV2 rows.

    Intended for UI clients to validate and preview FX rates.
    """

    try:
        contents = await file.read()
        parsed = parse_fx_rates_csv(contents)
        has_errors = any(i.severity == "error" for i in parsed.issues)
        if has_errors and not allow_partial:
            raise HTTPException(status_code=400, detail=parsed.model_dump())
        return parsed
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


@router.post("/v2/entities/parse-csv", response_model=EntitiesCsvParseResult)
async def entities_parse_csv_v2(
    file: UploadFile = File(...),
    default_tested_jurisdiction_id: str | None = Query(
        default=None,
        description=(
            "Optional. If provided, all parsed rows are assumed to belong to this Tested Jurisdiction. "
            "If the CSV also includes tested_jurisdiction_id, that column is still returned via grouped_entities."
        ),
    ),
    default_jurisdiction_code: str | None = Query(
        default=None,
        description="Optional. If provided and a row omits jurisdiction_code, this value is used.",
    ),
    allow_partial: bool = Query(
        default=False,
        description=(
            "If false (default), any row-level errors will return HTTP 400. "
            "If true, returns parsed entities along with issues (some rows may be dropped)."
        ),
    ),
):
    """Upload a CSV of entities and parse into EntityFactsV2 rows.

    This endpoint is designed for UI clients (including Anything.com) to:
      - validate the CSV,
      - preview parsed entities,
      - then populate the Tested Jurisdiction's entities[] table.
    """

    try:
        contents = await file.read()
        parsed = parse_entities_csv(
            contents,
            default_tested_jurisdiction_id=default_tested_jurisdiction_id,
            default_jurisdiction_code=default_jurisdiction_code,
        )
        has_errors = any(i.severity == "error" for i in parsed.issues)
        if has_errors and not allow_partial:
            raise HTTPException(status_code=400, detail=parsed.model_dump())
        return parsed
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e




@router.post("/v2/tested-jurisdictions/build", response_model=TestedJurisdictionsBuildResponseV2)
def build_tested_jurisdictions_v2(payload: TestedJurisdictionsBuildRequestV2):
    """Build a Tested Jurisdiction list from entity rows (UI helper).

    This is intended for front-ends (e.g. Anything.com) to take a flat entity upload
    and produce a correctly-shaped tested_jurisdictions[] array with entity roll-up buckets.
    """

    try:
        return build_tested_jurisdictions_from_entities(payload)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


@router.post("/v2/validate", response_model=ValidationResponseV2)
def validate_request_endpoint_v2(req: CalculationRequestV2):
    """Validate a v2 request for completeness and allocation readiness.

    Returns issues with severity. Does not run calculations.
    """

    try:
        return validate_request_v2(req)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e

@router.get("/v2/tested-jurisdiction/template", response_model=TestedJurisdictionInputV2)
def tested_jurisdiction_template_v2(
    tested_jurisdiction_id: str = Query(..., description="Unique identifier for the Tested Jurisdiction."),
    jurisdiction_code: str | None = Query(default=None, description="Optional country/territory code."),
    tested_jurisdiction_type: str | None = Query(
        default=None,
        description="Optional classification (e.g., 'investment_entity', 'stateless', 'standard').",
    ),
    aggregation_method: str = Query(
        default="JURISDICTION_FACTS",
        description="JURISDICTION_FACTS, ENTITY_ROLLUP, or MIXED.",
    ),
    label: str | None = Query(default=None, description="Optional display label."),
    include_placeholder_entity: bool = Query(
        default=True,
        description="If aggregation_method is ENTITY_ROLLUP or MIXED, include a placeholder entity row.",
    ),
):
    """Return a skeleton TestedJurisdictionInputV2 JSON object.

    Intended for UI builders to create a correctly-shaped Tested Jurisdiction object.
    """

    return generate_tested_jurisdiction_template(
        tested_jurisdiction_id=tested_jurisdiction_id,
        jurisdiction_code=jurisdiction_code,
        tested_jurisdiction_type=tested_jurisdiction_type,
        aggregation_method=aggregation_method,
        label=label,
        include_placeholder_entity=include_placeholder_entity,
    )


@router.post("/v2/scenario/advance-year", response_model=ScenarioAdvanceYearResponseV2)
def scenario_advance_year_v2(payload: ScenarioAdvanceYearRequestV2):
    """Build the next fiscal year request payload from the previous request + response.

    This enables multi-year "planner" workflows without requiring server-side persistence.
    Clients store the returned next_request and can submit it to /api/v2/calc.
    """

    try:
        return advance_year_scenario(payload)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
