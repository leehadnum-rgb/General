import unittest
from datetime import date

from app.services.models_v2 import (
    CalculationRequestV2,
    FiscalYearV2,
    TestedJurisdictionInputV2,
    TestedJurisdictionCompositionV2,
    JurisdictionFactsV2,
    PriorYearStatusV2,
)
from app.services.calculator_v2 import calculate_v2


class Module8EntryReentryTests(unittest.TestCase):
    def test_entry_criteria_computed_pass(self):
        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            prior_years_status=[
                PriorYearStatusV2(
                    tested_jurisdiction_id="US_MAIN",
                    fiscal_year_start=date(2025, 1, 1),
                    regime="FULL_GLOBE",
                    topup_tax_status="NONE",
                ),
                PriorYearStatusV2(
                    tested_jurisdiction_id="US_MAIN",
                    fiscal_year_start=date(2026, 1, 1),
                    regime="FULL_GLOBE",
                    topup_tax_status="NONE",
                ),
            ],
            tested_jurisdictions=[
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="US_MAIN",
                    jurisdiction_code="US",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    facts=JurisdictionFactsV2(jpbt=100.0, current_tax_expense=20.0),
                )
            ],
        )

        resp = calculate_v2(req)
        r = resp.results[0]
        self.assertIsNotNone(r.entry_reentry_status)
        self.assertEqual(r.entry_reentry_status.mode, "FIRST_ELECTION")
        self.assertTrue(r.entry_reentry_status.entry_criteria_satisfied)
        self.assertTrue(r.eligible)

    def test_entry_criteria_computed_fail(self):
        req = CalculationRequestV2(
            fiscal_year=FiscalYearV2(start_date=date(2027, 1, 1)),
            minimum_rate=0.15,
            prior_years_status=[
                PriorYearStatusV2(
                    tested_jurisdiction_id="US_MAIN",
                    fiscal_year_start=date(2025, 1, 1),
                    regime="FULL_GLOBE",
                    topup_tax_status="TOPUP_TAX",
                ),
                PriorYearStatusV2(
                    tested_jurisdiction_id="US_MAIN",
                    fiscal_year_start=date(2026, 1, 1),
                    regime="FULL_GLOBE",
                    topup_tax_status="NONE",
                ),
            ],
            tested_jurisdictions=[
                TestedJurisdictionInputV2(
                    tested_jurisdiction_id="US_MAIN",
                    jurisdiction_code="US",
                    composition=TestedJurisdictionCompositionV2(aggregation_method="JURISDICTION_FACTS"),
                    facts=JurisdictionFactsV2(jpbt=100.0, current_tax_expense=20.0),
                )
            ],
        )

        resp = calculate_v2(req)
        r = resp.results[0]
        self.assertIsNotNone(r.entry_reentry_status)
        self.assertEqual(r.entry_reentry_status.mode, "FIRST_ELECTION")
        self.assertFalse(r.entry_reentry_status.entry_criteria_satisfied)
        self.assertFalse(r.eligible)
        self.assertTrue(any("Entry criteria" in x or "24" in x for x in r.ineligibility_reasons))


if __name__ == "__main__":
    unittest.main()
