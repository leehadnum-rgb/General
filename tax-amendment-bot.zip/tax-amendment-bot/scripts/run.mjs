import "dotenv/config";
import fs from "node:fs/promises";
import crypto from "node:crypto";
import { openaiJsonSchema } from "./lib/openai.mjs";
import { exaSearch, exaContents } from "./lib/exa.mjs";
import { getNextAlert, markAlert, upsertPost } from "./lib/anything.mjs";

const LOG_LEVEL = process.env.LOG_LEVEL || "info";
const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };

function log(level, msg, obj) {
  if ((LEVELS[level] || 20) < (LEVELS[LOG_LEVEL] || 20)) return;
  const line = obj ? `${msg} ${JSON.stringify(obj)}` : msg;
  console.log(`[${new Date().toISOString()}] ${level.toUpperCase()} ${line}`);
}

function mustEnv(key) {
  const v = process.env[key];
  if (!v) throw new Error(`Missing env var: ${key}`);
  return v;
}

function toBool(x, def = false) {
  if (x == null) return def;
  return String(x).toLowerCase() === "true";
}

function clamp(n, lo, hi) {
  return Math.max(lo, Math.min(hi, n));
}

function domainOf(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return null;
  }
}

function truncate(text, maxChars) {
  if (!text) return "";
  if (text.length <= maxChars) return text;
  return text.slice(0, maxChars) + "\n\n[TRUNCATED]";
}

function makeSlug(title) {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, "")
    .trim()
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .slice(0, 80);
}

function countMarkdownLinks(markdown) {
  // Simple heuristic: count occurrences of ](http
  return (markdown.match(/\]\(https?:\/\//g) || []).length;
}

function citationsPerUpdateMin(markdown) {
  // Split by level-2 headings. We expect: "## General" then "## Update..."
  const parts = markdown.split(/\n##\s+/).map((s) => s.trim());
  // First part includes anything before first "##" (likely empty). Remove.
  const headings = parts.filter(Boolean);

  // Find and drop the General section (first heading should be "General")
  const updateSections = [];
  for (let i = 0; i < headings.length; i++) {
    const section = headings[i];
    const headingLine = section.split(/\n/)[0].trim();
    const body = section.slice(headingLine.length).trim();
    if (headingLine.toLowerCase() === "general") continue;
    updateSections.push({ heading: headingLine, body });
  }
  if (!updateSections.length) return 0;

  const counts = updateSections.map((s) => countMarkdownLinks(s.body));
  return Math.min(...counts);
}

async function readFileText(relPath) {
  const p = new URL(relPath, import.meta.url);
  return await fs.readFile(p, "utf-8");
}

async function readSchema(relPath) {
  return JSON.parse(await readFileText(relPath));
}

async function main() {
  const ANYTHING_BASE_URL = mustEnv("ANYTHING_BASE_URL");
  const ANYTHING_INTERNAL_TOKEN = mustEnv("ANYTHING_INTERNAL_TOKEN");

  const OPENAI_API_KEY = mustEnv("OPENAI_API_KEY");
  const EXA_API_KEY = mustEnv("EXA_API_KEY");

  const OPENAI_MODEL_CLASSIFY = process.env.OPENAI_MODEL_CLASSIFY || "gpt-5-nano";
  const OPENAI_MODEL_PICK_SOURCES = process.env.OPENAI_MODEL_PICK_SOURCES || "gpt-5-mini";
  const OPENAI_MODEL_DRAFT = process.env.OPENAI_MODEL_DRAFT || "gpt-5.2";
  const OPENAI_REASONING_EFFORT = process.env.OPENAI_REASONING_EFFORT || "medium";
  const OPENAI_STORE = toBool(process.env.OPENAI_STORE, false);

  const EXA_SEARCH_TYPE = process.env.EXA_SEARCH_TYPE || "auto";
  const MAX_ALERTS_PER_RUN = parseInt(process.env.MAX_ALERTS_PER_RUN || "1", 10);

  const AUTOPUBLISH_THRESHOLD = parseFloat(process.env.AUTOPUBLISH_THRESHOLD || "0.85");
  const MIN_UPDATES_FOR_PUBLISH = parseInt(process.env.MIN_UPDATES_FOR_PUBLISH || "1", 10);
  const MIN_CITATIONS_PER_UPDATE = parseInt(process.env.MIN_CITATIONS_PER_UPDATE || "1", 10);
  const MAX_SOURCE_TEXT_CHARS = parseInt(process.env.MAX_SOURCE_TEXT_CHARS || "60000", 10);

  const classifyPrompt = await readFileText("../prompts/classify.md");
  const pickPrompt = await readFileText("../prompts/pick_sources.md");
  const draftPrompt = await readFileText("../prompts/draft_article.md");

  const classifySchema = await readSchema("../schemas/classify.schema.json");
  const pickSchema = await readSchema("../schemas/pick_sources.schema.json");
  const draftSchema = await readSchema("../schemas/draft.schema.json");

  log("info", "Job starting", { MAX_ALERTS_PER_RUN });

  for (let idx = 0; idx < MAX_ALERTS_PER_RUN; idx++) {
    log("info", "Fetching next alert...");
    const alert = await getNextAlert({ baseUrl: ANYTHING_BASE_URL, token: ANYTHING_INTERNAL_TOKEN });

    if (!alert) {
      log("info", "No pending alerts. Exiting.");
      return;
    }

    const alertId = alert.id;
    log("info", "Processing alert", { alertId, headline: alert.headline });

    try {
      // 1) Classify
      const classifyMessages = [
        { role: "system", content: classifyPrompt },
        {
          role: "user",
          content: JSON.stringify(
            {
              headline: alert.headline || "",
              snippet: alert.snippet || "",
              bloomberg_url: alert.source_url || null,
            },
            null,
            2
          ),
        },
      ];

      const classify = await openaiJsonSchema({
        apiKey: OPENAI_API_KEY,
        model: OPENAI_MODEL_CLASSIFY,
        messages: classifyMessages,
        schemaName: "tax_amendment_classification",
        schema: classifySchema,
        reasoningEffort: OPENAI_REASONING_EFFORT,
        store: OPENAI_STORE,
      });

      log("info", "Classification result", classify.parsed);

      if (!classify.parsed.is_relevant) {
        await markAlert({
          baseUrl: ANYTHING_BASE_URL,
          token: ANYTHING_INTERNAL_TOKEN,
          alertId,
          status: "irrelevant",
          payload: { classify: classify.parsed },
        });
        log("info", "Marked alert irrelevant", { alertId });
        continue;
      }

      // 2) Search for candidate sources
      const includeDomains = (classify.parsed.preferred_domains || []).filter(Boolean);
      const searchQueries = (classify.parsed.search_queries || []).slice(0, 8);

      const candidates = [];
      for (const q of searchQueries) {
        log("info", "Exa search", { q, includeDomainsCount: includeDomains.length });
        const res = await exaSearch({
          apiKey: EXA_API_KEY,
          query: q,
          type: EXA_SEARCH_TYPE,
          numResults: 10,
          includeDomains,
          highlightsMaxCharacters: 2500,
        });

        for (const r of res?.results || []) {
          candidates.push({
            title: r.title,
            url: r.url,
            publishedDate: r.publishedDate || null,
            highlights: r.highlights || [],
            scoreHint: Array.isArray(r.highlightScores) ? Math.max(...r.highlightScores) : null,
          });
        }
      }

      // Deduplicate by URL
      const seen = new Set();
      const deduped = [];
      for (const c of candidates) {
        if (!c?.url) continue;
        if (seen.has(c.url)) continue;
        seen.add(c.url);
        deduped.push(c);
      }

      // If Exa found nothing, fail gracefully
      if (!deduped.length) {
        await markAlert({
          baseUrl: ANYTHING_BASE_URL,
          token: ANYTHING_INTERNAL_TOKEN,
          alertId,
          status: "error",
          payload: { error: "No search results from Exa", classify: classify.parsed },
        });
        log("warn", "No Exa results; marked alert error", { alertId });
        continue;
      }

      // 3) Pick primary sources
      const pickMessages = [
        { role: "system", content: pickPrompt },
        {
          role: "user",
          content: JSON.stringify(
            {
              alert: { headline: alert.headline, snippet: alert.snippet, bloomberg_url: alert.source_url },
              candidates: deduped.slice(0, 40),
            },
            null,
            2
          ),
        },
      ];

      const picked = await openaiJsonSchema({
        apiKey: OPENAI_API_KEY,
        model: OPENAI_MODEL_PICK_SOURCES,
        messages: pickMessages,
        schemaName: "tax_amendment_primary_sources",
        schema: pickSchema,
        reasoningEffort: OPENAI_REASONING_EFFORT,
        store: OPENAI_STORE,
      });

      log("info", "Picked sources", {
        amending: picked.parsed.amending.url,
        base: picked.parsed.base.url,
        confidence: picked.parsed.confidence,
      });

      // 4) Fetch full text for the two chosen sources
      const urls = [picked.parsed.amending.url, picked.parsed.base.url];
      const contents = await exaContents({
        apiKey: EXA_API_KEY,
        urls,
        text: true,
        maxAgeHours: 24,
      });

      const byUrl = new Map();
      for (const r of contents?.results || []) {
        byUrl.set(r.url, r);
      }

      const amendingText = truncate(byUrl.get(picked.parsed.amending.url)?.text || "", MAX_SOURCE_TEXT_CHARS);
      const baseText = truncate(byUrl.get(picked.parsed.base.url)?.text || "", MAX_SOURCE_TEXT_CHARS);

      if (!amendingText || !baseText) {
        await markAlert({
          baseUrl: ANYTHING_BASE_URL,
          token: ANYTHING_INTERNAL_TOKEN,
          alertId,
          status: "error",
          payload: {
            error: "Could not retrieve full text for one or both sources",
            picked: picked.parsed,
          },
        });
        log("warn", "Missing source text; marked alert error", { alertId });
        continue;
      }

      // 5) Draft the article
      const draftMessages = [
        { role: "system", content: draftPrompt },
        {
          role: "user",
          content: JSON.stringify(
            {
              alert: { headline: alert.headline, snippet: alert.snippet, bloomberg_url: alert.source_url },
              metadata: {
                jurisdiction_guess: classify.parsed.jurisdiction_guess,
                hinted_instruments: classify.parsed.hinted_instruments,
                amending: {
                  title: picked.parsed.amending.title,
                  url: picked.parsed.amending.url,
                  domain: domainOf(picked.parsed.amending.url),
                },
                base: {
                  title: picked.parsed.base.title,
                  url: picked.parsed.base.url,
                  domain: domainOf(picked.parsed.base.url),
                },
              },
              sources: {
                amending_text: amendingText,
                base_text: baseText,
              },
            },
            null,
            2
          ),
        },
      ];

      const drafted = await openaiJsonSchema({
        apiKey: OPENAI_API_KEY,
        model: OPENAI_MODEL_DRAFT,
        messages: draftMessages,
        schemaName: "tax_amendment_article",
        schema: draftSchema,
        reasoningEffort: OPENAI_REASONING_EFFORT,
        store: OPENAI_STORE,
      });

      // 6) Autopublish gate
      const pipelineConfidence = clamp(
        Math.min(
          classify.parsed.relevance_confidence ?? 0,
          picked.parsed.confidence ?? 0,
          drafted.parsed.confidence ?? 0
        ),
        0,
        1
      );

      const citationsMin = citationsPerUpdateMin(drafted.parsed.markdown || "");
      const updatesCount = drafted.parsed.updates_count ?? 0;

      const autopublish =
        pipelineConfidence >= AUTOPUBLISH_THRESHOLD &&
        !!picked.parsed.amending.is_primary_source &&
        !!picked.parsed.base.is_primary_source &&
        updatesCount >= MIN_UPDATES_FOR_PUBLISH &&
        citationsMin >= MIN_CITATIONS_PER_UPDATE;

      const status = autopublish ? "published" : "draft";

      const post = {
        title: drafted.parsed.title,
        slug: makeSlug(drafted.parsed.title),
        status,
        markdown: drafted.parsed.markdown,
        jurisdiction: drafted.parsed.jurisdiction,
        issued_on: drafted.parsed.issued_on,
        authority: drafted.parsed.authority,
        instrument_type: drafted.parsed.instrument_type,
        amending: drafted.parsed.amending,
        base: drafted.parsed.base,
        confidence: pipelineConfidence,
        confidence_rationale: drafted.parsed.confidence_rationale,
        debug: {
          classify: classify.parsed,
          picked: picked.parsed,
          drafted_meta: {
            confidence: drafted.parsed.confidence,
            citationsMin,
            updatesCount,
          },
        },
      };

      await upsertPost({
        baseUrl: ANYTHING_BASE_URL,
        token: ANYTHING_INTERNAL_TOKEN,
        alertId,
        post,
      });

      await markAlert({
        baseUrl: ANYTHING_BASE_URL,
        token: ANYTHING_INTERNAL_TOKEN,
        alertId,
        status: autopublish ? "published" : "drafted",
        payload: { pipelineConfidence, citationsMin, updatesCount, autopublish },
      });

      log("info", "Done", { alertId, status, pipelineConfidence, citationsMin, updatesCount });
    } catch (err) {
      const errId = crypto.randomUUID();
      log("error", "Unhandled error", { alertId, errId, message: err?.message || String(err) });

      await markAlert({
        baseUrl: ANYTHING_BASE_URL,
        token: ANYTHING_INTERNAL_TOKEN,
        alertId,
        status: "error",
        payload: { errId, message: err?.message || String(err) },
      });
    }
  }

  log("info", "Job finished");
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
